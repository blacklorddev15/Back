PIXEL X ULTRA — single user
===========================

THREE WAYS IN — pick whichever suits you.

  1. NUMBERED MENU (easiest)
       npm install
       npm start
     First start with no session shows:
        [1] paste a session ID
        [2] pair with a phone number
     Choose 2, type your number, get an 8-character code, enter it in
     WhatsApp -> Linked devices -> Link with phone number.

  2. PHONE NUMBER FROM .env
       PAIR_PHONE=254712345678
       npm start
     Same code, no menu — good for panels that restart on their own.

  3. SESSION STRING FROM .env
       SESSION_ID=Pixel~eyJ...      (or plain base64)
       npm start
     Starts already connected. Accepts Pixel~, Pixel:, PIXEL-, pxu| prefixes.

WHAT HAPPENS AFTERWARD
  Credentials land in ./session/creds.json and are reused on every restart.
  A restart never asks you to pair again unless WhatsApp logged the device
  out (401) — in that case the bot prints "device was logged out" and you
  re-run with option 1 or 2.

COMMANDS WORTH KNOWING
  .menu            everything
  .setprefix <x>   change prefix to any word, number or emoji
  .prefixfree on   use commands with no prefix at all (692 commands)
  .setstick <cmd>  reply to a sticker to bind it to a command
  .checkban <num>  is that number on WhatsApp / banned
  .play <song>     mp3 as a file + as audio, nothing else
  .settings        boxed read-out of every toggle

LOGS
  Coloured in the console, and data/server.log when run via a pipe/panel.
