require('dotenv').config();
const fs = require('fs');
const chalk = require('chalk');

// Contact details
global.sessionid = process.env.SESSION_ID || '';
global.dbSite = process.env.DB_SITE || '';
global.ytname = process.env.YT_NAME || "YT: @PixelTechs";
global.socialm = process.env.SOCIAL_M || "GitHub: PixelTech";
global.location = process.env.LOCATION || "Nigeria, Port Harcourt";

// Creator details
global.prefix = process.env.PREFIX || '.';
global.ownername = process.env.OWNER_NAME || 'Pixel';
global.botname = process.env.BOT_NAME || 'Pixel';

// Settings: true=enable false=disable
global.autoRecording = process.env.AUTO_RECORDING === 'true';
global.autoTyping = process.env.AUTO_TYPING === 'true';
global.autorecordtype = process.env.AUTO_RECORD_TYPE === 'true';
global.autoread = process.env.AUTO_READ === 'true';
global.autobio = process.env.AUTO_BIO !== 'false';
global.autoviewstatus = process.env.AUTO_VIEW_STATUS !== 'false';
global.welcome = process.env.WELCOME !== 'false';
global.autoreact = process.env.AUTO_REACT === 'true';
global.autolikestatus = process.env.AUTO_LIKE_STATUS === 'true';
global.autoOffline = process.env.AUTO_OFFLINE === 'true';


// Sticker details
global.packname = process.env.PACKNAME || 'Sticker By';
global.author = process.env.AUTHOR || 'Pixel Tech\n\nContact: +2347047504860';
// Default settings 2
global.wm = process.env.WM || "Youtube @PixelTechs";
global.link = process.env.LINK || 'https://github.com/frozenlorddev/pixel-x-ultra';

// Reply messages
global.mess = {
    done: '✅ Done',
    prem: '⚠️ Premium only',
    admin: '⚠️ Admins only',
    botAdmin: '⚠️ Need admin',
    owner: '⛔ Owner only',
    group: 'ℹ️ Groups only',
    private: 'ℹ️ DM only',
    wait: '⏳ Working…',
    error: '❌ Error',
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.redBright(`Updated: ${__filename}`));
    delete require.cache[file];
    require(file);
});
