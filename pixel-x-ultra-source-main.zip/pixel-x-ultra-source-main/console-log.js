'use strict';
/**
 * console-log.js — Pixel console output for the Pixel X Ultra build.
 *
 * Same frame as server one:
 *
 *   ┏━━━━━━━━━━━━━『 Pixel 』━━━━━━━━━━━━━─
 *   » Session: +254729632649
 *   » Sent Time: Monday, 19:42:03 SGT
 *   » Date: 19/10/2026
 *   » Message Type: conversation
 *   » Sender Name: blacklord
 *   » Chat ID: 254729632649
 *   » Message: .menu
 *   ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━─ ⳹
 *
 * chalk is optional: without it the same text prints uncoloured instead of throwing.
 */

const chalk = (() => {
  try { return require('chalk'); } catch { return null; }
})();

const BRAND = process.env.BOT_NAME || 'Pixel';

const C = {
  blue: text => (chalk ? chalk.blue.bold(text) : text),
  cyan: text => (chalk ? chalk.cyan(text) : text),
  green: text => (chalk ? chalk.green(text) : text),
  yellow: text => (chalk ? chalk.yellow(text) : text),
  red: text => (chalk ? chalk.red(text) : text),
  grey: text => (chalk ? chalk.grey(text) : text),
  bold: text => (chalk ? chalk.bold(text) : text),
};

const BARS = 13;
const FOOT_BARS = 40;
const HEAD = '┏' + '━'.repeat(BARS) + '『 ' + BRAND + ' 』' + '━'.repeat(BARS) + '─';
const FOOT = '┗' + '━'.repeat(FOOT_BARS) + '─ ⳹';

const TZ = process.env.CONSOLE_TZ || 'Africa/Nairobi'; // container sets TZ=UTC; keep the bot's own zone
const TZ_SHORT = {
  'Africa/Nairobi': 'EAT', 'Africa/Kampala': 'EAT', 'Africa/Dar_es_Salaam': 'EAT',
  'Africa/Addis_Ababa': 'EAT', 'Africa/Lagos': 'WAT', 'Africa/Johannesburg': 'SAST',
  'Africa/Cairo': 'EET', 'Asia/Dubai': 'GST', 'Asia/Kolkata': 'IST', 'Asia/Karachi': 'PKT',
  'Asia/Singapore': 'SGT', 'Europe/London': 'GMT', UTC: 'UTC',
};

function zoneLabel() {
  if (TZ_SHORT[TZ]) return TZ_SHORT[TZ];
  try {
    const name = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, timeZoneName: 'short' })
      .formatToParts(new Date()).find(p => p.type === 'timeZoneName')?.value;
    return name && !name.startsWith('GMT') ? name : (TZ.split('/')[1] || TZ);
  } catch { return TZ; }
}

function stamp(date = new Date()) {
  const fmt = new Intl.DateTimeFormat('en-GB', {
    timeZone: TZ, weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
  });
  const p = {};
  for (const { type, value } of fmt.formatToParts(date)) p[type] = value;
  return {
    time: `${p.weekday}, ${p.hour}:${p.minute}:${p.second} ${zoneLabel()}`,
    date: `${p.day}/${p.month}/${p.year}`,
  };
}

function extractText(message) {
  if (!message) return '';
  return (
    message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.documentWithCaptionMessage?.message?.documentMessage?.caption ||
    message.buttonsResponseMessage?.selectedDisplayText ||
    message.templateButtonReplyMessage?.selectedDisplayText ||
    message.listResponseMessage?.title ||
    ''
  );
}

const number = jid => String(jid || '').split('@')[0].split(':')[0];

/** One incoming-message block. */
function logIncoming({ msg, session, groupName } = {}) {
  try {
    const chatJid = msg?.key?.remoteJid || '';
    const isGroup = chatJid.endsWith('@g.us');
    const sender = msg?.key?.participant || chatJid;
    const type = msg?.message ? Object.keys(msg.message)[0] : 'unknown';
    const text = extractText(msg?.message);
    const { time, date } = stamp();

    const lines = [C.blue(HEAD)];
    if (session) lines.push(C.grey(`» Session: +${session}`));
    lines.push(C.grey('» Sent Time: ') + C.cyan(time));
    lines.push(C.grey('» Date: ') + C.cyan(date));
    lines.push(C.grey('» Message Type: ') + C.cyan(type));
    lines.push(C.grey('» Sender Name: ') + C.green(msg?.pushName || 'Unknown'));
    lines.push(C.grey('» Chat ID: ') + C.cyan(number(chatJid)));
    if (isGroup) {
      lines.push(C.grey('» Group: ') + C.green(groupName || 'Unknown'));
      lines.push(C.grey('» Group JID: ') + C.cyan(number(chatJid)));
    } else {
      lines.push(C.grey('» Sender: ') + C.cyan(number(sender)));
    }
    if (text) lines.push(C.grey('» Message: ') + C.yellow(String(text).split('\n')[0].slice(0, 160)));
    lines.push(C.blue(FOOT));
    console.log(lines.join('\n'));
  } catch (e) {
    console.log(`» [console-log] could not render message block: ${e.message}`);
  }
}

/** Boot banner. */
function logBoot({ session = null, connected = false, mode = 'private', port = null } = {}) {
  const lines = [C.blue(HEAD)];
  lines.push(C.grey('» Bot: ') + C.green(BRAND));
  if (session) lines.push(C.grey('» Session: ') + C.cyan('+' + session));
  lines.push(C.grey('» Status: ') + (connected ? C.green('🟢 connected') : C.yellow('🟡 connecting')));
  lines.push(C.grey('» Mode: ') + C.cyan(String(mode).toUpperCase()));
  if (port) lines.push(C.grey('» Dashboard: ') + C.cyan(':' + port));
  lines.push(C.blue(FOOT));
  console.log(lines.join('\n'));
}

/** Login menu — same wording and colours as server one. */
function loginMenu() {
  console.log(C.green('Choose Any WhatsApp Login method:'));
  console.log(C.yellow('1. ✓Enter Session ID'));
  console.log(C.yellow('2. ✓Enter Phone Number'));
}

function sessionPrompt() {
  console.log('');
  console.log(C.yellow("Enter your session ID, if it doesn't work put it in .env file"));
  console.log(C.yellow('Session Formats accepted:'));
  console.log(C.yellow('Use a supported WhatsApp session string.'));
}

function numberPrompt() {
  console.log('');
  console.log(C.green('Enter your WhatsApp phone number with country code.'));
  console.log(C.green('Example: 2547xxxxxxxx'));
}

function pairingCodeBlock(code) {
  const pretty = String(code || '').match(/.{1,4}/g)?.join('-') || code;
  const inner = `\n🔑 Your Pairing Code: ${pretty}\n`;
  console.log(chalk ? chalk.black.bgCyanBright(inner) : inner);
  console.log(C.blue('\n1. Open WhatsApp → Settings → Linked Devices'));
  console.log(C.blue('2. Tap "Link a Device"'));
  console.log(C.blue('3. Enter the code above\n'));
}

/** Small helpers for one-line status messages. */
const tagged = (msg, colour = 'cyan') => {
  const paint = C[colour] || C.cyan;
  const body = String(msg);
  if (body.includes('\n')) console.log(C.blue(`[ ${BRAND} ]`), paint(body));
  else console.log(`${C.blue(`[ ${BRAND} ]`)} ${paint(body)}`);
};
const logInfo = (label, msg) => tagged(`[INFO]  ${label}${msg ? ` – ${msg}` : ''}`, 'cyan');
const logSuccess = (label, msg) => tagged(`[OK]    ${label}${msg ? ` – ${msg}` : ''}`, 'green');
const logWarn = (label, msg) => tagged(`[WARN]  ${label}${msg ? ` – ${msg}` : ''}`, 'yellow');
const logError = (label, msg) => tagged(`[ERR]   ${label}${msg ? ` – ${msg}` : ''}`, 'red');

module.exports = {
  BRAND, HEAD, FOOT, loginMenu, sessionPrompt, numberPrompt, pairingCodeBlock,
  logIncoming, logBoot, extractText, stamp, zoneLabel,
  tagged, logInfo, logSuccess, logWarn, logError, C,
};
