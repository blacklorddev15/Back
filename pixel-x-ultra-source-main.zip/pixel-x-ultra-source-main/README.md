# Pixel X Ultra

A WhatsApp bot — single-user build. One WhatsApp account, one process, no
multi-tenant machinery. Node.js 20+, runs on a panel, a VPS, Render, Railway or
anything that can keep a Node process alive.

## What's in here

| File | Purpose |
|---|---|
| `index.js` | Supervisor + HTTP server. Serves the landing page and keeps the child process alive. |
| `Pixel.js` | The message pipeline: 420+ commands, group guards, anti-link/anti-call, status tools. |
| `config.js` | Bot name, owner, prefix, feature defaults. |
| `lib/endpoints.js` | Upstream REST/CDN hosts the commands call. Override with env vars. |
| `lib/index.html` | Landing page served at `/`. |
| `lib/wa.js` | Baileys wiring. |
| `lib/menu421.js`, `database/menu_list.json` | The boxed menu and its command list. |
| `doctor-single.js` | Self-check: config, session, database, permissions. |

## Run it

```bash
npm install
npm start
```

First start with no session offers two ways in:

1. **Paste a session ID** — a session string from a pairing generator.
2. **Pair with a phone number** — type the number, get an 8-character code, then
   enter it in WhatsApp → Linked devices → Link with phone number.

Non-interactive hosts (panels that restart on their own) should use env instead:

```bash
PAIR_PHONE=254712345678    # mint a code from the number at boot
SESSION_ID=Pixel~...       # or skip pairing entirely
```

## Environment

| Variable | Default | Meaning |
|---|---|---|
| `SESSION_ID` | — | Session string, skips pairing. |
| `PAIR_PHONE` | — | Number to request a pairing code for. |
| `PORT` | `5000` | HTTP port for the landing page and `/keepalive`. |
| `PIXEL_API_ROOT` | see `lib/endpoints.js` | Primary REST API for downloads/search/AI tools. |
| `PIXEL_API_MIRROR` | see `lib/endpoints.js` | Secondary REST API. |
| `PIXEL_CDN_ROOT` | see `lib/endpoints.js` | Upload/CDN host. |

The three endpoint variables exist because the commands call third-party
services. Point them at your own backend and nothing in the source needs to
change.

## Commands

Prefix defaults to `.` — see `config.js`. `.menu` prints the full list. Plain
text without the prefix is ignored by design (chatbot replies default to off).

## Notes

- Session credentials live in `session/` and are git-ignored. Never commit them.
- `npm run doctor` verifies config, database files and session state before you
  deploy.
- The bot must run on a number that is **not** the number you message it from.

## License

MIT — see `LICENSE`.
