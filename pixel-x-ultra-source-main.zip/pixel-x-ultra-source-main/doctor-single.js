#!/usr/bin/env node
"use strict";
let hasDotenv = true;
try { require("dotenv").config(); } catch { hasDotenv = false; }
const fs = require("fs");
const path = require("path");
let fails = 0;
const ok = (m) => console.log("  \u2714 " + m);
const warn = (m) => console.log("  \u25B8 " + m);
const bad = (m) => { fails++; console.log("  \u2716 " + m); };
console.log("\nPIXEL X ULTRA - pre-flight\n");
const major = Number(process.versions.node.split(".")[0]);
major >= 20 ? ok("node " + process.versions.node) : bad("node " + process.versions.node + " (needs 20+)");
hasDotenv ? ok("dotenv installed") : bad("dotenv missing - npm install");
const envFile = path.join(__dirname, ".env");
fs.existsSync(envFile) ? ok(".env found") : warn(".env missing - copy .env.example");

const creds = path.join(__dirname, "session", "creds.json");
const hasCreds = fs.existsSync(creds);
const sid = String(process.env.SESSION_ID || "").trim();
const phone = String(process.env.PAIR_PHONE || "").replace(/\D/g, "");

if (hasCreds) ok("session/creds.json present - starts connected");
else if (sid) ok("SESSION_ID set - will import on start");
else if (phone) ok("PAIR_PHONE=" + phone + " - will print a code");
else warn("no session, no SESSION_ID, no PAIR_PHONE - numbered menu on start");

let lib = "none";
try { require.resolve("@whiskeysockets/baileys"); lib = "@whiskeysockets/baileys"; }
catch {
  try { require.resolve("blacklord-baileys"); lib = "blacklord-baileys"; }
  catch {
    try { require.resolve("baileys"); lib = "baileys"; }
    catch { lib = "none"; }
  }
}
lib === "none" ? bad("no WhatsApp library installed") : ok("library: " + lib);

const forced = String(process.env.WA_LIB || "auto").toLowerCase();
forced === "auto" ? ok("WA_LIB=auto") : warn("WA_LIB=" + forced + " (forced)");

["Pixel.js", "index.js", "config.js", "lib/menu421.js", "database/menu_list.json", "database/pixelpic.jpg"]
  .forEach((f) => (fs.existsSync(path.join(__dirname, f)) ? ok(f) : bad(f + " missing")));

console.log("");
if (fails) {
  console.log("  " + fails + " problem(s) - fix them before npm start\n");
  process.exit(1);
}
console.log("  all good - run npm start\n");
