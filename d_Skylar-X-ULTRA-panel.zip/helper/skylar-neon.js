// ============================================================
//   helper/skylar-neon.js  –  Neon pairing channel for SKYLAR X ULTRA
//
//   The website (Vercel) writes pairing requests to Neon
//   (skylar_pairing_requests). This bot polls them every 3s,
//   generates the WhatsApp pairing code, and writes it back.
// ============================================================
'use strict';

const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.NEON_DATABASE_URL || require('../settings').NEON_DATABASE_URL,
});

async function claimPairingRequest() {
  const { rows } = await pool.query(
    `UPDATE skylar_pairing_requests SET status = 'processing', updated_at = now()
     WHERE id = (SELECT id FROM skylar_pairing_requests
                 WHERE status = 'pending' AND expires_at > now()
                 ORDER BY id LIMIT 1)
     RETURNING *`
  );
  return rows[0] || null;
}

async function setPairingCode(id, code) {
  await pool.query(
    `UPDATE skylar_pairing_requests SET status = 'code_generated', pairing_code = $1, updated_at = now() WHERE id = $2`,
    [code, id]
  );
}

async function markPairingFailed(id, error) {
  await pool.query(
    `UPDATE skylar_pairing_requests SET status = 'failed', error = $1, updated_at = now() WHERE id = $2`,
    [String(error || 'unknown reason').slice(0, 300), id]
  );
}

async function markPairingConnected(id, phone) {
  await pool.query(
    `UPDATE skylar_pairing_requests SET status = 'connected', updated_at = now() WHERE id = $1`,
    [id]
  );
}

async function expireStaleRequests() {
  await pool.query(
    `UPDATE skylar_pairing_requests SET status = 'expired'
     WHERE status IN ('pending', 'processing') AND expires_at < now()`
  );
}

// Mirror active sessions to Neon so the website stats are real
async function upsertSession(sessionId, phone, status) {
  try {
    await pool.query(
      `INSERT INTO skylar_sessions (id, phone, status, updated_at) VALUES ($1, $2, $3, now())
       ON CONFLICT (id) DO UPDATE SET phone = EXCLUDED.phone, status = EXCLUDED.status, updated_at = now()`,
      [sessionId, phone || null, status]
    );
  } catch { /* stats only – never crash the bot */ }
}

// starter: (sessionId, phone, pairingCodeCallback) => Promise<sock>
function startSkylarPairingLoop(starter) {
  setInterval(async () => {
    try {
      const row = await claimPairingRequest();
      if (!row) return;

      const sessionId = `web_${row.phone}`;

      if (global._activeSockets && global._activeSockets.has(sessionId)) {
        await markPairingFailed(row.id, 'This number is already connected.');
        return;
      }
      const { sessionExists } = require('./function');
      if (sessionExists(sessionId)) {
        await markPairingFailed(row.id, 'A session for this number already exists. Delete it first.');
        return;
      }

      const sock = await starter(sessionId, row.phone, async (code) => {
        await setPairingCode(row.id, code);
      });
      if (sock) sock.__pairingRequestId = row.id;
    } catch (e) {
      console.error('[SKYLAR-NEON] poll error:', e.message);
    }
  }, 3000);

  setInterval(() => {
    expireStaleRequests().catch(() => {});
  }, 60000);

  console.log('[SKYLAR-NEON] Pairing loop started (3s interval)');
}

module.exports = {
  startSkylarPairingLoop,
  claimPairingRequest,
  setPairingCode,
  markPairingFailed,
  markPairingConnected,
  expireStaleRequests,
  upsertSession,
};
