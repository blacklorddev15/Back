'use strict';
require('dotenv').config();

module.exports = {
  TELEGRAM_TOKEN:     process.env.TELEGRAM_TOKEN    || '8592412132:AAFc84dmZDg97nyQDslFTd2UZaFP_D1kMis',
  OWNER_TELEGRAM_ID:  process.env.OWNER_TELEGRAM_ID || '8736349675',
  OWNER_NAME:         process.env.OWNER_NAME        || 'rita',
  SUDO_NUMBER:        process.env.SUDO_NUMBER       || '', // extra owner WA number
GITHUB_TOKEN:    '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',
GITHUB_USERNAME: 'talkless',
GITHUB_REPO:     'database',
GITHUB_BRANCH:   'main',
PANEL_URL:       '',   // your Pterodactyl URL for ping
WEBSITE_URL:     'https://skylar-pairing.vercel.app',   // pairing website (Vercel)
  BOT_NAME:      '〖𝐒𝐊𝐘𝐋Λ𝐑 𝐗 𝐔𝐋𝐓𝐑𝐀〗 ',
  BOT_VERSION: '4.0.0',
  COMPANY:     'SKYLAR X ULTRA',
  CREDITS:     'rita',

  SESSION_DIR:      './sessions',
  NEON_DATABASE_URL: process.env.NEON_DATABASE_URL || 'postgresql://neondb_owner:npg_I08bQKJLwOkN@ep-billowing-darkness-aybn2tcg.c-5.us-east-2.aws.neon.tech/neondb?sslmode=require', // Neon pairing channel (website)
  DEFAULT_PREFIX:   '.',
  DEFAULT_MENU_IMG:  'https://i.ibb.co/zTp3tR1H/4775bb5831b5.jpg',

  REQUIRED_CHANNEL:      process.env.REQUIRED_CHANNEL      || '',
  REQUIRED_GROUP:        process.env.REQUIRED_GROUP        || '',
  REQUIRED_CHANNEL_LINK: process.env.REQUIRED_CHANNEL_LINK || '',
  REQUIRED_GROUP_LINK:   process.env.REQUIRED_GROUP_LINK   || '',
  REQUIRED_CHANNEL_ID:   process.env.REQUIRED_CHANNEL_ID   || '',
  REQUIRED_GROUP_ID:     process.env.REQUIRED_GROUP_ID     || '',

  AUTO_FOLLOW_NEWSLETTERS: [
  '120363426406372312@newsletter',
'120363425539800408@newsletter',

  ], // add as many as you want
  AUTO_JOIN_GROUPS:        [], // add as many as you want
};
