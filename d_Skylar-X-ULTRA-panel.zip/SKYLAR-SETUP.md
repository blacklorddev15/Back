# SKYLAR X ULTRA — Panel Setup

## Install (Pterodactyl)
1. Upload these files into your bot folder.
2. Console: `npm install`
3. Start: `npm start` (or `node index.js`)

## Neon pairing (website)
- Website is live: **https://skylar-pairing.vercel.app**
- Bot polls `skylar_pairing_requests` every 3s → generates the pairing code → writes it back.
- The Neon connection string is already in `settings.js` (NEON_DATABASE_URL) — or override with the same env var on the panel.
- `schema-skylar.sql` — apply once in the Neon SQL editor (already applied).
- Admin section on the website can change the Neon database connection + manage premium keys (password: blacklorddev).

## Telegram
- Reply keyboard with 9 buttons (VARNOX style): PAIR SKYLAR X ULTRA, DEL PAIR, GENERATE SESSION, TELEGRAM ID, OWNER, BUY PANEL, ADMIN PANEL, MY PROFILE, LIST PAIRED.
- Commands: /pair <number>, /delpair <number>, /listpaired, /listsession, /broadcast, /reportissue, /premonly, /addprem, /delprem, /listprem, /addowner

## Sessions
- Stored in ./sessions (local) + synced from GitHub (talkless/database).
- Website-paired sessions are created as web_<number> automatically.
