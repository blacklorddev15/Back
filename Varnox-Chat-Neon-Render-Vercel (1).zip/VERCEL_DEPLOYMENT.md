# Varnox Chat — Vercel, Render, and Neon Deployment

## Architecture

Use Vercel for the Expo web frontend, Render for the Express API, and Neon for PostgreSQL:

```text
Vercel  →  Expo web frontend
Render  →  Express API
Neon    →  PostgreSQL database
```

The backend has been migrated from MySQL to PostgreSQL and uses the Neon-compatible `pg` driver with Drizzle PostgreSQL migrations.

## Vercel frontend

1. Import this repository into Vercel.
2. Use these settings:
   - Framework preset: **Other**
   - Install command: `pnpm install --frozen-lockfile`
   - Build command: `pnpm build:web`
   - Output directory: `dist`
3. Add `EXPO_PUBLIC_API_BASE_URL` with the public Render API URL.
4. Deploy the website.

The project includes `vercel.json` with the same build and SPA fallback configuration.

## Render backend

Create a Render **Web Service** connected to this repository.

- Runtime: **Node**
- Build command: `corepack enable && pnpm install --frozen-lockfile && pnpm drizzle-kit migrate && pnpm build`
- Start command: `pnpm start`

Add these environment variables in Render:

- `DATABASE_URL` — the pooled Neon PostgreSQL connection string from Neon’s Connect panel
- `JWT_SECRET` — a long random secret
- `OWNER_OPEN_ID` — the owner identifier used by the app
- `RESEND_API_KEY`
- `RESEND_FROM`
- `NODE_ENV=production`
- `VONAGE_API_KEY` and `VONAGE_API_SECRET` only if SMS verification is enabled

Neon connection strings normally look like:

```text
postgresql://user:password@ep-example-pooler.region.aws.neon.tech/dbname?sslmode=require
```

Never commit this value to Git or place it in the ZIP. Store it only in Render environment variables.

## Database migration

The active migration is in `drizzle/0000_warm_stingray.sql`. Render runs the migration during deployment using the `DATABASE_URL` value.

If you prefer to migrate manually from a local machine:

```bash
pnpm install --frozen-lockfile
DATABASE_URL="your-neon-url" pnpm drizzle-kit migrate
```

## Frontend connection

After Render deploys, copy its HTTPS URL, for example:

```text
https://varnox-api.onrender.com
```

Set this Vercel variable:

```text
EXPO_PUBLIC_API_BASE_URL=https://varnox-api.onrender.com
```

Then redeploy Vercel.

## Admin account

The registered `blacklorddev` account is assigned the `admin` role in the project database. Never commit its password or store it in Vercel or Render configuration.

## Native builds

Vercel and Render host the browser frontend and API. Android and iOS builds still use Expo/EAS for packaging and store submission.
