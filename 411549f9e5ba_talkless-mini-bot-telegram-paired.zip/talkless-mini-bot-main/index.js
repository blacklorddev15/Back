const config = require("./config");
const express = require("express");
const TelegramBot = require("node-telegram-bot-api");
const { loadCommands } = require("./telegram/loadCommands");

const PORT = process.env.PORT || 5000;

if (!config.BOT_TOKEN) {
    console.error("❌ Missing BOT_TOKEN. Add it to your .env file and restart.");
    process.exit(1);
}

// Loaded lazily inside startWhatsAppRuntime so a problem in the WhatsApp stack
// can never stop the Telegram bot from booting.
let manager = null;
let managerReady = false;

// ─── Health check server (kept for hosting platforms that expect an open port) ──
const app = express();
app.get("/", (_req, res) =>
    res.status(200).send("Talkless Mini Bot (Telegram) is running.")
);
app.get("/health", async (_req, res) => {
    const payload = {
        status: "alive",
        uptime: process.uptime(),
        whatsapp: config.ENABLE_WHATSAPP ? "enabled" : "disabled",
    };

    if (managerReady && manager) {
        try {
            const stats = await manager.getStats();
            payload.accounts = {
                registered: stats.accounts.registered,
                live: stats.accounts.live,
                pending: stats.accounts.pending,
                byStatus: stats.accounts.byStatus,
            };
            payload.commands = stats.commands.total;
        } catch (error) {
            payload.accounts = { error: error.message };
        }
    }

    res.status(200).json(payload);
});
app.listen(PORT, () => console.log(`✅ Health server running on port ${PORT}`));

// ─── Telegram bot ────────────────────────────────────────────────────────────
const bot = new TelegramBot(config.BOT_TOKEN, { polling: true });
const commands = loadCommands();

bot.on("polling_error", (err) => console.error("Polling error:", err.message));

bot.onText(/^\/(\w+)(?:@\S+)?(?:\s+(.*))?$/, async (msg, match) => {
    const commandName = match[1].toLowerCase();
    const cmd = commands.get(commandName);
    if (!cmd) return;

    try {
        await cmd.execute(bot, msg, commands);
    } catch (error) {
        console.error(`Command error [${commandName}]:`, error);
        try {
            await bot.sendMessage(msg.chat.id, `🚨 Command failed: ${error.message}`);
        } catch (_) {}
    }
});

console.log(
    `💜 Talkless Mini Bot starting on Telegram, ${commands.size} command(s) loaded: ${[
        ...commands.keys(),
    ].join(", ")}`
);

// ─── WhatsApp multi-account runtime ──────────────────────────────────────────
// The Telegram bot is already serving at this point; linked accounts are
// restored in the background so a slow WhatsApp handshake never delays /start.
async function startWhatsAppRuntime() {
    if (!config.ENABLE_WHATSAPP) {
        console.log("ℹ️  WhatsApp runtime disabled (ENABLE_WHATSAPP=false)");
        return;
    }

    try {
        manager = require("./whatsapp/manager");
        const info = await manager.init({
            notify: (chatId, text, options) => bot.sendMessage(chatId, text, options),
        });
        managerReady = true;
        console.log(
            `✅ WhatsApp runtime ready — ${info.commands} command(s), ${info.accounts} account(s) online`
        );
    } catch (error) {
        console.error("❌ WhatsApp runtime failed to start:", error.message);
        console.error("   The Telegram bot keeps running; /pair will report the failure.");
    }
}

startWhatsAppRuntime();

// ─── Shutdown ────────────────────────────────────────────────────────────────
let shuttingDown = false;
async function shutdown(signal) {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`\n${signal} received — closing WhatsApp sockets...`);
    try {
        await manager?.shutdown();
    } catch (error) {
        console.error("Shutdown error:", error.message);
    }
    try {
        bot.stopPolling();
    } catch (_) {}
    process.exit(0);
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
