const fs = require("fs-extra");
if (fs.existsSync(".env"))
    require("dotenv").config({ path: __dirname + "/.env", quiet: true });

// ─── Env coercion helpers ────────────────────────────────────────────────────
function toBool(value, fallback) {
    if (value === undefined || value === null || value === "") return fallback;
    return ["true", "1", "yes", "on"].includes(String(value).trim().toLowerCase());
}

function toInt(value, fallback) {
    const parsed = parseInt(value, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

module.exports = {
    BOT_TOKEN: process.env.BOT_TOKEN,
    OWNER_ID: process.env.OWNER_ID,
    TIME_ZONE: process.env.TIME_ZONE,
    DATABASE_URL: process.env.DATABASE_URL, // Postgres (Neon/Supabase/Render/Heroku builtin)... falls back to path: ./talkless_mini_bot/database/database.db if not provided

    // ─── Multi-account WhatsApp linking ──────────────────────────────────────
    // Master switch for the WhatsApp side; the Telegram bot still runs without it.
    ENABLE_WHATSAPP: toBool(process.env.ENABLE_WHATSAPP, true),

    // Where per-account auth state lives, relative to the project root.
    SESSIONS_DIR: process.env.SESSIONS_DIR || "sessions",

    // Hard ceiling on simultaneously linked accounts in this process.
    MAX_SESSIONS: toInt(process.env.MAX_SESSIONS, 100),

    // How many numbers one Telegram user may link.
    MAX_SESSIONS_PER_USER: toInt(process.env.MAX_SESSIONS_PER_USER, 2),

    // How many pairing handshakes may be in flight at once. Each pending pair
    // holds an open socket, so this stays small on purpose.
    PENDING_PAIR_LIMIT: toInt(process.env.PENDING_PAIR_LIMIT, 5),

    // Pairing rate limits (per Telegram user).
    PAIR_COOLDOWN_SECONDS: toInt(process.env.PAIR_COOLDOWN_SECONDS, 60),
    PAIR_WINDOW_SECONDS: toInt(process.env.PAIR_WINDOW_SECONDS, 3600),
    PAIR_MAX_PER_WINDOW: toInt(process.env.PAIR_MAX_PER_WINDOW, 5),

    // How long to wait for WhatsApp to hand back a pairing code.
    PAIR_TIMEOUT_SECONDS: toInt(process.env.PAIR_TIMEOUT_SECONDS, 120),

    // A code nobody entered within this window is dropped and the slot freed.
    PAIR_STALE_SECONDS: toInt(process.env.PAIR_STALE_SECONDS, 300),

    // Stagger between restoring accounts on boot, so a restart does not open
    // every socket at the same instant.
    SESSION_RESTORE_DELAY_MS: toInt(process.env.SESSION_RESTORE_DELAY_MS, 3000),

    // Per-account reconnect cap before an account is parked as offline.
    SESSION_MAX_RECONNECT_ATTEMPTS: toInt(process.env.SESSION_MAX_RECONNECT_ATTEMPTS, 10),

    // The number that paired an account can always command it, even when the
    // bot-wide MODE is "private".
    SESSION_OWNER_IS_SUPERUSER: toBool(process.env.SESSION_OWNER_IS_SUPERUSER, true),

    // Off by default: doing these silently on other people's numbers is a
    // WhatsApp ban risk.
    SESSION_AUTO_FOLLOW_NEWSLETTER: toBool(process.env.SESSION_AUTO_FOLLOW_NEWSLETTER, false),
    SESSION_AUTO_JOIN_GROUP: toBool(process.env.SESSION_AUTO_JOIN_GROUP, false),
    SESSION_STARTUP_MESSAGE: toBool(process.env.SESSION_STARTUP_MESSAGE, false),

    // Refuse new pairings above this RSS, to keep the box from swapping.
    MAX_RSS_MB: toInt(process.env.MAX_RSS_MB, 1500),

    // Prefix shown in the "commands are live" hint.
    PAIR_HELP_PREFIX: process.env.PAIR_HELP_PREFIX || ".",
};

let fileName = require.resolve(__filename);
fs.watchFile(fileName, () => {
    fs.unwatchFile(fileName);
    console.log(`Writing File: ${__filename}`);
    delete require.cache[fileName];
    require(fileName);
});
