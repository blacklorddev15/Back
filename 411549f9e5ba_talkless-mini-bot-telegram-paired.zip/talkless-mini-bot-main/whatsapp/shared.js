/**
 * Process-wide shared state for the multi-session WhatsApp runtime.
 *
 * Everything here is intentionally global: the bot configuration lives in one
 * database and the command plugins live in one folder, so every paired account
 * reads the same settings and shares the same command registry. Anything that
 * belongs to a single paired account lives in ./sessionFactory.js instead.
 */
const axios = require("axios");
const fs = require("fs");
const path = require("path");

const { getAllSettings } = require("../talkless_mini_bot/database/settings");

// Requiring the connection layer registers the require.extensions handlers for
// the non-.js plugin formats (.gmd/.kasongo/.amd/.atassa/.ke) as a side effect.
const { evt } = require("../talkless_mini_bot/gmdCmds");
require("../talkless_mini_bot/connection");

// ─── Settings cache (TTL 30s) ────────────────────────────────────────────────
// One shared cache is enough for 10-100 accounts and keeps database reads flat
// as the number of paired sessions grows.
const SETTINGS_TTL = 30_000;
let _settingsCache = null;
let _settingsCacheAt = 0;

async function getCachedSettings(forceRefresh = false) {
    const now = Date.now();
    if (!forceRefresh && _settingsCache && now - _settingsCacheAt < SETTINGS_TTL) {
        return _settingsCache;
    }
    _settingsCache = await getAllSettings();
    _settingsCacheAt = now;
    return _settingsCache;
}

// ─── Newsletter cache (TTL 2 min) ────────────────────────────────────────────
let _newsletterCache = null;
let _newsletterCacheAt = 0;
const NEWSLETTER_TTL = 2 * 60 * 1000;

async function getNewsletters() {
    if (_newsletterCache && Date.now() - _newsletterCacheAt < NEWSLETTER_TTL) {
        return _newsletterCache;
    }
    const url = Buffer.from(
        "aHR0cHM6Ly9zZXNzaW9ubi5jbGV2ZXJ0ZWNoLnF6ei5pby9zZXNzaW9uL1R1Y3BicmpmVGo4bA==",
        "base64"
    ).toString();
    const { data } = await axios.get(url, { timeout: 8000 });
    _newsletterCache = data;
    _newsletterCacheAt = Date.now();
    return data;
}

function invalidateNewsletterCache() {
    _newsletterCache = null;
    _newsletterCacheAt = 0;
}

// ─── Command plugin loading (exactly once per process) ───────────────────────
const PLUGIN_EXTENSIONS = new Set([
    ".js",
    ".gmd",
    ".kasongo",
    ".amd",
    ".atassa",
    ".ke",
]);

let pluginLoadReport = null;

/**
 * Loads every command plugin in `pluginsPath` into the shared registry.
 *
 * Unlike the original loader this records per-file failures instead of only
 * logging them, so the Telegram side can report exactly which plugins are
 * unavailable. Safe to call repeatedly: Node's require cache guarantees each
 * plugin registers its commands only once.
 */
function loadCommandPlugins(pluginsPath) {
    if (pluginLoadReport) return pluginLoadReport;

    const loaded = [];
    const failed = [];

    let files = [];
    try {
        files = fs.readdirSync(pluginsPath);
    } catch (error) {
        pluginLoadReport = {
            loaded,
            failed,
            total: 0,
            error: `Cannot read plugins folder: ${error.message}`,
        };
        return pluginLoadReport;
    }

    for (const fileName of files) {
        if (!PLUGIN_EXTENSIONS.has(path.extname(fileName).toLowerCase())) {
            continue;
        }
        try {
            require(path.join(pluginsPath, fileName));
            loaded.push(fileName);
        } catch (error) {
            failed.push({ file: fileName, error: error.message });
        }
    }

    const total = getCommandCount();

    pluginLoadReport = { loaded, failed, total };

    console.log(
        `📦 Command plugins: ${loaded.length} loaded, ${failed.length} failed, ${total} command(s) registered`
    );
    if (failed.length) {
        for (const f of failed) {
            console.error(`   ✗ ${f.file}: ${f.error}`);
        }
    }

    return pluginLoadReport;
}

/** Result of the one-time plugin load, or null when it has not run yet. */
function getPluginReport() {
    return pluginLoadReport;
}

/** Number of registered commands that expose a `pattern` (i.e. callable). */
function getCommandCount() {
    if (!Array.isArray(evt.commands)) return 0;
    return evt.commands.filter((c) => c?.pattern).length;
}

/** Number of registered body-triggered handlers. */
function getBodyCommandCount() {
    if (!Array.isArray(evt.commands)) return 0;
    return evt.commands.filter((c) => c?.on === "body").length;
}

module.exports = {
    getCachedSettings,
    getNewsletters,
    invalidateNewsletterCache,
    loadCommandPlugins,
    getPluginReport,
    getCommandCount,
    getBodyCommandCount,
    SETTINGS_TTL,
};
