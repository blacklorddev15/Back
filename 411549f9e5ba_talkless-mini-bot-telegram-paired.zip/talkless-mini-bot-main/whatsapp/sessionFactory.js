/**
 * Per-account WhatsApp runtime.
 *
 * This is the original single-account entry point (legacy-whatsapp-index.js.bak)
 * turned into a factory so one process can run many independent paired accounts.
 *
 * What changed versus the legacy script:
 *  - Every mutable global (socket, message store, processed-message set, start
 *    time, reconnect counters, pairing state) now lives in the factory closure.
 *  - The shared connection handler was replaced with a per-account lifecycle:
 *    the original called process.exit(1) on logout/bad-session/too-many-retries,
 *    which would take every other user's account down with it.
 *  - Command plugins are loaded once by ./shared.js, not per account.
 *  - Auto-following the project newsletter, auto-joining a group and sending a
 *    startup message are opt-in for managed accounts (see config.js), because
 *    doing that silently on 10-100 users' own numbers is a ban risk.
 */
const path = require("path");
const {
    default: giftedConnect,
    downloadContentFromMessage,
    getContentType,
    fetchLatestWaWebVersion,
    DisconnectReason,
} = require("gifted-baileys");

const bot = require("../talkless_mini_bot");
const {
    saveAntiDelete,
    findAntiDelete,
    removeAntiDelete,
    SQLiteStore,
} = require("../talkless_mini_bot/database/messageStore");
const config = require("../config");
const {
    getCachedSettings,
    getNewsletters,
    invalidateNewsletterCache,
    getCommandCount,
} = require("./shared");

let sendButtons = null;
try {
    ({ sendButtons } = require("gifted-btns"));
} catch (_) {
    sendButtons = null;
}

let googleTTS = null;
try {
    googleTTS = require("google-tts-api");
} catch (_) {
    googleTTS = null;
}

// Loaded once for the whole process, not per account.
let fileTypeModule = null;
import("file-type")
    .then((m) => {
        fileTypeModule = m;
    })
    .catch(() => {});

const STATUS = {
    IDLE: "idle",
    CONNECTING: "connecting",
    PAIRING: "pairing",
    ACTIVE: "active",
    OFFLINE: "offline",
    LOGGED_OUT: "logged_out",
    FAILED: "failed",
};

const MAX_PROCESSED = 2000;
const RECONNECT_BASE_DELAY = 5000;
const RECONNECT_MAX_DELAY = 300_000;

/**
 * Disconnect reasons that mean the stored credentials are dead and the account
 * has to be paired again. Everything else is treated as transient.
 */
const FATAL_REASONS = new Set([
    DisconnectReason.loggedOut,
    DisconnectReason.badSession,
    DisconnectReason.multideviceMismatch,
    DisconnectReason.forbidden,
]);

/**
 * Extracts the numeric disconnect reason.
 *
 * The original code did `new Boom(lastDisconnect?.error)?.output?.statusCode`,
 * which silently turns any non-Boom error into 500 (= badSession) and would
 * then wipe a healthy account. We only trust an explicit status code and let
 * anything unknown fall through to the reconnect path.
 */
function disconnectReasonOf(lastDisconnect) {
    const error = lastDisconnect?.error;
    if (!error) return undefined;

    const candidates = [
        error?.output?.statusCode,
        error?.statusCode,
        error?.data?.statusCode,
    ];
    for (const candidate of candidates) {
        if (Number.isFinite(candidate)) return candidate;
    }

    if (typeof error === "object" && error.isBoom) {
        const code = error.output?.statusCode;
        if (Number.isFinite(code)) return code;
    }

    return undefined;
}

/**
 * Creates an isolated runtime for one paired WhatsApp account.
 *
 * @param {object}   options
 * @param {string}   options.key            Stable id for the account (telegram id + number).
 * @param {string}   options.sessionDir     Directory holding session.db for this account.
 * @param {Function} [options.onStatus]     Called with { key, status, detail } on every change.
 * @param {Function} [options.onLogout]     Called when the device is unlinked remotely.
 * @returns {{ key, start, stop, requestPairingCode, getSocket, getStatus, getInfo }}
 */
function createWhatsAppSession({ key, sessionDir, onStatus, onLogout }) {
    // ─── Per-account state ───────────────────────────────────────────────────
    let socket = null;
    let store = null;
    let stopped = false;
    let status = STATUS.IDLE;
    let statusDetail = "";
    let startedAt = null;
    let lastError = null;
    let reconnectAttempts = 0;
    let reconnectTimer = null;
    let pairingTimeout = null;
    let pairingRequested = false;
    let pairingWaiter = null;
    let pendingPairNumber = null;
    let listenersBound = false;

    const processedMessages = new Set();
    const helpersBound = new Set();

    // ─── Status plumbing ─────────────────────────────────────────────────────
    // Notifications are chained so a late "offline" write from stop() can never
    // overwrite a newer "failed"/"logged_out" write issued by the manager.
    let statusWrite = Promise.resolve();

    function setStatus(next, detail = "") {
        if (status === next && statusDetail === detail) return;
        status = next;
        statusDetail = detail;
        statusWrite = statusWrite
            .then(() => onStatus?.({ key, status: next, detail }))
            .catch(() => {});
    }

    /** Resolves once every queued status notification has been persisted. */
    function whenSettled() {
        return statusWrite;
    }

    // ─── Bounded processed-message set (max 2000, auto-evict oldest) ─────────
    function markProcessed(id) {
        if (!id) return true;
        if (processedMessages.has(id)) return false;
        if (processedMessages.size >= MAX_PROCESSED) {
            const first = processedMessages.values().next().value;
            processedMessages.delete(first);
        }
        processedMessages.add(id);
        return true;
    }

    // ─── JID resolver ────────────────────────────────────────────────────────
    async function resolveRealJid(sock, jid) {
        if (!jid) return null;
        if (!jid.endsWith("@lid")) return jid;
        try {
            const { getLidMapping } = require("../talkless_mini_bot/connection/groupCache");
            const cached = getLidMapping(jid);
            if (cached) return cached;
        } catch (_) {}
        try {
            const resolved = await sock.getJidFromLid(jid);
            if (resolved && !resolved.endsWith("@lid")) return resolved;
        } catch (_) {}
        try {
            const { getLidMappingFromDb } = require("../talkless_mini_bot/database/lidMapping");
            const fromDb = await getLidMappingFromDb(jid);
            if (fromDb) return fromDb;
        } catch (_) {}
        return jid;
    }

    // ─── Auto React ──────────────────────────────────────────────────────────
    function setupAutoReact(sock) {
        sock.ev.on("messages.upsert", async (mek) => {
            try {
                const ms = mek.messages[0];
                if (!ms?.message || ms.key.fromMe) return;

                const s = await getCachedSettings();
                const autoReactMode = s.AUTO_REACT || "off";
                if (autoReactMode === "off" || autoReactMode === "false") return;

                const from = ms.key.remoteJid;
                const isGroup = from?.endsWith("@g.us");
                const isDm = from?.endsWith("@s.whatsapp.net");

                const shouldReact =
                    autoReactMode === "all" ||
                    autoReactMode === "true" ||
                    (autoReactMode === "dm" && isDm) ||
                    (autoReactMode === "groups" && isGroup);

                if (!shouldReact) return;

                const randomEmoji =
                    bot.emojis[Math.floor(Math.random() * bot.emojis.length)];
                await bot.GiftedAutoReact(randomEmoji, ms, sock);
            } catch (err) {
                console.error(`[${key}] Auto reaction error:`, err.message);
            }
        });
    }

    // ─── Anti Delete + anti-sticker ──────────────────────────────────────────
    function setupAntiDelete(sock) {
        const botJid = `${sock.user?.id?.split(":")[0]}@s.whatsapp.net`;

        const realJid = (j) => (j && !j.endsWith("@lid") ? j : null);

        const getSender = (ms) => {
            const { key: mkey } = ms;
            return (
                realJid(mkey.participantPn) ||
                realJid(mkey.senderPn) ||
                realJid(ms.senderPn) ||
                realJid(mkey.participant) ||
                realJid(ms.participant) ||
                mkey.participantPn ||
                mkey.participant ||
                ms.participant ||
                (mkey.remoteJid?.endsWith("@g.us")
                    ? null
                    : realJid(mkey.remoteJid) || mkey.remoteJid)
            );
        };

        const getPushName = (ms) =>
            ms.pushName || ms.key?.pushName || ms.verifiedBizName || "Unknown";

        const getProtocolMessage = (ms) =>
            ms.message?.protocolMessage ||
            ms.message?.ephemeralMessage?.message?.protocolMessage ||
            ms.message?.viewOnceMessage?.message?.protocolMessage ||
            ms.message?.viewOnceMessageV2?.message?.protocolMessage;

        const getActualMessage = (ms) => {
            const msg = ms.message;
            if (!msg) return null;
            return (
                msg.ephemeralMessage?.message ||
                msg.viewOnceMessage?.message ||
                msg.viewOnceMessageV2?.message ||
                msg.documentWithCaptionMessage?.message ||
                msg
            );
        };

        sock.ev.on("messages.upsert", async ({ messages }) => {
            for (const ms of messages) {
                try {
                    if (!ms?.message) continue;
                    const { key: mkey } = ms;
                    if (
                        !mkey?.remoteJid ||
                        mkey.fromMe ||
                        mkey.remoteJid === "status@broadcast"
                    ) {
                        continue;
                    }

                    const protocolMsg = getProtocolMessage(ms);

                    if (protocolMsg?.type === 0) {
                        const deletedId = protocolMsg.key?.id;
                        const chatJid = mkey.remoteJid;
                        if (!deletedId) continue;

                        const deletedMsg = findAntiDelete(chatJid, deletedId);
                        if (!deletedMsg?.message) continue;

                        const deleter = getSender(ms) || mkey.remoteJid;
                        if (deleter === botJid) continue;

                        await bot.GiftedAntiDelete(
                            sock,
                            deletedMsg,
                            mkey,
                            deleter,
                            deletedMsg.originalSender,
                            botJid,
                            getPushName(ms),
                            deletedMsg.originalPushName
                        );
                        removeAntiDelete(chatJid, deletedId);
                        continue;
                    }

                    if (protocolMsg) continue;

                    const actualMessage = getActualMessage(ms);
                    if (!actualMessage) continue;

                    const from = mkey.remoteJid;
                    const isGroup = from.endsWith("@g.us");

                    const isSticker =
                        ms.message?.stickerMessage ||
                        ms.message?.ephemeralMessage?.message?.stickerMessage ||
                        ms.message?.viewOnceMessageV2?.message?.stickerMessage;

                    if (isGroup && isSticker) {
                        await bot.antiStickerHandler(ms, sock);
                    }

                    const sender = getSender(ms);
                    if (!sender || sender === botJid) continue;

                    const entry = {
                        ...ms,
                        message: actualMessage,
                        originalSender: sender,
                        originalPushName: getPushName(ms),
                        timestamp: Date.now(),
                    };
                    setImmediate(() => saveAntiDelete(from, entry));
                } catch (error) {
                    bot.logger.error(`[${key}] Anti-delete error:`, error);
                }
            }
        });
    }

    // ─── Auto Bio ────────────────────────────────────────────────────────────
    function setupAutoBio(sock) {
        (async () => {
            const s = await getCachedSettings();
            if (s.AUTO_BIO === "true") {
                setTimeout(() => bot.GiftedAutoBio(sock), 1000);
                const timer = setInterval(() => bot.GiftedAutoBio(sock), 60_000);
                timer.unref?.();
            }
        })();
    }

    // ─── Anti Call ───────────────────────────────────────────────────────────
    function setupAntiCall(sock) {
        sock.ev.on("call", (json) => bot.GiftedAnticall(json, sock));
    }

    // ─── Newsletter React ────────────────────────────────────────────────────
    function setupNewsletterReact(sock) {
        const emojiList = ["❤️", "💛", "👍", "💜", "😮", "🤍", "💙"];
        sock.ev.on("messages.upsert", async (mek) => {
            try {
                const msg = mek.messages[0];
                if (!msg?.message || !msg?.key?.server_id) return;

                const newsletters = await getNewsletters();
                if (!newsletters.includes(msg.key.remoteJid)) return;

                const emoji = emojiList[Math.floor(Math.random() * emojiList.length)];
                await sock.newsletterReactMessage(
                    msg.key.remoteJid,
                    msg.key.server_id.toString(),
                    emoji
                );
            } catch (err) {
                if (["ECONNRESET", "ECONNREFUSED", "ETIMEDOUT"].includes(err?.code)) {
                    invalidateNewsletterCache();
                }
            }
        });
    }

    // ─── Presence ────────────────────────────────────────────────────────────
    function setupPresence(sock) {
        sock.ev.on("messages.upsert", async ({ messages }) => {
            if (messages?.length > 0) {
                await bot.GiftedPresence(sock, messages[0].key.remoteJid);
            }
        });

        sock.ev.on("connection.update", ({ connection }) => {
            if (connection === "open") {
                bot.GiftedPresence(sock, "status@broadcast");
            }
        });
    }

    // ─── ChatBot + AntiLink + games ──────────────────────────────────────────
    function setupChatBotAndAntiLink(sock) {
        sock.ev.on("messages.upsert", async ({ messages, type }) => {
            if (type === "append") return;

            const firstMsg = messages[0];
            if (firstMsg?.message) {
                const s = await getCachedSettings();
                if ((s.CHATBOT === "true" || s.CHATBOT === "audio") && googleTTS) {
                    bot.GiftedChatBot(
                        sock,
                        s.CHATBOT,
                        s.CHATBOT_MODE || "inbox",
                        bot.createContext,
                        bot.createContext2,
                        googleTTS
                    );
                }
            }

            for (const message of messages) {
                if (!message?.message) continue;
                const from = message.key?.remoteJid || "";
                if (message.key.fromMe && !from.endsWith("@g.us")) continue;

                if (from.endsWith("@g.us")) {
                    await Promise.allSettled([
                        bot.GiftedAntiLink(sock, message, bot.getGroupMetadata),
                        bot.GiftedAntibad(sock, message, bot.getGroupMetadata),
                    ]);
                }
                await Promise.allSettled([
                    bot.GiftedAntiGroupMention(sock, message, bot.getGroupMetadata),
                    bot.handleGameMessage(sock, message),
                ]);
            }
        });
    }

    // ─── Anti Edit ───────────────────────────────────────────────────────────
    function setupAntiEdit(sock) {
        sock.ev.on("messages.update", async (updates) => {
            for (const update of updates) {
                try {
                    if (!update?.update?.message) continue;
                    if (update.key?.fromMe) continue;
                    if (update.key?.remoteJid === "status@broadcast") continue;
                    await bot.GiftedAntiEdit(sock, update, findAntiDelete);
                } catch (err) {
                    console.error(`[${key}] Anti-edit error:`, err.message);
                }
            }
        });
    }

    // ─── Status handlers ─────────────────────────────────────────────────────
    function setupStatusHandlers(sock) {
        sock.ev.on("messages.upsert", async (mek) => {
            try {
                mek = mek.messages[0];
                if (!mek?.message) return;

                mek.message =
                    getContentType(mek.message) === "ephemeralMessage"
                        ? mek.message.ephemeralMessage.message
                        : mek.message;

                if (mek.key?.remoteJid !== "status@broadcast") return;

                const s = await getCachedSettings();
                const rawParticipant =
                    mek.participant || mek.key.participantPn || mek.key.participant;
                const participantJid = await resolveRealJid(sock, rawParticipant);

                const shouldView = s.AUTO_READ_STATUS === "true";
                const readKey =
                    participantJid && participantJid !== mek.key.participant
                        ? { ...mek.key, participant: participantJid }
                        : mek.key;

                if (shouldView) await sock.readMessages([readKey]);

                if (shouldView && s.AUTO_LIKE_STATUS === "true" && participantJid) {
                    const statusEmojis = (s.STATUS_LIKE_EMOJIS || "💛,❤️,💜,🤍,💙")
                        .split(",")
                        .map((e) => e.trim())
                        .filter(Boolean);
                    const randomEmoji =
                        statusEmojis[Math.floor(Math.random() * statusEmojis.length)];
                    await sock.sendMessage(
                        "status@broadcast",
                        {
                            react: {
                                text: randomEmoji,
                                key: { ...mek.key, participant: participantJid },
                            },
                        },
                        { statusJidList: [participantJid] }
                    );
                }

                if (
                    shouldView &&
                    s.AUTO_REPLY_STATUS === "true" &&
                    !mek.key.fromMe &&
                    participantJid
                ) {
                    await sock.sendMessage(
                        participantJid,
                        {
                            text:
                                s.STATUS_REPLY_TEXT ||
                                bot.DEFAULT_SETTINGS.STATUS_REPLY_TEXT,
                        },
                        { quoted: mek }
                    );
                }
            } catch (error) {
                const code = error?.output?.statusCode || error?.code || "";
                const msg = error?.message || "";
                const transient =
                    code === 428 ||
                    msg === "Connection Closed" ||
                    ["ECONNRESET", "ETIMEDOUT", "ECONNREFUSED", "EPIPE"].some((e) =>
                        msg.includes(e)
                    ) ||
                    msg.includes("Connection Terminated") ||
                    msg.includes("Stream Errored") ||
                    ["ECONNRESET", "EPIPE"].includes(String(code));
                if (!transient) {
                    console.error(`[${key}] Status action error:`, error);
                }
            }
        });
    }

    // ─── Command handler ─────────────────────────────────────────────────────
    function setupCommandHandler(sock) {
        sock.ev.on("messages.upsert", async ({ messages, type }) => {
            if (type === "append") return;

            const ms = messages[0];
            if (!ms?.message || !ms?.key) return;

            const messageId = ms.key.id;
            if (!markProcessed(messageId)) return;

            const messageTimestamp =
                (ms.messageTimestamp?.low || ms.messageTimestamp) * 1000;
            if (messageTimestamp && messageTimestamp < startedAt - 5000) return;

            try {
                const [settings, botId] = await Promise.all([
                    getCachedSettings(),
                    Promise.resolve(bot.standardizeJid(sock.user?.id)),
                ]);

                const serialized = await bot.serializeMessage(ms, sock, settings);
                if (!serialized) return;

                const {
                    from,
                    isGroup,
                    body,
                    isCommand,
                    command,
                    args,
                    sender: rawSender,
                    messageAuthor,
                    user,
                    pushName,
                    quoted,
                    repliedMessage,
                    mentionedJid,
                    tagged,
                    quotedMsg,
                    quotedKey,
                    quotedUser,
                } = serialized;

                const [groupData, superUser] = await Promise.all([
                    bot.getGroupInfo(sock, from, botId, rawSender),
                    bot.buildSuperUsers(
                        settings,
                        bot.getSudoNumbers,
                        botId,
                        settings.OWNER_NUMBER || ""
                    ),
                ]);

                const {
                    groupInfo,
                    groupName,
                    participants,
                    groupAdmins,
                    groupSuperAdmins,
                    isBotAdmin,
                    isAdmin,
                    isSuperAdmin,
                    sender,
                } = groupData;

                // The account that paired this session can always command it,
                // otherwise a shared/global MODE=private setting would lock the
                // owner out of their own account.
                const sessionOwnerNumber = String(sock.user?.id || "").split(":")[0];
                const superUsers = [...superUser];
                if (config.SESSION_OWNER_IS_SUPERUSER && sessionOwnerNumber) {
                    const ownerJid = bot.standardizeJid(sessionOwnerNumber);
                    if (ownerJid) superUsers.push(ownerJid);
                }

                const isSuperUser = superUsers.includes(sender);

                // Auto-block
                if (settings.AUTO_BLOCK && sender && !isSuperUser && !isGroup) {
                    const countryCodes = settings.AUTO_BLOCK.split(",").map((c) =>
                        c.trim()
                    );
                    if (countryCodes.some((code) => sender.startsWith(code))) {
                        sock.updateBlockStatus(sender, "block").catch((e) =>
                            console.error(`[${key}] Block error:`, e.message)
                        );
                    }
                }

                // Auto-read
                const autoReadMode = settings.AUTO_READ_MESSAGES || "off";
                const shouldRead =
                    autoReadMode === "all" ||
                    autoReadMode === "true" ||
                    (autoReadMode === "dm" && !isGroup) ||
                    (autoReadMode === "groups" && isGroup) ||
                    (autoReadMode === "commands" && isCommand);

                if (shouldRead) await sock.readMessages([ms.key]);

                const contextData = {
                    from,
                    isGroup,
                    groupInfo,
                    groupName,
                    participants,
                    groupAdmins,
                    groupSuperAdmins,
                    isBotAdmin,
                    isAdmin,
                    isSuperAdmin,
                    sender,
                    superUser: superUsers,
                    isSuperUser,
                    messageAuthor,
                    user,
                    pushName,
                    args,
                    quoted,
                    repliedMessage,
                    mentionedJid,
                    tagged,
                    quotedMsg,
                    quotedKey,
                    quotedUser,
                    Gifted: sock,
                    botId,
                    body,
                    command,
                };

                // Body commands
                const bodyCmd = bot.findBodyCommand(body);
                if (bodyCmd?.function) {
                    if (settings.MODE?.toLowerCase() !== "private" || isSuperUser) {
                        try {
                            const helpers = bot.createHelpers(sock, ms, from);
                            const conText = buildContext(ms, settings, helpers, contextData);
                            await bodyCmd.function(from, sock, conText);
                        } catch (error) {
                            console.error(`[${key}] Body command error:`, error.message);
                        }
                    }
                }

                // Prefix commands
                if (isCommand && command) {
                    const gmd = bot.findCommand(command);
                    if (!gmd) return;
                    if (settings.MODE?.toLowerCase() === "private" && !isSuperUser) {
                        return;
                    }

                    try {
                        const helpers = bot.createHelpers(sock, ms, from);

                        if (settings.AUTO_REACT === "commands") {
                            const randomEmoji =
                                bot.emojis[Math.floor(Math.random() * bot.emojis.length)];
                            await sock.sendMessage(from, {
                                react: { key: ms.key, text: randomEmoji },
                            });
                        } else if (gmd.react) {
                            await sock.sendMessage(from, {
                                react: { key: ms.key, text: gmd.react },
                            });
                        }

                        setupGiftedHelpers(sock, from);
                        const conText = buildContext(ms, settings, helpers, contextData);
                        await gmd.function(from, sock, conText);
                    } catch (error) {
                        console.error(`[${key}] Command error [${command}]:`, error.message);
                        try {
                            await sock.sendMessage(
                                from,
                                {
                                    text: `🚨 Command failed: ${error.message}`,
                                    ...(await bot.createContext(messageAuthor, {
                                        title: "Error",
                                        body: "Command execution failed",
                                    })),
                                },
                                { quoted: ms }
                            );
                        } catch (sendErr) {
                            console.error(
                                `[${key}] Error sending error message:`,
                                sendErr.message
                            );
                        }
                    }
                }
            } catch (error) {
                console.error(`[${key}] Message handling error:`, error.message);
            }
        });
    }

    // ─── Gifted helpers (bound once per chat) ────────────────────────────────
    function setupGiftedHelpers(sock, from) {
        const cacheKey = `${sock.user?.id || "?"}:${from}`;
        if (helpersBound.has(cacheKey)) return;
        helpersBound.add(cacheKey);
        if (helpersBound.size > 500) {
            const first = helpersBound.values().next().value;
            helpersBound.delete(first);
        }

        sock.getJidFromLid = async (lid) => {
            const groupMetadata = await bot.getGroupMetadata(sock, from);
            if (!groupMetadata) return null;
            const match = groupMetadata.participants.find(
                (p) => p.lid === lid || p.id === lid
            );
            return match?.pn || match?.phoneNumber || null;
        };

        sock.getLidFromJid = async (jid) => {
            const groupMetadata = await bot.getGroupMetadata(sock, from);
            if (!groupMetadata) return null;
            const match = groupMetadata.participants.find(
                (p) =>
                    p.jid === jid ||
                    p.pn === jid ||
                    p.phoneNumber === jid ||
                    p.id === jid
            );
            return match?.lid || null;
        };

        sock.downloadAndSaveMediaMessage = async (
            message,
            filename,
            attachExtension = true
        ) => {
            try {
                const quoted = message.msg ? message.msg : message;
                const mime = (message.msg || message).mimetype || "";
                const messageType = message.mtype
                    ? message.mtype.replace(/Message/gi, "")
                    : mime.split("/")[0];

                const stream = await downloadContentFromMessage(quoted, messageType);
                const buffer = await streamToBuffer(stream);

                let fileTypeResult;
                try {
                    fileTypeResult = await fileTypeModule?.fileTypeFromBuffer(buffer);
                } catch (_) {}

                const extension =
                    fileTypeResult?.ext ||
                    mime.split("/")[1] ||
                    (messageType === "image"
                        ? "jpg"
                        : messageType === "video"
                          ? "mp4"
                          : messageType === "audio"
                            ? "mp3"
                            : "bin");

                const trueFileName = attachExtension
                    ? `${filename}.${extension}`
                    : filename;
                await require("fs-extra").writeFile(trueFileName, buffer);
                return trueFileName;
            } catch (error) {
                console.error(`[${key}] downloadAndSaveMediaMessage:`, error.message);
                throw error;
            }
        };
    }

    // ─── Context builder (same shape the plugins expect) ─────────────────────
    function buildContext(ms, settings, helpers, data) {
        return {
            m: ms,
            mek: ms,
            body: data.body || "",
            edit: helpers.edit,
            react: helpers.react,
            del: helpers.del,
            args: data.args,
            arg: data.args,
            quoted: data.quoted,
            isCmd: data.isCommand !== undefined ? data.isCommand : true,
            command: data.command || "",
            isAdmin: data.isAdmin,
            isBotAdmin: data.isBotAdmin,
            sender: data.sender,
            pushName: data.pushName,
            setSudo: bot.setSudo,
            delSudo: bot.delSudo,
            q: (data.args || []).join(" "),
            reply: helpers.reply,
            config,
            superUser: data.superUser,
            tagged: data.tagged,
            mentionedJid: data.mentionedJid,
            isGroup: data.isGroup,
            groupInfo: data.groupInfo,
            groupName: data.groupName,
            getSudoNumbers: bot.getSudoNumbers,
            authorMessage: data.messageAuthor,
            user: data.user || "",
            gmdBuffer: bot.gmdBuffer,
            gmdJson: bot.gmdJson,
            formatAudio: bot.formatAudio,
            formatVideo: bot.formatVideo,
            toAudio: bot.toAudio,
            groupMember: data.isGroup ? data.messageAuthor : "",
            from: data.from,
            groupAdmins: data.groupAdmins,
            participants: data.participants,
            repliedMessage: data.repliedMessage,
            quotedMsg: data.quotedMsg,
            quotedKey: data.quotedKey,
            quotedUser: data.quotedUser,
            isSuperUser: data.isSuperUser,
            botMode: settings.MODE,
            botPic: settings.BOT_PIC,
            botFooter: settings.FOOTER,
            botCaption: settings.CAPTION,
            botVersion: settings.VERSION,
            ownerNumber: settings.OWNER_NUMBER,
            ownerName: settings.OWNER_NAME,
            botName: settings.BOT_NAME,
            giftedRepo: settings.BOT_REPO,
            packName: settings.PACK_NAME,
            packAuthor: settings.PACK_AUTHOR,
            isSuperAdmin: data.isSuperAdmin,
            getMediaBuffer: bot.getMediaBuffer,
            getFileContentType: bot.getFileContentType,
            bufferToStream: bot.bufferToStream,
            uploadToPixhost: bot.uploadToPixhost,
            uploadToImgBB: bot.uploadToImgBB,
            setCommitHash: bot.setCommitHash,
            getCommitHash: bot.getCommitHash,
            uploadToGithubCdn: bot.uploadToGithubCdn,
            uploadToGiftedCdn: bot.uploadToGiftedCdn,
            uploadToCatbox: bot.uploadToCatbox,
            newsletterUrl: settings.NEWSLETTER_URL,
            newsletterJid: settings.NEWSLETTER_JID,
            GiftedTechApi: bot.GiftedTechApi,
            GiftedApiKey: bot.GiftedApiKey,
            botPrefix: settings.PREFIX,
            timeZone: settings.TIME_ZONE,
        };
    }

    // ─── Helpers used above ──────────────────────────────────────────────────
    async function streamToBuffer(stream) {
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        return Buffer.concat(chunks);
    }

    // ─── Connection lifecycle (per account, never exits the process) ─────────
    function bindConnectionLifecycle(sock) {
        sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect, qr } = update;

            if (qr) {
                setStatus(STATUS.PAIRING, "waiting for pairing code entry");
                await deliverPairingCode(sock);
            }

            if (connection === "connecting") {
                if (status !== STATUS.PAIRING) setStatus(STATUS.CONNECTING);
            }

            if (connection === "open") {
                reconnectAttempts = 0;
                lastError = null;
                setStatus(STATUS.ACTIVE, "connected");
                await handleOpen(sock);
            }

            if (connection === "close") {
                await handleClose(sock, disconnectReasonOf(lastDisconnect), lastDisconnect);
            }
        });
    }

    function scheduleReconnect() {
        if (stopped) return;
        if (reconnectAttempts >= config.SESSION_MAX_RECONNECT_ATTEMPTS) {
            setStatus(
                STATUS.OFFLINE,
                `giving up after ${reconnectAttempts} reconnect attempt(s)`
            );
            return;
        }
        reconnectAttempts += 1;
        const delay = Math.min(
            RECONNECT_BASE_DELAY * Math.pow(2, reconnectAttempts - 1),
            RECONNECT_MAX_DELAY
        );
        console.log(
            `[${key}] reconnect ${reconnectAttempts}/${config.SESSION_MAX_RECONNECT_ATTEMPTS} in ${delay}ms`
        );
        setStatus(STATUS.OFFLINE, `reconnecting in ${Math.round(delay / 1000)}s`);
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(() => {
            start().catch((error) => {
                lastError = error.message;
                console.error(`[${key}] Reconnect failed:`, error.message);
                scheduleReconnect();
            });
        }, delay);
        reconnectTimer.unref?.();
    }

    async function handleClose(sock, reason, lastDisconnect) {
        lastError = lastDisconnect?.error?.message || statusDetail || "";

        if (FATAL_REASONS.has(reason)) {
            console.log(`[${key}] logged out (${reason}) - stopping account`);
            setStatus(STATUS.LOGGED_OUT, `device unlinked (${reason})`);
            await stop({ keepData: false });
            try {
                onLogout?.({ key, reason });
            } catch (_) {}
            return;
        }

        if (reason === DisconnectReason.connectionReplaced) {
            // Another device took over this session; reconnecting would fight
            // it, so park the account instead.
            console.log(`[${key}] connection replaced - parking account`);
            clearTimeout(reconnectTimer);
            setStatus(STATUS.OFFLINE, "connection replaced by another session");
            return;
        }

        // connectionClosed / connectionLost / restartRequired / timedOut /
        // unavailableService / anything unknown: try to come back.
        console.log(`[${key}] connection closed (${reason ?? "unknown"}) - reconnecting`);
        scheduleReconnect();
    }

    async function handleOpen(sock) {
        try {
            const s = await getCachedSettings(true);

            const tasks = [bot.initializeLidStore(sock)];
            if (config.SESSION_AUTO_FOLLOW_NEWSLETTER && s.NEWSLETTER_JID) {
                tasks.push(bot.safeNewsletterFollow(sock, s.NEWSLETTER_JID));
            }
            if (config.SESSION_AUTO_JOIN_GROUP && s.GC_JID) {
                tasks.push(bot.safeGroupAcceptInvite(sock, s.GC_JID));
            }
            await Promise.allSettled(tasks);

            clearTimeout(pairingTimeout);
            pairingRequested = false;
            pendingPairNumber = null;

            if (config.SESSION_STARTUP_MESSAGE && s.STARTING_MESSAGE === "true" && sendButtons) {
                setTimeout(async () => {
                    try {
                        const d = bot.DEFAULT_SETTINGS;
                        const md = s.MODE === "public" ? "public" : "private";
                        const totalCommands = getCommandCount();
                        const connectionMsg = `
┌─⭓⃟
├ⵟ❏ *${(s.BOT_NAME || d.BOT_NAME).toUpperCase()}*
├❏
├❏ 🔹 *ᴘʀᴇꜰɪx*  : *[ ${s.PREFIX || d.PREFIX} ]*
├❏ 🔹 *ᴘʟᴜɢɪɴs* : *${totalCommands}*
├❏ 🔹 *ᴍᴏᴅᴇ*    : *${md.toUpperCase()}*
├❏ 🔹 *ᴏᴡɴᴇʀ*   : *${s.OWNER_NUMBER || d.OWNER_NUMBER}*
├❏
├❏ _ʙᴏᴛ ᴍᴀʏ ᴛᴀᴋᴇ sᴏᴍᴇ ꜰᴇᴡ_
├❏ _sᴇᴄᴏɴᴅs/ᴍɪɴᴜᴛᴇs ᴛᴏ sʏɴᴄ_
├❏ _ʙᴇ ꜰᴏʀᴇ ʙᴇɪɴɢ ʀᴇᴀᴅʏ ᴛᴏ ᴜsᴇ._
├❏
├❏ 🥷 _${s.CAPTION || d.CAPTION}_
└─❏
`;
                        await sendButtons(sock, sock.user.id, {
                            text: connectionMsg,
                        });
                    } catch (err) {
                        console.error(`[${key}] Post-connection setup error:`, err.message);
                    }
                }, 5000);
            }
        } catch (err) {
            console.error(`[${key}] Post-connection setup error:`, err.message);
        }
    }

    // ─── Pairing code delivery ───────────────────────────────────────────────
    async function deliverPairingCode(sock) {
        if (!pairingRequested || !pendingPairNumber || !pairingWaiter) return;
        pairingRequested = false;
        try {
            const code = await sock.requestPairingCode(pendingPairNumber);
            clearTimeout(pairingTimeout);
            pairingWaiter.resolve(code);
        } catch (error) {
            clearTimeout(pairingTimeout);
            pairingWaiter.reject(error);
        } finally {
            pairingWaiter = null;
        }
    }

    /**
     * Starts the account and resolves with an 8-character pairing code.
     * Used by the Telegram /pair flow for accounts that are not linked yet.
     */
    async function requestPairingCode(number) {
        if (pairingWaiter) {
            throw new Error("A pairing request is already in progress");
        }
        if (status === STATUS.ACTIVE) {
            throw new Error("This account is already linked");
        }

        pendingPairNumber = String(number).replace(/\D/g, "");
        pairingRequested = true;

        const codePromise = new Promise((resolve, reject) => {
            pairingWaiter = { resolve, reject };
        });

        await start();

        pairingTimeout = setTimeout(() => {
            if (pairingWaiter) {
                pairingWaiter.reject(
                    new Error(
                        `Timed out after ${config.PAIR_TIMEOUT_SECONDS}s waiting for WhatsApp to issue a pairing code`
                    )
                );
                pairingWaiter = null;
            }
            pairingRequested = false;
        }, config.PAIR_TIMEOUT_SECONDS * 1000);
        pairingTimeout.unref?.();

        return codePromise;
    }

    // ─── Start / stop ────────────────────────────────────────────────────────
    async function start() {
        if (stopped) stopped = false;
        if (socket) return socket;

        setStatus(status === STATUS.IDLE ? STATUS.CONNECTING : status);

        let version;
        try {
            ({ version } = await fetchLatestWaWebVersion());
        } catch (_) {
            // Offline or the version endpoint is blocked: Baileys falls back to
            // its bundled default, so this is not fatal.
        }

        const { state, saveCreds } = await bot.useSQLiteAuthState(
            path.join(sessionDir, "session.db")
        );

        if (store) store.destroy();
        store = new SQLiteStore();

        const socketConfig = bot.createSocketConfig(version, state, bot.logger);
        socketConfig.getMessage = async (msgKey) => {
            if (store) {
                const msg = await store.loadMessage(msgKey.remoteJid, msgKey.id);
                return msg?.message || undefined;
            }
            return { conversation: "Error occurred" };
        };

        const sock = giftedConnect(socketConfig);
        socket = sock;
        store.bind(sock.ev);

        sock.ev.process(async (events) => {
            if (events["creds.update"]) await saveCreds();
        });

        setupAutoReact(sock);
        setupAntiDelete(sock);
        setupAutoBio(sock);
        setupAntiCall(sock);
        setupNewsletterReact(sock);
        setupPresence(sock);
        setupChatBotAndAntiLink(sock);
        setupAntiEdit(sock);
        setupStatusHandlers(sock);
        bot.setupGroupEventsListeners(sock);
        setupCommandHandler(sock);
        bindConnectionLifecycle(sock);

        startedAt = Date.now();
        return sock;
    }

    /**
     * Stops the account. `keepData: false` also wipes the local auth state,
     * which is what /unpair and a remote logout should do.
     */
    async function stop({ keepData = true } = {}) {
        stopped = true;
        clearTimeout(reconnectTimer);
        clearTimeout(pairingTimeout);
        reconnectTimer = null;

        if (pairingWaiter) {
            pairingWaiter.reject(new Error("Session stopped before pairing completed"));
            pairingWaiter = null;
        }
        pairingRequested = false;

        try {
            store?.destroy();
        } catch (_) {}
        store = null;

        const current = socket;
        socket = null;
        if (current) {
            try {
                if (keepData) {
                    current.end?.();
                } else {
                    // logout() unlinks the device; end() just closes the socket.
                    await current.logout?.().catch(() => {});
                    current.end?.();
                }
            } catch (_) {}
        }

        if (!keepData) {
            try {
                const fs = require("fs-extra");
                await fs.remove(sessionDir);
            } catch (error) {
                console.error(`[${key}] Failed to remove session data:`, error.message);
            }
        }

        if (status !== STATUS.LOGGED_OUT) setStatus(STATUS.OFFLINE, "stopped");
    }

    function getInfo() {
        const sock = socket;
        return {
            key,
            sessionDir,
            status,
            statusDetail,
            lastError,
            number: sock?.user?.id ? String(sock.user.id).split(":")[0] : null,
            pushName: sock?.user?.name || null,
            startedAt,
            uptimeMs: startedAt ? Date.now() - startedAt : 0,
            reconnectAttempts,
            processed: processedMessages.size,
        };
    }

    return {
        key,
        start,
        stop,
        requestPairingCode,
        whenSettled,
        getSocket: () => socket,
        getStatus: () => status,
        getInfo,
    };
}

module.exports = { createWhatsAppSession, STATUS };
