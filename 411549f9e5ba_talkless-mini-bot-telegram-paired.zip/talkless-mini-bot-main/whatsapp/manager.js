/**
 * Multi-account WhatsApp manager.
 *
 * Owns the lifecycle of every paired account: pairing, restoring after a
 * restart, stopping, unpairing and the resource limits that keep 10-100
 * accounts inside one process.
 *
 * The Telegram layer only ever talks to this module.
 */
const fs = require("fs-extra");
const path = require("path");

const config = require("../config");
const registry = require("./registry");
const { STATUS } = require("./registry");
const { createWhatsAppSession, STATUS: SESSION_STATUS } = require("./sessionFactory");
const {
    loadCommandPlugins,
    getPluginReport,
    getCommandCount,
    getBodyCommandCount,
} = require("./shared");
const { syncDatabase } = require("../talkless_mini_bot/database/database");
const {
    initializeSettings,
    getAllSettings,
} = require("../talkless_mini_bot/database/settings");
const {
    initializeGroupSettings,
} = require("../talkless_mini_bot/database/groupSettings");

/** Live account runtimes, keyed by session key. */
const live = new Map();

/** RSS right after startup, used to measure real per-account growth. */
let baselineRssBytes = process.memoryUsage().rss;

/**
 * Registry statuses that hold no working WhatsApp link. Numbers behind these
 * rows can be claimed again and do not count against a user's quota.
 */
const UNUSABLE_STATUSES = new Set([STATUS.LOGGED_OUT, STATUS.FAILED]);
/** telegramId -> array of recent /pair attempt timestamps (pruned to the window). */
const pairAttempts = new Map();

let notify = async () => {};
let started = false;
let sweepTimer = null;

class PairError extends Error {
    constructor(code, message) {
        super(message);
        this.name = "PairError";
        this.code = code;
    }
}

// ─── Paths ───────────────────────────────────────────────────────────────────

function sessionsRoot() {
    return path.resolve(process.cwd(), config.SESSIONS_DIR);
}

function resolveSessionDir(relative) {
    return path.join(sessionsRoot(), relative);
}

function sessionSegment(telegramId, waNumber) {
    return path.join(String(telegramId), String(waNumber));
}

// ─── Validation helpers ──────────────────────────────────────────────────────

function normalizeNumber(raw) {
    if (raw === undefined || raw === null) return "";
    return String(raw).replace(/[^\d]/g, "");
}

/**
 * @returns {{ ok: true, number: string } | { ok: false, reason: string }}
 */
function validateNumber(raw) {
    const number = normalizeNumber(raw);
    if (!number) {
        return { ok: false, reason: "No number given." };
    }
    if (number.length < 7 || number.length > 15) {
        return {
            ok: false,
            reason: "A number with the country code is 7-15 digits (example: 255712345678).",
        };
    }
    if (number.startsWith("0") && number.length <= 11) {
        return {
            ok: false,
            reason:
                "That looks like a local number. Include the country code and drop the leading 0 " +
                "(example: 255712345678, not 0712345678).",
        };
    }
    return { ok: true, number };
}

function checkPairCooldown(telegramId) {
    const id = String(telegramId);
    const now = Date.now();
    const windowMs = config.PAIR_WINDOW_SECONDS * 1000;
    const cooldownMs = config.PAIR_COOLDOWN_SECONDS * 1000;

    // Keep only the attempts that fall inside the rolling window.
    const recent = (pairAttempts.get(id) || []).filter((at) => now - at < windowMs);

    const last = recent[recent.length - 1];
    if (last !== undefined && now - last < cooldownMs) {
        const wait = Math.ceil((cooldownMs - (now - last)) / 1000);
        throw new PairError(
            "COOLDOWN",
            `Please wait ${wait}s before requesting another pairing code.`
        );
    }

    // Rolling window so a user cannot cycle through numbers forever.
    if (recent.length >= config.PAIR_MAX_PER_WINDOW) {
        const wait = Math.ceil((windowMs - (now - recent[0])) / 1000);
        throw new PairError(
            "RATE_LIMITED",
            `Too many pairing attempts. Try again in ${wait}s.`
        );
    }

    recent.push(now);
    pairAttempts.set(id, recent);
}

/**
 * Slots reserved by a /pair call that has passed the capacity check but has not
 * registered its runtime yet. Without this, two users pairing at the same
 * moment could both pass the check and overshoot the cap.
 */
let reservedSlots = 0;

function countPendingPairs() {
    let pending = reservedSlots;
    for (const session of live.values()) {
        if (
            session.getStatus() === SESSION_STATUS.PAIRING ||
            session.getStatus() === SESSION_STATUS.CONNECTING
        ) {
            pending += 1;
        }
    }
    return pending;
}

/**
 * Gives back a rate-limit token when a request was rejected for a reason the
 * user cannot influence, so a server hiccup does not cost them their hourly
 * allowance.
 */
function refundPairAttempt(telegramId) {
    const id = String(telegramId);
    const recent = pairAttempts.get(id);
    if (!recent || !recent.length) return;
    recent.pop();
    if (!recent.length) pairAttempts.delete(id);
}

function assertCapacity() {
    if (live.size + reservedSlots >= config.MAX_SESSIONS) {
        throw new PairError(
            "CAPACITY",
            `The bot is at capacity (${config.MAX_SESSIONS} linked accounts). Try again later.`
        );
    }

    if (countPendingPairs() >= config.PENDING_PAIR_LIMIT) {
        throw new PairError(
            "BUSY",
            `Another pairing is in progress right now. Try again in a minute.`
        );
    }

    const rssMb = process.memoryUsage().rss / (1024 * 1024);
    if (rssMb > config.MAX_RSS_MB) {
        throw new PairError(
            "MEMORY",
            `The bot is under memory pressure (${Math.round(rssMb)}MB) and is not accepting new accounts right now.`
        );
    }
}

// ─── Notifications ───────────────────────────────────────────────────────────

async function safeNotify(telegramId, text, options) {
    try {
        await notify(telegramId, text, options);
    } catch (error) {
        console.error(`Failed to notify ${telegramId}:`, error.message);
    }
}

// ─── Session lifecycle ───────────────────────────────────────────────────────

async function startSessionForRow(row, { delayMs = 0 } = {}) {
    if (live.has(row.session_key)) return live.get(row.session_key);

    const dir = resolveSessionDir(row.session_dir);
    await fs.ensureDir(dir);

    const session = createWhatsAppSession({
        key: row.session_key,
        sessionDir: dir,
        onStatus: async ({ status, detail }) => {
            await onSessionStatus(row.session_key, status, detail);
        },
        onLogout: async () => {
            await registry.updateSession(row.session_key, {
                status: STATUS.LOGGED_OUT,
                pairing_code: null,
                last_error: "Device unlinked from WhatsApp",
            });
            await safeNotify(
                row.telegram_id,
                `⚠️ The WhatsApp account *+${row.wa_number}* was unlinked from the phone ` +
                    `(Linked devices → Log out).\n\nRun /pair again with a new code to relink it.`,
                { parse_mode: "Markdown" }
            );
        },
    });

    live.set(row.session_key, session);

    if (delayMs > 0) {
        await new Promise((resolve) => {
            const timer = setTimeout(resolve, delayMs);
            timer.unref?.();
        });
    }

    try {
        await session.start();
    } catch (error) {
        live.delete(row.session_key);
        await session.whenSettled?.();
        await registry.updateSession(row.session_key, {
            status: STATUS.FAILED,
            last_error: error.message,
        });
        throw error;
    }

    return session;
}

/**
 * Maps runtime status to registry status and keeps the owner informed.
 */
async function onSessionStatus(key, status, detail) {
    const row = await registry.getSession(key);
    if (!row) return;

    let registryStatus = row.status;
    switch (status) {
        case SESSION_STATUS.ACTIVE:
            registryStatus = STATUS.ACTIVE;
            break;
        case SESSION_STATUS.PAIRING:
            registryStatus = STATUS.PAIRING;
            break;
        case SESSION_STATUS.CONNECTING:
            registryStatus = STATUS.CONNECTING;
            break;
        case SESSION_STATUS.OFFLINE:
            registryStatus = STATUS.OFFLINE;
            break;
        case SESSION_STATUS.LOGGED_OUT:
            registryStatus = STATUS.LOGGED_OUT;
            break;
        case SESSION_STATUS.FAILED:
            registryStatus = STATUS.FAILED;
            break;
        default:
            return;
    }

    const fields = { status: registryStatus };
    if (status === SESSION_STATUS.ACTIVE) {
        fields.pairing_code = null;
        fields.last_error = null;
        if (!row.paired_at) fields.paired_at = new Date();
        fields.session_dir = row.session_dir;
    } else if (detail && status !== SESSION_STATUS.PAIRING) {
        fields.last_error = detail;
    }

    const wasActive = row.status === STATUS.ACTIVE;
    await registry.updateSession(key, fields);

    if (status === SESSION_STATUS.ACTIVE && !wasActive && !row.paired_at) {
        await safeNotify(
            row.telegram_id,
            `✅ *+${row.wa_number}* is now linked and online.\n\n` +
                `Your WhatsApp commands are live on that account. ` +
                `Send \`${config.PAIR_HELP_PREFIX}menu\` from the linked phone to see them.`,
            { parse_mode: "Markdown" }
        );
    }
}

async function stopSession(key, { keepData = true, removeRow = false } = {}) {
    const session = live.get(key);
    if (session) {
        try {
            await session.stop({ keepData });
            // Let the stop() status write land before the caller writes its own,
            // otherwise the two race and the stale one can win.
            await session.whenSettled?.();
        } catch (error) {
            console.error(`Failed to stop ${key}:`, error.message);
        }
        live.delete(key);
    } else if (!keepData) {
        const row = await registry.getSession(key);
        if (row) await fs.remove(resolveSessionDir(row.session_dir)).catch(() => {});
    }

    if (removeRow) await registry.removeSession(key);
}

// ─── Public API ──────────────────────────────────────────────────────────────

async function init({ notify: notifyFn } = {}) {
    if (started) return;

    if (typeof notifyFn === "function") notify = notifyFn;

    await syncDatabase();
    await initializeSettings();
    await initializeGroupSettings();
    await registry.initRegistry();

    const pluginsPath = path.join(__dirname, "..", "commands");
    const report = loadCommandPlugins(pluginsPath);

    await fs.ensureDir(sessionsRoot());

    // Re-baseline after plugin loading so the reported per-account figure is the
    // marginal cost of a connected account, not one-off startup overhead.
    baselineRssBytes = process.memoryUsage().rss;

    await restoreSessions();

    sweepTimer = setInterval(() => {
        sweepStalePairs().catch((error) =>
            console.error("Pair sweep failed:", error.message)
        );
    }, 60_000);
    sweepTimer.unref?.();

    started = true;
    console.log(
        `🟢 WhatsApp manager ready: ${live.size} account(s) live, ` +
            `${report.total} command(s), ${report.failed.length} plugin(s) failed`
    );

    return {
        plugins: report,
        commands: report.total,
        bodyCommands: getBodyCommandCount(),
        accounts: live.size,
    };
}

async function restoreSessions() {
    const rows = await registry.listSessions();
    const restorable = [];
    let interrupted = 0;

    for (const row of rows) {
        if (row.status === STATUS.PENDING || row.status === STATUS.PAIRING) {
            // A half-finished pairing cannot be resumed: the handshake state
            // lived in memory. Fail it cleanly so the slot is freed.
            await registry.updateSession(row.session_key, {
                status: STATUS.FAILED,
                pairing_code: null,
                last_error: "Pairing interrupted by a restart",
            });
            interrupted += 1;
            continue;
        }

        if (row.status === STATUS.LOGGED_OUT) continue;

        const dir = resolveSessionDir(row.session_dir);
        if (!fs.existsSync(path.join(dir, "session.db"))) {
            await registry.updateSession(row.session_key, {
                status: STATUS.LOGGED_OUT,
                last_error: "Local session data is missing",
            });
            continue;
        }

        restorable.push(row);
        if (restorable.length >= config.MAX_SESSIONS) break;
    }

    if (interrupted) {
        console.log(`ℹ️  ${interrupted} interrupted pairing(s) marked as failed`);
    }

    console.log(`🔄 Restoring ${restorable.length} linked account(s)...`);

    for (const row of restorable) {
        try {
            await startSessionForRow(row, { delayMs: config.SESSION_RESTORE_DELAY_MS });
        } catch (error) {
            console.error(`Failed to restore +${row.wa_number}:`, error.message);
        }
    }
}

async function sweepStalePairs() {
    const rows = await registry.listSessions();
    const now = Date.now();
    for (const row of rows) {
        if (row.status !== STATUS.PENDING && row.status !== STATUS.PAIRING) continue;
        const age = now - new Date(row.updatedAt).getTime();
        if (age < config.PAIR_STALE_SECONDS * 1000) continue;
        await stopSession(row.session_key, { keepData: false });
        await registry.updateSession(row.session_key, {
            status: STATUS.FAILED,
            pairing_code: null,
            last_error: "Pairing code expired before it was entered",
        });
        await safeNotify(
            row.telegram_id,
            `⌛ The pairing code for *+${row.wa_number}* expired.\n\n` +
                `Run /pair again to get a fresh code.`,
            { parse_mode: "Markdown" }
        );
    }
}

/**
 * Pairing flow entry point used by the Telegram /pair command.
 *
 * @returns {Promise<{ number: string, code: string, sessionKey: string }>}
 * @throws {PairError} with a user-facing message
 */
async function pair({ telegramId, telegramUsername, telegramName, number: rawNumber }) {
    if (!started) throw new PairError("NOT_READY", "The bot is still starting up.");

    const check = validateNumber(rawNumber);
    if (!check.ok) throw new PairError("INVALID_NUMBER", check.reason);
    const number = check.number;

    // Serialize the whole flow per attempt: capacity numbers are read before
    // anything is created, and a rejected attempt must not leak a socket.
    checkPairCooldown(telegramId);

    // Re-pairing a number the user already owns is always allowed; adding a
    // brand new one is capped so one user cannot fill the whole server.
    // Rows that hold no working link (unlinked by the user, or a pairing that
    // never completed) must not consume the quota, otherwise a couple of failed
    // attempts would lock a user out until they run /unpair.
    const existingOwn = await registry.listSessionsByTelegram(telegramId);
    const usableOwn = existingOwn.filter((row) => !UNUSABLE_STATUSES.has(row.status));
    const alreadyOwned = usableOwn.some((row) => row.wa_number === number);
    if (!alreadyOwned && usableOwn.length >= config.MAX_SESSIONS_PER_USER) {
        throw new PairError(
            "PER_USER_LIMIT",
            `You already have ${config.MAX_SESSIONS_PER_USER} linked account(s). ` +
                `Use /unpair to remove one first.`
        );
    }

    const numberOwner = await registry.getSessionByNumber(number);
    let releasableRow = null;
    if (numberOwner && String(numberOwner.telegram_id) !== String(telegramId)) {
        if (UNUSABLE_STATUSES.has(numberOwner.status)) {
            // The previous owner unlinked that account (or their pairing never
            // completed), so the number is free. Leaving the stale row in place
            // would block it for everybody forever.
            releasableRow = numberOwner;
        } else {
            throw new PairError(
                "NUMBER_TAKEN",
                `That number is already linked by another user.`
            );
        }
    }

    // Synchronous critical section: assertCapacity() reads the counters and
    // reservedSlots is incremented with no await in between, so two concurrent
    // /pair calls cannot both pass the cap.
    reservedSlots += 1;
    try {
        assertCapacity();
    } catch (error) {
        reservedSlots -= 1;
        refundPairAttempt(telegramId);
        throw error;
    }

    try {
        if (releasableRow) {
            // Release through stopSession, not registry.removeSession: a parked
            // runtime for that key may still sit in `live` (a remote logout sets
            // the row to logged_out without dropping the runtime) and deleting
            // only the row would leave it eating a capacity slot forever, with
            // no way to reach it from /unpair. This also wipes the dead
            // credential directory on disk.
            await stopSession(releasableRow.session_key, {
                keepData: false,
                removeRow: true,
            });
        }

        const relative = sessionSegment(telegramId, number);
        const dir = resolveSessionDir(relative);

        // Re-pairing always starts from a clean slate: stale credentials would
        // make WhatsApp refuse the new pairing request.
        const existingSession = live.get(registry.buildKey(telegramId, number));
        if (existingSession) {
            await stopSession(registry.buildKey(telegramId, number), { keepData: false });
        } else {
            await fs.remove(dir).catch(() => {});
        }
        await fs.ensureDir(dir);

        let row;
        try {
            row = await registry.createSession({
                telegramId,
                telegramUsername,
                telegramName,
                waNumber: number,
                sessionDir: relative,
                status: STATUS.PENDING,
                pairingCode: null,
            });
        } catch (error) {
            if (error.name === "SequelizeUniqueConstraintError") {
                // Someone claimed the number between the check and the insert.
                throw new PairError(
                    "NUMBER_TAKEN",
                    `That number was linked by another user just now. Please try a different number.`
                );
            }
            throw error;
        }

        const session = await startSessionForRow(row);

        let code;
        try {
            code = await session.requestPairingCode(number);
        } catch (error) {
            console.error(`Pairing failed for +${number}:`, error.message);
            await stopSession(row.session_key, { keepData: false });
            await registry.updateSession(row.session_key, {
                status: STATUS.FAILED,
                last_error: error.message,
            });
            refundPairAttempt(telegramId);
            throw new PairError(
                "PAIR_FAILED",
                `Could not get a pairing code for +${number}.\n\n` +
                    `Make sure the number is a real WhatsApp account with the country code ` +
                    `included, then try again.`
            );
        }

        await registry.updateSession(row.session_key, {
            status: STATUS.PAIRING,
            pairing_code: code,
        });

        return { number, code, sessionKey: row.session_key };
    } finally {
        reservedSlots -= 1;
    }
}

async function unpair({ telegramId, target, isOwner = false }) {
    const rows = await registry.listSessions();
    const wanted = normalizeNumber(target);

    const mine = rows.filter((row) => {
        if (!isOwner && String(row.telegram_id) !== String(telegramId)) return false;
        if (!target || String(target).toLowerCase() === "all") return true;
        return row.wa_number === wanted;
    });

    if (!mine.length) {
        return { removed: [], message: "No matching linked account found." };
    }

    const removed = [];
    for (const row of mine) {
        await stopSession(row.session_key, { keepData: false, removeRow: true });
        removed.push(row.wa_number);
    }

    return {
        removed,
        message: removed.map((n) => `+${n}`).join(", "),
    };
}

function getSessionsFor(telegramId) {
    const result = [];
    for (const [key, session] of live.entries()) {
        if (!key.startsWith(`${telegramId}:`)) continue;
        result.push({ key, ...session.getInfo() });
    }
    return result;
}

/**
 * A row that claims to be connected while no runtime is driving it is not
 * actually online, and reporting it as such would mislead the user.
 */
function effectiveStatus(row, session) {
    const info = session?.getInfo();
    if (info) {
        return { status: info.status, detail: info.statusDetail || row.last_error || "" };
    }
    const claimsLive = [STATUS.ACTIVE, STATUS.CONNECTING, STATUS.PAIRING].includes(
        row.status
    );
    return {
        status: claimsLive ? STATUS.OFFLINE : row.status,
        detail: claimsLive
            ? "not running in this process"
            : row.last_error || "",
    };
}

async function getStatusFor(telegramId) {
    const rows = await registry.listSessionsByTelegram(telegramId);
    return rows.map((row) => {
        const session = live.get(row.session_key);
        const { status, detail } = effectiveStatus(row, session);
        const info = session?.getInfo();
        return {
            number: row.wa_number,
            status,
            detail,
            uptimeMs: info?.uptimeMs || 0,
            key: row.session_key,
            createdAt: row.createdAt,
            pairedAt: row.paired_at,
        };
    });
}

async function getOwnerSnapshot() {
    const rows = await registry.listSessions();
    return rows.map((row) => {
        const session = live.get(row.session_key);
        const { status, detail } = effectiveStatus(row, session);
        const info = session?.getInfo();
        return {
            number: row.wa_number,
            telegramId: row.telegram_id,
            telegramName: row.telegram_name || row.telegram_username || "",
            status,
            detail,
            uptimeMs: info?.uptimeMs || 0,
            key: row.session_key,
        };
    });
}

async function killSession({ key, number, wipe = false }) {
    const rows = await registry.listSessions();
    const target = rows.find(
        (row) =>
            row.session_key === key ||
            row.wa_number === normalizeNumber(number) ||
            String(row.telegram_id) === String(number)
    );
    if (!target) return null;

    await stopSession(target.session_key, { keepData: !wipe, removeRow: wipe });

    if (!wipe) {
        await registry.updateSession(target.session_key, {
            status: STATUS.OFFLINE,
            last_error: "Stopped by owner",
        });
    }

    return { number: target.wa_number, telegramId: target.telegram_id, wiped: wipe };
}

async function getStats() {
    const counts = await registry.countByStatus();
    const mem = process.memoryUsage();
    const liveCount = live.size;

    // Measured, not assumed: how much this process grew per connected account
    // since the pre-restore baseline. Reported as null rather than 0 when there
    // is nothing to measure or when growth is flat/negative (GC can pull RSS
    // back below the baseline), because "0 MB per account" reads like "free".
    // It is an average taken since startup, not a strict per-account attribution.
    const growthMb = mem.rss - baselineRssBytes;
    const avgRssMbPerAccount =
        liveCount > 0 && growthMb > 0 ? Math.round(growthMb / liveCount / (1024 * 1024)) : null;

    return {
        accounts: {
            registered: await registry.countSessions(),
            live: liveCount,
            pending: countPendingPairs(),
            byStatus: counts,
            avgRssMbPerAccount,
        },
        limits: {
            maxSessions: config.MAX_SESSIONS,
            maxSessionsPerUser: config.MAX_SESSIONS_PER_USER,
            pendingPairLimit: config.PENDING_PAIR_LIMIT,
            maxRssMb: config.MAX_RSS_MB,
        },
        commands: {
            total: getCommandCount(),
            body: getBodyCommandCount(),
            plugins: getPluginReport(),
        },
        process: {
            uptimeSeconds: Math.floor(process.uptime()),
            rssMb: Math.round(mem.rss / (1024 * 1024)),
            heapUsedMb: Math.round(mem.heapUsed / (1024 * 1024)),
        },
    };
}

async function shutdown() {
    clearInterval(sweepTimer);
    const keys = [...live.keys()];
    await Promise.allSettled(keys.map((key) => stopSession(key, { keepData: true })));
    started = false;
}

module.exports = {
    PairError,
    init,
    pair,
    unpair,
    killSession,
    getStatusFor,
    getSessionsFor,
    getOwnerSnapshot,
    getStats,
    shutdown,
    // exported for tests and operational resets
    _internal: {
        validateNumber,
        normalizeNumber,
        checkPairCooldown,
        resetRateLimits: () => pairAttempts.clear(),
        countPendingPairs,
        // Live runtimes, reserved slots and the RSS baseline, exposed for
        // inspection/tests.
        live,
        getReservedSlots: () => reservedSlots,
        setRssBaseline: (bytes) => {
            baselineRssBytes = bytes;
        },
        getRssBaseline: () => baselineRssBytes,
        resolveSessionDir,
        sessionSegment,
        sessionsRoot,
    },
};
