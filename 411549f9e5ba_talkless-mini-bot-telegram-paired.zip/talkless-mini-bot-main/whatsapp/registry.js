/**
 * Persistent registry of paired WhatsApp accounts.
 *
 * One row per linked account. The row is what lets the bot survive a restart:
 * on boot the manager walks the registry and brings every account with local
 * auth state back online.
 *
 * Uses the same Sequelize instance as the rest of the bot, so it works on both
 * SQLite (default) and Postgres (DATABASE_URL).
 */
const { DATABASE } = require("../talkless_mini_bot/database/database");
const { DataTypes } = require("sequelize");

const STATUS = {
    PENDING: "pending",
    ACTIVE: "active",
    CONNECTING: "connecting",
    PAIRING: "pairing",
    OFFLINE: "offline",
    LOGGED_OUT: "logged_out",
    FAILED: "failed",
};

const PairedSession = DATABASE.define(
    "PairedSession",
    {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        session_key: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
        },
        telegram_id: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        telegram_username: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        telegram_name: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        wa_number: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
        },
        session_dir: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        status: {
            type: DataTypes.STRING,
            allowNull: false,
            defaultValue: STATUS.PENDING,
        },
        pairing_code: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        last_error: {
            type: DataTypes.TEXT,
            allowNull: true,
        },
        paired_at: {
            type: DataTypes.DATE,
            allowNull: true,
        },
        last_seen: {
            type: DataTypes.DATE,
            allowNull: true,
        },
    },
    {
        tableName: "paired_sessions",
        timestamps: true,
        indexes: [
            { fields: ["telegram_id"] },
            { fields: ["status"] },
        ],
    }
);

let initialized = false;

async function initRegistry() {
    if (initialized) return;
    await PairedSession.sync();
    initialized = true;
}

function buildKey(telegramId, waNumber) {
    return `${telegramId}:${waNumber}`;
}

async function listSessions() {
    await initRegistry();
    return PairedSession.findAll({ order: [["createdAt", "ASC"]] });
}

async function listSessionsByTelegram(telegramId) {
    await initRegistry();
    return PairedSession.findAll({
        where: { telegram_id: String(telegramId) },
        order: [["createdAt", "ASC"]],
    });
}

async function getSession(key) {
    await initRegistry();
    return PairedSession.findOne({ where: { session_key: key } });
}

async function getSessionByNumber(waNumber) {
    await initRegistry();
    return PairedSession.findOne({
        where: { wa_number: String(waNumber).replace(/\D/g, "") },
    });
}

async function countSessions(where) {
    await initRegistry();
    return PairedSession.count(where ? { where } : undefined);
}

async function createSession({
    telegramId,
    telegramUsername,
    telegramName,
    waNumber,
    sessionDir,
    status = STATUS.PENDING,
    pairingCode = null,
}) {
    await initRegistry();
    const key = buildKey(telegramId, waNumber);
    const [row, created] = await PairedSession.findOrCreate({
        where: { session_key: key },
        defaults: {
            session_key: key,
            telegram_id: String(telegramId),
            telegram_username: telegramUsername || null,
            telegram_name: telegramName || null,
            wa_number: String(waNumber).replace(/\D/g, ""),
            session_dir: sessionDir,
            status,
            pairing_code: pairingCode,
            last_seen: new Date(),
        },
    });

    if (!created) {
        await row.update({
            status,
            pairing_code: pairingCode,
            session_dir: sessionDir,
            last_error: null,
            last_seen: new Date(),
        });
    }

    return row;
}

async function updateSession(key, fields) {
    await initRegistry();
    const row = await getSession(key);
    if (!row) return null;
    await row.update({ ...fields, last_seen: new Date() });
    return row;
}

async function updateSessionById(id, fields) {
    await initRegistry();
    const row = await PairedSession.findByPk(id);
    if (!row) return null;
    await row.update({ ...fields, last_seen: new Date() });
    return row;
}

async function removeSession(key) {
    await initRegistry();
    const row = await getSession(key);
    if (!row) return false;
    await row.destroy();
    return true;
}

async function removeSessionsByTelegram(telegramId) {
    await initRegistry();
    return PairedSession.destroy({
        where: { telegram_id: String(telegramId) },
    });
}

async function countByStatus() {
    await initRegistry();
    const rows = await PairedSession.findAll({
        attributes: [
            "status",
            [DATABASE.fn("COUNT", DATABASE.col("status")), "count"],
        ],
        group: ["status"],
        raw: true,
    });
    const counts = {};
    for (const row of rows) counts[row.status] = Number(row.count);
    return counts;
}

module.exports = {
    PairedSession,
    STATUS,
    initRegistry,
    buildKey,
    listSessions,
    listSessionsByTelegram,
    getSession,
    getSessionByNumber,
    countSessions,
    countByStatus,
    createSession,
    updateSession,
    updateSessionById,
    removeSession,
    removeSessionsByTelegram,
};
