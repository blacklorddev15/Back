# Tests

```
npm test
```

`tests/run.js` is a self-contained harness (no test framework). It stubs the
Baileys socket so the whole suite runs offline, without a phone number and
without contacting WhatsApp.

## Covered (69 checks)

| Area | What is verified |
|---|---|
| Config | Limits parse into positive integers; `SESSIONS_DIR` is honoured |
| Number validation | International format accepted; local numbers, non-numeric, too short/long rejected |
| Registry | Create, lookup by key/number, status updates, status counts, one-owner-per-number constraint |
| Plugin loading | All 26 plugin files load, 0 failures, **305 commands** + 2 body handlers registered |
| Command resolution | `pair`, `onwa`, `vcf`, `menu` resolve to handlers that came from `commands/` |
| Dispatch | A `.onwa 254794469700` message serialises to `isCommand: true`, `command: onwa`, correct args; plain text is not a command |
| Session lifecycle | `start()` opens a socket and writes SQLite auth state; QR triggers `requestPairingCode`; `open` → active; 401/500/411 → logged out + session data wiped |
| Blast radius | A 440 (connection replaced) parks only that account; an unknown error reconnects instead of wiping; a bad session never calls `process.exit` |
| Pairing limits | Global cap, per-user cap, re-pair allowance, number already owned by someone else, cooldown, rolling window, pairing timeout → `PAIR_FAILED` with the row marked `failed` |
| Number recycling | A `logged_out` or `failed` row releases its number to a new user; a still-linked number stays blocked; dead rows do not consume the user's quota; releasing a number stops its stale runtime and does not leak a capacity slot |
| Resource accounting | No pairing reservation leaks on any failure path; the live-runtime count returns to its previous value after a failed pairing |
| Rate-limit fairness | A server-side rejection (capacity) refunds the token, so the next attempt is not charged a cooldown |
| Paths | Session directories resolve under `SESSIONS_DIR` and cannot escape it |
| Status views | Per-user status, owner snapshot, and stats; a row that claims to be connected with no live socket is reported `offline`; stats expose the memory-guard limit |
| Memory sizing | The per-account RSS figure is computed from the measured baseline (a 50 MB baseline gap over one live account reports ~50 MB) and is reported as `null` rather than `0 MB` when there is nothing to measure or growth went negative |

## Not covered — requires a real WhatsApp account

These paths can only be exercised with a live phone number, so they were **not**
verified here:

1. **An actual successful pairing** against WhatsApp's servers (socket handshake,
   `link_code_companion_reg`, code accepted on the phone).
2. **Sending and receiving real WhatsApp messages**, including media download and
   every command that hits an external API.
3. **Long-run stability** of 10-100 sockets in one process (memory growth,
   reconnect storms after a network outage).
4. **Postgres mode.** The suite runs on the default SQLite file; the registry
   model is dialect-neutral but has not been run against Postgres.
5. **Restore-after-restart with real credentials** (the restore code path is
   exercised, but with no live socket to reconnect).

To check those manually: set `BOT_TOKEN` and `OWNER_ID`, run `npm start`, then
`/pair <your number>` from Telegram and enter the code on the phone.

## Notes

- The harness writes only to `tests/.tmp-sessions/` and the local SQLite file,
  and deletes its own registry rows (`9900000*`) on completion.
- `gifted-baileys` is stubbed by injecting into Node's require cache before any
  other module loads; the real Baileys is still used for crypto/proto helpers so
  the auth-state layer is genuinely exercised.
