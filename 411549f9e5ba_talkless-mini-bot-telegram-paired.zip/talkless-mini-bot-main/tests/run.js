/**
 * Test harness for the multi-account pairing build.
 *
 * Run with:  npm test
 *
 * The WhatsApp socket is stubbed, so every test here runs without a phone
 * number, without a network connection and without touching WhatsApp servers.
 * What that means: pairing *mechanics* are covered, but a real end-to-end
 * pairing against WhatsApp is not (see tests/README.md).
 */
const path = require("path");
const fs = require("fs-extra");
const { EventEmitter } = require("events");

// ─── Stub gifted-baileys before anything requires it ─────────────────────────
const realBaileys = require("gifted-baileys");

let lastSocket = null;
const connectionLog = [];

function createFakeSocket(socketConfig) {
    const emitter = new EventEmitter();
    const processHandlers = [];

    const ev = {
        on: (event, handler) => emitter.on(event, handler),
        off: (event, handler) => emitter.off(event, handler),
        removeAllListeners: (event) => emitter.removeAllListeners(event),
        process: (handler) => {
            processHandlers.push(handler);
            return Promise.resolve();
        },
        emit: (event, payload) => {
            const result = emitter.emit(event, payload);
            for (const handler of processHandlers) {
                if (event !== "creds.update") continue;
                Promise.resolve(handler({ [event]: [payload] })).catch(() => {});
            }
            return result;
        },
        flush: async () => {},
        isBuffering: () => false,
        buffer: () => {},
    };

    const socket = {
        __fake: true,
        socketConfig,
        ev,
        user: { id: "255799999999:1@s.whatsapp.net", name: "Test Account" },
        authState: { creds: {}, keys: {} },
        pairingRequests: [],
        ended: false,
        loggedOutCount: 0,
        sentMessages: [],

        requestPairingCode: async function (number) {
            this.pairingRequests.push(number);
            return "ABCD1234";
        },
        sendMessage: async function (jid, content) {
            this.sentMessages.push({ jid, content });
            return { key: { id: `fake-${this.sentMessages.length}` } };
        },
        readMessages: async () => {},
        updateBlockStatus: async () => {},
        groupMetadata: async () => ({ participants: [] }),
        groupFetchAllParticipating: async () => ({}),
        newsletterFollow: async () => {},
        newsletterReactMessage: async () => {},
        profilePictureUrl: async () => null,
        end: function () {
            this.ended = true;
        },
        logout: async function () {
            this.loggedOutCount += 1;
        },
    };

    lastSocket = socket;
    return socket;
}

const stub = Object.assign({}, realBaileys, {
    default: (socketConfig) => {
        connectionLog.push(socketConfig);
        return createFakeSocket(socketConfig);
    },
    fetchLatestWaWebVersion: async () => ({ version: [2, 3000, 0] }),
});

const baileysPath = require.resolve("gifted-baileys");
require.cache[baileysPath] = {
    id: baileysPath,
    filename: baileysPath,
    loaded: true,
    exports: stub,
    children: [],
    paths: [],
};

// ─── Tiny assertion harness ──────────────────────────────────────────────────
let passed = 0;
const failures = [];

function check(name, fn) {
    try {
        const result = fn();
        if (result === false) throw new Error("assertion returned false");
        passed += 1;
        console.log(`  ✓ ${name}`);
    } catch (error) {
        failures.push({ name, error: error.message });
        console.error(`  ✗ ${name}\n      ${error.message}`);
    }
}

async function checkAsync(name, fn) {
    try {
        const result = await fn();
        if (result === false) throw new Error("assertion returned false");
        passed += 1;
        console.log(`  ✓ ${name}`);
    } catch (error) {
        failures.push({ name, error: error.message });
        console.error(`  ✗ ${name}\n      ${error.message}`);
    }
}

function assert(condition, message) {
    if (!condition) throw new Error(message || "assertion failed");
    return true;
}

function assertEqual(actual, expected, message) {
    if (actual !== expected) {
        throw new Error(
            `${message || "values differ"}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`
        );
    }
    return true;
}

async function expectPairError(fn, code) {
    try {
        await fn();
    } catch (error) {
        if (error.code !== code) {
            throw new Error(`expected PairError ${code}, got ${error.code || error.name}: ${error.message}`);
        }
        return true;
    }
    throw new Error(`expected PairError ${code}, but the call succeeded`);
}

const tick = () => new Promise((resolve) => setTimeout(resolve, 25));

// ─── Test state ──────────────────────────────────────────────────────────────
const TEST_TG = "990000001";
const TEST_TG_2 = "990000002";
const TEST_NUMBER = "255700000111";
const TEST_NUMBER_2 = "255700000222";
const TMP_SESSIONS = path.join(__dirname, ".tmp-sessions");

process.env.SESSIONS_DIR = TMP_SESSIONS;

// ─── Main ────────────────────────────────────────────────────────────────────
(async () => {
    await fs.remove(TMP_SESSIONS);
    await fs.ensureDir(TMP_SESSIONS);

    const manager = require("../whatsapp/manager");
    const registry = require("../whatsapp/registry");
    const shared = require("../whatsapp/shared");
    const config = require("../config");

    // ── 1. Config ────────────────────────────────────────────────────────────
    console.log("\n1. Config");
    check("MAX_SESSIONS is a positive integer", () =>
        assert(Number.isInteger(config.MAX_SESSIONS) && config.MAX_SESSIONS > 0)
    );
    check("limits are integers", () =>
        assert(
            Number.isInteger(config.MAX_SESSIONS_PER_USER) &&
                Number.isInteger(config.PENDING_PAIR_LIMIT) &&
                Number.isInteger(config.PAIR_COOLDOWN_SECONDS)
        )
    );
    check("SESSIONS_DIR is set", () => assertEqual(config.SESSIONS_DIR, TMP_SESSIONS));

    // ── 2. Number validation ─────────────────────────────────────────────────
    console.log("\n2. Number validation");
    const { validateNumber, normalizeNumber } = manager._internal;

    check("accepts a normal international number", () =>
        assertEqual(validateNumber("255712345678").number, "255712345678")
    );
    check("strips +, spaces and dashes", () =>
        assertEqual(validateNumber("+255 712-345-678").number, "255712345678")
    );
    check("rejects a local number with a leading 0", () =>
        assertEqual(validateNumber("0712345678").ok, false)
    );
    check("rejects non-numeric input", () => assertEqual(validateNumber("abc").ok, false));
    check("rejects an empty value", () => assertEqual(validateNumber("").ok, false));
    check("rejects a too short number", () => assertEqual(validateNumber("12345").ok, false));
    check("rejects a too long number", () =>
        assertEqual(validateNumber("1234567890123456").ok, false)
    );
    check("normalizeNumber keeps digits only", () =>
        assertEqual(normalizeNumber("+25 57-123"), "2557123")
    );

    // ── 3. Registry ──────────────────────────────────────────────────────────
    console.log("\n3. Registry persistence");
    await registry.initRegistry();
    await registry.removeSessionsByTelegram(TEST_TG);
    await registry.removeSessionsByTelegram(TEST_TG_2);

    const row = await registry.createSession({
        telegramId: TEST_TG,
        telegramUsername: "tester",
        telegramName: "Test User",
        waNumber: TEST_NUMBER,
        sessionDir: registry.buildKey(TEST_TG, TEST_NUMBER).replace(":", "/"),
        status: registry.STATUS.PENDING,
    });

    check("row is created with the right key", () =>
        assertEqual(row.session_key, `${TEST_TG}:${TEST_NUMBER}`)
    );

    const fetched = await registry.getSessionByNumber(TEST_NUMBER);
    check("lookup by number works", () => assertEqual(fetched.telegram_id, TEST_TG));

    await registry.updateSession(row.session_key, { status: registry.STATUS.ACTIVE });
    const updated = await registry.getSession(row.session_key);
    check("status update persists", () =>
        assertEqual(updated.status, registry.STATUS.ACTIVE)
    );

    const counts = await registry.countByStatus();
    check("countByStatus reports the active row", () => assert((counts.active || 0) >= 1));

    await checkAsync("a number cannot be registered to two owners", async () => {
        try {
            await registry.createSession({
                telegramId: TEST_TG_2,
                waNumber: TEST_NUMBER,
                sessionDir: "other",
                status: registry.STATUS.PENDING,
            });
        } catch (error) {
            return true;
        }
        throw new Error("duplicate number was accepted");
    });

    // Removed before manager.init() so the restore pass does not adopt it.
    await registry.removeSession(row.session_key);

    // ── 4. Plugin registry (WhatsApp commands) ───────────────────────────────
    console.log("\n4. WhatsApp command plugins");
    const initInfo = await manager.init({ notify: async () => {} });

    check("every plugin file loads", () =>
        assertEqual(initInfo.plugins.failed.length, 0, "failed plugins")
    );
    check("26 plugin files loaded", () => assertEqual(initInfo.plugins.loaded.length, 26));
    check("305 commands registered", () => assertEqual(initInfo.commands, 305));
    check("2 body handlers registered", () => assertEqual(initInfo.bodyCommands, 2));
    check("plugin report is retrievable", () => {
        const report = shared.getPluginReport();
        return assert(report && report.total === 305);
    });

    const bot = require("../talkless_mini_bot");
    const { getAllSettings } = require("../talkless_mini_bot/database/settings");
    const settings = await getAllSettings();

    for (const pattern of ["pair", "onwa", "vcf", "menu"]) {
        check(`/^${pattern}$/ resolves to a command`, () => {
            const cmd = bot.findCommand(pattern);
            assert(cmd, `no command registered for "${pattern}"`);
            assert(typeof cmd.function === "function", `${pattern} has no handler`);
            assert(
                cmd.filename.includes(`${path.sep}commands${path.sep}`),
                `${pattern} did not come from commands/: ${cmd.filename}`
            );
            return true;
        });
    }

    // ── 5. Message dispatch into the WhatsApp command set ────────────────────
    console.log("\n5. Command dispatch");
    const fakeSocketForSerialize = {
        user: { id: "255799999999:1@s.whatsapp.net", name: "Test Account" },
    };

    const serialized = await bot.serializeMessage(
        {
            key: {
                remoteJid: "255700000001@s.whatsapp.net",
                fromMe: false,
                id: "TEST-MSG-1",
            },
            message: { conversation: `${settings.PREFIX}onwa 254794469700` },
            pushName: "Tester",
            messageTimestamp: Math.floor(Date.now() / 1000),
        },
        fakeSocketForSerialize,
        settings
    );

    check("message is recognised as a command", () =>
        assertEqual(serialized.isCommand, true)
    );
    check("command name is parsed", () => assertEqual(serialized.command, "onwa"));
    check("arguments are parsed", () => {
        assert(Array.isArray(serialized.args), "args is not an array");
        return assertEqual(serialized.args[0], "254794469700");
    });
    check("non-command text is not treated as a command", async () => {
        const plain = await bot.serializeMessage(
            {
                key: {
                    remoteJid: "255700000001@s.whatsapp.net",
                    fromMe: false,
                    id: "TEST-MSG-2",
                },
                message: { conversation: "hello there" },
                pushName: "Tester",
                messageTimestamp: Math.floor(Date.now() / 1000),
            },
            fakeSocketForSerialize,
            settings
        );
        return assertEqual(plain.isCommand, false);
    });

    // ── 6. Session factory lifecycle ─────────────────────────────────────────
    console.log("\n6. Session lifecycle (stubbed socket)");
    const { createWhatsAppSession } = require("../whatsapp/sessionFactory");
    const facDir = path.join(TMP_SESSIONS, "lifecycle-test");
    const statuses = [];
    let logoutSeen = false;

    const session = createWhatsAppSession({
        key: "lifecycle:test",
        sessionDir: facDir,
        onStatus: ({ status }) => statuses.push(status),
        onLogout: () => {
            logoutSeen = true;
        },
    });

    await session.start();
    const sock = session.getSocket();

    check("start() creates a socket", () => assert(sock && sock.__fake));
    check("start() writes sqlite auth state", () =>
        assert(fs.existsSync(path.join(facDir, "session.db")))
    );

    const code = await (async () => {
        const promise = session.requestPairingCode("255712345678");
        await tick();
        sock.ev.emit("connection.update", { qr: "qr-payload" });
        return promise;
    })();

    check("pairing code is returned to the caller", () => assertEqual(code, "ABCD1234"));
    check("pairing code was requested for the right number", () =>
        assertEqual(sock.pairingRequests[0], "255712345678")
    );

    sock.ev.emit("connection.update", { connection: "open" });
    await tick();
    check("connection open marks the session active", () =>
        assertEqual(session.getStatus(), "active")
    );
    check("status callbacks fired", () => assert(statuses.includes("active")));

    // Baileys reports disconnects with a Boom error, so use the real shape.
    const { Boom } = require("@hapi/boom");

    sock.ev.emit("connection.update", {
        connection: "close",
        lastDisconnect: { error: new Boom("Connection Closed", { statusCode: 401 }) },
    });
    await tick();

    check("remote logout is reported", () => assertEqual(logoutSeen, true));
    check("remote logout sets logged_out", () =>
        assertEqual(session.getStatus(), "logged_out")
    );
    check("remote logout wipes local session data", () =>
        assert(!fs.existsSync(facDir))
    );

    // Reconnecting session must not exit the process.
    const facDir2 = path.join(TMP_SESSIONS, "reconnect-test");
    const session2 = createWhatsAppSession({
        key: "reconnect:test",
        sessionDir: facDir2,
        onStatus: () => {},
    });
    await session2.start();
    const sock2 = session2.getSocket();

    sock2.ev.emit("connection.update", {
        connection: "close",
        lastDisconnect: { error: new Boom("replaced", { statusCode: 440 }) },
    });
    await tick();
    check("connection replaced parks the account instead of exiting", () =>
        assertEqual(session2.getStatus(), "offline")
    );
    check("parked account keeps its session data", () =>
        assert(fs.existsSync(path.join(facDir2, "session.db")))
    );

    // An unrecognised error must never be treated as a dead session.
    sock2.ev.emit("connection.update", {
        connection: "close",
        lastDisconnect: { error: new Error("socket hang up") },
    });
    await tick();
    check("unknown disconnect reason reconnects instead of wiping", () => {
        assert(
            session2.getStatus() !== "logged_out",
            `unexpected status ${session2.getStatus()}`
        );
        return assert(fs.existsSync(path.join(facDir2, "session.db")));
    });

    sock2.ev.emit("connection.update", {
        connection: "close",
        lastDisconnect: { error: new Boom("mismatch", { statusCode: 411 }) },
    });
    await tick();
    check("multidevice mismatch stops the account", () =>
        assertEqual(session2.getStatus(), "logged_out")
    );

    await session2.stop({ keepData: false });

    // ── 7. Pairing limits ────────────────────────────────────────────────────
    console.log("\n7. Pairing limits");
    const savedConfig = {
        MAX_SESSIONS: config.MAX_SESSIONS,
        MAX_SESSIONS_PER_USER: config.MAX_SESSIONS_PER_USER,
        PAIR_COOLDOWN_SECONDS: config.PAIR_COOLDOWN_SECONDS,
        PAIR_MAX_PER_WINDOW: config.PAIR_MAX_PER_WINDOW,
        PAIR_WINDOW_SECONDS: config.PAIR_WINDOW_SECONDS,
        PAIR_TIMEOUT_SECONDS: config.PAIR_TIMEOUT_SECONDS,
    };

    manager._internal.resetRateLimits();
    config.PAIR_COOLDOWN_SECONDS = 0;
    config.PAIR_MAX_PER_WINDOW = 100;
    config.MAX_SESSIONS_PER_USER = 1;

    await checkAsync("invalid numbers fail before any limit applies", async () => {
        await expectPairError(
            () => manager.pair({ telegramId: "990000010", number: "0712345678" }),
            "INVALID_NUMBER"
        );
        return true;
    });

    // Each scenario gets its own Telegram id so the checks cannot mask each other.
    config.MAX_SESSIONS = 0;

    await checkAsync("global capacity cap rejects new pairings", () =>
        expectPairError(
            () => manager.pair({ telegramId: "990000010", number: "255712345678" }),
            "CAPACITY"
        )
    );

    await registry.createSession({
        telegramId: "990000011",
        waNumber: TEST_NUMBER,
        sessionDir: `${TEST_TG}/${TEST_NUMBER}`,
        status: registry.STATUS.ACTIVE,
    });

    await checkAsync("per-user cap rejects a second number", () =>
        expectPairError(
            () => manager.pair({ telegramId: "990000011", number: TEST_NUMBER_2 }),
            "PER_USER_LIMIT"
        )
    );

    await checkAsync("re-pairing an owned number passes the per-user gate", () =>
        expectPairError(
            () => manager.pair({ telegramId: "990000011", number: TEST_NUMBER }),
            "CAPACITY"
        )
    );

    await checkAsync("a number owned by someone else is rejected", () =>
        expectPairError(
            () => manager.pair({ telegramId: "990000012", number: TEST_NUMBER }),
            "NUMBER_TAKEN"
        )
    );

    // NUMBER_TAKEN is a user-caused rejection, so it stays on the meter; use it
    // to test the cooldown and window without the server-side refund kicking in.
    manager._internal.resetRateLimits();
    config.PAIR_COOLDOWN_SECONDS = 60;
    config.PAIR_MAX_PER_WINDOW = 5;

    await checkAsync("cooldown blocks an immediate second attempt", async () => {
        await expectPairError(
            () => manager.pair({ telegramId: "990000013", number: TEST_NUMBER }),
            "NUMBER_TAKEN"
        );
        await expectPairError(
            () => manager.pair({ telegramId: "990000013", number: TEST_NUMBER }),
            "COOLDOWN"
        );
        return true;
    });

    manager._internal.resetRateLimits();
    config.PAIR_COOLDOWN_SECONDS = 0;
    config.PAIR_MAX_PER_WINDOW = 2;

    await checkAsync("rolling window caps repeated attempts", async () => {
        await expectPairError(
            () => manager.pair({ telegramId: "990000014", number: TEST_NUMBER }),
            "NUMBER_TAKEN"
        );
        await expectPairError(
            () => manager.pair({ telegramId: "990000014", number: TEST_NUMBER }),
            "NUMBER_TAKEN"
        );
        await expectPairError(
            () => manager.pair({ telegramId: "990000014", number: TEST_NUMBER }),
            "RATE_LIMITED"
        );
        return true;
    });

    manager._internal.resetRateLimits();
    config.PAIR_TIMEOUT_SECONDS = 1;

    await checkAsync("a capacity rejection refunds the rate-limit token", async () => {
        config.MAX_SESSIONS = 0;
        config.PAIR_COOLDOWN_SECONDS = 60;
        await expectPairError(
            () => manager.pair({ telegramId: "990000016", number: "255700000444" }),
            "CAPACITY"
        );
        config.MAX_SESSIONS = 100;
        config.PAIR_COOLDOWN_SECONDS = 0;
        // With the token refunded this reaches WhatsApp and times out; had the
        // rejection been charged, this would have thrown COOLDOWN instead.
        await expectPairError(
            () => manager.pair({ telegramId: "990000016", number: "255700000444" }),
            "PAIR_FAILED"
        );
        return true;
    });

    await checkAsync("a logged-out row releases its number to a new user", async () => {
        await registry.createSession({
            telegramId: "990000017",
            waNumber: "255700000555",
            sessionDir: "stale/255700000555",
            status: registry.STATUS.LOGGED_OUT,
        });

        const before = await registry.getSessionByNumber("255700000555");
        assertEqual(before.telegram_id, "990000017");

        // Simulate the leak this path used to have: a parked runtime still
        // registered in `live` for the about-to-be-released key.
        const staleKey = before.session_key;
        let staleStopped = false;
        manager._internal.live.set(staleKey, {
            stop: async () => {
                staleStopped = true;
            },
            whenSettled: async () => {},
            getStatus: () => "logged_out",
            getInfo: () => ({ status: "logged_out" }),
        });
        const liveBefore = manager._internal.live.size;

        await expectPairError(
            () => manager.pair({ telegramId: "990000018", number: "255700000555" }),
            "PAIR_FAILED"
        );

        const after = await registry.getSessionByNumber("255700000555");
        assertEqual(after.telegram_id, "990000018", "number was not released");
        check("releasing a number stops its stale runtime", () =>
            assertEqual(staleStopped, true)
        );
        check("releasing a number does not leak a capacity slot", () =>
            assertEqual(manager._internal.live.has(staleKey), false)
        );
        check("no reservation leaks after a failed pairing", () =>
            assertEqual(manager._internal.getReservedSlots(), 0)
        );
        check("live count returns to its earlier value", () => {
            // The new user's own (failed) session must have been cleaned up.
            return assertEqual(manager._internal.live.size, liveBefore - 1);
        });
        return true;
    });

    await checkAsync("a still-linked number stays blocked for other users", () =>
        expectPairError(
            () => manager.pair({ telegramId: "990000019", number: TEST_NUMBER }),
            "NUMBER_TAKEN"
        )
    );

    await checkAsync("a failed row does not consume the user's quota", async () => {
        // MAX_SESSIONS_PER_USER is 1 here: reaching WhatsApp at all proves the
        // dead row did not count against the quota.
        await registry.createSession({
            telegramId: "990000021",
            waNumber: "255700000666",
            sessionDir: "dead/255700000666",
            status: registry.STATUS.FAILED,
        });

        await expectPairError(
            () => manager.pair({ telegramId: "990000021", number: "255700000777" }),
            "PAIR_FAILED"
        );
        return true;
    });

    // The happy path needs WhatsApp to answer, so cover the timeout branch:
    // the stubbed socket never emits a QR, so WhatsApp never issues a code.
    config.MAX_SESSIONS = 100;
    config.MAX_SESSIONS_PER_USER = 2;
    config.PAIR_COOLDOWN_SECONDS = 0;
    config.PAIR_TIMEOUT_SECONDS = 1;

    await checkAsync("a pairing request that times out fails cleanly", async () => {
        await expectPairError(
            () =>
                manager.pair({
                    telegramId: "990000015",
                    number: "255700000333",
                    telegramName: "Timeout Test",
                }),
            "PAIR_FAILED"
        );
        const row = await registry.getSessionByNumber("255700000333");
        assert(row, "the failed attempt left no registry row");
        assertEqual(row.status, registry.STATUS.FAILED);
        return true;
    });

    Object.assign(config, savedConfig);
    manager._internal.resetRateLimits();

    // ── 8. Session paths ─────────────────────────────────────────────────────
    console.log("\n8. Session storage paths");
    const { sessionSegment, resolveSessionDir } = manager._internal;
    const segment = sessionSegment(TEST_TG, TEST_NUMBER);
    check("segment is telegramId/number", () =>
        assertEqual(segment, path.join(TEST_TG, TEST_NUMBER))
    );
    check("resolved dir stays inside SESSIONS_DIR", () => {
        const resolved = resolveSessionDir(segment);
        return assert(
            resolved.startsWith(TMP_SESSIONS),
            `escaped the sessions root: ${resolved}`
        );
    });

    // ── 9. Status / owner views ──────────────────────────────────────────────
    console.log("\n9. Status views");
    const statusesForUser = await manager.getStatusFor("990000011");
    check("user status lists their account", () => assertEqual(statusesForUser.length, 1));
    check("status reports a connection state", () =>
        assert(
            typeof statusesForUser[0].status === "string" &&
                statusesForUser[0].status.length > 0
        )
    );
    check("status marks a non-running account offline", () =>
        assertEqual(statusesForUser[0].status, "offline")
    );

    const snapshot = await manager.getOwnerSnapshot();
    check("owner snapshot includes the account", () =>
        assert(snapshot.some((row) => row.number === TEST_NUMBER))
    );

    const stats = await manager.getStats();
    check("stats expose account and command counts", () =>
        assert(stats.accounts.registered >= 1 && stats.commands.total === 305)
    );
    check("stats report no per-account figure without live accounts", () =>
        assertEqual(stats.accounts.avgRssMbPerAccount, null)
    );
    check("stats expose the memory guard limit", () =>
        assertEqual(stats.limits.maxRssMb, config.MAX_RSS_MB)
    );

    await checkAsync("stats measure per-account RSS and clamp negative growth", async () => {
        const rss = process.memoryUsage().rss;
        const testKey = "rss-measurement:test";
        manager._internal.live.set(testKey, {
            stop: async () => {},
            whenSettled: async () => {},
            getStatus: () => "active",
            getInfo: () => ({ status: "active" }),
        });

        try {
            // 50 MB of measured growth over one live account must report ~50 MB.
            manager._internal.setRssBaseline(rss - 50 * 1024 * 1024);
            const grown = await manager.getStats();
            assert(
                grown.accounts.avgRssMbPerAccount >= 40 &&
                    grown.accounts.avgRssMbPerAccount <= 60,
                `expected ~50 MB per account, got ${grown.accounts.avgRssMbPerAccount}`
            );

            // Growth below the baseline (GC, or accounts stopped) must not be
            // reported as "0 MB per account", which would read like "free".
            manager._internal.setRssBaseline(rss + 100 * 1024 * 1024);
            const shrunk = await manager.getStats();
            assertEqual(
                shrunk.accounts.avgRssMbPerAccount,
                null,
                "negative growth must not be reported as 0 MB"
            );
        } finally {
            manager._internal.live.delete(testKey);
            manager._internal.setRssBaseline(process.memoryUsage().rss);
        }
        return true;
    });

    // ── Cleanup ──────────────────────────────────────────────────────────────
    console.log("\n10. Cleanup");
    await manager.shutdown();

    const leftovers = (await registry.listSessions()).filter((r) =>
        String(r.telegram_id).startsWith("9900000")
    );
    for (const leftover of leftovers) {
        await registry.removeSession(leftover.session_key);
    }
    await fs.remove(TMP_SESSIONS);

    const remaining = (await registry.listSessions()).filter((r) =>
        String(r.telegram_id).startsWith("9900000")
    );
    check("test rows removed", () => assertEqual(remaining.length, 0));

    // ── Report ───────────────────────────────────────────────────────────────
    console.log(
        `\n${failures.length ? "❌" : "✅"} ${passed} passed, ${failures.length} failed`
    );
    if (failures.length) {
        for (const failure of failures) {
            console.error(`   ✗ ${failure.name}: ${failure.error}`);
        }
        process.exit(1);
    }
    process.exit(0);
})().catch((error) => {
    console.error("Harness crashed:", error);
    process.exit(1);
});
