> ## 🔗 Multi-user pairing is live
> The Telegram bot now doubles as a **multi-account WhatsApp pairing server**.
> - `/pair 255712345678` → the bot returns an 8-character pairing code for that number.
> - Enter the code on the phone: **WhatsApp → Settings → Linked devices → Link a device → Link with phone number instead**.
> - Once linked, the **full WhatsApp command set (305 commands)** runs on that account, exactly as the original single-account bot did.
> - Many users can pair at the same time. Each account gets its own isolated session under `sessions/<telegram_id>/<number>/` and its own socket.
> - Telegram commands: `/pair`, `/status`, `/unpair` for everyone; `/sessions`, `/kill`, `/stats` for the owner.
> - Run it with `npm install && npm start` after setting `BOT_TOKEN` in `.env`. See `.env.example` for every option.

### How pairing works

```
Telegram user                Bot process                        WhatsApp
─────────────                ───────────                        ────────
/pair 255712345678  ──▶  validate + rate-limit
                         create sessions/<tg>/<number>/
                         open a Baileys socket   ──────────▶  handshake
                         requestPairingCode()    ◀──────────  8-char code
        ◀──────────────  reply with the code
enter code on phone    ──────────────────────────────────▶  link accepted
        ◀──────────────  "✅ linked and online"      ◀──────────  connection open
                         every WhatsApp command now runs on that account
```

What the bot enforces so many users can share one process:

| Limit | Env var | Default |
|---|---|---|
| Accounts running at once | `MAX_SESSIONS` | 100 |
| Accounts per Telegram user | `MAX_SESSIONS_PER_USER` | 2 |
| Concurrent pairing handshakes | `PENDING_PAIR_LIMIT` | 5 |
| Cooldown between pairing attempts | `PAIR_COOLDOWN_SECONDS` | 60s |
| Attempts per rolling hour | `PAIR_MAX_PER_WINDOW` | 5 |
| Code expiry | `PAIR_STALE_SECONDS` | 300s |
| Reconnect cap per account | `SESSION_MAX_RECONNECT_ATTEMPTS` | 10 |

**Operational notes**

- `SESSIONS_DIR` holds WhatsApp credentials. Put it on a **persistent disk**. On
  hosts with an ephemeral filesystem (Heroku, most free tiers) every linked
  account is lost on restart and users have to `/pair` again — the bot degrades
  gracefully (those accounts are marked `logged_out`, never silently broken).
- **`MAX_SESSIONS` is a hard ceiling, but `MAX_RSS_MB` is usually what actually
  binds first.** The bot refuses new pairings once RSS passes `MAX_RSS_MB`
  (default 1500 MB), so on a 512 MB instance you will hit the memory guard long
  before 100 accounts. Don't guess the per-account cost on your host — run
  `/stats` once a few accounts are linked and read **"avg RSS per account"**,
  which is this process's own measurement of how much it grew per connected
  account since startup (it reads `not available yet` until there is at least
  one live account and some measurable growth). Then set `MAX_SESSIONS` to what
  your plan's memory can hold.
- One account is one WhatsApp session: sessions in this process never share
  credentials, and a remote logout on one account does not affect the others.
- `legacy-whatsapp-index.js.bak` is kept as the original single-account
  reference. The live code path is `whatsapp/sessionFactory.js`, which is that
  same runtime turned into a factory.

**Troubleshooting: `GLIBC_2.xx not found` on startup**

If the bot dies with something like:

```
Error: /lib/x86_64-linux-gnu/libm.so.6: version `GLIBC_2.38' not found
       (required by .../node_modules/sqlite3/build/Release/node_sqlite3.node)
```

the host's system libraries are older than the prebuilt SQLite driver. This
project pins drivers that run on old hosts on purpose — do not "upgrade" them:

| Package | Pinned | Needs at most | So it runs on |
|---|---|---|---|
| `sqlite3` | `^5.1.7` | GLIBC_2.4 | anything |
| `better-sqlite3` | `^11.10.0` | GLIBC_2.29 | Debian 10+, Ubuntu 19+ |

Newer releases (`sqlite3@6`, `better-sqlite3@13`) ship binaries built against
GLIBC_2.34-2.38 and fail on those hosts. To check your host: `ldd --version`.

Fixes, in order of preference:

1. Reinstall from the lockfile, which already pins the safe versions:
   `rm -rf node_modules && npm install`
2. If the prebuilt binary cannot be downloaded, build it locally (needs
   `python3`, `make`, `g++` on the host):
   `npm rebuild sqlite3 better-sqlite3 --build-from-source`
3. Point `DATABASE_URL` at a Postgres database to skip the SQLite driver for the
   bot's own settings/registry. Note this does **not** remove the need for
   `better-sqlite3`, which stores each linked account's WhatsApp credentials.

**Known limitation (unchanged from the original design)**

WhatsApp *credentials and sockets* are fully per-account, but two pieces of state
are still process-wide because all 26 command plugins read them by JID alone:

- the group metadata cache (`talkless_mini_bot/connection/groupCache.js`), and
- the single settings row (`PREFIX`, `MODE`, `BOT_NAME`, owner number, …).

Practical effect: all linked accounts share one command prefix and one
configuration, and group metadata fetched by one account can be served to
another account that is in the same group. Nothing here exposes a WhatsApp
session or lets one user read another user's chats, but if you need hard
per-user isolation, run one instance per account with `MAX_SESSIONS=1`
(`SESSIONS_DIR` per instance) instead of one instance for everybody.

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<h1 align="center">𝐁𝐋𝐀𝐂𝐊 𝐇𝐀𝐓 𝐌𝐃 𝐕𝐄𝐑𝐒𝐈𝐎𝐍 5.0.1</h1>

<p align="center">
  <b>WhatsApp Multi-Device Bot</b>
</p>

<p align="center">
  🚀 Easy Deployment • ⚡ Fast • 🔥 Powerful
</p>

> ⚠️ For Heroku, VPS and Bot Hosting deployments, follow the instructions below carefully.

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## 📢 NOTICE

<details>
<summary><b>⚠️ TAP TO READ</b></summary>

### 📦 IMPORTANT FOR VPS / PANEL USERS

For **VPS / Bot Hosting Panel deployment**, download the ZIP file from the button below.

This is recommended for panel deployment, especially if you want the media and YouTube downloader features to work correctly.

<a href="https://github.com/clevertechn/talkless-mini-bot/archive/refs/heads/main.zip">
<img src="https://img.shields.io/badge/DOWNLOAD%20ZIP-yellow" alt="Download ZIP" width="180">
</a>

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## 🔗 OFFICIAL LINKS

<p align="center">

<a href="https://github.com/clevertechn">
<img title="GITHUB" src="https://img.shields.io/badge/GITHUB-CLEVER%20TECH-red.svg?style=for-the-badge&logo=github">
</a>

</p>

<p align="center">

<a href="https://github.com/clevertechn?tab=followers">
<img title="Followers" src="https://img.shields.io/github/followers/clevertechn?label=Followers&style=social">
</a>

<a href="https://github.com/clevertechn/talkless-mini-bot/stargazers/">
<img title="STARS" src="https://img.shields.io/github/stars/clevertechn/talkless-mini-bot?style=social">
</a>

<a href="https://github.com/clevertechn/talkless-mini-bot/network/members">
<img title="Forks" src="https://img.shields.io/github/forks/clevertechn/talkless-mini-bot?style=social">
</a>

<a href="https://github.com/clevertechn/talkless-mini-bot/watchers">
<img title="Watching" src="https://img.shields.io/github/watchers/clevertechn/talkless-mini-bot?label=Watching&style=social">
</a>

</p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

# 𝟏. 𝐒𝐄𝐓𝐔𝐏

## 🍴 FORK THE REPOSITORY

**FORK IS RECOMMENDED**

<details>
<summary><b>👉 CLICK HERE TO FORK</b></summary>

Forking the repository gives you your own copy of the project for deployment and customization.

<a href="https://github.com/clevertechn/talkless-mini-bot/fork">
<img src="https://img.shields.io/badge/FORK%20REPOSITORY-purple?style=for-the-badge" alt="Fork Repository">
</a>

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

# 𝟐. 𝐋𝐈𝐍𝐊 𝐖𝐈𝐓𝐇 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏

<details>
<summary><b>🔐 GET YOUR SESSION_ID</b></summary>

<br>

<p align="center">
<b>Click any server below to generate your Session ID.</b>
</p>

<div align="center">

<a href="https://sessionn.clevertech.qzz.io" target="_blank">
<img src="https://img.shields.io/badge/PAIRING_CODE_SERVER_1-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" alt="Pairing Server 1">
</a>

&nbsp;&nbsp;

<a href="https://pair.clevertech.qzz.io" target="_blank">
<img src="https://img.shields.io/badge/PAIRING_CODE_SERVER_2-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" alt="Pairing Server 2">
</a>

&nbsp;&nbsp;

<a href="https://sessionn.clevertech.qzz.io" target="_blank">
<img src="https://img.shields.io/badge/PAIRING_CODE_SERVER_3-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" alt="Pairing Server 3">
</a>

</div>

<br>

<p align="center">
⚠️ Your Session ID must start with:
<br>
<b>TALKLESSMINIBOT~</b>
</p>

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

# 𝟑. 𝐃𝐄𝐏𝐋𝐎𝐘𝐌𝐄𝐍𝐓

---

## 🅰️ HEROKU DEPLOYMENT

<details>
<summary><b>🚀 TAP TO OPEN HEROKU DEPLOYMENT</b></summary>

<br>

<a href="https://signup.heroku.com/login">
<img src="https://img.shields.io/badge/HEROKU%20SIGNUP-white?style=for-the-badge" alt="Heroku Signup">
</a>

<a href="https://dashboard.heroku.com/new?template=https://github.com/clevertechn/talkless-mini-bot">
<img src="https://img.shields.io/badge/DEPLOY%20NOW-red?style=for-the-badge" alt="Deploy on Heroku">
</a>

### Database

PostgreSQL is automatically provisioned through the Heroku configuration.

No manual PostgreSQL setup should be required if the provided configuration is used.

### Environment Variables

Add your:

```env
SESSION_ID=TALKLESSMINIBOT~your_session_id_here
```

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

---

# 🅱️ BOT HOSTING PANEL DEPLOYMENT 🔥

<details>
<summary><b>🔥 TAP TO OPEN BOT HOSTING GUIDE</b></summary>

<p aligin="center">
  Need a server to run TALKLESS MINI BOT 24/7?
</p>

<p align="center"><a href="https://bot-hosting.net/?aff=clevertechn" target="_blank">
<img src="https://img.shields.io/badge/🔥%20GET%20YOUR%20BOT%20HOSTING%20NOW-blue?style=for-the-badge" alt="Get Bot Hosting">
</a></p><p align="center">
⚡ Easy Setup • 🚀 Fast Deployment • 🔥 24/7 Hosting
</p>---
<br>

### STEP 1 — DOWNLOAD THE BOT FILES

Download the ZIP file:

<a href="https://github.com/clevertechn/talkless-mini-bot/archive/refs/heads/main.zip">
<img src="https://img.shields.io/badge/DOWNLOAD%20FILES-yellow?style=for-the-badge" alt="Download Files">
</a>

Extract the ZIP and upload the bot files to your Bot Hosting server using **SFTP/File Manager**.

---

### STEP 2 — INSTALL DEPENDENCIES

Your hosting panel should install the dependencies from `package.json`.

If your panel has an **Install Dependencies** button, use it.

---

### STEP 3 — SET ENVIRONMENT VARIABLES

Open your server's **Variables / Environment Variables** section and add:

```env
SESSION_ID=TALKLESSMINIBOT~your_session_id_here
MODE=public
TIME_ZONE=Africa/Nairobi
```

Replace:

```text
TALKLESSMINIBOT~your_session_id_here
```

with your real Session ID.

---

# ⚙️ STEP 4 — SET THE STARTUP COMMAND

⚠️ **THIS STEP IS VERY IMPORTANT!**

Open your Bot Hosting server dashboard.

Go to:

```text
Server → Startup
```

or:

```text
Server → Startup Command
```

Depending on the panel version.

You will see a field called:

```text
STARTUP COMMAND
```

### ❌ Remove the old command

Delete the existing Startup Command.

### ✅ Paste this command

```bash
cd /home/container && npm install --no-fund --no-audit && npm install-scripts approve sharp && npm install-scripts approve better-sqlite3 && npm rebuild sharp && npm rebuild better-sqlite3 && exec node index.js
```

### 📌 IMPORTANT

Do **NOT** put this command inside:

- `package.json`
- `index.js`
- `.env`
- SFTP
- Console as a permanent file

It belongs in the **Startup Command field** of your Bot Hosting server.

---

### STEP 5 — SAVE THE STARTUP COMMAND

After pasting the command:

1. Click **Save**
2. Go back to your server
3. Click **Restart**
4. Wait for the installation to finish
5. Check the Console

You should eventually see messages similar to:

```text
Server Running on Port: 5000
Session File Loaded
Database Synchronized.
Bot Settings Initialized
Group Settings Initialized.
```

If the bot starts successfully, keep the server running.

---

### 🛠️ IF THE BOT FAILS TO START

Do not randomly change files.

Copy the **last error from the Console** and check what module or package is causing the problem.

Common native modules include:

```text
sharp
better-sqlite3
sqlite3
```

The Startup Command above is designed to approve and rebuild the important native dependencies automatically.

---

### 🎥 VIDEO TUTORIAL

<a href="https://youtu.be/5uefRCSJegU?feature=shared">
<img src="https://img.shields.io/badge/WATCH%20TUTORIAL-red?style=for-the-badge" alt="Bot Hosting Tutorial">
</a>

### 🔥 GET BOT HOSTING

<a href="https://bot-hosting.net/?aff=clevertechn" target="_blank">
<img src="https://img.shields.io/badge/🚀%20BOT%20HOSTING%20%E2%80%94%20START%20NOW-blue?style=for-the-badge" alt="Bot Hosting">
</a></details><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

---

# 🅲️ RENDER DEPLOYMENT

<details>
<summary><b>🚀 TAP TO OPEN RENDER DEPLOYMENT</b></summary>

<br>

<a href="https://dashboard.render.com/signup">
<img src="https://img.shields.io/badge/RENDER%20SIGNUP-green?style=for-the-badge" alt="Render Signup">
</a>

<a href="https://render.com/deploy">
<img src="https://img.shields.io/badge/DEPLOY%20NOW-blue?style=for-the-badge" alt="Deploy on Render">
</a>

### Steps

1. Fork this repository.
2. Sign in to Render.
3. Click **New → Blueprint**.
4. Connect your forked repository.
5. Render reads the project configuration.
6. Add your `SESSION_ID`.
7. Click **Apply**.

### Environment Variables

```env
SESSION_ID=TALKLESSMINIBOT~your_session_id_here
MODE=public
TIME_ZONE=Africa/Nairobi
```

> ⚠️ For persistent database storage, use PostgreSQL and set `DATABASE_URL`.

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

---

# 🅳 RAILWAY DEPLOYMENT

<details>
<summary><b>🚂 TAP TO OPEN RAILWAY DEPLOYMENT</b></summary>

<br>

<a href="https://railway.app/login">
<img src="https://img.shields.io/badge/RAILWAY%20SIGNUP-black?style=for-the-badge" alt="Railway Signup">
</a>

<a href="https://railway.app/new/template">
<img src="https://img.shields.io/badge/DEPLOY%20NOW-purple?style=for-the-badge" alt="Deploy on Railway">
</a>

### Steps

1. Fork this repository.
2. Sign in to Railway.
3. Click **New Project**.
4. Select **Deploy from GitHub repo**.
5. Select your fork.
6. Add a PostgreSQL database.
7. Open the **Variables** section.

Add:

```env
SESSION_ID=TALKLESSMINIBOT~your_session_id_here
MODE=public
TIME_ZONE=Africa/Nairobi
```

Railway can provide the PostgreSQL connection through the project environment.

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

---

# 🅴 KOYEB DEPLOYMENT

<details>
<summary><b>☁️ TAP TO OPEN KOYEB DEPLOYMENT</b></summary>

<br>

<a href="https://app.koyeb.com/auth/signup">
<img src="https://img.shields.io/badge/KOYEB%20SIGNUP-purple?style=for-the-badge" alt="Koyeb Signup">
</a>

<a href="https://app.koyeb.com/services/deploy/?type=git&repository=github.com%2Fclevertechn%2Ftalkless-mini-bot&branch=main&name=talkless-mini-bot&builder=dockerfile&env%5BSESSION_ID%5D=your%20sessionid%20here">
<img src="https://img.shields.io/badge/DEPLOY%20NOW-black?style=for-the-badge" alt="Deploy on Koyeb">
</a>

### Steps

1. Fork the repository.
2. Sign in to Koyeb.
3. Create a new application.
4. Select GitHub.
5. Select your fork.
6. Configure the environment variables.
7. Deploy.

### Environment Variables

```env
SESSION_ID=TALKLESSMINIBOT~your_session_id_here
MODE=public
TIME_ZONE=Africa/Nairobi
DATABASE_URL=your_postgresql_url
```

For persistent storage, PostgreSQL is recommended.

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

---

# 🅵 VPS / SELF-HOSTED DEPLOYMENT

<details>
<summary><b>🖥️ TAP TO OPEN VPS GUIDE</b></summary>

<br>

### Requirements

- Ubuntu 20.04+
- Node.js 20+
- Git
- FFmpeg

### 1. Clone Repository

```bash
git clone https://github.com/clevertechn/talkless-mini-bot.git
cd talkless-mini-bot
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Create `.env`

```env
SESSION_ID=TALKLESSMINIBOT~your_session_id_here
MODE=public
TIME_ZONE=Africa/Nairobi
AUTO_LIKE_STATUS=true
AUTO_READ_STATUS=true
DATABASE_URL=
```

### 4. Install FFmpeg

#### Ubuntu / Debian

```bash
sudo apt update
sudo apt install -y ffmpeg
```

#### CentOS / RHEL

```bash
sudo yum install -y ffmpeg
```

### 5. Start the Bot

```bash
npm start
```

### 6. PM2

For 24/7 operation:

```bash
npm install -g pm2
pm2 start index.js --name talkless-mini-bot
pm2 save
pm2 startup
```

### 7. Update Bot

```bash
git pull
npm install
pm2 restart talkless-mini-bot
```

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

# 🔐 ENVIRONMENT VARIABLES

| Variable | Required | Example |
|---|---|---|
| `SESSION_ID` | ✅ Yes | `TALKLESSMINIBOT~xxxxxxxx` |
| `MODE` | ❌ No | `public` |
| `TIME_ZONE` | ❌ No | `Africa/Nairobi` |
| `AUTO_LIKE_STATUS` | ❌ No | `true` |
| `AUTO_READ_STATUS` | ❌ No | `true` |
| `DATABASE_URL` | ❌ No | PostgreSQL URL |

---

# ❗ TROUBLESHOOTING

<details>
<summary><b>🔧 COMMON ERRORS</b></summary>

### `Cannot find module`

Make sure dependencies are installed:

```bash
npm install
```

### `sharp` error

Make sure the Bot Hosting Startup Command is:

```bash
cd /home/container && npm install --no-fund --no-audit && npm install-scripts approve sharp && npm install-scripts approve better-sqlite3 && npm rebuild sharp && npm rebuild better-sqlite3 && exec node index.js
```

### `better-sqlite3` bindings error

The native module may need to be rebuilt:

```bash
npm rebuild better-sqlite3
```

The Bot Hosting Startup Command above performs this automatically.

### `Cannot find module './'`

Make sure the Startup Command ends with:

```bash
exec node index.js
```

Do not leave the startup file variable empty.

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

# 📢 UPDATES

<details>
<summary><b>📲 CLICK HERE</b></summary>

### CONTACT SUPPORT

<a href="https://clevertech.qzz.io/">
<img src="https://img.shields.io/badge/CONTACT%20SUPPORT-blue?style=for-the-badge" alt="Contact Support">
</a>

### WHATSAPP CHANNEL

<a href="https://whatsapp.com/channel/0029Vb73SRl1CYoLWtyr4u1X">
<img src="https://img.shields.io/badge/WHATSAPP%20CHANNEL-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" alt="WhatsApp Channel">
</a>

### GITHUB

<a href="https://github.com/clevertechn">
<img src="https://img.shields.io/badge/GITHUB-CLEVER%20TECH-black?style=for-the-badge&logo=github" alt="GitHub">
</a>

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

# ⭐ REPO STAR HISTORY

[![TALKLESS-MINI-BOT](https://api.star-history.com/svg?repos=clevertechn/talkless-mini-bot&type=Timeline)](#)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## ❤️ TALKLESS MINI BOT

<p align="center">
<b>Developed and maintained by Clever Techn</b>
</p><p align="center">
⭐ Star the repository if you find it useful!
</p><p align="center">
<a href="https://bot-hosting.net/?aff=clevertechn" target="_blank">
<img src="https://img.shields.io/badge/🚀%20HOST%20TALKLESS%20MINI%20BOT%2024%2F7-blue?style=for-the-badge" alt="Host TALKLESS MINI BOT">
</a>
</p>
