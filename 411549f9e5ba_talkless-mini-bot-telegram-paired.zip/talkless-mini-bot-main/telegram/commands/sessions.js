const {
    manager,
    config,
    reply,
    isOwner,
    ownerNotConfigured,
    formatDuration,
    statusIcon,
} = require("../lib");

const MAX_ROWS = 40;

module.exports = {
    name: "sessions",
    description: "Owner: list every linked WhatsApp account",
    async execute(bot, msg) {
        if (ownerNotConfigured()) {
            await reply(
                bot,
                msg,
                "⚙️ No `OWNER_ID` is configured, so this command is disabled.\n\n" +
                    "Set `OWNER_ID` in `.env` to your numeric Telegram id."
            );
            return;
        }

        if (!isOwner(msg)) {
            await reply(bot, msg, "🚫 This command is owner-only.");
            return;
        }

        const rows = await manager.getOwnerSnapshot();

        if (!rows.length) {
            await reply(bot, msg, "No accounts are linked yet.");
            return;
        }

        const shown = rows.slice(0, MAX_ROWS);
        const lines = shown.map((row, index) => {
            const who = row.telegramName ? ` (${row.telegramName})` : "";
            const uptime = row.uptimeMs ? ` · up ${formatDuration(row.uptimeMs)}` : "";
            const detail = row.detail ? `\n   _${row.detail}_` : "";
            return (
                `${index + 1}. ${statusIcon(row.status)} *+${row.number}*\n` +
                `   tg: \`${row.telegramId}\`${who} · ${row.status}${uptime}${detail}`
            );
        });

        const footer =
            rows.length > MAX_ROWS
                ? `\n\n_…showing ${MAX_ROWS} of ${rows.length}; use /kill or /stats for the rest._`
                : "";

        await reply(
            bot,
            msg,
            [
                `🗂 *Linked accounts* (${rows.length}/${config.MAX_SESSIONS})`,
                "",
                ...lines,
                footer,
            ].join("\n"),
            { parse_mode: "Markdown" }
        );
    },
};
