const { config } = require("../lib");

module.exports = {
    name: "start",
    description: "Greet the user and show a quick intro",
    async execute(bot, msg) {
        const chatId = msg.chat.id;
        const firstName = msg.from?.first_name || "there";

        const lines = [
            `👋 Hey ${firstName}, welcome to *Talkless Mini Bot*!`,
            "",
        ];

        if (config.ENABLE_WHATSAPP) {
            lines.push(
                "*Link your WhatsApp in one step:*",
                "`/pair 255712345678`",
                "_Use your own number in international format — you get an 8-character code to enter in WhatsApp._",
                "",
                "Once linked, the full command set runs on *your* WhatsApp account.",
                ""
            );
        }

        lines.push(
            "Try /help to list everything, /status to see your linked accounts."
        );

        await bot.sendMessage(chatId, lines.join("\n"), { parse_mode: "Markdown" });
    },
};
