const { manager, argsOf, reply, isOwner, ownerNotConfigured } = require("../lib");

const USAGE = [
    "🛑 *Stop a linked account*",
    "",
    "`/kill 255712345678` — stop the account, keep its session data",
    "`/kill 255712345678 wipe` — stop it and delete its session data",
    "`/kill <telegram_id>` — same, by the owner's Telegram id",
    "",
    "_Use `/sessions` to find the number or Telegram id._",
].join("\n");

module.exports = {
    name: "kill",
    description: "Owner: stop a linked WhatsApp account",
    async execute(bot, msg) {
        if (ownerNotConfigured() || !isOwner(msg)) {
            await reply(bot, msg, "🚫 This command is owner-only.");
            return;
        }

        const args = argsOf(msg);
        const target = args[0];
        if (!target) {
            await reply(bot, msg, USAGE, { parse_mode: "Markdown" });
            return;
        }

        const wipe = (args[1] || "").toLowerCase() === "wipe";

        const result = await manager.killSession({
            key: undefined,
            number: target,
            wipe,
        });

        if (!result) {
            await reply(
                bot,
                msg,
                `No linked account matches \`${target}\`.\n\nUse /sessions to see them.`,
                { parse_mode: "Markdown" }
            );
            return;
        }

        await reply(
            bot,
            msg,
            wipe
                ? `🛑 Stopped *+${result.number}* (tg \`${result.telegramId}\`) and deleted its session data.`
                : `⏸ Stopped *+${result.number}* (tg \`${result.telegramId}\`). It will not reconnect until /pair is run again.`,
            { parse_mode: "Markdown" }
        );
    },
};
