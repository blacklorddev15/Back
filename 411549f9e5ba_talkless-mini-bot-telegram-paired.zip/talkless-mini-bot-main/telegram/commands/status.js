const { manager, config, reply, formatDuration, statusIcon } = require("../lib");

module.exports = {
    name: "status",
    description: "Show your linked WhatsApp accounts and their connection state",
    async execute(bot, msg) {
        const telegramId = msg.from?.id;
        const accounts = await manager.getStatusFor(telegramId);

        if (!accounts.length) {
            await reply(
                bot,
                msg,
                "You have no linked WhatsApp accounts yet.\n\n" +
                    "Send `/pair 255712345678` (your number, international format) to link one.",
                { parse_mode: "Markdown" }
            );
            return;
        }

        const lines = accounts.map((account, index) => {
            const uptime = account.uptimeMs
                ? ` · up ${formatDuration(account.uptimeMs)}`
                : "";
            const detail = account.detail ? `\n   _${account.detail}_` : "";
            return (
                `${index + 1}. ${statusIcon(account.status)} *+${account.number}* — ${account.status}${uptime}${detail}`
            );
        });

        await reply(
            bot,
            msg,
            [
                `📋 *Your linked accounts* (${accounts.length}/${config.MAX_SESSIONS_PER_USER})`,
                "",
                ...lines,
                "",
                "_Commands run on the linked account itself, so send them from that WhatsApp number._",
                "Use /unpair to remove an account.",
            ].join("\n"),
            { parse_mode: "Markdown" }
        );
    },
};
