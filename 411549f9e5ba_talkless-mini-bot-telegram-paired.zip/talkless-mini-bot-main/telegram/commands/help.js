const { escapeMarkdown, isOwner, ownerNotConfigured, config } = require("../lib");

const GROUPS = [
    {
        title: "🔗 WhatsApp linking",
        names: ["pair", "status", "unpair"],
    },
    {
        title: "🛠 General",
        names: ["start", "help", "ping", "owner"],
    },
    {
        title: "👑 Owner",
        names: ["sessions", "kill", "stats"],
    },
];

module.exports = {
    name: "help",
    description: "List available commands",
    async execute(bot, msg, commands) {
        const owner = !ownerNotConfigured() && isOwner(msg);
        const listed = new Set();

        const sections = [];
        for (const group of GROUPS) {
            const entries = group.names
                .map((name) => commands.get(name))
                .filter((cmd) => cmd && (group.title !== "👑 Owner" || owner));

            if (!entries.length) continue;

            entries.forEach((cmd) => listed.add(cmd.name));
            sections.push(
                `*${group.title}*\n` +
                    entries
                        .map(
                            (cmd) =>
                                `/${cmd.name} — ${escapeMarkdown(cmd.description)}`
                        )
                        .join("\n")
            );
        }

        const leftovers = [...commands.values()].filter(
            (cmd) => !listed.has(cmd.name)
        );
        if (leftovers.length) {
            sections.push(
                `*Other*\n` +
                    leftovers
                        .map(
                            (cmd) =>
                                `/​${cmd.name} — ${escapeMarkdown(cmd.description)}`
                        )
                        .join("\n")
            );
        }

        const footer = config.ENABLE_WHATSAPP
            ? "\n\n_WhatsApp commands (the full plugin set) run on the linked account itself, " +
              "not here. Send them from the WhatsApp number you linked._"
            : "\n\n_WhatsApp linking is disabled on this deployment._";

        await bot.sendMessage(
            msg.chat.id,
            `📖 *Available commands*\n\n${sections.join("\n\n")}${footer}`,
            { parse_mode: "Markdown" }
        );
    },
};
