const {
    manager,
    config,
    argsOf,
    reply,
    formatDuration,
    PAIR_CODE_HINT,
} = require("../lib");

const USAGE = [
    "🔗 *Link a WhatsApp number*",
    "",
    "Send the number in international format, no `+` and no spaces:",
    "",
    "`/pair 255712345678`",
    "",
    "_The bot returns an 8-character pairing code. Open WhatsApp on that phone → " +
        "Settings → Linked devices → Link a device → Link with phone number instead, " +
        "then type the code._",
].join("\n");

const ERROR_TITLES = {
    INVALID_NUMBER: "⚠️ That number does not look right",
    COOLDOWN: "⏳ Slow down",
    RATE_LIMITED: "⏳ Too many attempts",
    PER_USER_LIMIT: "🚫 Account limit reached",
    NUMBER_TAKEN: "🚫 Number already linked",
    CAPACITY: "🚧 Bot at capacity",
    BUSY: "⏳ Bot is busy",
    MEMORY: "🚧 Bot under memory pressure",
    NOT_READY: "⏳ Still starting",
    PAIR_FAILED: "❌ Pairing failed",
};

module.exports = {
    name: "pair",
    description: "Link your WhatsApp number and get a pairing code",
    async execute(bot, msg) {
        const args = argsOf(msg);
        const raw = args.join("").trim();

        if (!raw) {
            await reply(bot, msg, USAGE, { parse_mode: "Markdown" });
            return;
        }

        if (!config.ENABLE_WHATSAPP) {
            await reply(
                bot,
                msg,
                "⚠️ WhatsApp linking is switched off on this deployment " +
                    "(`ENABLE_WHATSAPP=false`)."
            );
            return;
        }

        const shown = raw.replace(/[^\d]/g, "") || raw;
        const placeholder = await reply(
            bot,
            msg,
            `⏳ Requesting a pairing code for *+${shown}*…\n\n_This takes up to 30 seconds._`,
            { parse_mode: "Markdown" }
        );

        try {
            await bot.sendChatAction(msg.chat.id, "typing");
        } catch (_) {}

        try {
            const { number, code } = await manager.pair({
                telegramId: msg.from?.id,
                telegramUsername: msg.from?.username,
                telegramName: [msg.from?.first_name, msg.from?.last_name]
                    .filter(Boolean)
                    .join(" "),
                number: raw,
            });

            const text =
                `🔑 *Pairing code for +${number}*\n\n` +
                `\`${code}\`\n\n` +
                `${PAIR_CODE_HINT}\n\n` +
                `⏱ Enter it within ~${formatDuration(config.PAIR_STALE_SECONDS * 1000)} or the code expires.\n` +
                `✅ You will get a confirmation here as soon as the account goes online.\n\n` +
                `Check progress any time with /status`;

            if (placeholder) {
                await bot
                    .editMessageText(text, {
                        chat_id: msg.chat.id,
                        message_id: placeholder.message_id,
                        parse_mode: "Markdown",
                    })
                    .catch(async () => {
                        await reply(bot, msg, text, { parse_mode: "Markdown" });
                    });
            } else {
                await reply(bot, msg, text, { parse_mode: "Markdown" });
            }
        } catch (error) {
            // Only PairError messages are written for end users; anything else
            // is logged server-side and reported generically.
            const known = Boolean(error.code && ERROR_TITLES[error.code]);
            const title = known ? ERROR_TITLES[error.code] : "❌ Pairing failed";
            const body = known
                ? error.message
                : "Something went wrong on the bot's side. Please try again in a moment.";

            if (!known) console.error("Unexpected /pair failure:", error);

            const text =
                `${title}\n\n${body}\n\n` +
                `Send /pair with a number in international format, for example:\n` +
                "`/pair 255712345678`";

            if (placeholder) {
                await bot
                    .editMessageText(text, {
                        chat_id: msg.chat.id,
                        message_id: placeholder.message_id,
                        parse_mode: "Markdown",
                    })
                    .catch(async () => {
                        await reply(bot, msg, text, { parse_mode: "Markdown" });
                    });
            } else {
                await reply(bot, msg, text, { parse_mode: "Markdown" });
            }
        }
    },
};
