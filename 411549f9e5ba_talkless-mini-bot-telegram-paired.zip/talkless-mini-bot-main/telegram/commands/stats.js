const {
    manager,
    reply,
    isOwner,
    ownerNotConfigured,
    formatDuration,
} = require("../lib");

module.exports = {
    name: "stats",
    description: "Owner: bot health, account counts and command plugin status",
    async execute(bot, msg) {
        if (ownerNotConfigured() || !isOwner(msg)) {
            await reply(bot, msg, "🚫 This command is owner-only.");
            return;
        }

        const stats = await manager.getStats();
        const perAccount =
            stats.accounts.avgRssMbPerAccount === null
                ? "not available yet"
                : `${stats.accounts.avgRssMbPerAccount} MB`;
        const statusLines = Object.entries(stats.accounts.byStatus)
            .map(([status, count]) => `   • ${status}: ${count}`)
            .join("\n");

        const pluginReport = stats.commands.plugins;
        const failedLines = pluginReport?.failed?.length
            ? pluginReport.failed
                  .slice(0, 15)
                  .map((f) => `   ✗ ${f.file}: ${f.error}`)
                  .join("\n")
            : "   _none_";

        const text = [
            "📊 *Bot status*",
            "",
            "*Accounts*",
            `   registered: ${stats.accounts.registered}`,
            `   live: ${stats.accounts.live}`,
            `   pairing in flight: ${stats.accounts.pending}`,
            `   avg RSS per account (since start): ${perAccount}`,
            statusLines || "   _no rows_",
            "",
            "*Limits*",
            `   max accounts: ${stats.limits.maxSessions}`,
            `   per user: ${stats.limits.maxSessionsPerUser}`,
            `   concurrent pairings: ${stats.limits.pendingPairLimit}`,
            `   memory guard: ${stats.limits.maxRssMb} MB`,
            "",
            "*WhatsApp commands*",
            `   registered: ${stats.commands.total}`,
            `   body handlers: ${stats.commands.body}`,
            `   plugin files loaded: ${pluginReport?.loaded?.length ?? 0}`,
            "   failed plugins:",
            failedLines,
            "",
            "*Process*",
            `   uptime: ${formatDuration(stats.process.uptimeSeconds * 1000)}`,
            `   rss: ${stats.process.rssMb} MB`,
            `   heap used: ${stats.process.heapUsedMb} MB`,
        ].join("\n");

        await reply(bot, msg, text, { parse_mode: "Markdown" });
    },
};
