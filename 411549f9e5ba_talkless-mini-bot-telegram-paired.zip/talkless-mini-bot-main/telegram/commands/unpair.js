const {
    manager,
    argsOf,
    reply,
    statusIcon,
    isOwner,
} = require("../lib");

module.exports = {
    name: "unpair",
    description: "Unlink one of your WhatsApp accounts (or all of them)",
    async execute(bot, msg) {
        const target = argsOf(msg)[0];
        const accounts = await manager.getStatusFor(msg.from?.id);

        if (!target) {
            const list = accounts.length
                ? accounts
                      .map(
                          (account) =>
                              `• ${statusIcon(account.status)} +${account.number}`
                      )
                      .join("\n")
                : "_none linked_";

            await reply(
                bot,
                msg,
                [
                    "🔓 *Unlink a WhatsApp account*",
                    "",
                    "Your accounts:",
                    list,
                    "",
                    "Send one of:",
                    "`/unpair 255712345678` — unlink that number",
                    "`/unpair all` — unlink everything you linked",
                    "",
                    "_The device is logged out on WhatsApp's side and the local session data is deleted._",
                ].join("\n"),
                { parse_mode: "Markdown" }
            );
            return;
        }

        if (String(target).toLowerCase() === "all") {
            const result = await manager.unpair({
                telegramId: msg.from?.id,
                target: "all",
                isOwner: isOwner(msg),
            });

            await reply(
                bot,
                msg,
                result.removed.length
                    ? `🔓 Unlinked ${result.message}.`
                    : "You have no linked accounts to remove."
            );
            return;
        }

        const result = await manager.unpair({
            telegramId: msg.from?.id,
            target,
            isOwner: isOwner(msg),
        });

        await reply(
            bot,
            msg,
            result.removed.length
                ? `🔓 Unlinked ${result.message}. The session data was deleted.`
                : `No linked account found for \`${target}\`.\n\nCheck /status for your numbers.`,
            { parse_mode: "Markdown" }
        );
    },
};
