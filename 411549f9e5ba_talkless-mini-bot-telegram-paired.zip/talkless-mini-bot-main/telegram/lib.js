/**
 * Shared helpers for the Telegram command layer.
 *
 * This lives outside ./commands so the command loader does not treat it as a
 * command module.
 */
const config = require("../config");

const manager = require("../whatsapp/manager");

function isOwner(msg) {
    const ownerId = String(config.OWNER_ID || "").trim();
    if (!ownerId) return false;
    return String(msg.from?.id || "") === ownerId;
}

function ownerNotConfigured() {
    return !String(config.OWNER_ID || "").trim();
}

/** Telegram Markdown (legacy parse_mode) only needs these escaped. */
function escapeMarkdown(text) {
    return String(text ?? "").replace(/([_*`\[\]])/g, "\\$1");
}

/** Splits "@user 123 extra" style argument strings into tokens. */
function argsOf(msg) {
    const text = msg.text || "";
    return text.trim().split(/\s+/).slice(1);
}

function formatDuration(ms) {
    if (!ms || ms < 1000) return "0s";
    const totalSeconds = Math.floor(ms / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    if (days) return `${days}d ${hours}h`;
    if (hours) return `${hours}h ${minutes}m`;
    if (minutes) return `${minutes}m ${seconds}s`;
    return `${seconds}s`;
}

const STATUS_ICON = {
    active: "🟢",
    pairing: "🔑",
    pending: "🔑",
    connecting: "🟡",
    offline: "⚪️",
    logged_out: "🔴",
    failed: "❌",
    idle: "⚪️",
};

function statusIcon(status) {
    return STATUS_ICON[status] || "⚪️";
}

/** Best-effort edit that never throws (Telegram dislikes no-op edits). */
async function safeEdit(bot, chatId, messageId, text, options = {}) {
    try {
        await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: messageId,
            ...options,
        });
    } catch (error) {
        console.error("Edit failed:", error.message);
    }
}

/** Sends or edits, falling back to a fresh message when the edit is rejected. */
async function reply(bot, msg, text, options = {}) {
    try {
        return await bot.sendMessage(msg.chat.id, text, {
            reply_to_message_id: msg.message_id,
            ...options,
        });
    } catch (error) {
        console.error("Send failed:", error.message);
        try {
            return await bot.sendMessage(msg.chat.id, text, options);
        } catch (_) {
            return null;
        }
    }
}

const PAIR_CODE_HINT =
    "Open WhatsApp on the phone for that number:\n" +
    "*Settings → Linked devices → Link a device → Link with phone number instead*,\n" +
    "then enter the code above.";

module.exports = {
    manager,
    config,
    isOwner,
    ownerNotConfigured,
    escapeMarkdown,
    argsOf,
    formatDuration,
    statusIcon,
    safeEdit,
    reply,
    PAIR_CODE_HINT,
};
