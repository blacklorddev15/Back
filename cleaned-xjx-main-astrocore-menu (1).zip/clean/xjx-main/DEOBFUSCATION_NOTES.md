# Cleaned source version

This copy was recovered from `967d9498fcb6_xjx-main.zip` using WebCrack deobfuscation/unminification followed by a scope-aware Babel AST rename pass.

- All 355 JavaScript files were processed successfully.
- All 355 JavaScript files pass `node --check` syntax validation.
- Obfuscator-generated `_0x...` bindings were renamed with unique, reference-safe identifiers.
- Non-JavaScript assets and project configuration were preserved.
- The stale `npm run build` entry referencing a missing `obfuscator.js` was removed.
- The `encrypt` command and its `js-confuser` dependency were retained because they are runtime features.

The names are automatically recovered and may be generic (`valueN`, `resultN`, `errorN`) where the original meaning could not be inferred safely. Review credentials, network endpoints, database settings, and bot permissions before running it.
