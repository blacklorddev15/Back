require("./utils/shutdown").enforceShutdownChain();
process.on("warning", value1 => {
  const value2 = String(value1?.message || "");
  if (value1?.code === "SECURITY WARNING" || value2.includes("SECURITY WARNING") || value2.includes("The SSL modes") || value2.includes("pg-connection-string")) {
    return;
  }
  console.warn(value1);
});
require("dotenv").config();
const FFMPEG_PATH = require("./utils/ffmpegPath");
require("fluent-ffmpeg").setFfmpegPath(FFMPEG_PATH());
const {
  ensureFfmpegRuntime
} = require("./utils/ffmpegRuntime");
if (FFMPEG_PATH() === "ffmpeg") {
  ensureFfmpegRuntime();
}
if (FFMPEG_PATH() === "ffmpeg") {
  console.log("[ BOOT ] WARNING: no ffmpeg binary found (PATH, /usr/bin, /usr/local/bin, data/ffmpeg, ffmpeg-static). Sticker/media conversion may fail until the runtime binary finishes downloading.");
} else {
  console.log("[ BOOT ] ffmpeg resolved: " + FFMPEG_PATH());
}
if (process.env.JUNE_START_TIME) {
  const startTime = parseInt(process.env.JUNE_START_TIME);
  process.uptime = () => (Date.now() - startTime) / 1000;
}
const originalWrite = process.stdout.write;
const originalWriteError = process.stderr.write;
const originalLog = console.log;
let suppressSignalStackUntil = 0;
const SIGNAL_NOISE_PATTERNS = ["closing session: sessionentry", "sessionentry {", "failed to decrypt message with any known session", "session error: error: bad mac", "bad mac error: bad mac", "decrypted message with closed session", "incoming prekey bundle"];
function outputText(value3) {
  if (typeof value3 === "string") {
    return value3;
  }
  if (Buffer.isBuffer(value3)) {
    return value3.toString("utf8");
  }
  try {
    return String(value3);
  } catch (error4) {
    return "";
  }
}
function shouldSuppressSignalNoise(value5) {
  const value6 = outputText(value5);
  const value7 = value6.toLowerCase();
  const value8 = SIGNAL_NOISE_PATTERNS.some(value9 => value7.includes(value9));
  if (value8) {
    suppressSignalStackUntil = Date.now() + 2500;
    return true;
  }
  const value10 = value7.includes("/libsignal/") || value7.includes("session_cipher.js") || value7.includes("queue_job.js") || /^\s*at\s/.test(value6) || value7.trim() === "...";
  return Date.now() < suppressSignalStackUntil && value10;
}
function acknowledgeSuppressedWrite(value11, value12) {
  const value13 = typeof value11 === "function" ? value11 : value12;
  if (typeof value13 === "function") {
    try {
      value13();
    } catch (error14) {}
  }
  return true;
}
process.stdout.write = function (value15, value16, value17) {
  if (shouldSuppressSignalNoise(value15)) {
    return acknowledgeSuppressedWrite(value16, value17);
  }
  return originalWrite.apply(this, arguments);
};
process.stderr.write = function (value18, value19, value20) {
  if (shouldSuppressSignalNoise(value18)) {
    return acknowledgeSuppressedWrite(value19, value20);
  }
  return originalWriteError.apply(this, arguments);
};
console.log = function (value21, ...value22) {
  if (shouldSuppressSignalNoise(value21)) {
    return;
  }
  originalLog.apply(console, [value21, ...value22]);
};
const fs = require("fs");
const BOOT_DEBUG = /^(1|true|yes|on)$/i.test(String(process.env.DEBUG || ""));
const chalk = require("chalk");
const path = require("path");
const os = require("os");
const crypto = require("crypto");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  jidNormalizedUser,
  makeCacheableSignalKeyStore,
  delay
} = require("@whiskeysockets/baileys");
const NodeCache = require("node-cache");
const pino = require("pino");
const readline = require("readline");
const {
  rmSync
} = require("fs");
const moment = require("moment-timezone");
const lolcatjs = require("lolcatjs");
const {
  normalizeJidWithLid
} = require("./utils/jidHelper");
const {
  runFileSweep,
  startScheduledCleanups,
  stopScheduledCleanups
} = require("./utils/cleanup");
const {
  createMessageStore
} = require("./utils/messageStore");
const {
  applyFont
} = require("./utils/fontConverter");
const {
  atomicWriteFile,
  createDiskManager
} = require("./utils/juneDb/runtimeProtection");
const juneDatabase = require("./database");
const pgAdapter = require("./utils/juneDb/pgAdapter");
const mongoAdapter = require("./utils/juneDb/mongoAdapter");
const replayDrain = require("./utils/juneDb/replayDrain");
const {
  useSQLiteAuthState,
  getSQLiteAuthStats,
  validateSQLiteAuth,
  migrateFilesToSQLite,
  finalizePendingFileMigration,
  cleanupSessionQuarantines,
  getSessionIdFingerprint,
  setSessionIdFingerprint,
  getSessionIdRevokedFingerprint,
  setSessionIdRevokedFingerprint,
  getAuthSource,
  setAuthSource,
  isAuthConnectionVerified,
  setAuthConnectionVerified,
  isLocallyVerifiedAuth,
  hasVerifiedSQLiteAuth,
  clearSQLiteAuth,
  invalidateSQLiteAuth
} = require("./utils/juneDb/auth-state");
const sessionServer = require("./utils/juneDb/sessionServer");
const {
  wrapSockSanitized
} = require("./utils/sanitizeUserText");
process.env.PUPPETEER_SKIP_DOWNLOAD = "true";
process.env.PUPPETEER_SKIP_CHROMIUM_DOWNLOAD = "true";
function log(value23, value24 = "white", value25 = false) {
  require("./utils/consoleTheme").log(value23, value24, value25);
}
global.log = log;
const {
  maskNumber,
  maskBotId
} = require("./utils/redact");
const STARTUP_REPORT_WIDTH = 62;
function startupPlain(value26) {
  return String(value26 ?? "").replace(/\r?\n/g, " ").replace(/\x1B\[[0-?]*[ -/]*[@-~]/g, "");
}
function startupFit(value27, value28) {
  const value29 = startupPlain(value27);
  if (value29.length > value28) {
    return value29.slice(0, Math.max(0, value28 - 1)) + "…";
  } else {
    return value29.padEnd(value28);
  }
}
function startupStatusIcon(value30) {
  const value31 = String(value30 || "").toLowerCase();
  if (["ok", "ready", "connected", "active", "online", "enabled", "passed"].includes(value31)) {
    return chalk.green("✓");
  }
  if (["warn", "warning", "degraded", "fallback", "connecting"].includes(value31)) {
    return chalk.yellow("!");
  }
  if (["off", "disabled", "not_set", "unavailable", "error", "failed"].includes(value31)) {
    return chalk.red("×");
  }
  return chalk.cyan("•");
}
function startupStatusText(value32, value33) {
  const value34 = String(value32 || "").toLowerCase();
  const value35 = value33 || value32 || "unknown";
  if (["ok", "ready", "connected", "active", "online", "enabled", "passed"].includes(value34)) {
    return chalk.green(value35);
  }
  if (["warn", "warning", "degraded", "fallback", "connecting"].includes(value34)) {
    return chalk.yellow(value35);
  }
  if (["off", "disabled", "not_set", "unavailable", "error", "failed"].includes(value34)) {
    return chalk.red(value35);
  }
  return chalk.cyan(value35);
}
function startupRow(value36, value37, value38) {
  const value39 = startupFit(value36, 18);
  const value40 = value38 ? startupStatusIcon(value38) + " " + startupStatusText(value38, value37) : startupPlain(value37);
  return "│  " + chalk.gray(value39) + " : " + value40;
}
function startupHeading(value41) {
  return "│  " + chalk.cyan.bold("◆ " + value41);
}
function startupSeparator() {
  return "│  " + chalk.gray("─".repeat(STARTUP_REPORT_WIDTH - 4));
}
function startupToggleValue(value42) {
  if (value42) {
    return chalk.green("•ON");
  } else {
    return chalk.red("•OFF");
  }
}
function startupTogglePair(value43, value44, value45, value46) {
  const value47 = chalk.gray(startupFit(value43, 12)) + " " + startupToggleValue(value44);
  const value48 = chalk.gray(startupFit(value45, 12)) + " " + startupToggleValue(value46);
  return "│  " + value47 + " " + chalk.gray("│") + " " + value48;
}
function normalizeStartupPostgres(value49 = {}) {
  if (value49.available || value49.ready) {
    return {
      ...value49,
      status: "connected",
      label: "connected"
    };
  }
  return {
    ...value49,
    status: "disabled",
    label: "not set"
  };
}
function getStartupToggleState() {
  const value50 = juneDatabase;
  const value51 = value50.loadSettings?.() || {};
  const value52 = (() => {
    try {
      return require("./utils/presenceSettings").getModes();
    } catch (error53) {
      return {
        pm: "off",
        group: "off"
      };
    }
  })();
  const value54 = value52.pm === "typing" || value52.group === "typing";
  const value55 = value52.pm === "recording" || value52.group === "recording" || value52.pm === "recordtype" || value52.group === "recordtype";
  const value56 = value52.pm === "recordtype" || value52.group === "recordtype";
  const value57 = (() => {
    try {
      return Boolean(require("./utils/autoReact").load().enabled);
    } catch (error58) {
      return Boolean(value50.getBotSetting?.("autoReact") ?? juneDatabase.getBotSetting("autoReact"));
    }
  })();
  const value59 = Boolean(value50.getAutoDownloadStatusSettings().enabled);
  const value60 = value50.getAntideleteMode();
  const value61 = value50.isAntideleteStatusEnabled();
  return {
    autoStatusView: Boolean(value51.enabled),
    autoStatusReact: Boolean(value51.react),
    autoTyping: value54,
    autoRecording: value55,
    autoRecordType: value56,
    autoDownload: value59,
    alwaysOnline: Boolean(value50.getBotSetting?.("alwaysOnline")),
    antideleteStatus: value61,
    autoReact: value57,
    antiDelete: value60 !== "off"
  };
}
function printStartupReport(value62 = {}) {
  const value63 = value62.time || new Date().toLocaleTimeString();
  const value64 = value62.platform || os.platform();
  const value65 = String(value62.mode || "public").toUpperCase();
  const value66 = value62.commandCount ?? "—";
  const value67 = value62.databaseInfo || getExternalDatabaseStatus();
  let value68 = [startupHeading("DATABASE"), startupRow("SQLite", value62.sqliteLabel || "ready", value62.sqliteStatus || "ready"), startupRow("Driver", value62.sqliteDriver || "sql.js-fallback"), startupRow("Schema", value62.schemaVersion ? "v" + value62.schemaVersion : "—"), startupRow("Integrity", value62.integrityLabel || "passed", value62.integrityStatus || "passed")];
  const value69 = (value67.databases || []).filter(value70 => value70.configured);
  value68.push(startupSeparator());
  value68.push(startupHeading(value69.length > 0 ? "EXTERNAL DATABASE" : "EXTERNAL DATABASES"));
  if (value69.length === 0) {
    for (const value71 of value67.databases || []) {
      value68.push(startupRow(value71.name, "not configured", "not_set"));
    }
  } else {
    for (const value72 of value69) {
      value68.push(startupRow(value72.name, value72.connected ? "connected" : "unavailable — SQLite fallback", value72.connected ? "connected" : "warning"));
    }
  }
  const value73 = ["┌" + "─".repeat(46) + "┐", "┃" + chalk.cyan("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓").padEnd(9) + "┃", "┃" + chalk.white.bold("        🤖 JUNE X (•ˇ_ˇ•) ULTRA STARTING...").padEnd(65) + "┃", "┃" + chalk.cyan("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛").padEnd(9) + "┃", "├" + "─".repeat(46) + "┤", startupHeading("SYSTEM"), startupRow("Platform", value64), startupRow("Node.js", value62.nodeVersion || process.version), startupRow("Time", value63), startupRow("Startup", value62.startupTime || "—"), startupSeparator(), startupHeading("CONFIGURATION"), startupRow("Prefix", value62.prefix ?? "."), startupRow("Mode", value65, "active"), startupRow("Owner", value62.owner || "configured"), startupRow("Commands", value66 + " loaded" + (value62.aliasCount ? " (+" + value62.aliasCount + " aliases)" : ""), "ready"), startupSeparator(), ...value68, startupSeparator(), startupHeading("TOGGLES"), startupTogglePair("Status View", value62.toggles?.autoStatusView, "Status React", value62.toggles?.autoStatusReact), startupTogglePair("Typing", value62.toggles?.autoTyping, "Recording", value62.toggles?.autoRecording), startupTogglePair("Record+Type", value62.toggles?.autoRecordType, "Auto-Save", value62.toggles?.autoDownload), startupTogglePair("Auto-React", value62.toggles?.autoReact, "Always-On", value62.toggles?.alwaysOnline), startupTogglePair("Anti-Delete", value62.toggles?.antiDelete, "Anti-Status", value62.toggles?.antideleteStatus), startupSeparator(), startupHeading("RUNTIME PROTECTION"), startupRow("Disk manager", value62.diskManagerLabel || "active", value62.diskManagerStatus || "active"), startupRow("Atomic writes", value62.atomicWritesLabel || "enabled", value62.atomicWritesStatus || "enabled"), startupRow("Cache limits", value62.cacheLabel || "enabled", value62.cacheStatus || "enabled"), startupRow("Telemetry", value62.telemetryLabel || "enabled", value62.telemetryStatus || "enabled"), startupRow("Shutdown", value62.shutdownLabel || "protected", value62.shutdownStatus || "active"), startupSeparator(), startupHeading("AUTHENTICATION"), startupRow("Session", value62.sessionLabel || "restored", value62.sessionStatus || "ready"), startupRow("Auth source", value62.authSource || "SQLite"), startupRow("Signal keys", value62.signalKeysLabel || "verified", value62.signalKeysStatus || "ready"), startupRow("Session Srv", value62.sessionServerLabel || "not set", value62.sessionServerStatus || "off"), startupSeparator(), startupHeading("CONNECTION"), startupRow("WhatsApp", value62.whatsappLabel || "connecting", value62.whatsappStatus || "connecting"), startupRow("Account", value62.accountLabel || "hidden", value62.accountStatus), startupRow("Group join", value62.groupJoinLabel || "not set", value62.groupJoinStatus), "│  " + chalk.gray("─".repeat(45)), "│  " + chalk.gray.bold("(•ˇ_ˇ•)  JUNE SYSTEM REPORT SUMMARY   (•ˇ_ˇ•)"), "│  " + chalk.gray("─".repeat(45)), "┗" + "━".repeat(46) + "┛"];
  console.log(value73.join("\n"));
  const value74 = (value67.databases || []).filter(value75 => value75.configured);
  const value76 = value74.filter(value77 => value77.connected);
  if (value76.length > 0) {
    log("[ DATABASE ] External database connected: " + value76.map(value78 => value78.name).join(", "), "green");
  }
  if (value74.some(value79 => !value79.connected)) {
    log("[ DATABASE ] A configured external database is unavailable; using SQLite safely.", "yellow");
  }
  if (value74.length === 0) {
    log("[ DATABASE ] No external database configured (using SQLite only)", "cyan");
  }
}
global.isBotConnected = false;
global.connectDebounceTimeout = null;
global.errorRetryCount = 0;
global.isReconnecting = false;
global._consecutive500Count = 0;
global._conflictCount = 0;
global._lastConflictLogTime = 0;
global._suppressedConflictCount = 0;
global._conflictSummaryTimer = null;
global._reconnectTimer = null;
global._shutdownRequested = false;
global.startupReportPrinted = false;
global.startupStartedAt = process.env.JUNE_START_TIME ? parseInt(process.env.JUNE_START_TIME) : Date.now();
global._activeIntervals = [];
global.botState = "disconnected";
global.currentSock = null;
global.connectedAt = null;
global.__CORE__ = __dirname;
global.__ROOT__ = __dirname;
async function applyPersistedRuntimeSettings() {
  try {
    await juneDatabase.ready;
    const value80 = juneDatabase;
    try {
      const value81 = require("./utils/presenceSettings").getModes();
      juneDatabase.setBotSetting("autoTyping", value81.pm === "typing" || value81.group === "typing");
      juneDatabase.setBotSetting("autoRecording", value81.pm === "recording" || value81.group === "recording" || value81.pm === "recordtype" || value81.group === "recordtype");
      juneDatabase.setBotSetting("autoRecordType", value81.pm === "recordtype" || value81.group === "recordtype");
    } catch (error82) {}
  } catch (error83) {
    log("[ SETTINGS ] Could not load runtime settings: " + error83.message, "yellow");
  }
}
let handler = null;
const {
  saveSession,
  getSession,
  clearSession
} = juneDatabase;
const sessionDir = path.join(__dirname, juneDatabase.SESSION_NAME || "session");
const credsPath = path.join(sessionDir, "creds.json");
const envPath = path.join(process.cwd(), ".env");
if (!fs.existsSync(envPath)) {
  const defaultEnv = ["# June Ultra — Environment Variables", "# Official session mechanism: pair at " + sessionServer.getServerUrl() + "/pair", "# and paste your JUNE-X~ Session ID here.", "SESSION_ID=", "", "# Optional: override bot port (default 5000)", "# PORT=5000"].join("\n");
  atomicWriteFile(envPath, defaultEnv, "utf8");
  log("[ .env ] No .env file found — created with default template.", "green");
}
function readSessionIDFromEnv() {
  try {
    if (!fs.existsSync(envPath)) {
      return "";
    }
    const value84 = fs.readFileSync(envPath, "utf8").split("\n");
    for (const value85 of value84) {
      const value86 = value85.trim();
      if (value86.startsWith("#") || !value86.startsWith("SESSION_ID=")) {
        continue;
      }
      const value87 = value86.slice("SESSION_ID=".length).trim();
      return value87;
    }
  } catch (error88) {
    log("[ .env ] Failed to read SESSION_ID: " + error88.message, "red", true);
  }
  return "";
}
const _rawSessionID = readSessionIDFromEnv();
if (_rawSessionID) {
  process.env.SESSION_ID = _rawSessionID;
}
function getPersistedSessionErrorState() {
  try {
    return juneDatabase.getSessionErrorState();
  } catch (error89) {
    log("Error loading session retry state: " + error89.message, "red", true);
    return {
      count: 0,
      last_error_timestamp: 0
    };
  }
}
function setPersistedSessionErrorState(value90) {
  try {
    return juneDatabase.setSessionErrorState(value90);
  } catch (error91) {
    log("Error saving session retry state: " + error91.message, "red", true);
    return {
      count: 0,
      last_error_timestamp: 0
    };
  }
}
function clearPersistedSessionErrorState() {
  try {
    juneDatabase.clearSessionErrorState();
    return true;
  } catch (error92) {
    log("Failed to clear session retry state: " + error92.message, "red", true);
    return false;
  }
}
function clearSessionFiles() {
  try {
    log("[ CLEARING ] session folder...", "blue");
    if (fs.existsSync(sessionDir)) {
      const value93 = sessionDir + ".quarantine-" + Date.now();
      try {
        fs.renameSync(sessionDir, value93);
        log("[ SESSION ] Previous auth preserved at " + path.basename(value93) + ".", "yellow");
      } catch (error94) {
        log("[ SESSION ] Could not quarantine old auth: " + error94.message, "yellow");
        rmSync(sessionDir, {
          recursive: true,
          force: true
        });
      }
    }
    juneDatabase.clearStoredLoginMethod();
    clearPersistedSessionErrorState();
    global.errorRetryCount = 0;
    clearSession();
    clearSQLiteAuth(juneDatabase._db, "session-cleared");
    juneDatabase.clearRemoteAuthState();
    clearSessionIdFingerprint();
    juneDatabase.markDatabaseDirty("session-cleared");
    log("[ SESSION ] files cleared successfully.", "green");
  } catch (error95) {
    log("Failed to clear session files: " + error95.message, "red", true);
  }
}
let diskManager = null;
function runEmergencyCleanup() {
  try {
    juneDatabase.pruneAntideleteData?.();
  } catch (error96) {}
  try {
    runFileSweep(null);
  } catch (error97) {}
  try {
    cleanupExpiredSessionQuarantines("low-disk cleanup");
  } catch (error98) {}
  try {
    Promise.resolve(juneDatabase.flushBackup?.()).catch(() => {});
  } catch (error99) {}
}
diskManager = createDiskManager({
  root: __dirname,
  cleanup: ({
    aggressive: value100
  }) => {
    runEmergencyCleanup();
    log("[ DISK ] Low storage detected; " + (value100 ? "emergency " : "") + "cleanup completed.", "yellow");
  }
});
global.diskManager = diskManager;
const rl = process.stdin.isTTY ? readline.createInterface({
  input: process.stdin,
  output: process.stdout
}) : null;
const question = value101 => rl ? new Promise(value102 => rl.question(value101, value102)) : Promise.resolve("");
async function saveLoginMethod(value103) {
  return juneDatabase.setStoredLoginMethod(value103);
}
async function getLastLoginMethod() {
  return juneDatabase.getStoredLoginMethod();
}
function clearLoginMethod() {
  return juneDatabase.clearStoredLoginMethod();
}
function sessionExists() {
  return fs.existsSync(credsPath);
}
function fingerprintSessionId(value104) {
  return crypto.createHash("sha256").update(String(value104)).digest("hex");
}
function hasUsableFileSession() {
  if (!sessionExists()) {
    return false;
  }
  try {
    const value105 = JSON.parse(fs.readFileSync(credsPath, "utf8"));
    return !!value105 && typeof value105 === "object" && (!!value105.noiseKey || !!value105.signedIdentityKey || !!value105.registrationId || value105.registered === true);
  } catch (error106) {
    return false;
  }
}
function rememberSessionIdFingerprint(value107) {
  if (!value107) {
    return false;
  }
  setSessionIdFingerprint(juneDatabase._db, value107);
  const value108 = getSessionIdFingerprint(juneDatabase._db);
  if (value108 !== value107) {
    log("[ AUTH META ] SESSION_ID fingerprint could not be verified in SQLite.", "red", true);
    return false;
  }
  juneDatabase.markDatabaseDirty("session-id-fingerprint");
  return true;
}
function clearSessionIdFingerprint() {
  setSessionIdFingerprint(juneDatabase._db, null);
  juneDatabase.markDatabaseDirty("session-id-fingerprint-cleared");
}
function markSessionIdFingerprintRevoked(value109) {
  if (!value109) {
    return;
  }
  setSessionIdRevokedFingerprint(juneDatabase._db, value109);
  juneDatabase.markDatabaseDirty("session-id-revoked");
}
function clearRevokedSessionIdFingerprint() {
  setSessionIdRevokedFingerprint(juneDatabase._db, null);
  juneDatabase.markDatabaseDirty("session-id-revocation-cleared");
}
function cleanupExpiredSessionQuarantines(value110 = "startup") {
  const value111 = cleanupSessionQuarantines(sessionDir);
  if (value111.removed.length > 0) {
    const value112 = [];
    if (value111.removedByRetention) {
      value112.push(value111.removedByRetention + " expired");
    }
    if (value111.removedByLimit) {
      value112.push(value111.removedByLimit + " over limit");
    }
    log("[ SESSION ] Removed " + value111.removed.length + " quarantine(s) during " + value110 + (value112.length ? " (" + value112.join(", ") + ")" : "") + ".", "yellow");
  }
  return value111;
}
function quarantineCurrentSessionForReplacement() {
  if (!fs.existsSync(sessionDir)) {
    return null;
  }
  try {
    const value113 = fs.readdirSync(sessionDir);
    if (value113.length === 0) {
      fs.rmSync(sessionDir, {
        recursive: true,
        force: true
      });
      return null;
    }
    const value114 = sessionDir + ".quarantine-" + Date.now();
    fs.renameSync(sessionDir, value114);
    return value114;
  } catch (error115) {
    throw new Error("Could not preserve the current session directory: " + error115.message);
  }
}
const SESSION_ID_PREFIX_RE = /^june-x~/i;
const LEGACY_SESSION_PREFIXES = ["JUNE-MD:~", "Ultra-X:~", "June-Ultra:~", "June::~", "ultra-x:~", "June-X:~"];
async function checkAndHandleSessionFormat() {
  const value116 = process.env.SESSION_ID;
  if (value116 && value116.trim() !== "") {
    if (LEGACY_SESSION_PREFIXES.some(value117 => value116.trim().startsWith(value117))) {
      log(chalk.black.bgRedBright("[ERROR]: The raw-session SESSION_ID format was RETIRED."), "white");
      log(chalk.white.bgRedBright("Your SESSION_ID is an old Ultra-X:~/JUNE-MD:~/June-Ultra:~ base64 string."), "white");
      log(chalk.white.bgRedBright("These no longer work. Migrate now:"), "white");
      log(chalk.white.bgRedBright("  1. Pair at " + sessionServer.getServerUrl() + "/pair"), "white");
      log(chalk.white.bgRedBright("  2. Set SESSION_ID to your new JUNE-X~ Session ID"), "white");
      log(chalk.white.bgRedBright("  3. Restart the bot. Exiting in 30 seconds..."), "white");
      await delay(30000);
      process.exit(1);
    }
    if (!SESSION_ID_PREFIX_RE.test(value116.trim())) {
      log(chalk.black.bgYellowBright("[ERROR]: Invalid SESSION_ID format."), "white");
      log(chalk.black.bgYellowBright("[SESSION ID] Must be a JUNE-X~ Session ID (e.g. JUNE-X~ab12cd)."), "white");
      log(chalk.black.bgYellowBright("Get one at " + sessionServer.getServerUrl() + "/pair — then restart. Exiting in 20 seconds..."), "white");
      await delay(20000);
      process.exit(1);
    }
  }
}
async function downloadSessionData() {
  await fs.promises.mkdir(sessionDir, {
    recursive: true
  });
  if (!fs.existsSync(credsPath) && global.SESSION_ID) {
    const value118 = global.SESSION_ID;
    if (sessionServer.isJuneHandle(value118)) {
      return;
    }
    log("[ SESSION ] The raw-session SESSION_ID download path was retired. " + ("Pair at " + sessionServer.getServerUrl() + "/pair and use a JUNE-X~ Session ID."), "red", true);
    process.exit(1);
  }
}
async function restoreSessionFromDB() {
  if (sessionExists()) {
    return false;
  }
  const value119 = getSession();
  if (!value119) {
    return false;
  }
  try {
    await fs.promises.mkdir(sessionDir, {
      recursive: true
    });
    const value120 = Buffer.from(value119, "base64");
    JSON.parse(value120.toString("utf8"));
    atomicWriteFile(credsPath, value120);
    return true;
  } catch (error121) {
    log("⚠️ DB session restore failed", "yellow");
    clearSession();
    return false;
  }
}
async function getLoginMethod() {
  const value122 = await getLastLoginMethod();
  if (value122 && sessionExists()) {
    return value122;
  }
  if (!sessionExists() && value122) {
    clearLoginMethod();
  }
  if (!process.stdin.isTTY) {
    log("❌ No SESSION_ID found and no TTY available for interactive login.", "red");
    process.exit(1);
  }
  log("Choose Any WhatsApp Login method:", "green");
  log("1. ✓Enter Session ID", "yellow");
  log("2. ✓Enter Phone Number", "yellow");
  let value123 = await question(chalk.greenBright("\nYour choice (1 or 2): "));
  value123 = value123.trim();
  if (value123 === "1") {
    log("\nEnter your Session ID — get it at " + sessionServer.getServerUrl() + "/pair", "yellow");
    log("Accepted format: JUNE-X~xxxxxx (4-20 letters/digits after the ~)", "yellow");
    let value124 = await question(chalk.greenBright("\nYour Session ID: "));
    value124 = value124.trim();
    if (!SESSION_ID_PREFIX_RE.test(value124)) {
      log("Invalid Session ID! It must be a JUNE-X~ Session ID (pair on the website).", "red");
      process.exit(1);
    }
    global.SESSION_ID = value124;
    process.env.SESSION_ID = value124;
    await saveLoginMethod("session");
    return "session";
  } else if (value123 === "2") {
    log("\nEnter your WhatsApp phone number with country code.", "green");
    log("Example: 2547xxxxxxxx", "green");
    let value125 = await question(chalk.greenBright("\nYour phone number: "));
    value125 = value125.trim().replace(/[^0-9]/g, "");
    if (value125.length < 7) {
      log("Invalid phone number.", "red");
      return getLoginMethod();
    }
    global.phoneNumber = value125;
    await saveLoginMethod("number");
    return "number";
  } else {
    log("Invalid option! Please choose 1 or 2.", "red");
    return getLoginMethod();
  }
}
async function requestPairingCode(value126) {
  try {
    log("Waiting 3 seconds for socket to stabilize...", "yellow");
    await delay(3000);
    let value127 = await value126.requestPairingCode(global.phoneNumber);
    value127 = value127?.match(/.{1,4}/g)?.join("-") || value127;
    log(chalk.black.bgCyanBright("\n🔑 Your Pairing Code: " + value127 + "\n"), "white");
    log("\n1. Open WhatsApp → Settings → Linked Devices\n2. Tap \"Link a Device\"\n3. Enter the code above\n", "blue");
    return true;
  } catch (error128) {
    log("Failed to get pairing code: " + error128.message, "red", true);
    return false;
  }
}
function detectPlatform() {
  if (process.env.DYNO) {
    return "☁️ Heroku";
  }
  if (process.env.RENDER) {
    return "⚡ Render";
  }
  if (process.env.RAILWAY_ENVIRONMENT || process.env.RAILWAY_PROJECT_ID) {
    return "🚉 Railway";
  }
  if (process.env.REPLIT_SLUG || process.env.REPL_ID) {
    return "🔵 Replit";
  }
  if (process.env.PREFIX && process.env.PREFIX.includes("termux")) {
    return "📱 Termux";
  }
  if (process.env.PORTS && process.env.CYPHERX_HOST_ID) {
    return "🌀 CypherX Platform";
  }
  if (process.env.P_SERVER_UUID) {
    return "🖥️ Panel";
  }
  if (process.env.LXC) {
    return "🐦‍⬛ Linux Container (LXC)";
  }
  switch (os.platform()) {
    case "win32":
      return "🪟 Windows";
    case "darwin":
      return "🍎 macOS";
    case "linux":
      return "🐧 Linux";
    default:
      return "❓ Unknown";
  }
}
async function sendWelcomeMessage(value129) {
  if (global.isBotConnected) {
    return;
  }
  await delay(1500);
  try {
    if (!value129.user || global.isBotConnected) {
      return;
    }
    global.isBotConnected = true;
    const value130 = value129.user.id.split(":")[0] + "@s.whatsapp.net";
    const value131 = juneDatabase.getBotSetting("prefix") === "" ? "none" : juneDatabase.getBotSetting("prefix") || ".";
    const value132 = detectPlatform();
    const value133 = (Array.isArray(juneDatabase.getOwnerNames()) ? juneDatabase.getOwnerNames()[0] : juneDatabase.getOwnerNames()) || "Bot Owner";
    const value134 = applyFont("┏━━━✧ CONNECTED ✧━━━━\n┃✧ Bot: " + juneDatabase.getBotSetting("botName") + "\n┃✧ Prefix: [ " + value131 + " ]\n┃✧ Owner: " + value133 + "\n┃✧ Platform: " + value132 + "\n┃✧ Status: online \n┃✧ Time: " + new Date().toLocaleString() + "\n┃✧ T.Group: t.me/juneOff\n┃✧ Telegram: t.me/supremlord\n┃✧ Repo: https://github.com/Vinpink2\n┗━━━━━━━━━━━━━━━");
    let value135 = value134;
    if (global._credsOnlyWarmStart) {
      global._credsOnlyWarmStart = false;
      log("[ AUTH ] Baileys is rebuilding your WhatsApp auth keys… this can take a few minutes on a whale-sized account. Early replies may be slow.", "yellow");
      const value136 = String.fromCharCode(8206).repeat(12000);
      const value137 = applyFont("🔥 WARMING UP…\n\nSession restored — bot is online ✅\n\nFirst replies may be slow for 2–3 minutes\nwhile keys rebuild. Then: instant ⚡");
      value135 = "" + value134 + value136 + "\n" + value137;
    }
    await value129.sendMessage(value130, {
      text: value135
    });
    clearPersistedSessionErrorState();
    global.errorRetryCount = 0;
  } catch (error138) {
    log("Welcome message error: " + error138.message, "red", true);
    global.isBotConnected = false;
  }
}
async function handle408Error(value139) {
  if (value139 !== DisconnectReason.connectionTimeout) {
    return {
      is408: false
    };
  }
  global.errorRetryCount++;
  const value140 = 10;
  const value141 = getPersistedSessionErrorState();
  value141.count = global.errorRetryCount;
  value141.last_error_timestamp = Date.now();
  setPersistedSessionErrorState(value141);
  log("Connection Timeout (408). Retry " + global.errorRetryCount + "/" + value140, "yellow");
  const value142 = global.errorRetryCount >= value140;
  if (value142) {
    log(chalk.black.bgYellowBright("[MAX TIMEOUTS] " + value140 + " reached. Refreshing Baileys version and waiting 60s..."), "white");
    clearPersistedSessionErrorState();
    global.errorRetryCount = 0;
    _baileysVersionCache = null;
  }
  return {
    is408: true,
    maxReached: value142
  };
}
async function checkSessionIntegrityAndClean() {
  const value143 = fs.existsSync(sessionDir);
  const value144 = sessionExists();
  if (value143 && !value144) {
    if (hasVerifiedSQLiteAuth(juneDatabase._db)) {
      const value145 = fs.readdirSync(sessionDir);
      if (value145.length > 0) {
        const value146 = sessionDir + ".incomplete-" + Date.now();
        try {
          fs.renameSync(sessionDir, value146);
          log("[ SESSION ] Incomplete session folder preserved at " + path.basename(value146) + ".", "yellow");
        } catch (error147) {}
      }
      return;
    }
    clearSessionFiles();
    log("Cleanup done. Waiting 3 seconds...", "yellow");
    await delay(3000);
  }
}
function checkEnvStatus() {
  try {
    global._envWatcher = fs.watch(envPath, {
      persistent: false
    }, (value148, value149) => {
      if (value149 && value148 === "change") {
        if (global._suppressEnvWatcherUntil && Date.now() < global._suppressEnvWatcherUntil) {
          return;
        }
        log(chalk.black.bgBlueBright("[ENV CHANGED] Restarting to apply new configuration..."), "white");
        process.exit(1);
      }
    });
  } catch (error150) {
    log("⚠️ .env watcher failed: " + error150.message, "yellow");
  }
}
const STORE_MAX_CHATS = Math.max(50, parseInt(process.env.JUNE_MAX_STORED_CHATS, 10) || 300);
const store = createMessageStore({
  maxPerChat: 20,
  maxChats: STORE_MAX_CHATS
});
const processedMessages = new Set();
setInterval(() => processedMessages.clear(), 300000);
const MEMORY_WATCHDOG_INTERVAL_MS = 300000;
const MEMORY_WARN_RSS_MB = Math.max(128, parseInt(process.env.JUNE_RSS_WARN_MB, 10) || 440);
function memoryWatchdog() {
  try {
    const value151 = process.memoryUsage().rss / 1048576;
    if (value151 < MEMORY_WARN_RSS_MB) {
      return;
    }
    const value152 = store.messages.size;
    store.evictOldestChats(Math.floor(store.maxChats / 2));
    const value153 = value152 - store.messages.size;
    if (typeof global.gc === "function") {
      try {
        global.gc();
      } catch (error154) {}
    }
    const value155 = process.memoryUsage().rss / 1048576;
    log("[MEM] RSS " + Math.round(value151) + "MB ≥ " + MEMORY_WARN_RSS_MB + "MB — evicted " + value153 + " oldest chat(s) from store (" + store.messages.size + " remain), RSS now " + Math.round(value155) + "MB.", "yellow");
  } catch (error156) {
    log("[MEM] Watchdog error: " + error156.message, "red", true);
  }
}
setInterval(() => memoryWatchdog(), MEMORY_WATCHDOG_INTERVAL_MS);
function getExternalDatabaseStatus() {
  const value157 = pgAdapter.getStatus?.() || {};
  const value158 = mongoAdapter.getStatus?.() || {};
  const value159 = [{
    name: "PostgreSQL",
    configured: Boolean(value157.configured || String(process.env.DATABASE_URL || "").trim()),
    connected: value157.available === true,
    error: value157.lastError ? "connection unavailable" : null
  }, {
    name: "MongoDB",
    configured: Boolean(value158.configured || String(process.env.MONGODB_URI || process.env.MONGO_URL || "").trim()),
    connected: value158.available === true,
    error: value158.lastError ? "connection unavailable" : null
  }];
  return {
    configured: value159.some(value160 => value160.configured),
    connected: value159.some(value161 => value161.connected),
    databases: value159
  };
}
const NOISE_PATTERNS = ["closing session", "sessionentry", "prekey bundle", "pendingprekey", "_chains", "registrationid", "currentratchet", "chainkey", "ratchet", "signal protocol", "ephemeralkeypair", "indexinfo", "basekey", "ratchetkey", "(node:33) Warning:", "(node:33)", "WARNING:", "SECURITY"];
function suppressedLogger() {
  const value162 = pino({
    level: "silent"
  });
  value162.info = (...value163) => {
    const value164 = value163.map(value165 => typeof value165 === "string" ? value165 : JSON.stringify(value165)).join(" ").toLowerCase();
    if (!NOISE_PATTERNS.some(value166 => value164.includes(value166))) {
      pino({
        level: "info"
      }).info(...value163);
    }
  };
  value162.debug = () => {};
  value162.trace = () => {};
  return value162;
}
const isSystemJid = value167 => !value167 || value167.includes("@broadcast") || value167.includes("status.broadcast") || value167.includes("@newsletter");
let _baileysVersionCache = null;
async function getBaileysVersion() {
  if (_baileysVersionCache) {
    return _baileysVersionCache;
  }
  try {
    const value168 = await fetchLatestBaileysVersion();
    _baileysVersionCache = value168.version;
  } catch (error169) {
    _baileysVersionCache = [2, 3000, 1023507977];
    log("[ VERSION ] fetchLatestBaileysVersion failed (" + error169.message + "). Using fallback version.", "yellow");
  }
  return _baileysVersionCache;
}
async function startJunexBot() {
  if (global._shutdownRequested) {
    return null;
  }
  sessionServer.markOfflineMode();
  const value170 = global.currentSock;
  if (value170) {
    global.currentSock = null;
    try {
      value170.ev?.removeAllListeners?.();
    } catch (error171) {}
    try {
      value170.ws?.close?.();
    } catch (error172) {}
    try {
      value170.end?.(new Error("replaced by reconnect"));
    } catch (error173) {}
    await delay(250);
  }
  if (global._activeIntervals && global._activeIntervals.length > 0) {
    global._activeIntervals.forEach(value174 => clearInterval(value174));
    global._activeIntervals = [];
    log("[ CLEANUP ] Cleared stale intervals from previous connection.", "yellow");
  }
  const value175 = await getBaileysVersion();
  const value176 = getSQLiteAuthStats(juneDatabase._db);
  if (value176.pendingFileMigration && fs.existsSync(sessionDir)) {
    try {
      const value177 = await finalizePendingFileMigration(juneDatabase._db, sessionDir, {
        onMutation: value178 => juneDatabase.markDatabaseDirty(value178)
      });
      if (value177.ok) {
        log("[ AUTH ] Finalized pending file-auth migration; session folder quarantined.", "green");
      }
    } catch (error179) {
      log("[ AUTH ] Pending file-auth migration deferred: " + error179.message, "yellow");
      log("[ AUTH ] Continuing with the previously verified SQLite snapshot.", "yellow");
    }
  }
  const value180 = await validateSQLiteAuth(juneDatabase._db, {
    onMutation: value181 => juneDatabase.markDatabaseDirty(value181)
  });
  if (value180.repairedLidMappings > 0) {
    const value182 = value180.repairedLidMappings;
    log("[ AUTH ] Repaired " + value182 + " malformed auxiliary LID mapping " + (value182 === 1 ? "row" : "rows") + "; valid Signal auth preserved.", "yellow");
    try {
      await juneDatabase.createBackup?.();
    } catch (error183) {
      log("[ AUTH ] Could not flush cleaned auth backup yet: " + error183.message, "yellow");
    }
  }
  if (value180.wasVerified && !value180.ok) {
    log("[ AUTH ] ❌ SQLite startup validation failed: " + value180.reason, "red", true);
    log("[ AUTH ] Recovery required: restore the last valid database backup or perform an explicit re-pair.", "yellow");
    throw new Error("AUTH_STARTUP_VALIDATION_FAILED: " + value180.reason);
  }
  let value184;
  try {
    if (!hasVerifiedSQLiteAuth(juneDatabase._db)) {
      await fs.promises.mkdir(sessionDir, {
        recursive: true
      });
    }
    value184 = await useSQLiteAuthState(juneDatabase._db, sessionDir, {
      allowFresh: true,
      allowFreshAfterInvalid: value176.invalidReason === "session-cleared",
      onMutation: value185 => juneDatabase.markDatabaseDirty(value185)
    });
  } catch (error186) {
    if (!error186.message?.startsWith("AUTH_MIGRATION_NO_KEY_FILES") && !error186.message?.startsWith("AUTH_MIGRATION_NO_VALID_KEY_FILES")) {
      throw error186;
    }
    await fs.promises.mkdir(sessionDir, {
      recursive: true
    });
    const value187 = await useMultiFileAuthState(sessionDir);
    value184 = {
      ...value187,
      source: "files",
      stats: getSQLiteAuthStats(juneDatabase._db)
    };
  }
  const {
    state: value188,
    saveCreds: value189
  } = value184;
  global._credsOnlyWarmStart = value184.source === "sqlite" && value184.stats.totalKeys === 0 && getAuthSource(juneDatabase._db) === "session-server";
  const value190 = "[ AUTH ] " + (value184.source === "sqlite" ? "SQLite" : "file") + " auth active (" + value184.stats.totalKeys + " key rows).";
  if (global._credsOnlyWarmStart) {
    log(value190 + " Creds-only restore — keys rebuild after connect (first messages slow ~2 min).", "cyan");
  } else {
    log(value190, "cyan");
  }
  const value191 = new NodeCache();
  let value192 = null;
  let value193 = false;
  let value194 = null;
  let value195 = null;
  const value196 = Math.min(1500, Math.max(500, Number(process.env.JUNE_CREDS_MIGRATION_DELAY_MS) || 1000));
  const value197 = async value198 => {
    if (value184.source !== "files" || value193) {
      return null;
    }
    const value199 = getSQLiteAuthStats(juneDatabase._db);
    if (value199.verified && !value199.pendingFileMigration) {
      return null;
    }
    if (value194) {
      return null;
    }
    if (value192) {
      return value192;
    }
    value192 = (async () => {
      try {
        const value200 = await migrateFilesToSQLite(juneDatabase._db, sessionDir, {
          replace: true,
          quarantine: false,
          onMutation: value201 => juneDatabase.markDatabaseDirty(value201)
        });
        value184.stats = value200.stats;
        value193 = true;
        value194 = null;
        log("[ AUTH ] File-auth snapshot migrated to SQLite after " + value198 + "; quarantine will complete on the next start.", "green");
        return value200;
      } catch (error202) {
        if (error202.message?.startsWith("AUTH_MIGRATION_NO_VALID_KEY_FILES")) {
          value194 = error202.message;
          log("[ AUTH ] File-auth SQLite migration paused: " + error202.message, "yellow");
        } else if (!error202.message?.startsWith("AUTH_MIGRATION_NO_KEY_FILES")) {
          log("[ AUTH ] File-auth migration after " + value198 + " failed: " + error202.message, "yellow");
        }
        return null;
      } finally {
        value192 = null;
      }
    })();
    return value192;
  };
  const value203 = () => {
    if (value195) {
      clearTimeout(value195);
    }
    value195 = setTimeout(() => {
      value195 = null;
      if (global._shutdownRequested || global.currentSock !== value204) {
        return;
      }
      value197("creds-update");
    }, value196);
    value195.unref?.();
  };
  const value204 = makeWASocket({
    version: value175,
    logger: pino({
      level: "silent"
    }),
    printQRInTerminal: false,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    auth: {
      creds: value188.creds,
      keys: makeCacheableSignalKeyStore(value188.keys, pino({
        level: "fatal"
      }).child({
        level: "fatal"
      }))
    },
    markOnlineOnConnect: (() => {
      if (String(process.env.JUNE_STAY_ONLINE || "").trim().toLowerCase() === "true") {
        return true;
      }
      return false;
    })(),
    generateHighQualityLinkPreview: false,
    syncFullHistory: false,
    downloadHistory: false,
    msgRetryCounterCache: value191,
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 20000,
    getMessage: async value205 => {
      const value206 = value205.remoteJid?.endsWith("@lid") ? value205.remoteJid : jidNormalizedUser(value205.remoteJid);
      let value207 = await store.loadMessage(value206, value205.id);
      if (!value207?.message && value205.remoteJidAlt) {
        value207 = await store.loadMessage(value205.remoteJidAlt, value205.id);
      }
      return value207?.message || "";
    }
  });
  store.bind(value204.ev);
  value204.botStore = store;
  global.currentSock = value204;
  try {
    require("./utils/stealthMode").applyToSocket(value204);
  } catch (error208) {}
  let value209 = false;
  value204.ev.on("connection.update", async value210 => {
    const {
      connection: value211,
      lastDisconnect: value212,
      qr: value213
    } = value210;
    if (value213 && global.phoneNumber && !value209) {
      value209 = true;
      await requestPairingCode(value204);
    }
    if (value211 === "close") {
      global.isBotConnected = false;
      global.botState = "connecting";
      const value214 = value212?.error?.output?.statusCode;
      const value215 = String(value212?.error?.message || value212?.error?.output?.payload?.message || "").toLowerCase();
      const value216 = value214 === 401 && value215.includes("conflict");
      const value217 = value214 === 403;
      if (value217) {
        global._forbiddenCount = (global._forbiddenCount || 0) + 1;
        log("[ BANNED ] WhatsApp refused this account (403) — attempt " + (global._forbiddenCount + "/3. This usually means the number is banned."), "yellow");
      } else {
        global._forbiddenCount = 0;
      }
      const value218 = value217 && global._forbiddenCount >= 3;
      const value219 = !value216 && (value214 === DisconnectReason.loggedOut || value214 === 401 || value218);
      if (value218) {
        log(chalk.white.bgRedBright("☠️  Account refused by WhatsApp (403) three times."), "white");
        log("[ BANNED ] Clearing the stored credentials so another number can pair.", "yellow");
        log("[ BANNED ] After pairing a new number, also update PN= in .env and run .setownernumber, or the bot keeps using the old number's data.", "yellow");
      }
      if (value219) {
        log(chalk.white.bgRedBright("💥 Disconnected [" + value214 + "] — logged out. Clearing session..."), "white");
        const value220 = process.env.SESSION_ID?.trim();
        if (value220 && SESSION_ID_PREFIX_RE.test(value220)) {
          markSessionIdFingerprintRevoked(fingerprintSessionId(value220));
        }
        if (getAuthSource(juneDatabase._db) === "mirror-restore" && !isAuthConnectionVerified(juneDatabase._db)) {
          log("[ SESSION SERVER ] Local auth was only a mirror copy; NOT marking the session revoked — it will be re-fetched from the Session Server on the next start.", "yellow");
        } else {
          sessionServer.revokeSession("whatsapp-logout").catch(() => {});
        }
        global.botState = "disconnected";
        global.connectedAt = null;
        clearSessionFiles();
        log("Session cleared. Returning to login menu in 10 seconds...", "yellow");
        for (let value221 = 10; value221 > 0; value221--) {
          log("Restarting login in " + value221 + "s...", "cyan");
          await delay(1000);
        }
        log("Restarting login flow...", "green");
        return main();
      } else {
        if (global.isReconnecting) {
          return;
        }
        global.isReconnecting = true;
        const {
          is408: value222,
          maxReached: value223
        } = await handle408Error(value214);
        let value224;
        let value225 = true;
        if (value222) {
          if (value223) {
            value224 = 60000;
          } else {
            const value226 = Math.pow(2, Math.min(global.errorRetryCount, 3)) * 5000;
            value224 = Math.min(value226 + Math.floor(Math.random() * 1000), 60000);
          }
        } else if (value214 === 503) {
          global.errorRetryCount++;
          setPersistedSessionErrorState({
            count: global.errorRetryCount,
            last_error_timestamp: Date.now()
          });
          value224 = Math.min(global.errorRetryCount * 30000, 300000);
          log(chalk.black.bgYellowBright("[503] WhatsApp servers unavailable. Retry " + global.errorRetryCount + " — waiting " + value224 / 1000 + "s..."), "white");
        } else if (value214 === 500) {
          global._consecutive500Count = (global._consecutive500Count || 0) + 1;
          if (global._consecutive500Count >= 3) {
            log(chalk.white.bgRedBright("[500×" + global._consecutive500Count + "] Persistent server errors. Preserving verified auth state..."), "white");
            global._consecutive500Count = 0;
            log("[500] Keeping the verified SQLite auth state; this may be a transient server error.", "yellow");
            value224 = 8000;
          } else {
            log(chalk.black.bgYellowBright("[500] WhatsApp error (attempt " + global._consecutive500Count + "/3). Retrying without clearing session..."), "white");
            value224 = 10000;
          }
        } else if (value214 === 409 || value214 === 440 || value216) {
          value225 = false;
          global._conflictCount = (global._conflictCount || 0) + 1;
          const value227 = Date.now();
          const value228 = global._lastConflictLogTime || 0;
          const value229 = 180000;
          const value230 = value227 - value228 > value229;
          if (global._conflictCount >= 10) {
            value224 = 300000;
            if (value230) {
              log("[ CONFLICT ] Persistent device conflict (" + value214 + " × " + global._conflictCount + "). Waiting 5 minutes; close other WhatsApp bot instances.", "yellow");
              global._lastConflictLogTime = value227;
              global._suppressedConflictCount = 0;
            } else {
              global._suppressedConflictCount++;
            }
            global._conflictCount = 0;
          } else {
            value224 = Math.min(8000 + global._conflictCount * 5000, 120000);
            if (value230) {
              log("[ CONFLICT ] WhatsApp session replaced (" + value214 + "). Reconnecting in " + value224 / 1000 + "s.", "yellow");
              global._lastConflictLogTime = value227;
              global._suppressedConflictCount = 0;
              if (global._conflictSummaryTimer) {
                clearTimeout(global._conflictSummaryTimer);
              }
              global._conflictSummaryTimer = setTimeout(() => {
                if (global._suppressedConflictCount > 0) {
                  log("[ CONFLICT ] Repeated " + value214 + " conflicts suppressed — " + global._suppressedConflictCount + " reconnect attempts.", "yellow");
                }
                global._suppressedConflictCount = 0;
                global._conflictSummaryTimer = null;
              }, value229);
            } else {
              global._suppressedConflictCount++;
            }
          }
        } else {
          value224 = 5000;
        }
        if (value225) {
          log("Connection closed (" + value214 + "). Reconnecting in " + Math.round(value224 / 1000) + "s...", "yellow");
        }
        await new Promise(value231 => {
          global._reconnectTimer = setTimeout(value231, value224);
          global._reconnectTimer.unref?.();
        });
        global._reconnectTimer = null;
        if (global._shutdownRequested) {
          global.isReconnecting = false;
          return;
        }
        global.isReconnecting = false;
        try {
          await startJunexBot();
        } catch (error232) {
          const value233 = String(error232?.message || error232 || "unknown startup error");
          const value234 = value233.includes("AUTH_STARTUP_VALIDATION_FAILED");
          global.botState = "connecting";
          if (value234) {
            log("[ AUTH ] Reconnect stopped safely: " + value233.replace(/^AUTH_STARTUP_VALIDATION_FAILED:\s*/, ""), "yellow");
            log("[ AUTH ] No auth data was cleared. Restore a known-good backup or explicitly re-pair to recover.", "yellow");
          } else {
            const value235 = 30000;
            log("[ RECONNECT ] Startup retry failed safely: " + value233, "yellow");
            log("[ RECONNECT ] Retrying in " + value235 / 1000 + "s...", "yellow");
            global._reconnectTimer = setTimeout(() => {
              global._reconnectTimer = null;
              startJunexBot().catch(value236 => {
                log("[ RECONNECT ] Retry stopped safely: " + (value236?.message || value236), "yellow");
              });
            }, value235);
            global._reconnectTimer.unref?.();
          }
        }
      }
    } else if (value211 === "open") {
      global.isReconnecting = false;
      global.errorRetryCount = 0;
      global._forbiddenCount = 0;
      clearPersistedSessionErrorState();
      global._consecutive500Count = 0;
      global._conflictCount = 0;
      if (global._conflictSummaryTimer) {
        clearTimeout(global._conflictSummaryTimer);
        global._conflictSummaryTimer = null;
      }
      if (global._suppressedConflictCount > 0) {
        log("[ CONFLICT ] Connection restored successfully.", "green");
        global._suppressedConflictCount = 0;
      }
      global._lastConflictLogTime = 0;
      global.botState = "connected";
      global.connectedAt = Date.now();
      try {
        setAuthConnectionVerified(juneDatabase._db, true);
      } catch (error237) {}
      replayDrain.markConnectionOpen();
      global.phoneNumber = null;
      const value238 = value204.user?.id?.split(":")[0] || "unknown";
      try {
        const value239 = String(value204.user?.id || "").split(":")[0].split("@")[0].replace(/\D/g, "");
        juneDatabase.setRuntimeOwnerName(value204.user?.name || value204.user?.verifiedName || "");
        if (value239) {
          const value240 = juneDatabase.getOwners();
          if (!value240.length) {
            juneDatabase.setOwners([value239], "auto");
            log("[ OWNER ] Claimed " + maskNumber(value239) + " from the paired account.", "green");
          } else if (!value240.includes(value239)) {
            log("[ OWNER ] Paired as " + maskNumber(value239) + " but owner is " + value240.map(value241 => maskNumber(value241)).join(", ") + " " + ("(set: " + (juneDatabase.getOwnerSource() || "unknown") + "). Not changing — ") + ("run .setownernumber " + maskNumber(value239) + " to update."), "yellow");
          }
        }
      } catch (error242) {
        log("[ OWNER ] Could not resolve owner from the session: " + error242.message, "yellow");
      }
      try {
        const value243 = !!process.env.DATABASE_URL || !!process.env.MONGODB_URI || !!process.env.MONGO_URL;
        const value244 = global.__BOT_ID_SOURCE__;
        if (value243 && value244) {
          const value245 = String(value204.user?.id || "").split(":")[0].split("@")[0].replace(/\D/g, "");
          const value246 = String(value244).split("@")[0].split(":")[0].replace(/\D/g, "");
          if (value245 && value246 && value245 !== value246) {
            log("[ BOT ID ] PN is " + maskNumber(value246) + " but this session is paired as " + maskNumber(value245) + ". " + ("Remote data is stored under \"" + maskBotId(pgAdapter.buildBotId(value244)) + "\". ") + ("Set PN=" + maskNumber(value245) + " in .env if that is wrong."), "yellow");
          }
        }
      } catch (error247) {}
      await value197("connection-open");
      const value248 = handler.getCommandCount ? handler.getCommandCount() : "?";
      const value249 = handler.getAliasCount ? handler.getAliasCount() : 0;
      const value250 = ["120363405182019728@newsletter", "120363402430393036@newsletter"];
      const value251 = ["F6eFzZE2cXF5PkPyqu8gr5", "", ""];
      global.newsletters = value250;
      global.groupInvites = value251;
      let value252 = "Failed";
      groupJoinStatus = "warning";
      if (value251.length > 0) {
        const value253 = await Promise.allSettled(value251.map(value254 => value204.groupAcceptInvite(value254)));
        const value255 = value253.some(value256 => value256.status === "fulfilled");
        const value257 = value253.filter(value258 => value258.status === "rejected").map(value259 => String(value259.reason?.message || value259.reason || "failed").toLowerCase());
        const value260 = value257.some(value261 => value261.includes("already") || value261.includes("conflict"));
        if (value255) {
          value252 = "Connected";
          groupJoinStatus = "connected";
        } else if (value260) {
          value252 = "Joined already";
          groupJoinStatus = "connected";
        } else {
          value252 = "Failed";
          groupJoinStatus = "warning";
        }
      }
      if (!global.startupReportPrinted) {
        const value262 = process.env.JUNE_IS_UPDATE === "true";
        if (value262) {
          log("[ SYSTEM ] Bot respawned successfully after update.", "green");
          global.startupReportPrinted = true;
        } else {
          const value263 = juneDatabase.getDatabaseHealth();
          const value264 = getSQLiteAuthStats(juneDatabase._db);
          const value265 = pgAdapter.getStatus();
          const value266 = mongoAdapter.getStatus();
          const value267 = juneDatabase.getBotMode?.() || "public";
          const value268 = diskManager?.getStatus?.() || {};
          const value269 = getStartupToggleState();
          const value270 = Array.isArray(juneDatabase.getOwnerNames()) ? juneDatabase.getOwnerNames()[0] : juneDatabase.getOwnerNames() || "configured";
          const value271 = ((Date.now() - global.startupStartedAt) / 1000).toFixed(2);
          const value272 = {
            version: juneDatabase.VERSION,
            platform: os.platform(),
            nodeVersion: process.version,
            prefix: juneDatabase.getBotSetting("prefix") === "" ? "none" : juneDatabase.getBotSetting("prefix") || ".",
            mode: value267,
            owner: value270,
            commandCount: value248,
            aliasCount: value249,
            startupTime: value271 + "s",
            sqliteLabel: value263.ok ? "ready" : "degraded",
            sqliteStatus: value263.ok ? "ready" : "warning",
            sqliteDriver: value263.driver || "unknown",
            schemaVersion: value263.schemaVersion,
            integrityLabel: value263.lastIntegrityCheck?.ok === false ? "failed" : "passed",
            integrityStatus: value263.lastIntegrityCheck?.ok === false ? "failed" : "passed",
            postgres: value265,
            mongo: value266,
            toggles: value269,
            diskManagerLabel: value268.low ? "low storage" : "active",
            diskManagerStatus: value268.low ? "warning" : "active",
            sessionLabel: value264.verified ? "verified" : "active",
            sessionStatus: value264.verified ? "ready" : "warning",
            authSource: value184.source === "sqlite" ? "SQLite" : "file auth",
            sessionServerLabel: sessionServer.isTokenModeActive() ? sessionServer.isAuthenticated() ? "connected" : "Session ID set" : "not set",
            sessionServerStatus: sessionServer.isTokenModeActive() ? "connected" : "off",
            signalKeysLabel: (value264.totalKeys || 0) + " key rows",
            signalKeysStatus: value264.verified ? "ready" : "warning",
            whatsappLabel: "connected",
            whatsappStatus: "connected",
            accountLabel: "+" + String(value238).slice(0, 3) + "******" + String(value238).slice(-3),
            accountStatus: "connected",
            groupJoinLabel: value252,
            groupJoinStatus: groupJoinStatus,
            databaseInfo: getExternalDatabaseStatus()
          };
          printStartupReport(value272);
          global.startupReportPrinted = true;
        }
      }
      if (!global.welcomeSent) {
        global.welcomeSent = true;
        await sendWelcomeMessage(value204);
      }
      handler.initializeAntiCall(value204);
      require("./utils/pinger").onBotConnected(value204);
      require("./utils/notes").onBotConnected(value204);
      setImmediate(async () => {
        await Promise.allSettled(value250.filter(Boolean).map(value273 => value204.newsletterFollow(value273).catch(value274 => {
          if (!value274.message?.includes("already") && !value274.message?.includes("conflict") && !value274.message?.includes("unexpected")) {
            log("🚫 Newsletter follow failed: " + value274.message, "red");
          }
        })));
      });
      try {
        const value275 = require("./commands/owner/alwaysonline");
        const value276 = value275.loadSettings();
        if (value276.enabled) {
          value275.startHeartbeat(value204);
        }
      } catch (error277) {}
    }
  });
  value204.ev.on("messages.upsert", async ({
    messages: value278,
    type: value279
  }) => {
    if (value279 !== "notify") {
      return;
    }
    value278 = value278.filter(value280 => !replayDrain.isReplayMessage(value280));
    if (value278.length === 0) {
      return;
    }
    const {
      loadSettings: value281,
      pickEmoji: value282
    } = require("./database");
    const {
      handleAutoDownloadStatus: value283
    } = require("./commands/owner/autodownloadstatus");
    if (!global._sReactQueue) {
      global._sReactQueue = [];
      global._sReactQueueRunning = false;
    }
    function handler284(value285) {
      global._sReactQueue.push(value285);
      if (!global._sReactQueueRunning) {
        handler286();
      }
    }
    async function handler286() {
      global._sReactQueueRunning = true;
      while (global._sReactQueue.length) {
        const {
          sock: value287,
          emoji: value288,
          reactKey: value289,
          normPart: value290
        } = global._sReactQueue.shift();
        try {
          await value287.sendMessage("status@broadcast", {
            react: {
              text: value288,
              key: value289
            }
          }, {
            statusJidList: [value290]
          });
        } catch (error291) {
          log("[ STATUS ] Auto-react FAILED for " + (value289?.id || "?") + ": " + error291.message, "red");
        }
        await new Promise(value292 => setTimeout(value292, 2500 + Math.floor(Math.random() * 1500)));
      }
      global._sReactQueueRunning = false;
    }
    for (const value293 of value278) {
      if (!value293.message || !value293.key?.id) {
        continue;
      }
      const value294 = value293.key.remoteJid;
      if (value294 !== "status@broadcast" || value293.key.fromMe) {
        continue;
      }
      if (value293.message?.protocolMessage) {
        continue;
      }
      if (value293.messageStubType) {
        continue;
      }
      const value295 = value293.key.participant;
      const value296 = value295 || value293.key.participantAlt || null;
      const value297 = value295 ? normalizeJidWithLid(value295) : value293.key.participantAlt || null;
      const value298 = value296 ? String(value296).split(":")[0].split("@")[0] : null;
      const value299 = [value204.user?.id, value204.user?.lid].filter(Boolean).map(value300 => String(value300).split(":")[0].split("@")[0]);
      if (value298 && value299.includes(value298)) {
        continue;
      }
      if (value297 && value293.message) {
        if (!global.statusStore) {
          global.statusStore = new Map();
        }
        const value301 = global.statusStore.get(value297) || [];
        value301.push(value293);
        if (value301.length > 20) {
          value301.shift();
        }
        global.statusStore.set(value297, value301);
      }
      try {
        await value283(value204, value293.key, value293.message);
      } catch (error302) {}
      try {
        const value303 = require("./commands/owner/antideletestatus");
        if (value303?.storeStatusMessage) {
          value303.storeStatusMessage(value293);
        }
      } catch (error304) {}
      try {
        const value305 = value281();
        if (value305.enabled && value296) {
          const value306 = {
            remoteJid: "status@broadcast",
            id: value293.key.id,
            participant: value296,
            fromMe: false
          };
          await new Promise(value307 => setTimeout(value307, 500 + Math.floor(Math.random() * 500)));
          try {
            await value204.readMessages([value306]);
          } catch (error308) {
            log("[ STATUS ] Auto-view FAILED for " + value293.key.id + ": " + error308.message, "red");
          }
        }
        if (value305.react && value296) {
          if (!global._sReactedIds) {
            global._sReactedIds = new Set();
          }
          if (!global._sReactedIds.has(value293.key.id)) {
            global._sReactedIds.add(value293.key.id);
            if (global._sReactedIds.size > 500) {
              global._sReactedIds.delete(global._sReactedIds.values().next().value);
            }
            handler284({
              sock: value204,
              emoji: value282(value305) || "💙",
              reactKey: {
                remoteJid: "status@broadcast",
                id: value293.key.id,
                participant: value296,
                fromMe: false
              },
              normPart: value296
            });
          }
        }
      } catch (error309) {
        log("[ STATUS ] Handler error: " + error309.message, "red");
      }
    }
    for (const value310 of value278) {
      if (!value310.message || !value310.key?.id) {
        continue;
      }
      const value311 = value310.key.remoteJid;
      if (!value311 || isSystemJid(value311)) {
        continue;
      }
      if (processedMessages.has(value310.key.id)) {
        continue;
      }
      const value312 = 300000;
      if (value310.messageTimestamp && Date.now() - value310.messageTimestamp * 1000 > value312) {
        continue;
      }
      processedMessages.add(value310.key.id);
      store.storeMessage(value311, value310);
      if (value310.message?.ephemeralMessage) {
        value310.message = value310.message.ephemeralMessage.message;
      }
      if (value310.message) {
        try {
          const value313 = juneDatabase.getTimeZone();
          const value314 = Object.keys(value310.message)[0] || "N/A";
          const value315 = value310.pushName || "N/A";
          const value316 = value310.message?.conversation || value310.message?.extendedTextMessage?.text || value310.message?.imageMessage?.caption || value310.message?.videoMessage?.caption || "";
          const value317 = value311.endsWith("@g.us");
          let value318 = null;
          if (value317) {
            try {
              const value319 = await handler.getGroupMetadata(value204, value311);
              value318 = value319?.subject || null;
            } catch (error320) {}
          }
          const value321 = moment(Date.now()).tz(value313).locale("en").format("dddd");
          const value322 = moment(Date.now()).tz(value313).locale("en").format("HH:mm:ss z");
          const value323 = moment(Date.now()).tz(value313).format("DD/MM/YYYY");
          lolcatjs.fromString("┏━━━━━━━━━━━━━『  JUNE ULTRA 』━━━━━━━━━━━━━─");
          lolcatjs.fromString("»  Sent Time: " + value321 + ", " + value322);
          lolcatjs.fromString("»  Date: " + value323);
          lolcatjs.fromString("»  Message Type: " + value314);
          lolcatjs.fromString("»  Sender Name: " + value315);
          lolcatjs.fromString("»  Chat ID: " + value311.split("@")[0]);
          if (value317 && value318) {
            lolcatjs.fromString("»  Group: " + value318);
            lolcatjs.fromString("»  Group JID: " + value311.split("@")[0]);
          }
          if (value316) {
            lolcatjs.fromString("»  Message: " + value316);
          }
          lolcatjs.fromString("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━─ ⳹\n");
        } catch (error324) {}
      }
      setImmediate(() => {
        try {
          const value325 = require("./commands/owner/savestatus");
          value325.handleStatusReply(value204, value310).catch(() => {});
        } catch (error326) {}
      });
      require("./commands/owner/autoread").readMessageIfEnabled(value204, value310).catch(() => {});
      handler.handleMessage(value204, value310).catch(value327 => {
        if (!value327.message?.includes("rate-overlimit") && !value327.message?.includes("not-authorized")) {
          log("Message handler error: " + value327.message, "red", true);
        }
      });
    }
  });
  value204.ev.on("creds.update", async () => {
    await value189();
    saveSession(credsPath);
    if (value184.source === "sqlite") {
      juneDatabase.markDatabaseDirty("auth-creds");
    }
    value203();
  });
  if (!global.presenceStore) {
    global.presenceStore = {};
  }
  value204.ev.on("presence.update", ({
    id: value328,
    presences: value329
  }) => {
    try {
      for (const [value330, value331] of Object.entries(value329)) {
        global.presenceStore[value330] = {
          status: value331.lastKnownPresence || "unavailable",
          lastSeen: value331.lastSeen || null,
          updatedAt: Date.now()
        };
        try {
          juneDatabase.recordRuntimeTelemetry("presence", value330, {
            chatId: value328,
            status: value331.lastKnownPresence || "unavailable"
          });
        } catch (error332) {}
      }
    } catch (error333) {
      log("[Presence] update error: " + error333.message, "yellow");
    }
  });
  value204.ev.on("group-participants.update", async value334 => {
    try {
      await handler.handleGroupUpdate(value204, value334);
    } catch (error335) {
      log("Group update error: " + error335.message, "red", true);
    }
  });
  const value336 = ["120363405182019728@newsletter", "120363405182019728@newsletter", "120363402430393036@newsletter"];
  const value337 = ["❤️", "💛", "👍", "💜", "😮", "🤍", "💙"];
  value204.ev.on("messages.upsert", async value338 => {
    try {
      const value339 = value338.messages[0];
      if (!value339?.message || !value339?.key?.server_id) {
        return;
      }
      if (!value336.includes(value339.key.remoteJid)) {
        return;
      }
      const value340 = value337[Math.floor(Math.random() * value337.length)];
      await value204.newsletterReactMessage(value339.key.remoteJid, value339.key.server_id.toString(), value340);
    } catch {}
  });
  global._activeIntervals.push(setInterval(() => {
    cleanupExpiredSessionQuarantines("scheduled cleanup");
  }, 21600000));
  startScheduledCleanups(value204);
  return value204;
}
async function connectViaSessionServer({
  sessionId: value341,
  fingerprint: value342,
  sqliteAuthReady: value343,
  forceBootstrap: value344,
  usableFileSession: value345
}) {
  if (!sessionServer.isJuneHandle(value341)) {
    const value346 = sessionServer.describeHandleProblem(value341);
    log(chalk.black.bgYellowBright("[ERROR]: Invalid Session ID (" + value346 + ")."), "white");
    log(chalk.black.bgYellowBright("A Session ID looks like: JUNE-X~ab12cd."), "white");
    await delay(10000);
    process.exit(1);
  }
  if (value343 && !value344 && isLocallyVerifiedAuth(juneDatabase._db)) {
    log("[ SESSION SERVER ] Verified local auth — connecting from SQLite; Session ID kept only as recovery backup.", "green");
    const value347 = getSessionIdFingerprint(juneDatabase._db);
    if (value342 && value347 !== value342) {
      if (value347) {
        log("[ SESSION SERVER ] Session ID changed; keeping the verified local auth (set JUNE_FORCE_SESSION_BOOTSTRAP=true to replace it).", "yellow");
      }
      rememberSessionIdFingerprint(value342);
    }
    await saveLoginMethod("session");
    await startJunexBot();
    return;
  }
  log("[ SESSION SERVER ] Session ID configured (redacted) — fetching the authoritative session…", "cyan");
  if (value344 && sessionExists()) {
    log("[ SESSION SERVER ] Forced bootstrap — preserving prior file auth first.", "yellow");
    try {
      const value348 = quarantineCurrentSessionForReplacement();
      if (value348) {
        log("[ SESSION ] Previous file auth preserved at " + path.basename(value348) + ".", "yellow");
      }
    } catch (error349) {
      log("[ SESSION SERVER ] Could not quarantine prior file auth: " + error349.message, "yellow");
    }
  }
  let value350 = 0;
  while (!global._shutdownRequested) {
    try {
      const value351 = await sessionServer.fetchAndRestoreSnapshot(juneDatabase._db);
      log("[ SESSION SERVER ] ✅ Auth state restored (" + value351.keyRows + " signal key rows). Connecting...", "green");
      juneDatabase.markDatabaseDirty("session-server-restore");
      setAuthSource(juneDatabase._db, "session-server");
      setAuthConnectionVerified(juneDatabase._db, true);
      rememberSessionIdFingerprint(value342);
      clearRevokedSessionIdFingerprint();
      await saveLoginMethod("session");
      await startJunexBot();
      return;
    } catch (error352) {
      if (error352.terminal) {
        log("[ SESSION SERVER ] ❌ " + error352.code + ": " + error352.message, "red", true);
        log("[ SESSION SERVER ] This Session ID can no longer be used. Pair again on the website, update SESSION_ID, and restart.", "yellow");
        checkEnvStatus();
        return;
      }
      if (/No valid JUNE-X~ Session ID/.test(error352.message || "")) {
        log("[ SESSION SERVER ] ❌ The Session ID is missing from the environment — this is a configuration error, not a network problem.", "red", true);
        log("[ SESSION SERVER ] Add SESSION_ID=<JUNE-X~ Session ID> to .env or your host panel, then restart.", "yellow");
        checkEnvStatus();
        return;
      }
      value350 += 1;
      if ((value345 || value343 && !value344) && value350 >= 2) {
        log("[ SESSION SERVER ] Unreachable (" + error352.message + "); falling back to the existing local auth" + (value345 ? " (file session)" : " (mirror-restored, unproven)") + ".", "yellow");
        await saveLoginMethod("session");
        await startJunexBot();
        return;
      }
      const value353 = Math.min(value350 * 15, 300);
      log("[ SESSION SERVER ] Unreachable (" + error352.message + "); retrying in " + value353 + "s...", "yellow");
      await delay(value353 * 1000);
    }
  }
}
async function main() {
  await juneDatabase.ready;
  const value354 = process.env.PN || process.env.JUNE_PN || process.env.JUNE_BOT_ID || process.env.BOT_ID || process.env.OWNER_NUMBER;
  const value355 = value354 ? null : sessionServer.handleBotIdSuffix(sessionServer.getConfiguredToken());
  let value356;
  let value357;
  if (value355) {
    value356 = "session-id";
    value357 = "june-ultra-main-tk-" + value355;
    log("[ BOT ID ] Session ID identity active — bot_id=\"" + maskBotId(value357) + "\" (no PN needed).", "cyan");
  } else {
    value356 = value354 || juneDatabase.getOwners()?.[0];
    value357 = pgAdapter.buildBotId(value356);
  }
  global.__BOT_ID_SOURCE__ = value356 || null;
  pgAdapter.setBotId(value357);
  mongoAdapter.setBotId(value357);
  if (!value356 && (process.env.DATABASE_URL || process.env.MONGODB_URI || process.env.MONGO_URL)) {
    log("[ BOT ID ] No SESSION_ID set — cloud data (Postgres/Mongo) is saved under the shared name " + ("\"" + value357 + "\".\n") + "  • Running only ONE bot on this database? You can ignore this.\n  • Running more than one bot on the same database? They will overwrite each other's data.\n  • Fix: paste your session token (SESSION_ID) in .env — each token automatically gets its own separate data space.\n    (Old way still works: PN=<your number> in .env)", "yellow");
  }
  const [value358, value359] = await Promise.all([pgAdapter.init(), mongoAdapter.init()]);
  if (value358.available) {
    const value360 = await juneDatabase.restoreFromPostgres();
    if (value360.restored > 0) {
      log("[ PG ] Restored " + value360.restored + " missing local database records.", "green");
    }
  }
  if (value359.available) {
    const value361 = await juneDatabase.restoreFromMongo();
    if (value361.restored > 0) {
      log("[ MONGO ] Restored " + value361.restored + " missing local database records.", "green");
    }
  }
  if (value358.available || value359.available) {
    try {
      const value362 = juneDatabase.backfillRemote();
      if (value362.pushed > 0) {
        log("[ SYNC ] Backfilled " + value362.pushed + " records to the remote mirror.", "cyan");
      }
    } catch (error363) {
      log("[ SYNC ] Backfill skipped: " + error363.message, "yellow");
    }
  }
  if (!hasVerifiedSQLiteAuth(juneDatabase._db) && !hasUsableFileSession()) {
    const value364 = await juneDatabase.restoreRemoteAuthState();
    if (value364.restored) {
      setAuthSource(juneDatabase._db, "mirror-restore");
      setAuthConnectionVerified(juneDatabase._db, false);
      log("[ AUTH MIRROR ] Restored " + value364.source + " auth state (" + value364.keyRows + " key rows).");
    } else if (value364.error) {
      log("[ AUTH MIRROR ] Remote auth state was unavailable or invalid.", "yellow");
    }
  }
  if (hasVerifiedSQLiteAuth(juneDatabase._db)) {
    if (juneDatabase.scheduleRemoteAuthMirror("startup")) {
      log("[ AUTH MIRROR ] External auth state mirror scheduled.", "cyan");
    }
  }
  await applyPersistedRuntimeSettings();
  if (!handler) {
    handler = require("./handler");
  }
  diskManager.start();
  const value365 = readSessionIDFromEnv();
  if (value365) {
    process.env.SESSION_ID = value365;
  }
  await checkAndHandleSessionFormat();
  global.errorRetryCount = getPersistedSessionErrorState().count;
  if (global.errorRetryCount > 0) {
    log("Initial 408 retry count: " + global.errorRetryCount, "yellow");
  }
  cleanupExpiredSessionQuarantines("startup");
  const value366 = process.env.SESSION_ID?.trim() || "";
  const value367 = Boolean(value366 && SESSION_ID_PREFIX_RE.test(value366));
  const value368 = hasVerifiedSQLiteAuth(juneDatabase._db);
  const value369 = value367 ? fingerprintSessionId(value366) : null;
  const value370 = [getSessionIdFingerprint(juneDatabase._db)].filter(Boolean);
  const value371 = [getSessionIdRevokedFingerprint(juneDatabase._db)].filter(Boolean);
  const value372 = Boolean(value369 && value370.includes(value369));
  const value373 = Boolean(value369 && value370.length > 0 && !value372);
  const value374 = Boolean(value369 && value371.includes(value369));
  const value375 = hasUsableFileSession();
  log("[ SESSION_ID ] " + (value367 ? "Configured (redacted)" : "(none)"), "cyan");
  {
    const value376 = String(process.env.SESSION_ID || "").trim();
    const value377 = sessionServer.isJuneHandle(value376);
    const value378 = /^(1|true|yes|on)$/i.test(String(process.env.JUNE_FORCE_SESSION_BOOTSTRAP || ""));
    if (value376) {
      if (!value377) {
        log("[ SESSION SERVER ] SESSION_ID: INVALID FORMAT (must be JUNE-X~ + 4-20 letters/digits — check quotes/spaces)", "yellow");
      }
    } else if (value378) {
      log("[ SESSION SERVER ] JUNE_FORCE_SESSION_BOOTSTRAP is set but no SESSION_ID is configured — the flag has no effect.", "yellow");
    } else if (String(process.env.JUNE_SESSION_SERVER_URL || "").trim()) {
      log("[ SESSION SERVER ] Server URL set but no SESSION_ID configured.", "yellow");
    }
  }
  if (value374) {
    log("[ SESSION_ID ] This session was logged out by WhatsApp. Add a fresh JUNE-X~ Session ID as SESSION_ID, then restart.", "red", true);
    checkEnvStatus();
    return;
  }
  if (sessionServer.isJuneHandle(value366)) {
    await connectViaSessionServer({
      sessionId: value366,
      fingerprint: value369,
      sqliteAuthReady: value368,
      forceBootstrap: /^(1|true|yes|on)$/i.test(String(process.env.JUNE_FORCE_SESSION_BOOTSTRAP || "")),
      usableFileSession: value375
    });
    checkEnvStatus();
    return;
  }
  const value379 = /^(1|true|yes|on)$/i.test(String(process.env.JUNE_FORCE_SESSION_BOOTSTRAP || ""));
  const value380 = value367 && (value379 || !value368 && !value375);
  if (value380) {
    global.SESSION_ID = value366;
    const value381 = value379 && sessionExists() || !value375 && sessionExists();
    if (value381) {
      const value382 = value379 ? "a forced SESSION_ID bootstrap" : "an unusable existing file session";
      log("[ SESSION_ID ] Applying " + value382 + " — preserving prior file auth first.", "yellow");
      const value383 = quarantineCurrentSessionForReplacement();
      if (value383) {
        log("[ SESSION ] Previous file auth preserved at " + path.basename(value383) + ".", "yellow");
      }
    } else {
      log("[ SESSION_ID MODE ] No usable local auth found — bootstrapping from SESSION_ID.", "white");
    }
    if (!sessionExists()) {
      log("[ SESSION_ID ] Writing creds.json from SESSION_ID...", "magenta");
      await fs.promises.mkdir(sessionDir, {
        recursive: true
      });
      try {
        await downloadSessionData();
        if (!hasUsableFileSession()) {
          throw new Error("creds.json was not written or is invalid after SESSION_ID bootstrap");
        }
        log("[ SESSION_ID ] ✅ Session bootstrap saved successfully.", "green");
      } catch (error384) {
        log("[ SESSION_ID ] ❌ Failed to bootstrap session: " + error384.message, "red", true);
        log("Retrying in 5 seconds...", "yellow");
        await delay(5000);
        return main();
      }
    }
    invalidateSQLiteAuth(juneDatabase._db, value379 ? "session-id-forced-bootstrap" : "session-id-bootstrap");
    rememberSessionIdFingerprint(value369);
    clearRevokedSessionIdFingerprint();
    await saveLoginMethod("session");
    log("[ SESSION_ID ] Connecting...", "cyan");
    await startJunexBot();
    checkEnvStatus();
    return;
  }
  if (value367 && value368) {
    if (value371.length > 0 && !value374) {
      clearRevokedSessionIdFingerprint();
    }
    if (!value372) {
      rememberSessionIdFingerprint(value369);
      log("[ AUTH ] Linked the existing verified SQLite auth to the configured SESSION_ID fingerprint.", "cyan");
    }
    log("[ AUTH ] Verified SQLite auth found; SESSION_ID is retained only as a recovery backup.", "green");
  } else if (value367 && value375) {
    if (!value372 && value369) {
      if (value373) {
        log("[ SESSION_ID ] Configured fingerprint differs; retaining usable file auth. Set JUNE_FORCE_SESSION_BOOTSTRAP=true only for an intentional replacement.", "yellow");
      }
      const value385 = rememberSessionIdFingerprint(value369);
      if (value385) {
        log("[ SESSION_ID ] Existing file auth adopted; fingerprint recorded in SQLite.", "green");
      }
    }
    if (value371.length > 0 && !value374) {
      clearRevokedSessionIdFingerprint();
    }
    await saveLoginMethod("session");
    log("[ SESSION_ID ] Existing usable file session retained; rebuilding SQLite auth if needed.", "cyan");
  } else {
    log("[ SESSION_ID ] No SESSION_ID in .env — checking for a saved session...", "yellow");
  }
  await checkSessionIntegrityAndClean();
  if (sessionExists()) {
    log("[ SESSION_ID ] Saved session found — continuing with it.", "green");
    await startJunexBot();
    checkEnvStatus();
    return;
  }
  if (hasVerifiedSQLiteAuth(juneDatabase._db)) {
    log("[ AUTH ] Verified SQLite auth found; starting without session files.", "green");
    await saveLoginMethod("session");
    await startJunexBot();
    checkEnvStatus();
    return;
  }
  const value386 = await restoreSessionFromDB();
  if (value386) {
    await saveLoginMethod("session");
    await startJunexBot();
    checkEnvStatus();
    return;
  }
  log(chalk.black.bgYellowBright("[ LOGIN ] No SESSION_ID found and no stored session. Launching login menu..."), "white");
  const value387 = await getLoginMethod();
  if (value387 === "session") {
    if (sessionServer.isJuneHandle(global.SESSION_ID)) {
      await connectViaSessionServer({
        sessionId: String(global.SESSION_ID).trim(),
        fingerprint: fingerprintSessionId(String(global.SESSION_ID).trim()),
        sqliteAuthReady: hasVerifiedSQLiteAuth(juneDatabase._db),
        forceBootstrap: true,
        usableFileSession: false
      });
      checkEnvStatus();
      return;
    }
    try {
      await downloadSessionData();
      if (!sessionExists()) {
        throw new Error("Session file was not written — SESSION_ID may be corrupt or expired.");
      }
      log("[ LOGIN ] ✅ Session ID accepted. Connecting...", "green");
    } catch (error388) {
      log("[ LOGIN ] ❌ Failed to load session: " + error388.message, "red", true);
      log("Please check your SESSION_ID and try again. Retrying in 5 seconds...", "yellow");
      await delay(5000);
      return main();
    }
  }
  await startJunexBot();
  checkEnvStatus();
}
function startKeepAliveServer() {
  const value389 = require("express");
  const value390 = require("http");
  const value391 = value389();
  const value392 = Date.now();
  value391.get("/", (value393, value394) => {
    const value395 = Date.now() - value392;
    const value396 = Math.floor(value395 / 1000);
    const value397 = Math.floor(value396 / 86400);
    const value398 = Math.floor(value396 % 86400 / 3600);
    const value399 = Math.floor(value396 % 3600 / 60);
    const value400 = value396 % 60;
    const value401 = value397 > 0 ? value397 + "d " + value398 + "h " + value399 + "m " + value400 + "s" : value398.toString().padStart(2, "0") + "h " + value399.toString().padStart(2, "0") + "m " + value400.toString().padStart(2, "0") + "s";
    const value402 = new Date();
    const value403 = value402.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric"
    });
    const value404 = detectPlatform();
    const value405 = global.botState === "connected";
    const value406 = global.currentSock?.user?.id?.split(":")[0];
    const value407 = value405 ? "OPERATIONAL • ACTIVE" : global.botState === "connecting" ? "CONNECTING" : "OFFLINE";
    const value408 = value405 ? "#00ffe0" : global.botState === "connecting" ? "#ffb703" : "#e94560";
    value394.send("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <meta http-equiv=\"refresh\" content=\"10\">\n  <title>June-X Ultra — Dashboard</title>\n  <style>\n    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=JetBrains+Mono:wght@400;600&display=swap');\n    * { margin: 0; padding: 0; box-sizing: border-box; }\n    body {\n      background: radial-gradient(circle at 20% 30%, #0a0f1e, #03060c);\n      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;\n      color: #e2f0ff;\n      min-height: 100vh;\n      display: flex;\n      flex-direction: column;\n      align-items: center;\n      justify-content: center;\n      padding: 2rem;\n      position: relative;\n      overflow-x: hidden;\n    }\n    body::before {\n      content: '';\n      position: fixed;\n      top: 0; left: 0;\n      width: 100%; height: 100%;\n      background-image: radial-gradient(2px 2px at 20px 30px, #00ffe0, rgba(0,0,0,0)), radial-gradient(1px 1px at 80px 140px, #ff6b35, rgba(0,0,0,0)), radial-gradient(3px 3px at 260px 80px, #00aaff, rgba(0,0,0,0));\n      background-size: 200px 200px, 180px 180px, 220px 220px;\n      background-repeat: no-repeat;\n      opacity: 0.3;\n      pointer-events: none;\n      animation: drift 60s linear infinite;\n    }\n    @keyframes drift {\n      0% { background-position: 0 0, 0 0, 0 0; }\n      100% { background-position: 400px 400px, 300px 300px, 500px 500px; }\n    }\n    .wrapper { max-width: 500px; width: 100%; z-index: 2; position: relative; }\n    .header { text-align: center; margin-bottom: 2.5rem; }\n    .bot-name {\n      font-family: 'JetBrains Mono', 'SF Mono', 'Cascadia Code', 'Consolas', 'Courier New', monospace;\n      font-size: 2.5rem;\n      font-weight: 700;\n      background: linear-gradient(135deg, #00ffe0, #ff6b35);\n      -webkit-background-clip: text;\n      background-clip: text;\n      color: transparent;\n      text-shadow: 0 0 20px rgba(0,255,224,0.3);\n      letter-spacing: -0.02em;\n      display: inline-block;\n      animation: glitch 3s infinite;\n    }\n    @keyframes glitch {\n      0%, 100% { transform: skew(0deg, 0deg); opacity: 1; }\n      95% { transform: skew(0deg, 0deg); opacity: 1; }\n      96% { transform: skew(2deg, 1deg); opacity: 0.8; text-shadow: -2px 0 #ff6b35, 2px 0 #00ffe0; }\n      97% { transform: skew(-1deg, -0.5deg); opacity: 0.9; }\n    }\n    .tagline { font-size: 0.8rem; letter-spacing: 4px; text-transform: uppercase; color: #7f9eb5; margin-top: 0.5rem; }\n    .status-badge {\n      display: inline-flex;\n      align-items: center;\n      gap: 10px;\n      background: rgba(0,255,224,0.1);\n      border-radius: 60px;\n      padding: 0.4rem 1.5rem;\n      margin-top: 1.2rem;\n      font-size: 0.75rem;\n      font-weight: 500;\n      letter-spacing: 1px;\n      backdrop-filter: blur(4px);\n    }\n    .dot {\n      width: 10px; height: 10px;\n      background: " + value408 + ";\n      border-radius: 50%;\n      box-shadow: 0 0 8px " + value408 + ";\n      animation: pulse 1.4s infinite;\n    }\n    @keyframes pulse {\n      0%, 100% { opacity: 1; transform: scale(1); }\n      50% { opacity: 0.4; transform: scale(0.8); }\n    }\n    .dashboard-grid { display: flex; flex-direction: column; align-items: center; gap: 1.5rem; margin-bottom: 2rem; }\n    .card {\n      width: 100%; max-width: 400px;\n      background: rgba(10, 20, 28, 0.65);\n      backdrop-filter: blur(12px);\n      border: 1px solid rgba(0, 255, 224, 0.2);\n      border-radius: 0;\n      padding: 1.5rem;\n      transition: transform 0.2s ease, border-color 0.2s;\n      box-shadow: 0 0 15px rgba(0, 255, 224, 0.2), 0 8px 20px rgba(0,0,0,0.2);\n      text-align: center;\n      position: relative;\n      overflow: hidden;\n    }\n    .card::before, .card::after {\n      content: '';\n      position: absolute;\n      width: 50px; height: 50px;\n      pointer-events: none;\n      transition: 0.3s;\n    }\n    .card::before { top: 0; left: 0; border-top: 2px solid #00ffe0; border-left: 2px solid #00ffe0; border-radius: 0 0 20px 0; box-shadow: -2px -2px 12px rgba(0,255,224,0.5); }\n    .card::after  { bottom: 0; right: 0; border-bottom: 2px solid #ff6b35; border-right: 2px solid #ff6b35; border-radius: 20px 0 0 0; box-shadow: 2px 2px 12px rgba(255,107,53,0.5); }\n    .card:hover::before { border-top-color: #ff6b35; border-left-color: #ff6b35; box-shadow: -2px -2px 18px #ff6b35; }\n    .card:hover::after  { border-bottom-color: #00ffe0; border-right-color: #00ffe0; box-shadow: 2px 2px 18px #00ffe0; }\n    .card:hover { transform: translateY(-4px); border-color: rgba(0, 255, 224, 0.6); box-shadow: 0 0 25px rgba(0,255,224,0.3), 0 15px 30px rgba(0,0,0,0.3); }\n    .card-title { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px; color: #6c8ea0; margin-bottom: 0.75rem; display: flex; align-items: center; justify-content: center; gap: 0.5rem; }\n    .card-value { font-family: 'JetBrains Mono', 'SF Mono', 'Cascadia Code', 'Consolas', 'Courier New', monospace; font-size: 1.6rem; font-weight: 600; color: #00ffe0; text-shadow: 0 0 6px rgba(0,255,224,0.3); line-height: 1.2; word-break: break-word; }\n    .card-value.small { font-size: 1.2rem; }\n    .card-sub { font-size: 0.65rem; color: #8aaec0; margin-top: 0.6rem; border-top: 1px dashed rgba(0,255,224,0.2); padding-top: 0.6rem; }\n    .footer { text-align: center; margin-top: 2rem; font-size: 0.7rem; color: #5a7c8c; letter-spacing: 1px; text-transform: uppercase; }\n    .footer strong { color: #00ffe0; }\n    .refresh-note { text-align: center; font-size: 0.65rem; margin-top: 1rem; opacity: 0.6; }\n    @media (max-width: 480px) {\n      body { padding: 1rem; }\n      .bot-name { font-size: 1.8rem; }\n      .card-value { font-size: 1.3rem; }\n      .card-value.small { font-size: 1rem; }\n      .card { max-width: 100%; }\n    }\n  </style>\n</head>\n<body>\n<div class=\"wrapper\">\n  <div class=\"header\">\n    <div class=\"bot-name\">June-X Ultra</div>\n    <div class=\"tagline\">Autonomous Bot Matrix</div>\n    <div class=\"status-badge\">\n      <span class=\"dot\"></span> " + value407 + "\n    </div>\n  </div>\n  <div class=\"dashboard-grid\">\n    <div class=\"card\">\n      <div class=\"card-title\">🖥️ PLATFORM</div>\n      <div class=\"card-value small\">" + value404 + "</div>\n      <div class=\"card-sub\">deployment environment</div>\n    </div>\n    <div class=\"card\">\n      <div class=\"card-title\">⏱ UPTIME</div>\n      <div class=\"card-value\">" + value401 + "</div>\n      <div class=\"card-sub\">continuous runtime</div>\n    </div>\n    <div class=\"card\">\n      <div class=\"card-title\">📅 DATE</div>\n      <div class=\"card-value small\">" + value403 + "</div>\n      <div class=\"card-sub\">local server date</div>\n    </div>\n    <div class=\"card\">\n      <div class=\"card-title\">📶 CONNECTION</div>\n      <div class=\"card-value small\">" + (value405 ? "+" + value406 : value407) + "</div>\n      <div class=\"card-sub\">whatsapp session</div>\n    </div>\n  </div>\n  <div class=\"footer\">\n    ⚡ Powered by <strong>supreme</strong> &nbsp;|&nbsp; June-X Ultra\n  </div>\n  <div class=\"refresh-note\">⟳ dashboard auto-refreshes every 10 seconds</div>\n</div>\n</body>\n</html>");
  });
  value391.get("/health", (value409, value410) => value410.status(200).send("OK"));
  value391.get("/health/details", async (value411, value412) => {
    try {
      const value413 = juneDatabase.getDatabaseHealth();
      const value414 = getSQLiteAuthStats(juneDatabase._db);
      let value415 = null;
      try {
        value415 = require("./commands/owner/antidelete").getStoreStats();
      } catch (error416) {}
      value412.json({
        ok: value413.ok === true && (!value413.backupExists || value413.backupValid === true),
        botState: global.botState || "unknown",
        database: {
          sizeBytes: value413.databaseSizeBytes,
          backupSizeBytes: value413.backupSizeBytes,
          backupExists: value413.backupExists,
          backupValid: value413.backupValid,
          dirty: value413.dirty,
          lastBackup: value413.lastBackup,
          integrity: value413.lastIntegrityCheck,
          maintenance: value413.maintenance,
          remoteSync: value413.remoteSync,
          authMirror: value413.authMirror,
          postgres: value413.postgres,
          mongo: value413.mongo
        },
        stability: {
          replayDrain: replayDrain.getStats()
        },
        auth: {
          verified: value414.verified,
          hasCreds: value414.hasCreds,
          totalKeys: value414.totalKeys,
          byType: value414.byType,
          pendingFileMigration: value414.pendingFileMigration,
          invalidReason: value414.invalidReason
        },
        antiDelete: value415,
        storage: diskManager?.getReport?.() || null,
        telemetry: {
          stats: (() => {
            const value417 = juneDatabase.getRuntimeTelemetry(1000);
            return {
              total: value417.length,
              eventTypes: value417.reduce((value418, value419) => {
                value418[value419.eventType] = (value418[value419.eventType] || 0) + value419.count;
                return value418;
              }, {})
            };
          })()
        }
      });
    } catch (error420) {
      value412.status(503).json({
        ok: false,
        error: error420.message
      });
    }
  });
  const value421 = value390.createServer(value391);
  const value422 = process.env.PORT ? [parseInt(process.env.PORT, 10)] : [5000, 3000, 8000, 4000];
  let value423 = 0;
  function handler424() {
    if (value423 >= value422.length) {
      return;
    }
    const value425 = value422[value423];
    value421.listen(value425, "0.0.0.0");
    value421.once("listening", () => {
      const value426 = process.env.APP_URL || "http://localhost:" + value425 + "/health";
      setInterval(() => {
        value390.get(value426, value427 => {}).on("error", () => {});
      }, 240000);
    });
    value421.once("error", value428 => {
      if (value428.code === "EADDRINUSE") {
        value423++;
        handler424();
      }
    });
  }
  handler424();
  return value421;
}
let keepAliveServer = null;
global.__JUNE_SHUTDOWN = async () => {
  if (global._shutdownPromise) {
    return global._shutdownPromise;
  }
  global._shutdownRequested = true;
  global._shutdownPromise = (async () => {
    log("[ SHUTDOWN ] Gracefully stopping June-X...", "yellow");
    if (global._reconnectTimer) {
      clearTimeout(global._reconnectTimer);
      global._reconnectTimer = null;
    }
    for (const value429 of global._activeIntervals || []) {
      clearInterval(value429);
    }
    global._activeIntervals = [];
    try {
      global._envWatcher?.close?.();
    } catch (error430) {}
    try {
      diskManager?.stop?.();
    } catch (error431) {}
    try {
      stopScheduledCleanups();
    } catch (error432) {}
    try {
      global.__JUNE_FLUSH_ANTIDELETE?.();
    } catch (error433) {}
    try {
      global.__JUNE_FLUSH_GROUP_STATS?.();
    } catch (error434) {}
    try {
      const value435 = global.currentSock;
      if (value435?.ws?.close) {
        value435.ws.close();
      } else if (value435?.end) {
        value435.end(new Error("process shutdown"));
      }
    } catch (error436) {}
    try {
      keepAliveServer?.close?.();
    } catch (error437) {}
    try {
      await juneDatabase.shutdownDatabase();
    } catch (error438) {
      log("[ SHUTDOWN ] Database flush failed: " + error438.message, "red", true);
    }
    log("[ SHUTDOWN ] Complete.", "green");
  })();
  return global._shutdownPromise;
};
for (const juneSignal of ["SIGINT", "SIGTERM"]) {
  process.on(juneSignal, () => {
    global.__JUNE_SHUTDOWN().then(() => process.exit(0)).catch(() => process.exit(0));
  });
}
keepAliveServer = startKeepAliveServer();
main().catch(value439 => log("Fatal error: " + value439.message, "red", true));
process.on("uncaughtException", value440 => {
  if (value440.code === "ENOSPC" || value440.errno === -28) {
    log("⚠️ ENOSPC: No space left on device. Attempting cleanup...", "yellow");
    runFileSweep(null);
    return;
  }
  log("Uncaught Exception: " + value440.message, "red", true);
});
process.on("unhandledRejection", value441 => {
  if (value441?.code === "ENOSPC" || value441?.errno === -28) {
    log("⚠️ ENOSPC in promise.", "yellow");
    return;
  }
  if (value441?.message?.includes("rate-overlimit")) {
    return;
  }
  if (value441?.message?.includes("AUTH_STARTUP_VALIDATION_FAILED")) {
    log("[ AUTH ] Startup recovery stopped safely: " + value441.message.replace(/^AUTH_STARTUP_VALIDATION_FAILED:\s*/, ""), "yellow");
    log("[ AUTH ] No auth data was cleared. Restore a known-good backup or explicitly re-pair.", "yellow");
    return;
  }
  log("Unhandled Rejection: " + value441?.message, "red", true);
});
module.exports = {
  store: store
};
