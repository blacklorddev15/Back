module.exports = {
  name: "q",
  aliases: ["quotedinfo"],
  category: "tools",
  description: "Get detailed information about a quoted message",
  usage: ".q (reply to any message)",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value2.message?.extendedTextMessage?.contextInfo;
      if (!value5?.quotedMessage) {
        return value4.reply("❌ Reply to the message you want to inspect.");
      }
      const value6 = Object.keys(value5.quotedMessage)[0] || "unknown";
      const value7 = value5.quotedMessage;
      const value8 = {
        type: value6,
        sender: value5.participant || value5.remoteJid || "unknown",
        chat: value4.from,
        stanzaId: value5.stanzaId || "",
        text: value7?.conversation || value7?.extendedTextMessage?.text || "",
        caption: value7?.imageMessage?.caption || value7?.videoMessage?.caption || value7?.documentMessage?.caption || "",
        mimetype: value7?.imageMessage?.mimetype || value7?.videoMessage?.mimetype || value7?.audioMessage?.mimetype || value7?.documentMessage?.mimetype || "",
        fileName: value7?.documentMessage?.fileName || "",
        isForwarded: value7?.[value6]?.isForwarded || false,
        forwardingScore: value7?.[value6]?.forwardingScore || 0,
        hasMedia: ["imageMessage", "videoMessage", "audioMessage", "documentMessage", "stickerMessage"].includes(value6)
      };
      await value1.sendMessage(value4.from, {
        text: "📋 *Quoted Message Info*\n\n```json\n" + JSON.stringify(value8, null, 2) + "\n```"
      }, {
        quoted: value2
      });
    } catch (error9) {
      console.error("[QUOTEDINFO ERROR]", error9);
      await value4.reply("❌ Failed to fetch quoted message information.");
    }
  }
};
