const fs = require("fs");
const path = require("path");
const os = require("os");
const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
let JsConfuser = null;
const getJsConfuser = () => JsConfuser ||= require("js-confuser");
module.exports = {
  name: "encrypt",
  aliases: ["enc"],
  category: "tools",
  description: "Encrypt/obfuscate a JavaScript file with hard code protection",
  usage: ".enc (reply to a .js file)",
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6,
      isOwner: value7
    } = value4;
    try {
      await value1.sendMessage(value5, {
        react: {
          text: "🔐",
          key: value2.key
        }
      });
      const value8 = value2.key.participant || value2.key.remoteJid;
      const value9 = path.join(os.tmpdir(), "june-x-temp");
      if (!fs.existsSync(value9)) {
        fs.mkdirSync(value9, {
          recursive: true
        });
      }
      const value10 = value2.message?.extendedTextMessage?.contextInfo?.quotedMessage || value2.message?.imageMessage?.contextInfo?.quotedMessage || value2.message?.videoMessage?.contextInfo?.quotedMessage || value2.message?.audioMessage?.contextInfo?.quotedMessage || value2.message?.stickerMessage?.contextInfo?.quotedMessage;
      if (!value10) {
        return value6("🔐 *Encrypt Command Usage*\n\nReply to a JavaScript (.js) file with `.enc` or `.encrypt`\n\n📌 *Example:*\n1. Send a .js file\n2. Reply to it with `.enc`\n\n✨ *Features:*\n• Hard code obfuscation\n• Variable renaming\n• String encoding\n• Control flow flattening");
      }
      const value11 = value10.documentMessage;
      if (!value11 || !value11.fileName || !value11.fileName.endsWith(".js")) {
        return value6("❌ *Invalid File*\nPlease reply to a JavaScript (.js) file to encrypt.");
      }
      const value12 = await downloadContentFromMessage(value11, "document");
      let value13 = Buffer.from([]);
      for await (const value14 of value12) {
        value13 = Buffer.concat([value13, value14]);
      }
      if (!value13 || value13.length === 0) {
        throw new Error("Failed to download the file or file is empty!");
      }
      const value15 = value13.length;
      const value16 = (value15 / 1024).toFixed(2);
      if (value15 > 5242880) {
        return value6("❌ *File Too Large*\nMaximum file size is 5MB for encryption.");
      }
      const value17 = value11.fileName;
      const value18 = value13.toString("utf8");
      await value1.sendMessage(value5, {
        react: {
          text: "⚙️",
          key: value2.key
        }
      });
      const value19 = await getJsConfuser().obfuscate(value18, {
        target: "node",
        preset: "high",
        compact: true,
        minify: true,
        flatten: true,
        identifierGenerator: function () {
          const value20 = "晴素晴素晴ˢᵁᴾᴿᴱᴹᴱ素晴晴素晴晴ˢᵁᴾᴿᴱᴹᴱ素晴晴";
          const value21 = value22 => value22.replace(/[^a-zA-Z素GIDDY晴TENNOR晴]/g, "");
          const value23 = value24 => {
            let value25 = "";
            const value26 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            for (let value27 = 0; value27 < value24; value27++) {
              value25 += value26.charAt(Math.floor(Math.random() * value26.length));
            }
            return value25;
          };
          return value21(value20) + value23(2);
        },
        renameVariables: true,
        renameGlobals: true,
        stringEncoding: true,
        stringSplitting: 0,
        stringConcealing: true,
        stringCompression: true,
        duplicateLiteralsRemoval: 1,
        shuffle: {
          hash: 0,
          true: 0
        },
        stack: true,
        controlFlowFlattening: 1,
        opaquePredicates: 0.9,
        deadCode: 0,
        dispatcher: true,
        rgf: false,
        calculator: true,
        hexadecimalNumbers: true,
        movedDeclarations: true,
        objectExtraction: true,
        globalConcealing: true
      });
      const value28 = Buffer.byteLength(value19, "utf8");
      const value29 = (value28 / 1024).toFixed(2);
      const value30 = ((value28 - value15) / value15 * 100).toFixed(2);
      const value31 = Date.now();
      const value32 = path.join(value9, "encrypted_" + value31 + ".js");
      fs.writeFileSync(value32, value19);
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        document: Buffer.from(value19, "utf8"),
        mimetype: "application/javascript",
        fileName: value17
      }, {
        quoted: value2
      });
      if (fs.existsSync(value32)) {
        fs.unlinkSync(value32);
      }
    } catch (error33) {
      console.error("Encrypt command error:", error33);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      let value34 = "🚫 *Encryption Error:* " + error33.message;
      if (error33.message.includes("syntax")) {
        value34 = "❌ *Syntax Error!*\nThe JavaScript file contains syntax errors that prevent encryption.";
      } else if (error33.message.includes("download")) {
        value34 = "❌ *Download Failed!*\nCould not download the file. Please try again.";
      } else if (error33.message.includes("timeout")) {
        value34 = "⏱️ *Encryption Timeout!*\nThe file might be too complex. Try with a simpler script.";
      }
      return value6(value34);
    }
  }
};
