const {
  sendButtons
} = require("gifted-btns");
const {
  applyFont
} = require("../../utils/fontConverter");
const axios = require("axios");
const config = (() => {
  const value16 = require("../../database");
  return {
    get prefix() {
      return value16.getBotSetting("prefix");
    },
    get botName() {
      return value16.getBotSetting("botName");
    }
  };
})();
const fs = require("fs");
const path = require("path");
const os = require("os");
const GITHUB_USER = "Vinpink2";
const GITHUB_REPO = "June-Ultra";
const REPO_URL = "https://github.com/" + GITHUB_USER + "/" + GITHUB_REPO;
const API_URL = "https://api.github.com/repos/" + GITHUB_USER + "/" + GITHUB_REPO;
function extractButtonResponseId(value20) {
  return value20.message?.buttonsResponseMessage?.selectedButtonId || value20.message?.templateButtonReplyMessage?.selectedId || value20.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || null;
}
function getResponseSender(value29) {
  return value29.key?.participant || value29.key?.remoteJid;
}
function buildMainButtons(value54, value55) {
  const value56 = config.prefix || ".";
  return [{
    name: "cta_url",
    buttonParamsJson: JSON.stringify({
      display_text: "🔗 Open Repo",
      url: value54
    })
  }, {
    name: "cta_copy",
    buttonParamsJson: JSON.stringify({
      display_text: "📋 Copy Repo URL",
      copy_code: value54
    })
  }, {
    id: value56 + "ghzip_" + value55,
    text: "📦 Download ZIP"
  }];
}
module.exports = {
  name: "github",
  aliases: ["repo", "git", "source", "rp", "script"],
  category: "tools",
  description: "Show bot GitHub repository and statistics",
  usage: ".github",
  ownerOnly: false,
  async execute(value63, value64, value65, value66) {
    try {
      const value73 = value66.from;
      const value74 = config.prefix || ".";
      const value75 = value64.key?.participant || value64.key?.remoteJid;
      const value76 = "Powered by " + config.botName;
      const value77 = Date.now();
      let value78;
      let value79 = REPO_URL;
      let value80 = "main";
      try {
        const {
          data: value81
        } = await axios.get(API_URL, {
          headers: {
            "User-Agent": "June_X_Ultra"
          },
          timeout: 10000
        });
        value79 = value81.html_url;
        value80 = value81.default_branch || "main";
        value78 = applyFont("┏━━━━━━━━━━━━━━━━\n\n" + ("✧ Repository:  " + value81.name + "\n") + ("✧ Owner:       " + value81.owner.login + "\n") + ("✧ Description: " + (value81.description || "N/A") + "\n") + ("✧ Language:    " + (value81.language || "N/A") + "\n") + ("✧ License:     " + (value81.license?.name || "N/A") + "\n") + ("✧ Branch:      " + value80 + "\n") + ("✧ Visibility:  " + (value81.private ? "🔒 Private" : "🔓 Public") + "\n\n") + "┗━━━━━━━━━━━━━━━━━\n┏━━━━━━━━━━━━━━━━━\n\n⿻ STATISTICS\n" + ("⿻ Stars:       " + value81.stargazers_count.toLocaleString() + "\n") + ("⿻ Forks:       " + value81.forks_count.toLocaleString() + "\n") + ("⿻ Watchers:    " + value81.watchers_count.toLocaleString() + "\n") + ("⿻ Size:        " + (value81.size / 1024).toFixed(2) + " MB\n") + ("⿻ Issues:      " + value81.open_issues_count.toLocaleString() + "\n\n") + "┗━━━━━━━━━━━━━━━━");
      } catch (error82) {
        console.error("[GitHub] API error:", error82.message);
        value78 = applyFont("┏━━『 GITHUB REPOSITORY 』━━\n\n" + ("🤖 Bot Name:   " + config.botName + "\n") + ("📁 Repository: " + GITHUB_REPO + "\n") + ("👤 Owner:      " + GITHUB_USER + "\n") + ("🔗 URL:        " + REPO_URL + "\n\n") + "⚠️ Could not fetch live stats.\n   Visit the repo for latest info.\n\n┗━━━━━━━━━━━━━━━━");
      }
      const value83 = path.join(__dirname, "../../utils/menu1.jpg");
      const value84 = fs.existsSync(value83) ? fs.readFileSync(value83) : null;
      await sendButtons(value63, value73, {
        image: value84 ? {
          buffer: value84,
          mimetype: "image/jpeg"
        } : undefined,
        text: value78,
        footer: value76,
        buttons: buildMainButtons(value79, value77)
      }, {
        quoted: value64
      });
      const value85 = async value86 => {
        const value93 = value86.messages[0];
        if (!value93?.message) {
          return;
        }
        const value94 = extractButtonResponseId(value93);
        if (!value94) {
          return;
        }
        if (value94 !== value74 + "ghzip_" + value77) {
          return;
        }
        if (value93.key?.remoteJid !== value73) {
          return;
        }
        const value95 = getResponseSender(value93);
        if (value95 !== value75) {
          return;
        }
        value63.ev.off("messages.upsert", value85);
        await value63.sendMessage(value73, {
          react: {
            text: "⏳",
            key: value64.key
          }
        });
        const value96 = value79 + "/archive/refs/heads/" + value80 + ".zip";
        let value97;
        try {
          value97 = path.join(os.tmpdir(), GITHUB_REPO + "-" + value77 + ".zip");
          const value98 = await axios({
            method: "get",
            url: value96,
            responseType: "stream",
            timeout: 120000,
            headers: {
              "User-Agent": "June_X_Ultra"
            },
            maxRedirects: 5
          });
          const value99 = fs.createWriteStream(value97);
          value98.data.pipe(value99);
          await new Promise((value100, value101) => {
            value99.on("finish", value100);
            value99.on("error", value101);
          });
          if (!fs.existsSync(value97) || fs.statSync(value97).size === 0) {
            throw new Error("ZIP download failed — file is empty");
          }
          const value108 = (fs.statSync(value97).size / 1048576).toFixed(2);
          await value63.sendMessage(value73, {
            document: fs.readFileSync(value97),
            mimetype: "application/zip",
            fileName: GITHUB_REPO + ".zip",
            caption: applyFont("┏━━『 ZIP DOWNLOADED 』━━\n\n" + ("📁 Repository: " + GITHUB_REPO + "\n") + ("🌿 Branch:     " + value80 + "\n") + ("💾 Size:       " + value108 + " MB\n\n") + "┗━━━━━━━━━━━━━━━━\n\n" + ("> " + config.botName))
          }, {
            quoted: value93
          });
          await value63.sendMessage(value73, {
            react: {
              text: "✅",
              key: value64.key
            }
          });
        } catch (error109) {
          console.error("[GitHub] ZIP download error:", error109.message);
          await value63.sendMessage(value73, {
            react: {
              text: "❌",
              key: value64.key
            }
          });
          await value63.sendMessage(value73, {
            text: applyFont("┏━━『 ERROR 』━━\n\n❌ Failed: ZIP Download\n" + ("⚠️ Reason: " + error109.message + "\n\n") + "  Try copying the link instead.\n\n┗━━━━━━━━━━━━━━━━")
          }, {
            quoted: value93
          });
        } finally {
          if (value97 && fs.existsSync(value97)) {
            fs.unlinkSync(value97);
          }
        }
      };
      value63.ev.on("messages.upsert", value85);
      setTimeout(() => value63.ev.off("messages.upsert", value85), 300000);
    } catch (error110) {
      console.error("[GitHub] command error:", error110);
      await value66.reply("❌ Error: " + error110.message);
    }
  }
};
