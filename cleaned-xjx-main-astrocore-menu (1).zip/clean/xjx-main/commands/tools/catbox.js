const axios = require("axios");
const FormData = require("form-data");
const {
  sendButtons
} = require("gifted-btns");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const database = require("../../database");
const PONE_BASE = "https://pone.rs";
const UPLOAD_ATTEMPTS = [{
  endpoint: PONE_BASE + "/upload.php",
  field: "files[]"
}, {
  endpoint: PONE_BASE + "/upload",
  field: "files[]"
}, {
  endpoint: PONE_BASE + "/upload",
  field: "file"
}];
function extractUrl(value1) {
  if (!value1) {
    return null;
  }
  if (typeof value1 === "string") {
    const value2 = value1.trim();
    try {
      return extractUrl(JSON.parse(value2));
    } catch {
      const value3 = value2.match(/https?:\/\/[^\s"'<>]+/);
      if (value3) {
        return value3[0];
      } else {
        return null;
      }
    }
  }
  if (Array.isArray(value1)) {
    for (const value4 of value1) {
      const value5 = extractUrl(value4);
      if (value5) {
        return value5;
      }
    }
    return null;
  }
  if (typeof value1 === "object") {
    if (typeof value1.url === "string" && value1.url.startsWith("http")) {
      return value1.url;
    }
    if (value1.files) {
      const value6 = extractUrl(value1.files);
      if (value6) {
        return value6;
      }
    }
    if (value1.data) {
      const value7 = extractUrl(value1.data);
      if (value7) {
        return value7;
      }
    }
    if (typeof value1.url === "string") {
      return PONE_BASE + "/" + value1.url.replace(/^\//, "");
    }
  }
  return null;
}
async function uploadToPone(value8, value9, value10) {
  let value11;
  for (const {
    endpoint: value12,
    field: value13
  } of UPLOAD_ATTEMPTS) {
    try {
      const value14 = new FormData();
      value14.append(value13, value8, {
        filename: value9,
        contentType: value10
      });
      const {
        data: value15
      } = await axios.post(value12, value14, {
        headers: {
          ...value14.getHeaders(),
          "User-Agent": "Mozilla/5.0"
        },
        timeout: 60000,
        maxBodyLength: Infinity,
        maxContentLength: Infinity
      });
      const value16 = extractUrl(value15);
      if (value16) {
        return value16;
      }
      value11 = new Error("Unexpected response from pone.rs");
    } catch (error17) {
      value11 = error17;
    }
  }
  throw value11 || new Error("Upload failed or was rejected by pone.rs");
}
module.exports = {
  name: "tourl",
  aliases: ["pone", "upload", "tolink"],
  category: "tools",
  description: "Upload a file to pone.rs via URL or quoted media (permanent hosting)",
  usage: ".tourl <file-url> or reply to media",
  async execute(value18, value19, value20, value21) {
    try {
      await value18.sendMessage(value21.from, {
        react: {
          text: "⏳",
          key: value19.key
        }
      });
      let value22;
      let value23;
      let value24;
      let value25;
      const value26 = value19.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (value26) {
        const value27 = value26.imageMessage ? "imageMessage" : value26.videoMessage ? "videoMessage" : value26.audioMessage ? "audioMessage" : value26.documentMessage ? "documentMessage" : value26.stickerMessage ? "stickerMessage" : null;
        if (!value27) {
          return value21.reply("❌ Quoted message has no supported media!");
        }
        const value28 = value26[value27];
        const value29 = {
          key: value19.message.extendedTextMessage.contextInfo.stanzaId ? {
            ...value19.key,
            id: value19.message.extendedTextMessage.contextInfo.stanzaId
          } : value19.key,
          message: value26
        };
        value22 = await downloadMediaMessage(value29, "buffer", {}, {
          logger: value18.logger
        });
        value24 = value28.mimetype || "application/octet-stream";
        const value30 = value24.split("/")[1]?.split(";")[0] || "bin";
        value23 = value28.fileName || "upload_" + Date.now() + "." + value30;
        value25 = (value22.byteLength / 1024).toFixed(1);
      } else {
        const value31 = value20.join(" ").trim();
        if (!value31) {
          return value21.reply("❌ Please provide a file URL or reply to a media message!\nExample:\n.tourl https://example.com/image.png");
        }
        const value32 = await axios.get(value31, {
          responseType: "arraybuffer",
          timeout: 30000,
          maxContentLength: 209715200
        });
        const value33 = value32.headers["content-disposition"];
        if (value33) {
          const value34 = value33.match(/filename="?([^";\n]+)"?/);
          if (value34) {
            value23 = value34[1].trim();
          }
        }
        if (!value23) {
          const value35 = value31.split("?")[0];
          value23 = value35.split("/").pop() || "upload_" + Date.now();
        }
        value24 = value32.headers["content-type"] || "application/octet-stream";
        value22 = Buffer.from(value32.data);
        value25 = (value22.byteLength / 1024).toFixed(1);
      }
      const value36 = await uploadToPone(value22, value23, value24);
      if (!value36 || !value36.startsWith("http")) {
        throw new Error("Upload failed or was rejected by pone.rs");
      }
      await value18.sendMessage(value21.from, {
        react: {
          text: "✅",
          key: value19.key
        }
      });
      const value37 = value36.split("/").pop();
      const value38 = " *📦 File Hosted on pone.rs*\n\n" + (" *File:* " + value37 + "\n") + (" *Size:* " + value25 + " KB\n") + (" *Hosted:* " + value36 + "\n\n") + " ♾️ _This link is permanent_";
      await sendButtons(value18, value21.from, {
        text: value38,
        footer: "> Powered by " + database.getBotSetting("botName"),
        buttons: [{
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🌐 Open File",
            url: value36
          })
        }, {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "📋 Copy Link",
            copy_code: value36
          })
        }]
      }, {
        quoted: value19
      });
    } catch (error39) {
      console.error("TOURL ERROR:", error39);
      await value18.sendMessage(value21.from, {
        react: {
          text: "❌",
          key: value19.key
        }
      });
      let value40 = "❌ Failed to upload to pone.rs: ";
      if (error39.code === "ECONNABORTED") {
        value40 += "Request timed out (file may be too large)";
      } else if (error39.code === "ERR_FR_MAX_BODY_LENGTH_EXCEEDED") {
        value40 += "File exceeds the 200MB limit";
      } else {
        value40 += error39.message || "Unknown error";
      }
      await value21.reply(value40);
    }
  }
};
