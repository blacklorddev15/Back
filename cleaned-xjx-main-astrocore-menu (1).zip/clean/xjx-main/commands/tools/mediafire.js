const axios = require("axios");
const cheerio = require("cheerio");
module.exports = {
  name: "mediafire",
  aliases: ["mf"],
  category: "tools",
  description: "Download a file from a MediaFire link",
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    const value6 = value3[0];
    if (!value6 || !value6.includes("mediafire.com")) {
      return value1.sendMessage(value5, {
        text: "◆ *MEDIAFIRE DOWNLOADER*\n\nProvide a valid MediaFire link.\n\n*Usage:* .mediafire <link>"
      }, {
        quoted: value2
      });
    }
    try {
      const {
        data: value7
      } = await axios.get(value6, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
        },
        timeout: 15000
      });
      const value8 = cheerio.load(value7);
      const value9 = value8("a#downloadButton").attr("href") || value8("a.popsok").attr("href") || value8("[aria-label=\"Download file\"]").attr("href");
      const value10 = value8(".filename").text().trim() || value8("meta[property=\"og:title\"]").attr("content") || "downloaded_file";
      const value11 = value8(".subheading").first().text().trim() || value8(".file-size").text().trim() || "Unknown";
      if (!value9) {
        return value1.sendMessage(value5, {
          text: "❌ Could not extract download link. The file may be private or removed."
        }, {
          quoted: value2
        });
      }
      const value12 = await axios.get(value9, {
        responseType: "arraybuffer",
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        },
        timeout: 60000,
        maxContentLength: 104857600
      });
      const value13 = Buffer.from(value12.data);
      const value14 = value12.headers["content-type"] || "application/octet-stream";
      await value1.sendMessage(value5, {
        document: value13,
        mimetype: value14,
        fileName: value10,
        caption: "◆ *" + value10 + "*\n◇ Via MediaFire Downloader"
      }, {
        quoted: value2
      });
    } catch (error15) {
      console.error("[mediafire]", error15.message);
      await value1.sendMessage(value5, {
        text: "❌ Failed to download.\n\n_" + error15.message + "_"
      }, {
        quoted: value2
      });
    }
  }
};
