const fs = require("fs");
const path = require("path");
const os = require("os");
const {
  execFile
} = require("child_process");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const {
  toPTT
} = require("../../utils/converter");
const {
  resolveQuoted
} = require("../../utils/quotedMedia");
const ffmpegPath = require("../../utils/ffmpegPath");
const TEMP_DIR = path.join(os.tmpdir(), "june-x-audio");
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, {
    recursive: true
  });
}
function rand(value1) {
  return path.join(TEMP_DIR, Date.now() + "_" + Math.floor(Math.random() * 9999) + value1);
}
async function downloadAudio(value2, value3) {
  const value4 = resolveQuoted(value3);
  if (!value4) {
    return null;
  }
  const {
    quotedMessage: value5,
    fullQuoted: value6
  } = value4;
  if (!value5.audioMessage) {
    return null;
  }
  const value7 = await downloadMediaMessage(value6, "buffer", {}, {
    logger: undefined
  });
  const value8 = rand(".ogg");
  fs.writeFileSync(value8, value7);
  return {
    inputPath: value8,
    buffer: value7
  };
}
function runFfmpeg(value9, value10, value11) {
  return new Promise((value12, value13) => {
    execFile(ffmpegPath(), ["-y", "-i", value9, ...value11, value10], value14 => {
      try {
        fs.unlinkSync(value9);
      } catch (error15) {}
      if (value14) {
        return value13(value14);
      }
      value12();
    });
  });
}
async function applyEffect(value16, value17, value18, value19) {
  const value20 = value17.key.remoteJid;
  const value21 = resolveQuoted(value17);
  if (!value21?.quotedMessage?.audioMessage) {
    return value19("Reply to an *audio file* with this command to apply the effect.");
  }
  try {
    const {
      inputPath: value22,
      buffer: value23
    } = (await downloadAudio(value16, value17)) || {};
    if (!value22) {
      return value19("Reply to an *audio file* with this command.");
    }
    const value24 = rand(".mp3");
    await runFfmpeg(value22, value24, value18);
    if (!fs.existsSync(value24) || fs.statSync(value24).size === 0) {
      throw new Error("FFmpeg produced no output");
    }
    const value25 = fs.readFileSync(value24);
    fs.unlinkSync(value24);
    await value16.sendMessage(value20, {
      audio: value25,
      mimetype: "audio/mpeg",
      fileName: "effect.mp3"
    }, {
      quoted: value17
    });
  } catch (error26) {
    value19("🚫 Error: " + error26.message);
  }
}
module.exports = [{
  name: "bass",
  aliases: ["bassboost"],
  category: "tools",
  description: "Add bass boost to an audio file",
  usage: ".bass (reply to audio)",
  async execute(value27, value28, value29, {
    reply: value30
  }) {
    await value27.sendMessage(value28.key.remoteJid, {
      react: {
        text: "🔊",
        key: value28.key
      }
    });
    await applyEffect(value27, value28, ["-af", "equalizer=f=54:width_type=o:width=2:g=20"], value30);
  }
}, {
  name: "blown",
  aliases: [],
  category: "tools",
  description: "Apply blown/pitched-down effect to audio",
  usage: ".blown (reply to audio)",
  async execute(value31, value32, value33, {
    reply: value34
  }) {
    await value31.sendMessage(value32.key.remoteJid, {
      react: {
        text: "💨",
        key: value32.key
      }
    });
    await applyEffect(value31, value32, ["-af", "atempo=4/4,asetrate=44500*2/3"], value34);
  }
}, {
  name: "earrape",
  aliases: [],
  category: "tools",
  description: "Apply ear-rape (extreme volume) effect to audio",
  usage: ".earrape (reply to audio)",
  async execute(value35, value36, value37, {
    reply: value38
  }) {
    await value35.sendMessage(value36.key.remoteJid, {
      react: {
        text: "📢",
        key: value36.key
      }
    });
    await applyEffect(value35, value36, ["-af", "volume=12"], value38);
  }
}, {
  name: "volaudio",
  aliases: ["volume"],
  category: "tools",
  description: "Boost the volume of an audio file (2x)",
  usage: ".volaudio (reply to audio)",
  async execute(value39, value40, value41, {
    reply: value42
  }) {
    await value39.sendMessage(value40.key.remoteJid, {
      react: {
        text: "🔉",
        key: value40.key
      }
    });
    await applyEffect(value39, value40, ["-filter:a", "volume=2.0"], value42);
  }
}, {
  name: "treble",
  aliases: ["trebleboost"],
  category: "tools",
  description: "Boost treble frequencies of an audio file",
  usage: ".treble (reply to audio)",
  async execute(value43, value44, value45, {
    reply: value46
  }) {
    await value43.sendMessage(value44.key.remoteJid, {
      react: {
        text: "🎶",
        key: value44.key
      }
    });
    await applyEffect(value43, value44, ["-af", "equalizer=f=10000:width_type=o:width=2:g=15"], value46);
  }
}, {
  name: "fast",
  aliases: ["speedup"],
  category: "tools",
  description: "Speed up an audio file (1.5x)",
  usage: ".fast (reply to audio)",
  async execute(value47, value48, value49, {
    reply: value50
  }) {
    await value47.sendMessage(value48.key.remoteJid, {
      react: {
        text: "⏩",
        key: value48.key
      }
    });
    await applyEffect(value47, value48, ["-filter:a", "atempo=1.5"], value50);
  }
}, {
  name: "slow",
  aliases: ["slowdown"],
  category: "tools",
  description: "Slow down an audio file (0.8x)",
  usage: ".slow (reply to audio)",
  async execute(value51, value52, value53, {
    reply: value54
  }) {
    await value51.sendMessage(value52.key.remoteJid, {
      react: {
        text: "⏪",
        key: value52.key
      }
    });
    await applyEffect(value51, value52, ["-filter:a", "atempo=0.8"], value54);
  }
}, {
  name: "reverse",
  aliases: ["audioreverse"],
  category: "tools",
  description: "Reverse an audio file",
  usage: ".reverse (reply to audio)",
  async execute(value55, value56, value57, {
    reply: value58
  }) {
    await value55.sendMessage(value56.key.remoteJid, {
      react: {
        text: "🔄",
        key: value56.key
      }
    });
    await applyEffect(value55, value56, ["-filter_complex", "areverse"], value58);
  }
}, {
  name: "echo",
  aliases: ["audioecho"],
  category: "tools",
  description: "Add echo effect to an audio file",
  usage: ".echo (reply to audio)",
  async execute(value59, value60, value61, {
    reply: value62
  }) {
    await value59.sendMessage(value60.key.remoteJid, {
      react: {
        text: "🔁",
        key: value60.key
      }
    });
    await applyEffect(value59, value60, ["-filter:a", "aecho=0.8:0.9:1000:0.3"], value62);
  }
}, {
  name: "robot",
  aliases: ["robotvoice"],
  category: "tools",
  description: "Apply robot voice effect to audio",
  usage: ".robot (reply to audio)",
  async execute(value63, value64, value65, {
    reply: value66
  }) {
    await value63.sendMessage(value64.key.remoteJid, {
      react: {
        text: "🤖",
        key: value64.key
      }
    });
    await applyEffect(value63, value64, ["-filter_complex", "afftfilt=real='hypot(re,im)*sin(0)':imag='hypot(re,im)*cos(0)':win_size=512:overlap=0.75"], value66);
  }
}, {
  name: "deep",
  aliases: ["deepvoice"],
  category: "tools",
  description: "Apply deep/low voice effect to audio",
  usage: ".deep (reply to audio)",
  async execute(value67, value68, value69, {
    reply: value70
  }) {
    await value67.sendMessage(value68.key.remoteJid, {
      react: {
        text: "🎤",
        key: value68.key
      }
    });
    await applyEffect(value67, value68, ["-filter:a", "asetrate=44100*0.7,aresample=44100"], value70);
  }
}, {
  name: "chipmunk",
  aliases: ["squeak"],
  category: "tools",
  description: "Apply chipmunk/high-pitch effect to audio",
  usage: ".chipmunk (reply to audio)",
  async execute(value71, value72, value73, {
    reply: value74
  }) {
    await value71.sendMessage(value72.key.remoteJid, {
      react: {
        text: "🐿️",
        key: value72.key
      }
    });
    await applyEffect(value71, value72, ["-filter:a", "asetrate=44100*1.5,aresample=44100"], value74);
  }
}, {
  name: "nightcore",
  aliases: [],
  category: "tools",
  description: "Apply nightcore effect to audio",
  usage: ".nightcore (reply to audio)",
  async execute(value75, value76, value77, {
    reply: value78
  }) {
    await value75.sendMessage(value76.key.remoteJid, {
      react: {
        text: "🌙",
        key: value76.key
      }
    });
    await applyEffect(value75, value76, ["-filter:a", "atempo=1.06,asetrate=44100*1.25"], value78);
  }
}, {
  name: "instrumental",
  aliases: [],
  category: "tools",
  description: "Extract instrumental from audio (stereo processing)",
  usage: ".instrumental (reply to audio)",
  async execute(value79, value80, value81, {
    reply: value82
  }) {
    await value79.sendMessage(value80.key.remoteJid, {
      react: {
        text: "🎸",
        key: value80.key
      }
    });
    await applyEffect(value79, value80, ["-af", "pan=stereo|c0=c0|c1=c1,aresample=async=1:first_pts=0"], value82);
  }
}, {
  name: "vocalremove",
  aliases: ["removevocal", "novocal"],
  category: "tools",
  description: "Remove vocals from an audio file (stereo cancellation)",
  usage: ".vocalremove (reply to audio)",
  async execute(value83, value84, value85, {
    reply: value86
  }) {
    await value83.sendMessage(value84.key.remoteJid, {
      react: {
        text: "🎵",
        key: value84.key
      }
    });
    await applyEffect(value83, value84, ["-af", "pan=stereo|c0=c0|c1=-1*c1"], value86);
  }
}, {
  name: "karaoke",
  aliases: [],
  category: "tools",
  description: "Create a karaoke version of an audio file",
  usage: ".karaoke (reply to audio)",
  async execute(value87, value88, value89, {
    reply: value90
  }) {
    await value87.sendMessage(value88.key.remoteJid, {
      react: {
        text: "🎤",
        key: value88.key
      }
    });
    await applyEffect(value87, value88, ["-af", "stereotools=mode=ms>lr"], value90);
  }
}, {
  name: "toptt",
  aliases: ["tovn"],
  category: "tools",
  description: "Convert an audio file to a WhatsApp voice note (PTT)",
  usage: ".toptt (reply to audio)",
  async execute(value91, value92, value93, {
    reply: value94
  }) {
    const value95 = value92.key.remoteJid;
    const value96 = value92.message?.extendedTextMessage?.contextInfo;
    if (!value96?.quotedMessage?.audioMessage) {
      return value94("Reply to an *audio file* to convert it to a voice note.");
    }
    await value91.sendMessage(value95, {
      react: {
        text: "🗣️",
        key: value92.key
      }
    });
    try {
      const value97 = {
        key: {
          remoteJid: value96.remoteJid || value95,
          fromMe: false,
          id: value96.stanzaId,
          participant: value96.participant
        },
        message: value96.quotedMessage
      };
      const value98 = await downloadMediaMessage(value97, "buffer", {}, {
        logger: undefined
      });
      const value99 = await toPTT(value98, "ogg");
      await value91.sendMessage(value95, {
        audio: value99,
        mimetype: "audio/ogg; codecs=opus",
        ptt: true
      }, {
        quoted: value92
      });
    } catch (error100) {
      value94("🚫 Error: " + error100.message);
    }
  }
}];
