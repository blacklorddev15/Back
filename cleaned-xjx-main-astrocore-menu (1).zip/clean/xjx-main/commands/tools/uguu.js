const axios = require("axios");
const FormData = require("form-data");
const {
  sendButtons
} = require("gifted-btns");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const database = require("../../database");
module.exports = {
  name: "uguu",
  aliases: ["temp", "temphost"],
  category: "tools",
  description: "Upload a file to uguu.se via URL or quoted media (temporary ~48hr hosting)",
  usage: ".uguu <file-url> or reply to media",
  async execute(value1, value2, value3, value4) {
    try {
      await value1.sendMessage(value4.from, {
        react: {
          text: "⏳",
          key: value2.key
        }
      });
      let value5;
      let value6;
      let value7;
      let value8;
      const value9 = value2.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (value9) {
        const value10 = value9.imageMessage ? "imageMessage" : value9.videoMessage ? "videoMessage" : value9.audioMessage ? "audioMessage" : value9.documentMessage ? "documentMessage" : value9.stickerMessage ? "stickerMessage" : null;
        if (!value10) {
          return value4.reply("❌ Quoted message has no supported media!");
        }
        const value11 = value9[value10];
        const value12 = {
          key: {
            ...value2.key
          },
          message: value9
        };
        value5 = await downloadMediaMessage(value12, "buffer", {}, {
          logger: undefined
        });
        value7 = value11.mimetype || "application/octet-stream";
        const value13 = value7.split("/")[1]?.split(";")[0] || "bin";
        value6 = value11.fileName || "upload_" + Date.now() + "." + value13;
        value8 = (value5.byteLength / 1024).toFixed(1);
      } else {
        const value14 = value3.join(" ").trim();
        if (!value14) {
          return value4.reply("❌ Please provide a file URL or reply to a media message!\nExample:\n.uguu https://example.com/image.png");
        }
        const value15 = await axios.get(value14, {
          responseType: "arraybuffer",
          timeout: 30000,
          maxBodyLength: 104857600
        });
        const value16 = value15.headers["content-disposition"];
        if (value16) {
          const value17 = value16.match(/filename="?([^";\n]+)"?/);
          if (value17) {
            value6 = value17[1].trim();
          }
        }
        if (!value6) {
          const value18 = value14.split("?")[0];
          value6 = value18.split("/").pop() || "upload_" + Date.now();
        }
        value7 = value15.headers["content-type"] || "application/octet-stream";
        value5 = Buffer.from(value15.data);
        value8 = (value5.byteLength / 1024).toFixed(1);
      }
      const value19 = new FormData();
      value19.append("files[]", value5, {
        filename: value6,
        contentType: value7
      });
      const {
        data: value20
      } = await axios.post("https://uguu.se/upload.php", value19, {
        headers: {
          ...value19.getHeaders(),
          "User-Agent": "Mozilla/5.0"
        },
        timeout: 60000
      });
      if (!value20?.success || !value20?.files?.length) {
        throw new Error("Uguu returned an invalid response");
      }
      const value21 = value20.files[0].url;
      const value22 = value20.files[0].name;
      await value1.sendMessage(value4.from, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
      const value23 = " *⏱️ File Hosted on Uguu.se*\n\n" + (" *File:* " + value22 + "\n") + (" *Size:* " + value8 + " KB\n") + (" *Hosted:* " + value21 + "\n\n") + " ⚠️ _This link expires in ~48 hours_";
      await sendButtons(value1, value4.from, {
        text: value23,
        footer: "> Powered by " + database.getBotSetting("botName"),
        buttons: [{
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🌐 Open File",
            url: value21
          })
        }, {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "📋 Copy Link",
            copy_code: value21
          })
        }]
      }, {
        quoted: value2
      });
    } catch (error24) {
      console.error("UGUU ERROR:", error24);
      await value1.sendMessage(value4.from, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      let value25 = "❌ Failed to upload to Uguu: ";
      if (error24.code === "ECONNABORTED") {
        value25 += "Request timed out (file may be too large)";
      } else if (error24.response?.status === 413) {
        value25 += "File is too large for Uguu";
      } else {
        value25 += error24.message || error24;
      }
      await value4.reply(value25);
    }
  }
};
