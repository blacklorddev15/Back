const axios = require("axios");
module.exports = {
  name: "enhance",
  aliases: ["colorenhance", "upscale"],
  category: "tools",
  description: "Enhance and colorize an image using AI",
  usage: ".enhance (reply to an image)",
  async execute(value1, value2, value3, value4) {
    await value4.react("🎨");
    try {
      const value5 = value2.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const value6 = value5?.imageMessage || value2.message?.imageMessage;
      if (!value6) {
        return value4.reply("❌ Please reply to an image to enhance it.");
      }
      await value4.reply("🎨 Enhancing your image, please wait...");
      const {
        downloadMediaMessage: value7
      } = require("@whiskeysockets/baileys");
      const value8 = await value7({
        key: value2.message?.extendedTextMessage?.contextInfo?.stanzaId ? {
          ...value2.key,
          id: value2.message.extendedTextMessage.contextInfo.stanzaId
        } : value2.key,
        message: value5 || value2.message
      }, "buffer", {}, {
        logger: console,
        reuploadRequest: value1.updateMediaMessage
      });
      const value9 = require("form-data");
      const value10 = new value9();
      value10.append("files[]", value8, {
        filename: "image.jpg",
        contentType: "image/jpeg"
      });
      const value11 = await axios.post("https://uguu.se/upload", value10, {
        headers: value10.getHeaders()
      });
      const value12 = value11.data?.files?.[0]?.url;
      if (!value12) {
        throw new Error("Image upload to Uguu failed.");
      }
      const {
        data: value13
      } = await axios.get("https://api.shizo.top/ai/enhance?apikey=shizo&url=" + encodeURIComponent(value12));
      if (!value13.status || !value13.result) {
        throw new Error("Enhancement failed. No result returned.");
      }
      await value1.sendMessage(value2.key.remoteJid, {
        image: {
          url: value13.result
        },
        caption: "✨ *AI Enhanced Image*\n\n_Powered by Shizo AI_"
      }, {
        quoted: value2
      });
      await value4.react("✅");
    } catch (error14) {
      await value4.react("❌");
      await value4.reply("❌ Error: " + error14.message);
    }
  }
};
