const APIs = require("../../utils/api");
module.exports = {
  name: "translate",
  aliases: ["tr", "trans"],
  category: "tools",
  description: "Translate text",
  usage: ".translate <lang_code> <text>",
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    if (value3.length < 2) {
      return await value1.sendMessage(value5, {
        text: "Usage: .translate <lang_code> <text>\nExample: .translate es Hello there"
      }, {
        quoted: value2
      });
    }
    const value6 = value3[0];
    const value7 = value3.slice(1).join(" ");
    try {
      const {
        translation: value8
      } = await APIs.translate(value7, value6);
      await value1.sendMessage(value5, {
        text: value8
      }, {
        quoted: value2
      });
    } catch (error9) {
      console.error("[translate]", error9.message);
      await value1.sendMessage(value5, {
        text: "❌ Translation failed."
      }, {
        quoted: value2
      });
    }
  }
};
