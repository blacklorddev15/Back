const axios = require("axios");
const database = require("../../database");
const API_BASE = "https://snapshot.xwolf.space/api/capture";
const VIEWPORTS = ["desktop", "mobile"];
module.exports = {
  name: "ssdsktp",
  aliases: ["capture", "ssdesktop"],
  category: "tools",
  description: "Take a screenshot of a website",
  usage: ".ss <url> [desktop | mobile]",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value3[0];
      const value6 = VIEWPORTS.includes(value3[1]?.toLowerCase()) ? value3[1].toLowerCase() : "desktop";
      if (!value5) {
        return value4.reply("📸 Provide a URL to screenshot!\n\nUsage: `.ss <url> [desktop | mobile]`\nExample: `.ss https://google.com mobile`");
      }
      const value7 = value5.startsWith("http") ? value5 : "https://" + value5;
      await value1.sendMessage(value4.from, {
        react: {
          text: "⏳",
          key: value2.key
        }
      });
      const value8 = await axios.get(API_BASE, {
        params: {
          siteUrl: value7,
          viewport: value6
        },
        responseType: "arraybuffer",
        timeout: 60000
      });
      const value9 = Buffer.from(value8.data);
      if (!value9 || value9.length === 0) {
        await value1.sendMessage(value4.from, {
          react: {
            text: "❌",
            key: value2.key
          }
        });
        return value4.reply("❌ Failed to capture. Site may be unreachable.");
      }
      const value10 = value8.headers["content-type"] || "image/png";
      await value1.sendMessage(value4.from, {
        image: value9,
        mimetype: value10,
        caption: "📸 *" + value7 + "*\n📱 Viewport: " + value6 + "\n\n> " + database.getBotSetting("botName")
      }, {
        quoted: value2
      });
      await value1.sendMessage(value4.from, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error11) {
      console.error("[SS] error:", error11.message);
      await value1.sendMessage(value4.from, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      let value12 = "❌ Failed to capture: " + error11.message;
      if (error11.code === "ECONNABORTED") {
        value12 = "❌ Request timed out. The site took too long to load.";
      } else if (error11.response?.status === 400) {
        value12 = "❌ Invalid URL. Please check and try again.";
      } else if (error11.response?.status === 500) {
        value12 = "❌ API server error. Try again later.";
      }
      await value4.reply(value12);
    }
  }
};
