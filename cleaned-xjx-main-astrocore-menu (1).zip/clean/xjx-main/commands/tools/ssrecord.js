const axios = require("axios");
const database = require("../../database");
const API_BASE = "https://snapshot.xwolf.space/api/record";
const VIEWPORTS = ["desktop", "mobile"];
module.exports = {
  name: "ssrecord",
  aliases: ["ssr", "webrecord", "screenrecord"],
  category: "tools",
  description: "Record a website screen as a video",
  usage: ".ssrecord <url> [desktop | mobile]",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value3[0];
      const value6 = VIEWPORTS.includes(value3[1]?.toLowerCase()) ? value3[1].toLowerCase() : "desktop";
      if (!value5) {
        return value4.reply("🎥 Provide a URL to record!\n\nUsage: `.ssrecord <url> [desktop | mobile]`\nExample: `.ssrecord https://google.com mobile`");
      }
      const value7 = value5.startsWith("http") ? value5 : "https://" + value5;
      await value1.sendMessage(value4.from, {
        react: {
          text: "⏳",
          key: value2.key
        }
      });
      await value4.reply("🎥 Recording *" + value7 + "* on *" + value6 + "*...\nThis may take a few seconds.");
      const value8 = await axios.get(API_BASE, {
        params: {
          siteUrl: value7,
          viewport: value6
        },
        responseType: "arraybuffer",
        timeout: 60000
      });
      const value9 = Buffer.from(value8.data);
      if (!value9 || value9.length === 0) {
        await value1.sendMessage(value4.from, {
          react: {
            text: "❌",
            key: value2.key
          }
        });
        return value4.reply("❌ Failed to record. Site may be unreachable.");
      }
      const value10 = (value9.length / 1048576).toFixed(2);
      await value1.sendMessage(value4.from, {
        video: value9,
        mimetype: "video/webm",
        caption: "🎥 *" + value7 + "*\n📱 Viewport: " + value6 + "\n📦 Size: " + value10 + " MB\n\n> " + database.getBotSetting("botName")
      }, {
        quoted: value2
      });
      await value1.sendMessage(value4.from, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error11) {
      console.error("[SSRecord] error:", error11.message);
      await value1.sendMessage(value4.from, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      let value12 = "❌ Failed to record: " + error11.message;
      if (error11.code === "ECONNABORTED") {
        value12 = "❌ Request timed out. The site took too long to load.";
      } else if (error11.response?.status === 400) {
        value12 = "❌ Invalid URL. Please check and try again.";
      } else if (error11.response?.status === 500) {
        value12 = "❌ API server error. Try again later.";
      }
      await value4.reply(value12);
    }
  }
};
