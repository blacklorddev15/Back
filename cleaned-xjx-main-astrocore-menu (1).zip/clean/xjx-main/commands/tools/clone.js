const {
  applyFont
} = require("../../utils/fontConverter");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const os = require("os");
const database = require("../../database");
function parseGitHubUrl(value1) {
  try {
    const value2 = value1.replace(/^(https?:\/\/)?(www\.)?github\.com\//, "").replace(/\.git$/, "").trim();
    const value3 = value2.split("/").filter(Boolean);
    if (value3.length < 2) {
      return null;
    }
    return {
      owner: value3[0],
      repo: value3[1]
    };
  } catch {
    return null;
  }
}
module.exports = {
  name: "gitclone",
  aliases: ["gclone", "clonerepo"],
  category: "general",
  description: "Download any public GitHub repository as a ZIP",
  usage: ".gitclone <github url>",
  ownerOnly: false,
  async execute(value4, value5, value6, value7) {
    const value8 = value7.from;
    const value9 = database.getBotSetting("prefix") || ".";
    const value10 = value6.join(" ").trim();
    if (!value10) {
      return value7.reply(applyFont("┏━━『 GITCLONE 』━━\n\n" + ("➥ Usage ➜ " + value9 + "gitclone <github url>\n\n") + "➥ Example:\n" + ("   " + value9 + "gitclone https://github.com/owner/repo\n\n") + "┗━━━━━━━━━━━━━━━━"));
    }
    const value11 = parseGitHubUrl(value10);
    if (!value11) {
      return value7.reply(applyFont("┏━━『 GITCLONE ERROR 』━━\n\n➥ Invalid GitHub URL\n➥ Expected: https://github.com/owner/repo\n\n┗━━━━━━━━━━━━━━━━"));
    }
    const {
      owner: value12,
      repo: value13
    } = value11;
    await value4.sendMessage(value8, {
      react: {
        text: "⏳",
        key: value5.key
      }
    });
    let value14 = "main";
    let value15 = value13;
    try {
      const {
        data: value16
      } = await axios.get("https://api.github.com/repos/" + value12 + "/" + value13, {
        headers: {
          "User-Agent": "June_X_Ultra"
        },
        timeout: 10000
      });
      value14 = value16.default_branch || "main";
      value15 = value16.name || value13;
    } catch {}
    const value17 = "https://github.com/" + value12 + "/" + value13 + "/archive/refs/heads/" + value14 + ".zip";
    const value18 = Date.now();
    let value19;
    try {
      value19 = path.join(os.tmpdir(), value15 + "-" + value18 + ".zip");
      const value20 = await axios({
        method: "get",
        url: value17,
        responseType: "stream",
        timeout: 120000,
        headers: {
          "User-Agent": "June_X_Ultra"
        },
        maxRedirects: 5
      });
      const value21 = fs.createWriteStream(value19);
      value20.data.pipe(value21);
      await new Promise((value22, value23) => {
        value21.on("finish", value22);
        value21.on("error", value23);
      });
      if (!fs.existsSync(value19) || fs.statSync(value19).size === 0) {
        throw new Error("ZIP download failed — file is empty");
      }
      const value24 = (fs.statSync(value19).size / 1048576).toFixed(2);
      await value4.sendMessage(value8, {
        document: fs.readFileSync(value19),
        mimetype: "application/zip",
        fileName: value15 + ".zip",
        caption: applyFont("┏━━『 GITCLONE ZIP 』━━\n\n" + ("➥ Repository ➜ " + value12 + "/" + value15 + "\n") + ("➥ Branch     ➜ " + value14 + "\n") + ("➥ Size       ➜ " + value24 + " MB\n\n") + "┗━━━━━━━━━━━━━━━━\n\n" + ("> " + database.getBotSetting("botName")))
      }, {
        quoted: value5
      });
      await value4.sendMessage(value8, {
        react: {
          text: "✅",
          key: value5.key
        }
      });
    } catch (error25) {
      console.error("[GitClone] error:", error25.message);
      await value4.sendMessage(value8, {
        react: {
          text: "❌",
          key: value5.key
        }
      });
      await value7.reply(applyFont("┏━━『 GITCLONE ERROR 』━━\n\n➥ Failed  ➜ ZIP Download\n" + ("➥ Reason  ➜ " + error25.message + "\n\n") + "  Make sure the repo is public.\n\n┗━━━━━━━━━━━━━━━━"));
    } finally {
      if (value19 && fs.existsSync(value19)) {
        fs.unlinkSync(value19);
      }
    }
  }
};
