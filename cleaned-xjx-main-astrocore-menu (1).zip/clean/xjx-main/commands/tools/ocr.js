const axios = require("axios");
const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
module.exports = {
  name: "ocr",
  aliases: ["readtext"],
  category: "tools",
  description: "Extract text from an image",
  usage: ".ocr (reply to an image)",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value2.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const value6 = value5?.imageMessage || value2.message?.imageMessage;
      if (!value6) {
        return value4.reply("⚠️ Send or reply to an *image* with the caption *.ocr* to extract text.");
      }
      if (!/image/.test(value6.mimetype || "")) {
        return value4.reply("⚠️ This command only works with *images*!");
      }
      await value1.sendMessage(value4.from, {
        react: {
          text: "⏳",
          key: value2.key
        }
      });
      const value7 = await downloadContentFromMessage(value6, "image");
      let value8 = Buffer.from([]);
      for await (const value9 of value7) {
        value8 = Buffer.concat([value8, value9]);
      }
      const value10 = /png/.test(value6.mimetype) ? "image/png" : "image/jpeg";
      const value11 = value8.toString("base64");
      const value12 = await axios.post("https://staging-ai-image-ocr-266i.frontend.encr.app/api/ocr/process", {
        imageBase64: value11,
        mimeType: value10
      }, {
        headers: {
          "content-type": "application/json"
        }
      });
      const value13 = value12.data.extractedText?.trim() || "❌ No text detected in the image.";
      await value4.reply("📄 *Extracted Text:*\n\n" + value13);
      await value1.sendMessage(value4.from, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error14) {
      console.error("OCR Error:", error14);
      await value4.reply("💥 Failed to read text from image. Please try again later.");
      await value1.sendMessage(value4.from, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
    }
  }
};
