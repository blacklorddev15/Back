const axios = require("axios");
module.exports = {
  name: "llama",
  aliases: ["llama3"],
  category: "tools",
  description: "Chat with LLaMA AI",
  usage: ".llama <question>",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value3.join(" ").trim();
      if (!value5) {
        return value4.reply("❌ Please type a message.\nExample: `.llama hello`");
      }
      await value4.reply("🦙 Asking LLaMA...");
      const value6 = await axios.get("https://apiskeith.vercel.app/ai/ilama?q=" + encodeURIComponent(value5));
      const value7 = value6.data?.result;
      if (!value7) {
        return value4.reply("⚠️ No response from LLaMA. Try again later.");
      }
      await value1.sendMessage(value4.from, {
        text: "🦙 *LLaMA says:*\n\n" + value7
      }, {
        quoted: value2
      });
    } catch (error8) {
      console.error("LLaMA API Error:", error8.message);
      await value4.reply("💥 API error! Try again later.");
    }
  }
};
