const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
module.exports = {
  name: "tutorial",
  aliases: ["deploy", "tut"],
  category: "tools",
  description: "Get deployment tutorial links for various hosting platforms",
  usage: ".tutorial",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      const value6 = "┏━━『 *DEPLOYMENT TUTORIALS* 』━━\n\n✬ Choose a platform below to get the\n" + ("  full deployment tutorial for *" + database.getBotSetting("botName") + "*\n\n") + "┃ *Available Platforms*\n☁️  Heroku\n🖥️  Panels (Pterodactyl)\n🚉  Railway\n⚡  Optiklink\n🔥  Daki.cc\n🟣  Render\n\n┗━━━━━━━━━━━━━━━━";
      await sendButtons(value1, value5, {
        title: "📚 BOT TUTORIALS",
        text: value6,
        footer: "Powered by " + database.getBotSetting("botName"),
        buttons: [{
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "☁️ Deploy to Heroku",
            url: "https://heroku.com"
          })
        }, {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🖥️ Deploy to Panels",
            url: "https://panel.daki.cc"
          })
        }, {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🚉 Deploy to Railway",
            url: "https://railway.app"
          })
        }, {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "⚡ Deploy to Optiklink",
            url: "https://optiklink.com"
          })
        }, {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🔥 Deploy to Daki.cc",
            url: "https://daki.cc"
          })
        }, {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🟣 Deploy to Render",
            url: "https://render.com"
          })
        }]
      }, {
        quoted: value2
      });
    } catch (error7) {
      console.error("[tutorial] error:", error7);
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
