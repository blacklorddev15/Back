const axios = require("axios");
const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
module.exports = {
  name: "shorturl",
  aliases: ["shortlink"],
  category: "tools",
  description: "Create a short URL from a long link",
  usage: ".shorturl <url>",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value3.join(" ").trim();
      if (!value5) {
        return value4.reply("âŒ Please provide a link to shorten!\nExample:\n.shorturl https://google.com");
      }
      await value1.sendMessage(value4.from, {
        react: {
          text: "â³",
          key: value2.key
        }
      });
      const {
        data: value6
      } = await axios.get("https://tinyurl.com/api-create.php?url=" + encodeURIComponent(value5));
      await value1.sendMessage(value4.from, {
        react: {
          text: "âœ…",
          key: value2.key
        }
      });
      const value7 = " *Short URL Created*\n\n" + (" *Original:* " + value5 + "\n") + (" *Shortened:* " + value6);
      await sendButtons(value1, value4.from, {
        text: value7,
        footer: "> Powered by " + database.getBotSetting("botName"),
        buttons: [{
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "Open Link",
            url: value6
          })
        }, {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "‹ Copy URL",
            copy_code: value6
          })
        }]
      }, {
        quoted: value2
      });
    } catch (error8) {
      console.error("SHORTLINK ERROR:", error8);
      await value1.sendMessage(value4.from, {
        react: {
          text: "âŒ",
          key: value2.key
        }
      });
      await value4.reply("âŒ Failed to create shortlink: " + (error8.message || error8));
    }
  }
};
