const {
  getDevice
} = require("@whiskeysockets/baileys");
const DEVICE_LABELS = {
  android: "Android",
  ios: "iOS (iPhone/iPad)",
  web: "WhatsApp Web",
  desktop: "WhatsApp Desktop",
  unknown: "Unknown"
};
module.exports = {
  name: "getdevice",
  aliases: ["device", "checkdevice"],
  category: "tools",
  description: "Detect what device a quoted message was sent from",
  usage: ".device (reply to any message)",
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6
    } = value4;
    const value7 = value2.message?.extendedTextMessage?.contextInfo || value2.message?.imageMessage?.contextInfo || value2.message?.videoMessage?.contextInfo || value2.message?.audioMessage?.contextInfo || value2.message?.stickerMessage?.contextInfo || value2.message?.buttonsResponseMessage?.contextInfo || value2.message?.listResponseMessage?.contextInfo;
    if (!value7?.stanzaId) {
      return value6(" *Device Checker*\n\nReply to any message to detect what device it was sent from.");
    }
    const value8 = value7.stanzaId;
    const value9 = getDevice(value8);
    const value10 = DEVICE_LABELS[value9] || "" + value9;
    return value6("*Device Detected*\n\nThis message was sent from *" + value10 + "*");
  }
};
