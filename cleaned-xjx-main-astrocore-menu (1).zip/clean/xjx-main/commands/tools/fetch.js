const axios = require("axios");
const METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"];
const MAX_FILE_SIZE = 104857600;
module.exports = {
  name: "fetch",
  aliases: ["get", "browse", "request"],
  category: "tools",
  description: "Fetch/send a request to a URL using any HTTP method",
  usage: ".fetch [method] <url> [json body]\ne.g. .fetch https://example.com\n     .fetch POST https://api.example.com/x {\"key\":\"value\"}",
  async execute(value1, value2, value3, value4) {
    try {
      await value1.sendMessage(value4.from, {
        react: {
          text: "🔍",
          key: value2.key
        }
      });
      if (!value3.length) {
        return await value1.sendMessage(value4.from, {
          text: "❌ Please provide a URL to fetch.\n\n" + module.exports.usage
        }, {
          quoted: value2
        });
      }
      let value5 = "GET";
      let value6 = [...value3];
      if (METHODS.includes(value6[0].toUpperCase())) {
        value5 = value6[0].toUpperCase();
        value6 = value6.slice(1);
      }
      const value7 = value6.shift();
      if (!value7) {
        return await value1.sendMessage(value4.from, {
          text: "❌ Please provide a valid URL to fetch."
        }, {
          quoted: value2
        });
      }
      try {
        new URL(value7);
      } catch (error8) {
        return await value1.sendMessage(value4.from, {
          text: "❌ Invalid URL format. Please provide a valid URL."
        }, {
          quoted: value2
        });
      }
      const value9 = value6.join(" ").trim();
      let value10;
      let value11 = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
      };
      if (value9 && ["POST", "PUT", "PATCH"].includes(value5)) {
        try {
          value10 = JSON.parse(value9);
          value11["Content-Type"] = "application/json";
        } catch {
          value10 = value9;
          value11["Content-Type"] = "text/plain";
        }
      }
      const value12 = await axios({
        method: value5,
        url: value7,
        data: value10,
        responseType: "arraybuffer",
        timeout: 70000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        validateStatus: () => true,
        headers: value11
      });
      const value13 = value12.headers["content-type"] || "";
      const value14 = Buffer.from(value12.data);
      const value15 = value7.split("/").pop()?.split("?")[0] || "file";
      if (value12.status >= 400) {
        const value16 = value14.toString("utf8").slice(0, 1500);
        return await value1.sendMessage(value4.from, {
          text: value16 ? "```\n" + value16 + "\n```" : "❌ " + value12.status + " — empty response body"
        }, {
          quoted: value2
        });
      }
      if (value14.length > MAX_FILE_SIZE) {
        return await value1.sendMessage(value4.from, {
          text: "❌ File is too large (" + (value14.length / 1048576).toFixed(2) + "MB). Maximum allowed size is " + MAX_FILE_SIZE / 1048576 + "MB."
        }, {
          quoted: value2
        });
      }
      if (value13.includes("application/json")) {
        try {
          const value17 = JSON.parse(value14.toString());
          const value18 = JSON.stringify(value17, null, 2);
          return await value1.sendMessage(value4.from, {
            text: "```json\n" + value18 + "\n```"
          }, {
            quoted: value2
          });
        } catch (error19) {
          return await value1.sendMessage(value4.from, {
            text: value14.toString()
          }, {
            quoted: value2
          });
        }
      }
      if (value13.includes("text/html") || value13.includes("text/")) {
        return await value1.sendMessage(value4.from, {
          text: value14.toString()
        }, {
          quoted: value2
        });
      }
      if (value13.includes("image")) {
        if (value14.length > 16777216) {
          return await value1.sendMessage(value4.from, {
            document: value14,
            fileName: value15,
            mimetype: value13
          }, {
            quoted: value2
          });
        }
        return await value1.sendMessage(value4.from, {
          image: value14
        }, {
          quoted: value2
        });
      }
      if (value13.includes("video")) {
        if (value14.length > 16777216) {
          return await value1.sendMessage(value4.from, {
            document: value14,
            fileName: value15,
            mimetype: value13,
            caption: "📹 Video too large for inline display. Sent as document."
          }, {
            quoted: value2
          });
        }
        return await value1.sendMessage(value4.from, {
          video: value14
        }, {
          quoted: value2
        });
      }
      if (value13.includes("audio")) {
        return await value1.sendMessage(value4.from, {
          audio: value14,
          mimetype: value13,
          fileName: value15
        }, {
          quoted: value2
        });
      }
      if (value13.includes("application/pdf")) {
        return await value1.sendMessage(value4.from, {
          document: value14,
          mimetype: "application/pdf",
          fileName: value15.endsWith(".pdf") ? value15 : value15 + ".pdf"
        }, {
          quoted: value2
        });
      }
      if (value13.includes("application")) {
        return await value1.sendMessage(value4.from, {
          document: value14,
          mimetype: value13,
          fileName: value15
        }, {
          quoted: value2
        });
      }
      if (value14.length === 0) {
        return await value1.sendMessage(value4.from, {
          text: "❌ " + value12.status + " — empty response body"
        }, {
          quoted: value2
        });
      }
      return await value1.sendMessage(value4.from, {
        document: value14,
        fileName: value15,
        mimetype: value13 || "application/octet-stream"
      }, {
        quoted: value2
      });
    } catch (error20) {
      console.error("[fetch]", error20.message);
      let value21 = "❌ Failed to fetch the URL. ";
      if (error20.code === "ECONNABORTED") {
        value21 += "Request timeout. The server took too long to respond.";
      } else if (error20.response) {
        value21 += "Server responded with status: " + error20.response.status;
      } else if (error20.request) {
        value21 += "No response received from server.";
      } else {
        value21 += "Please check the URL and try again.";
      }
      await value1.sendMessage(value4.from, {
        text: value21
      }, {
        quoted: value2
      });
      await value1.sendMessage(value4.from, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
    }
  }
};
