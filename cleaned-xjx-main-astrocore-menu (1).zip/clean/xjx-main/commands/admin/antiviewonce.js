const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const database = require(require("path").join(global.__CORE__, "database"));
const VO_WRAPPERS = ["viewOnceMessageV2Extension", "viewOnceMessageV2", "viewOnceMessage"];
const MEDIA_DL_TYPES = {
  imageMessage: "image",
  videoMessage: "video",
  audioMessage: "audio"
};
function extractViewOnce(value1) {
  const value2 = [value1];
  if (value1.ephemeralMessage?.message) {
    value2.push(value1.ephemeralMessage.message);
  }
  for (const value3 of value2) {
    for (const value4 of VO_WRAPPERS) {
      const value5 = value3[value4]?.message;
      if (value5) {
        const value6 = Object.keys(value5).find(value7 => MEDIA_DL_TYPES[value7]);
        if (value6) {
          return {
            innerMsg: value5,
            mtype: value6,
            dlType: MEDIA_DL_TYPES[value6]
          };
        }
      }
    }
    for (const [value8, value9] of Object.entries(MEDIA_DL_TYPES)) {
      if (value3[value8]?.viewOnce === true) {
        return {
          innerMsg: {
            [value8]: {
              ...value3[value8],
              viewOnce: false
            }
          },
          mtype: value8,
          dlType: value9
        };
      }
    }
  }
  return null;
}
async function handleAntiviewonce(value10, value11) {
  try {
    if (!value11?.key || !value11.message) {
      return false;
    }
    const value12 = value11.key.remoteJid;
    if (!value12.endsWith("@g.us")) {
      return false;
    }
    const value13 = database.getGroupSettings(value12);
    if (!value13.antiviewonce) {
      return false;
    }
    const value14 = extractViewOnce(value11.message);
    if (!value14) {
      return false;
    }
    const {
      innerMsg: value15,
      mtype: value16,
      dlType: value17
    } = value14;
    const value18 = await downloadContentFromMessage(value15[value16], value17);
    const value19 = [];
    for await (const value20 of value18) {
      value19.push(value20);
    }
    const value21 = Buffer.concat(value19);
    const value22 = value11.key.participant || value11.key.remoteJid;
    const value23 = value22.split("@")[0].split(":")[0];
    const value24 = (value15[value16]?.caption ? value15[value16].caption + "\n\n" : "") + ("👁️ _View-once revealed · sent by @" + value23 + "_");
    if (value17 === "image") {
      await value10.sendMessage(value12, {
        image: value21,
        caption: value24,
        mentions: [value22]
      }, {
        quoted: value11
      });
    } else if (value17 === "video") {
      await value10.sendMessage(value12, {
        video: value21,
        caption: value24,
        mimetype: "video/mp4",
        mentions: [value22]
      }, {
        quoted: value11
      });
    } else if (value17 === "audio") {
      await value10.sendMessage(value12, {
        audio: value21,
        ptt: false,
        mimetype: "audio/mp4"
      }, {
        quoted: value11
      });
    }
    return true;
  } catch (error25) {
    console.error("[ANTIVIEWONCE] error:", error25.message);
    return false;
  }
}
module.exports = {
  name: "antiviewonce",
  aliases: ["antivo", "noviewonce", "revealvo"],
  category: "admin",
  description: "Auto-reveal view-once messages in groups",
  usage: ".antiviewonce on/off",
  groupOnly: true,
  adminOnly: true,
  handleAntiviewonce: handleAntiviewonce,
  async execute(value26, value27, value28, value29) {
    const {
      from: value30,
      reply: value31
    } = value29;
    const value32 = (value28[0] || "").toLowerCase();
    const value33 = database.getGroupSettings(value30);
    if (!value32) {
      return value31("👁️ *Anti View-Once*\n━━━━━━━━━━━━━━━\n" + ("Status: *" + (value33.antiviewonce ? "✅ ON" : "❌ OFF") + "*\n\n") + "When enabled, all view-once images, videos and audio sent in this group are automatically revealed.\n\n  .antiviewonce on\n  .antiviewonce off");
    }
    if (value32 === "on") {
      database.updateGroupSettings(value30, {
        antiviewonce: true
      });
      return value31("✅ *Anti View-Once* enabled — view-once media will be auto-revealed in this group.");
    }
    if (value32 === "off") {
      database.updateGroupSettings(value30, {
        antiviewonce: false
      });
      return value31("❌ *Anti View-Once* disabled.");
    }
    return value31("⚠️ Usage: .antiviewonce on/off");
  }
};
