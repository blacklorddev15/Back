const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
module.exports = {
  name: "hidetag",
  aliases: ["tag"],
  description: "Silently tag all members in the group",
  usage: ".tag <message> (or reply to media)",
  category: "admin",
  groupOnly: true,
  adminOnly: false,
  botAdminNeeded: false,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = await value1.groupMetadata(value4.from);
      const value6 = value5.participants || [];
      const value7 = value6.map(value8 => value8.id || value8.lid).filter(Boolean);
      await value1.sendMessage(value4.from, {
        delete: value2.key
      });
      const value9 = value2.message?.extendedTextMessage?.contextInfo;
      let value10 = value2;
      if (value9?.quotedMessage) {
        value10 = {
          key: {
            remoteJid: value4.from,
            id: value9.stanzaId,
            participant: value9.participant
          },
          message: value9.quotedMessage
        };
      }
      const value11 = value10.message?.imageMessage || value10.message?.videoMessage || value10.message?.stickerMessage;
      if (value11) {
        try {
          const value12 = await downloadMediaMessage(value10, "buffer", {}, {
            logger: undefined,
            reuploadRequest: value1.updateMediaMessage
          });
          if (value10.message?.imageMessage) {
            const value13 = value3.join(" ") || value10.message.imageMessage.caption || "";
            await value1.sendMessage(value4.from, {
              image: value12,
              caption: value13,
              mentions: value7
            });
          } else if (value10.message?.videoMessage) {
            const value14 = value3.join(" ") || value10.message.videoMessage.caption || "";
            await value1.sendMessage(value4.from, {
              video: value12,
              caption: value14,
              mentions: value7
            });
          } else if (value10.message?.stickerMessage) {
            await value1.sendMessage(value4.from, {
              sticker: value12,
              mentions: value7
            });
            const value15 = value3.join(" ");
            if (value15) {
              await value1.sendMessage(value4.from, {
                text: value15,
                mentions: value7
              });
            }
          }
        } catch (error16) {
          console.error("Error downloading media for hidetag:", error16);
          const value17 = value3.join(" ") || " ";
          await value1.sendMessage(value4.from, {
            text: value17,
            mentions: value7
          });
        }
      } else if (value9?.quotedMessage) {
        const value18 = value9.quotedMessage.conversation || value9.quotedMessage.extendedTextMessage?.text || value3.join(" ") || " ";
        await value1.sendMessage(value4.from, {
          text: value18,
          mentions: value7
        });
      } else {
        const value19 = value3.join(" ") || " ";
        await value1.sendMessage(value4.from, {
          text: value19,
          mentions: value7
        });
      }
    } catch (error20) {
      console.error("HideTag command error:", error20);
      await value4.reply("❌ Failed to tag members.");
    }
  }
};
