module.exports = {
  name: "disp",
  aliases: ["disappear", "disappearing", "ephemeral", "vanish"],
  category: "admin",
  description: "Set disappearing messages timer in chat/group",
  usage: ".disp <off/24h/7d/90d>",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = {
        off: 0,
        "0": 0,
        "24h": 86400,
        "1d": 86400,
        "7d": 604800,
        "1w": 604800,
        "90d": 7776000,
        "3m": 7776000
      };
      if (!value3[0]) {
        return value4.reply("⏳ *Disappearing Messages*\n━━━━━━━━━━━━━━━\n\nSet auto-delete timer for messages.\n\n*Usage:*\n  .disp off — Disable\n  .disp 24h — 24 hours\n  .disp 7d — 7 days\n  .disp 90d — 90 days");
      }
      const value6 = value3[0].toLowerCase();
      const value7 = value5[value6];
      if (value7 === undefined) {
        return value4.reply("❌ *Invalid option.*\n\nChoose: off, 24h, 7d, or 90d");
      }
      await value1.sendMessage(value4.from, {
        disappearingMessagesInChat: value7
      });
      if (value7 === 0) {
        return value4.reply("✅ *Disappearing messages turned OFF*\n\nMessages will no longer auto-delete.");
      }
      const value8 = {
        86400: "24 hours",
        604800: "7 days",
        7776000: "90 days"
      };
      return value4.reply("✅ *Disappearing messages set to " + value8[value7] + "*\n\nMessages will auto-delete after " + value8[value7] + ".");
    } catch (error9) {
      console.error("disp error:", error9);
      await value4.reply("❌ Error: " + error9.message);
    }
  }
};
