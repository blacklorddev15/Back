const MAX_SUBJECT = 100;
module.exports = {
  name: "setgname",
  aliases: ["setsubject", "setgroupname", "gname"],
  category: "admin",
  description: "Change the group name",
  usage: ".setgname <new name>",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.groupMetadata?.subject || "this group";
    const value6 = (value3 || []).join(" ").trim();
    if (!value6) {
      return value4.reply("🏷️ *Group Name*\n\n" + ("Current: *" + value5 + "*\n\n") + "Usage: .setgname <new name>\nExample: .setgname June-X Hangout");
    }
    if (value6.length > MAX_SUBJECT) {
      return value4.reply("❌ Group name is too long (" + value6.length + "/" + MAX_SUBJECT + " characters).");
    }
    try {
      if (value4.react) {
        await value4.react("✏️").catch(() => {});
      }
      await value1.groupUpdateSubject(value4.from, value6);
      if (value4.react) {
        await value4.react("✅").catch(() => {});
      }
      await value4.reply("✅ *Group name updated*\n\n" + value5 + "  →  *" + value6 + "*");
    } catch (error7) {
      console.error("[setgname]", error7.message);
      if (value4.react) {
        await value4.react("❌").catch(() => {});
      }
      const value8 = /not-authorized|401|403|forbidden/i.test(error7.message || "");
      await value4.reply(value8 ? "❌ I do not have permission to change the group name. Make sure the bot is admin and the group is not locked." : "❌ Failed to update group name: " + error7.message);
    }
  }
};
