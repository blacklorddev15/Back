function getQuotedText(value1) {
  const value2 = value1.message?.extendedTextMessage?.contextInfo || value1.message?.imageMessage?.contextInfo || value1.message?.videoMessage?.contextInfo || null;
  const value3 = value2?.quotedMessage;
  if (!value3) {
    return "";
  }
  return (value3.conversation || value3.extendedTextMessage?.text || value3.imageMessage?.caption || value3.videoMessage?.caption || value3.documentMessage?.caption || "").trim();
}
module.exports = {
  name: "setgdesc",
  aliases: ["setdesc", "setgroupdesc", "setdescription"],
  category: "admin",
  description: "Change or clear the group description",
  usage: ".setgdesc <text> | .setgdesc clear | reply + .setgdesc",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value4, value5, value6, value7) {
    const value8 = (value6 || []).join(" ").trim();
    const value9 = getQuotedText(value5);
    const value10 = value7.groupMetadata?.desc?.trim() || "";
    const value11 = value7.groupMetadata?.subject || "This group";
    const value12 = ["clear", "off", "remove", "delete", "none"].includes(value8.toLowerCase());
    const value13 = value12 ? "" : value8 || value9;
    if (!value13 && !value12) {
      return value7.reply("📝 *Group Description*\n\n" + ("Group: *" + value11 + "*\n") + ("Current:\n" + (value10 || "_No description set._") + "\n\n") + "*Usage:*\n  .setgdesc Welcome to the group\n  .setgdesc   _(reply to a message)_\n  .setgdesc clear");
    }
    try {
      if (value7.react) {
        await value7.react("✏️").catch(() => {});
      }
      await value4.groupUpdateDescription(value7.from, value12 ? undefined : value13);
      if (value7.react) {
        await value7.react("✅").catch(() => {});
      }
      if (value12) {
        return value7.reply("✅ Group description *removed*.");
      }
      await value7.reply("✅ *Group description updated*\n\n" + value13);
    } catch (error14) {
      console.error("[setgdesc]", error14.message);
      if (value7.react) {
        await value7.react("❌").catch(() => {});
      }
      const value15 = /not-authorized|401|403|forbidden/i.test(error14.message || "");
      await value7.reply(value15 ? "❌ I do not have permission to change the description. Make sure the bot is admin and the group is not locked." : "❌ Failed to update description: " + error14.message);
    }
  }
};
