const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antitag",
  aliases: ["antimention", "at"],
  description: "Configure anti-tag protection (tagall/hidetag)",
  usage: ".antitag <on/off/set/get>",
  category: "admin",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      if (!value3[0]) {
        const value5 = database.getGroupSettings(value4.from);
        const value6 = value5.antitag ? "ON" : "OFF";
        const value7 = value5.antitagAction || "delete";
        return value4.reply("📛 Anti-tag is *" + value6 + "* (action: *" + value7 + "*).\nUsage:\n  .antitag on\n  .antitag off\n  .antitag set delete | kick\n  .antitag get");
      }
      const value8 = value3[0].toLowerCase();
      if (value8 === "on") {
        if (database.getGroupSettings(value4.from).antitag) {
          return value4.reply("*Antitag is already on*");
        }
        database.updateGroupSettings(value4.from, {
          antitag: true
        });
        return value4.reply("*Antitag has been turned ON*");
      }
      if (value8 === "off") {
        database.updateGroupSettings(value4.from, {
          antitag: false
        });
        return value4.reply("*Antitag has been turned OFF*");
      }
      if (value8 === "set") {
        if (value3.length < 2) {
          return value4.reply("*Please specify an action: .antitag set delete | kick*");
        }
        const value9 = value3[1].toLowerCase();
        if (!["delete", "kick"].includes(value9)) {
          return value4.reply("*Invalid action. Choose delete or kick.*");
        }
        database.updateGroupSettings(value4.from, {
          antitagAction: value9,
          antitag: true
        });
        return value4.reply("*Antitag action set to " + value9 + "*");
      }
      if (value8 === "get") {
        const value10 = database.getGroupSettings(value4.from);
        const value11 = value10.antitag ? "ON" : "OFF";
        const value12 = value10.antitagAction || "delete";
        return value4.reply("*Antitag Configuration:*\nStatus: " + value11 + "\nAction: " + value12);
      }
      return value4.reply("*Use .antitag for usage.*");
    } catch (error13) {
      await value4.reply("❌ Error: " + error13.message);
    }
  }
};
