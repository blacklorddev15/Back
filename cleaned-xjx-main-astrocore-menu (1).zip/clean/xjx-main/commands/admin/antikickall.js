const database = require(require("path").join(global.__CORE__, "database"));
const BLOCKED_CMDS = new Set(["kickall", "removeall", "killgc", "killgroup", "killall"]);
module.exports = {
  name: "antikickall",
  aliases: ["antikick", "protectgroup", "groupprotect"],
  category: "admin",
  description: "Block anyone from running group-destruction commands (kickall, removeall, killgroup…)",
  usage: ".antikickall on | off | status",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  BLOCKED_CMDS: BLOCKED_CMDS,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6
    } = value4;
    const value7 = database.getGroupSettings(value5);
    const value8 = (value3[0] || "").toLowerCase();
    const value9 = [...BLOCKED_CMDS].map(value10 => "  • ." + value10).join("\n");
    if (!value8 || value8 === "status") {
      return value6("🛡️ *Anti-KickAll Protection*\n━━━━━━━━━━━━━━━\n" + ("📌 Status: *" + (value7.antikickall ? "✅ ON" : "❌ OFF") + "*\n\n") + ("*Blocked commands:*\n" + value9 + "\n\n") + "*Punishment on attempt:*\n  🗑️ Message deleted\n  ⬇️ Demoted (if admin)\n  ⚠️ Warning issued\n  🚫 Kicked from group\n\n_Bot owners are always exempt._\n\n*Commands:*\n  .antikickall on  — enable protection\n  .antikickall off — disable protection");
    }
    if (value8 === "on") {
      database.updateGroupSettings(value5, {
        antikickall: true
      });
      return value6("✅ *Anti-KickAll ENABLED*\n\n" + ("Anyone who tries to use:\n" + value9 + "\n\n") + "…will be *demoted, warned, and kicked* immediately.");
    }
    if (value8 === "off") {
      database.updateGroupSettings(value5, {
        antikickall: false
      });
      return value6("❌ *Anti-KickAll* disabled. Group-destruction commands are no longer blocked.");
    }
    return value6("⚠️ Usage: .antikickall on | off | status");
  }
};
