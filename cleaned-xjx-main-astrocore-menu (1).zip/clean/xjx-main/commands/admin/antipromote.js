const database = require(require("path").join(global.__CORE__, "database"));
const botCorrecting = new Set();
function markCorrecting(value1) {
  botCorrecting.add(value1);
  setTimeout(() => botCorrecting.delete(value1), 6000);
}
function excludeBot(value2, value3) {
  const value4 = value3.includes(":") ? value3.split(":")[0] : value3.split("@")[0];
  return value2.filter(value5 => {
    if (!value5) {
      return false;
    }
    const value6 = value5.split(":")[0].split("@")[0];
    return value6 !== value4 && value5 !== value3;
  });
}
async function handlePromote(value7, value8, value9, value10) {
  try {
    const value11 = database.getGroupSettings(value8);
    if (!value11.antipromote) {
      return;
    }
    if (botCorrecting.has(value10)) {
      return;
    }
    const value12 = value7.user?.id || "";
    const value13 = value11.antipromoteAction || "revert";
    const value14 = value9 ? value9.split("@")[0] : "Unknown";
    const value15 = value10 ? value10.split("@")[0] : "Unknown";
    const value16 = new Date().toLocaleString("en-GB", {
      timeZone: database.getTimeZone(),
      hour12: false,
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
    markCorrecting(value10);
    if (value9) {
      markCorrecting(value9);
    }
    let value17 = "";
    if (value13 === "revert") {
      const value18 = excludeBot([value10], value12);
      if (value18.length) {
        await value7.groupParticipantsUpdate(value8, value18, "demote");
      }
      value17 = "🔄 *Action:* Promotion reversed — member demoted back";
    } else if (value13 === "kick") {
      const value19 = excludeBot([value10, value9], value12);
      if (value19.length) {
        await value7.groupParticipantsUpdate(value8, value19, "remove");
      }
      value17 = "🚫 *Action:* Both parties kicked from the group";
    } else if (value13 === "demote") {
      const value20 = excludeBot([value10, value9], value12);
      if (value20.length) {
        await value7.groupParticipantsUpdate(value8, value20, "demote");
      }
      value17 = "⬇️ *Action:* Promoted member reverted + promoter demoted";
    }
    await value7.sendMessage(value8, {
      text: ["⚠️ *Security Alert — AntiPromote*", "", "An unauthorized promotion was *detected and actioned*.", "", "👤 *Promoter:* @" + value14, "🎯 *Promoted:* @" + value15, "⏰ *Time:* " + value16, "" + value17, "", "> Powered by " + database.getBotSetting("botName")].join("\n"),
      mentions: [value9, value10].filter(Boolean)
    });
  } catch (error21) {
    console.error("[AntiPromote] Error:", error21.message);
  }
}
module.exports = {
  name: "antipromote",
  aliases: ["antipm"],
  category: "admin",
  description: "Block unauthorized admin promotions with configurable action",
  usage: ".antipromote on | revert | kick | demote | off",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  handlePromote: handlePromote,
  botCorrecting: botCorrecting,
  async execute(value22, value23, value24, value25) {
    const {
      from: value26,
      reply: value27,
      react: value28
    } = value25;
    const value29 = value24[0]?.toLowerCase();
    const value30 = database.getGroupSettings(value26);
    const value31 = !!value30.antipromote;
    const value32 = value30.antipromoteAction || "revert";
    const value33 = {
      revert: "🔄 Revert — demote the promoted member back",
      kick: "🚫 Kick — remove both parties from group",
      demote: "⬇️ Demote — demote both promoter and promoted"
    };
    if (!value29) {
      return value27("🛡️ *AntiPromote*\n\n" + ("Status: *" + (value31 ? "✅ ON" : "❌ OFF") + "*\n") + ("Action: *" + (value31 ? value33[value32] || value32 : "—") + "*\n\n") + "Catches unauthorized promotions and acts on both parties.\n\n*Options:*\n  .antipromote revert  — demote the promoted member back\n  .antipromote kick    — kick both promoter + promoted\n  .antipromote demote  — demote both parties\n  .antipromote on      — enable (default: revert)\n  .antipromote off     — disable");
    }
    if (value29 === "on") {
      database.updateGroupSettings(value26, {
        antipromote: true
      });
      await value28("✅");
      return value27("🛡️ *AntiPromote enabled* — action: *" + (value33[value32] || value32) + "*");
    }
    if (value29 === "off") {
      database.updateGroupSettings(value26, {
        antipromote: false
      });
      await value28("✅");
      return value27("🛡️ *AntiPromote disabled.*");
    }
    if (["revert", "kick", "demote"].includes(value29)) {
      database.updateGroupSettings(value26, {
        antipromote: true,
        antipromoteAction: value29
      });
      await value28("✅");
      return value27("🛡️ *AntiPromote enabled*\n" + value33[value29]);
    }
    return value27("❌ Usage: .antipromote on | revert | kick | demote | off");
  }
};
