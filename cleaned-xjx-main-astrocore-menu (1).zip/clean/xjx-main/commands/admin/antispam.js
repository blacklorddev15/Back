const database = require(require("path").join(global.__CORE__, "database"));
const spamTracker = new Map();
const DEFAULT_LIMIT = 5;
const DEFAULT_WINDOW = 5;
function getTracker(value1, value2) {
  if (!spamTracker.has(value1)) {
    spamTracker.set(value1, new Map());
  }
  const value3 = spamTracker.get(value1);
  if (!value3.has(value2)) {
    value3.set(value2, []);
  }
  return value3.get(value2);
}
function pruneOld(value4, value5) {
  const value6 = Date.now() - value5;
  while (value4.length && value4[0] < value6) {
    value4.shift();
  }
}
async function handleAntispam(value7, value8, value9) {
  try {
    if (!value8?.key || !value8.message) {
      return false;
    }
    const value10 = value8.key.remoteJid;
    if (!value10.endsWith("@g.us")) {
      return false;
    }
    const value11 = database.getGroupSettings(value10);
    if (!value11.antiSpam) {
      return false;
    }
    const value12 = value8.key.participant || value8.key.remoteJid;
    if (!value12) {
      return false;
    }
    const value13 = (value9?.participants || []).filter(value14 => value14.admin).map(value15 => value15.id);
    if (value13.includes(value12)) {
      return false;
    }
    const value16 = value11.antiSpamLimit || DEFAULT_LIMIT;
    const value17 = value11.antiSpamWindow || DEFAULT_WINDOW;
    const value18 = value11.antiSpamAction || "delete";
    const value19 = value17 * 1000;
    const value20 = getTracker(value10, value12);
    pruneOld(value20, value19);
    value20.push(Date.now());
    if (value20.length < value16) {
      return false;
    }
    spamTracker.get(value10).delete(value12);
    const value21 = value12.split("@")[0].split(":")[0];
    const value22 = "@" + value21;
    const value23 = (value9?.participants || []).some(value24 => value24.id === value7.user?.id && value24.admin);
    if (value18 === "delete" || value18 === "warn") {
      try {
        await value7.sendMessage(value10, {
          delete: value8.key
        });
      } catch (error25) {}
      await value7.sendMessage(value10, {
        text: "⚠️ *Anti-Spam* — " + value22 + " please slow down!\n_" + value16 + " messages in " + value17 + "s detected._",
        mentions: [value12]
      });
    }
    if (value18 === "kick" && value23) {
      await value7.sendMessage(value10, {
        text: "🚫 *Anti-Spam* — " + value22 + " has been removed for spamming.",
        mentions: [value12]
      });
      await value7.groupParticipantsUpdate(value10, [value12], "remove");
    }
    if (value18 === "mute" && value23) {
      await value7.sendMessage(value10, {
        text: "🔇 *Anti-Spam* — " + value22 + " slow down or you will be removed!",
        mentions: [value12]
      });
    }
    return true;
  } catch (error26) {
    console.error("[ANTISPAM] error:", error26.message);
    return false;
  }
}
module.exports = {
  name: "antispam",
  aliases: ["spamprotect", "nospam"],
  category: "admin",
  description: "Prevent spam in groups — warns, deletes, or kicks spammers",
  usage: ".antispam on/off/set/action",
  groupOnly: true,
  adminOnly: true,
  handleAntispam: handleAntispam,
  async execute(value27, value28, value29, value30) {
    const {
      from: value31,
      reply: value32
    } = value30;
    const value33 = database.getGroupSettings(value31);
    const value34 = (value29[0] || "").toLowerCase();
    if (!value34) {
      const value35 = value33.antiSpamLimit || DEFAULT_LIMIT;
      const value36 = value33.antiSpamWindow || DEFAULT_WINDOW;
      const value37 = value33.antiSpamAction || "delete";
      return value32("🛡️ *Anti-Spam Settings*\n━━━━━━━━━━━━━━━\n" + ("📌 Status: *" + (value33.antiSpam ? "✅ ON" : "❌ OFF") + "*\n") + ("📊 Limit: *" + value35 + " msgs / " + value36 + "s*\n") + ("⚡ Action: *" + value37 + "*\n\n") + "*Commands:*\n  .antispam on\n  .antispam off\n  .antispam set <count> <seconds>  _(e.g. set 5 10)_\n  .antispam action delete|warn|kick|mute");
    }
    if (value34 === "on") {
      database.updateGroupSettings(value31, {
        antiSpam: true
      });
      return value32("✅ *Anti-Spam* enabled.");
    }
    if (value34 === "off") {
      database.updateGroupSettings(value31, {
        antiSpam: false
      });
      return value32("❌ *Anti-Spam* disabled.");
    }
    if (value34 === "set") {
      const value38 = parseInt(value29[1]);
      const value39 = parseInt(value29[2]);
      if (!value38 || !value39 || value38 < 2 || value39 < 1) {
        return value32("⚠️ Usage: .antispam set <count> <seconds>\nExample: .antispam set 5 10");
      }
      database.updateGroupSettings(value31, {
        antiSpamLimit: value38,
        antiSpamWindow: value39
      });
      return value32("✅ Spam threshold set to *" + value38 + " messages in " + value39 + " seconds*.");
    }
    if (value34 === "action") {
      const value40 = (value29[1] || "").toLowerCase();
      if (!["delete", "warn", "kick", "mute"].includes(value40)) {
        return value32("⚠️ Valid actions: delete | warn | kick | mute");
      }
      database.updateGroupSettings(value31, {
        antiSpamAction: value40
      });
      return value32("✅ Spam action set to *" + value40 + "*.");
    }
    return value32("⚠️ Unknown option. Use .antispam for help.");
  }
};
