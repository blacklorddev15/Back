const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "warn",
  aliases: ["warning"],
  category: "admin",
  description: "Warn a user (groups and PM)",
  usage: ".warn @user <reason>",
  groupOnly: false,
  adminOnly: false,
  botAdminNeeded: false,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from.endsWith("@g.us");
      const value6 = value2.key.fromMe || value4.isOwner;
      const value7 = database.getBotSetting("maxWarnings");
      let value8;
      let value9;
      if (value5) {
        const value10 = value2.key.participant || value2.participant;
        const value11 = value4.isAdmin !== undefined ? value4.isAdmin : value4.groupMetadata?.participants?.some(value12 => (value12.id === value10 || value12.lid === value10) && (value12.admin === "admin" || value12.admin === "superadmin"));
        if (!value11 && !value6) {
          return value4.reply("❌ Only group admins can use this command!");
        }
        const value13 = value2.message?.extendedTextMessage?.contextInfo;
        const value14 = value13?.mentionedJid || [];
        if (value14.length > 0) {
          value8 = value14[0];
        } else if (value13?.participant && value13.stanzaId && value13.quotedMessage) {
          value8 = value13.participant;
        } else {
          return value4.reply("❌ Please mention or reply to the user to warn!\n\nExample: .warn @user Breaking rules");
        }
        value9 = value3.slice(value14.length > 0 ? 1 : 0).join(" ") || "No reason specified";
        const value15 = value1.user?.id ? value1.user.id.split(":")[0] + "@s.whatsapp.net" : null;
        const value16 = value1.user?.lid || null;
        if (value15 && (value8 === value15 || value8 === value16 || value8 === value1.user?.id)) {
          return value4.reply("🤖 I cannot warn myself!");
        }
        const value17 = value4.groupMetadata.participants.find(value18 => (value18.id === value8 || value18.lid === value8) && (value18.admin === "admin" || value18.admin === "superadmin"));
        if (value17) {
          return value4.reply("❌ Cannot warn an admin!");
        }
      } else {
        if (!value6) {
          return value4.reply("❌ Only the owner can use this command in PM!");
        }
        value8 = value4.from;
        value9 = value3.join(" ") || "No reason specified";
      }
      const value19 = database.addWarning(value4.from, value8, value9);
      const value20 = "⚠️ @" + value8.split("@")[0] + "\nWarning: " + value19.count + "/" + value7;
      await value1.sendMessage(value4.from, {
        text: value20,
        mentions: [value8]
      }, {
        quoted: value2
      });
      if (value19.count >= value7) {
        if (value5) {
          if (value4.isBotAdmin) {
            await value1.groupParticipantsUpdate(value4.from, [value8], "remove");
            database.clearWarnings(value4.from, value8);
          }
        } else {
          await value1.updateBlockStatus(value8, "block");
          database.clearWarnings(value4.from, value8);
        }
      }
    } catch (error21) {
      await value4.reply("❌ Error: " + error21.message);
    }
  }
};
