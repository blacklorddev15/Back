module.exports = {
  name: "staff",
  aliases: ["admins", "adminlist"],
  category: "admin",
  description: "Show group staff / admin list with group info",
  usage: ".staff",
  groupOnly: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6
    } = value4;
    try {
      const value7 = await value1.groupMetadata(value5);
      const value8 = value7.participants;
      const value9 = value8.filter(value10 => value10.admin);
      let value11;
      try {
        value11 = await value1.profilePictureUrl(value5, "image");
      } catch {
        value11 = null;
      }
      const value12 = value7.owner || value9.find(value13 => value13.admin === "superadmin")?.id || null;
      const value14 = value9.map((value15, value16) => value16 + 1 + ". @" + value15.id.split("@")[0]).join("\n");
      const value17 = value7.creation ? new Date(value7.creation * 1000).toLocaleDateString() : "Unknown";
      const value18 = ["ℹ️ *GROUP STAFF*", "", "📛 *Group:* " + value7.subject, value12 ? "👑 *Owner:* @" + value12.split("@")[0] : null, "📅 *Created:* " + value17, "👥 *Members:* " + value8.length, "🛡️ *Admins:* " + value9.length, "", "📋 *Admin List:*", value14].filter(Boolean).join("\n");
      const value19 = [...value9.map(value20 => value20.id), value12].filter(Boolean);
      if (value11) {
        await value1.sendMessage(value5, {
          image: {
            url: value11
          },
          caption: value18,
          mentions: value19
        }, {
          quoted: value2
        });
      } else {
        await value1.sendMessage(value5, {
          text: value18,
          mentions: value19
        }, {
          quoted: value2
        });
      }
    } catch (error21) {
      console.error("[STAFF] Error:", error21.message);
      await value6("❌ Failed to fetch group staff info.");
    }
  }
};
