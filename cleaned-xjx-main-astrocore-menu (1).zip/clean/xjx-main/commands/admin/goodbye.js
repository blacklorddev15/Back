const db = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "goodbye",
  aliases: ["goodbyeon", "goodbyeoff"],
  category: "admin",
  desc: "Enable/disable goodbye messages",
  usage: "goodbye on/off",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  execute: async (value1, value2, value3) => {
    try {
      const value4 = value2.key.remoteJid;
      const value5 = value3[0]?.toLowerCase();
      if (!value5 || !["on", "off"].includes(value5)) {
        const value6 = db.getGroupSettings(value4);
        const value7 = value6.goodbye ? "✅ Enabled" : "❌ Disabled";
        return await value1.sendMessage(value4, {
          text: "👋 *Goodbye Messages*\n\nStatus: " + value7 + "\nMessage: " + value6.goodbyeMessage + "\n\nUsage: .goodbye on/off\n\nTo customize: .setgoodbye <message>"
        }, {
          quoted: value2
        });
      }
      const value8 = value5 === "on";
      db.updateGroupSettings(value4, {
        goodbye: value8
      });
      await value1.sendMessage(value4, {
        text: "✅ Goodbye messages " + (value8 ? "enabled" : "disabled") + "!" + (value8 ? "\n\nLeaving members will now receive goodbye messages." : "")
      }, {
        quoted: value2
      });
    } catch (error9) {
      console.error("Goodbye Error:", error9);
      await value1.sendMessage(value2.key.remoteJid, {
        text: "❌ Error: " + error9.message
      }, {
        quoted: value2
      });
    }
  }
};
