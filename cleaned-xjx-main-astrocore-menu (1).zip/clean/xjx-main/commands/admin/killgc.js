const path = require("path");
const {
  resolvePhone,
  preloadLidResolution
} = require(path.join(global.__ROOT__, "utils", "jidHelper"));
function extractInviteCode(value1) {
  if (!value1) {
    return null;
  }
  const value2 = value1.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/);
  if (value2) {
    return value2[1];
  } else if (/^[A-Za-z0-9_-]{10,}$/.test(value1.trim())) {
    return value1.trim();
  } else {
    return null;
  }
}
async function kickAll(value3, value4, value5) {
  if (!value5.length) {
    return;
  }
  try {
    await value3.groupParticipantsUpdate(value4, value5, "remove");
  } catch (error6) {
    const value7 = 25;
    for (let value8 = 0; value8 < value5.length; value8 += value7) {
      await value3.groupParticipantsUpdate(value4, value5.slice(value8, value8 + value7), "remove");
      if (value8 + value7 < value5.length) {
        await new Promise(value9 => setTimeout(value9, 500));
      }
    }
  }
}
function botIsAdmin(value10, value11) {
  const value12 = value11.split("@")[0].split(":")[0];
  const value13 = (value10.participants || []).find(value14 => {
    const value15 = value14.id.split("@")[0].split(":")[0];
    return value15 === value12;
  });
  return !!value13 && (value13.admin === "admin" || value13.admin === "superadmin");
}
module.exports = {
  name: "killgc",
  aliases: ["killgv"],
  category: "admin",
  description: "Kick all members from a group and leave. Optionally pass a group link.",
  usage: ".killgc [group link]",
  ownerOnly: true,
  botAdminNeeded: true,
  async execute(value16, value17, value18, value19) {
    const value20 = value19.from;
    const value21 = extractInviteCode(value18[0]);
    try {
      let value22;
      if (value21) {
        try {
          value22 = await value16.groupAcceptInvite(value21);
        } catch (error23) {
          const value24 = error23.message?.includes("406") || error23.output?.statusCode === 406;
          if (value24) {
            try {
              const value25 = await value16.groupGetInviteInfo(value21);
              value22 = value25.id;
            } catch (error26) {
              return value19.reply("❌ Already in that group but could not resolve its ID.");
            }
          } else {
            return value19.reply("❌ Could not join group: " + error23.message);
          }
        }
        const value27 = await value16.groupMetadata(value22);
        const value28 = value16.user?.id || "";
        if (!botIsAdmin(value27, value28)) {
          await value16.groupLeave(value22).catch(() => {});
          return value19.reply("❌ Bot is not admin in that group. Aborting.");
        }
        return await runKill(value16, value22, value27, value20, value19, true);
      } else {
        if (!value19.isGroup) {
          return value19.reply("❌ Run this inside a group, or pass a group link:\n`.killgc https://chat.whatsapp.com/XXXX`");
        }
        value22 = value19.from;
        const value29 = await value16.groupMetadata(value22);
        const value30 = value16.user?.id || "";
        if (!botIsAdmin(value29, value30)) {
          return value19.reply("❌ Bot is not admin in this group. Aborting.");
        }
        return await runKill(value16, value22, value29, value20, value19, false);
      }
    } catch (error31) {
      console.error("[killgc]", error31.message);
      await value16.sendMessage(value20, {
        text: "❌ Kill GC failed: " + error31.message
      }).catch(() => {});
    }
  }
};
async function runKill(value32, value33, value34, value35, value36, value37) {
  const value38 = value34.participants || [];
  await preloadLidResolution(value32, value38);
  const value39 = value32.user?.id || "";
  const value40 = (await resolvePhone(value32, value39)) || value39.split("@")[0].split(":")[0];
  const value41 = [];
  for (const value42 of value38) {
    let value43 = await resolvePhone(value32, value42.id);
    if (!value43) {
      value43 = value42.id.split("@")[0].split(":")[0];
    }
    if (value43 === value40) {
      continue;
    }
    value41.push(value42.id);
  }
  if (!value41.length) {
    await value32.groupLeave(value33).catch(() => {});
    return value36.reply("❌ No members to remove.");
  }
  await value32.sendMessage(value33, {
    text: "☠️ *Kill GC* — removing *" + value41.length + "* member(s). Goodbye! 👋",
    mentions: value41
  });
  await kickAll(value32, value33, value41);
  await value32.groupLeave(value33);
  if (value37) {
    await value32.sendMessage(value35, {
      text: "✅ Kicked *" + value41.length + "* from *" + (value34.subject || value33) + "* and left."
    });
  }
}
