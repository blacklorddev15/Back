const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antigroupmention",
  aliases: ["agm"],
  category: "admin",
  description: "Configure antigroupmention protection (delete/kick)",
  usage: ".antigroupmention <on/off/set/get>",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      if (!value3[0]) {
        const value5 = database.getGroupSettings(value4.from);
        const value6 = value5.antigroupmention ? "ON" : "OFF";
        const value7 = value5.antigroupmentionAction || "delete";
        return value4.reply("📌 *Anti-Group Mention Status*\n\n" + ("Status: *" + value6 + "*\n") + ("Action: *" + value7 + "*\n\n") + "Usage:\n  .antigroupmention on\n  .antigroupmention off\n  .antigroupmention set delete | warn | kick\n  .antigroupmention get\n\n_Detects when someone shares a status that mentions this group and takes the configured action._");
      }
      const value8 = value3[0].toLowerCase();
      if (value8 === "on") {
        if (database.getGroupSettings(value4.from).antigroupmention) {
          return value4.reply("*Antigroupmention is already on*");
        }
        database.updateGroupSettings(value4.from, {
          antigroupmention: true
        });
        return value4.reply("*Antigroupmention has been turned ON*");
      }
      if (value8 === "off") {
        database.updateGroupSettings(value4.from, {
          antigroupmention: false
        });
        return value4.reply("*Antigroupmention has been turned OFF*");
      }
      if (value8 === "set") {
        if (value3.length < 2) {
          return value4.reply("*Please specify an action: .antigroupmention set delete | kick*");
        }
        const value9 = value3[1].toLowerCase();
        if (!["delete", "kick", "warn"].includes(value9)) {
          return value4.reply("*Invalid action. Choose delete, warn or kick.*");
        }
        database.updateGroupSettings(value4.from, {
          antigroupmentionAction: value9,
          antigroupmention: true
        });
        return value4.reply("*Antigroupmention action set to " + value9 + "*");
      }
      if (value8 === "get") {
        const value10 = database.getGroupSettings(value4.from);
        const value11 = value10.antigroupmention ? "ON" : "OFF";
        const value12 = value10.antigroupmentionAction || "delete";
        return value4.reply("*Antigroupmention Configuration:*\nStatus: " + value11 + "\nAction: " + value12);
      }
      return value4.reply("*Use .antigroupmention for usage.*");
    } catch (error13) {
      await value4.reply("❌ Error: " + error13.message);
    }
  }
};
