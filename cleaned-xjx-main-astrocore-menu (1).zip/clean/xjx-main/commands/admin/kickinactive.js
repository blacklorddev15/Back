const {
  getInactiveUsers
} = require(require("path").join(global.__CORE__, "utils", "groupstats"));
module.exports = {
  name: "kickinactive",
  aliases: ["kickinnactive", "removeinactive", "kickidle", "kickinact"],
  category: "admin",
  description: "Remove all inactive members (no tracked messages) from the group",
  usage: ".kickinactive",
  groupOnly: true,
  adminOnly: true,
  ownerOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      await value4.react("⏳");
      const value6 = await value1.groupMetadata(value5);
      const value7 = value6.participants || [];
      const value8 = value1.user?.id || "";
      const value9 = value1.user?.lid || "";
      const value10 = value8.split("@")[0].split(":")[0];
      const value11 = value9.split("@")[0].split(":")[0];
      const value12 = value13 => {
        const value14 = (value13 || "").split("@")[0].split(":")[0];
        return value14 === value10 || value11 && value14 === value11;
      };
      const value15 = new Set(value7.filter(value16 => value16.admin === "admin" || value16.admin === "superadmin").map(value17 => value17.id));
      const value18 = value7.flatMap(value19 => [value19.id, value19.lid].filter(Boolean));
      const value20 = new Set(getInactiveUsers(value5, value18));
      const value21 = value7.filter(value22 => {
        if (value12(value22.id) || value12(value22.lid)) {
          return false;
        }
        if (value15.has(value22.id)) {
          return false;
        }
        const value23 = value20.has(value22.id);
        const value24 = !value22.lid || value20.has(value22.lid);
        return value23 && value24;
      });
      if (value21.length === 0) {
        await value4.react("✅");
        return value4.reply("✅ No inactive members to remove. Everyone has been active!");
      }
      const value25 = value21.map(value26 => value26.id);
      const value27 = value25.map(value28 => "@" + value28.split("@")[0].split(":")[0]).join(" ");
      await value1.sendMessage(value5, {
        text: "🧹 *Removing " + value21.length + " inactive member(s)* (no message activity tracked):\n\n" + value27,
        mentions: value25
      });
      await value1.groupParticipantsUpdate(value5, value25, "remove");
      await value4.react("✅");
      await value1.sendMessage(value5, {
        text: "✅ Removed *" + value21.length + "* inactive member(s) successfully."
      }, {
        quoted: value2
      });
    } catch (error29) {
      console.error("Kickinactive command error:", error29);
      try {
        await value4.react("❌");
      } catch (error30) {}
      await value4.reply("❌ Failed to remove inactive members. Make sure I am admin.");
    }
  }
};
