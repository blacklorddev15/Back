'use strict';

const database = require("../../database");
const GROUP_FEATURES = [{
  key: "antilink",
  label: "🔗 Anti-Link"
}, {
  key: "antiSpam",
  label: "🛡️ Anti-Spam"
}, {
  key: "antiimage",
  label: "🖼️ Anti-Image"
}, {
  key: "antiaudio",
  label: "🔇 Anti-Audio"
}, {
  key: "antisticker",
  label: "🎭 Anti-Sticker"
}, {
  key: "antitag",
  label: "📛 Anti-Tag"
}, {
  key: "antibot",
  label: "🤖 Anti-Bot"
}, {
  key: "antigroupmention",
  label: "📌 Anti-Group Mention"
}, {
  key: "antigroupstatus",
  label: "🛡️ Anti-Group Status"
}, {
  key: "antidemote",
  label: "⬇️ Anti-Demote"
}, {
  key: "antipromote",
  label: "⬆️ Anti-Promote"
}, {
  key: "antiviewonce",
  label: "👁️ Anti-View-Once"
}];
const icon = value1 => value1 ? "✅" : "❌";
const modeLabel = value2 => value2 === "off" ? "❌ OFF" : "✅ " + value2;
function getStatus(value3) {
  const value4 = database.getGroupSettings(value3);
  const value5 = database.getAntiTagAdminsSettings(value3);
  return {
    groupSettings: value4,
    antiAll: database.isAntiAllEnabled(value3),
    antiTagAdmins: value5,
    antiDeleteMode: database.getAntideleteMode(),
    antiEditMode: database.getAntieditMode(),
    antiDeleteStatus: database.isAntideleteStatusEnabled()
  };
}
function setGroupProtectionBundle(value6, value7) {
  const value8 = {};
  for (const value9 of GROUP_FEATURES) {
    value8[value9.key] = value7;
  }
  database.updateGroupSettings(value6, value8);
  database.setAntiAllEnabled(value6, value7);
  database.setAntiTagAdminsSettings(value6, {
    enabled: value7
  });
}
module.exports = {
  name: "antiall",
  aliases: ["allanti", "antialll"],
  category: "admin",
  description: "Enable/disable the AntiAll group master and group protections",
  usage: ".antiall on/off",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value10, value11, value12, value13) {
    const {
      from: value14,
      reply: value15
    } = value13;
    const value16 = (value12[0] || "").toLowerCase();
    if (!value16) {
      const value17 = getStatus(value14);
      const value18 = ["  " + icon(value17.antiAll) + " ⛔ AntiAll Master (blocks non-admin/non-owner messages)", ...GROUP_FEATURES.map(value19 => "  " + icon(value17.groupSettings[value19.key]) + " " + value19.label), "  " + icon(value17.antiTagAdmins.enabled) + " 🛡️ Anti-Tag Admins" + (value17.antiTagAdmins.enabled ? " — " + value17.antiTagAdmins.action : "")];
      return value15("🛡️ *AntiAll — Group Protection Status*\n━━━━━━━━━━━━━━━━━━━━\n" + value18.join("\n") + "\n━━━━━━━━━━━━━━━━━━━━\n*Global owner settings — not changed by .antiall:*\n" + ("  🗑️ Anti-Delete: " + modeLabel(value17.antiDeleteMode) + "\n") + ("  ✏️ Anti-Edit: " + modeLabel(value17.antiEditMode) + "\n") + ("  📸 Anti-Delete Status: " + icon(value17.antiDeleteStatus) + "\n\n") + "*Commands:*\n  .antiall on  — enable the group bundle + master\n  .antiall off — disable the group bundle + master");
    }
    if (value16 === "on") {
      setGroupProtectionBundle(value14, true);
      const value20 = database.getAntiTagAdminsSettings(value14);
      return value15("✅ *AntiAll — Group Protections ENABLED*\n━━━━━━━━━━━━━━━━━━━━\n  ✅ ⛔ AntiAll Master — blocks ALL non-admin messages (.antiall master off to disable)\n" + GROUP_FEATURES.map(value21 => "  ✅ " + value21.label).join("\n") + "\n" + ("  ✅ 🛡️ Anti-Tag Admins — " + value20.action + "\n") + "━━━━━━━━━━━━━━━━━━━━\n_Global Anti-Delete, Anti-Edit, and Anti-Delete Status settings were not changed._");
    }
    if (value16 === "off") {
      setGroupProtectionBundle(value14, false);
      return value15("❌ *AntiAll — Group Protections DISABLED*\n━━━━━━━━━━━━━━━━━━━━\n  ❌ ⛔ AntiAll Master\n" + GROUP_FEATURES.map(value22 => "  ❌ " + value22.label).join("\n") + "\n  ❌ 🛡️ Anti-Tag Admins\n━━━━━━━━━━━━━━━━━━━━\n_Global Anti-Delete, Anti-Edit, and Anti-Delete Status settings were not changed._");
    }
    if (value16 === "master") {
      const value23 = (value12[1] || "").toLowerCase();
      if (value23 === "on" || value23 === "off") {
        database.setAntiAllEnabled(value14, value23 === "on");
        return value15(value23 === "on" ? "⛔ *AntiAll Master ON* — every message from non-admins is now deleted, not just rule-breaking ones.\n_Use .antiall master off if members should chat freely._" : "💬 *AntiAll Master OFF* — members can chat freely. All individual protections stay armed and still delete rule-breaking messages.");
      }
      return value15("⚠️ Usage: .antiall master on | off");
    }
    return value15("⚠️ Usage: .antiall on | off | master on/off\nNo argument shows current status.");
  }
};
