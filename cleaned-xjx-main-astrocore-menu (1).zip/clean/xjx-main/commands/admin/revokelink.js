module.exports = {
  name: "revokelink",
  aliases: ["resetlink", "revoke", "newlink"],
  category: "admin",
  description: "Reset the group invite link (old links stop working)",
  usage: ".revokelink",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      if (value4.react) {
        await value4.react("🔁").catch(() => {});
      }
      const value5 = await value1.groupRevokeInvite(value4.from);
      if (!value5) {
        throw new Error("WhatsApp did not return a new invite code.");
      }
      const value6 = "https://chat.whatsapp.com/" + value5;
      const value7 = value4.groupMetadata?.subject || "this group";
      if (value4.react) {
        await value4.react("✅").catch(() => {});
      }
      await value4.reply("🔁 *Invite link reset*\n\n" + ("Group: *" + value7 + "*\n") + ("New link:\n" + value6 + "\n\n") + "⚠️ Every old link for this group is now dead.");
    } catch (error8) {
      console.error("[revokelink]", error8.message);
      if (value4.react) {
        await value4.react("❌").catch(() => {});
      }
      const value9 = /not-authorized|401|403|forbidden/i.test(error8.message || "");
      await value4.reply(value9 ? "❌ I cannot reset the link. Make sure the bot is an admin." : "❌ Failed to reset link: " + error8.message);
    }
  }
};
