const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "resetwarn",
  aliases: ["resetwarning", "clearwarn", "unwarn", "delwarn"],
  category: "admin",
  description: "Reset all warnings for a user",
  usage: ".resetwarn @user",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      let value5;
      const value6 = value2.message?.extendedTextMessage?.contextInfo;
      const value7 = value6?.mentionedJid || [];
      if (value7 && value7.length > 0) {
        value5 = value7[0];
      } else if (value6?.participant && value6.stanzaId && value6.quotedMessage) {
        value5 = value6.participant;
      } else {
        return value4.reply("❌ Please mention or reply to the user to reset warnings!\n\nExample: .resetwarn @user");
      }
      const value8 = database.getWarnings(value4.from, value5);
      if (value8.count === 0) {
        return value4.reply("✅ @" + value5.split("@")[0] + " has no warnings to reset.", {
          mentions: [value5]
        });
      }
      database.clearWarnings(value4.from, value5);
      await value1.sendMessage(value4.from, {
        text: "✅ *Warnings Reset*\n\n👤 User: @" + value5.split("@")[0] + "\n⚠️ Previous warnings: " + value8.count + "\n\nAll warnings have been cleared.",
        mentions: [value5]
      }, {
        quoted: value2
      });
    } catch (error9) {
      console.error("ResetWarn command error:", error9);
      await value4.reply("❌ Error: " + error9.message);
    }
  }
};
