const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antilink",
  aliases: ["al", "nolink"],
  category: "admin",
  description: "Block links in the group — delete, kick, or warn the sender",
  usage: ".antilink on | off | delete | kick | warn",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const {
        from: value5,
        isOwner: value6,
        isAdmin: value7,
        reply: value8,
        react: value9
      } = value4;
      const value10 = database.getGroupSettings(value5);
      const value11 = (value3[0] || "").toLowerCase();
      if (!value11 || value11 === "status") {
        const value12 = value10.antilink ? "✅ ON" : "❌ OFF";
        const value13 = value10.antilinkAction || "delete";
        const value14 = {
          delete: "🗑️ Delete message",
          kick: "👢 Delete + kick sender",
          warn: "⚠️ Delete + warn (kick at " + (database.getBotSetting("maxWarnings") || 3) + " warns)"
        }[value13] || value13;
        return value8("🔗 *Antilink*\n" + ("Status: *" + value12 + "* | Action: *" + value14 + "*\n\n") + ".antilink delete | kick | warn | on | off");
      }
      if (value11 === "on") {
        if (value10.antilink) {
          return value8("ℹ️ Antilink is already *ON*.");
        }
        database.updateGroupSettings(value5, {
          antilink: true
        });
        const value15 = value10.antilinkAction || "delete";
        await value9("✅");
        return value8("🔗 *Antilink ON* ✅\nAction: *" + value15 + "*");
      }
      if (value11 === "off") {
        database.updateGroupSettings(value5, {
          antilink: false
        });
        await value9("❌");
        return value8("🔗 *Antilink OFF* ❌\nLinks are now allowed in this group.");
      }
      if (["delete", "kick", "warn"].includes(value11)) {
        database.updateGroupSettings(value5, {
          antilink: true,
          antilinkAction: value11
        });
        const value16 = {
          delete: "🗑️ delete the message",
          kick: "👢 delete + kick sender",
          warn: "⚠️ delete + warn sender (kick at " + (database.getBotSetting("maxWarnings") || 3) + " warnings)"
        }[value11];
        await value9("✅");
        return value8("🔗 *Antilink ON* ✅\nAction: *" + value16 + "*");
      }
      return value8("❓ Unknown option.\nUsage: *.antilink delete | kick | warn | on | off*");
    } catch (error17) {
      await value4.reply("❌ Error: " + error17.message);
    }
  }
};
