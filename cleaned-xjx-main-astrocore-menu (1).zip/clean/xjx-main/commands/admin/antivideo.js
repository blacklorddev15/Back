const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antivideo",
  aliases: ["novideo", "antivid"],
  category: "admin",
  description: "Block videos in group — delete, warn, or kick the sender",
  usage: ".antivideo on | off | action delete|warn|kick",
  groupOnly: true,
  adminOnly: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6
    } = value4;
    const value7 = database.getGroupSettings(value5);
    const value8 = (value3[0] || "").toLowerCase();
    if (!value8) {
      const value9 = value7.antivideoAction || "delete";
      return value6("🎬 *Anti-Video Settings*\n━━━━━━━━━━━━━━━\n" + ("📌 Status: *" + (value7.antivideo ? "✅ ON" : "❌ OFF") + "*\n") + ("⚡ Action: *" + value9 + "*\n\n") + "*Commands:*\n  .antivideo on               — enable\n  .antivideo off              — disable\n  .antivideo action delete    — silently delete videos\n  .antivideo action warn      — warn; kick at max warnings\n  .antivideo action kick      — immediately kick sender\n\n_Admins and bot owner are always exempt._");
    }
    if (value8 === "on") {
      database.updateGroupSettings(value5, {
        antivideo: true
      });
      const value10 = value7.antivideoAction || "delete";
      return value6("✅ *Anti-Video* enabled.\nAction: *" + value10 + "*.\n_Videos sent by non-admins will be " + value10 + "ed._");
    }
    if (value8 === "off") {
      database.updateGroupSettings(value5, {
        antivideo: false
      });
      return value6("❌ *Anti-Video* disabled.");
    }
    if (value8 === "action") {
      const value11 = (value3[1] || "").toLowerCase();
      if (!["delete", "warn", "kick"].includes(value11)) {
        return value6("⚠️ Valid actions: delete | warn | kick");
      }
      database.updateGroupSettings(value5, {
        antivideoAction: value11
      });
      return value6("✅ Anti-Video action set to *" + value11 + "*.");
    }
    return value6("⚠️ Unknown option. Use .antivideo for help.");
  }
};
