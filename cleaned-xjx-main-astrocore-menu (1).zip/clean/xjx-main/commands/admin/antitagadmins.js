'use strict';

const database = require("../../database");
const ACTION_LABELS = {
  kick: "👢 Kick",
  warn: "⚠️ Warn",
  delete: "🗑️ Delete"
};
const VALID_ACTIONS = new Set(["kick", "warn", "delete"]);
module.exports = {
  name: "antitagadmins",
  aliases: ["antiadmintag", "antitagadmin", "notagadmin"],
  category: "admin",
  description: "Prevent non-admins from tagging group admins",
  usage: ".antitagadmins on [kick|warn|delete] | .antitagadmins off",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6
    } = value4;
    const value7 = database.getAntiTagAdminsSettings(value5);
    const value8 = value7.enabled ? "✅ *ON* — action: *" + (ACTION_LABELS[value7.action] || value7.action) + "*" : "❌ *OFF*";
    if (!value3.length) {
      return value6("🛡️ *AntiTagAdmins*\n\n" + ("Status: " + value8 + "\n\n") + "*Commands:*\n• `.antitagadmins on` — enable (default: warn)\n• `.antitagadmins on kick` — kick the offender\n• `.antitagadmins on warn` — warn + delete message\n• `.antitagadmins on delete` — silently delete message\n• `.antitagadmins off` — disable");
    }
    const value9 = value3[0].toLowerCase();
    const value10 = (value3[1] || "warn").toLowerCase();
    if (value9 === "off") {
      database.setAntiTagAdminsSettings(value5, {
        enabled: false
      });
      return value6("🛡️ *AntiTagAdmins* turned ❌ *OFF*.");
    }
    if (value9 === "on") {
      const value11 = VALID_ACTIONS.has(value10) ? value10 : "warn";
      database.setAntiTagAdminsSettings(value5, {
        enabled: true,
        action: value11
      });
      return value6("🛡️ *AntiTagAdmins* turned ✅ *ON*\n\n" + ("Action: *" + ACTION_LABELS[value11] + "*\n\n") + ("Non-admins who tag group admins will be *" + value11 + "ed*."));
    }
    return value6("❌ Usage: `.antitagadmins on [kick|warn|delete]` | `.antitagadmins off`");
  },
  async handleMessage(value12, value13, value14, value15, value16, value17 = false) {
    const value18 = database.getAntiTagAdminsSettings(value16);
    if (!value18.enabled || value13.key?.fromMe) {
      return;
    }
    const value19 = value13.message?.extendedTextMessage?.contextInfo || value13.message?.imageMessage || value13.message?.videoMessage;
    const value20 = value19?.mentionedJid || [];
    if (!value20.length) {
      return;
    }
    const value21 = value14?.participants || [];
    const value22 = new Set(value21.filter(value23 => value23.admin).map(value24 => value24.id));
    if (!value22.size) {
      return;
    }
    const value25 = value20.filter(value26 => value22.has(value26));
    if (!value25.length) {
      return;
    }
    const value27 = value21.some(value28 => value28.id === value15 && value28.admin);
    if (value27 || value17) {
      return;
    }
    const value29 = value18.action;
    const value30 = value25.map(value31 => "@" + value31.split("@")[0]).join(", ");
    try {
      try {
        await value12.sendMessage(value16, {
          delete: value13.key
        });
      } catch (error32) {}
      if (value29 === "warn") {
        await value12.sendMessage(value16, {
          text: "🛡️ *AntiTagAdmins*\n\n⚠️ @" + value15.split("@")[0] + ", you are *not allowed* to tag admins (" + value30 + ").\nFurther violations may result in a kick.",
          mentions: [value15, ...value25]
        }, {
          quoted: value13
        });
      }
      if (value29 === "kick") {
        try {
          await value12.groupParticipantsUpdate(value16, [value15], "remove");
        } catch (error33) {}
        await value12.sendMessage(value16, {
          text: "🛡️ *AntiTagAdmins*\n\n👢 @" + value15.split("@")[0] + " was kicked for tagging admins (" + value30 + ").",
          mentions: [value15, ...value25]
        });
      }
    } catch (error34) {
      console.error("[ANTITAGADMINS] error:", error34.message);
    }
  }
};
