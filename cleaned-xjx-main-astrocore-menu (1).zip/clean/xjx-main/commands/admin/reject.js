module.exports = {
  name: "reject",
  aliases: ["rejectjoin", "declinejoin", "decline"],
  category: "admin",
  description: "Reject pending group join requests",
  usage: ".reject all | @user",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6,
      react: value7
    } = value4;
    const value8 = value3[0]?.toLowerCase();
    const value9 = async () => {
      try {
        return (await value1.groupRequestParticipantsList(value5)) || [];
      } catch {
        return [];
      }
    };
    if (value8 === "all") {
      const value10 = await value9();
      if (!value10.length) {
        return value6("⚠️ No pending join requests.");
      }
      const value11 = value10.map(value12 => value12.jid);
      await value1.groupRequestParticipantsUpdate(value5, value11, "reject");
      await value7("✅");
      return await value1.sendMessage(value5, {
        text: "🚫 *Rejected " + value11.length + " join request" + (value11.length !== 1 ? "s" : "") + ".*"
      }, {
        quoted: value2
      });
    }
    const value13 = value2.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const value14 = value2.message?.extendedTextMessage?.contextInfo?.participant;
    let value15 = value13[0] || value14 || null;
    if (!value15 && value3[0]) {
      const value16 = value3[0].replace(/\D/g, "");
      if (value16.length >= 7) {
        value15 = value16 + "@s.whatsapp.net";
      }
    }
    if (!value15) {
      return value6("❌ *Usage:*\n  .reject all — reject all pending requests\n  .reject @user — reject a specific user");
    }
    await value1.groupRequestParticipantsUpdate(value5, [value15], "reject");
    await value7("✅");
    const value17 = value15.split("@")[0];
    return await value1.sendMessage(value5, {
      text: "🚫 *@" + value17 + "*'s join request has been rejected.",
      mentions: [value15]
    }, {
      quoted: value2
    });
  }
};
