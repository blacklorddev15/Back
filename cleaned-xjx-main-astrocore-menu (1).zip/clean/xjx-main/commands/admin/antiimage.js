const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antiimage",
  aliases: ["antiphoto", "antiimg"],
  category: "admin",
  description: "Block images in group (delete/warn/kick)",
  usage: ".antiimage <on/off/set/get>",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = database.getGroupSettings(value4.from);
      const value6 = value5.antiimage ? "ON" : "OFF";
      const value7 = value5.antiimageAction || "delete";
      if (!value3[0]) {
        return value4.reply("🖼️ *Anti Image*\n━━━━━━━━━━━━━━━\n\n" + ("📌 Status: *" + value6 + "*\n") + ("⚡ Action: *" + value7 + "*\n\n") + "*Usage:*\n  .antiimage on\n  .antiimage off\n  .antiimage set delete\n  .antiimage set warn\n  .antiimage set kick\n  .antiimage get");
      }
      const value8 = value3[0].toLowerCase();
      if (value8 === "on") {
        if (value5.antiimage) {
          return value4.reply("🖼️ *Anti Image is already ON*");
        }
        database.updateGroupSettings(value4.from, {
          antiimage: true
        });
        return value4.reply("🖼️ *Anti Image turned ON*\n⚡ Action: *" + value7 + "*");
      }
      if (value8 === "off") {
        database.updateGroupSettings(value4.from, {
          antiimage: false
        });
        return value4.reply("🖼️ *Anti Image turned OFF*");
      }
      if (value8 === "set") {
        if (!value3[1]) {
          return value4.reply("⚠️ Use: .antiimage set delete/warn/kick");
        }
        const value9 = value3[1].toLowerCase();
        if (!["delete", "warn", "kick"].includes(value9)) {
          return value4.reply("❌ Choose: delete, warn, or kick");
        }
        database.updateGroupSettings(value4.from, {
          antiimageAction: value9,
          antiimage: true
        });
        return value4.reply("🖼️ *Anti Image action set to " + value9 + "*");
      }
      if (value8 === "get") {
        return value4.reply("🖼️ *Anti Image Config*\n📌 Status: *" + value6 + "*\n⚡ Action: *" + value7 + "*");
      }
      return value4.reply("⚠️ Use .antiimage for usage info.");
    } catch (error10) {
      await value4.reply("❌ Error: " + error10.message);
    }
  }
};
