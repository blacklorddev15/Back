const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "unmute",
  aliases: ["unsilence", "opengroup"],
  category: "admin",
  description: "Unmute a user or reopen the group",
  usage: ".unmute @user  OR  .unmute  (opens group)",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      const value6 = value2.message?.extendedTextMessage?.contextInfo;
      const value7 = value6?.mentionedJid || [];
      const value8 = value6?.participant && value6.stanzaId ? value6.participant : null;
      const value9 = value7[0] || value8;
      if (!value9) {
        await value1.groupSettingUpdate(value5, "not_announcement");
        return value4.reply("🔓 *Group Opened*\n\nAll members can send messages again.");
      }
      const value10 = database.unmuteUser(value5, value9);
      const value11 = value9.split("@")[0];
      if (!value10) {
        return value4.reply("ℹ️ @" + value11 + " is not muted.");
      }
      await value1.sendMessage(value5, {
        text: "🔊 *User Unmuted*\n\n" + ("👤 @" + value11 + " has been unmuted.\n") + "✅ Their messages will no longer be deleted.",
        mentions: [value9]
      }, {
        quoted: value2
      });
    } catch (error12) {
      console.error("[unmute] error:", error12);
      await value4.reply("❌ Error: " + error12.message);
    }
  }
};
