const database = require(require("path").join(global.__CORE__, "database"));
const BOT_PATTERNS = [/\bbot\b/i, /\bai\b/i, /assistant/i, /automat/i, /robot/i, /\bscript\b/i, /spambot/i, /floodbot/i, /chatbot/i, /userbot/i];
const WHITELIST_PATTERNS = [/junex/i, /june[\s\-_]?x/i, /june[\s\-_]?ultra/i];
const isWhitelisted = value1 => !!value1 && WHITELIST_PATTERNS.some(value2 => value2.test(value1));
const isBotName = value3 => !!value3 && !isWhitelisted(value3) && BOT_PATTERNS.some(value4 => value4.test(value3));
const BOT_SERVERS = ["@hosted.lid", "@hosted", "@agent", "@bot.whatsapp.net"];
const isBotJid = value5 => {
  if (!value5 || typeof value5 !== "string") {
    return false;
  }
  return BOT_SERVERS.some(value6 => value5.endsWith(value6));
};
const safeGetStatus = async (value7, value8) => {
  try {
    const value9 = await value7.fetchStatus(value8);
    if (!value9) {
      return null;
    }
    if (Array.isArray(value9)) {
      const value10 = value9.find(value11 => value11?.id === value8 || value11?.jid === value8 || value11?.id?.user === value8.split("@")[0]);
      return value10?.status?.status || value10?.status || null;
    }
    return value9?.status || null;
  } catch {
    return null;
  }
};
const getBotJid = value12 => {
  const value13 = value12?.user?.id;
  if (!value13) {
    return null;
  }
  if (value13.includes(":")) {
    return value13.split(":")[0] + "@s.whatsapp.net";
  } else {
    return value13;
  }
};
const isParticipantAdmin = (value14 = [], value15) => {
  if (!value15) {
    return false;
  }
  const value16 = value15.split("@")[0].split(":")[0];
  return value14.some(value17 => {
    if (value17.admin !== "admin" && value17.admin !== "superadmin") {
      return false;
    }
    const value18 = (value17.id || value17.lid || "").split("@")[0].split(":")[0];
    return value18 === value16;
  });
};
const isSuspectedBot = async (value19, value20, value21) => {
  if (isBotJid(value20)) {
    return true;
  }
  const value22 = value20.split("@")[0];
  if (isBotName(value22) || isBotName(value21)) {
    return true;
  }
  const value23 = await safeGetStatus(value19, value20);
  if (value23 && isBotName(value23)) {
    return true;
  }
  return false;
};
module.exports = {
  name: "antibot",
  aliases: ["nobot", "botblock"],
  category: "admin",
  description: "Auto-kick suspected bot/agent accounts from the group",
  usage: ".antibot on | off | status",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value24, value25, value26, value27) {
    const {
      from: value28,
      reply: value29,
      react: value30
    } = value27;
    const value31 = (value26[0] || "").toLowerCase();
    const value32 = database.getGroupSettings(value28);
    if (!value31 || value31 === "status") {
      return value29("🤖 *AntiBot Settings*\n━━━━━━━━━━━━━━━\n" + ("📌 Status: *" + (value32.antibot ? "✅ ON" : "❌ OFF") + "*\n\n") + "*Detection methods:*\n  • WhatsApp API agent JIDs (@hosted.lid / @hosted)\n  • Name keyword matching (bot, ai, assistant, robot…)\n  • Profile bio scanning\n\n*Commands:*\n  .antibot on      — enable\n  .antibot off     — disable\n  .antibot status  — show this panel\n\n_Admins and bot owner are always exempt._");
    }
    if (value31 === "on") {
      if (value32.antibot) {
        return value29("🤖 AntiBot is already *ON*.");
      }
      database.updateGroupSettings(value28, {
        antibot: true
      });
      await value30("✅");
      return value29("🤖 *AntiBot* turned *ON*.\nSuspected bot accounts will be auto-kicked on join or message.");
    }
    if (value31 === "off") {
      database.updateGroupSettings(value28, {
        antibot: false
      });
      await value30("❌");
      return value29("🤖 *AntiBot* turned *OFF*.");
    }
    return value29("⚠️ Unknown option. Use .antibot for help.");
  },
  async handleGroupJoin(value33, value34, value35) {
    try {
      const value36 = database.getGroupSettings(value34);
      if (!value36.antibot) {
        return;
      }
      const value37 = getBotJid(value33);
      if (value37 && value35.split("@")[0] === value37.split("@")[0]) {
        return;
      }
      const value38 = await isSuspectedBot(value33, value35, null);
      if (!value38) {
        return;
      }
      await value33.groupParticipantsUpdate(value34, [value35], "remove");
      await value33.sendMessage(value34, {
        text: "🤖 *AntiBot* — Auto-kicked *@" + value35.split("@")[0] + "*\n📌 Reason: Detected as a bot/agent account on join.",
        mentions: [value35]
      });
    } catch (error39) {
      console.error("[ANTIBOT] handleGroupJoin error:", error39.message);
    }
  },
  async handleMessage(value40, value41, value42) {
    try {
      if (!value41?.key || !value41.message) {
        return;
      }
      const value43 = value41.key.remoteJid;
      if (!value43?.endsWith("@g.us")) {
        return;
      }
      const value44 = database.getGroupSettings(value43);
      if (!value44.antibot) {
        return;
      }
      if (value41.key.fromMe) {
        return;
      }
      const value45 = value41.key.participant || value41.key.remoteJid;
      if (!value45) {
        return;
      }
      const value46 = getBotJid(value40);
      if (value46 && value45.split("@")[0] === value46.split("@")[0]) {
        return;
      }
      const value47 = value45.split("@")[0].split(":")[0];
      if (database.getOwners()?.some(value48 => value48.replace(/\D/g, "") === value47)) {
        return;
      }
      const value49 = value42?.participants || [];
      if (isParticipantAdmin(value49, value45)) {
        return;
      }
      const value50 = value41.pushName || "";
      const value51 = await isSuspectedBot(value40, value45, value50);
      if (!value51) {
        return;
      }
      await value40.groupParticipantsUpdate(value43, [value45], "remove");
      await value40.sendMessage(value43, {
        text: "🤖 *AntiBot* — Auto-kicked *@" + value47 + "*\n📌 Reason: Detected as a bot/agent account via message.",
        mentions: [value45]
      });
    } catch (error52) {
      console.error("[ANTIBOT] handleMessage error:", error52.message);
    }
  }
};
