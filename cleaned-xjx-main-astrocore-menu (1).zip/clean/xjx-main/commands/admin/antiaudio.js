const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antiaudio",
  aliases: ["antivoice", "antivn"],
  category: "admin",
  description: "Block audio/voice notes in group (delete/warn/kick)",
  usage: ".antiaudio <on/off/set/get>",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = database.getGroupSettings(value4.from);
      const value6 = value5.antiaudio ? "ON" : "OFF";
      const value7 = value5.antiaudioAction || "delete";
      if (!value3[0]) {
        return value4.reply("🔇 *Anti Audio*\n━━━━━━━━━━━━━━━\n\n" + ("📌 Status: *" + value6 + "*\n") + ("⚡ Action: *" + value7 + "*\n\n") + "*Usage:*\n  .antiaudio on\n  .antiaudio off\n  .antiaudio set delete\n  .antiaudio set warn\n  .antiaudio set kick\n  .antiaudio get");
      }
      const value8 = value3[0].toLowerCase();
      if (value8 === "on") {
        if (value5.antiaudio) {
          return value4.reply("🔇 *Anti Audio is already ON*");
        }
        database.updateGroupSettings(value4.from, {
          antiaudio: true
        });
        return value4.reply("🔇 *Anti Audio turned ON*\n⚡ Action: *" + value7 + "*");
      }
      if (value8 === "off") {
        database.updateGroupSettings(value4.from, {
          antiaudio: false
        });
        return value4.reply("🔇 *Anti Audio turned OFF*");
      }
      if (value8 === "set") {
        if (!value3[1]) {
          return value4.reply("⚠️ Use: .antiaudio set delete/warn/kick");
        }
        const value9 = value3[1].toLowerCase();
        if (!["delete", "warn", "kick"].includes(value9)) {
          return value4.reply("❌ Choose: delete, warn, or kick");
        }
        database.updateGroupSettings(value4.from, {
          antiaudioAction: value9,
          antiaudio: true
        });
        return value4.reply("🔇 *Anti Audio action set to " + value9 + "*");
      }
      if (value8 === "get") {
        return value4.reply("🔇 *Anti Audio Config*\n📌 Status: *" + value6 + "*\n⚡ Action: *" + value7 + "*");
      }
      return value4.reply("⚠️ Use .antiaudio for usage info.");
    } catch (error10) {
      await value4.reply("❌ Error: " + error10.message);
    }
  }
};
