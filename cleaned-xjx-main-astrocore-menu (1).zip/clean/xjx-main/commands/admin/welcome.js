const db = require("../../database");
module.exports = {
  name: "welcome",
  aliases: ["welcomeon", "welcomeoff"],
  category: "admin",
  desc: "Enable/disable welcome messages",
  usage: "welcome on/off",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  execute: async (value1, value2, value3) => {
    try {
      const value4 = value2.key.remoteJid;
      const value5 = value3[0]?.toLowerCase();
      if (!value5 || !["on", "off"].includes(value5)) {
        const value6 = db.getGroupSettings(value4);
        const value7 = value6.welcome ? "✅ Enabled" : "❌ Disabled";
        return await value1.sendMessage(value4, {
          text: "👋 *Welcome Messages*\n\nStatus: " + value7 + "\nMessage: " + value6.welcomeMessage + "\n\nUsage: .welcome on/off\n\nTo customize: .setwelcome <message>"
        }, {
          quoted: value2
        });
      }
      const value8 = value5 === "on";
      db.updateGroupSettings(value4, {
        welcome: value8
      });
      await value1.sendMessage(value4, {
        text: "✅ Welcome messages " + (value8 ? "enabled" : "disabled") + "!" + (value8 ? "\n\nNew members will now receive welcome messages." : "")
      }, {
        quoted: value2
      });
    } catch (error9) {
      console.error("Welcome Error:", error9);
      await value1.sendMessage(value2.key.remoteJid, {
        text: "❌ Error: " + error9.message
      }, {
        quoted: value2
      });
    }
  }
};
