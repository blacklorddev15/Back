const db = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "setgoodbye",
  aliases: ["goodbyetext"],
  category: "admin",
  desc: "Set custom goodbye message",
  usage: "setgoodbye <message> (use @user for member mention)",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  execute: async (value1, value2, value3) => {
    try {
      const value4 = value2.key.remoteJid;
      if (!value3.length) {
        const value5 = db.getGroupSettings(value4);
        return await value1.sendMessage(value4, {
          text: "📝 *Current Goodbye Message*\n\n" + value5.goodbyeMessage + "\n\n*Usage:* .setgoodbye <message>\n\n*Tip:* Use @user to mention the member who left"
        }, {
          quoted: value2
        });
      }
      const value6 = value3.join(" ");
      if (value6.length > 500) {
        return await value1.sendMessage(value4, {
          text: "❌ Goodbye message is too long! Maximum 500 characters."
        }, {
          quoted: value2
        });
      }
      db.updateGroupSettings(value4, {
        goodbyeMessage: value6
      });
      await value1.sendMessage(value4, {
        text: "✅ Goodbye message updated!\n\n*Preview:*\n" + value6.replace("@user", "@" + value2.key.participant.split("@")[0]),
        mentions: [value2.key.participant]
      }, {
        quoted: value2
      });
    } catch (error7) {
      console.error("Set Goodbye Error:", error7);
      await value1.sendMessage(value2.key.remoteJid, {
        text: "❌ Error: " + error7.message
      }, {
        quoted: value2
      });
    }
  }
};
