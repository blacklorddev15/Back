module.exports = {
  name: "approve",
  aliases: ["acceptjoin", "approvejoin"],
  category: "admin",
  description: "Approve or reject pending group join requests",
  usage: ".approve all | @user | none",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6,
      react: value7
    } = value4;
    const value8 = value3[0]?.toLowerCase();
    const value9 = async () => {
      try {
        return (await value1.groupRequestParticipantsList(value5)) || [];
      } catch {
        return [];
      }
    };
    if (!value8) {
      const value10 = await value9();
      if (!value10.length) {
        return value6("✅ No pending join requests in this group.");
      }
      const value11 = value10.map((value12, value13) => "  " + (value13 + 1) + ". @" + value12.jid.split("@")[0]).join("\n");
      return await value1.sendMessage(value5, {
        text: "📋 *Pending Join Requests (" + value10.length + ")*\n\n" + value11 + "\n\nUse:\n  • *.approve all* — approve everyone\n  • *.approve @user* — approve one person\n  • *.approve none* — reject everyone\n  • *.reject @user* — reject one person",
        mentions: value10.map(value14 => value14.jid)
      }, {
        quoted: value2
      });
    }
    if (value8 === "all") {
      const value15 = await value9();
      if (!value15.length) {
        return value6("⚠️ No pending join requests.");
      }
      const value16 = value15.map(value17 => value17.jid);
      await value1.groupRequestParticipantsUpdate(value5, value16, "approve");
      await value7("✅");
      return await value1.sendMessage(value5, {
        text: "✅ *Approved " + value16.length + " join request" + (value16.length !== 1 ? "s" : "") + ".*"
      }, {
        quoted: value2
      });
    }
    if (value8 === "none") {
      const value18 = await value9();
      if (!value18.length) {
        return value6("⚠️ No pending join requests.");
      }
      const value19 = value18.map(value20 => value20.jid);
      await value1.groupRequestParticipantsUpdate(value5, value19, "reject");
      await value7("✅");
      return await value1.sendMessage(value5, {
        text: "🚫 *Rejected " + value19.length + " join request" + (value19.length !== 1 ? "s" : "") + ".*"
      }, {
        quoted: value2
      });
    }
    const value21 = value2.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const value22 = value2.message?.extendedTextMessage?.contextInfo?.participant;
    let value23 = value21[0] || value22 || null;
    if (!value23 && value3[0]) {
      const value24 = value3[0].replace(/\D/g, "");
      if (value24.length >= 7) {
        value23 = value24 + "@s.whatsapp.net";
      }
    }
    if (!value23) {
      return value6("❌ *Usage:*\n  .approve all — approve all pending requests\n  .approve @user — approve a specific user\n  .approve none — reject all pending requests");
    }
    await value1.groupRequestParticipantsUpdate(value5, [value23], "approve");
    await value7("✅");
    const value25 = value23.split("@")[0];
    return await value1.sendMessage(value5, {
      text: "✅ *@" + value25 + "* has been approved to join the group.",
      mentions: [value23]
    }, {
      quoted: value2
    });
  }
};
