module.exports = {
  name: "getgroupdesc",
  aliases: ["groupdesc", "gdesc", "description"],
  category: "admin",
  description: "Get the group's description",
  usage: ".getgroupdesc",
  groupOnly: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      const value6 = value4.groupMetadata;
      const value7 = value6.desc?.trim();
      const value8 = value6.subject || "This group";
      if (!value7) {
        return value4.reply("ℹ️ *" + value8 + "* has no description set.");
      }
      const value9 = value6.descTime ? new Date(value6.descTime * 1000).toLocaleString() : "Unknown";
      const value10 = value6.descOwner ? "@" + value6.descOwner.split("@")[0] : "Unknown";
      let value11 = "📋 *Group Description*\n\n";
      value11 += "🏷️ Group: *" + value8 + "*\n";
      value11 += "🕒 Set on: " + value9 + "\n";
      value11 += "👤 Set by: " + value10 + "\n\n";
      value11 += "📝 " + value7;
      const value12 = value6.descOwner ? [value6.descOwner] : [];
      await value1.sendMessage(value5, {
        text: value11,
        mentions: value12
      }, {
        quoted: value2
      });
    } catch (error13) {
      console.error("getgroupdesc error:", error13);
      value4.reply("❌ Failed to fetch group description.");
    }
  }
};
