module.exports = {
  name: "demoteall",
  aliases: ["removeadmins", "demoteadmins"],
  category: "admin",
  description: "Demote all admins in the group (bot and creator are protected)",
  usage: ".demoteall",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      const value6 = await value1.groupMetadata(value5);
      const value7 = value6.participants || [];
      const value8 = (value9 = "") => value9.split("@")[0].split(":")[0];
      const value10 = value1.user?.id || "";
      const value11 = value8(value10);
      const value12 = value6.owner || value6.creator || "";
      const value13 = value8(value12);
      const value14 = value15 => {
        const value16 = value8(value15.id);
        if (value16 === value11) {
          return true;
        }
        if (value16 === value13 && value13) {
          return true;
        }
        if (value15.admin === "superadmin") {
          return true;
        }
        return false;
      };
      let value17 = value7.filter(value18 => value18.admin === "admin" && !value14(value18)).map(value19 => value19.id);
      value17 = value17.filter(value20 => value8(value20) !== value11);
      if (value17.length === 0) {
        return value4.reply("ℹ️ No admins to demote — bot and group creator are protected.");
      }
      await value1.groupParticipantsUpdate(value5, value17, "demote");
      const value21 = "✅ *Demote All Complete*\n\n" + ("👤 *Demoted (" + value17.length + "):*\n") + value17.map(value22 => "• @" + value8(value22)).join("\n");
      await value1.sendMessage(value5, {
        text: value21,
        mentions: value17
      }, {
        quoted: value2
      });
    } catch (error23) {
      console.error("[demoteall] Error:", error23);
      await value4.reply("❌ Error: " + error23.message);
    }
  }
};
