const handler = require(require("path").join(global.__CORE__, "handler"));
module.exports = {
  name: "kick",
  aliases: ["remove", "out"],
  category: "admin",
  description: "Kick mentioned/replied members from the group",
  usage: ".kick @user",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      const value6 = value2.message?.extendedTextMessage?.contextInfo;
      const value7 = value6?.mentionedJid || [];
      let value8 = [];
      if (value7 && value7.length > 0) {
        value8 = value7;
      } else if (value6?.participant && value6.stanzaId && value6.quotedMessage) {
        value8 = [value6.participant];
      }
      if (value8.length === 0) {
        return value4.reply("👤 Mention or reply to the user you want to kick.");
      }
      const value9 = value1.user?.id || "";
      const value10 = value1.user?.lid || "";
      const value11 = value9.includes(":") ? value9.split(":")[0] : value9.includes("@") ? value9.split("@")[0] : value9;
      const value12 = value11 + "@s.whatsapp.net";
      const value13 = value10.includes(":") ? value10.split(":")[0] : value10.includes("@") ? value10.split("@")[0] : value10;
      const value14 = value10.includes("@") ? value10.split("@")[0] : value10;
      const value15 = await value1.groupMetadata(value5);
      const value16 = value15.participants || [];
      const value17 = value8.some(value18 => {
        const value19 = value18.includes(":") ? value18.split(":")[0] : value18.includes("@") ? value18.split("@")[0] : value18;
        const value20 = value18.includes("@lid") ? value18.split("@")[0].split(":")[0] : "";
        const value21 = value18 === value9 || value18 === value10 || value18 === value12 || value19 === value11 || value20 && value13 && value20 === value13;
        if (value21) {
          return true;
        }
        const value22 = value16.some(value23 => {
          const value24 = value23.phoneNumber ? value23.phoneNumber.split("@")[0] : "";
          const value25 = value23.id ? value23.id.split("@")[0] : "";
          const value26 = value23.lid ? value23.lid.split("@")[0] : "";
          const value27 = value23.id || "";
          const value28 = value23.lid || "";
          const value29 = value26.includes(":") ? value26.split(":")[0] : value26;
          const value30 = value27 === value9 || value28 === value10 || value29 === value13 || value24 === value11 || value25 === value11 || value23.phoneNumber === value12 || value10 && value26 && value14 === value26;
          if (!value30) {
            return false;
          }
          return value18 === value27 || value18 === value28 || value19 === value24 || value19 === value25 || value18 === value23.phoneNumber || value26 && value20 && value20 === value29 || value20 && value29 && value20 === value29;
        });
        return value22;
      });
      if (value17) {
        await value4.reply("❌ Cannot kick myself!");
        return;
      }
      await value1.groupParticipantsUpdate(value5, value8, "remove");
      const value31 = value8.map(value32 => "@" + value32.split("@")[0]);
      const value33 = "✅ " + value31.join(", ") + " has been kicked successfully.";
      await value1.sendMessage(value4.from, {
        text: value33,
        mentions: value8
      }, {
        quoted: value2
      });
    } catch (error34) {
      console.error("Kick command error:", error34);
      await value4.reply("❌ Failed to kick user(s). Make sure I am admin.");
    }
  }
};
