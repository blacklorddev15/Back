const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antisticker",
  aliases: ["antis"],
  category: "admin",
  description: "Block stickers in group — delete, warn the whole group, or kick sender",
  usage: ".antisticker <on/off/set/get>",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = database.getGroupSettings(value4.from);
      const value6 = value5.antisticker ? "ON ✅" : "OFF ❌";
      const value7 = value5.antistickerAction || "delete";
      const value8 = {
        delete: "Delete sticker silently + notify group",
        warn: "Delete + warn sender (group-wide) — removed at max warnings",
        kick: "Delete + instantly remove sender from group"
      }[value7] || value7;
      if (!value3[0]) {
        return value4.reply("🎭 *Anti Sticker*\n━━━━━━━━━━━━━━━\n\n" + ("📌 Status: *" + value6 + "*\n") + ("⚡ Action: *" + value7 + "* — _" + value8 + "_\n\n") + "*Commands:*\n  .antisticker on\n  .antisticker off\n  .antisticker set delete  — silent delete + group notice\n  .antisticker set warn    — warn whole group, kick at max\n  .antisticker set kick    — instant remove from group\n  .antisticker get");
      }
      const value9 = value3[0].toLowerCase();
      if (value9 === "on") {
        if (value5.antisticker) {
          return value4.reply("🎭 *Anti Sticker is already ON*");
        }
        database.updateGroupSettings(value4.from, {
          antisticker: true
        });
        return value4.reply("🎭 *Anti Sticker turned ON*\n" + ("⚡ Action: *" + value7 + "* — _" + value8 + "_\n\n") + "_All sticker messages from non-admins will be handled automatically._");
      }
      if (value9 === "off") {
        database.updateGroupSettings(value4.from, {
          antisticker: false
        });
        return value4.reply("🎭 *Anti Sticker turned OFF*");
      }
      if (value9 === "set") {
        if (!value3[1]) {
          return value4.reply("⚠️ Use: .antisticker set delete/warn/kick");
        }
        const value10 = value3[1].toLowerCase();
        if (!["delete", "warn", "kick"].includes(value10)) {
          return value4.reply("❌ Choose: *delete*, *warn*, or *kick*");
        }
        database.updateGroupSettings(value4.from, {
          antistickerAction: value10,
          antisticker: true
        });
        const value11 = value8;
        return value4.reply("🎭 *Anti Sticker action set to: " + value10 + "*\n" + ("⚡ _" + value8 + "_\n\n") + "_Anti Sticker is now ON._");
      }
      if (value9 === "get") {
        return value4.reply("🎭 *Anti Sticker Config*\n━━━━━━━━━━━━━━━\n\n" + ("📌 Status: *" + value6 + "*\n") + ("⚡ Action: *" + value7 + "* — _" + value8 + "_"));
      }
      return value4.reply("⚠️ Use .antisticker for usage info.");
    } catch (error12) {
      await value4.reply("❌ Error: " + error12.message);
    }
  }
};
