const path = require("path");
const {
  jidDecode
} = require("@whiskeysockets/baileys");
const database = require(require("path").join(global.__CORE__, "database"));
const {
  resolvePhone,
  preloadLidResolution
} = require(path.join(global.__ROOT__, "utils", "jidHelper"));
function normaliseCode(value1) {
  return String(value1).replace(/^\+/, "").trim();
}
function isForeignPhone(value2, value3) {
  return !String(value2).startsWith(value3);
}
async function enrichParticipants(value4, value5, value6) {
  const value7 = (await resolvePhone(value4, value6)) || (value6 || "").split("@")[0].split(":")[0];
  const value8 = await Promise.all(value5.map(async value9 => {
    let value10 = null;
    if (value9.phoneNumber) {
      const value11 = jidDecode(value9.phoneNumber);
      value10 = value11?.user?.split(":")[0] || String(value9.phoneNumber).split("@")[0].split(":")[0];
    }
    if (!value10) {
      value10 = await resolvePhone(value4, value9.id);
    }
    return {
      ...value9,
      phone: value10,
      isUnresolvableLid: !value10
    };
  }));
  return value8.filter(value12 => {
    const value13 = value12.phone || value12.id.split("@")[0].split(":")[0];
    if (value13 === value7) {
      return false;
    }
    if (value12.admin) {
      return false;
    }
    return true;
  });
}
async function getForeignParticipants(value14, value15, value16, value17) {
  const value18 = await enrichParticipants(value14, value15, value17);
  const value19 = value18.filter(value20 => value20.isUnresolvableLid);
  const value21 = value18.filter(value22 => !value22.isUnresolvableLid && isForeignPhone(value22.phone, value16));
  return {
    foreign: value21,
    unresolved: value19
  };
}
module.exports = {
  name: "antiforeign",
  aliases: ["foregn", "foreignprotect", "foreigners"],
  category: "admin",
  description: "Scan/remove members whose number doesn't match the allowed country code",
  usage: ".antiforeign [code] [on|kick|off]",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value23, value24, value25, value26) {
    const {
      from: value27,
      reply: value28
    } = value26;
    const value29 = database.getGroupSettings(value27);
    const value30 = value29.antiforegnCode || "254";
    const value31 = !!value29.antiforeign;
    const value32 = (value25[0] || "").toLowerCase().replace(/^\+/, "");
    const value33 = (value25[1] || "").toLowerCase();
    if (!value32) {
      return this._scan(value23, value27, value30, value28);
    }
    if (value32 === "status") {
      return value28("🌍 *AntiForeign*\n\n" + ("Status: " + (value31 ? "✅ ON  (allowed: *+" + value30 + "*)" : "❌ OFF") + "\n\n") + "*.antiforeign 254 on* — enable auto-kick on join\n*.antiforeign 254 kick* — remove all non-254 now\n*.antiforeign 254* — scan only (no action)\n*.antiforeign off* — disable");
    }
    if (value32 === "off") {
      database.updateGroupSettings(value27, {
        antiforeign: false
      });
      return value28("🌍 *AntiForeign* turned ❌ *OFF*.\nForeign members can now join freely.");
    }
    if (value32 === "kick") {
      if (!value31 || !value29.antiforegnCode) {
        return value28("❌ AntiForeign is not enabled. Enable it first:\n*.antiforeign 254 on*\n\nOr kick directly without enabling:\n*.antiforeign 254 kick*");
      }
      return this._kick(value23, value27, value30, value28);
    }
    const value34 = normaliseCode(value32);
    if (!/^\d+$/.test(value34)) {
      return value28("❌ Invalid country code.\n\nUsage:\n`.antiforeign 254` — scan only\n`.antiforeign 254 on` — enable auto-kick\n`.antiforeign 254 kick` — remove all non-254 now");
    }
    if (value33 === "on") {
      database.updateGroupSettings(value27, {
        antiforeign: true,
        antiforegnCode: value34
      });
      return value28("🌍 *AntiForeign ON* ✅\n\n" + ("Allowed country code: *+" + value34 + "*\n") + ("Members joining without *+" + value34 + "* will be auto-kicked.\n\n") + ("_Run_ *.antiforeign " + value34 + " kick* _to purge existing foreign members._"));
    }
    if (value33 === "kick") {
      return this._kick(value23, value27, value34, value28);
    }
    if (value33 === "off") {
      database.updateGroupSettings(value27, {
        antiforeign: false
      });
      return value28("🌍 *AntiForeign* turned ❌ *OFF*.");
    }
    return this._scan(value23, value27, value34, value28);
  },
  async _scan(value35, value36, value37, value38) {
    try {
      const value39 = await value35.groupMetadata(value36);
      await value38("⏳ Resolving member numbers, this can take a few seconds…");
      await preloadLidResolution(value35, value39.participants || []);
      const {
        foreign: value40,
        unresolved: value41
      } = await getForeignParticipants(value35, value39.participants || [], value37, value35.user?.id);
      const value42 = value41.length ? "\n\n_(" + value41.length + " member(s) couldn't be verified yet — their LID hasn't resolved to a number)_" : "";
      if (!value40.length) {
        return value38("✅ *AntiForeign Scan — +" + value37 + "*\n\nNo foreign members found.\n" + ("All verified non-admin members have *+" + value37 + "* numbers.") + value42);
      }
      const value43 = value40.map((value44, value45) => value45 + 1 + ". +" + value44.phone).join("\n");
      return value38("🌍 *AntiForeign Scan — +" + value37 + "*\n\n" + ("Found *" + value40.length + "* non-+" + value37 + " member(s):\n\n") + (value43 + "\n\n") + ("_Run_ *.antiforeign " + value37 + " kick* _to remove them._") + value42);
    } catch (error46) {
      console.error("[antiforeign scan]", error46.message);
      return value38("❌ Error scanning group: " + error46.message);
    }
  },
  async _kick(value47, value48, value49, value50) {
    try {
      const value51 = await value47.groupMetadata(value48);
      await preloadLidResolution(value47, value51.participants || []);
      const {
        foreign: value52,
        unresolved: value53
      } = await getForeignParticipants(value47, value51.participants || [], value49, value47.user?.id);
      if (!value52.length) {
        return value50("✅ *AntiForeign — +" + value49 + "*\n\nNo foreign members found. Nothing to remove." + (value53.length ? "\n\n_(" + value53.length + " member(s) unverified — skipped)_" : ""));
      }
      await value50("⏳ *AntiForeign* — removing *" + value52.length + "* non-+" + value49 + " member(s)…");
      const value54 = value52.map(value55 => value55.id);
      for (let value56 = 0; value56 < value54.length; value56 += 5) {
        await value47.groupParticipantsUpdate(value48, value54.slice(value56, value56 + 5), "remove");
        if (value56 + 5 < value54.length) {
          await new Promise(value57 => setTimeout(value57, 1500));
        }
      }
      await value47.sendMessage(value48, {
        text: "🌍 *AntiForeign:* Removed *" + value54.length + "* member(s) " + ("whose numbers don't match *+" + value49 + "*.")
      });
    } catch (error58) {
      console.error("[antiforeign kick]", error58.message);
      await value50("❌ Error during removal: " + error58.message);
    }
  },
  async handleGroupJoin(value59, value60, value61) {
    const value62 = database.getGroupSettings(value60);
    if (!value62.antiforeign || !value62.antiforegnCode) {
      return;
    }
    let value63 = await resolvePhone(value59, value61);
    if (!value63) {
      try {
        await value59.presenceSubscribe(value61);
      } catch (error64) {}
      for (let value65 = 0; value65 < 3 && !value63; value65++) {
        await new Promise(value66 => setTimeout(value66, 1000));
        value63 = await resolvePhone(value59, value61);
      }
    }
    if (!value63) {
      return;
    }
    if (isForeignPhone(value63, value62.antiforegnCode)) {
      try {
        await value59.groupParticipantsUpdate(value60, [value61], "remove");
        await value59.sendMessage(value60, {
          text: "🌍 *AntiForeign:* Removed *+" + value63 + "* " + ("— number does not match allowed code *+" + value62.antiforegnCode + "*."),
          mentions: [value61]
        });
      } catch (error67) {
        console.error("[antiforeign join-kick]", error67.message);
      }
    }
  }
};
