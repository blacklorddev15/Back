const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "autosticker",
  aliases: ["autos", "asticker"],
  category: "admin",
  description: "Enable or disable auto-sticker conversion (images/videos automatically become stickers)",
  usage: ".autosticker <on/off>",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: false,
  async execute(value1, value2, value3, value4) {
    try {
      if (!value3[0]) {
        const value5 = database.getGroupSettings(value4.from);
        const value6 = value5.autosticker ? "ON" : "OFF";
        return value4.reply("📌 *AutoSticker Status*\n\n" + ("Status: *" + value6 + "*\n\n") + "When enabled, all images and videos sent in this group will automatically be converted to stickers.\n\nUsage:\n  .autosticker on\n  .autosticker off");
      }
      const value7 = value3[0].toLowerCase();
      if (value7 === "on") {
        if (database.getGroupSettings(value4.from).autosticker) {
          return value4.reply("*AutoSticker is already ON*");
        }
        database.updateGroupSettings(value4.from, {
          autosticker: true
        });
        return value4.reply("✅ *AutoSticker has been turned ON*\n\nAll images and videos will now automatically be converted to stickers!");
      }
      if (value7 === "off") {
        if (!database.getGroupSettings(value4.from).autosticker) {
          return value4.reply("*AutoSticker is already OFF*");
        }
        database.updateGroupSettings(value4.from, {
          autosticker: false
        });
        return value4.reply("❌ *AutoSticker has been turned OFF*");
      }
      return value4.reply("❌ Invalid option!\nUsage: .autosticker <on/off>");
    } catch (error8) {
      console.error("[AutoSticker Command Error]:", error8);
      return value4.reply("❌ Error updating autosticker setting.");
    }
  }
};
