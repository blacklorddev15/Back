const os = require("os");
const fs = require("fs");
const path = require("path");
const {
  jidDecode
} = require("@whiskeysockets/baileys");
const {
  resolvePhone,
  preloadLidResolution
} = require(path.join(global.__ROOT__, "utils", "jidHelper"));
module.exports = {
  name: "vcf",
  aliases: ["vcard", "contacts", "exportcontacts"],
  category: "admin",
  description: "Export all group members as a VCF contacts file",
  usage: ".vcf",
  groupOnly: true,
  adminOnly: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      await value1.sendMessage(value5, {
        react: {
          text: "📇",
          key: value2.key
        }
      });
      const value6 = value4.groupMetadata?.participants || [];
      const value7 = value4.groupMetadata?.subject || "Group";
      await preloadLidResolution(value1, value6);
      const value8 = value1.user?.id || "";
      const value9 = (await resolvePhone(value1, value8)) || value8.split("@")[0].split(":")[0];
      const value10 = [];
      for (const value11 of value6) {
        let value12 = null;
        if (value11.phoneNumber) {
          const value13 = jidDecode(value11.phoneNumber);
          value12 = value13?.user?.split(":")[0] || String(value11.phoneNumber).split("@")[0].split(":")[0];
        }
        if (!value12) {
          value12 = await resolvePhone(value1, value11.id);
        }
        if (!value12 && (value11.id || "").endsWith("@s.whatsapp.net")) {
          value12 = value11.id.replace("@s.whatsapp.net", "").split(":")[0];
        }
        if (!value12) {
          continue;
        }
        const value14 = value12.replace(/\D/g, "");
        if (!/^\d{7,15}$/.test(value14)) {
          continue;
        }
        if (value14 === value9) {
          continue;
        }
        value10.push(value14);
      }
      if (value10.length === 0) {
        return await value1.sendMessage(value5, {
          text: "❌ No valid phone numbers found in this group."
        }, {
          quoted: value2
        });
      }
      let value15 = "";
      value10.forEach((value16, value17) => {
        value15 += "BEGIN:VCARD\n";
        value15 += "VERSION:3.0\n";
        value15 += "FN:" + value7 + " " + (value17 + 1) + "\n";
        value15 += "ORG:" + value7 + ";\n";
        value15 += "TEL;TYPE=CELL,VOICE:+" + value16 + "\n";
        value15 += "END:VCARD\n";
      });
      const value18 = path.join(os.tmpdir(), "june-x-temp");
      if (!fs.existsSync(value18)) {
        fs.mkdirSync(value18, {
          recursive: true
        });
      }
      const value19 = value7.replace(/[^a-zA-Z0-9_\-]/g, "_").slice(0, 40);
      const value20 = path.join(value18, value19 + "_contacts.vcf");
      fs.writeFileSync(value20, value15);
      const value21 = fs.readFileSync(value20);
      await value1.sendMessage(value5, {
        document: value21,
        mimetype: "text/vcard",
        fileName: value19 + "_contacts.vcf",
        caption: "📇 *" + value7 + "* — " + value10.length + " contact(s) exported"
      }, {
        quoted: value2
      });
      fs.unlinkSync(value20);
    } catch (error22) {
      console.error("[vcf]", error22.message);
      await value1.sendMessage(value5, {
        text: "🚫 Error: " + error22.message
      }, {
        quoted: value2
      });
    }
  }
};
