const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antigif",
  aliases: ["nogif", "blockgif"],
  category: "admin",
  description: "Block GIFs in group (delete/warn/kick)",
  usage: ".antigif on | off | action delete|warn|kick",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6
    } = value4;
    const value7 = database.getGroupSettings(value5);
    const value8 = (value3[0] || "").toLowerCase();
    if (!value8) {
      const value9 = value7.antigifAction || "delete";
      return value6("🎞️ *Anti-GIF Settings*\n━━━━━━━━━━━━━━━\n" + ("📌 Status: *" + (value7.antigif ? "✅ ON" : "❌ OFF") + "*\n") + ("⚡ Action: *" + value9 + "*\n\n") + "*Commands:*\n  .antigif on               — enable\n  .antigif off              — disable\n  .antigif action delete    — silently delete GIFs\n  .antigif action warn      — warn; kick at max warnings\n  .antigif action kick      — immediately kick sender\n\n_Admins and bot owner are always exempt._");
    }
    if (value8 === "on") {
      database.updateGroupSettings(value5, {
        antigif: true
      });
      const value10 = value7.antigifAction || "delete";
      return value6("✅ *Anti-GIF* enabled.\nAction: *" + value10 + "*.\n_GIFs sent by non-admins will be " + value10 + "d._");
    }
    if (value8 === "off") {
      database.updateGroupSettings(value5, {
        antigif: false
      });
      return value6("❌ *Anti-GIF* disabled.");
    }
    if (value8 === "action") {
      const value11 = (value3[1] || "").toLowerCase();
      if (!["delete", "warn", "kick"].includes(value11)) {
        return value6("⚠️ Valid actions: delete | warn | kick");
      }
      database.updateGroupSettings(value5, {
        antigifAction: value11
      });
      return value6("✅ Anti-GIF action set to *" + value11 + "*.");
    }
    return value6("⚠️ Unknown option. Use .antigif for help.");
  }
};
