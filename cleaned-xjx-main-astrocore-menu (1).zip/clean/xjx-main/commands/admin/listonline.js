module.exports = {
  name: "listonline",
  aliases: ["listactive", "activeusers", "activemembers"],
  category: "admin",
  description: "Show most active users in the group by message count",
  usage: ".listonline",
  groupOnly: true,
  adminOnly: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      isGroup: value6,
      reply: value7,
      groupName: value8,
      getActiveUsers: value9
    } = value4;
    if (!value6) {
      return value7(global.mess?.notgroup || "❌ This command can only be used in groups.");
    }
    const value10 = value9(value5, 15);
    if (!value10.length) {
      return value7("*📊 No active users found in this group.*\n\nSend some messages first to track activity!");
    }
    let value11 = "📊 *ACTIVE USERS - " + (value8 || "This Group") + "*\n\n";
    value10.forEach((value12, value13) => {
      const value14 = value13 === 0 ? "🥇" : value13 === 1 ? "🥈" : value13 === 2 ? "🥉" : "🔹";
      value11 += value14 + " " + (value13 + 1) + ". @" + value12.jid.split("@")[0] + " - *" + value12.count + " messages*\n";
    });
    value11 += "\n📈 *Total tracked users:* " + value10.length;
    await value1.sendMessage(value2.key.remoteJid, {
      text: value11,
      mentions: value10.map(value15 => value15.jid)
    }, {
      quoted: value2
    });
  }
};
