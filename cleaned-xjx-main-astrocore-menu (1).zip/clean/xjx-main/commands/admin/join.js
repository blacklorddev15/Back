module.exports = {
  name: "join",
  aliases: [],
  category: "admin",
  description: "Make the bot join a group via invite link",
  usage: ".join https://chat.whatsapp.com/XXXXXX",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      if (!value3 || value3.length === 0) {
        return value4.reply("🔗 Please provide a group invite link.\n\nExample: .join https://chat.whatsapp.com/XXXXXX");
      }
      const value5 = value3[0].trim();
      const value6 = value5.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/);
      if (!value6) {
        return value4.reply("❌ Invalid invite link. It should look like:\nhttps://chat.whatsapp.com/XXXXXX");
      }
      const value7 = value6[1];
      await value1.sendMessage(value4.from, {
        react: {
          text: "⏳",
          key: value2.key
        }
      });
      const value8 = await value1.groupAcceptInvite(value7);
      await value1.sendMessage(value4.from, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
      await value4.reply("✅ Successfully joined the group!\n🔗 Group ID: " + value8);
    } catch (error9) {
      console.error("Join command error:", error9);
      await value1.sendMessage(value4.from, {
        react: {
          text: "❌",
          key: value2.key
        }
      }).catch(() => {});
      if (error9.message?.includes("not-authorized") || error9.message?.includes("401")) {
        return value4.reply("❌ This invite link is invalid or has expired.");
      }
      if (error9.message?.includes("406")) {
        return value4.reply("❌ The bot is already a member of this group.");
      }
      await value4.reply("❌ Failed to join the group. The link may be invalid or expired.");
    }
  }
};
