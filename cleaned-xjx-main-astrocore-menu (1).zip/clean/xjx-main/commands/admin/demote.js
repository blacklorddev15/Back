const {
  findParticipant
} = require(require("path").join(global.__CORE__, "utils", "jidHelper"));
module.exports = {
  name: "demote",
  aliases: ["removeadmin"],
  category: "admin",
  description: "Remove admin privileges from member",
  usage: ".demote @user",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      let value5;
      const value6 = value2.message?.extendedTextMessage?.contextInfo;
      const value7 = value6?.mentionedJid || [];
      if (value7 && value7.length > 0) {
        value5 = value7[0];
      } else if (value6?.participant && value6.stanzaId && value6.quotedMessage) {
        value5 = value6.participant;
      } else {
        return value4.reply("❌ Please mention or reply to the user to demote!\n\nExample: .demote @user");
      }
      const value8 = await value1.groupMetadata(value4.from);
      const value9 = findParticipant(value8.participants, value5);
      if (!value9) {
        return value4.reply("❌ User not found in group!");
      }
      if (value9.admin !== "admin" && value9.admin !== "superadmin") {
        return value4.reply("❌ This user is not an admin!");
      }
      await value1.groupParticipantsUpdate(value4.from, [value5], "demote");
      await value1.sendMessage(value4.from, {
        text: "✅ @" + value5.split("@")[0] + " is no longer an admin!",
        mentions: [value5]
      }, {
        quoted: value2
      });
    } catch (error10) {
      await value4.reply("❌ Error: " + error10.message);
    }
  }
};
