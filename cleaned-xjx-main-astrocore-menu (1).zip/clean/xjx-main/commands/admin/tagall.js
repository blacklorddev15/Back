module.exports = {
  name: "tagall",
  aliases: ["mentionall", "everyone"],
  category: "admin",
  description: "Tag all group members",
  usage: ".tagall <message>",
  groupOnly: true,
  adminOnly: false,
  botAdminNeeded: false,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value3.join(" ") || "Everyone!";
      const value6 = value4.groupMetadata.participants.map(value7 => value7.id);
      let value8 = "📢 *GROUP ANNOUNCEMENT*\n\n";
      value8 += value5 + "\n\n";
      value8 += "👥 Tagged Members:\n";
      value6.forEach((value9, value10) => {
        value8 += value10 + 1 + ". @" + value9.split("@")[0] + "\n";
      });
      await value1.sendMessage(value4.from, {
        text: value8,
        mentions: value6
      }, {
        quoted: value2
      });
    } catch (error11) {
      await value4.reply("❌ Error: " + error11.message);
    }
  }
};
