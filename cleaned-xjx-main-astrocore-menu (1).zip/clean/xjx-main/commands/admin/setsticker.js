const database = require(require("path").join(global.__CORE__, "database"));
const VALID_ACTIONS = ["promote", "demote", "kick", "warn", "add", "tagall", "mute"];
const ACTION_DESC = {
  promote: "Promotes the quoted member to admin",
  demote: "Demotes the quoted admin to member",
  kick: "Removes the quoted member from the group",
  warn: "Warns the quoted member (kicks on max warns)",
  add: "Re-adds the quoted member to the group",
  tagall: "Tags all group members",
  mute: "Mutes the quoted member (bot ignores them)"
};
const SKIP_KEYS = ["messageContextInfo", "protocolMessage", "senderKeyDistributionMessage"];
const WRAPPERS = ["ephemeralMessage", "viewOnceMessage", "viewOnceMessageV2", "viewOnceMessageV2Extension", "documentWithCaptionMessage"];
function resolveContent(value1) {
  if (!value1) {
    return null;
  }
  const value2 = Object.keys(value1).filter(value3 => !SKIP_KEYS.includes(value3));
  const value4 = value2[0];
  if (!value4) {
    return null;
  }
  if (WRAPPERS.includes(value4)) {
    return value1[value4]?.message || null;
  }
  return value1;
}
function extractContextInfo(value5) {
  const value6 = resolveContent(value5.message);
  if (!value6) {
    return null;
  }
  const value7 = Object.keys(value6).filter(value8 => !SKIP_KEYS.includes(value8));
  const value9 = value7[0];
  if (!value9) {
    return null;
  }
  return value6[value9]?.contextInfo || null;
}
function toBase64Hash(value10) {
  if (!value10) {
    return null;
  }
  if (Buffer.isBuffer(value10)) {
    return value10.toString("base64");
  }
  if (typeof value10 === "object") {
    return Buffer.from(Object.values(value10)).toString("base64");
  }
  return null;
}
module.exports = {
  name: "setsticker",
  aliases: ["stickeraction", "stickertrigger"],
  category: "admin",
  description: "Set a sticker to trigger a group action on the quoted member when sent",
  usage: ".setsticker <action> — reply to a sticker\n.setsticker list\n.setsticker clear <action>",
  groupOnly: true,
  adminOnly: true,
  async execute(value11, value12, value13, value14) {
    try {
      const value15 = value13[0]?.toLowerCase();
      if (!value15) {
        const value16 = VALID_ACTIONS.map(value17 => "  • *" + value17 + "* — " + ACTION_DESC[value17]).join("\n");
        return value14.reply("🎭 *Set Sticker Trigger*\n━━━━━━━━━━━━━━━\n\nReply to a sticker with:\n*.setsticker <action>*\n\nWhen an admin replies to a member's message with that sticker, the action is applied to the *quoted member*.\n\n" + ("*Actions:*\n" + value16 + "\n\n") + "*Other commands:*\n  .setsticker list\n  .setsticker clear <action>");
      }
      const value18 = database.getGroupSettings(value14.from);
      const value19 = value18.stickerActions || {};
      if (value15 === "list") {
        const value20 = Object.entries(value19);
        if (!value20.length) {
          return value14.reply("📋 No sticker triggers set for this group.");
        }
        const value21 = value20.map(([value22]) => "  • *" + value22 + "* → " + ACTION_DESC[value22] + " ✅").join("\n");
        return value14.reply("📋 *Sticker Triggers*\n━━━━━━━━━━━━━━━\n\n" + value21 + "\n\n_Reply to a member's message with the set sticker to trigger the action._");
      }
      if (value15 === "clear") {
        const value23 = value13[1]?.toLowerCase();
        if (!value23 || !VALID_ACTIONS.includes(value23)) {
          return value14.reply("❌ Specify a valid action to clear:\n" + VALID_ACTIONS.join(", "));
        }
        if (!value19[value23]) {
          return value14.reply("❌ No sticker trigger set for *" + value23 + "*.");
        }
        delete value19[value23];
        database.updateGroupSettings(value14.from, {
          stickerActions: value19
        });
        return value14.reply("✅ Sticker trigger for *" + value23 + "* cleared.");
      }
      if (!VALID_ACTIONS.includes(value15)) {
        return value14.reply("❌ Invalid action. Valid actions:\n" + VALID_ACTIONS.join(", "));
      }
      const value24 = extractContextInfo(value12);
      const value25 = value24?.quotedMessage?.stickerMessage;
      if (!value25) {
        return value14.reply("❌ Please *reply to a sticker* to set it as the trigger!");
      }
      const value26 = toBase64Hash(value25.fileSha256) || toBase64Hash(value25.fileEncSha256);
      if (!value26) {
        return value14.reply("❌ Could not read sticker fingerprint. Try a different sticker.");
      }
      value19[value15] = {
        fileSha256: toBase64Hash(value25.fileSha256) || null,
        fileEncSha256: toBase64Hash(value25.fileEncSha256) || null
      };
      database.updateGroupSettings(value14.from, {
        stickerActions: value19
      });
      return value14.reply("✅ *Sticker trigger set!*\n\n" + ("⚡ Action: *" + value15 + "*\n") + ("📌 " + ACTION_DESC[value15] + "\n\n") + ("_When an admin replies to a member's message with this sticker, *" + value15 + "* will be applied to the quoted member._"));
    } catch (error27) {
      await value14.reply("❌ Error: " + error27.message);
    }
  }
};
