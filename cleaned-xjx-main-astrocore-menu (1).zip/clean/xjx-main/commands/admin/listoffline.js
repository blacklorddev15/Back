module.exports = {
  name: "listoffline",
  aliases: ["listinactive", "inactiveusers", "inactivemembers"],
  category: "admin",
  description: "Show inactive users who have not sent any messages in the group",
  usage: ".listoffline",
  groupOnly: true,
  adminOnly: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      isGroup: value6,
      reply: value7,
      groupName: value8,
      getInactiveUsers: value9
    } = value4;
    if (!value6) {
      return value7(global.mess?.notgroup || "❌ This command can only be used in groups.");
    }
    try {
      const value10 = await value1.groupMetadata(value5);
      const value11 = value10.participants.map(value12 => value12.id);
      const value13 = value9(value5, value11);
      if (!value13.length) {
        return value7("*✅ No inactive users found in this group!*\n\nAll participants have sent messages.");
      }
      let value14 = "⚠️ *INACTIVE USERS - " + (value8 || "This Group") + "*\n\n";
      value14 += "_Users who haven't sent any messages:_\n\n";
      value14 += value13.map((value15, value16) => "🔹 " + (value16 + 1) + ". @" + value15.split("@")[0]).join("\n");
      value14 += "\n\n📊 *Total inactive:* " + value13.length;
      await value1.sendMessage(value2.key.remoteJid, {
        text: value14,
        mentions: value13
      }, {
        quoted: value2
      });
    } catch (error17) {
      console.error("Error in listoffline command:", error17);
      value7("❌ *Error fetching group data!*");
    }
  }
};
