const {
  getActiveUsers
} = require(require("path").join(global.__CORE__, "utils", "groupstats"));
module.exports = {
  name: "kickactive",
  aliases: ["removeactive", "kickchatty", "kickact"],
  category: "admin",
  description: "Remove all active members (who have sent messages) from the group",
  usage: ".kickactive",
  groupOnly: true,
  adminOnly: true,
  ownerOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      await value4.react("⏳");
      const value6 = await value1.groupMetadata(value5);
      const value7 = value6.participants || [];
      const value8 = value1.user?.id || "";
      const value9 = value1.user?.lid || "";
      const value10 = value8.split("@")[0].split(":")[0];
      const value11 = value9.split("@")[0].split(":")[0];
      const value12 = value13 => {
        const value14 = (value13 || "").split("@")[0].split(":")[0];
        return value14 === value10 || value11 && value14 === value11;
      };
      const value15 = new Set(value7.filter(value16 => value16.admin === "admin" || value16.admin === "superadmin").map(value17 => value17.id));
      const value18 = getActiveUsers(value5, 9999);
      const value19 = new Set(value18.map(value20 => value20.jid));
      const value21 = value7.filter(value22 => {
        if (value12(value22.id) || value12(value22.lid)) {
          return false;
        }
        if (value15.has(value22.id)) {
          return false;
        }
        return value19.has(value22.id) || value22.lid && value19.has(value22.lid);
      });
      if (value21.length === 0) {
        await value4.react("✅");
        return value4.reply("✅ No active members to remove. No tracked activity yet.");
      }
      const value23 = value21.map(value24 => value24.id);
      const value25 = value23.map(value26 => "@" + value26.split("@")[0].split(":")[0]).join(" ");
      await value1.sendMessage(value5, {
        text: "🚨 *Removing " + value21.length + " active member(s)*:\n\n" + value25,
        mentions: value23
      });
      await value1.groupParticipantsUpdate(value5, value23, "remove");
      await value4.react("✅");
      await value1.sendMessage(value5, {
        text: "✅ Removed *" + value21.length + "* active member(s) successfully."
      }, {
        quoted: value2
      });
    } catch (error27) {
      console.error("Kickactive command error:", error27);
      try {
        await value4.react("❌");
      } catch (error28) {}
      await value4.reply("❌ Failed to remove active members. Make sure I am admin.");
    }
  }
};
