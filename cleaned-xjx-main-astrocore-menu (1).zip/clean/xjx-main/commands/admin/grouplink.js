module.exports = {
  name: "grouplink",
  aliases: ["link", "gclink"],
  category: "admin",
  description: "Get group invite link",
  usage: ".grouplink",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = await value1.groupInviteCode(value4.from);
      const value6 = "https://chat.whatsapp.com/" + value5;
      let value7 = "🔗 *GROUP INVITE LINK*\n\n";
      value7 += "📱 Group: " + value4.groupMetadata.subject + "\n";
      value7 += "🔗 Link: " + value6 + "\n\n";
      value7 += "⚠️ Don't share this link publicly!";
      await value4.reply(value7);
    } catch (error8) {
      await value4.reply("❌ Error: " + error8.message);
    }
  }
};
