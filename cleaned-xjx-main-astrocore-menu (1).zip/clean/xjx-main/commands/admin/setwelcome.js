const db = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "setwelcome",
  aliases: ["welcometext"],
  category: "admin",
  desc: "Set custom welcome/goodbye message or toggle no-profile-photo mode",
  usage: ".setwelcome <message> | .setwelcome nopp | .setwelcome reset",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  execute: async (value1, value2, value3) => {
    try {
      const value4 = value2.key.remoteJid;
      const value5 = db.getGroupSettings(value4);
      if (!value3.length) {
        const value6 = value5.welcomeNoPP ? "✅ ON (text only)" : "❌ OFF (with profile photo)";
        return await value1.sendMessage(value4, {
          text: "📝 *Welcome Settings*\n\n" + ("*Message:*\n" + value5.welcomeMessage + "\n\n") + ("*No-photo mode (nopp):* " + value6 + "\n\n") + "*Variables you can use:*\n• @user — member's phone number\n• @group — group name\n• groupDesc — group description\n• time — current time\n• #memberCount — member count\n• botName — bot name\n\n*Commands:*\n• .setwelcome <message> — set custom message\n• .setwelcome nopp — toggle no-photo mode\n• .setwelcome reset — restore default message"
        }, {
          quoted: value2
        });
      }
      const value7 = value3.join(" ").trim();
      if (value7.toLowerCase() === "nopp") {
        const value8 = !value5.welcomeNoPP;
        db.updateGroupSettings(value4, {
          welcomeNoPP: value8
        });
        return await value1.sendMessage(value4, {
          text: "🖼️ *No-photo mode* is now *" + (value8 ? "ON" : "OFF") + "*.\n\n" + (value8 ? "Welcome & goodbye messages will be sent as *text only* (no profile photo)." : "Welcome & goodbye messages will include the *member profile photo* (or group photo as fallback).")
        }, {
          quoted: value2
        });
      }
      if (value7.toLowerCase() === "reset") {
        db.updateGroupSettings(value4, {
          welcomeMessage: db.getDefaultGroupSettings().welcomeMessage
        });
        return await value1.sendMessage(value4, {
          text: "✅ Welcome message reset to default."
        }, {
          quoted: value2
        });
      }
      if (value7.length > 500) {
        return await value1.sendMessage(value4, {
          text: "❌ Welcome message is too long! Maximum 500 characters."
        }, {
          quoted: value2
        });
      }
      db.updateGroupSettings(value4, {
        welcomeMessage: value7
      });
      const value9 = value7.replace(/@user/g, "@" + (value2.key.participant || value2.key.remoteJid).split("@")[0]).replace(/@group/g, "This Group").replace(/groupDesc/g, "Group description here").replace(/time/g, new Date().toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
      })).replace(/#memberCount/g, "?").replace(/botName/g, db.getBotSetting("botName"));
      await value1.sendMessage(value4, {
        text: "✅ *Welcome message updated!*\n\n*Preview:*\n" + value9,
        mentions: [value2.key.participant]
      }, {
        quoted: value2
      });
    } catch (error10) {
      console.error("Set Welcome Error:", error10);
      await value1.sendMessage(value2.key.remoteJid, {
        text: "❌ Error: " + error10.message
      }, {
        quoted: value2
      });
    }
  }
};
