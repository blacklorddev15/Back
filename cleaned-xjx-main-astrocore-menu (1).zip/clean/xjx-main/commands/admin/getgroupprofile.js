const axios = require("axios");
module.exports = {
  name: "getgroupprofile",
  aliases: ["ggp", "grouppp", "groupphoto"],
  category: "admin",
  description: "Get the group's profile picture",
  usage: ".getgroupprofile",
  groupOnly: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      const value6 = await value1.profilePictureUrl(value5, "image");
      if (!value6) {
        return value4.reply("❌ This group has no profile picture set.");
      }
      const value7 = await axios.get(value6, {
        responseType: "arraybuffer"
      });
      const value8 = Buffer.from(value7.data);
      await value1.sendMessage(value5, {
        image: value8,
        caption: "🖼️ *Group Profile Picture*\n📋 Group: " + value4.groupMetadata.subject
      }, {
        quoted: value2
      });
    } catch (error9) {
      if (error9.message?.includes("item-not-found") || error9.output?.statusCode === 404) {
        return value4.reply("❌ This group has no profile picture set.");
      }
      console.error("getgroupprofile error:", error9);
      value4.reply("❌ Failed to fetch group profile picture.");
    }
  }
};
