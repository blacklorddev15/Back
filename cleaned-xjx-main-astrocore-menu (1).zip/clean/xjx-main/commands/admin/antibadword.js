const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antibadword",
  aliases: ["abw", "badword"],
  category: "admin",
  description: "Filter bad/offensive words in group with kick, delete, or warn action",
  usage: ".antibadword <on/off/set/list/add/delete>",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const {
        from: value5,
        reply: value6
      } = value4;
      if (!value3[0]) {
        const value7 = database.getGroupSettings(value5);
        const value8 = value7.antibadword ? "ON" : "OFF";
        const value9 = value7.antibadwordAction || "warn";
        const value10 = database.getBadWords(value5);
        return value6("🤬 *AntiBadWord Status*\n\n" + ("Status: *" + value8 + "*\n") + ("Action: *" + value9 + "*\n") + ("Bad Words: *" + value10.length + "* word(s)\n\n") + "*Usage:*\n  .antibadword on\n  .antibadword off\n  .antibadword set <kick|delete|warn>\n  .antibadword add <word>\n  .antibadword delete <word>\n  .antibadword list");
      }
      const value11 = value3[0].toLowerCase();
      if (value11 === "on") {
        if (database.getGroupSettings(value5).antibadword) {
          return value6("*AntiBadWord is already ON*");
        }
        database.updateGroupSettings(value5, {
          antibadword: true
        });
        return value6("✅ *AntiBadWord has been turned ON*");
      }
      if (value11 === "off") {
        database.updateGroupSettings(value5, {
          antibadword: false
        });
        return value6("❌ *AntiBadWord has been turned OFF*");
      }
      if (value11 === "set") {
        if (!value3[1]) {
          return value6("*Please specify an action:*\n.antibadword set kick | delete | warn");
        }
        const value12 = value3[1].toLowerCase();
        if (!["kick", "delete", "warn"].includes(value12)) {
          return value6("*Invalid action.* Choose one of: kick, delete, warn");
        }
        database.updateGroupSettings(value5, {
          antibadwordAction: value12,
          antibadword: true
        });
        return value6("✅ *AntiBadWord action set to* _" + value12 + "_ *(and turned ON)*");
      }
      if (value11 === "add") {
        if (!value3[1]) {
          return value6("*Please specify a word to add.*\nExample: .antibadword add fuck");
        }
        const value13 = value3[1].toLowerCase().trim();
        const value14 = database.addBadWord(value5, value13);
        if (value14) {
          return value6("✅ *\"" + value13 + "\"* has been added to the bad words list.");
        }
        return value6("⚠️ *\"" + value13 + "\"* is already in the bad words list.");
      }
      if (value11 === "delete" || value11 === "remove") {
        if (!value3[1]) {
          return value6("*Please specify a word to remove.*\nExample: .antibadword delete fuck");
        }
        const value15 = value3[1].toLowerCase().trim();
        const value16 = database.removeBadWord(value5, value15);
        if (value16) {
          return value6("✅ *\"" + value15 + "\"* has been removed from the bad words list.");
        }
        return value6("⚠️ *\"" + value15 + "\"* was not found in the bad words list.");
      }
      if (value11 === "list") {
        const value17 = database.getBadWords(value5);
        if (!value17.length) {
          return value6("📋 *Bad Words List is empty.*\nAdd words using: .antibadword add <word>");
        }
        return value6("📋 *Bad Words List (" + value17.length + ")*\n\n" + value17.map((value18, value19) => value19 + 1 + ". " + value18).join("\n") + "\n\nRemove with: .antibadword delete <word>");
      }
      return value6("⚠️ Unknown option. Use *.antibadword* to see usage.");
    } catch (error20) {
      await value4.reply("❌ Error: " + error20.message);
    }
  }
};
