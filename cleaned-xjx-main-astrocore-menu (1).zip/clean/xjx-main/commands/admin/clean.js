module.exports = {
  name: "clean",
  aliases: ["purge", "clear"],
  category: "admin",
  description: "Clean messages (all or from specific user if replied)",
  usage: ".clean <number>",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = parseInt(value3[0]);
      if (!value5 || value5 < 1 || value5 > 100) {
        return value4.reply("❌ Please enter a valid number (1-100).");
      }
      const value6 = value4.from;
      const {
        store: value7
      } = require(require("path").join(global.__ROOT__, "index"));
      const value8 = value2.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const value9 = value2.message?.extendedTextMessage?.contextInfo?.participant;
      const value10 = value7.messages?.get?.(value6);
      if (!value10 || value10.size === 0) {
        return value4.reply("❌ No stored messages found.");
      }
      let value11 = [];
      if (value8 && value9) {
        value11 = [...value10.values()].filter(value12 => {
          const value13 = value12.key.participant || value12.key.remoteJid;
          return value13 === value9;
        }).sort((value14, value15) => (value15.messageTimestamp || 0) - (value14.messageTimestamp || 0)).slice(0, value5);
      } else {
        value11 = [...value10.values()].sort((value16, value17) => (value17.messageTimestamp || 0) - (value16.messageTimestamp || 0)).slice(0, value5);
      }
      let value18 = 0;
      for (const value19 of value11) {
        try {
          await value1.sendMessage(value6, {
            delete: value19.key
          });
          value18++;
          await new Promise(value20 => setTimeout(value20, 300));
        } catch (error21) {
          console.error("[clean] delete error:", error21.message);
        }
      }
    } catch (error22) {
      console.error("[clean cmd] error:", error22);
      value4.reply("❌ Failed to clean messages.");
    }
  }
};
