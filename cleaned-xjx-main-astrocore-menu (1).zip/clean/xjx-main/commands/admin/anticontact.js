const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "anticontact",
  aliases: ["nocontact", "anticard"],
  category: "admin",
  description: "Block contact cards shared in group (delete/warn/kick)",
  usage: ".anticontact on | off | action delete|warn|kick",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6
    } = value4;
    const value7 = database.getGroupSettings(value5);
    const value8 = (value3[0] || "").toLowerCase();
    if (!value8) {
      const value9 = value7.anticontactAction || "delete";
      return value6("📇 *Anti-Contact Settings*\n━━━━━━━━━━━━━━━\n" + ("📌 Status: *" + (value7.anticontact ? "✅ ON" : "❌ OFF") + "*\n") + ("⚡ Action: *" + value9 + "*\n\n") + "*Commands:*\n  .anticontact on               — enable\n  .anticontact off              — disable\n  .anticontact action delete    — silently delete contact cards\n  .anticontact action warn      — warn; kick at max warnings\n  .anticontact action kick      — immediately kick sender\n\n_Admins and bot owner are always exempt._");
    }
    if (value8 === "on") {
      database.updateGroupSettings(value5, {
        anticontact: true
      });
      const value10 = value7.anticontactAction || "delete";
      return value6("✅ *Anti-Contact* enabled.\nAction: *" + value10 + "*.\n_Contact cards sent by non-admins will be " + value10 + "d._");
    }
    if (value8 === "off") {
      database.updateGroupSettings(value5, {
        anticontact: false
      });
      return value6("❌ *Anti-Contact* disabled.");
    }
    if (value8 === "action") {
      const value11 = (value3[1] || "").toLowerCase();
      if (!["delete", "warn", "kick"].includes(value11)) {
        return value6("⚠️ Valid actions: delete | warn | kick");
      }
      database.updateGroupSettings(value5, {
        anticontactAction: value11
      });
      return value6("✅ Anti-Contact action set to *" + value11 + "*.");
    }
    return value6("⚠️ Unknown option. Use .anticontact for help.");
  }
};
