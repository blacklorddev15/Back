const database = require(require("path").join(global.__CORE__, "database"));
function isForwarded(value1) {
  if (!value1.message) {
    return false;
  }
  const value2 = value1.message;
  for (const value3 of Object.keys(value2)) {
    const value4 = value2[value3]?.contextInfo;
    if (!value4) {
      continue;
    }
    if (value4.isForwarded === true) {
      return true;
    }
    if (typeof value4.forwardingScore === "number" && value4.forwardingScore > 0) {
      return true;
    }
  }
  return false;
}
async function handleAntiforward(value5, value6, value7) {
  try {
    if (!value6?.key || !value6.message) {
      return false;
    }
    const value8 = value6.key.remoteJid;
    if (!value8.endsWith("@g.us")) {
      return false;
    }
    const value9 = database.getAntiforwardSettings(value8);
    if (!value9.antiforward) {
      return false;
    }
    if (!isForwarded(value6)) {
      return false;
    }
    const value10 = value6.key.participant || value6.key.remoteJid;
    if (!value10) {
      return false;
    }
    const value11 = value7?.participants || [];
    const value12 = value11.find(value13 => value13.id === value10 || value13.id?.split(":")[0] === value10.split(":")[0]);
    const value14 = !!value12?.admin;
    const value15 = !!value11.find(value16 => (value16.id === value5.user?.id || value16.id?.split(":")[0] === value5.user?.id?.split(":")[0]) && value16.admin);
    const value17 = value10 === value5.user?.id || value10.split(":")[0] === value5.user?.id?.split(":")[0];
    if (value14 || value17) {
      return false;
    }
    if (!value15) {
      return false;
    }
    const value18 = value9.antiforwardAction || "delete";
    const value19 = value9.antiforwardMaxWarnings || 3;
    const value20 = value10.split("@")[0];
    try {
      await value5.sendMessage(value8, {
        delete: value6.key
      });
    } catch (error21) {}
    if (value18 === "warn") {
      const value22 = database.addAntiforwardWarning(value8, value10);
      if (value22 >= value19) {
        try {
          await value5.groupParticipantsUpdate(value8, [value10], "remove");
          await value5.sendMessage(value8, {
            text: "🚫 *AntiForward* — @" + value20 + " was *removed*.\nReached max warnings (" + value19 + "/" + value19 + ") for forwarding messages.",
            mentions: [value10]
          });
          database.clearAllAntiforwardWarnings(value8, value10);
        } catch (error23) {
          console.error("[antiforward]", error23.message);
        }
        return true;
      }
      try {
        await value5.sendMessage(value8, {
          text: "↩️ *AntiForward* ⚠️ Warning to @" + value20 + "\nForwarded message deleted. Warnings: *" + value22 + "/" + value19 + "*",
          mentions: [value10]
        });
      } catch (error24) {
        console.error("[antiforward]", error24.message);
      }
      return true;
    }
    if (value18 === "kick") {
      try {
        await value5.groupParticipantsUpdate(value8, [value10], "remove");
        await value5.sendMessage(value8, {
          text: "🚫 *AntiForward* — @" + value20 + " was *removed* for forwarding messages.",
          mentions: [value10]
        });
      } catch (error25) {
        console.error("[antiforward]", error25.message);
      }
      return true;
    }
    try {
      await value5.sendMessage(value8, {
        text: "↩️ *AntiForward* — @" + value20 + "'s forwarded message was deleted.",
        mentions: [value10]
      });
    } catch (error26) {
      console.error("[antiforward]", error26.message);
    }
    return true;
  } catch (error27) {
    console.error("[antiforward]", error27.message);
    return false;
  }
}
module.exports = {
  name: "antiforward",
  aliases: ["noforward", "antiforw", "forwardprotect"],
  category: "admin",
  description: "Prevent non-admins from forwarding messages in the group",
  usage: ".antiforward on/off/action/warns",
  groupOnly: true,
  adminOnly: true,
  handleAntiforward: handleAntiforward,
  async execute(value28, value29, value30, value31) {
    try {
      const {
        from: value32,
        reply: value33,
        react: value34
      } = value31;
      const value35 = (value30[0] || "").toLowerCase();
      const value36 = database.getAntiforwardSettings(value32);
      if (!value35) {
        return value33("AntiForward: " + (value36.antiforward ? "ON" : "OFF") + " (" + value36.antiforwardAction + ", " + value36.antiforwardMaxWarnings + " warns)\n.antiforward on/off/action <delete|warn|kick>/warns <n>");
      }
      if (value35 === "on") {
        if (value36.antiforward) {
          return value34("❌");
        }
        database.updateAntiforwardSettings(value32, true, "delete", value36.antiforwardMaxWarnings);
        return value34("✅");
      }
      if (value35 === "off") {
        if (!value36.antiforward) {
          return value34("❌");
        }
        database.updateAntiforwardSettings(value32, false, value36.antiforwardAction, value36.antiforwardMaxWarnings);
        return value34("✅");
      }
      if (value35 === "action") {
        const value37 = (value30[1] || "").toLowerCase();
        if (!["delete", "warn", "kick"].includes(value37)) {
          return value34("❌");
        }
        database.updateAntiforwardSettings(value32, value36.antiforward, value37, value36.antiforwardMaxWarnings);
        return value34("✅");
      }
      if (value35 === "warns" || value35 === "warnings") {
        const value38 = parseInt(value30[1], 10);
        if (isNaN(value38) || value38 < 1) {
          return value34("❌");
        }
        database.updateAntiforwardSettings(value32, value36.antiforward, value36.antiforwardAction, value38);
        return value34("✅");
      }
      return value34("❌");
    } catch (error39) {
      console.error("[antiforward]", error39.message);
      return value31.react("❌");
    }
  }
};
