'use strict';

const {
  getOpenRouterApiKey
} = require("../../utils/juneDb/orap.js");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const {
  normalizeMessageContent,
  jidNormalizedUser,
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const database = require("../../database");
const APIs = require("../../utils/api");
const {
  AI_MODELS,
  MODEL_PRIORITY
} = require("../../utils/helpers");
const {
  loadProfile,
  saveProfile,
  learnFromMessage,
  buildProfileContext,
  getPersonalizedGreeting
} = require("../../database");
const getjid = require("../owner/getjid");
const resolveJid = getjid.resolveJid || getjid;
const EMOTE = "🤖";
function defaultBotName() {
  return database.getBotSetting("botName") || "JuneX";
}
function defaultTechName() {
  const value1 = Array.isArray(database.getOwnerNames()) && database.getOwnerNames()[0] || "";
  return value1 || "JUNE X TECH";
}
const DATA_DIR = path.join(process.cwd(), "data", "chatbot");
const CONVERSATIONS_DIR = path.join(DATA_DIR, "conversations");
const _lgCache = new Map();
const _LG_MAX = 200;
async function _extractTargetUsers(value2, value3, value4) {
  const value5 = value3.key.remoteJid;
  const value6 = new Set();
  const value7 = (value3.message?.extendedTextMessage?.contextInfo?.mentionedJid || []).filter(value8 => value8 && !value8.includes("status"));
  if (value7.length > 0) {
    for (const value9 of value7) {
      try {
        const value10 = await resolveJid(value2, value9, value5);
        value6.add(value10);
      } catch {
        value6.add(value9);
      }
    }
  } else {
    for (let value11 = 1; value11 < value4.length; value11++) {
      const value12 = String(value4[value11]).replace(/[^0-9]/g, "");
      if (value12.length >= 7) {
        value6.add(value12 + "@s.whatsapp.net");
      }
    }
  }
  return [...value6];
}
function _checkGroupUserFilter(value13, value14, value15) {
  const value16 = (value13.groupUserFilters || {})[value14];
  if (!value16 || !value16.users || value16.users.length === 0) {
    return true;
  }
  const value17 = value15.split("@")[0].split(":")[0].replace(/\D/g, "");
  const value18 = value16.users.some(value19 => {
    const value20 = value19.split("@")[0].split(":")[0].replace(/\D/g, "");
    return value20 === value17;
  });
  if (value16.mode === "allow") {
    return value18;
  }
  if (value16.mode === "block") {
    return !value18;
  }
  return true;
}
function getBotId() {
  const value21 = (database.getOwners()?.[0] || "").replace(/[^0-9]/g, "");
  if (value21) {
    const value22 = path.join(DATA_DIR, "chatbot_config_" + value21 + ".json");
    if (fs.existsSync(value22)) {
      return value21;
    }
  }
  try {
    const value23 = fs.readdirSync(DATA_DIR).filter(value24 => value24.startsWith("chatbot_config_") && value24.endsWith(".json"));
    if (value23.length > 0) {
      return value23[0].replace("chatbot_config_", "").replace(".json", "");
    }
  } catch {}
  return value21 || "default";
}
function getConfigFile() {
  return path.join(DATA_DIR, "chatbot_config_" + getBotId() + ".json");
}
function getConversationsDir() {
  return path.join(CONVERSATIONS_DIR, getBotId());
}
const pendingActions = new Map();
const PENDING_TIMEOUT = 120000;
function pendingKey(value25, value26) {
  return value25 + "::" + value26;
}
function setPendingAction(value27, value28, value29, value30) {
  pendingActions.set(pendingKey(value27, value28), {
    type: value29,
    command: value30,
    timestamp: Date.now()
  });
}
function getPendingAction(value31, value32) {
  const value33 = pendingKey(value31, value32);
  const value34 = pendingActions.get(value33);
  if (!value34) {
    return null;
  }
  if (Date.now() - value34.timestamp > PENDING_TIMEOUT) {
    pendingActions.delete(value33);
    return null;
  }
  return value34;
}
function clearPendingAction(value35, value36) {
  pendingActions.delete(pendingKey(value35, value36));
}
const CANCEL_WORDS = ["cancel", "nevermind", "never mind", "nvm", "stop", "nah", "no", "forget it", "skip"];
function ensureDataDirs() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, {
      recursive: true
    });
  }
  const value37 = getConversationsDir();
  if (!fs.existsSync(value37)) {
    fs.mkdirSync(value37, {
      recursive: true
    });
  }
}
function loadConfig() {
  ensureDataDirs();
  const value38 = {
    mode: "off",
    preferredModel: "nvidia-chat",
    chatbotName: defaultBotName(),
    techName: defaultTechName(),
    excludedGroups: [],
    allowedDMs: [],
    blockedDMs: [],
    groupUserFilters: {},
    stats: {
      totalQueries: 0,
      modelsUsed: {},
      mediaActions: {}
    }
  };
  const value39 = getConfigFile();
  try {
    if (fs.existsSync(value39)) {
      const value40 = JSON.parse(fs.readFileSync(value39, "utf8"));
      const value41 = {
        ...value38,
        ...value40,
        stats: {
          ...value38.stats,
          ...(value40.stats || {})
        }
      };
      if (value41.preferredModel === "gpt") {
        value41.preferredModel = "nvidia-chat";
      }
      return value41;
    }
  } catch {}
  return value38;
}
function saveConfig(value42) {
  ensureDataDirs();
  fs.writeFileSync(getConfigFile(), JSON.stringify(value42, null, 2));
}
function getConversationFile(value43) {
  return path.join(getConversationsDir(), value43.replace(/[^a-zA-Z0-9]/g, "_") + ".json");
}
function loadConversation(value44) {
  ensureDataDirs();
  const value45 = getConversationFile(value44);
  try {
    if (fs.existsSync(value45)) {
      const value46 = JSON.parse(fs.readFileSync(value45, "utf8"));
      const value47 = 86400000;
      if (Date.now() - (value46.lastActive || 0) > value47) {
        return {
          messages: [],
          lastActive: Date.now(),
          model: null
        };
      }
      return value46;
    }
  } catch {}
  return {
    messages: [],
    lastActive: Date.now(),
    model: null
  };
}
function saveConversation(value48, value49) {
  ensureDataDirs();
  const value50 = getConversationFile(value48);
  value49.lastActive = Date.now();
  if (value49.messages.length > 40) {
    value49.messages = value49.messages.slice(-40);
  }
  fs.writeFileSync(value50, JSON.stringify(value49, null, 2));
}
function clearConversation(value51) {
  const value52 = getConversationFile(value51);
  if (fs.existsSync(value52)) {
    fs.unlinkSync(value52);
  }
}
function buildContextPrompt(value53, value54, value55, value56 = null, value57 = null) {
  const value58 = value55 || defaultBotName();
  const value59 = value57 || defaultTechName();
  const value60 = value56 ? buildProfileContext(value56) : "";
  let value61 = "You are " + value58 + ", an elite AI assistant created by " + value59 + ". Your name is " + value58 + " and you must always identify yourself as " + value58 + " when asked who you are. You are intelligent, witty, warm, and helpful. You have a distinct personality — friendly and sometimes a little humorous without being annoying. You remember conversation context and respond naturally like a real chat partner. Keep responses SHORT and CONCISE — aim for 2-3 sentences maximum unless the question genuinely requires more detail. Occasionally ask a follow-up question to keep the conversation flowing.\n\nCRITICAL IDENTITY RULES:\n- Your name is " + value58 + ". Always refer to yourself as " + value58 + ".\n- You were created by " + value59 + ". Never say you were made by OpenAI, Google, Anthropic, Microsoft, Meta, xAI, or any other company.\n- Never reveal or mention any underlying AI model (GPT, Claude, Copilot, Grok, Bard, Blackbox, Perplexity, LLaMA, Gemini, NVIDIA, etc).\n- If asked what you are, say: \"I'm " + value58 + ", an AI assistant by " + value59 + ".\"\n- Never say \"As an AI language model\" — instead say \"As " + value58 + "\" if needed.\n- You are not ChatGPT, not Claude, not Bard, not Copilot. You are " + value58 + ".\n\n";
  if (value60) {
    value61 += value60 + "\n";
  }
  if (value53.messages.length > 0) {
    value61 += "Previous conversation:\n";
    const value62 = value53.messages.slice(-10);
    for (const value63 of value62) {
      value61 += (value63.role === "user" ? "Human" : value58) + ": " + value63.content + "\n";
    }
    value61 += "\n";
  }
  value61 += "Human: " + value54 + "\n" + value58 + ":";
  return value61;
}
const NVIDIA_CHAT_MODEL = "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning";
async function queryAI(value64, value65, value66 = 35000, value67 = null) {
  if (!AI_MODELS[value64]) {
    return null;
  }
  try {
    const value68 = await APIs.nvidiaChat(value65, {
      model: NVIDIA_CHAT_MODEL,
      maxTokens: 700,
      timeoutMs: 90000
    });
    if (value68 && value68.trim().length >= 3) {
      const value69 = value68.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
      if (value69.length >= 3) {
        return value69;
      }
    }
  } catch (error70) {
    console.error("[Chatbot/NVIDIA/" + value64 + "]", error70.message);
  }
  return null;
}
const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const OPENROUTER_VISION_MODELS = [{
  id: "nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free",
  key: "nemotron-omni"
}, {
  id: "nvidia/nemotron-nano-12b-v2-vl:free",
  key: "nemotron-vl"
}];
async function askOpenRouterVision(value71, value72) {
  const value73 = getOpenRouterApiKey();
  if (!value73) {
    throw new Error("OPENROUTER_API_KEY is not set");
  }
  const value74 = "data:image/jpeg;base64," + Buffer.from(value72).toString("base64");
  let value75;
  for (const value76 of OPENROUTER_VISION_MODELS) {
    try {
      const value77 = await axios.post(OPENROUTER_URL, {
        model: value76.id,
        messages: [{
          role: "user",
          content: [{
            type: "text",
            text: value71
          }, {
            type: "image_url",
            image_url: {
              url: value74
            }
          }]
        }]
      }, {
        headers: {
          Authorization: "Bearer " + value73,
          "Content-Type": "application/json",
          "HTTP-Referer": process.env.OPENROUTER_SITE_URL || "https://replit.com",
          "X-Title": process.env.OPENROUTER_APP_NAME || "June_Ultra"
        },
        timeout: 90000
      });
      const value78 = value77.data?.choices?.[0]?.message?.content;
      if (value78) {
        const value79 = typeof value78 === "string" ? value78 : JSON.stringify(value78);
        if (value79 && value79.trim().length >= 3) {
          return {
            answer: value79.trim(),
            model: value76.key
          };
        }
      }
      value75 = new Error("Empty response from " + value76.id);
    } catch (error80) {
      value75 = error80;
      console.error("[Chatbot/Vision] OpenRouter " + value76.id + ":", error80.message);
    }
  }
  throw value75 || new Error("OpenRouter vision failed");
}
const VISION_PROMPT = "Analyze this image. FIRST, transcribe all visible text exactly as written. THEN briefly describe the visual content (colors, layout, subjects). If you are not sure about something, say so explicitly. Do NOT invent objects, people, animals, or scenes that are not actually in the image. If the image is mostly text on a plain background, just transcribe it and note that.";
async function queryVision(value81, value82) {
  const value83 = value81 && value81.trim() && value81.length > 3 ? value81.trim() : VISION_PROMPT;
  if (process.env.OPENROUTER_API_KEY) {
    try {
      const value84 = await askOpenRouterVision(value83, value82);
      if (value84?.answer) {
        return value84.answer.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
      }
    } catch (error85) {
      console.error("[Chatbot/Vision] OpenRouter failed, falling back to NVIDIA:", error85.message);
    }
  }
  try {
    const value86 = await APIs.nvidiaVision(value83, value82, {
      model: NVIDIA_CHAT_MODEL,
      maxTokens: 1024,
      timeoutMs: 90000
    });
    if (value86) {
      return value86.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
    } else {
      return null;
    }
  } catch (error87) {
    console.error("[Chatbot/Vision]", error87.message);
    return null;
  }
}
async function generateImage(value88) {
  let value89 = await APIs.nvidiaImage(value88, {
    width: 1024,
    height: 1024,
    timeoutMs: 120000
  });
  if (value89 && value89.length > 0) {
    return value89;
  }
  value89 = await APIs.pollinationsImage(value88, {
    width: 1024,
    height: 1024,
    timeoutMs: 60000
  });
  if (value89 && value89.length > 0) {
    return value89;
  }
  return null;
}
async function getAIResponse(value90, value91, value92 = "nvidia-chat", value93 = null, value94 = null, value95 = null) {
  const value96 = buildContextPrompt(value91, value90, value93, value94, value95);
  let value97 = await queryAI(value92, value96, 35000, value90);
  if (value97) {
    return {
      response: value97,
      model: value92
    };
  }
  for (const value98 of MODEL_PRIORITY) {
    if (value98 === value92) {
      continue;
    }
    value97 = await queryAI(value98, value96, 35000, value90);
    if (value97) {
      return {
        response: value97,
        model: value98
      };
    }
  }
  value97 = await queryAI("nvidia-chat", value90);
  if (value97) {
    return {
      response: value97,
      model: "nvidia-chat"
    };
  }
  return null;
}
function cleanAIResponse(value99, value100, value101) {
  if (!value99) {
    return "";
  }
  const value102 = value100 || defaultBotName();
  const value103 = value102.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  value99 = value99.replace(/\[\d+\]/g, "");
  value99 = value99.replace(/Human:.*$/gm, "");
  value99 = value99.replace(new RegExp("^" + value103 + ":\\s*", "gim"), "");
  value99 = value99.replace(/^(Assistant|AI|Bot|Claude|GPT|Grok|Copilot|Bard):\s*/gim, "");
  value99 = value99.replace(/\b(ChatGPT|GPT-?[34o5]?|GPT|OpenAI)\b/gi, value102);
  value99 = value99.replace(/\b(Claude|Anthropic)\b/gi, value102);
  value99 = value99.replace(/\b(Copilot|Microsoft Copilot)\b/gi, value102);
  value99 = value99.replace(/\b(Google Bard|Bard|Gemini)\b/gi, value102);
  value99 = value99.replace(/\b(Grok|xAI)\b/gi, value102);
  value99 = value99.replace(/\b(Blackbox|Blackbox AI)\b/gi, value102);
  value99 = value99.replace(/\b(Perplexity|Perplexity AI)\b/gi, value102);
  value99 = value99.replace(/\b(LLaMA|Meta AI|Mistral)\b/gi, value102);
  value99 = value99.replace(/\bI'?m an? (?:large )?AI? ?(?:language )?model\b/gi, "I'm " + value102);
  value99 = value99.replace(/\bAs an? (?:large )?AI ?(?:language )?model\b/gi, "As " + value102);
  value99 = value99.replace(/\ba (?:large )?language model\b/gi, "" + value102);
  value99 = value99.replace(/\bI'?m a (?:large )?language model\b/gi, "I'm " + value102);
  const value104 = value101 || defaultTechName();
  value99 = value99.replace(/\bmade by (OpenAI|Google|Anthropic|Microsoft|Meta|xAI)\b/gi, "made by " + value104);
  value99 = value99.replace(/\bcreated by (OpenAI|Google|Anthropic|Microsoft|Meta|xAI)\b/gi, "created by " + value104);
  value99 = value99.replace(/\bdeveloped by (OpenAI|Google|Anthropic|Microsoft|Meta|xAI)\b/gi, "developed by " + value104);
  value99 = value99.replace(/\bbuilt by (OpenAI|Google|Anthropic|Microsoft|Meta|xAI)\b/gi, "built by " + value104);
  value99 = value99.replace(/\btrained by (OpenAI|Google|Anthropic|Microsoft|Meta|xAI)\b/gi, "trained by " + value104);
  value99 = value99.replace(new RegExp("(" + value103 + "[\\s,]*){2,}", "g"), value102 + " ");
  value99 = value99.replace(/\n\s*\n\s*\n/g, "\n\n");
  return value99.trim();
}
function trimResponse(value105, value106 = 700) {
  if (!value105 || value105.length <= value106) {
    return value105;
  }
  const value107 = value105.slice(0, value106 + 100);
  const value108 = /[.!?](?:\s|$)/g;
  let value109 = -1;
  let value110;
  while ((value110 = value108.exec(value107)) !== null) {
    if (value110.index + 1 <= value106) {
      value109 = value110.index + 1;
    }
  }
  if (value109 > 50) {
    return value105.slice(0, value109).trim() + " _..._";
  }
  const value111 = value105.slice(0, value106);
  const value112 = value111.lastIndexOf(" ");
  return (value112 > 50 ? value111.slice(0, value112) : value111).trim() + " _..._";
}
function getChatbotConfig() {
  return loadConfig();
}
function isChatbotActiveForChat(value113) {
  const value114 = loadConfig();
  if (value114.mode === "off") {
    return false;
  }
  const value115 = value113.endsWith("@g.us");
  const value116 = value113.endsWith("@s.whatsapp.net") || value113.endsWith("@lid");
  const value117 = value114.excludedGroups || [];
  const value118 = value114.allowedDMs || [];
  if (value115) {
    if (value114.mode === "groups" || value114.mode === "on" || value114.mode === "both") {
      return !value117.includes(value113);
    }
    return false;
  }
  if (value116 && value118.length > 0) {
    const value119 = value113.split("@")[0].split(":")[0];
    let value120 = null;
    if (value113.endsWith("@lid")) {
      const value121 = global.lidPhoneCache?.get(value119) || global.lidPhoneCache?.get(value113);
      const value122 = global.resolvePhoneFromLid?.(value113);
      const value123 = value122 || value121;
      if (value123) {
        value120 = String(value123).replace(/[^0-9]/g, "");
      }
    }
    if (value120 || !value113.endsWith("@lid")) {
      return value118.some(value124 => {
        const value125 = value124.split("@")[0].split(":")[0];
        if (value125 === value119) {
          return true;
        }
        if (value120 && value125 === value120) {
          return true;
        }
        return false;
      });
    }
  }
  if (value114.mode === "on" || value114.mode === "both") {
    return true;
  }
  if (value114.mode === "groups" && value115) {
    return true;
  }
  if (value114.mode === "dms" && value116) {
    return true;
  }
  return false;
}
function createSilentSock(value126, value127, value128) {
  const value129 = {
    get(value130, value131) {
      if (value131 === "sendMessage") {
        return async (value132, value133, value134 = {}) => {
          if (value133.react) {
            return value130.sendMessage(value132, value133, value134);
          }
          if (value133.image || value133.video || value133.audio || value133.document || value133.sticker) {
            if (value133.caption) {
              value133.caption = EMOTE + " Here is your result!\n\n" + value133.caption;
            }
            return value130.sendMessage(value132, value133, value134);
          }
          if (value133.edit) {
            return {
              key: {
                id: "suppressed"
              }
            };
          }
          if (value133.text && !value133.image && !value133.video && !value133.audio) {
            return {
              key: {
                id: "suppressed"
              }
            };
          }
          return value130.sendMessage(value132, value133, value134);
        };
      }
      const value135 = value130[value131];
      if (typeof value135 === "function") {
        return value135.bind(value130);
      }
      return value135;
    }
  };
  return new Proxy(value126, value129);
}
async function executeMediaCommand(value136, value137, value138, value139, value140) {
  if (!value140 || !value140.has(value138)) {
    return false;
  }
  const value141 = value140.get(value138);
  if (!value141 || !value141.execute) {
    return false;
  }
  try {
    const value142 = value137.key.remoteJid;
    const value143 = MEDIA_REACTIONS[value138] || "⚡";
    await value136.sendMessage(value142, {
      react: {
        text: value143,
        key: value137.key
      }
    });
    const value144 = ".";
    const value145 = value139.split(/\s+/).filter(Boolean);
    const value146 = {
      ...value137,
      message: {
        conversation: "" + value144 + value138 + " " + value139,
        extendedTextMessage: {
          text: "" + value144 + value138 + " " + value139
        }
      }
    };
    const value147 = createSilentSock(value136, value142, value137);
    await value141.execute(value147, value146, value145, {
      from: value142,
      sender: value137.key.participant || value142,
      isGroup: value142.endsWith("@g.us"),
      prefix: value144,
      command: value138,
      reply: value148 => value147.sendMessage(value142, {
        text: value148
      }, {
        quoted: value137
      }),
      react: value149 => value147.sendMessage(value142, {
        react: {
          text: value149,
          key: value137.key
        }
      })
    });
    await value136.sendMessage(value142, {
      react: {
        text: "✅",
        key: value137.key
      }
    });
    return true;
  } catch (error150) {
    console.error("[Chatbot] Media command error (" + value138 + "):", error150.message);
    await value136.sendMessage(value137.key.remoteJid, {
      react: {
        text: "❌",
        key: value137.key
      }
    });
    return false;
  }
}
function trackMediaAction(value151, value152) {
  value152.stats.totalQueries = (value152.stats.totalQueries || 0) + 1;
  value152.stats.mediaActions = value152.stats.mediaActions || {};
  value152.stats.mediaActions[value151] = (value152.stats.mediaActions[value151] || 0) + 1;
  saveConfig(value152);
}
const MEDIA_REACTIONS = {
  imagine: "🎨",
  play: "🎵",
  video: "🎬",
  song: "🎶"
};
const MEDIA_PROMPTS = {
  image: {
    ask: "Sure! Describe the image you'd like me to generate 🎨",
    confirm: "Got it! Let me create that for you... 🎨"
  },
  playAudio: {
    ask: "Of course! What song or music would you like me to play? 🎵",
    confirm: "Great choice! Let me find that for you... 🎵"
  },
  playVideo: {
    ask: "Sure thing! What video would you like me to find? 🎬",
    confirm: "On it! Finding that video for you... 🎬"
  },
  song: {
    ask: "Sure! Which song would you like me to download? 🎶",
    confirm: "Alright! Downloading that for you... 🎶"
  }
};
const INTENT_PATTERNS = {
  image: {
    vaguePatterns: [/^(?:can you |could you |bot,?\s+)?(?:generate|create|make|draw|design|paint|sketch)\s+(?:an?\s+)?(?:image|picture|photo|art|artwork|illustration|pic|img|drawing|painting)\s*\??$/i, /^(?:can you |could you |bot,?\s+)?(?:generate|create|make|draw|design)\s+(?:for me|something|an image|a picture)\s*\??$/i, /^(?:i want|i need|i'd like)\s+(?:an?\s+)?(?:image|picture|photo|art|drawing)\s*\.?$/i, /^(?:generate|create|make|draw)\s+(?:an?\s+)?(?:image|picture|photo)\s*\??$/i],
    specificPatterns: [/^(?:generate|create|make|draw|design|paint|sketch)\s+(?:an?\s+)?(?:image|picture|photo|art|artwork|illustration|pic|img|drawing|painting)\s+(?:of|about|for|with|showing)\s+.{3,}/i, /^(?:generate|create|make|draw|design|paint|sketch)\s+(?:me\s+)?(?:an?\s+)?.{5,}/i, /(?:image|picture|photo|art|drawing|painting)\s+(?:of|about|for|with)\s+.{3,}/i, /^imagine\s+.{3,}/i, /^(?:can you |please |bot,?\s+)?(?:generate|create|make|draw|design)\s+(?:an?\s+)?(?:image|picture|photo)\s+(?:of|about|for|with|showing)\s+.{3,}/i],
    extractQuery: value153 => {
      let value154 = value153;
      value154 = value154.replace(/^(?:can you |could you |please |bot,?\s+)?(?:generate|create|make|draw|design|paint|sketch)\s+(?:me\s+)?(?:an?\s+)?(?:image|picture|photo|art|artwork|illustration|pic|img|drawing|painting)\s*(?:of|about|for|with|showing)?\s*/i, "");
      value154 = value154.replace(/^imagine\s+/i, "");
      value154 = value154.replace(/^(?:can you |could you |please |bot,?\s+)?(?:generate|create|make|draw|design|paint|sketch)\s+(?:me\s+)?(?:an?\s+)?/i, "");
      return value154.trim();
    },
    command: "imagine"
  },
  playAudio: {
    vaguePatterns: [/^(?:can you |could you |bot,?\s+)?(?:play|sing|find)\s+(?:a\s+)?(?:song|music|something|audio)\s*\??$/i, /^(?:play|sing)\s+(?:me\s+)?(?:something|a song|music)\s*\??$/i, /^(?:i want to (?:hear|listen to)|let me hear)\s+(?:a\s+)?(?:song|music|something)\s*\??$/i],
    specificPatterns: [/^(?:play|sing|find me|put on|listen to)\s+(?:the\s+)?(?:song\s+)?(?!(?:a\s+)?(?:song|music|something|audio)\s*\??$).{3,}/i, /^(?:can you |please |bot,?\s+)?(?:play|sing|find me|put on)\s+(?!(?:a\s+)?(?:song|music|something)\s*\??$).{3,}/i, /^(?:play|download)\s+(?:me\s+)?(?:the\s+)?(?:song|music|audio|mp3)\s+.{3,}/i, /^(?:i want to (?:hear|listen)|let me hear|play me)\s+.{3,}/i],
    extractQuery: value155 => {
      let value156 = value155;
      value156 = value156.replace(/^(?:can you |could you |please |bot,?\s+)?(?:play|sing|find me|put on|listen to|download)\s+(?:me\s+)?(?:the\s+)?(?:song|music|track|audio|mp3)?\s*/i, "");
      value156 = value156.replace(/^(?:i want to (?:hear|listen)|let me hear|play me)\s+/i, "");
      value156 = value156.replace(/\s+(?:on youtube|from youtube|for me|please)$/i, "");
      return value156.trim();
    },
    command: "play"
  },
  playVideo: {
    vaguePatterns: [/^(?:can you |could you |bot,?\s+)?(?:play|download|get|find|show)\s+(?:a\s+)?(?:video|vid|clip)\s*\??$/i, /^(?:i want to (?:watch|see)|let me (?:watch|see)|show me)\s+(?:a\s+)?(?:video|something)\s*\??$/i],
    specificPatterns: [/^(?:play|download|get|find|show)\s+(?:the\s+)?(?:video|vid|clip|movie)\s+(?:of|about|for)?\s*.{3,}/i, /^(?:play|download|get|find|show)\s+(?:me\s+)?(?:the\s+)?video\s+.{3,}/i, /^(?:can you |please |bot,?\s+)?(?:play|download|get|show)\s+(?:the\s+)?(?:video|vid)\s+.{3,}/i, /^(?:i want to (?:watch|see)|let me (?:watch|see)|show me)\s+.{3,}/i, /^(?:play|download)\s+.{3,}\s+video$/i],
    extractQuery: value157 => {
      let value158 = value157;
      value158 = value158.replace(/^(?:can you |could you |please |bot,?\s+)?(?:play|download|get|find|show)\s+(?:me\s+)?(?:the\s+)?(?:video|vid|clip|movie)\s*(?:of|about|for)?\s*/i, "");
      value158 = value158.replace(/^(?:i want to (?:watch|see)|let me (?:watch|see)|show me)\s+/i, "");
      value158 = value158.replace(/\s+(?:video|vid|clip)$/i, "");
      value158 = value158.replace(/\s+(?:on youtube|from youtube|for me|please)$/i, "");
      return value158.trim();
    },
    command: "video"
  },
  song: {
    vaguePatterns: [/^(?:can you |could you |bot,?\s+)?(?:download|get|send|give)\s+(?:me\s+)?(?:a\s+)?(?:song|music|audio)\s*\??$/i],
    specificPatterns: [/^(?:download|get)\s+(?:the\s+)?(?:song|music|audio|mp3)\s+.{3,}/i, /^(?:send|give)\s+(?:me\s+)?(?:the\s+)?(?:song|music|audio)\s+.{3,}/i],
    extractQuery: value159 => {
      let value160 = value159;
      value160 = value160.replace(/^(?:download|get|send|give)\s+(?:me\s+)?(?:the\s+)?(?:song|music|audio|mp3)\s*/i, "");
      value160 = value160.replace(/\s+(?:for me|please)$/i, "");
      return value160.trim();
    },
    command: "song"
  }
};
function detectIntent(value161) {
  const value162 = value161.trim();
  if (value162.length < 4) {
    return null;
  }
  for (const [value163, value164] of Object.entries(INTENT_PATTERNS)) {
    if (value163 === "playAudio") {
      const value165 = INTENT_PATTERNS.playVideo.vaguePatterns.some(value166 => value166.test(value162)) || INTENT_PATTERNS.playVideo.specificPatterns.some(value167 => value167.test(value162));
      if (value165) {
        continue;
      }
    }
    for (const value168 of value164.vaguePatterns) {
      if (value168.test(value162)) {
        return {
          type: value163,
          command: value164.command,
          query: "",
          vague: true
        };
      }
    }
    for (const value169 of value164.specificPatterns) {
      if (value169.test(value162)) {
        const value170 = value164.extractQuery(value162);
        if (value170 && value170.length >= 2) {
          return {
            type: value163,
            command: value164.command,
            query: value170,
            vague: false
          };
        }
      }
    }
  }
  return null;
}
const CAPABILITY_PHRASES = ["what can you do", "what tools do you have", "what tools can you use", "what are your tools", "what are your capabilities", "what features do you have", "list your tools", "show your tools", "show me what you can do", "what do you support", "do you have tools", "can you generate images", "can you play music", "can you play songs", "can you download music", "can you find videos", "can you describe images", "help me list your features", "what are you capable of", "your capabilities"];
function isCapabilityQuestion(value171) {
  const value172 = String(value171 || "").trim().toLowerCase();
  if (!value172) {
    return false;
  }
  if (/\b(?:can'?t|cannot|couldn'?t|didn'?t|doesn'?t|don'?t|not able)\b/.test(value172)) {
    return false;
  }
  return CAPABILITY_PHRASES.some(value173 => value172.includes(value173));
}
function chatbotCapabilities(value174) {
  const value175 = value176 => !!value174 && !!value174.get(value176)?.execute;
  const value177 = [];
  const value178 = (value179, value180) => "• " + value179 + " — `" + value180 + "`";
  if (value175("imagine") || value175("generate")) {
    value177.push({
      label: "Image generation",
      cmd: "generate",
      example: "generate an image of a sunset over Lagos"
    });
  }
  if (value175("play")) {
    value177.push({
      label: "Music (find + send audio)",
      cmd: "play",
      example: "play Faded by Alan Walker"
    });
  }
  if (value175("video")) {
    value177.push({
      label: "Videos (YouTube search)",
      cmd: "video",
      example: "find a video about Linux"
    });
  }
  if (value175("song")) {
    value177.push({
      label: "Song downloads",
      cmd: "song",
      example: "download the song Believer"
    });
  }
  const value181 = [EMOTE + " *Here is what I can do*", "", "🧰 *Chat* — Chat naturally, remember recent conversations, and learn your preferences.", "👁️ *Vision* — Analyze images and answer questions about them."];
  if (value177.length) {
    value181.push("", "*Command actions I can run for you:*");
    for (const value182 of value177) {
      value181.push(value178(value182.label, value182.example));
    }
  }
  value181.push("", "_Just say it naturally — e.g. \"play Faded\" or \"generate an image of a wolf\"._");
  return value181.join("\n");
}
async function handleChatbotMessage(value183, value184, value185) {
  const value186 = value184.key.remoteJid;
  const value187 = value184.key.participant || value186;
  const value188 = jidNormalizedUser(value187);
  const value189 = loadConfig().chatbotName || defaultBotName();
  if (value186.endsWith("@g.us")) {
    const value190 = loadConfig();
    let value191 = value188;
    if (value188.endsWith("@lid")) {
      try {
        value191 = await resolveJid(value183, value188, value186);
      } catch {}
    }
    if (!_checkGroupUserFilter(value190, value186, value191)) {
      return false;
    }
  }
  const value192 = normalizeMessageContent(value184.message);
  const value193 = value192?.conversation || value192?.extendedTextMessage?.text || value192?.imageMessage?.caption || value192?.videoMessage?.caption || "";
  const value194 = !!value184.message?.imageMessage || !!value184.message?.viewOnceMessageV2?.message?.imageMessage;
  if (value194) {
    const value195 = loadConfig();
    const value196 = value195.techName || defaultTechName();
    const value197 = value193.trim() || VISION_PROMPT;
    const value198 = getBotId();
    let value199 = loadProfile(value198, value188);
    try {
      await value183.sendPresenceUpdate("composing", value186);
      await value183.sendMessage(value186, {
        react: {
          text: "👀",
          key: value184.key
        }
      });
      const value200 = await downloadMediaMessage(value184, "buffer", {});
      let value201 = null;
      if (value200 && value200.length > 0) {
        value201 = await queryVision(value197, value200);
      }
      if (value201) {
        const value202 = cleanAIResponse(value201, value189, value196);
        const value203 = trimResponse(value202, 1000);
        const value204 = getPersonalizedGreeting(value199);
        const value205 = value204 ? value204 + " " : EMOTE + " ";
        const value206 = loadConversation(value188);
        value206.messages.push({
          role: "user",
          content: "[Image sent] " + value197
        });
        value206.messages.push({
          role: "assistant",
          content: value202
        });
        saveConversation(value188, value206);
        value199 = learnFromMessage(value197, value199);
        saveProfile(value198, value188, value199);
        value195.stats.totalQueries = (value195.stats.totalQueries || 0) + 1;
        saveConfig(value195);
        await value183.sendMessage(value186, {
          react: {
            text: "✅",
            key: value184.key
          }
        });
        await value183.sendMessage(value186, {
          text: "" + value205 + value203
        }, {
          quoted: value184
        });
      } else {
        await value183.sendMessage(value186, {
          text: EMOTE + " _I received your image but couldn't analyse it right now. Try again or add a caption describing what you'd like to know!_"
        }, {
          quoted: value184
        });
      }
    } catch (error207) {
      console.error("[" + value189 + "] Vision error:", error207.message);
      await value183.sendMessage(value186, {
        text: EMOTE + " _Image analysis failed. Please try again._"
      }, {
        quoted: value184
      });
    }
    return true;
  }
  if (!value193 || value193.trim().length < 2) {
    return false;
  }
  const value208 = value193.trim();
  if (value208.startsWith(".") || value208.startsWith("/") || value208.startsWith("!")) {
    clearPendingAction(value188, value186);
    return false;
  }
  if (isCapabilityQuestion(value208)) {
    const value209 = chatbotCapabilities(value185);
    await value183.sendMessage(value186, {
      text: value209
    }, {
      quoted: value184
    });
    return true;
  }
  const value210 = getPendingAction(value188, value186);
  if (value210 && value185) {
    clearPendingAction(value188, value186);
    if (CANCEL_WORDS.includes(value208.toLowerCase()) || value208.length < 3) {
      await value183.sendMessage(value186, {
        text: EMOTE + " Alright, cancelled!"
      }, {
        quoted: value184
      });
      return true;
    }
    const value211 = await executeMediaCommand(value183, value184, value210.command, value208, value185);
    if (value211) {
      const value212 = loadConfig();
      trackMediaAction(value210.type, value212);
      const value213 = loadConversation(value188);
      value213.messages.push({
        role: "user",
        content: value208
      });
      value213.messages.push({
        role: "assistant",
        content: "[Executed " + value210.command + ": " + value208 + "]"
      });
      saveConversation(value188, value213);
      return true;
    }
  }
  const value214 = loadConfig();
  const value215 = value214.techName || defaultTechName();
  const value216 = loadConversation(value188);
  const value217 = getBotId();
  let value218 = loadProfile(value217, value188);
  const value219 = [/^(?:generate|create|make|draw|paint|design|render)\s+(?:me\s+)?(?:an?\s+)?(?:ai\s+)?(?:image|picture|photo|art|artwork|illustration|painting|wallpaper)\s+(?:of|showing|with|about)\s+(.+)/i, /^(?:generate|create|make|draw|paint)\s+(?:me\s+)?(?:an?\s+)?(?:image|picture|photo|art|painting)\s+(.+)/i, /^imagine\s+(.+)/i, /^flux\s+(.+)/i, /^(?:nvidia\s+)?(?:flux|image)\s+(.+)/i, /^(?:generate|create)\s+(?:ai\s+)?(?:image|art)\s+(.+)/i];
  let value220 = null;
  for (const value221 of value219) {
    const value222 = value208.match(value221);
    if (value222?.[1]?.trim().length > 3) {
      value220 = value222[1].trim();
      break;
    }
  }
  if (value220) {
    try {
      await value183.sendPresenceUpdate("composing", value186);
      await value183.sendMessage(value186, {
        react: {
          text: "🎨",
          key: value184.key
        }
      });
      const value223 = await generateImage(value220);
      if (value223) {
        await value183.sendMessage(value186, {
          image: value223,
          caption: "🎨 *" + value220 + "*\n_Generated with NVIDIA FLUX Dev_"
        }, {
          quoted: value184
        });
        value216.messages.push({
          role: "user",
          content: value208
        });
        value216.messages.push({
          role: "assistant",
          content: "[Generated image: " + value220 + "]"
        });
        saveConversation(value188, value216);
        value218 = learnFromMessage(value208, value218);
        saveProfile(value217, value188, value218);
        value214.stats.totalQueries = (value214.stats.totalQueries || 0) + 1;
        value214.stats.imagesCreated = (value214.stats.imagesCreated || 0) + 1;
        saveConfig(value214);
        await value183.sendMessage(value186, {
          react: {
            text: "✅",
            key: value184.key
          }
        });
        return true;
      }
      await value183.sendMessage(value186, {
        react: {
          text: "❌",
          key: value184.key
        }
      });
      await value183.sendMessage(value186, {
        text: EMOTE + " _Image generation failed. Try again in a moment._"
      }, {
        quoted: value184
      });
      return true;
    } catch (error224) {
      console.error("[" + value189 + "] Image gen error:", error224.message);
      await value183.sendMessage(value186, {
        text: EMOTE + " _Image generation error: " + error224.message + "_"
      }, {
        quoted: value184
      });
      return true;
    }
  }
  const value225 = detectIntent(value208);
  if (value225 && value225.type !== "image" && value185) {
    if (value225.vague) {
      setPendingAction(value188, value186, value225.type, value225.command);
      const value226 = MEDIA_PROMPTS[value225.type];
      await value183.sendMessage(value186, {
        text: EMOTE + " " + (value226?.ask || "Sure! What would you like?")
      }, {
        quoted: value184
      });
      value216.messages.push({
        role: "user",
        content: value208
      });
      value216.messages.push({
        role: "assistant",
        content: value226?.ask || "Sure! What would you like?"
      });
      saveConversation(value188, value216);
      return true;
    }
    const value227 = await executeMediaCommand(value183, value184, value225.command, value225.query, value185);
    if (value227) {
      const value228 = loadConfig();
      trackMediaAction(value225.type, value228);
      const value229 = loadConversation(value188);
      value229.messages.push({
        role: "user",
        content: value208
      });
      value229.messages.push({
        role: "assistant",
        content: "[Executed " + value225.command + ": " + value225.query + "]"
      });
      saveConversation(value188, value229);
      return true;
    }
  }
  try {
    await value183.sendPresenceUpdate("composing", value186);
    const value230 = await getAIResponse(value208, value216, value214.preferredModel || "nvidia-chat", value189, value218, value215);
    if (!value230) {
      await value183.sendMessage(value186, {
        text: EMOTE + " _I'm having trouble connecting right now. Try again in a moment._"
      }, {
        quoted: value184
      });
      return true;
    }
    const value231 = cleanAIResponse(value230.response, value189, value215);
    const value232 = trimResponse(value231);
    const value233 = getPersonalizedGreeting(value218);
    const value234 = value233 ? value233 + " " : EMOTE + " ";
    value216.messages.push({
      role: "user",
      content: value208
    });
    value216.messages.push({
      role: "assistant",
      content: value231
    });
    saveConversation(value188, value216);
    value218 = learnFromMessage(value208, value218);
    saveProfile(value217, value188, value218);
    value214.stats.totalQueries = (value214.stats.totalQueries || 0) + 1;
    value214.stats.modelsUsed = value214.stats.modelsUsed || {};
    value214.stats.modelsUsed[value230.model] = (value214.stats.modelsUsed[value230.model] || 0) + 1;
    saveConfig(value214);
    await value183.sendMessage(value186, {
      text: "" + value234 + value232
    }, {
      quoted: value184
    });
    return true;
  } catch (error235) {
    console.error("[" + value189 + "] Chat error:", error235.message);
    return false;
  }
}
async function getDashboardGroupCount(value236) {
  try {
    const value237 = await value236.groupFetchAllParticipating();
    return Object.keys(value237 || {}).length;
  } catch {
    return null;
  }
}
function buildStatusCard(value238, value239, value240) {
  const value241 = value238.mode !== "off";
  const value242 = value241 ? value238.mode === "both" ? "Both" : value238.mode === "groups" ? "Groups" : value238.mode === "dms" ? "DMs" : value238.mode : "off";
  const value243 = String(value238.preferredModel || "nvidia-chat").toUpperCase();
  const value244 = value238.chatbotName || "June Ultra";
  const value245 = value238.techName || "June_Ultra";
  return "╭─⌈ ⚡ *" + value244 + " Chatbot ⌋\n│ Status: " + (value241 ? "🟢 ON" : "🔴 OFF") + "\n│ Mode: " + value242 + "\n│ Model: " + value243 + "\n│ Name: " + value244 + "\n│ Tech: " + value245 + "\n│ Groups: " + (value240 === null ? "Unavailable" : value240) + "\n│ Excluded Groups: " + (value238.excludedGroups || []).length + "\n│ Allowed DMs: " + (value238.allowedDMs || []).length + "\n│ Blocked DMs: " + (value238.blockedDMs || []).length + "\n│ Memory: 🟢 Enabled\n╰─ Type `" + value239 + "chatbot help` to view all commands.";
}
function buildHelpMenu(value246, value247) {
  const value248 = value246.mode !== "off" ? "🟢 ON" : "🔴 OFF";
  const value249 = value246.chatbotName || "June Ultra";
  return "╭─⌈ ⚡ *" + value249 + " CHATBOT* ⌋\n│ " + value248 + "\n│ 🎯 Mode: " + value246.mode + "\n│ 🤖 Model: " + (value246.preferredModel || "nvidia-chat") + "\n│ 🏷️ Name: " + value249 + "\n│ 🏢 Tech: " + (value246.techName || "June_Ultra") + "\n├─⊷ *" + value247 + "chatbot on*\n│  └⊷ Enable everywhere\n├─⊷ *" + value247 + "chatbot off*\n│  └⊷ Disable chatbot\n" + value247 + "chatbot groups*\n│  └⊷ Groups only\n" + value247 + "chatbot dms*\n│  └⊷ DMs only\n" + value247 + "chatbot both*\n│  └⊷ All chats\n" + value247 + "chatbot name <name>*\n│  └⊷ Set chatbot name\n" + value247 + "chatbot techname <name>*\n│  └⊷ Set creator/tech name\n├─⊷ *" + value247 + "chatbot model*\n│  └⊷ Switch AI model\n├─⊷ *" + value247 + "chatbot stats*\n│  └⊷ View stats\n" + value247 + "chatbot status*\n│  └⊷ View status card\n" + value247 + "chatbot clear*\n│  └⊷ Reset history\n├─⊷ *" + value247 + "chatbot settings*\n│  └⊷ View config\n├─⌈ 📋 *GROUP CONTROL* ⌋\n" + value247 + "chatbot addgroup*\n│  └⊷ Re-enable this group\n" + value247 + "chatbot removegroup [jid]*\n│  └⊷ Exclude this group\n├─⊷ *" + value247 + "chatbot listgroups*\n│  └⊷ List groups + status\n├─⊷ *" + value247 + "chatbot cleargroups*\n│  └⊷ Clear exclusions\n├─⌈ 👤 *USER FILTER (per group)* ⌋\n" + value247 + "chatbot allowonly @user*\n│  └⊷ Reply only to selected users\n" + value247 + "chatbot blockuser @user*\n│  └⊷ Ignore selected users\n" + value247 + "chatbot allowuser @user*\n│  └⊷ Add/unblock a user\n" + value247 + "chatbot removeuser @user*\n│  └⊷ Remove user from filters\n├─⊷ *" + value247 + "chatbot listusers*\n│  └⊷ Show this group's filter\n" + value247 + "chatbot clearusers*\n│  └⊷ Reply to everyone\n├─⌈ 💬 *DM CONTROL* ⌋\n" + value247 + "chatbot adddm <number>*\n│  └⊷ Add an allowed DM\n" + value247 + "chatbot removedm <number>*\n│  └⊷ Remove an allowed DM\n├─⊷ *" + value247 + "chatbot blockdm <number>*\n│  └⊷ Block a DM user\n├─⊷ *" + value247 + "chatbot unblockdm <number>*\n│  └⊷ Unblock a DM user\n" + value247 + "chatbot listdms*\n│  └⊷ List allowed DMs\n" + value247 + "chatbot listbdms*\n│  └⊷ List blocked DMs\n" + value247 + "chatbot cleardms*\n│  └⊷ Clear allowed DMs\n" + value247 + "chatbot clearbdms*\n│  └⊷ Clear blocked DMs\n╰───";
}
function commandDistance(value250, value251) {
  value250 = String(value250);
  value251 = String(value251);
  const value252 = value250.length;
  const value253 = value251.length;
  if (value252 === 0) {
    return value253;
  }
  if (value253 === 0) {
    return value252;
  }
  let value254 = new Array(value253 + 1);
  for (let value255 = 0; value255 <= value253; value255++) {
    value254[value255] = value255;
  }
  for (let value256 = 1; value256 <= value252; value256++) {
    const value257 = [value256];
    for (let value258 = 1; value258 <= value253; value258++) {
      const value259 = value250[value256 - 1] === value251[value258 - 1] ? 0 : 1;
      value257[value258] = Math.min(value257[value258 - 1] + 1, value254[value258] + 1, value254[value258 - 1] + value259);
    }
    value254 = value257;
  }
  return value254[value253];
}
async function execute(value260, value261, value262, value263) {
  const value264 = value263 && value263.from || value261.key.remoteJid;
  const value265 = value263 && value263.prefix || ".";
  const value266 = loadConfig();
  const value267 = (value262[0] || "").toLowerCase();
  const value268 = value261.message?.extendedTextMessage?.contextInfo?.stanzaId;
  const value269 = (value262[0] || "").trim();
  if (value268 && _lgCache.has(value268) && /^\d+$/.test(value269)) {
    const value270 = _lgCache.get(value268);
    const value271 = parseInt(value269) - 1;
    const value272 = value270[value271];
    if (!value272) {
      return value260.sendMessage(value264, {
        text: "❌ No group at position *" + value269 + "*. The list has *" + value270.length + "* groups."
      }, {
        quoted: value261
      });
    }
    const value273 = "╭─⌈ 👥 *GROUP DETAIL* ⌋\n├─⊷ *" + value272.name + "*\n╰─⊷ 🆔 `" + value272.gid + "`";
    try {
      const {
        sendInteractiveMessage: value274
      } = require("gifted-btns");
      return await value274(value260, value264, {
        text: value273,
        footer: value266.chatbotName || defaultBotName(),
        interactiveButtons: [{
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "📋 Copy JID",
            copy_code: value272.gid
          })
        }, {
          name: "quick_reply",
          buttonParamsJson: JSON.stringify({
            display_text: "🗑️ Remove Group",
            id: value265 + "chatbot removegroup " + value272.gid
          })
        }]
      });
    } catch {
      return value260.sendMessage(value264, {
        text: value273 + ("\n\n_Long-press the JID above to copy it._\n_Or send:_ `" + value265 + "chatbot removegroup " + value272.gid + "` _to remove._")
      }, {
        quoted: value261
      });
    }
  }
  if (!value267) {
    const value275 = await getDashboardGroupCount(value260);
    const value276 = buildStatusCard(value266, value265, value275);
    if (value263 && typeof value263.reply === "function") {
      return value263.reply(value276);
    } else {
      return value260.sendMessage(value264, {
        text: value276
      }, {
        quoted: value261
      });
    }
  }
  if (value267 === "help") {
    return value260.sendMessage(value264, {
      text: buildHelpMenu(value266, value265)
    }, {
      quoted: value261
    });
  }
  if (["on", "off", "groups", "dms", "both"].includes(value267)) {
    value266.mode = value267;
    saveConfig(value266);
    const value277 = {
      on: "🟢 ON",
      off: "🔴 OFF",
      groups: "👥 GROUPS",
      dms: "💬 DMS",
      both: "🌐 ALL"
    };
    return value260.sendMessage(value264, {
      text: "✅ Chatbot mode set to: *" + value277[value267] + "*"
    }, {
      quoted: value261
    });
  }
  if (value267 === "model") {
    const value278 = (value262[1] || "").toLowerCase();
    if (!value278) {
      const value279 = value266.preferredModel || "nvidia-chat";
      let value280 = "*AI Models:*\n";
      for (const [value281, value282] of Object.entries(AI_MODELS)) {
        value280 += value282.icon + " " + value282.name + " (`" + value281 + "`)" + (value281 === value279 ? " ✅" : "") + "\n";
      }
      value280 += "\nSwitch: `" + value265 + "chatbot model <key>`";
      return value260.sendMessage(value264, {
        text: value280
      }, {
        quoted: value261
      });
    }
    if (!AI_MODELS[value278]) {
      const value283 = Object.keys(AI_MODELS).join(", ");
      return value260.sendMessage(value264, {
        text: "❌ Unknown model: *" + value278 + "*\nAvailable: " + value283
      }, {
        quoted: value261
      });
    }
    value266.preferredModel = value278;
    saveConfig(value266);
    const value284 = AI_MODELS[value278];
    return value260.sendMessage(value264, {
      text: "✅ Model set to: " + value284.icon + " *" + value284.name + "*"
    }, {
      quoted: value261
    });
  }
  if (value267 === "stats") {
    const value285 = value266.stats || {
      totalQueries: 0,
      modelsUsed: {},
      mediaActions: {}
    };
    let value286 = EMOTE + " *" + (value266.chatbotName || defaultBotName()) + " Stats*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" + ("📊 *Total Queries:* " + value285.totalQueries + "\n") + ("🤖 *Model:* " + (AI_MODELS[value266.preferredModel] || AI_MODELS.gpt).name + "\n") + ("📡 *Mode:* " + value266.mode.toUpperCase() + "\n\n");
    if (Object.keys(value285.modelsUsed || {}).length > 0) {
      value286 += "🔄 *AI Usage:*\n";
      const value287 = Object.entries(value285.modelsUsed).sort((value288, value289) => value289[1] - value288[1]);
      for (const [value290, value291] of value287) {
        const value292 = AI_MODELS[value290];
        if (value292) {
          value286 += "  " + value292.icon + " " + value292.name + ": " + value291 + "\n";
        }
      }
      value286 += "\n";
    }
    if (Object.keys(value285.mediaActions || {}).length > 0) {
      const value293 = {
        image: "🎨",
        playAudio: "🎵",
        playVideo: "🎬",
        song: "🎶"
      };
      const value294 = {
        image: "Images",
        playAudio: "Music",
        playVideo: "Videos",
        song: "Songs"
      };
      value286 += "🎯 *Media Actions:*\n";
      for (const [value295, value296] of Object.entries(value285.mediaActions)) {
        value286 += "  " + (value293[value295] || "📦") + " " + (value294[value295] || value295) + ": " + value296 + "\n";
      }
    }
    value286 += "\n⚡ " + (database.getOwnerNames() && database.getOwnerNames()[0] || "JuneX");
    return value260.sendMessage(value264, {
      text: value286
    }, {
      quoted: value261
    });
  }
  if (value267 === "clear") {
    const value297 = value261.key.participant || value264;
    clearConversation(value297);
    clearPendingAction(value297, value264);
    return value260.sendMessage(value264, {
      text: "✅ Conversation history cleared"
    }, {
      quoted: value261
    });
  }
  if (value267 === "settings") {
    const value298 = AI_MODELS[value266.preferredModel] || AI_MODELS.gpt;
    const value299 = {
      off: "🔴",
      on: "🟢",
      groups: "👥",
      dms: "💬",
      both: "🌐"
    };
    const value300 = value266.excludedGroups || [];
    const value301 = value266.allowedDMs || [];
    let value302 = "";
    if (value300.length > 0 || value301.length > 0) {
      value302 = "\n📋 *Filters:*\n";
      if (value300.length > 0) {
        value302 += "  🚫 " + value300.length + " group(s) excluded\n";
      }
      if (value301.length > 0) {
        value302 += "  💬 " + value301.length + " DM(s) whitelisted\n";
      }
    }
    const value303 = value266.chatbotName || defaultBotName();
    const value304 = value266.techName || defaultTechName();
    const value305 = EMOTE + " *" + value303 + " Settings*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" + ("🏷️ *Name:* " + value303 + "\n") + ("🏢 *Tech:* " + value304 + "\n") + ((value299[value266.mode] || "🔴") + " *Mode:* " + value266.mode.toUpperCase() + "\n") + (value298.icon + " *Model:* " + value298.name + "\n") + "🔄 *Auto-Fallback:* Enabled\n💾 *Memory:* 20 msgs (24h timeout)\n🎯 *Interactive:* Images, Music, Videos\n" + ("📊 *Queries:* " + (value266.stats?.totalQueries || 0) + "\n") + value302 + "\n" + ("🤖 *Models (" + Object.keys(AI_MODELS).length + "):*\n") + Object.entries(AI_MODELS).map(([value306, value307]) => "  " + value307.icon + " " + value307.name + " (`" + value306 + "`)").join("\n") + ("\n\n⚡ " + (database.getOwnerNames() && database.getOwnerNames()[0] || "JuneX"));
    return value260.sendMessage(value264, {
      text: value305
    }, {
      quoted: value261
    });
  }
  if (value267 === "addgroup") {
    if (!value264.endsWith("@g.us")) {
      return value260.sendMessage(value264, {
        text: "❌ Run this command inside a group."
      }, {
        quoted: value261
      });
    }
    if (!value266.excludedGroups) {
      value266.excludedGroups = [];
    }
    let value308 = value264.split("@")[0];
    const value309 = global.groupMetadataCache?.get(value264);
    if (value309?.data?.subject) {
      value308 = value309.data.subject;
    }
    const value310 = value266.mode === "off";
    if (value310) {
      value266.mode = "groups";
    }
    const value311 = value266.excludedGroups.indexOf(value264);
    if (value311 !== -1) {
      value266.excludedGroups.splice(value311, 1);
      saveConfig(value266);
      return value260.sendMessage(value264, {
        text: "✅ *" + value308 + "* re-enabled — chatbot will respond here again."
      }, {
        quoted: value261
      });
    }
    saveConfig(value266);
    const value312 = value310 ? "\n⚠️ Mode auto-set to GROUPS (was OFF)" : "";
    return value260.sendMessage(value264, {
      text: "✅ *" + value308 + "* is already active" + value312
    }, {
      quoted: value261
    });
  }
  if (value267 === "removegroup") {
    if (!value266.excludedGroups) {
      value266.excludedGroups = [];
    }
    let value313 = null;
    if (value262[1]) {
      value313 = value262[1].includes("@") ? value262[1].trim() : value262[1].trim() + "@g.us";
    } else if (value264.endsWith("@g.us")) {
      value313 = value264;
    } else {
      return value260.sendMessage(value264, {
        text: "❌ Provide a group JID: *" + value265 + "chatbot removegroup <jid>*\n_Run " + value265 + "chatbot listgroups to see all groups._"
      }, {
        quoted: value261
      });
    }
    if (value266.excludedGroups.includes(value313)) {
      return value260.sendMessage(value264, {
        text: "⚠️ That group is already excluded.\n_Use " + value265 + "chatbot addgroup inside it to re-enable._"
      }, {
        quoted: value261
      });
    }
    let value314 = value313.split("@")[0];
    const value315 = global.groupMetadataCache?.get(value313);
    if (value315?.data?.subject) {
      value314 = value315.data.subject;
    }
    value266.excludedGroups.push(value313);
    saveConfig(value266);
    return value260.sendMessage(value264, {
      text: "🚫 *" + value314 + "* excluded — chatbot won't respond there.\n_Use " + value265 + "chatbot addgroup inside it to re-enable._"
    }, {
      quoted: value261
    });
  }
  if (value267 === "listgroups") {
    const value316 = value266.excludedGroups || [];
    let value317 = [];
    try {
      const value318 = await value260.groupFetchAllParticipating();
      value317 = Object.values(value318 || {});
    } catch (error319) {
      return value260.sendMessage(value264, {
        text: "❌ Failed to fetch groups: " + error319.message
      }, {
        quoted: value261
      });
    }
    if (value317.length === 0) {
      return value260.sendMessage(value264, {
        text: "📋 Bot is not in any groups yet."
      }, {
        quoted: value261
      });
    }
    const value320 = global.groupMetadataCache;
    const value321 = value317.map(value322 => {
      let value323 = (value322.subject || "").trim();
      if (!value323 && value320) {
        const value324 = value320.get(value322.id);
        if (value324?.data?.subject) {
          value323 = value324.data.subject.trim();
        }
      }
      return {
        gid: value322.id,
        name: value323 || value322.id.split("@")[0]
      };
    });
    value321.sort((value325, value326) => value325.name.localeCompare(value326.name));
    const value327 = value321.filter(value328 => !value316.includes(value328.gid)).length;
    let value329 = "📋 *Groups (" + value321.length + " total, " + value327 + " active):*\n\n";
    for (let value330 = 0; value330 < value321.length; value330++) {
      const {
        gid: value331,
        name: value332
      } = value321[value330];
      const value333 = value316.includes(value331);
      value329 += value333 ? value330 + 1 + ". 🚫 *" + value332 + "*\n" : value330 + 1 + ". ✅ *" + value332 + "*\n";
    }
    value329 += "\n_✅ active  •  🚫 excluded_\n_Reply with a number to copy its JID_";
    const value334 = await value260.sendMessage(value264, {
      text: value329
    }, {
      quoted: value261
    });
    const value335 = value334?.key?.id;
    if (value335) {
      _lgCache.set(value335, value321);
      if (_lgCache.size > _LG_MAX) {
        _lgCache.delete(_lgCache.keys().next().value);
      }
    }
    return;
  }
  if (value267 === "cleargroups") {
    value266.excludedGroups = [];
    saveConfig(value266);
    return value260.sendMessage(value264, {
      text: "✅ All exclusions cleared — chatbot will respond in all groups again."
    }, {
      quoted: value261
    });
  }
  if (value267 === "adddm") {
    const value336 = (value262[1] || "").replace(/[^0-9]/g, "");
    if (!value336 || value336.length < 7) {
      return value260.sendMessage(value264, {
        text: "❌ Provide a valid number.\nUsage: `" + value265 + "chatbot adddm 2547xxxxxxxx`"
      }, {
        quoted: value261
      });
    }
    if (!value266.allowedDMs) {
      value266.allowedDMs = [];
    }
    const value337 = value336 + "@s.whatsapp.net";
    const value338 = value266.allowedDMs.some(value339 => value339.split("@")[0].split(":")[0] === value336);
    if (value338) {
      return value260.sendMessage(value264, {
        text: "⚠️ " + value336 + " is already added."
      }, {
        quoted: value261
      });
    }
    value266.allowedDMs.push(value337);
    const value340 = value266.mode === "off";
    if (value340) {
      value266.mode = "dms";
    }
    saveConfig(value266);
    const value341 = value340 ? "\n⚠️ Mode auto-set to DMS (was OFF)" : "";
    return value260.sendMessage(value264, {
      text: "✅ " + value336 + " successfully added" + value341
    }, {
      quoted: value261
    });
  }
  if (value267 === "removedm") {
    const value342 = (value262[1] || "").replace(/[^0-9]/g, "");
    if (!value342 || value342.length < 7) {
      return value260.sendMessage(value264, {
        text: "❌ Provide a valid number.\nUsage: `" + value265 + "chatbot removedm 2547xxxxxxxx`"
      }, {
        quoted: value261
      });
    }
    if (!value266.allowedDMs) {
      value266.allowedDMs = [];
    }
    const value343 = value266.allowedDMs.findIndex(value344 => value344.split("@")[0].split(":")[0] === value342);
    if (value343 === -1) {
      return value260.sendMessage(value264, {
        text: "⚠️ " + value342 + " is not in the list."
      }, {
        quoted: value261
      });
    }
    value266.allowedDMs.splice(value343, 1);
    saveConfig(value266);
    return value260.sendMessage(value264, {
      text: "✅ " + value342 + " successfully removed"
    }, {
      quoted: value261
    });
  }
  if (value267 === "listdms") {
    const value345 = value266.allowedDMs || [];
    if (value345.length === 0) {
      return value260.sendMessage(value264, {
        text: "📋 No DMs in whitelist."
      }, {
        quoted: value261
      });
    }
    let value346 = "📋 *Whitelisted DMs (" + value345.length + "):*\n";
    for (let value347 = 0; value347 < value345.length; value347++) {
      const value348 = value345[value347].split("@")[0].split(":")[0];
      value346 += value347 + 1 + ". +" + value348 + "\n";
    }
    return value260.sendMessage(value264, {
      text: value346
    }, {
      quoted: value261
    });
  }
  if (value267 === "cleardms") {
    value266.allowedDMs = [];
    saveConfig(value266);
    return value260.sendMessage(value264, {
      text: "✅ All DMs cleared"
    }, {
      quoted: value261
    });
  }
  if (value267 === "blockdm") {
    const value349 = (value262[1] || "").replace(/[^0-9]/g, "");
    if (!value349 || value349.length < 7) {
      return value260.sendMessage(value264, {
        text: "❌ Provide a valid number.\nUsage: `" + value265 + "chatbot blockdm 2547xxxxxxxx`"
      }, {
        quoted: value261
      });
    }
    if (!value266.blockedDMs) {
      value266.blockedDMs = [];
    }
    const value350 = value266.blockedDMs.some(value351 => value351.split("@")[0].split(":")[0] === value349);
    if (value350) {
      return value260.sendMessage(value264, {
        text: "⚠️ " + value349 + " is already blocked."
      }, {
        quoted: value261
      });
    }
    value266.blockedDMs.push(value349 + "@s.whatsapp.net");
    saveConfig(value266);
    return value260.sendMessage(value264, {
      text: "🚫 " + value349 + " blocked — chatbot won't respond in DMs with them."
    }, {
      quoted: value261
    });
  }
  if (value267 === "unblockdm") {
    const value352 = (value262[1] || "").replace(/[^0-9]/g, "");
    if (!value352 || value352.length < 7) {
      return value260.sendMessage(value264, {
        text: "❌ Provide a valid number.\nUsage: `" + value265 + "chatbot unblockdm 2547xxxxxxxx`"
      }, {
        quoted: value261
      });
    }
    if (!value266.blockedDMs) {
      value266.blockedDMs = [];
    }
    const value353 = value266.blockedDMs.findIndex(value354 => value354.split("@")[0].split(":")[0] === value352);
    if (value353 === -1) {
      return value260.sendMessage(value264, {
        text: "⚠️ " + value352 + " is not blocked."
      }, {
        quoted: value261
      });
    }
    value266.blockedDMs.splice(value353, 1);
    saveConfig(value266);
    return value260.sendMessage(value264, {
      text: "✅ " + value352 + " unblocked — chatbot can respond again."
    }, {
      quoted: value261
    });
  }
  if (value267 === "listbdms" || value267 === "listblockeddms") {
    const value355 = value266.blockedDMs || [];
    if (value355.length === 0) {
      return value260.sendMessage(value264, {
        text: "📋 No blocked DMs."
      }, {
        quoted: value261
      });
    }
    let value356 = "🚫 *Blocked DMs (" + value355.length + "):*\n";
    for (let value357 = 0; value357 < value355.length; value357++) {
      const value358 = value355[value357].split("@")[0].split(":")[0];
      value356 += value357 + 1 + ". +" + value358 + "\n";
    }
    return value260.sendMessage(value264, {
      text: value356
    }, {
      quoted: value261
    });
  }
  if (value267 === "clearbdms") {
    value266.blockedDMs = [];
    saveConfig(value266);
    return value260.sendMessage(value264, {
      text: "✅ All blocked DMs cleared"
    }, {
      quoted: value261
    });
  }
  if (value267 === "status") {
    const value359 = await getDashboardGroupCount(value260);
    const value360 = buildStatusCard(value266, value265, value359);
    if (value263 && typeof value263.reply === "function") {
      return value263.reply(value360);
    } else {
      return value260.sendMessage(value264, {
        text: value360
      }, {
        quoted: value261
      });
    }
  }
  if (value267 === "name") {
    const value361 = value262.slice(1).join(" ").trim();
    if (!value361) {
      const value362 = value266.chatbotName || defaultBotName();
      return value260.sendMessage(value264, {
        text: "Name: *" + value362 + "*\nChange: `" + value265 + "chatbot name <new name>`"
      }, {
        quoted: value261
      });
    }
    if (value361.length > 30) {
      return value260.sendMessage(value264, {
        text: "❌ Name too long (max 30 characters)."
      }, {
        quoted: value261
      });
    }
    value266.chatbotName = value361;
    saveConfig(value266);
    return value260.sendMessage(value264, {
      text: "✅ Chatbot name set to: *" + value361 + "*"
    }, {
      quoted: value261
    });
  }
  if (value267 === "techname") {
    const value363 = value262.slice(1).join(" ").trim();
    if (!value363) {
      const value364 = value266.techName || defaultTechName();
      return value260.sendMessage(value264, {
        text: "Tech name: *" + value364 + "*\nChange: `" + value265 + "chatbot techname <new name>`"
      }, {
        quoted: value261
      });
    }
    if (value363.length > 40) {
      return value260.sendMessage(value264, {
        text: "❌ Tech name too long (max 40 characters)."
      }, {
        quoted: value261
      });
    }
    value266.techName = value363;
    saveConfig(value266);
    return value260.sendMessage(value264, {
      text: "✅ Tech/creator name set to: *" + value363 + "*\nThe chatbot will now say it was created by *" + value363 + "*."
    }, {
      quoted: value261
    });
  }
  if (["allowonly", "blockuser", "allowuser", "removeuser", "listusers", "clearusers"].includes(value267)) {
    if (!value264.endsWith("@g.us")) {
      return value260.sendMessage(value264, {
        text: "❌ User filters are per-group. Run this command inside a group."
      }, {
        quoted: value261
      });
    }
    if (!value266.groupUserFilters) {
      value266.groupUserFilters = {};
    }
    if (value267 === "listusers") {
      const value365 = value266.groupUserFilters[value264];
      if (!value365 || !value365.users || value365.users.length === 0) {
        return value260.sendMessage(value264, {
          text: "ℹ️ *No user filter set for this group.*\nChatbot replies to *everyone*.\n\nUse:\n• `" + value265 + "chatbot allowonly @user` — only reply to specific people\n• `" + value265 + "chatbot blockuser @user` — block specific people"
        }, {
          quoted: value261
        });
      }
      const value366 = value365.mode === "allow" ? "✅ *ALLOW ONLY* — replies only to listed users" : "🚫 *BLOCK LIST* — replies to everyone except listed users";
      let value367 = "╭─⌈ 👤 *USER FILTER* ⌋\n│\n│ " + value366 + "\n│\n";
      value365.users.forEach((value368, value369) => {
        const value370 = value368.split("@")[0].split(":")[0];
        value367 += "│ " + (value369 + 1) + ". +" + value370 + "\n";
      });
      value367 += "│\n╰⊷ " + (database.getOwnerNames() && database.getOwnerNames()[0] || "JuneX");
      return value260.sendMessage(value264, {
        text: value367
      }, {
        quoted: value261
      });
    }
    if (value267 === "clearusers") {
      delete value266.groupUserFilters[value264];
      saveConfig(value266);
      return value260.sendMessage(value264, {
        text: "✅ User filter cleared — chatbot will reply to *everyone* in this group."
      }, {
        quoted: value261
      });
    }
    const value371 = await _extractTargetUsers(value260, value261, value262);
    if (value371.length === 0) {
      const value372 = value267 === "allowonly" ? "`" + value265 + "chatbot allowonly @user`" : value267 === "blockuser" ? "`" + value265 + "chatbot blockuser @user`" : value267 === "allowuser" ? "`" + value265 + "chatbot allowuser @user`" : "`" + value265 + "chatbot removeuser @user`";
      return value260.sendMessage(value264, {
        text: "❌ @Mention someone or provide a number.\nExample: " + value372
      }, {
        quoted: value261
      });
    }
    const value373 = value374 => ({
      text: value374.map(value375 => "@" + value375.split("@")[0].split(":")[0].replace(/\D/g, "")).join(", "),
      mentions: value374
    });
    const value376 = value266.groupUserFilters[value264] || {
      mode: "block",
      users: []
    };
    if (value267 === "allowonly") {
      value376.mode = "allow";
      for (const value377 of value371) {
        const value378 = value377.split("@")[0].replace(/\D/g, "");
        const value379 = value376.users.some(value380 => value380.split("@")[0].replace(/\D/g, "") === value378);
        if (!value379) {
          value376.users.push(value377);
        }
      }
      value266.groupUserFilters[value264] = value376;
      saveConfig(value266);
      const {
        text: value381,
        mentions: value382
      } = value373(value371);
      return value260.sendMessage(value264, {
        text: "✅ *Allow-only mode* set.\nChatbot will reply *only* to: " + value381 + "\n_Add more anytime with `" + value265 + "chatbot allowonly @user`_",
        mentions: value382
      }, {
        quoted: value261
      });
    }
    if (value267 === "blockuser") {
      value376.mode = "block";
      const value383 = [];
      for (const value384 of value371) {
        const value385 = value384.split("@")[0].replace(/\D/g, "");
        const value386 = value376.users.some(value387 => value387.split("@")[0].replace(/\D/g, "") === value385);
        if (!value386) {
          value376.users.push(value384);
          value383.push(value384);
        }
      }
      value266.groupUserFilters[value264] = value376;
      saveConfig(value266);
      if (value383.length === 0) {
        return value260.sendMessage(value264, {
          text: "⚠️ Those users are already blocked."
        }, {
          quoted: value261
        });
      }
      const {
        text: value388,
        mentions: value389
      } = value373(value383);
      return value260.sendMessage(value264, {
        text: "🚫 *Blocked:* " + value388 + "\nChatbot will ignore them in this group.\n_Use `" + value265 + "chatbot allowuser @user` to unblock._",
        mentions: value389
      }, {
        quoted: value261
      });
    }
    if (value267 === "allowuser") {
      for (const value390 of value371) {
        const value391 = value390.split("@")[0].replace(/\D/g, "");
        if (value376.mode === "block") {
          const value392 = value376.users.findIndex(value393 => value393.split("@")[0].replace(/\D/g, "") === value391);
          if (value392 !== -1) {
            value376.users.splice(value392, 1);
          }
        } else if (value376.mode === "allow") {
          const value394 = value376.users.some(value395 => value395.split("@")[0].replace(/\D/g, "") === value391);
          if (!value394) {
            value376.users.push(value390);
          }
        }
      }
      if (value376.users.length === 0) {
        delete value266.groupUserFilters[value264];
      } else {
        value266.groupUserFilters[value264] = value376;
      }
      saveConfig(value266);
      const {
        text: value396,
        mentions: value397
      } = value373(value371);
      const value398 = value376.mode === "allow" ? "Added to allow list" : "Unblocked";
      return value260.sendMessage(value264, {
        text: "✅ *" + value398 + ":* " + value396,
        mentions: value397
      }, {
        quoted: value261
      });
    }
    if (value267 === "removeuser") {
      const value399 = [];
      for (const value400 of value371) {
        const value401 = value400.split("@")[0].replace(/\D/g, "");
        const value402 = value376.users.findIndex(value403 => value403.split("@")[0].replace(/\D/g, "") === value401);
        if (value402 !== -1) {
          value399.push(value376.users[value402]);
          value376.users.splice(value402, 1);
        }
      }
      if (value399.length === 0) {
        return value260.sendMessage(value264, {
          text: "⚠️ None of those users were in the filter list."
        }, {
          quoted: value261
        });
      }
      if (value376.users.length === 0) {
        delete value266.groupUserFilters[value264];
      } else {
        value266.groupUserFilters[value264] = value376;
      }
      saveConfig(value266);
      const {
        text: value404,
        mentions: value405
      } = value373(value399);
      return value260.sendMessage(value264, {
        text: "✅ *Removed from filter:* " + value404 + "\n" + (value376.users?.length ? "_" + value376.users.length + " user(s) still in list._" : "_Filter cleared — chatbot replies to everyone._"),
        mentions: value405
      }, {
        quoted: value261
      });
    }
  }
  {
    const value406 = ["on", "off", "groups", "dms", "both", "help", "status", "model", "name", "techname", "stats", "clear", "settings", "addgroup", "removegroup", "listgroups", "cleargroups", "allowonly", "blockuser", "allowuser", "removeuser", "listusers", "clearusers", "adddm", "removedm", "blockdm", "unblockdm", "listdms", "listbdms", "listblockeddms", "cleardms", "clearbdms"];
    let value407 = null;
    let value408 = Infinity;
    for (const value409 of value406) {
      const value410 = commandDistance(value267, value409);
      if (value410 < value408) {
        value408 = value410;
        value407 = value409;
      }
    }
    const value411 = Math.max(2, Math.floor(value267.length / 2));
    if (value407 && value408 <= value411 && value408 <= 3) {
      return value260.sendMessage(value264, {
        text: "❌ Unknown option: *" + value267 + "*\n\n💡 Did you mean: `" + value265 + "chatbot " + value407 + "`?\n_Use `" + value265 + "chatbot help` to see all commands._"
      }, {
        quoted: value261
      });
    }
    return value260.sendMessage(value264, {
      text: "❌ Unknown option: *" + value267 + "*\nUse `" + value265 + "chatbot` to see all commands."
    }, {
      quoted: value261
    });
  }
}
async function handleAutoReply(value412, value413, {
  from: value414,
  isGroup: value415,
  commands: value416
}) {
  try {
    const value417 = value414 || value413.key.remoteJid;
    if (!value417) {
      return false;
    }
    if (!isChatbotActiveForChat(value417)) {
      return false;
    }
    const value418 = await handleChatbotMessage(value412, value413, value416);
    return value418 === true;
  } catch (error419) {
    console.error("[Chatbot/AutoReply]", error419.message);
    return false;
  }
}
module.exports = {
  name: "chatbot",
  description: "JuneX Ultra AI chatbot | intelligent replies, image/audio/video intents, per-user memory",
  category: "ai",
  aliases: ["aichat", "ai-chat", "junex", "juneai"],
  usage: "chatbot <on|off|groups|dms|both|model>",
  ownerOnly: true,
  execute: execute,
  handleAutoReply: handleAutoReply,
  handleChatbotMessage: handleChatbotMessage,
  getChatbotConfig: getChatbotConfig,
  isChatbotActiveForChat: isChatbotActiveForChat
};
