const database = require(require("path").join(global.__CORE__, "database"));
const botCorrecting = new Set();
function markCorrecting(value1) {
  botCorrecting.add(value1);
  setTimeout(() => botCorrecting.delete(value1), 6000);
}
function excludeBot(value2, value3) {
  const value4 = value3.includes(":") ? value3.split(":")[0] : value3.split("@")[0];
  return value2.filter(value5 => {
    if (!value5) {
      return false;
    }
    const value6 = value5.split(":")[0].split("@")[0];
    return value6 !== value4 && value5 !== value3;
  });
}
async function handleDemote(value7, value8, value9, value10) {
  try {
    const value11 = database.getGroupSettings(value8);
    if (!value11.antidemote) {
      return;
    }
    if (botCorrecting.has(value10)) {
      return;
    }
    const value12 = value7.user?.id || "";
    const value13 = value11.antidemoteAction || "revert";
    const value14 = value9 ? value9.split("@")[0] : "Unknown";
    const value15 = value10 ? value10.split("@")[0] : "Unknown";
    const value16 = new Date().toLocaleString("en-GB", {
      timeZone: database.getTimeZone(),
      hour12: false,
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
    markCorrecting(value10);
    if (value9) {
      markCorrecting(value9);
    }
    let value17 = "";
    if (value13 === "revert") {
      const value18 = excludeBot([value10], value12);
      if (value18.length) {
        await value7.groupParticipantsUpdate(value8, value18, "promote");
      }
      value17 = "🔄 *Action:* Demotion reversed — admin restored";
    } else if (value13 === "kick") {
      const value19 = excludeBot([value10, value9], value12);
      if (value19.length) {
        await value7.groupParticipantsUpdate(value8, value19, "remove");
      }
      value17 = "🚫 *Action:* Both parties kicked from the group";
    } else if (value13 === "demote") {
      const value20 = excludeBot([value9], value12);
      if (value20.length) {
        await value7.groupParticipantsUpdate(value8, value20, "demote");
      }
      value17 = "⬇️ *Action:* Demoter demoted to regular member";
    }
    await value7.sendMessage(value8, {
      text: ["⚠️ *Security Alert — AntiDemote*", "", "An unauthorized demotion was *detected and actioned*.", "", "👤 *Demoter:* @" + value14, "🎯 *Demoted:* @" + value15, "⏰ *Time:* " + value16, "" + value17, "", "> Powered by " + database.getBotSetting("botName")].join("\n"),
      mentions: [value9, value10].filter(Boolean)
    });
  } catch (error21) {
    console.error("[AntiDemote] Error:", error21.message);
  }
}
module.exports = {
  name: "antidemote",
  aliases: ["antidm"],
  category: "admin",
  description: "Block unauthorized admin demotions with configurable action",
  usage: ".antidemote on | revert | kick | demote | off",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  handleDemote: handleDemote,
  botCorrecting: botCorrecting,
  async execute(value22, value23, value24, value25) {
    const {
      from: value26,
      reply: value27,
      react: value28
    } = value25;
    const value29 = value24[0]?.toLowerCase();
    const value30 = database.getGroupSettings(value26);
    const value31 = !!value30.antidemote;
    const value32 = value30.antidemoteAction || "revert";
    const value33 = {
      revert: "🔄 Revert — restore the demoted admin",
      kick: "🚫 Kick — remove both parties from group",
      demote: "⬇️ Demote — demote the demoter"
    };
    if (!value29) {
      return value27("🛡️ *AntiDemote*\n\n" + ("Status: *" + (value31 ? "✅ ON" : "❌ OFF") + "*\n") + ("Action: *" + (value31 ? value33[value32] || value32 : "—") + "*\n\n") + "Catches unauthorized demotions and acts on both parties.\n\n*Options:*\n  .antidemote revert  — restore the demoted admin\n  .antidemote kick    — kick both demoter + demoted\n  .antidemote demote  — demote the demoter\n  .antidemote on      — enable (default: revert)\n  .antidemote off     — disable");
    }
    if (value29 === "on") {
      database.updateGroupSettings(value26, {
        antidemote: true
      });
      await value28("✅");
      return value27("🛡️ *AntiDemote enabled* — action: *" + (value33[value32] || value32) + "*");
    }
    if (value29 === "off") {
      database.updateGroupSettings(value26, {
        antidemote: false
      });
      await value28("✅");
      return value27("🛡️ *AntiDemote disabled.*");
    }
    if (["revert", "kick", "demote"].includes(value29)) {
      database.updateGroupSettings(value26, {
        antidemote: true,
        antidemoteAction: value29
      });
      await value28("✅");
      return value27("🛡️ *AntiDemote enabled*\n" + value33[value29]);
    }
    return value27("❌ Usage: .antidemote on | revert | kick | demote | off");
  }
};
