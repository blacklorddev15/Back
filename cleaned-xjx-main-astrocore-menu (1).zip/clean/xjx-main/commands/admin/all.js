module.exports = {
  name: "all",
  aliases: ["tag-all", "alltag"],
  category: "admin",
  description: "Tag all members in the group",
  usage: ".all [message]  |  @all [message]",
  groupOnly: true,
  adminOnly: false,
  botAdminNeeded: false,
  async execute(value1, value2, value3, value4) {
    try {
      const {
        from: value5,
        groupMetadata: value6,
        reply: value7
      } = value4;
      const value8 = (value6?.participants || []).map(value9 => value9.id).filter(Boolean);
      if (!value8.length) {
        return value7("⚠️ Could not fetch group members.");
      }
      const value10 = value3.join(" ").trim();
      const value11 = "━━━━━━━━━━━━━━━━━━━━";
      const value12 = value8.map(value13 => "@" + value13.split("@")[0].split(":")[0]).join("  ");
      const value14 = value2.message?.extendedTextMessage?.contextInfo;
      const value15 = value14?.quotedMessage;
      if (value15) {
        const value16 = value15.conversation || value15.extendedTextMessage?.text || value15.imageMessage?.caption || value15.videoMessage?.caption || "";
        const value17 = "📢 *TAG ALL*\n" + value11 + "\n" + (value10 ? "💬 " + value10 + "\n\n" : "") + (value16 ? "📝 " + value16 + "\n\n" : "") + (value11 + "\n" + value12);
        await value1.sendMessage(value5, {
          text: value17,
          mentions: value8
        }, {
          quoted: value2
        });
        return;
      }
      const value18 = "📢 *TAG ALL*\n" + value11 + "\n" + (value10 ? "💬 " + value10 + "\n\n" : "") + (value11 + "\n" + value12);
      await value1.sendMessage(value5, {
        text: value18,
        mentions: value8
      }, {
        quoted: value2
      });
    } catch (error19) {
      console.error("[ALL] error:", error19.message);
      await value4.reply("❌ Failed to tag all members.");
    }
  }
};
