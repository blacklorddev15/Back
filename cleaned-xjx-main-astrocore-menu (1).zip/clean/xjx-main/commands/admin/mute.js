const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "mute",
  aliases: ["silence", "closegroup"],
  category: "admin",
  description: "Mute a user (auto-deletes their messages) or lock the whole group",
  usage: ".mute @user  OR  .mute  (locks group)",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      const value6 = value2.message?.extendedTextMessage?.contextInfo;
      const value7 = value6?.mentionedJid || [];
      const value8 = value6?.participant && value6.stanzaId ? value6.participant : null;
      const value9 = value7[0] || value8;
      if (!value9) {
        await value1.groupSettingUpdate(value5, "announcement");
        return value4.reply("🔒 *Group Locked*\n\nOnly admins can send messages now.\nUse `.unmute` to reopen.");
      }
      const value10 = value1.user?.id ? value1.user.id.split(":")[0] + "@s.whatsapp.net" : null;
      if (value10 && (value9 === value10 || value9 === value1.user?.id)) {
        return value4.reply("🤖 I cannot mute myself!");
      }
      const value11 = value4.groupMetadata?.participants?.some(value12 => (value12.id === value9 || value12.lid === value9) && (value12.admin === "admin" || value12.admin === "superadmin"));
      if (value11) {
        return value4.reply("❌ Cannot mute a group admin!");
      }
      database.muteUser(value5, value9);
      database.clearWarnings(value5, value9);
      const value13 = value9.split("@")[0];
      await value1.sendMessage(value5, {
        text: "🔇 *User Muted*\n\n" + ("👤 @" + value13 + " has been muted.\n") + "🗑️ Their messages will be automatically deleted.\n⚠️ Their warnings have been cleared.\n\n_Use .unmute @user to restore their access._",
        mentions: [value9]
      }, {
        quoted: value2
      });
    } catch (error14) {
      console.error("[mute] error:", error14);
      await value4.reply("❌ Error: " + error14.message);
    }
  }
};
