module.exports = {
  name: "add",
  aliases: [],
  category: "admin",
  description: "Add a member to the group by phone number",
  usage: ".add <number>  e.g. .add 254798570132",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    try {
      if (!value3 || value3.length === 0) {
        return value4.reply("📲 Please provide a phone number.\n\nExample: .add 254798570132");
      }
      const value5 = value3[0].replace(/[^0-9]/g, "");
      if (!value5 || value5.length < 7) {
        return value4.reply("❌ Invalid phone number. Example: .add 254798570132");
      }
      const value6 = value5 + "@s.whatsapp.net";
      const value7 = await value1.groupParticipantsUpdate(value4.from, [value6], "add");
      const value8 = value7 && value7[0] && value7[0].status;
      if (value8 === "200") {
        await value1.sendMessage(value4.from, {
          text: "✅ @" + value5 + " has been added to the group!",
          mentions: [value6]
        }, {
          quoted: value2
        });
      } else if (value8 === "403") {
        await value4.reply("❌ Cannot add @" + value5 + " — their privacy settings prevent being added to groups.");
      } else if (value8 === "408") {
        await value4.reply("❌ @" + value5 + " is not registered on WhatsApp or the number is invalid.");
      } else if (value8 === "409") {
        await value4.reply("❌ @" + value5 + " is already a member of this group.");
      } else {
        await value4.reply("❌ Failed to add " + value5 + ". Make sure the number is correct and I am an admin.");
      }
    } catch (error9) {
      console.error("Add command error:", error9);
      await value4.reply("❌ Failed to add member. Make sure I am an admin and the number is valid.");
    }
  }
};
