const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
module.exports = {
  name: "setgroupprofile",
  aliases: ["sgp", "setgrouppp", "setgrouppic"],
  category: "admin",
  description: "Set the group's profile picture",
  usage: ".setgroupprofile (send or reply to an image)",
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      let value6 = null;
      if (value2.message?.imageMessage) {
        value6 = value2;
      }
      if (!value6) {
        const value7 = value2.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (value7?.imageMessage) {
          value6 = {
            key: {
              remoteJid: value5,
              fromMe: false,
              id: value2.message.extendedTextMessage.contextInfo.stanzaId,
              participant: value2.message.extendedTextMessage.contextInfo.participant
            },
            message: value7
          };
        }
      }
      if (!value6) {
        return value4.reply("❌ Please send an image or reply to an image with this command.");
      }
      await value1.sendMessage(value5, {
        react: {
          text: "🖼️",
          key: value2.key
        }
      });
      const value8 = await downloadMediaMessage(value6, "buffer", {}, {
        logger: undefined
      });
      await value1.updateProfilePicture(value5, value8);
      await value4.reply("✅ Group profile picture updated successfully!");
    } catch (error9) {
      console.error("setgroupprofile error:", error9);
      if (error9.message?.includes("not-authorized") || error9.output?.statusCode === 401) {
        return value4.reply("❌ I do not have permission to change the group picture.");
      }
      value4.reply("❌ Failed to update group profile picture.");
    }
  }
};
