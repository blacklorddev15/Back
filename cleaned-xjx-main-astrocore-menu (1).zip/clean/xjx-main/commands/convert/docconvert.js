const fs = require("fs");
const path = require("path");
const os = require("os");
const {
  exec
} = require("child_process");
const {
  promisify
} = require("util");
const execAsync = promisify(exec);
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const TEMP_DIR = path.join(os.tmpdir(), "june-x-docconv");
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, {
    recursive: true
  });
}
async function getLibreOfficeBin() {
  const value1 = ["soffice", "libreoffice", "/usr/bin/soffice", "/usr/lib/libreoffice/program/soffice"];
  for (const value2 of value1) {
    try {
      await execAsync(value2 + " --version");
      return value2;
    } catch {}
  }
  return null;
}
async function libreOfficeConvert(value3, value4, value5) {
  const value6 = await getLibreOfficeBin();
  if (!value6) {
    return false;
  }
  try {
    await execAsync(value6 + " --headless --convert-to " + value5 + " --outdir \"" + value4 + "\" \"" + value3 + "\"", {
      timeout: 60000
    });
    return true;
  } catch (error7) {
    console.error("LibreOffice convert error:", error7.message);
    return false;
  }
}
function writeTmp(value8, value9) {
  const value10 = path.join(TEMP_DIR, "input_" + Date.now() + "_" + Math.random().toString(36).slice(2) + "." + value9);
  fs.writeFileSync(value10, value8);
  return value10;
}
function cleanup(...value11) {
  for (const value12 of value11) {
    try {
      if (value12 && fs.existsSync(value12)) {
        fs.unlinkSync(value12);
      }
    } catch {}
  }
}
async function downloadDocument(value13, value14) {
  const value15 = value14.message?.extendedTextMessage?.contextInfo;
  if (!value15?.quotedMessage) {
    return null;
  }
  const value16 = value15.quotedMessage.documentMessage || value15.quotedMessage.documentWithCaptionMessage?.message?.documentMessage;
  if (!value16) {
    return null;
  }
  const value17 = {
    key: {
      remoteJid: value15.remoteJid || value14.key.remoteJid,
      fromMe: false,
      id: value15.stanzaId,
      participant: value15.participant
    },
    message: value15.quotedMessage
  };
  const value18 = await downloadMediaMessage(value17, "buffer", {}, {
    logger: undefined
  });
  return {
    buffer: value18,
    docMsg: value16
  };
}
async function pdfToText(value19) {
  let value20;
  try {
    value20 = require("pdf-parse");
  } catch {
    throw new Error("pdf-parse is not installed. Run: npm i pdf-parse");
  }
  const value21 = Buffer.isBuffer(value19) ? value19 : Buffer.from(value19);
  const value22 = await value20(value21, {
    version: "v1.10.100"
  });
  const value23 = (value22.text || "").trim();
  if (!value23) {
    throw new Error("No readable text found in PDF. It may be scanned/image-based.");
  }
  return value23;
}
async function textToExcel(value24, value25) {
  let value26;
  try {
    value26 = require("xlsx");
  } catch {
    throw new Error("xlsx is not installed. Run: npm i xlsx");
  }
  const value27 = value24.split("\n").map(value28 => value28.trimEnd()).filter(value29 => value29.length > 0);
  const value30 = value27.map(value31 => {
    const value32 = value31.split(/\t|\s{2,}/);
    if (value32.length > 1) {
      return value32;
    } else {
      return [value31];
    }
  });
  const value33 = value26.utils.aoa_to_sheet(value30);
  const value34 = value30.reduce((value35, value36) => {
    value36.forEach((value37, value38) => {
      value35[value38] = Math.max(value35[value38] || 0, String(value37 || "").length);
    });
    return value35;
  }, []);
  value33["!cols"] = value34.map(value39 => ({
    wch: Math.min(value39 + 2, 60)
  }));
  const value40 = value26.utils.book_new();
  value26.utils.book_append_sheet(value40, value33, "Sheet1");
  value26.writeFile(value40, value25);
}
async function textToWord(value41, value42) {
  let value43;
  let value44;
  let value45;
  let value46;
  try {
    ({
      Document: value43,
      Packer: value44,
      Paragraph: value45,
      TextRun: value46
    } = require("docx"));
  } catch {
    throw new Error("docx is not installed. Run: npm i docx");
  }
  const value47 = value41.split("\n").map(value48 => value48.trim());
  const value49 = value47.map(value50 => new value45({
    children: [new value46({
      text: value50,
      size: 24,
      font: "Calibri"
    })],
    spacing: {
      after: 120
    }
  }));
  const value51 = new value43({
    sections: [{
      properties: {},
      children: value49
    }]
  });
  const value52 = await value44.toBuffer(value51);
  fs.writeFileSync(value42, value52);
}
async function docxToPdfNode(value53, value54) {
  let value55;
  let value56;
  try {
    value55 = require("mammoth");
  } catch {
    throw new Error("mammoth is not installed. Run: npm i mammoth");
  }
  try {
    value56 = require("pdfkit");
  } catch {
    throw new Error("pdfkit is not installed. Run: npm i pdfkit");
  }
  const value57 = await value55.extractRawText({
    buffer: value53
  });
  const value58 = (value57.value || "").trim();
  if (!value58) {
    throw new Error("No readable text found in the Word document.");
  }
  await new Promise((value59, value60) => {
    const value61 = new value56({
      margin: 50,
      size: "A4"
    });
    const value62 = fs.createWriteStream(value54);
    value61.pipe(value62);
    value61.font("Helvetica").fontSize(11);
    const value63 = value61.page.width - 100;
    value58.split("\n").forEach(value64 => {
      const value65 = value64.trim();
      if (value65 === "") {
        value61.moveDown(0.4);
      } else {
        value61.text(value65, {
          width: value63,
          lineGap: 3
        });
      }
    });
    value61.end();
    value62.on("finish", value59);
    value62.on("error", value60);
  });
}
async function excelToPdfNode(value66, value67) {
  let value68;
  let value69;
  try {
    value68 = require("xlsx");
  } catch {
    throw new Error("xlsx is not installed. Run: npm i xlsx");
  }
  try {
    value69 = require("pdfkit");
  } catch {
    throw new Error("pdfkit is not installed. Run: npm i pdfkit");
  }
  const value70 = value68.read(value66, {
    type: "buffer"
  });
  const value71 = value70.SheetNames[0];
  const value72 = value70.Sheets[value71];
  const value73 = value68.utils.sheet_to_json(value72, {
    header: 1,
    defval: ""
  });
  if (!value73.length) {
    throw new Error("Excel file appears to be empty.");
  }
  await new Promise((value74, value75) => {
    const value76 = new value69({
      margin: 30,
      size: "A4",
      layout: "landscape"
    });
    const value77 = fs.createWriteStream(value67);
    value76.pipe(value77);
    value76.font("Helvetica").fontSize(9);
    const value78 = value76.page.width - 60;
    const value79 = value76.page.height - 60;
    const value80 = Math.max(...value73.map(value81 => value81.length));
    const value82 = value80 > 0 ? Math.floor(value78 / value80) : value78;
    value73.forEach((value83, value84) => {
      if (value76.y > value79 - 20) {
        value76.addPage();
      }
      let value85 = 30;
      const value86 = value76.y;
      let value87 = 14;
      value83.forEach((value88, value89) => {
        const value90 = String(value88 ?? "");
        const value91 = value76.heightOfString(value90, {
          width: value82 - 4
        });
        value87 = Math.max(value87, value91 + 4);
        if (value84 === 0) {
          value76.font("Helvetica-Bold");
        } else {
          value76.font("Helvetica");
        }
        value76.text(value90, value85 + 2, value86, {
          width: value82 - 4,
          lineBreak: true
        });
        value85 += value82;
      });
      value76.y = value86 + value87;
      value76.x = 30;
      if (value84 === 0) {
        value76.moveTo(30, value76.y).lineTo(30 + value78, value76.y).stroke();
      }
    });
    value76.end();
    value77.on("finish", value74);
    value77.on("error", value75);
  });
}
async function convertWithFallback(value92, value93, value94, value95, value96) {
  const value97 = writeTmp(value94, value92);
  try {
    const value98 = await libreOfficeConvert(value97, TEMP_DIR, value93);
    if (value98) {
      const value99 = path.basename(value97, "." + value92);
      const value100 = path.join(TEMP_DIR, value99 + "." + value93);
      if (fs.existsSync(value100)) {
        fs.renameSync(value100, value95);
        cleanup(value97);
        return;
      }
    }
    await value96(value94, value95);
  } finally {
    cleanup(value97);
  }
}
const MIME_TYPES = {
  pdf: "application/pdf",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
};
module.exports = [{
  name: "toexcel",
  aliases: ["xlsx", "pdftoexcel"],
  category: "convert",
  description: "Convert a PDF to Excel (.xlsx)",
  usage: ".toexcel (reply to a PDF)",
  async execute(value101, value102, value103, value104) {
    const value105 = value104.from;
    const value106 = await downloadDocument(value101, value102);
    if (!value106) {
      return value104.reply("📎 Reply to a *PDF document* with *.toexcel*");
    }
    const {
      buffer: value107,
      docMsg: value108
    } = value106;
    if (!(value108.mimetype || "").includes("pdf")) {
      return value104.reply("❌ Only *PDF* files can be converted to Excel.");
    }
    await value101.sendMessage(value105, {
      react: {
        text: "⏳",
        key: value102.key
      }
    });
    const value109 = path.join(TEMP_DIR, "out_" + Date.now() + ".xlsx");
    try {
      const value110 = await pdfToText(value107);
      await textToExcel(value110, value109);
      await value101.sendMessage(value105, {
        document: fs.readFileSync(value109),
        mimetype: MIME_TYPES.xlsx,
        fileName: "converted.xlsx",
        caption: "✅ Converted to Excel."
      }, {
        quoted: value102
      });
      await value101.sendMessage(value105, {
        react: {
          text: "✅",
          key: value102.key
        }
      });
    } catch (error111) {
      console.error("toexcel error:", error111);
      await value104.reply("❌ Conversion failed: " + error111.message);
      await value101.sendMessage(value105, {
        react: {
          text: "❌",
          key: value102.key
        }
      });
    } finally {
      cleanup(value109);
    }
  }
}, {
  name: "toword",
  aliases: ["docx2", "pdftoword"],
  category: "convert",
  description: "Convert a PDF to Word (.docx)",
  usage: ".toword (reply to a PDF)",
  async execute(value112, value113, value114, value115) {
    const value116 = value115.from;
    const value117 = await downloadDocument(value112, value113);
    if (!value117) {
      return value115.reply("📎 Reply to a *PDF document* with *.toword*");
    }
    const {
      buffer: value118,
      docMsg: value119
    } = value117;
    if (!(value119.mimetype || "").includes("pdf")) {
      return value115.reply("❌ Only *PDF* files can be converted to Word.");
    }
    await value112.sendMessage(value116, {
      react: {
        text: "⏳",
        key: value113.key
      }
    });
    const value120 = path.join(TEMP_DIR, "out_" + Date.now() + ".docx");
    try {
      const value121 = await pdfToText(value118);
      await textToWord(value121, value120);
      await value112.sendMessage(value116, {
        document: fs.readFileSync(value120),
        mimetype: MIME_TYPES.docx,
        fileName: "converted.docx",
        caption: "✅ Converted to Word."
      }, {
        quoted: value113
      });
      await value112.sendMessage(value116, {
        react: {
          text: "✅",
          key: value113.key
        }
      });
    } catch (error122) {
      console.error("toword error:", error122);
      await value115.reply("❌ Conversion failed: " + error122.message);
      await value112.sendMessage(value116, {
        react: {
          text: "❌",
          key: value113.key
        }
      });
    } finally {
      cleanup(value120);
    }
  }
}, {
  name: "topdf",
  aliases: ["converttopdf", "makepdf"],
  category: "convert",
  description: "Convert Word (.docx) or Excel (.xlsx) to PDF",
  usage: ".topdf (reply to a .docx or .xlsx)",
  async execute(value123, value124, value125, value126) {
    const value127 = value126.from;
    const value128 = await downloadDocument(value123, value124);
    if (!value128) {
      return value126.reply("📎 Reply to a *Word (.docx)* or *Excel (.xlsx)* with *.topdf*");
    }
    const {
      buffer: value129,
      docMsg: value130
    } = value128;
    const value131 = value130.mimetype || "";
    const value132 = (value130.fileName || "").toLowerCase();
    const value133 = value131.includes("wordprocessingml") || value131.includes("msword") || value132.endsWith(".docx") || value132.endsWith(".doc");
    const value134 = value131.includes("spreadsheetml") || value131.includes("ms-excel") || value132.endsWith(".xlsx") || value132.endsWith(".xls");
    if (!value133 && !value134) {
      return value126.reply("❌ Send a *Word (.docx)* or *Excel (.xlsx)* file.");
    }
    await value123.sendMessage(value127, {
      react: {
        text: "⏳",
        key: value124.key
      }
    });
    const value135 = path.join(TEMP_DIR, "out_" + Date.now() + ".pdf");
    try {
      if (value133) {
        await convertWithFallback("docx", "pdf", value129, value135, docxToPdfNode);
      } else {
        await convertWithFallback("xlsx", "pdf", value129, value135, excelToPdfNode);
      }
      await value123.sendMessage(value127, {
        document: fs.readFileSync(value135),
        mimetype: MIME_TYPES.pdf,
        fileName: "converted.pdf",
        caption: "✅ Converted to PDF."
      }, {
        quoted: value124
      });
      await value123.sendMessage(value127, {
        react: {
          text: "✅",
          key: value124.key
        }
      });
    } catch (error136) {
      console.error("topdf error:", error136);
      await value126.reply("❌ Conversion failed: " + error136.message);
      await value123.sendMessage(value127, {
        react: {
          text: "❌",
          key: value124.key
        }
      });
    } finally {
      cleanup(value135);
    }
  }
}];
