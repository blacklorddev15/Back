const fs = require("fs");
const path = require("path");
const {
  execFile
} = require("child_process");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const ffmpegPath = require("../../utils/ffmpegPath");
const {
  getTempDir
} = require("../../utils/tempManager");
const MAX_SECONDS = 45;
const MAX_BYTES = 16777216;
function unwrapMessage(value1) {
  let value2 = value1 || {};
  if (value2.ephemeralMessage?.message) {
    value2 = value2.ephemeralMessage.message;
  }
  if (value2.viewOnceMessageV2Extension?.message) {
    value2 = value2.viewOnceMessageV2Extension.message;
  }
  if (value2.viewOnceMessageV2?.message) {
    value2 = value2.viewOnceMessageV2.message;
  }
  if (value2.viewOnceMessage?.message) {
    value2 = value2.viewOnceMessage.message;
  }
  if (value2.documentWithCaptionMessage?.message) {
    value2 = value2.documentWithCaptionMessage.message;
  }
  return value2;
}
function findSource(value3) {
  const value4 = unwrapMessage(value3.message);
  if (value4.videoMessage) {
    return {
      kind: "video",
      target: value3,
      video: value4.videoMessage
    };
  }
  if (value4.documentMessage?.mimetype?.startsWith("video/")) {
    return {
      kind: "video",
      target: value3,
      video: value4.documentMessage
    };
  }
  const value5 = value3.message?.extendedTextMessage?.contextInfo || value3.message?.imageMessage?.contextInfo || value3.message?.videoMessage?.contextInfo || null;
  const value6 = unwrapMessage(value5?.quotedMessage);
  if (!value6 || !value5) {
    return null;
  }
  const value7 = {
    key: {
      remoteJid: value5.remoteJid || value3.key.remoteJid,
      fromMe: false,
      id: value5.stanzaId,
      participant: value5.participant
    },
    message: value6
  };
  if (value6.videoMessage) {
    return {
      kind: "video",
      target: value7,
      video: value6.videoMessage
    };
  }
  if (value6.documentMessage?.mimetype?.startsWith("video/")) {
    return {
      kind: "video",
      target: value7,
      video: value6.documentMessage
    };
  }
  if (value6.stickerMessage?.isAnimated) {
    return {
      kind: "sticker",
      target: value7,
      sticker: value6.stickerMessage
    };
  }
  return null;
}
function probeDuration(value8) {
  return new Promise(value9 => {
    execFile(ffmpegPath(), ["-i", value8], (value10, value11, value12) => {
      const value13 = (value12 || "").match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
      if (!value13) {
        return value9(0);
      }
      value9(+value13[1] * 3600 + +value13[2] * 60 + parseFloat(value13[3]));
    });
  });
}
function runFfmpeg(value14) {
  return new Promise((value15, value16) => {
    execFile(ffmpegPath(), value14, (value17, value18, value19) => {
      if (value17) {
        const value20 = (value19 || "").split("\n").slice(-4).join(" ").trim();
        return value16(new Error(value20 || value17.message));
      }
      value15();
    });
  });
}
module.exports = {
  name: "togif",
  aliases: ["asgif", "sendgif", "videogif"],
  category: "convert",
  description: "Send a video as a WhatsApp GIF",
  usage: ".togif (reply to a video, gif, or animated sticker)",
  async execute(value21, value22, value23, value24) {
    const value25 = value24.from;
    const value26 = Date.now();
    const value27 = path.join(getTempDir(), "gif_in_" + value26 + ".tmp");
    const value28 = path.join(getTempDir(), "gif_out_" + value26 + ".mp4");
    try {
      const value29 = findSource(value22);
      if (!value29) {
        return value24.reply("🎞️ Reply to a *video*, *gif*, or *animated sticker* with `.togif`.\nYou can also send a video with `.togif` as the caption.");
      }
      if (value24.react) {
        await value24.react("🎞️").catch(() => {});
      }
      const value30 = await downloadMediaMessage(value29.target, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value21.updateMediaMessage
      });
      if (!value30 || !value30.length) {
        throw new Error("Failed to download the media.");
      }
      if (value29.kind === "sticker") {
        const {
          webp2mp4: value31
        } = require("../../utils/webp2mp4");
        const value32 = await value31(value30);
        if (!value32?.length) {
          throw new Error("Sticker conversion returned empty output.");
        }
        if (value32.length > MAX_BYTES) {
          throw new Error("Converted GIF is larger than 16MB.");
        }
        await value21.sendMessage(value25, {
          video: value32,
          gifPlayback: true,
          mimetype: "video/mp4"
        }, {
          quoted: value22
        });
        if (value24.react) {
          await value24.react("✅").catch(() => {});
        }
        return;
      }
      fs.writeFileSync(value27, value30);
      const value33 = await probeDuration(value27);
      const value34 = value33 > MAX_SECONDS ? ["-t", String(MAX_SECONDS)] : [];
      await runFfmpeg(["-y", "-i", value27, ...value34, "-an", "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", "-c:v", "libx264", "-preset", "veryfast", "-crf", "28", "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-f", "mp4", value28]);
      if (!fs.existsSync(value28) || fs.statSync(value28).size === 0) {
        throw new Error("Conversion produced an empty file.");
      }
      const value35 = fs.readFileSync(value28);
      if (value35.length > MAX_BYTES) {
        throw new Error("Converted GIF is larger than 16MB.");
      }
      await value21.sendMessage(value25, {
        video: value35,
        gifPlayback: true,
        mimetype: "video/mp4"
      }, {
        quoted: value22
      });
      if (value24.react) {
        await value24.react("✅").catch(() => {});
      }
    } catch (error36) {
      console.error("[togif]", error36.message);
      if (value24.react) {
        await value24.react("❌").catch(() => {});
      }
      try {
        const value37 = findSource(value22);
        if (value37?.kind === "video") {
          const value38 = await downloadMediaMessage(value37.target, "buffer", {}, {
            logger: undefined,
            reuploadRequest: value21.updateMediaMessage
          });
          if (value38?.length && value38.length <= MAX_BYTES) {
            await value21.sendMessage(value25, {
              video: value38,
              gifPlayback: true,
              mimetype: "video/mp4"
            }, {
              quoted: value22
            });
            return;
          }
        }
      } catch (error39) {}
      await value24.reply("❌ ToGIF failed: " + error36.message);
    } finally {
      for (const value40 of [value27, value28]) {
        try {
          if (fs.existsSync(value40)) {
            fs.unlinkSync(value40);
          }
        } catch (error41) {}
      }
    }
  }
};
