const fs = require("fs");
const path = require("path");
const os = require("os");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const {
  toAudio
} = require("../../utils/converter");
const {
  webp2mp4
} = require("../../utils/webp2mp4");
const TEMP_DIR = path.join(os.tmpdir(), "june-x-conv");
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, {
    recursive: true
  });
}
async function downloadQuoted(value1, value2) {
  const value3 = value2.message?.extendedTextMessage?.contextInfo;
  if (!value3?.quotedMessage) {
    return null;
  }
  const value4 = {
    key: {
      remoteJid: value3.remoteJid || value2.key.remoteJid,
      fromMe: false,
      id: value3.stanzaId,
      participant: value3.participant
    },
    message: value3.quotedMessage
  };
  return {
    buffer: await downloadMediaMessage(value4, "buffer", {}, {
      logger: undefined
    }),
    quotedMsg: value3.quotedMessage
  };
}
module.exports = [{
  name: "tomp3",
  aliases: ["toaudio", "extractaudio", "mp3"],
  category: "convert",
  description: "Extract audio from a video and send as MP3",
  usage: ".tomp3 (reply to video)",
  async execute(value5, value6, value7, {
    reply: value8,
    react: value9
  }) {
    const value10 = value6.key.remoteJid;
    const value11 = value6.message?.extendedTextMessage?.contextInfo;
    if (!value11?.quotedMessage?.videoMessage) {
      return value8("❌ Reply to a *video* to extract its audio.");
    }
    await value9("🎵");
    try {
      const {
        buffer: value12
      } = await downloadQuoted(value5, value6);
      if (!value12 || !value12.length) {
        throw new Error("Download failed");
      }
      const value13 = await toAudio(value12, "mp4");
      await value5.sendMessage(value10, {
        audio: value13,
        mimetype: "audio/mpeg",
        fileName: "audio.mp3"
      }, {
        quoted: value6
      });
    } catch (error14) {
      value8("❌ Conversion failed: " + error14.message);
    }
  }
}, {
  name: "tovideo",
  aliases: ["stickervideo", "webptomp4", "stickertomp4"],
  category: "convert",
  description: "Convert an animated WebP sticker to an MP4 video",
  usage: ".tovideo (reply to animated sticker)",
  async execute(value15, value16, value17, {
    reply: value18,
    react: value19
  }) {
    const value20 = value16.key.remoteJid;
    const value21 = value16.message?.extendedTextMessage?.contextInfo;
    if (!value21?.quotedMessage?.stickerMessage) {
      return value18("❌ Reply to an *animated sticker* to convert it to video.");
    }
    await value19("🎬");
    try {
      const {
        buffer: value22
      } = await downloadQuoted(value15, value16);
      if (!value22 || !value22.length) {
        throw new Error("Download failed");
      }
      const value23 = await webp2mp4(value22);
      if (!value23 || !value23.length) {
        throw new Error("Conversion returned empty output");
      }
      await value15.sendMessage(value20, {
        video: value23,
        mimetype: "video/mp4",
        fileName: "sticker.mp4"
      }, {
        quoted: value16
      });
    } catch (error24) {
      value18("❌ Conversion failed: " + error24.message);
    }
  }
}];
