const {
  normalizeMessageContent,
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const notes = require("../../utils/notes");
const db = require("../../database");
const WA_MEDIA_TYPES = {
  imageMessage: "image",
  videoMessage: "video",
  documentMessage: "document",
  stickerMessage: "sticker"
};
function extractMedia(value1) {
  const value2 = (value3, value4) => {
    if (!value3) {
      return null;
    }
    for (const [value5, value6] of Object.entries(WA_MEDIA_TYPES)) {
      if (value3[value5]) {
        return {
          kind: value6,
          node: value3[value5],
          mediaMsg: value4
        };
      }
    }
    if (value3.audioMessage) {
      return {
        kind: value3.audioMessage.ptt ? "voice" : "audio",
        node: value3.audioMessage,
        mediaMsg: value4
      };
    }
    return null;
  };
  const value7 = normalizeMessageContent(value1.message);
  const value8 = value2(value7, value1);
  if (value8) {
    return value8;
  }
  const value9 = value7?.extendedTextMessage?.contextInfo;
  const value10 = value9?.quotedMessage;
  if (value10) {
    const value11 = normalizeMessageContent({
      __x: value10
    }.__x ? value10 : {
      conversation: ""
    }) || value10;
    const value12 = value2(value10, {
      key: {
        remoteJid: value1.key.remoteJid,
        id: value9.stanzaId,
        participant: value9.participant,
        fromMe: !value9.participant
      },
      message: value10
    });
    if (value12) {
      return value12;
    }
  }
  return null;
}
module.exports = {
  name: "addnote",
  aliases: ["savenote", "newnote", "diary"],
  description: "Save a personal note (text or media, supports #tags)",
  category: "notes",
  async execute(value13, value14, value15, value16) {
    const value17 = value14.key.remoteJid;
    const value18 = db.getBotSetting("prefix") || ".";
    const value19 = (value15 || []).join(" ").trim();
    try {
      const value20 = extractMedia(value14);
      if (value20) {
        if (value19.length > notes.MAX_TEXT) {
          return value13.sendMessage(value17, {
            text: "❌ Caption too long (max " + notes.MAX_TEXT + " characters)."
          }, {
            quoted: value14
          });
        }
        const value21 = await downloadMediaMessage(value20.mediaMsg, "buffer", {});
        if (!value21 || value21.length === 0) {
          return value13.sendMessage(value17, {
            text: "❌ Could not download the media — try again."
          }, {
            quoted: value14
          });
        }
        const value22 = notes.getUserId(value14);
        const value23 = notes.saveMediaNote({
          userId: value22,
          buffer: value21,
          kind: value20.kind,
          mime: value20.node?.mimetype,
          filename: value20.node?.fileName,
          caption: value19
        });
        if (value23.error) {
          return value13.sendMessage(value17, {
            text: "❌ " + value23.error
          }, {
            quoted: value14
          });
        }
        await value13.sendMessage(value17, {
          react: {
            text: notes.KIND_META[value20.kind].icon,
            key: value14.key
          }
        });
        return value13.sendMessage(value17, {
          text: "┏━━『 ✅ " + notes.KIND_META[value20.kind].label.toUpperCase() + " NOTE SAVED 』━━\n" + ("➥ Note #     ➜ " + value23.index + "\n") + ("➥ Type       ➜ " + notes.KIND_META[value20.kind].icon + " " + notes.KIND_META[value20.kind].label + " (" + (value21.length / 1048576).toFixed(2) + "MB)\n") + (value19 ? "➥ Caption    ➜ " + value19 + "\n" : "") + (value23.note.tags.length ? "➥ Tags       ➜ " + value23.note.tags.join(" ") + "\n" : "") + ("➥ Total Notes ➜ " + value23.index + "\n") + ("➥ View All   ➜ " + value18 + "mynotes · Get ➜ " + value18 + "mynotes get " + value23.index + "\n") + ("➥ Powered By ➜ " + db.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value14
        });
      }
      if (!value19) {
        return value13.sendMessage(value17, {
          text: "┏━━『 📝 ADDNOTE 』━━\n" + ("➥ Usage      ➜ " + value18 + "addnote <your note>\n") + ("➥ Example    ➜ " + value18 + "addnote I will come tomorrow #plans\n") + ("➥ Media      ➜ send/reply media with caption " + value18 + "addnote <caption>\n") + ("➥ View       ➜ " + value18 + "mynotes\n") + ("➥ Powered By ➜ " + db.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value14
        });
      }
      if (value19.length > notes.MAX_TEXT) {
        return value13.sendMessage(value17, {
          text: "❌ Note too long (max " + notes.MAX_TEXT + " characters)."
        }, {
          quoted: value14
        });
      }
      const value24 = notes.getUserId(value14);
      const value25 = notes.loadNotes(value24);
      if (value25.length >= notes.MAX_NOTES) {
        return value13.sendMessage(value17, {
          text: "❌ You already have " + notes.MAX_NOTES + " notes. Delete some via *" + value18 + "mynotes* before adding more."
        }, {
          quoted: value14
        });
      }
      const value26 = {
        id: notes.newId(),
        type: "text",
        text: value19,
        tags: notes.parseTags(value19),
        savedAt: Date.now()
      };
      value25.push(value26);
      notes.saveNotes(value24, value25);
      await value13.sendMessage(value17, {
        react: {
          text: "📝",
          key: value14.key
        }
      });
      return value13.sendMessage(value17, {
        text: "┏━━『 ✅ NOTE SAVED 』━━\n" + ("➥ Note #     ➜ " + value25.length + "\n") + ("➥ Text       ➜ " + value26.text + "\n") + (value26.tags.length ? "➥ Tags       ➜ " + value26.tags.join(" ") + "\n" : "") + ("➥ Total Notes ➜ " + value25.length + "\n") + ("➥ View All   ➜ " + value18 + "mynotes\n") + ("➥ Powered By ➜ " + db.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value14
      });
    } catch (error27) {
      console.error("❌ [ADDNOTE] Error:", error27.message);
      return value13.sendMessage(value17, {
        text: "❌ Failed to save note: " + error27.message
      }, {
        quoted: value14
      });
    }
  }
};
