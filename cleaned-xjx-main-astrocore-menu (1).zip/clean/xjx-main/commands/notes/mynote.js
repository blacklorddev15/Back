const notes = require("../../utils/notes");
const db = require("../../database");
module.exports = {
  name: "mynotes",
  aliases: ["notes", "listnotes", "shownotes", "mydiary"],
  description: "View and manage your saved notes",
  category: "notes",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = db.getBotSetting("prefix") || ".";
    const value7 = notes.getUserId(value2);
    const value8 = notes.loadNotes(value7);
    const value9 = (value3[0] || "").toLowerCase();
    const value10 = value11 => value1.sendMessage(value5, {
      text: value11
    }, {
      quoted: value2
    });
    const value12 = "➥ List      ➜ " + value6 + "mynotes [page]\n" + ("➥ Search    ➜ " + value6 + "mynotes find <word> · Tag ➜ " + value6 + "mynotes #tag\n") + ("➥ Media     ➜ " + value6 + "mynotes get <num>\n") + ("➥ Edit      ➜ " + value6 + "mynotes edit <num> <text>\n") + ("➥ Remind    ➜ " + value6 + "mynotes remind <num> <30m|2h|1d>\n") + ("➥ Delete    ➜ " + value6 + "mynotes del <num> · Clear ➜ " + value6 + "mynotes clear\n") + ("➥ Export    ➜ " + value6 + "mynotes export");
    try {
      if (value9 === "find" || value9 === "search") {
        const value13 = value3.slice(1).join(" ").trim();
        if (!value13) {
          return value10("🔍 *Usage:* " + value6 + "mynotes find <word>");
        }
        const value14 = value8.map((value15, value16) => ({
          n: value15,
          i: value16 + 1
        })).filter(value17 => notes.matchesQuery(value17.n, value13));
        if (!value14.length) {
          return value10("🔍 No notes match *" + value13 + "*.");
        }
        return value1.sendMessage(value5, {
          text: "┏━━『 🔍 FOUND " + value14.length + " 』━━\n" + value14.slice(0, 25).map(value18 => notes.renderLine(value18.n, value18.i)).join("\n") + (value14.length > 25 ? "\n➥ …and " + (value14.length - 25) + " more" : "") + "\n┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value2
        });
      }
      if (value9.startsWith("#")) {
        const value19 = value8.map((value20, value21) => ({
          n: value20,
          i: value21 + 1
        })).filter(value22 => notes.matchesTag(value22.n, value9));
        if (!value19.length) {
          return value10("🏷️ No notes with *" + value9 + "*.");
        }
        return value1.sendMessage(value5, {
          text: "┏━━『 🏷️ " + value9 + " · " + value19.length + " NOTE(S) 』━━\n" + value19.map(value23 => notes.renderLine(value23.n, value23.i)).join("\n") + "\n┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value2
        });
      }
      if (value9 === "get") {
        const value24 = parseInt(value3[1], 10);
        if (!value24 || value24 < 1 || value24 > value8.length) {
          return value10("❌ Invalid number.\n*Usage:* " + value6 + "mynotes get <num>");
        }
        const value25 = value8[value24 - 1];
        if (!value25.type || value25.type === "text") {
          return value10("📝 Note *" + value24 + "* is a text note:\n\n" + notes.noteText(value25));
        }
        const value26 = notes.getMedia(value7, value25);
        if (!value26) {
          return value10("⚠️ The media for note *" + value24 + "* is no longer available (host redeploy may have wiped it). The text notes always survive.");
        }
        await notes.sendMediaByKind(value1, value5, value25, value26);
        return value1.sendMessage(value5, {
          text: "📄 Note *" + value24 + "*" + (value25.caption ? " — " + value25.caption : "")
        }, {
          quoted: value2
        });
      }
      if (value9 === "edit") {
        const value27 = parseInt(value3[1], 10);
        const value28 = value3.slice(2).join(" ").trim();
        if (!value27 || value27 < 1 || value27 > value8.length || !value28) {
          return value10("✏️ *Usage:* " + value6 + "mynotes edit <num> <new text>");
        }
        if (value28.length > notes.MAX_TEXT) {
          return value10("❌ Too long (max " + notes.MAX_TEXT + " characters).");
        }
        const value29 = value8[value27 - 1];
        if (value29.type === "text") {
          value29.text = value28;
        } else {
          value29.caption = value28;
        }
        value29.tags = notes.parseTags(value28);
        notes.saveNotes(value7, value8);
        await value1.sendMessage(value5, {
          react: {
            text: "✏️",
            key: value2.key
          }
        });
        return value1.sendMessage(value5, {
          text: "┏━━『 ✏️ NOTE EDITED 』━━\n" + ("➥ Note    ➜ " + value27 + "\n") + ("➥ New text ➜ " + value28 + "\n") + (value29.tags.length ? "➥ Tags    ➜ " + value29.tags.join(" ") + "\n" : "") + "┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value2
        });
      }
      if (value9 === "remind") {
        const value30 = parseInt(value3[1], 10);
        const value31 = notes.parseTimeSpec(value3[2]);
        if (!value30 || value30 < 1 || value30 > value8.length || !value31) {
          return value10("⏰ *Usage:* " + value6 + "mynotes remind <num> <30m|2h|1d>");
        }
        const value32 = value8[value30 - 1];
        const value33 = notes.addReminder({
          userId: value7,
          userJid: value7 + "@s.whatsapp.net",
          noteId: value32.id,
          dueAt: Date.now() + value31,
          noteRef: value32
        });
        return value1.sendMessage(value5, {
          text: "┏━━『 ⏰ REMINDER SET 』━━\n" + ("➥ Note   ➜ " + value30 + " · " + notes.noteIcon(value32) + " " + (notes.noteText(value32) || "(media note)") + "\n") + ("➥ I'll DM you in ➜ " + notes.describeDueAt(value33.dueAt) + "\n") + "┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value2
        });
      }
      if (value9 === "del" || value9 === "delete" || value9 === "rm") {
        const value34 = parseInt(value3[1], 10);
        if (!value34 || value34 < 1 || value34 > value8.length) {
          return value10("❌ Invalid number.\n*Usage:* " + value6 + "mynotes del <number>");
        }
        const value35 = value8.splice(value34 - 1, 1)[0];
        notes.deleteMedia(value7, value35);
        notes.saveNotes(value7, value8);
        await value1.sendMessage(value5, {
          react: {
            text: "🗑️",
            key: value2.key
          }
        });
        return value1.sendMessage(value5, {
          text: "┏━━『 🗑️ NOTE DELETED 』━━\n" + ("➥ Note      ➜ " + notes.noteIcon(value35) + " " + (notes.noteText(value35) || "(" + value35.type + ")") + "\n") + ("➥ Remaining ➜ " + value8.length + "\n") + "┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value2
        });
      }
      if (value9 === "clear" || value9 === "clearall" || value9 === "wipe") {
        if (!value8.length) {
          return value10("📝 You have no notes to clear.");
        }
        const value36 = value8.length;
        notes.deleteAllMedia(value7);
        notes.saveNotes(value7, []);
        await value1.sendMessage(value5, {
          react: {
            text: "🧹",
            key: value2.key
          }
        });
        return value1.sendMessage(value5, {
          text: "┏━━『 🧹 NOTES CLEARED 』━━\n➥ Removed ➜ " + value36 + " notes\n┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value2
        });
      }
      if (value9 === "export") {
        if (!value8.length) {
          return value10("📝 You have no notes to export.");
        }
        const value37 = notes.buildExportText(value7, value8);
        return value1.sendMessage(value5, {
          document: Buffer.from(value37, "utf8"),
          mimetype: "text/plain",
          fileName: "my-notes.txt",
          caption: "📝 " + value8.length + " note(s) exported"
        }, {
          quoted: value2
        });
      }
      if (!value8.length) {
        return value1.sendMessage(value5, {
          text: "┏━━『 📝 MY NOTES 』━━\n➥ You have no saved notes.\n" + ("➥ Add one ➜ " + value6 + "addnote <text> (or send media with a caption)\n") + "┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value2
        });
      }
      const value38 = parseInt(value3[0], 10) || 1;
      const {
        slice: value39,
        page: value40,
        pages: value41,
        total: value42
      } = notes.paginate(value8, value38);
      const value43 = (value40 - 1) * notes.PAGE_SIZE;
      const value44 = value8.filter(value45 => value45.type && value45.type !== "text").length;
      return value1.sendMessage(value5, {
        text: "┏━━『 📝 MY NOTES 』━━\n" + ("➥ Total ➜ " + value42 + (value44 ? " (" + value44 + " media)" : "") + " · Page " + value40 + "/" + value41 + "\n") + value39.map((value46, value47) => notes.renderLine(value46, value43 + value47 + 1)).join("\n") + "\n" + ("➥ " + value12 + "\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value2
      });
    } catch (error48) {
      console.error("❌ [MYNOTES] Error:", error48.message);
      return value10("❌ Failed to load notes: " + error48.message);
    }
  }
};
