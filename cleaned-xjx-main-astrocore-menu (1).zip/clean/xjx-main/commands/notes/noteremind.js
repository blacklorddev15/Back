const notes = require("../../utils/notes");
const db = require("../../database");
module.exports = {
  name: "note-remind",
  aliases: ["noteremind", "remind-note", "diaryremind"],
  description: "Save a note and get a DM reminder (e.g. .note-remind 30m Call mum)",
  category: "notes",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = db.getBotSetting("prefix") || ".";
    try {
      const value7 = notes.parseTimeSpec(value3[0]);
      const value8 = value3.slice(1).join(" ").trim();
      if (!value7 || !value8) {
        return value1.sendMessage(value5, {
          text: "┏━━『 ⏰ NOTE-REMIND 』━━\n" + ("➥ Usage   ➜ " + value6 + "note-remind <time> <note>\n") + "➥ Time    ➜ 30s · 30m · 2h · 1d (plain number = minutes)\n" + ("➥ Example ➜ " + value6 + "note-remind 30m Call mum #family\n") + ("➥ On an existing note ➜ " + value6 + "mynotes remind <num> <time>\n") + "┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value2
        });
      }
      if (value8.length > notes.MAX_TEXT) {
        return value1.sendMessage(value5, {
          text: "❌ Note too long (max " + notes.MAX_TEXT + " characters)."
        }, {
          quoted: value2
        });
      }
      const value9 = notes.getUserId(value2);
      const value10 = notes.loadNotes(value9);
      if (value10.length >= notes.MAX_NOTES) {
        return value1.sendMessage(value5, {
          text: "❌ You already have " + notes.MAX_NOTES + " notes. Delete some first via *" + value6 + "mynotes*."
        }, {
          quoted: value2
        });
      }
      const value11 = {
        id: notes.newId(),
        type: "text",
        text: value8,
        tags: notes.parseTags(value8),
        savedAt: Date.now()
      };
      value10.push(value11);
      notes.saveNotes(value9, value10);
      const value12 = notes.addReminder({
        userId: value9,
        userJid: value9 + "@s.whatsapp.net",
        noteId: value11.id,
        dueAt: Date.now() + value7,
        noteRef: value11
      });
      await value1.sendMessage(value5, {
        react: {
          text: "⏰",
          key: value2.key
        }
      });
      return value1.sendMessage(value5, {
        text: "┏━━『 ⏰ NOTE + REMINDER SET 』━━\n" + ("➥ Note #   ➜ " + value10.length + "\n") + ("➥ Text     ➜ " + value11.text + "\n") + (value11.tags.length ? "➥ Tags     ➜ " + value11.tags.join(" ") + "\n" : "") + ("➥ I'll DM you in ➜ " + notes.describeDueAt(value12.dueAt) + "\n") + ("➥ View     ➜ " + value6 + "mynotes\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value2
      });
    } catch (error13) {
      console.error("❌ [NOTE-REMIND] Error:", error13.message);
      return value1.sendMessage(value5, {
        text: "❌ Failed to set reminder: " + error13.message
      }, {
        quoted: value2
      });
    }
  }
};
