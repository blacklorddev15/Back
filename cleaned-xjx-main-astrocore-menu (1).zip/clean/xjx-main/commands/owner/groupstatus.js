const crypto = require("crypto");
const {
  generateWAMessageContent,
  generateWAMessageFromContent,
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const {
  PassThrough
} = require("stream");
const ffmpeg = require("fluent-ffmpeg");
const ffmpegPath = require("../../utils/ffmpegPath");
ffmpeg.setFfmpegPath(ffmpegPath);
const PURPLE_COLOR = "#9C27B0";
const SUCCESS_EMOJI = "✅";
module.exports = [{
  name: "groupstatus",
  aliases: ["togstatus", "swgc", "gs", "gstatus"],
  description: "Post replied media or text as a WhatsApp group status.",
  usage: ".groupstatus [caption] [groupJid]",
  category: "owner",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      let value6 = [...(value3 || [])];
      let value7 = null;
      const value8 = value6[value6.length - 1] || "";
      if (value8.endsWith("@g.us")) {
        value7 = value8;
        value6 = value6.slice(0, -1);
      } else if (value4.isGroup) {
        value7 = value5;
      }
      if (!value7) {
        return value4.reply("📝 *Group Status Usage*\n\n*In a group:*\n `.swgc Your text here`\n `.swgc` (reply to image/video/gif/audio/sticker/document/text)\n\n*From private chat:*\n `.swgc Hello everyone <groupJid>`\n `.swgc <groupJid>` (reply to media/text)");
      }
      if (!value7.endsWith("@g.us")) {
        return value4.reply("❌ Group status only works in groups. JID must end with @g.us");
      }
      const value9 = value6.join(" ").trim();
      const value10 = extractContext(value2.message);
      const value11 = value10?.quotedMessage;
      const value12 = !!value11;
      if (!value12) {
        if (!value9) {
          return value4.reply("❌ Provide text or reply to media.");
        }
        try {
          await postGroupStatus(value1, value7, {
            text: value9,
            backgroundColor: PURPLE_COLOR
          });
          return react(value1, value2, value5);
        } catch (error13) {
          console.error("[groupstatus] text error:", error13);
          return value4.reply("❌ Failed to post text status: " + (error13.message || error13));
        }
      }
      const value14 = unwrapMessage(value11);
      if (!value14) {
        return value4.reply("❌ Could not read quoted message.");
      }
      const value15 = {
        key: {
          remoteJid: value5,
          id: value10.stanzaId,
          participant: value10.participant
        },
        message: value14
      };
      const value16 = Object.keys(value14)[0] || "";
      if (/^(conversation|extendedTextMessage)$/i.test(value16)) {
        const value17 = value14.conversation || value14.extendedTextMessage?.text || "";
        const value18 = value9 || value17;
        if (!value18) {
          return value4.reply("❌ Quoted message has no text.");
        }
        await postGroupStatus(value1, value7, {
          text: value18,
          backgroundColor: PURPLE_COLOR
        });
        return react(value1, value2, value5);
      }
      if (/sticker/i.test(value16)) {
        const value19 = await downloadMedia(value15.message, "sticker");
        await postGroupStatus(value1, value7, {
          sticker: value19
        });
        return react(value1, value2, value5);
      }
      if (/^imageMessage$/i.test(value16)) {
        const value20 = await downloadMedia(value15.message, "image");
        await postGroupStatus(value1, value7, {
          image: value20,
          caption: value9 || ""
        });
        return react(value1, value2, value5);
      }
      if (/videoMessage/i.test(value16)) {
        const value21 = await downloadMedia(value15.message, "video");
        const value22 = !!value14.videoMessage?.gifPlayback;
        await postGroupStatus(value1, value7, {
          video: value21,
          caption: value9 || "",
          gifPlayback: value22
        });
        return react(value1, value2, value5);
      }
      if (/documentMessage/i.test(value16)) {
        const value23 = await downloadMedia(value15.message, "document");
        const value24 = value14.documentMessage || {};
        await postGroupStatus(value1, value7, {
          document: value23,
          mimetype: value24.mimetype || "application/octet-stream",
          fileName: value24.fileName || "file",
          caption: value9 || ""
        });
        return react(value1, value2, value5);
      }
      if (/audio/i.test(value16)) {
        const value25 = await downloadMedia(value15.message, "audio");
        const value26 = await toVN(value25).catch(() => value25);
        const value27 = await generateWaveform(value25).catch(() => undefined);
        await postGroupStatus(value1, value7, {
          audio: value26,
          mimetype: "audio/ogg; codecs=opus",
          ptt: true,
          waveform: value27
        });
        return react(value1, value2, value5);
      }
      return value4.reply("❌ Unsupported. Reply to image/video/gif/audio/sticker/document/text.");
    } catch (error28) {
      console.error("[groupstatus] outer:", error28);
      return value4.reply("❌ Error: " + (error28.message || error28));
    }
  }
}];
function parseColor(value29) {
  if (!value29) {
    return undefined;
  }
  if (typeof value29 === "string" && value29.startsWith("#")) {
    const value30 = value29.replace("#", "");
    const value31 = parseInt(value30.length === 6 ? "FF" + value30 : value30, 16);
    return value31;
  }
  if (typeof value29 === "number") {
    return value29;
  }
  return undefined;
}
async function postGroupStatus(value32, value33, value34) {
  const {
    backgroundColor: value35,
    font: value36,
    ...value37
  } = value34;
  const value38 = parseColor(value35);
  const value39 = await generateWAMessageContent(value37, {
    upload: value32.waUploadToServer
  });
  if (value39.extendedTextMessage && value38 !== undefined) {
    value39.extendedTextMessage.backgroundArgb = value38;
    if (value36 !== undefined) {
      value39.extendedTextMessage.font = value36;
    }
  }
  const value40 = crypto.randomBytes(32);
  const value41 = generateWAMessageFromContent(value33, {
    messageContextInfo: {
      messageSecret: value40
    },
    groupStatusMessageV2: {
      message: {
        ...value39,
        messageContextInfo: {
          messageSecret: value40
        }
      }
    }
  }, {
    userJid: value32.user.id
  });
  await value32.relayMessage(value33, value41.message, {
    messageId: value41.key.id
  });
  return value41;
}
function unwrapMessage(value42) {
  let value43 = value42;
  let value44 = 0;
  while (value43 && (value43.ephemeralMessage || value43.viewOnceMessage || value43.viewOnceMessageV2 || value43.viewOnceMessageV2Extension || value43.documentWithCaptionMessage) && value44 < 5) {
    value43 = value43.ephemeralMessage?.message || value43.viewOnceMessage?.message || value43.viewOnceMessageV2?.message || value43.viewOnceMessageV2Extension?.message || value43.documentWithCaptionMessage?.message;
    value44++;
  }
  return value43;
}
function extractContext(value45) {
  const value46 = unwrapMessage(value45);
  if (!value46 || typeof value46 !== "object") {
    return null;
  }
  for (const value47 of Object.keys(value46)) {
    const value48 = value46[value47];
    if (value48 && typeof value48 === "object" && value48.contextInfo && value48.contextInfo.quotedMessage) {
      return value48.contextInfo;
    }
  }
  return null;
}
async function react(value49, value50, value51, value52 = SUCCESS_EMOJI) {
  try {
    await value49.sendMessage(value51, {
      react: {
        text: value52,
        key: value50.key
      }
    });
  } catch {}
}
async function downloadMedia(value53, value54) {
  const value55 = value53[value54 + "Message"] || value53;
  const value56 = await downloadContentFromMessage(value55, value54);
  const value57 = [];
  for await (const value58 of value56) {
    value57.push(value58);
  }
  return Buffer.concat(value57);
}
function toVN(value59) {
  return new Promise((value60, value61) => {
    const value62 = new PassThrough();
    const value63 = new PassThrough();
    const value64 = [];
    value62.end(value59);
    ffmpeg(value62).noVideo().audioCodec("libopus").format("ogg").audioChannels(1).audioFrequency(48000).on("error", value61).on("end", () => value60(Buffer.concat(value64))).pipe(value63);
    value63.on("data", value65 => value64.push(value65));
  });
}
function generateWaveform(value66, value67 = 64) {
  return new Promise((value68, value69) => {
    const value70 = new PassThrough();
    value70.end(value66);
    const value71 = new PassThrough();
    const value72 = [];
    value71.on("data", value73 => value72.push(value73));
    ffmpeg(value70).audioChannels(1).audioFrequency(16000).format("s16le").on("error", value69).on("end", () => {
      const value74 = Buffer.concat(value72);
      const value75 = value74.length / 2;
      const value76 = [];
      for (let value77 = 0; value77 < value75; value77++) {
        value76.push(Math.abs(value74.readInt16LE(value77 * 2)) / 32768);
      }
      const value78 = Math.floor(value76.length / value67);
      if (value78 === 0) {
        return value68(undefined);
      }
      const value79 = Array.from({
        length: value67
      }, (value80, value81) => value76.slice(value81 * value78, (value81 + 1) * value78).reduce((value82, value83) => value82 + value83, 0) / value78);
      const value84 = Math.max(...value79);
      if (value84 === 0) {
        return value68(undefined);
      }
      value68(Buffer.from(value79.map(value85 => Math.floor(value85 / value84 * 100))).toString("base64"));
    }).pipe(value71);
  });
}
