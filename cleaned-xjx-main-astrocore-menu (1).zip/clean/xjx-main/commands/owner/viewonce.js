const fs = require("fs");
const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const {
  createTempFilePath,
  deleteTempFile
} = require("../../utils/tempManager");
module.exports = {
  name: "viewonce",
  aliases: ["vv", "vv2", "rvo", "readvo", "readviewonce"],
  category: "owner",
  ownerOnly: true,
  description: "Reveal view-once messages — .vv → owner DM | .vv2 → current chat",
  usage: ".vv (reply to a view-once) | .vv2 (reply to display here)",
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    const value6 = value1.user.id.split(":")[0] + "@s.whatsapp.net";
    const value7 = value4.command === "vv2";
    const value8 = value7 ? value5 : value6;
    let value9 = null;
    try {
      const value10 = value2.message?.extendedTextMessage?.contextInfo || value2.message?.stickerMessage?.contextInfo || value2.message?.imageMessage?.contextInfo || value2.message?.videoMessage?.contextInfo || value2.message?.buttonsResponseMessage?.contextInfo || value2.message?.listResponseMessage?.contextInfo;
      if (!value10?.quotedMessage) {
        return await value1.sendMessage(value5, {
          text: value7 ? "🗑️ Reply to a *view-once* message with *.vv2* to reveal it here." : "🗑️ Reply to a *view-once* message with *.vv* to reveal it in your DM."
        }, {
          quoted: value2
        });
      }
      const value11 = value10.quotedMessage;
      const value12 = !!value11.viewOnceMessageV2Extension || !!value11.viewOnceMessageV2 || !!value11.viewOnceMessage || !!value11?.imageMessage?.viewOnce || !!value11?.videoMessage?.viewOnce || !!value11?.audioMessage?.viewOnce;
      if (!value12) {
        return await value1.sendMessage(value5, {
          text: "❌ That is not a view-once message!"
        }, {
          quoted: value2
        });
      }
      let value13 = null;
      let value14 = null;
      if (value11.viewOnceMessageV2Extension?.message) {
        value13 = value11.viewOnceMessageV2Extension.message;
        value14 = Object.keys(value13)[0];
      } else if (value11.viewOnceMessageV2?.message) {
        value13 = value11.viewOnceMessageV2.message;
        value14 = Object.keys(value13)[0];
      } else if (value11.viewOnceMessage?.message) {
        value13 = value11.viewOnceMessage.message;
        value14 = Object.keys(value13)[0];
      } else if (value11.imageMessage?.viewOnce) {
        value13 = {
          imageMessage: value11.imageMessage
        };
        value14 = "imageMessage";
      } else if (value11.videoMessage?.viewOnce) {
        value13 = {
          videoMessage: value11.videoMessage
        };
        value14 = "videoMessage";
      } else if (value11.audioMessage?.viewOnce) {
        value13 = {
          audioMessage: value11.audioMessage
        };
        value14 = "audioMessage";
      }
      if (!value13 || !value14) {
        return await value1.sendMessage(value5, {
          text: "❌ Unsupported view-once message type."
        }, {
          quoted: value2
        });
      }
      const value15 = value14 === "imageMessage" ? "image" : value14 === "videoMessage" ? "video" : "audio";
      const value16 = value14 === "imageMessage" ? "jpg" : value14 === "videoMessage" ? "mp4" : "mp4";
      value9 = createTempFilePath("vv", value16);
      const value17 = fs.createWriteStream(value9);
      const value18 = await downloadContentFromMessage(value13[value14], value15);
      await new Promise((value19, value20) => {
        value18.pipe(value17);
        value17.on("finish", value19);
        value17.on("error", value20);
        value18.on("error", value20);
      });
      const value21 = value13[value14]?.caption || "";
      if (value14 === "imageMessage") {
        await value1.sendMessage(value8, {
          image: {
            url: value9
          },
          caption: value21 || "🖼️ *ViewOnce Image*"
        });
      } else if (value14 === "videoMessage") {
        await value1.sendMessage(value8, {
          video: {
            url: value9
          },
          caption: value21 || "🎬 *ViewOnce Video*",
          mimetype: "video/mp4"
        });
      } else {
        await value1.sendMessage(value8, {
          audio: {
            url: value9
          },
          mimetype: value13[value14]?.mimetype || "audio/mp4",
          ptt: false
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error22) {
      await value1.sendMessage(value5, {
        text: "❌ Failed to reveal view-once: " + (error22.message || "Unknown error")
      }, {
        quoted: value2
      });
    } finally {
      if (value9) {
        deleteTempFile(value9);
      }
    }
  }
};
