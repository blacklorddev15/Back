const database = require("../../database");
const {
  resolvePhone
} = require("../../utils/jidHelper");
async function resolveToPhone(value1, value2) {
  const value3 = await resolvePhone(value1, value2);
  if (value3) {
    return String(value3).replace(/\D/g, "");
  } else {
    return null;
  }
}
module.exports = {
  name: "removesudo",
  aliases: ["delsudo", "removemod", "delmod"],
  category: "owner",
  description: "Remove a sudo (moderator) user, or all at once",
  usage: ".removesudo @user | number | all",
  ownerOnly: true,
  async execute(value4, value5, value6, value7) {
    const {
      from: value8,
      reply: value9,
      react: value10
    } = value7;
    if (value6[0]?.toLowerCase() === "all") {
      const value11 = database.getModerators();
      if (!value11 || value11.length === 0) {
        return value9(" There are no sudo users to remove.");
      }
      for (const value12 of value11) {
        database.removeModerator(value12);
      }
      await value10("🤥");
      return value9("¸ *All sudo users removed.*\n\n*Cleared:* " + value11.length + " user" + (value11.length !== 1 ? "s" : ""));
    }
    const value13 = value5.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const value14 = value5.message?.extendedTextMessage?.contextInfo?.participant;
    let value15 = value13[0] || value14 || null;
    if (!value15 && value6[0]) {
      const value16 = value6[0].replace(/\D/g, "");
      if (value16.length >= 7) {
        value15 = value16 + "@s.whatsapp.net";
      }
    }
    if (!value15) {
      return value9("âŒ *Usage:*\n" + ("  " + database.getBotSetting("prefix") + "removesudo @user\n") + ("  " + database.getBotSetting("prefix") + "removesudo 254712345678\n") + ("  " + database.getBotSetting("prefix") + "removesudo all ” remove every sudo user"));
    }
    let value17 = await resolveToPhone(value4, value15);
    if (!value17) {
      const value18 = value15.split("@")[0].split(":")[0];
      return value9(" Could not resolve LID @" + value18 + " to a phone number.\n\nTry using the phone number directly:\n" + database.getBotSetting("prefix") + "removesudo 254712345678");
    }
    if (!database.isModerator(value17)) {
      return value4.sendMessage(value8, {
        text: " @" + value17 + " is not a sudo user.",
        mentions: [value17 + "@s.whatsapp.net"]
      }, {
        quoted: value5
      });
    }
    database.removeModerator(value17);
    await value10("🚫");
    const value19 = value17 + "@s.whatsapp.net";
    await value4.sendMessage(value8, {
      text: "*@" + value17 + "* has been removed from sudo users.",
      mentions: [value19]
    }, {
      quoted: value5
    });
  }
};
