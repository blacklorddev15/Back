const database = require("../../database");
module.exports = {
  name: "sudolist",
  aliases: ["modlist", "listsudo", "sudos"],
  category: "owner",
  description: "List all sudo (moderator) users",
  usage: ".sudolist",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6
    } = value4;
    const value7 = database.getModerators();
    if (!value7 || value7.length === 0) {
      return value6("📭 No sudo users have been added yet.\n\nUse *.addsudo* to add one.");
    }
    const value8 = value7.map((value9, value10) => value10 + 1 + ". @" + value9).join("\n");
    const value11 = value7.map(value12 => value12 + "@s.whatsapp.net");
    await value1.sendMessage(value5, {
      text: "👑 *Sudo Users (" + value7.length + ")*\n\n" + value8 + "\n\n_These users can run moderator-level commands._",
      mentions: value11
    }, {
      quoted: value2
    });
  }
};
