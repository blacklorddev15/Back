const db = require("../../database");
const HEARTBEAT_MS = 10000;
let _interval = null;
function loadSettings() {
  return {
    enabled: db.getBotSetting("alwaysOnline") || false
  };
}
function saveSettings(value1) {
  db.setBotSetting("alwaysOnline", !!value1.enabled);
}
function startHeartbeat(value2) {
  if (_interval) {
    clearInterval(_interval);
  }
  value2.sendPresenceUpdate("available").catch(() => {});
  _interval = setInterval(() => {
    value2.sendPresenceUpdate("available").catch(() => {});
  }, HEARTBEAT_MS);
}
function stopHeartbeat(value3) {
  if (_interval) {
    clearInterval(_interval);
    _interval = null;
  }
  if (value3) {
    value3.sendPresenceUpdate("unavailable").catch(() => {});
  }
}
module.exports = {
  name: "alwaysonline",
  aliases: ["aol", "onlinealways"],
  category: "owner",
  ownerOnly: true,
  description: "Keep bot presence always online",
  usage: ".alwaysonline on | off",
  loadSettings: loadSettings,
  startHeartbeat: startHeartbeat,
  stopHeartbeat: stopHeartbeat,
  async execute(value4, value5, value6, value7) {
    try {
      const value8 = loadSettings();
      const value9 = value6[0]?.toLowerCase();
      if (!value9) {
        return value7.reply("🟢 *Always Online*\n\n" + ("📌 Status: *" + (value8.enabled ? "ON ✅" : "OFF ❌") + "*\n\n") + "*Commands:*\n  .alwaysonline on\n  .alwaysonline off");
      }
      if (value9 === "on") {
        saveSettings({
          enabled: true
        });
        startHeartbeat(value4);
        return value7.reply("🟢 *Always Online: ON*\n\nBot will now continuously appear online to everyone.");
      }
      if (value9 === "off") {
        saveSettings({
          enabled: false
        });
        stopHeartbeat(value4);
        return value7.reply("⚫ *Always Online: OFF*\n\nBot presence is now normal (goes offline when idle).");
      }
      return value7.reply("⚠️ Use: .alwaysonline on  or  .alwaysonline off");
    } catch (error10) {
      await value7.reply("❌ Error: " + error10.message);
    }
  }
};
