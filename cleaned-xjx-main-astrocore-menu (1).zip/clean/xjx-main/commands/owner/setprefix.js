const db = require("../../database");
module.exports = {
  name: "setprefix",
  aliases: ["prefix"],
  category: "owner",
  description: "Change bot command prefix. Use \"none\" for no prefix.",
  usage: ".setprefix <new prefix | none>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      if (value3.length === 0) {
        const value5 = db.getBotSetting("prefix") || "(none)";
        return value4.reply("📌 Current prefix: " + value5 + "\n\n" + ("Usage: " + (db.getBotSetting("prefix") || "") + "setprefix <new prefix>\n") + ("Use *" + (db.getBotSetting("prefix") || "") + "setprefix none* to remove the prefix."));
      }
      const value6 = value3[0].toLowerCase();
      const value7 = value6 === "none" ? "" : value3[0];
      if (value7.length > 3) {
        return value4.reply("❌ Prefix must be 1-3 characters long!");
      }
      db.setBotSetting("prefix", value7);
      db.setBotSetting("prefix", value7);
      if (value7 === "") {
        await value4.reply("✅ Prefix removed! Commands now work without a prefix.\n\nExample: menu, ping, help");
      } else {
        await value4.reply("✅ Prefix changed to: " + value7 + "\n\nNew command format: " + value7 + "command");
      }
    } catch (error8) {
      await value4.reply("❌ Error: " + error8.message);
    }
  }
};
