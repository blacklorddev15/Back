const {
  getCurrentFont,
  setCurrentFont,
  getFontList,
  FONTS,
  applyFont
} = require("../../utils/fontConverter");
module.exports = {
  name: "setfont",
  aliases: ["font", "botfont"],
  category: "owner",
  description: "Set bot reply font style (20 styles). Does not affect links or @mentions.",
  usage: ".setfont <font name> or .setfont list",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = getFontList();
      if (!value3.length || value3[0].toLowerCase() === "list") {
        const value6 = getCurrentFont();
        let value7 = "🖋️ *Bot Font Styles*\n━━━━━━━━━━━━━━━\n\n";
        value7 += "Current: *" + value6 + "*\n\n";
        value5.forEach((value8, value9) => {
          const value10 = applyFontPreview(value8, "Hello");
          const value11 = value8 === value6 ? " ✅" : "";
          value7 += "*" + (value9 + 1) + ".* " + value8 + " — " + value10 + value11 + "\n";
        });
        value7 += "\n━━━━━━━━━━━━━━━\nUsage: *" + (value4.prefix || ".") + "setfont <name>*\nExample: *" + (value4.prefix || ".") + "setfont gothic*\nUse *" + (value4.prefix || ".") + "setfont normal* to reset.";
        return value4.reply(value7);
      }
      let value12 = value3[0].toLowerCase();
      if (/^\d+$/.test(value12)) {
        const value13 = parseInt(value12) - 1;
        if (value13 >= 0 && value13 < value5.length) {
          value12 = value5[value13];
        } else {
          return value4.reply("❌ Pick a number between 1 and " + value5.length + ".");
        }
      }
      if (!FONTS[value12]) {
        return value4.reply("❌ Font \"" + value12 + "\" not found.\n\nUse *" + (value4.prefix || ".") + "setfont list* to see all available fonts.");
      }
      setCurrentFont(value12);
      const value14 = applyFontPreview(value12, "Bot font has been updated!");
      await value4.reply("✅ Font set to *" + value12 + "*\n\nPreview: " + value14);
    } catch (error15) {
      await value4.reply("❌ Error: " + error15.message);
    }
  }
};
function applyFontPreview(value16, value17) {
  if (value16 === "normal" || !FONTS[value16]) {
    return value17;
  }
  const value18 = FONTS[value16];
  const value19 = "abcdefghijklmnopqrstuvwxyz";
  const value20 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const value21 = "0123456789";
  let value22 = "";
  for (const value23 of value17) {
    const value24 = value19.indexOf(value23);
    if (value24 !== -1) {
      value22 += [...value18.lower][value24] || value23;
      continue;
    }
    const value25 = value20.indexOf(value23);
    if (value25 !== -1) {
      value22 += [...value18.upper][value25] || value23;
      continue;
    }
    const value26 = value21.indexOf(value23);
    if (value26 !== -1) {
      value22 += [...value18.digits][value26] || value23;
      continue;
    }
    value22 += value23;
  }
  return value22;
}
