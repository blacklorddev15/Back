const db = require("../../database");
const KEY = "autoReadMode";
const MODES = ["off", "pm", "gc", "all", "contacts"];
const LABELS = {
  off: "❌ Auto-read: off",
  pm: "📩 Auto-read: pm",
  gc: "💬 Auto-read: gc",
  all: "✅ Auto-read: all",
  contacts: "👥 Auto-read: contacts"
};
const USAGE = "Usage: .autoread <off|pm|gc|all|contacts>";
function currentMode() {
  const value1 = db.getBotSetting(KEY);
  if (MODES.includes(value1)) {
    return value1;
  } else {
    return "off";
  }
}
function isPrivateJid(value2) {
  return value2.endsWith("@s.whatsapp.net") || value2.endsWith("@lid");
}
function isGroupJid(value3) {
  return value3.endsWith("@g.us");
}
function shouldAutoRead(value4, value5, value6 = () => true) {
  if (!["all", "contacts", "pm", "gc"].includes(value4)) {
    return false;
  }
  if (!value5 || !value5.key || !value5.key.remoteJid) {
    return false;
  }
  const value7 = String(value5.key.remoteJid);
  if (value5.key.fromMe) {
    return false;
  }
  if (value7 === "status@broadcast") {
    return false;
  }
  if (value7.endsWith("@newsletter")) {
    return false;
  }
  if (value7.endsWith("@broadcast")) {
    return false;
  }
  const value8 = isPrivateJid(value7);
  const value9 = isGroupJid(value7);
  if (value4 === "pm") {
    return value8;
  }
  if (value4 === "gc") {
    return value9;
  }
  if (value4 === "all") {
    return value8 || value9;
  }
  const value10 = value9 ? value5.key.participantAlt || value5.key.participant || null : value5.key.remoteJidAlt || value7;
  if (!value10) {
    return false;
  }
  return Boolean(value6(value10));
}
async function readMessageIfEnabled(value11, value12) {
  try {
    const value13 = currentMode();
    if (value13 === "off") {
      return false;
    }
    const value14 = value11?.contacts || {};
    const value15 = value16 => {
      const value17 = String(value16 || "").split(":")[0];
      if (value14[value17] || value14[value16]) {
        return true;
      }
      const value18 = value11?.signalRepository?.lidMapping;
      if (value18 && value17.endsWith("@lid")) {
        try {
          const value19 = value18.getPNForLID(value17);
          if (value19 && (value14[value19] || value14[String(value19).split(":")[0]])) {
            return true;
          }
        } catch (error20) {}
      }
      return false;
    };
    if (!shouldAutoRead(value13, value12, value15)) {
      return false;
    }
    await value11.readMessages([value12.key]);
    return true;
  } catch (error21) {
    return false;
  }
}
module.exports = {
  name: "autoread",
  aliases: ["read", "autoreadmsgs"],
  category: "owner",
  description: "Auto-read incoming messages (off / pm / gc / all / contacts)",
  usage: ".autoread <off | pm | gc | all | contacts>",
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(value22, value23, value24, value25) {
    try {
      const value26 = (value24[0] || "").toLowerCase();
      if (!value26) {
        return value25.reply(LABELS[currentMode()] + "\n" + USAGE);
      }
      if (!MODES.includes(value26)) {
        return value25.reply(USAGE);
      }
      db.setBotSetting(KEY, value26);
      if (value25.react) {
        await value25.react(value26 === "off" ? "❌" : "✅").catch(() => {});
      }
      return value25.reply(LABELS[value26]);
    } catch (error27) {
      console.error("[autoread]", error27.message);
      if (value25.react) {
        await value25.react("❌").catch(() => {});
      }
      return value25.reply("❌ " + error27.message);
    }
  },
  shouldAutoRead: shouldAutoRead,
  readMessageIfEnabled: readMessageIfEnabled,
  currentMode: currentMode
};
