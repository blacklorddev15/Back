'use strict';

const database = require("../../database");
const MENU_STYLES = {
  "1": "Document with thumbnail ad reply",
  "2": "Simple text reply",
  "3": "Text with external ad reply",
  "4": "Image with caption",
  "5": "Interactive native flow message",
  "6": "Payment request style"
};
const DISPLAY_OPTIONS = {
  memory: {
    key: "showMemory",
    label: "Memory usage"
  },
  uptime: {
    key: "showUptime",
    label: "Uptime"
  },
  plugins: {
    key: "showPluginCount",
    label: "Command count"
  },
  progress: {
    key: "showProgressBar",
    label: "RAM progress bar"
  }
};
Object.assign(DISPLAY_OPTIONS, {
  menumemory: DISPLAY_OPTIONS.memory,
  menuuptime: DISPLAY_OPTIONS.uptime,
  menucommands: DISPLAY_OPTIONS.plugins,
  commands: DISPLAY_OPTIONS.plugins,
  menuprogress: DISPLAY_OPTIONS.progress,
  ram: DISPLAY_OPTIONS.progress
});
const flag = value1 => value1 ? "✅ ON" : "❌ OFF";
function box(value2) {
  let value3 = "╭━━『 *Menu Style Settings* 』━━╮\n\n";
  value3 += value2.join("\n");
  value3 += "\n\n╰━━━━━━━━━━━━━━━━━━━━━━━╯";
  return value3;
}
function settingsLines(value4) {
  return ["📌 *Current Style:* " + value4.menuStyle + " — " + MENU_STYLES[value4.menuStyle], "", "*Menu Details:*", "  • Memory: " + flag(value4.showMemory), "  • Uptime: " + flag(value4.showUptime), "  • Commands: " + flag(value4.showPluginCount), "  • Progress Bar: " + flag(value4.showProgressBar)];
}
module.exports = {
  name: "setmenu",
  aliases: ["menustyle", "menuset"],
  category: "owner",
  description: "Set menu style and display details",
  usage: ".setmenu <1-6> | .setmenu <memory|uptime|plugins|progress> [on|off] | .setmenu all <on|off>",
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(value5, value6, value7, value8) {
    try {
      const value9 = String(value7[0] || "").trim().toLowerCase();
      const value10 = String(value7[1] || "").trim().toLowerCase();
      const value11 = database.getBotSetting("prefix") || ".";
      const styleAliases = {
        native: "5",
        nativeflow: "5",
        flow: "5",
        "native-flow": "5"
      };
      const selectedStyle = styleAliases[value9] || value9;
      if (!value9 || value9 === "status") {
        const value12 = database.getMenuSettings();
        const value13 = settingsLines(value12);
        value13.push("", "*Available Styles:*");
        for (const [value14, value15] of Object.entries(MENU_STYLES)) {
          value13.push("  *" + value14 + ".* " + value15 + (value14 === value12.menuStyle ? " ✅" : ""));
        }
        value13.push("", "💡 Style: *" + value11 + "setmenu <1-6>*", "💡 Details: *" + value11 + "setmenu memory on|off*", "💡 Flip one: *" + value11 + "setmenu memory*", "💡 Flip all: *" + value11 + "setmenu all off*", "   Options: memory, uptime, plugins (commands), progress");
        return value8.reply(box(value13));
      }
      if (database.MENU_STYLE_VALUES.includes(selectedStyle)) {
        database.updateMenuSettings({
          menuStyle: selectedStyle
        });
        return value8.reply(box(["✅ *Menu style set to Style " + selectedStyle + "!*", "", "📋 " + MENU_STYLES[selectedStyle], "", "Send *" + value11 + "menu* to preview the new style."]));
      }
      if (value9 === "all") {
        if (!["on", "off"].includes(value10)) {
          return value8.reply(box(["⚠️ Choose *on* or *off*.", "", "Example: *" + value11 + "setmenu all off*"]));
        }
        const value16 = value10 === "on";
        const value17 = {};
        for (const value18 of Object.values(DISPLAY_OPTIONS)) {
          value17[value18.key] = value16;
        }
        database.updateMenuSettings(value17);
        return value8.reply(box(["✅ *All menu details* are now " + flag(value16) + ".", ...settingsLines(database.getMenuSettings()).slice(2), "", "Send *" + value11 + "menu* to preview the change."]));
      }
      const value19 = DISPLAY_OPTIONS[value9];
      if (value19) {
        let value20;
        if (value10 === "on" || value10 === "off") {
          value20 = value10 === "on";
        } else if (!value10 || value10 === "toggle") {
          value20 = !database.getMenuSettings()[value19.key];
        } else {
          return value8.reply(box(["⚠️ Choose *on* or *off* for " + value19.label + ".", "", "Example: *" + value11 + "setmenu " + value9 + " on*", "Or just *" + value11 + "setmenu " + value9 + "* to flip it."]));
        }
        database.updateMenuSettings({
          [value19.key]: value20
        });
        return value8.reply(box(["✅ *" + value19.label + "* is now " + flag(value20) + ".", ...settingsLines(database.getMenuSettings()).slice(2), "", "Send *" + value11 + "menu* to preview the change."]));
      }
      return value8.reply(box(["❌ *Invalid menu setting!*", "", "Choose a style from *1* to *6*, or use one of:", "*memory*, *uptime*, *plugins* (or *commands*), *progress*, *all*"]));
    } catch (error21) {
      console.error("SetMenu command error:", error21);
      await value8.reply(box(["❌ *Failed to update menu settings*", "", error21.message]));
    }
  }
};
