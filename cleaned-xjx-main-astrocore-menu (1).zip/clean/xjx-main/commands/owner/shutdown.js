const {
  shutdownNow
} = require("../../utils/shutdown");
module.exports = {
  name: "shutdown",
  aliases: ["stop", "off", "kill"],
  category: "owner",
  description: "Forces the bot and server to stay offline.",
  ownerOnly: true,
  async execute(value1, value2, value3, {
    from: value4,
    reply: value5
  }) {
    console.log("[ BOT ] Shutdown command received. Triggering Nuclear Shutdown...");
    try {
      await value5("☢️ *Nuclear Shutdown Engaged.* Forcing server offline...");
      await new Promise(value6 => setTimeout(value6, 2000));
    } catch (error7) {
      console.error("Error sending shutdown feedback:", error7);
    }
    await shutdownNow();
  }
};
