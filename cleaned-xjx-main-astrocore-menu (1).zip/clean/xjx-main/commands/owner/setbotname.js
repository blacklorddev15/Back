const db = require("../../database");
const DEFAULT_BOT_NAME = "JuneX-Ultra";
module.exports = {
  name: "setbotname",
  aliases: ["setname", "botname"],
  category: "owner",
  description: "Change bot name (use \"reset\" to restore default)",
  usage: ".setbotname <new name> | .setbotname reset",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      let value5 = "";
      let value6 = false;
      const value7 = (value3[0] || "").toLowerCase();
      if (value7 === "reset" || value7 === "default" || value7 === "restore") {
        value5 = DEFAULT_BOT_NAME;
        value6 = true;
      } else {
        const value8 = value2.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (value8) {
          const value9 = value8.conversation || value8.extendedTextMessage?.text || value8.imageMessage?.caption || value8.videoMessage?.caption || "";
          value5 = value9.trim();
        } else {
          value5 = value3.join(" ").trim();
        }
      }
      if (!value5) {
        return value4.reply("📝 *Set Bot Name*\n\n" + ("Current bot name: *" + db.getBotSetting("botName") + "*\n") + ("Default bot name:  *" + DEFAULT_BOT_NAME + "*\n\n") + "Usage:\n  .setbotname <new name>\n  .setbotname reset    — restore default\n  Or reply to a message with .setbotname");
      }
      if (value5.length > 50) {
        return value4.reply("❌ Bot name must be 50 characters or less!");
      }
      db.setBotSetting("botName", value5);
      db.setBotSetting("botName", value5);
      const value10 = value6 ? "✅ Bot name reset to default: *" + value5 + "*" : "✅ Bot name changed to: *" + value5 + "*";
      await value4.reply(value10 + "\n\nThe new name will be used in menus and other places.");
    } catch (error11) {
      console.error("Setbotname command error:", error11);
      await value4.reply("❌ Error: " + error11.message);
    }
  }
};
