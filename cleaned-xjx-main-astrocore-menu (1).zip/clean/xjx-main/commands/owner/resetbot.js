'use strict';

const database = require("../../database");
const DATA_SCOPE = ["warnings", "moderators", "muted users", "KV store", "antidelete logs", "status-download history", "group stats", "group settings", "user profiles", "chat profiles", "LID map", "runtime telemetry", "bot settings", "sync queue"];
module.exports = {
  name: "resetbot",
  aliases: ["resetdb"],
  category: "owner",
  description: "Wipe the bot database (data only by default; add --session to also log out).",
  usage: ".resetbot confirm [--session]",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = new Set((value3 || []).map(value6 => String(value6).toLowerCase()));
      const value7 = value5.has("confirm");
      const value8 = value5.has("--session") || value5.has("--full") || value5.has("-s");
      const value9 = value5.has("--owner") || value5.has("--full");
      if (!value7) {
        return value4.reply("⚠️ *DATABASE RESET — CONFIRMATION REQUIRED*\n\nThis permanently wipes the bot’s stored data:\n• " + DATA_SCOPE.join("\n• ") + "\n\nKept by default:\n• WhatsApp login session\n• Owner number and name\n\nAdd *--session* to also clear the login (bot must re-pair).\nAdd *--owner* to also clear the owner.\n_(--full does both)_\n\nTo proceed, send: *.resetbot confirm*" + (value8 ? " *--session*" : "") + (value9 ? " *--owner*" : "") + "\n\n🔒 Owner only.");
      }
      await value4.reply("🧹 Wiping database, please wait…");
      const value10 = await database.resetDatabase({
        includeSession: value8,
        includeOwner: value9
      });
      const value11 = ["✅ *Database reset complete*\n", "🗄️ *Local tables cleared:* " + (value10.localCleared ? value10.localCleared.length : 0), "☁️ *Remote mirror cleared:* " + (value10.remote && value10.remote.remoteCleared ? "yes" : "no / not configured")];
      value11.push("");
      value11.push(value10.ownerPreserved ? "👑 *Owner kept* — " + (database.getOwners()[0] || "none") : "👑 *Owner cleared* — the paired account is re-claimed on the next connect.");
      if (value8) {
        value11.push("");
        value11.push("🔑 *Login session cleared locally.*");
        value11.push("☁️ Note: SESSION_ID is still set, so the bot will re-fetch this session from the Session Server on next start. To fully switch accounts, clear SESSION_ID in .env first and re-pair.");
      } else {
        value11.push("");
        value11.push("🔑 Login session kept — bot stays connected.");
      }
      value11.push("\n_Data will not return after a restart._");
      return value4.reply(value11.join("\n"));
    } catch (error12) {
      console.error("ResetBot command error:", error12);
      return value4.reply("❌ Failed to reset database: " + (error12 && error12.message ? error12.message : error12));
    }
  }
};
