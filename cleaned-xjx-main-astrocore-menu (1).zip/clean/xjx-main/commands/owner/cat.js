const fs = require("fs");
const path = require("path");
const ROOT = path.resolve(__dirname, "../../");
module.exports = {
  name: "cat",
  aliases: ["rf", "$", "shell"],
  category: "owner",
  description: "Display the contents of a file",
  usage: ".cat <filename>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    if (!value3 || value3.length === 0) {
      return value4.reply("📄 Usage: *.cat <filename>*\nExample: `.cat package.json`");
    }
    const value6 = value3.join(" ").trim();
    try {
      const value7 = path.resolve(ROOT, value6);
      if (!value7.startsWith(ROOT)) {
        return value4.reply("🚫 Access denied: path is outside the project directory.");
      }
      if (!fs.existsSync(value7)) {
        return value4.reply("❌ File not found: `" + value6 + "`");
      }
      const value8 = fs.statSync(value7);
      if (value8.isDirectory()) {
        const value9 = fs.readdirSync(value7);
        const value10 = value9.map(value11 => {
          const value12 = path.join(value7, value11);
          const value13 = fs.statSync(value12).isDirectory();
          if (value13) {
            return "📁 " + value11 + "/";
          } else {
            return "📄 " + value11;
          }
        }).join("\n");
        const value14 = path.relative(ROOT, value7) || ".";
        return await value1.sendMessage(value5, {
          text: "📂 *Directory: " + value14 + "*\n\n" + (value10 || "(empty)")
        }, {
          quoted: value2
        });
      }
      const value15 = (value8.size / 1024).toFixed(1);
      if (value8.size > 512000) {
        return value4.reply("❌ File too large (" + value15 + " KB). Max allowed is 500 KB.");
      }
      const value16 = fs.readFileSync(value7, "utf8");
      const value17 = path.relative(ROOT, value7);
      const value18 = path.extname(value7).slice(1);
      const value19 = "📄 *" + value17 + "* _(" + value15 + " KB)_";
      const value20 = "```" + value18 + "\n" + value16 + "\n```";
      await value1.sendMessage(value5, {
        text: value19 + "\n\n" + value20
      }, {
        quoted: value2
      });
    } catch (error21) {
      console.error("[cat] error:", error21);
      await value4.reply("🚫 Error: " + error21.message);
    }
  }
};
