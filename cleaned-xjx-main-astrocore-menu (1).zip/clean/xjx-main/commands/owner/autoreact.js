const {
  load,
  save
} = require("../../utils/autoReact");
function extractSingleEmoji(value1) {
  const value2 = String(value1 || "").trim();
  const value3 = [...value2.matchAll(/\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F|\uFE0E)?)*?/gu)].map(value4 => value4[0]).filter(Boolean);
  if (value3.length === 1 && value2.replace(value3[0], "").trim() === "") {
    return value3[0];
  } else {
    return null;
  }
}
function formatStatus(value5) {
  const value6 = value5.randomMode ? ["Reaction: *🎲 Random emojis*", "To use a fixed emoji:", "_.autoreact 🌪️_"] : ["Reaction: *" + value5.fixedEmoji + " Fixed emoji*", "To use random emojis:", "_.autoreact random_"];
  return ["🤖 *AUTO-REACT STATUS*", "━━━━━━━━━━━━", "Status: *" + (value5.enabled ? "ON" : "OFF") + "*", "Source: *" + (value5.mode === "bot" ? "Bot commands only" : "All messages") + "*", "Target: *" + (value5.target === "dms" ? "DMs" : value5.target === "groups" ? "Groups" : "Both") + "*", ...value6, "━━━━━━━━━━━━", "• .autoreact bot | all", "• .autoreact dms | groups | both", "• .autoreact random | off", "• .autoreact <emoji> | status"].join("\n");
}
module.exports = {
  name: "autoreact",
  category: "owner",
  description: "Configure automatic message reactions",
  usage: ".autoreact off | bot | all | dms | groups | both | random | <emoji> | status",
  ownerOnly: true,
  async execute(value7, value8, value9, value10) {
    try {
      const value11 = value9.join(" ").trim();
      const value12 = value11.toLowerCase();
      if (!value11 || value12 === "status") {
        return value10.reply(formatStatus(load()));
      }
      if (value12 === "off") {
        save({
          enabled: false
        });
        return value10.reply("❌ Auto-React disabled.");
      }
      if (value12 === "bot" || value12 === "all") {
        const value13 = save({
          mode: value12,
          enabled: true
        });
        return value10.reply("✅ Auto-React enabled: *" + (value13.mode === "bot" ? "bot commands only" : "all messages") + "*.");
      }
      if (value12 === "dms" || value12 === "groups" || value12 === "both") {
        const value14 = save({
          target: value12,
          enabled: true
        });
        const value15 = value14.target === "dms" ? "DMs" : value14.target === "groups" ? "groups" : "DMs and groups";
        return value10.reply("✅ Auto-React enabled for *" + value15 + "*.");
      }
      if (value12 === "random") {
        save({
          randomMode: true,
          enabled: true
        });
        return value10.reply("✅ Auto-React enabled with random emojis.");
      }
      const value16 = extractSingleEmoji(value11);
      if (value16) {
        save({
          fixedEmoji: value16,
          randomMode: false
        });
        return value10.reply("✅ Fixed Auto-React emoji set to " + value16 + ". Random mode turned OFF.");
      }
      return value10.reply("⚠️ *Auto-React usage*\n\n.autoreact off\n.autoreact bot\n.autoreact all\n.autoreact dms\n.autoreact groups\n.autoreact both\n.autoreact random\n.autoreact <emoji>\n.autoreact status");
    } catch (error17) {
      console.error("[autoreact cmd] error:", error17);
      return value10.reply("❌ Error configuring Auto-React.");
    }
  }
};
