const database = require("../../database");
function parseType(value1) {
  const value2 = String(value1 || "").toLowerCase();
  if (["video", "vid", "v", "cam"].includes(value2)) {
    return "video";
  }
  if (["voice", "audio", "call", "a"].includes(value2)) {
    return "audio";
  }
  return null;
}
function formatInZone(value3, value4) {
  try {
    return new Date(value3 * 1000).toLocaleString("en-GB", {
      timeZone: value4,
      weekday: "short",
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch (error5) {
    return new Date(value3 * 1000).toISOString();
  }
}
function zoneUnix(value6, value7, value8, value9, value10, value11) {
  const value12 = new Intl.DateTimeFormat("en-US", {
    timeZone: value11,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  });
  const value13 = value14 => {
    const value15 = value12.formatToParts(new Date(value14));
    const value16 = value17 => {
      const value18 = value15.find(value19 => value19.type === value17);
      if (value18) {
        return parseInt(value18.value, 10);
      } else {
        return 0;
      }
    };
    return {
      y: value16("year"),
      m: value16("month"),
      d: value16("day"),
      h: value16("hour") % 24,
      mi: value16("minute")
    };
  };
  let value20 = Date.UTC(value6, value7 - 1, value8, value9, value10, 0);
  for (let value21 = 0; value21 < 4; value21++) {
    const value22 = value13(value20);
    const value23 = Date.UTC(value22.y, value22.m - 1, value22.d, value22.h, value22.mi);
    const value24 = Date.UTC(value6, value7 - 1, value8, value9, value10);
    const value25 = value24 - value23;
    if (value25 === 0) {
      break;
    }
    value20 += value25;
  }
  return Math.floor(value20 / 1000);
}
function parseStart(value26, value27) {
  if (!value26.length) {
    return null;
  }
  const value28 = value26.join(" ").trim();
  if (!value28) {
    return null;
  }
  const value29 = new Date();
  const value30 = new Intl.DateTimeFormat("en-CA", {
    timeZone: value27,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(value29);
  const value31 = value32 => parseInt(value30.find(value33 => value33.type === value32).value, 10);
  let value34 = value31("year");
  let value35 = value31("month");
  let value36 = value31("day");
  let value37;
  let value38;
  const value39 = value28.match(/^(\d{4})-(\d{1,2})-(\d{1,2})[ T](\d{1,2}):(\d{2})$/);
  const value40 = value28.match(/^(\d{1,2}):(\d{2})$/);
  if (value39) {
    value34 = +value39[1];
    value35 = +value39[2];
    value36 = +value39[3];
    value37 = +value39[4];
    value38 = +value39[5];
  } else if (value40) {
    value37 = +value40[1];
    value38 = +value40[2];
  } else {
    throw new Error("Time must look like `18:30` or `2026-08-15 19:00`");
  }
  if (value37 > 23 || value38 > 59 || value35 < 1 || value35 > 12 || value36 < 1 || value36 > 31) {
    throw new Error("That date/time is not valid.");
  }
  const value41 = zoneUnix(value34, value35, value36, value37, value38, value27);
  if (value41 * 1000 < Date.now() - 60000) {
    throw new Error("That time is already in the past.");
  }
  return value41;
}
function toCallUrl(value42, value43) {
  if (!value43) {
    return null;
  }
  const value44 = String(value43).trim();
  if (/^https?:\/\//i.test(value44)) {
    return value44;
  }
  const value45 = value42 === "video" ? "video" : "voice";
  return "https://call.whatsapp.com/" + value45 + "/" + value44;
}
module.exports = {
  name: "calllink",
  aliases: ["voicelink", "videocalllink", "wacall"],
  category: "owner",
  description: "Create a WhatsApp voice or video call link",
  usage: ".calllink [voice|video] [HH:MM | YYYY-MM-DD HH:MM]",
  ownerOnly: true,
  async execute(value46, value47, value48, value49) {
    if (typeof value46.createCallLink !== "function") {
      return value49.reply("❌ `createCallLink` is not available on this Baileys build. Need 7.0.0-rc14 or newer.");
    }
    const value50 = [...(value48 || [])];
    let value51 = parseType(value50[0]);
    if (value51) {
      value50.shift();
    } else {
      value51 = "audio";
    }
    const value52 = database.getTimeZone();
    let value53 = null;
    try {
      value53 = parseStart(value50, value52);
    } catch (error54) {
      return value49.reply("📞 *Call Link*\n\n" + error54.message + "\n\nUsage:\n  .calllink\n  .calllink video\n  .calllink voice 18:30\n  .calllink video 2026-08-15 19:00");
    }
    try {
      if (value49.react) {
        await value49.react("📞").catch(() => {});
      }
      const value55 = value53 ? {
        startTime: value53
      } : undefined;
      const value56 = await value46.createCallLink(value51, value55);
      const value57 = toCallUrl(value51, value56);
      if (!value57) {
        throw new Error("WhatsApp did not return a call token.");
      }
      const value58 = value51 === "video" ? "Video" : "Voice";
      let value59 = "┏━━『 CALL LINK 』━━\n\n" + ("➥ Type      ➜ " + value58 + "\n") + ("➥ Link      ➜ " + value57 + "\n");
      if (value53) {
        value59 += "➥ Starts    ➜ " + formatInZone(value53, value52) + "\n";
        value59 += "➥ Timezone  ➜ " + value52 + "\n";
      }
      value59 += "\n┗━━━━━━━━━━━━━━━━";
      let value60 = false;
      try {
        const {
          sendButtons: value61
        } = require("gifted-btns");
        await value61(value46, value49.from, {
          text: value59,
          footer: "> Powered by " + (database.getBotSetting("botName") || "June-X Ultra"),
          buttons: [{
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "📞 Join " + value58 + " Call",
              url: value57
            })
          }, {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
              display_text: "📋 Copy Link",
              copy_code: value57
            })
          }]
        }, {
          quoted: value47
        });
        value60 = true;
      } catch (error62) {}
      if (!value60) {
        await value49.reply(value59);
      }
      if (value49.react) {
        await value49.react("✅").catch(() => {});
      }
    } catch (error63) {
      console.error("[calllink]", error63.message);
      if (value49.react) {
        await value49.react("❌").catch(() => {});
      }
      await value49.reply("❌ Could not create call link: " + error63.message);
    }
  }
};
