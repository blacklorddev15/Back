const {
  runPresenceCommand
} = require("../../utils/presenceSettings");
module.exports = {
  name: "autotyping",
  aliases: ["autotext", "faketyping"],
  category: "owner",
  description: "Show fake typing presence — pm = PM only, gc = groups only, all = both, off = disabled",
  usage: ".autotyping pm|gc|all|off",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    return runPresenceCommand({
      name: "autotyping",
      mode: "typing",
      args: value3,
      extra: value4,
      emoji: "⌨️",
      label: "Auto Typing"
    });
  }
};
