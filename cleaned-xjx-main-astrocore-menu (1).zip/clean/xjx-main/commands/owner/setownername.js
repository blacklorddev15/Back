const fs = require("fs");
const path = require("path");
const database = require("../../database");
module.exports = {
  name: "setownername",
  aliases: ["setowner_name"],
  category: "owner",
  description: "Change the bot owner display name",
  usage: ".setownername <new name>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      let value5 = "";
      const value6 = value2.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (value6) {
        value5 = (value6.conversation || value6.extendedTextMessage?.text || "").trim();
      } else {
        value5 = value3.join(" ").trim();
      }
      if (!value5) {
        const value7 = Array.isArray(database.getOwnerNames()) ? database.getOwnerNames()[0] : database.getOwnerNames();
        return value4.reply("👑 *Set Owner Name*\n\nCurrent: *" + value7 + "*\n\nUsage: " + database.getBotSetting("prefix") + "setownername <new name>");
      }
      if (value5.length > 50) {
        return value4.reply("❌ Owner name must be 50 characters or less!");
      }
      database.setOwnerNames([value5]);
      await value4.reply("✅ Owner name changed to: *" + value5 + "*");
    } catch (error8) {
      await value4.reply("❌ Error: " + error8.message);
    }
  }
};
