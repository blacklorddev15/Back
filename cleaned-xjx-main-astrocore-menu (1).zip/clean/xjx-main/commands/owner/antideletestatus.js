const database = require("../../database");
const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const isEnabled = () => database.isAntideleteStatusEnabled();
const getTimezone = () => database.getTimeZone();
const statusStore = new Map();
const STATUS_JID = "status@broadcast";
const MEDIA_TYPES = {
  imageMessage: "image",
  videoMessage: "video",
  audioMessage: "audio",
  documentMessage: "document"
};
function unwrap(value1) {
  return value1.ephemeralMessage?.message || value1.viewOnceMessageV2Extension?.message || value1.viewOnceMessageV2?.message || value1.viewOnceMessage?.message || value1;
}
function storeStatusMessage(value2) {
  try {
    if (!value2?.key?.id || !value2.message) {
      return;
    }
    if (value2.key.remoteJid !== STATUS_JID) {
      return;
    }
    const value3 = value2.key.participant || value2.key.remoteJid;
    const value4 = unwrap(value2.message);
    const value5 = value4.conversation || value4.extendedTextMessage?.text || value4.imageMessage?.caption || value4.videoMessage?.caption || value4.documentMessage?.caption || null;
    const value6 = Object.keys(MEDIA_TYPES).find(value7 => value4[value7]);
    if (!value5 && !value6) {
      return;
    }
    statusStore.set(value2.key.id, {
      sender: value3,
      timestamp: value2.messageTimestamp,
      type: value6 ? MEDIA_TYPES[value6] : "text",
      mtype: value6 || null,
      inner: value4,
      text: value5 || null
    });
    if (statusStore.size > 200) {
      statusStore.delete(statusStore.keys().next().value);
    }
  } catch (error8) {}
}
function botSelfJid(value9) {
  const value10 = value9.user?.id;
  if (!value10) {
    return null;
  }
  if (value10.includes(":")) {
    return value10.split(":")[0] + "@s.whatsapp.net";
  } else {
    return value10;
  }
}
async function downloadMedia(value11) {
  try {
    const value12 = await downloadContentFromMessage(value11.inner[value11.mtype], value11.type);
    const value13 = [];
    for await (const value14 of value12) {
      value13.push(value14);
    }
    return Buffer.concat(value13);
  } catch {
    return null;
  }
}
async function sendRecoveredStatus(value15, value16, value17) {
  const value18 = (value17.sender || "Unknown").split("@")[0].split(":")[0];
  const value19 = "━━━━━━━━━━━━━━━━━━━━";
  const value20 = String.fromCharCode(8206).repeat(4001);
  const value21 = value17.timestamp ? new Date(value17.timestamp * 1000).toLocaleString("en-GB", {
    hour12: false,
    timeZone: getTimezone(),
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }) : new Date().toLocaleString();
  const value22 = {
    image: "🖼️",
    video: "🎬",
    audio: "🎵",
    document: "📄",
    text: "📝"
  }[value17.type] || "📝";
  const value23 = "🗑️ *DELETED STATUS RECOVERED!*\n" + (value19 + "\n") + ("👤 *From:* @" + value18 + "\n") + ("🕐 *Time:* " + value21 + "\n") + (value22 + " *Type:* " + value17.type + "\n") + (value19 + "\n" + value20 + "\n");
  const value24 = value17.sender ? [value17.sender] : [];
  if (value17.type === "text") {
    await value15.sendMessage(value16, {
      text: value23 + "📝 *Status:*\n" + value17.text + "\n" + value19,
      mentions: value24
    });
    return;
  }
  const value25 = await downloadMedia(value17);
  if (!value25) {
    await value15.sendMessage(value16, {
      text: value23 + "⚠️ _Media expired (CDN link gone)._\n" + value19,
      mentions: value24
    });
    return;
  }
  const value26 = "🗑️ *DELETED STATUS RECOVERED!*\n" + value19 + "\n" + ("👤 *From:* @" + value18 + "\n") + ("🕐 *Time:* " + value21 + "\n") + (value22 + " *Type:* " + value17.type) + (value17.text ? "\n" + value19 + "\n" + value20 + "\n📝 *Caption:*\n" + value17.text : "") + ("\n" + value19);
  if (value17.type === "image") {
    await value15.sendMessage(value16, {
      image: value25,
      caption: value26,
      mentions: value24
    });
  } else if (value17.type === "video") {
    await value15.sendMessage(value16, {
      video: value25,
      caption: value26,
      mentions: value24,
      mimetype: value17.inner?.videoMessage?.mimetype || "video/mp4"
    });
  } else if (value17.type === "audio") {
    const value27 = value17.inner?.audioMessage?.ptt === true;
    await value15.sendMessage(value16, {
      audio: value25,
      ptt: value27,
      mimetype: value17.inner?.audioMessage?.mimetype || "audio/ogg; codecs=opus"
    });
    await value15.sendMessage(value16, {
      text: value23,
      mentions: value24
    });
  } else if (value17.type === "document") {
    await value15.sendMessage(value16, {
      document: value25,
      mimetype: value17.inner?.documentMessage?.mimetype || "application/octet-stream",
      fileName: value17.inner?.documentMessage?.fileName || "status_file",
      caption: value26,
      mentions: value24
    });
  }
}
async function handleStatusDelete(value28, value29) {
  try {
    if (!isEnabled()) {
      return;
    }
    const value30 = botSelfJid(value28);
    if (!value30) {
      return;
    }
    for (const {
      key: value31
    } of value29) {
      const value32 = value31.remoteJid === STATUS_JID;
      const value33 = statusStore.get(value31.id);
      if (!value32 && !value33) {
        continue;
      }
      const value34 = value33 || null;
      if (!value34) {
        continue;
      }
      await sendRecoveredStatus(value28, value30, value34);
      statusStore.delete(value31.id);
    }
  } catch (error35) {
    console.error("[ANTIDELETESTATUS] error:", error35.message);
  }
}
module.exports = {
  name: "antideletestatus",
  aliases: ["antidelstatus", "statusprotect"],
  category: "owner",
  description: "Recover deleted statuses — sends them to bot self-chat",
  usage: ".antideletestatus on | off",
  adminOnly: true,
  storeStatusMessage: storeStatusMessage,
  handleStatusDelete: handleStatusDelete,
  async execute(value36, value37, value38, value39) {
    const {
      reply: value40
    } = value39;
    const value41 = (value38[0] || "").toLowerCase();
    const value42 = isEnabled();
    const value43 = () => value42 ? "✅ ON — deleted statuses → bot self-chat" : "❌ OFF";
    if (!value41) {
      return value40("📸 *Anti-Delete Status*\n━━━━━━━━━━━━━━━\n" + ("📌 Status: *" + value43() + "*\n\n") + "Recovers deleted statuses\n\n*Commands:*\n  .antideletestatus on  — activate\n  .antideletestatus off — deactivate");
    }
    if (value41 === "on") {
      database.setAntideleteStatusEnabled(true);
      return value40("✅ *Anti-Delete Status* activated.");
    }
    if (value41 === "off") {
      database.setAntideleteStatusEnabled(false);
      return value40("❌ *Anti-Delete Status* deactivated.");
    }
    return value40("⚠️ Usage: .antideletestatus on | off");
  }
};
