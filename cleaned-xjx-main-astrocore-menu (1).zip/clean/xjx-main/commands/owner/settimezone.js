const db = require("../../database");
const COMMON_TIMEZONES = ["Africa/Nairobi", "Africa/Lagos", "Africa/Cairo", "Africa/Johannesburg", "Asia/Kolkata", "Asia/Dubai", "Asia/Shanghai", "Asia/Tokyo", "Asia/Jakarta", "Asia/Singapore", "Asia/Manila", "Asia/Karachi", "Asia/Dhaka", "Europe/London", "Europe/Paris", "Europe/Berlin", "Europe/Moscow", "America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles", "America/Sao_Paulo", "Australia/Sydney", "Pacific/Auckland"];
module.exports = {
  name: "settimezone",
  aliases: ["settz", "timezone"],
  category: "owner",
  description: "Set bot timezone for time display",
  usage: ".settimezone <timezone>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      if (!value3.length || value3[0].toLowerCase() === "list") {
        let value5 = "🌍 *Set Timezone*\n\n" + ("🕐 Active now: *" + db.getTimeZone() + "* _(" + db.getTimeZoneSource() + ")_\n") + ("💾 Saved setting: *" + (db.getBotSetting("timezone") || "not set") + "*\n\n");
        value5 += "*Common Timezones:*\n";
        COMMON_TIMEZONES.forEach(value6 => {
          const value7 = value6 === db.getBotSetting("timezone") ? " ✅" : "";
          try {
            const value8 = new Date().toLocaleString("en-US", {
              timeZone: value6,
              hour: "2-digit",
              minute: "2-digit",
              hour12: true
            });
            value5 += "• " + value6 + " — " + value8 + value7 + "\n";
          } catch {
            value5 += "• " + value6 + value7 + "\n";
          }
        });
        value5 += "\nUsage: *" + db.getBotSetting("prefix") + "settimezone Asia/Kolkata*\nOr: *" + db.getBotSetting("prefix") + "settimezone auto* → detect from phone number";
        return value4.reply(value5);
      }
      const value9 = value3.join(" ").trim();
      if (value9.toLowerCase() === "auto") {
        db.setBotSetting("timezone", "auto");
        const value10 = db.getTimeZone();
        const value11 = db.getTimeZoneSource();
        const value12 = value11 === "auto:owner" ? "📱 owner number" : value11 === "auto:paired" ? "📱 paired number" : value11 === "env" ? "🌍 TIMEZONE env" : "📦 bot default";
        return value4.reply("🔄 *Timezone: AUTO*\n\n" + ("🌍 Detected: *" + value10 + "* — from " + value12 + "\n\n") + "_Times follow the phone number's country (owner number first, then the paired number)._\n_Change your number with .setownernumber — the timezone follows instantly, no restart._\n_Lock a fixed zone anytime with .settimezone <zone>._");
      }
      try {
        new Date().toLocaleString("en-US", {
          timeZone: value9
        });
      } catch {
        return value4.reply("❌ Invalid timezone: *" + value9 + "*\n\nUse *" + db.getBotSetting("prefix") + "settimezone list* to see valid options.");
      }
      db.setBotSetting("timezone", value9);
      const value13 = new Date().toLocaleString("en-US", {
        timeZone: value9,
        dateStyle: "full",
        timeStyle: "long"
      });
      await value4.reply("✅ Timezone set to: *" + value9 + "*\n\n🕐 Current time: " + value13);
    } catch (error14) {
      await value4.reply("❌ Error: " + error14.message);
    }
  }
};
