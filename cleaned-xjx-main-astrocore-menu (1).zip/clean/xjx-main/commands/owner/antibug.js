const database = require(require("path").join(global.__CORE__, "database"));
module.exports = {
  name: "antibug",
  aliases: ["bugprotect", "crashprotect"],
  category: "owner",
  description: "Global crash-message protection — blocks WhatsApp bug messages in groups & DMs",
  usage: ".antibug on | off | action delete|warn|kick | status",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6
    } = value4;
    const value7 = (value3[0] || "").toLowerCase();
    const value8 = database.getBotSetting("antibug") ?? false;
    const value9 = database.getBotSetting("antibugAction") || "delete";
    if (!value7 || value7 === "status") {
      return value6("🛡️ *AntiBug* — " + (value8 ? "✅ ON" : "❌ OFF") + " (action: *" + value9 + "*)\n\n" + ("Group: admin → delete+" + value9 + " | not admin → leave\n") + "DM: block sender + notify owner\n\n.antibug on/off\n.antibug action delete|warn|kick");
    }
    if (value7 === "on") {
      database.setBotSetting("antibug", true);
      return value6("🛡️ *AntiBug turned ON*\nAction (groups): *" + value9 + "*");
    }
    if (value7 === "off") {
      database.setBotSetting("antibug", false);
      return value6("🛡️ *AntiBug turned OFF*");
    }
    if (value7 === "action") {
      const value10 = (value3[1] || "").toLowerCase();
      if (!["delete", "warn", "kick"].includes(value10)) {
        return value6("⚠️ Valid actions: delete | warn | kick");
      }
      database.setBotSetting("antibugAction", value10);
      return value6("✅ AntiBug group action set to *" + value10 + "*.");
    }
    return value6("⚠️ Unknown option. Use .antibug for help.");
  }
};
