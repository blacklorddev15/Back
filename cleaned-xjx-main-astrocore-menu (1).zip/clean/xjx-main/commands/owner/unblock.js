const {
  normalizeJidWithLid
} = require("../../utils/jidHelper");
function phoneToJid(value1) {
  const value2 = String(value1).replace(/[\s\-().+,]/g, "").replace(/^0+/, "");
  if (!value2 || value2.length < 7) {
    return null;
  }
  return value2 + "@s.whatsapp.net";
}
function looksLikePhone(value3) {
  return /^[+\d][\d\s\-().]{5,}[,]?$/.test(value3);
}
function toWhatsappNetJid(value4) {
  if (!value4) {
    return null;
  }
  const value5 = normalizeJidWithLid(value4) || value4;
  const value6 = String(value5).split("@")[0].split(":")[0];
  if (!value6) {
    return null;
  }
  return value6 + "@s.whatsapp.net";
}
module.exports = {
  name: "unblock",
  aliases: ["unblockuser"],
  category: "owner",
  description: "Unblock one or more users (mention, reply, or phone number)",
  usage: ".unblock @user | .unblock 254140480956 | reply to a user with .unblock",
  ownerOnly: true,
  async execute(value7, value8, value9, value10) {
    try {
      const value11 = value8.message?.extendedTextMessage?.contextInfo;
      const value12 = new Set();
      for (const value13 of value11?.mentionedJid || []) {
        const value14 = toWhatsappNetJid(value13);
        if (value14) {
          value12.add(value14);
        }
      }
      if (value11?.participant && value11.stanzaId && value11.quotedMessage) {
        const value15 = toWhatsappNetJid(value11.participant);
        if (value15) {
          value12.add(value15);
        }
      }
      for (const value16 of value9) {
        const value17 = value16.replace(/,+$/, "").trim();
        if (looksLikePhone(value17)) {
          const value18 = phoneToJid(value17);
          if (value18) {
            value12.add(value18);
          }
        }
      }
      if (value12.size === 0) {
        return value10.reply("❌ Please mention a user, reply to a user, or provide a phone number.\n\nExamples:\n• `.unblock @user`\n• `.unblock 254140480956`\n• Reply to a user with `.unblock`");
      }
      const value19 = [];
      const value20 = [];
      for (const value21 of value12) {
        try {
          await value7.updateBlockStatus(value21, "unblock");
          value19.push(value21);
        } catch (error22) {
          value20.push({
            jid: value21,
            err: error22.message
          });
        }
      }
      let value23 = "";
      if (value19.length) {
        value23 += "✅ *Unblocked (" + value19.length + "):*\n" + value19.map(value24 => "• @" + value24.split("@")[0]).join("\n");
      }
      if (value20.length) {
        if (value23) {
          value23 += "\n\n";
        }
        value23 += "❌ *Failed (" + value20.length + "):*\n" + value20.map(value25 => "• @" + value25.jid.split("@")[0] + " — " + value25.err).join("\n");
      }
      await value7.sendMessage(value10.from, {
        text: value23,
        mentions: [...value19, ...value20.map(value26 => value26.jid)]
      }, {
        quoted: value8
      });
    } catch (error27) {
      console.error("[unblock] error:", error27);
      await value10.reply("❌ Error: " + error27.message);
    }
  }
};
