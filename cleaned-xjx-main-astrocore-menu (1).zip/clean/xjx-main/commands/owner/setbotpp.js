const fs = require("fs");
const path = require("path");
const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const MAX_FILE_SIZE = 10485760;
module.exports = {
  name: "setbotpp",
  aliases: ["setppbot", "setpp"],
  category: "owner",
  description: "Set bot profile picture from image or sticker",
  usage: ".setbotpp (reply to image or sticker)",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value2.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!value5) {
        return value4.reply("⚠️ Please reply to an image or sticker with the .setbotpp command!");
      }
      const value6 = value5.imageMessage;
      const value7 = value5.stickerMessage;
      if (!value6 && !value7) {
        return value4.reply("❌ The replied message must contain an image or sticker!");
      }
      const value8 = value6 || value7;
      const value9 = getTempDir();
      const value10 = path.join(value9, "profile_" + Date.now() + ".jpg");
      try {
        const value11 = await downloadContentFromMessage(value8, "image");
        let value12 = Buffer.from([]);
        for await (const value13 of value11) {
          value12 = Buffer.concat([value12, value13]);
        }
        if (value12.length > MAX_FILE_SIZE) {
          return value4.reply("❌ File too large: " + (value12.length / 1024 / 1024).toFixed(2) + "MB (max: " + MAX_FILE_SIZE / 1024 / 1024 + "MB)");
        }
        fs.writeFileSync(value10, value12);
        await value1.updateProfilePicture(value1.user.id.split(":")[0] + "@s.whatsapp.net", {
          url: value10
        });
        await value4.reply("✅ Successfully updated bot profile picture!");
      } catch (error14) {
        console.error("setbotpp error:", error14);
        value4.reply("❌ Failed to update profile picture!");
      } finally {
        deleteTempFile(value10);
      }
    } catch (error15) {
      console.error("setbotpp error:", error15);
      value4.reply("❌ Failed to update profile picture!");
    }
  }
};
