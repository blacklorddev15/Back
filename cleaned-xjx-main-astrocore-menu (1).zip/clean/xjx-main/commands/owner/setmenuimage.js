'use strict';

const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const https = require("https");
const http = require("http");
const db = require("../../database");
function applyMenuStyle3() {
  try {
    db.updateMenuSettings({
      menuStyle: "3"
    });
  } catch (error1) {
    console.error("[setmenuimage] Could not auto-set menu style:", error1.message);
  }
}
function downloadFromUrl(value2) {
  return new Promise((value3, value4) => {
    const value5 = value2.startsWith("https") ? https : http;
    value5.get(value2, {
      headers: {
        "User-Agent": "Mozilla/5.0"
      },
      timeout: 15000
    }, value6 => {
      if (value6.statusCode >= 300 && value6.statusCode < 400 && value6.headers.location) {
        return downloadFromUrl(value6.headers.location).then(value3).catch(value4);
      }
      if (value6.statusCode !== 200) {
        return value4(new Error("HTTP " + value6.statusCode));
      }
      const value7 = [];
      value6.on("data", value8 => value7.push(value8));
      value6.on("end", () => value3(Buffer.concat(value7)));
      value6.on("error", value4);
    }).on("error", value4);
  });
}
async function saveImage(value9) {
  if (!Buffer.isBuffer(value9) || value9.length === 0) {
    throw new Error("Image data is empty.");
  }
  let value10 = value9;
  try {
    const value11 = require("jimp");
    const value12 = await value11.read(value9);
    value10 = await value12.quality(90).getBufferAsync(value11.MIME_JPEG);
  } catch (error13) {}
  const value14 = db.setMenuImageData(value10.toString("base64"));
  if (!value14) {
    throw new Error("Could not save the custom menu image to SQLite.");
  }
}
module.exports = {
  name: "setmenuimage",
  aliases: ["setmenuimg", "setbotimage", "setbotimg", "botimage", "menuimage"],
  category: "owner",
  description: "Set the SQLite-backed menu image from an image, URL, or user profile",
  usage: ".setmenuimage (reply to image) | .setmenuimage <url> | .setmenuimage @user | .setmenuimage reset",
  ownerOnly: true,
  async execute(value15, value16, value17, value18) {
    try {
      const value19 = value18.from;
      const value20 = db.getBotSetting("prefix") || ".";
      if (value17[0] && value17[0].toLowerCase() === "reset") {
        db.clearMenuImageData();
        return value18.reply("✅ Custom menu image removed. June X will use a bundled default image.");
      }
      if (value17[0] && /^https?:\/\//i.test(value17[0])) {
        await value18.react("⏳");
        try {
          const value21 = await downloadFromUrl(value17[0]);
          await saveImage(value21);
          applyMenuStyle3();
          await value18.react("✅");
          return value18.reply("✅ Menu image saved to SQLite from URL! Menu style auto-set to Style 3.");
        } catch (error22) {
          return value18.reply("❌ Failed to download image: " + error22.message);
        }
      }
      const value23 = value16.message?.extendedTextMessage?.contextInfo?.mentionedJid;
      if (value23?.length) {
        await value18.react("⏳");
        try {
          const value24 = await value15.profilePictureUrl(value23[0], "image");
          const value25 = await downloadFromUrl(value24);
          await saveImage(value25);
          applyMenuStyle3();
          await value18.react("✅");
          return value18.reply("✅ Menu image saved to SQLite from the mentioned user's profile picture!");
        } catch (error26) {
          return value18.reply("❌ Could not get the mentioned user's profile picture. They may not have one set.");
        }
      }
      const value27 = value16.message?.extendedTextMessage?.contextInfo;
      const value28 = value27?.quotedMessage;
      if (!value28) {
        return value18.reply("📷 *Set Menu Image*\n\n*Methods:*\n" + ("• Reply to an image: *" + value20 + "setmenuimage*\n") + ("• From URL: *" + value20 + "setmenuimage <url>*\n") + ("• From user: *" + value20 + "setmenuimage @user*\n") + ("• Remove: *" + value20 + "setmenuimage reset*"));
      }
      const value29 = value28.imageMessage || value28.stickerMessage;
      if (!value29) {
        return value18.reply("❌ Reply to an *image* or *sticker*.");
      }
      await value18.react("⏳");
      const value30 = {
        key: {
          remoteJid: value19,
          id: value27.stanzaId,
          participant: value27.participant
        },
        message: value28
      };
      const value31 = await downloadMediaMessage(value30, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value15.updateMediaMessage
      });
      if (!value31 || value31.length === 0) {
        return value18.reply("❌ Failed to download the image. Try sending a fresh image and replying to it.");
      }
      await saveImage(value31);
      applyMenuStyle3();
      await value18.react("✅");
      await value18.reply("✅ Menu image saved to SQLite! Menu style auto-set to Style 3.");
    } catch (error32) {
      console.error("setmenuimage error:", error32);
      await value18.reply("❌ Error: " + error32.message);
    }
  }
};
