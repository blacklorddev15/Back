const {
  runMediaDiagnostics,
  formatMediaReport
} = require("../../utils/mediaDiagnostics");
module.exports = {
  name: "dgns",
  category: "owner",
  description: "Run real, capture-only diagnostics for MEDIA-CMD",
  usage: ".dgns MEDIA-CMD",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value3.join(" ").trim().toUpperCase();
    if (value5 !== "MEDIA-CMD") {
      return value4.reply("⚠️ Only `.dgns MEDIA-CMD` is available right now.");
    }
    if (global.__JUNE_MEDIA_DGNS_RUNNING) {
      return value4.reply("⏳ A MEDIA-CMD diagnostic run is already in progress.");
    }
    global.__JUNE_MEDIA_DGNS_RUNNING = true;
    try {
      await value4.reply("🧪 *DGNS — MEDIA-CMD*\nStarting sequential real API/execution checks. This can take several minutes; media output is captured, not sent.");
      const value6 = await runMediaDiagnostics(value2);
      return value4.reply(formatMediaReport(value6));
    } catch (error7) {
      console.error("[DGNS MEDIA-CMD]", error7);
      return value4.reply("❌ MEDIA-CMD diagnostic could not complete: " + (error7.message || error7));
    } finally {
      global.__JUNE_MEDIA_DGNS_RUNNING = false;
    }
  }
};
