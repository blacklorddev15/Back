'use strict';

const {
  downloadMediaMessage,
  normalizeMessageContent,
  jidNormalizedUser
} = require("@whiskeysockets/baileys");
const database = require("../../database");
const FOOTER = "⚡ *Engineered by June_Ultra*";
const ALL_TYPES = [...database.AUTO_DOWNLOAD_STATUS_TYPES];
const DEFAULT_CONFIG = () => ({
  ...database.AUTO_DOWNLOAD_STATUS_DEFAULTS,
  downloadTypes: [...ALL_TYPES],
  excludedContacts: []
});
const manager = {
  config: DEFAULT_CONFIG(),
  loaded: false,
  reload() {
    this.config = database.getAutoDownloadStatusSettings();
    this.loaded = true;
    return this.config;
  },
  ensureLoaded() {
    if (this.loaded) {
      return true;
    }
    try {
      this.reload();
      return true;
    } catch (error1) {
      return false;
    }
  },
  save() {
    if (!this.ensureLoaded()) {
      return false;
    }
    this.config = database.setAutoDownloadStatusSettings(this.config);
    return true;
  },
  inFlight: new Set(),
  claim(value2) {
    if (!value2 || this.inFlight.has(value2) || database.hasStatusBeenDownloaded(value2)) {
      return false;
    }
    this.inFlight.add(value2);
    return true;
  },
  release(value3) {
    this.inFlight.delete(value3);
  },
  mark(value4, value5) {
    return database.markStatusDownloaded(value4, value5);
  },
  addDownload() {
    const value6 = database.incrementStatusDownloadCount();
    this.config.totalDownloaded = value6;
    return value6;
  },
  number(value7) {
    return String(value7 || "").replace(/\D/g, "");
  },
  excluded(value8) {
    const value9 = [value8?.participantPn, value8?.participant, value8?.remoteJidAlt, value8?.remoteJid].map(value10 => this.number(value10)).filter(Boolean);
    return this.config.excludedContacts.some(value11 => value9.includes(this.number(value11)));
  }
};
database.ready.then(() => manager.reload()).catch(() => {});
function getRealNumber(value12) {
  const value13 = manager.number(value12);
  if (value13.length >= 7) {
    return "+" + value13;
  } else {
    return String(value12 || "Unknown").split("@")[0];
  }
}
function getMediaInfo(value14) {
  if (!value14) {
    return null;
  }
  if (value14.imageMessage) {
    return {
      type: "image",
      media: value14.imageMessage,
      caption: value14.imageMessage.caption || ""
    };
  }
  if (value14.videoMessage) {
    return {
      type: "video",
      media: value14.videoMessage,
      caption: value14.videoMessage.caption || ""
    };
  }
  if (value14.audioMessage) {
    return {
      type: "audio",
      media: value14.audioMessage,
      caption: ""
    };
  }
  if (value14.documentMessage) {
    return {
      type: "document",
      media: value14.documentMessage,
      caption: value14.documentMessage.caption || ""
    };
  }
  if (value14.stickerMessage) {
    return {
      type: "sticker",
      media: value14.stickerMessage,
      caption: ""
    };
  }
  return null;
}
function getTextInfo(value15) {
  const value16 = value15?.extendedTextMessage?.text || value15?.conversation;
  if (value16) {
    return {
      type: "text",
      text: value16
    };
  } else {
    return null;
  }
}
function getOwnerJid(value17) {
  const value18 = value17?.user?.id;
  if (value18) {
    return jidNormalizedUser(value18);
  } else {
    return "";
  }
}
function makeCaption(value19, value20, value21, value22, value23) {
  return ["╭─⌈ 📲 *STATUS DOWNLOADED* ⌋", "│ 👤 *From:* " + (value19 ? value19 + " (" + value20 + ")" : value20), value22 ? "│ 💬 *Caption:* " + value22 : "", "│ 📁 *Type:* " + value21, "│ ⏰ *Time:* " + value23, "╰⊷ " + FOOTER].filter(Boolean).join("\n");
}
async function handleAutoDownloadStatus(value24, value25, value26) {
  try {
    if (!manager.ensureLoaded() || !manager.config.enabled || !value26 || value25?.fromMe) {
      return false;
    }
    const value27 = value25?.id;
    if (!value27 || manager.excluded(value25)) {
      return false;
    }
    const value28 = normalizeMessageContent(value26) || value26;
    if (!value28 || value28.protocolMessage || value28.reactionMessage || value28.messageStubType) {
      return false;
    }
    const value29 = getMediaInfo(value28);
    const value30 = getTextInfo(value28);
    const value31 = value29?.type || "text";
    if (!value29 && !value30 || !manager.config.downloadTypes.includes(value31)) {
      return false;
    }
    const value32 = value25.participantPn || value25.remoteJidAlt || value25.participant || value25.remoteJid || "";
    const value33 = manager.number(manager.config.ownerJid || getOwnerJid(value24));
    if (manager.config.skipOwnerStatus && value33 && manager.number(value32) === value33) {
      return false;
    }
    const value34 = manager.config.mode === "private" ? manager.config.ownerJid || getOwnerJid(value24) : manager.config.publicJid;
    if (!value34) {
      return false;
    }
    const value35 = jidNormalizedUser(value34);
    if (!manager.claim(value27)) {
      return false;
    }
    try {
      const value36 = getRealNumber(value32);
      const value37 = makeCaption(value25.pushName || "", value36, value31, value29?.caption, new Date().toLocaleTimeString());
      if (value29) {
        const value38 = {
          ...value29.media
        };
        delete value38.viewOnce;
        const value39 = {
          key: {
            remoteJid: "status@broadcast",
            id: value27,
            participant: value32,
            fromMe: false
          },
          message: {
            [value31 + "Message"]: value38
          }
        };
        const value40 = await Promise.race([downloadMediaMessage(value39, "buffer", {}, {
          logger: {
            level: "silent",
            child: () => ({})
          },
          reuploadRequest: value24.updateMediaMessage
        }), new Promise((value41, value42) => setTimeout(() => value42(new Error("status download timeout")), 20000))]);
        if (!value40?.length) {
          return false;
        }
        const value43 = {};
        if (value31 === "sticker") {
          value43.sticker = value40;
        } else if (value31 === "document") {
          value43.document = value40;
          value43.fileName = value29.media.fileName || "status_" + value27 + ".bin";
          value43.mimetype = value29.media.mimetype || "application/octet-stream";
          value43.caption = value37;
        } else {
          value43[value31] = value40;
          value43.caption = value37;
          if (value29.media.mimetype) {
            value43.mimetype = value29.media.mimetype;
          }
        }
        await value24.sendMessage(value35, value43);
        if (value31 === "sticker") {
          await value24.sendMessage(value35, {
            text: value37
          });
        }
      } else {
        await value24.sendMessage(value35, {
          text: ["╭─⌈ 📲 *STATUS DOWNLOADED* ⌋", "│ 👤 *From:* " + (value25.pushName ? value25.pushName + " (" + value36 + ")" : value36), "│ 📝 *Text:* " + value30.text, "│ ⏰ *Time:* " + new Date().toLocaleTimeString(), "╰⊷ " + FOOTER].join("\n")
        });
      }
      const value44 = manager.mark(value27, {
        senderId: value32,
        mediaType: value31,
        destinationJid: value35,
        downloadedAt: Date.now()
      });
      if (!value44) {
        return false;
      }
      manager.addDownload();
      console.log("[AutoDL-Status] " + value31 + " from " + value36);
      return true;
    } finally {
      manager.release(value27);
    }
  } catch (error45) {
    if (!/timeout|not-authorized/i.test(error45.message || "")) {
      console.error("[AutoDL-Status]", error45.message);
    }
    return false;
  }
}
function reply(value46, value47, value48, value49) {
  return value46.sendMessage(value47, {
    text: value49
  }, {
    quoted: value48
  });
}
function displayLogs(value50 = 10) {
  const value51 = database.getStatusDownloadLogs(value50);
  if (!value51.length) {
    return "No download history yet.";
  }
  return value51.map((value52, value53) => {
    const value54 = new Date(value52.downloadedAt).toLocaleString();
    return value53 + 1 + ". " + value52.mediaType + " — " + getRealNumber(value52.senderId) + "\n   " + value54;
  }).join("\n");
}
async function execute(value55, value56, value57, value58 = {}) {
  const value59 = value58.from || value56.key.remoteJid;
  if (!value58.isOwner && !value58.isSudo) {
    return reply(value55, value59, value56, "❌ Owner only command.");
  }
  if (!manager.ensureLoaded()) {
    return reply(value55, value59, value56, "⏳ Database is still starting. Please try again in a moment.");
  }
  const value60 = String(value57[0] || "").toLowerCase();
  const value61 = String(value57[1] || "").toLowerCase();
  const value62 = jidNormalizedUser(value56.key.participant || value59);
  if (!manager.config.ownerJid) {
    manager.config.ownerJid = value62;
    manager.save();
  }
  if (!value60) {
    const value63 = manager.config;
    return reply(value55, value59, value56, "╭─⌈ 📲 *AUTO-DOWNLOAD STATUS* ⌋\n│\n" + ("│ Status: " + (value63.enabled ? "✅ ON" : "❌ OFF") + "\n") + ("│ Mode: " + (value63.mode === "private" ? "🔒 Private DM" : "🌐 Public (" + (value63.publicJid || "not set") + ")") + "\n") + ("│ Types: " + (value63.downloadTypes.join(", ") || "none") + "\n│ Total: " + (value63.totalDownloaded || 0) + " downloaded\n") + ("│ Skip own status: " + (value63.skipOwnerStatus ? "✅" : "❌") + "\n│\n") + ("├─⊷ " + (value58.prefix || ".") + "ads on/off\n├─⊷ " + (value58.prefix || ".") + "ads private\n") + ("├─⊷ " + (value58.prefix || ".") + "ads public <jid> | here\n├─⊷ " + (value58.prefix || ".") + "ads types [add/remove/all/reset] <type>\n") + ("├─⊷ " + (value58.prefix || ".") + "ads exclude/include <number>\n├─⊷ " + (value58.prefix || ".") + "ads skipown on/off\n") + ("├─⊷ " + (value58.prefix || ".") + "ads stats | logs [limit] | clear\n╰⊷ " + FOOTER));
  }
  if (["on", "enable"].includes(value60)) {
    manager.config.enabled = true;
    manager.save();
    return reply(value55, value59, value56, "✅ *AUTO-DOWNLOAD STATUS ENABLED*");
  }
  if (["off", "disable"].includes(value60)) {
    manager.config.enabled = false;
    manager.save();
    return reply(value55, value59, value56, "❌ *AUTO-DOWNLOAD STATUS DISABLED*");
  }
  if (value60 === "private") {
    manager.config.mode = "private";
    manager.config.ownerJid = value62;
    manager.save();
    return reply(value55, value59, value56, "🔒 *PRIVATE MODE* — statuses will be saved to your DM.");
  }
  if (value60 === "public") {
    if (value61 === "here") {
      manager.config.mode = "public";
      manager.config.publicJid = value59;
      manager.save();
      return reply(value55, value59, value56, "🌐 *PUBLIC MODE* — statuses will be forwarded here.");
    }
    if (!value61 || !value61.endsWith("@g.us") && !value61.endsWith("@s.whatsapp.net")) {
      return reply(value55, value59, value56, "Usage: " + (value58.prefix || ".") + "ads public <groupJid>");
    }
    manager.config.mode = "public";
    manager.config.publicJid = value61;
    manager.save();
    return reply(value55, value59, value56, "🌐 *PUBLIC MODE* — forwarding to " + value61);
  }
  if (value60 === "here") {
    manager.config.mode = "public";
    manager.config.publicJid = value59;
    manager.save();
    return reply(value55, value59, value56, "🌐 *PUBLIC MODE* — statuses will be forwarded here.");
  }
  if (["exclude", "skip", "block"].includes(value60)) {
    const value64 = manager.number(value57[1]);
    if (!value64) {
      return reply(value55, value59, value56, "Usage: " + (value58.prefix || ".") + "ads exclude <number>");
    }
    if (!manager.config.excludedContacts.includes(value64)) {
      manager.config.excludedContacts.push(value64);
      manager.save();
      return reply(value55, value59, value56, "✅ " + value64 + " excluded.");
    }
    return reply(value55, value59, value56, "⚠️ That contact is already excluded.");
  }
  if (["include", "unexclude", "unblock"].includes(value60)) {
    const value65 = manager.number(value57[1]);
    const value66 = manager.config.excludedContacts.indexOf(value65);
    if (value66 === -1) {
      return reply(value55, value59, value56, "⚠️ That contact is not excluded.");
    }
    manager.config.excludedContacts.splice(value66, 1);
    manager.save();
    return reply(value55, value59, value56, "✅ " + value65 + " removed from exclusions.");
  }
  if (value60 === "types") {
    if (!value61) {
      return reply(value55, value59, value56, "Active types: " + (manager.config.downloadTypes.join(", ") || "none") + "\n" + ("Use " + (value58.prefix || ".") + "ads types add/remove/all/reset <type>"));
    }
    if (value61 === "all" || value61 === "reset") {
      manager.config.downloadTypes = [...ALL_TYPES];
    } else if (["add", "remove"].includes(value61)) {
      const value67 = String(value57[2] || "").toLowerCase();
      if (!ALL_TYPES.includes(value67)) {
        return reply(value55, value59, value56, "❌ Choose: " + ALL_TYPES.join(", "));
      }
      if (value61 === "add" && !manager.config.downloadTypes.includes(value67)) {
        manager.config.downloadTypes.push(value67);
      }
      if (value61 === "remove") {
        manager.config.downloadTypes = manager.config.downloadTypes.filter(value68 => value68 !== value67);
      }
    } else {
      return reply(value55, value59, value56, "Usage: " + (value58.prefix || ".") + "ads types add/remove/all/reset <type>");
    }
    manager.save();
    return reply(value55, value59, value56, "✅ Active types: " + (manager.config.downloadTypes.join(", ") || "none"));
  }
  if (value60 === "skipown") {
    if (!["on", "off"].includes(value61)) {
      return reply(value55, value59, value56, "Skip own status: " + (manager.config.skipOwnerStatus ? "ON" : "OFF"));
    }
    manager.config.skipOwnerStatus = value61 === "on";
    manager.save();
    return reply(value55, value59, value56, "✅ Skip own status: " + (manager.config.skipOwnerStatus ? "ON" : "OFF"));
  }
  if (["stats", "status", "info"].includes(value60)) {
    const value69 = manager.config;
    const value70 = database.getStatusDownloadLogs(1).length;
    return reply(value55, value59, value56, "📊 *AUTO-DOWNLOAD STATUS STATS*\n\n" + ("Status: " + (value69.enabled ? "ACTIVE ✅" : "INACTIVE ❌") + "\n") + ("Mode: " + value69.mode + "\nTypes: " + (value69.downloadTypes.join(", ") || "none") + "\n") + ("Total: " + (value69.totalDownloaded || 0) + "\nExcluded: " + value69.excludedContacts.length + "\n") + ("History: " + (value70 ? "available" : "empty")));
  }
  if (value60 === "logs") {
    const value71 = Math.max(1, Math.min(25, Number(value57[1]) || 10));
    return reply(value55, value59, value56, "📜 *AUTO-DOWNLOAD STATUS LOGS*\n\n" + displayLogs(value71));
  }
  if (["clear", "reset"].includes(value60)) {
    const value72 = database.clearStatusDownloadHistory();
    manager.config.totalDownloaded = 0;
    manager.save();
    return reply(value55, value59, value56, "🔄 Download history cleared (" + value72 + " record(s)).");
  }
  return reply(value55, value59, value56, "❌ Unknown option. Use " + (value58.prefix || ".") + "ads for help.");
}
module.exports = {
  name: "autodownloadstatus",
  aliases: ["ads", "autosave", "autostatussave", "autodlstatus"],
  category: "automation",
  description: "Automatically download WhatsApp statuses",
  usage: ".ads on|off|private|public <jid>|stats",
  ownerOnly: true,
  execute: execute,
  handleAutoDownloadStatus: handleAutoDownloadStatus,
  manager: manager
};
