const pinger = require("../../utils/pinger");
const HELP = "📡 *Pinger — keep-alive & uptime watch*\n\n" + ("• `.pinger <url>` — add a site (pinged immediately, then every " + Math.round(pinger.intervalMs() / 60000) + " min)\n") + "• `.pinger list` — show scheduled sites and their status\n• `.pinger stop <url>` — stop pinging a site\n• `.pinger stop all` — stop all pinging\n\n" + ("You get a DM when a site goes down 🔴 or recovers 🟢. Max " + pinger.MAX_TARGETS + " sites.");
function statusLine(value1, value2) {
  if (!value2) {
    return "⚪ " + value1 + "\n   not checked yet";
  }
  const value3 = value2.status === "up" ? "🟢" : "🔴";
  const value4 = value2.status === "up" ? "HTTP " + value2.httpStatus + " · " + value2.latencyMs + " ms" : "" + (value2.error || (value2.httpStatus ? "HTTP " + value2.httpStatus : "no response"));
  return value3 + " " + value1 + "\n   " + value4 + " · checked " + new Date(value2.checkedAt).toLocaleTimeString();
}
module.exports = {
  name: "pinger",
  aliases: ["pingweb", "pingsite"],
  category: "owner",
  description: "Schedule keep-alive pings for a website (owner only)",
  usage: ".pinger <url> | .pinger list | .pinger stop <url|all>",
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(value5, value6, value7, value8) {
    try {
      const value9 = String(value7[0] || "").toLowerCase();
      if (!value7.length || value9 === "list") {
        const value10 = pinger.listTargets();
        const value11 = pinger.getStatusMap();
        if (!value10.length) {
          return value8.reply(HELP + "\n\n_No sites scheduled yet._");
        }
        const value12 = value10.map(value13 => statusLine(value13.url, value11.get(value13.url))).join("\n");
        return value8.reply("📡 *Pinger — " + value10.length + " site" + (value10.length === 1 ? "" : "s") + " scheduled*\n\n" + value12);
      }
      if (value9 === "stop") {
        const value14 = value7.slice(1).join(" ").trim();
        if (!value14) {
          return value8.reply("Usage: `.pinger stop <url>` or `.pinger stop all`");
        }
        if (value8.react) {
          await value8.react("⏳").catch(() => {});
        }
        if (value14.toLowerCase() === "all") {
          const value15 = pinger.clearTargets();
          if (value8.react) {
            await value8.react(value15.cleared ? "✅" : "❌").catch(() => {});
          }
          return value8.reply(value15.cleared ? "✅ All pinger targets removed." : "ℹ️ Nothing was scheduled.");
        }
        const value16 = pinger.validateTargetUrl(value14);
        if (!value16.ok) {
          return value8.reply("❌ " + value16.error);
        }
        const value17 = pinger.removeTarget(value16.url);
        if (value8.react) {
          await value8.react(value17.removed ? "✅" : "❌").catch(() => {});
        }
        return value8.reply(value17.removed ? "✅ Stopped pinging " + value16.url : "ℹ️ " + value16.url + " was not scheduled.");
      }
      const value18 = pinger.validateTargetUrl(value7.join(" "));
      if (!value18.ok) {
        if (value8.react) {
          await value8.react("❌").catch(() => {});
        }
        return value8.reply("❌ " + value18.error + "\n\n" + HELP);
      }
      if (value8.react) {
        await value8.react("⏳").catch(() => {});
      }
      const value19 = pinger.listTargets();
      if (value19.length >= pinger.MAX_TARGETS && !value19.some(value20 => value20.url === value18.url)) {
        if (value8.react) {
          await value8.react("❌").catch(() => {});
        }
        return value8.reply("❌ Limit reached (" + pinger.MAX_TARGETS + " sites). Remove one first: `.pinger stop <url>`");
      }
      const value21 = await pinger.pingOnce(value18.url);
      const value22 = pinger.addTarget(value18.url);
      if (!value22.added && value22.reason === "already-listed") {
        if (value8.react) {
          await value8.react("ℹ️").catch(() => {});
        }
        return value8.reply("ℹ️ " + value18.url + " is already scheduled.\n\n" + statusLine(value18.url, value21));
      }
      if (!value22.added) {
        if (value8.react) {
          await value8.react("❌").catch(() => {});
        }
        return value8.reply("❌ Could not add the site (" + value22.reason + ").");
      }
      if (value8.react) {
        await value8.react("✅").catch(() => {});
      }
      const value23 = value21.status === "up" ? "🟢 Site is up — HTTP " + value21.httpStatus + " · " + value21.latencyMs + " ms" : "🔴 Site is down right now — " + (value21.error || "HTTP " + value21.httpStatus);
      return value8.reply("✅ *Pinger scheduled*\n\n" + value18.url + "\n\n" + value23 + "\n\n⏱️ Pinged every " + Math.round(pinger.intervalMs() / 60000) + " minutes " + ("· I'll DM you when it goes down 🔴 or recovers 🟢\n🗑️ Remove: `.pinger stop " + value18.url + "`"));
    } catch (error24) {
      console.error("[pinger]", error24.message);
      if (value8.react) {
        await value8.react("❌").catch(() => {});
      }
      return value8.reply("❌ Pinger error: " + error24.message);
    }
  }
};
