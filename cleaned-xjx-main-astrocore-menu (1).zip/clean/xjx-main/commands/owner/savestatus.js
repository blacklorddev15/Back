const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const {
  sendButtons
} = require("gifted-btns");
const fs = require("fs");
const path = require("path");
const database = require("../../database");
const HAPPY_EMOJI_RE = /^\s*[\p{Extended_Pictographic}\u200d\ufe0f\u20e3\s]+\s*$/u;
const SAVE_TRIGGERS = [/^\s*(save|send)\s*$/i, /^\s*(hello|hey|hi)\s*$/i, HAPPY_EMOJI_RE];
function isSaveTrigger(value1) {
  if (!value1 || !value1.trim()) {
    return false;
  }
  return SAVE_TRIGGERS.some(value2 => value2.test(value1.trim()));
}
function isHappyEmoji(value3) {
  if (!value3 || !value3.trim()) {
    return false;
  }
  return HAPPY_EMOJI_RE.test(value3.trim());
}
function getBotSelfJid(value4) {
  const value5 = value4?.user?.id;
  if (!value5) {
    return null;
  }
  const value6 = value5.split(":")[0].split("@")[0];
  return value6 + "@s.whatsapp.net";
}
async function downloadStatus(value7) {
  const value8 = value7;
  const value9 = {
    imageMessage: "image",
    videoMessage: "video",
    audioMessage: "audio",
    stickerMessage: "sticker",
    documentMessage: "document"
  };
  for (const [value10, value11] of Object.entries(value9)) {
    if (!value8[value10]) {
      continue;
    }
    try {
      const value12 = await downloadContentFromMessage(value8[value10], value11);
      const value13 = [];
      for await (const value14 of value12) {
        value13.push(value14);
      }
      return {
        buffer: Buffer.concat(value13),
        type: value11,
        mime: value8[value10].mimetype || "",
        caption: value8[value10].caption || "",
        ext: {
          image: ".jpg",
          video: ".mp4",
          audio: ".mp3",
          sticker: ".webp",
          document: ".bin"
        }[value11] || ".bin"
      };
    } catch (error15) {}
  }
  const value16 = value8.conversation || value8.extendedTextMessage?.text || value8.ephemeralMessage?.message?.conversation || "";
  if (value16) {
    return {
      type: "text",
      text: value16
    };
  }
  return null;
}
async function sendSavedStatus(value17, value18, value19, value20) {
  const value21 = "> Powered by " + database.getBotSetting("botName");
  if (!value19) {
    return value17.sendMessage(value18, {
      text: "❌ Could not download status. It may have expired."
    }, {
      quoted: value20
    }).catch(() => {});
  }
  if (value19.type === "text") {
    await sendButtons(value17, value18, {
      text: "💾 *Status Saved!*\n\n📝 *Text:*\n" + value19.text,
      footer: value21,
      buttons: [{
        name: "cta_copy",
        buttonParamsJson: JSON.stringify({
          display_text: "📋 Copy Text",
          copy_code: value19.text
        })
      }]
    }, {
      quoted: value20
    }).catch(() => {});
    return;
  }
  const value22 = value19.caption ? "💾 *Status Saved!*\n\n💬 " + value19.caption : "💾 *Status Saved!*";
  if (value19.type === "image") {
    await value17.sendMessage(value18, {
      image: value19.buffer,
      caption: value22
    }, {
      quoted: value20
    });
  } else if (value19.type === "video") {
    await value17.sendMessage(value18, {
      video: value19.buffer,
      caption: value22,
      gifPlayback: false
    }, {
      quoted: value20
    });
  } else if (value19.type === "audio") {
    await value17.sendMessage(value18, {
      audio: value19.buffer,
      mimetype: value19.mime || "audio/mp4",
      ptt: false
    }, {
      quoted: value20
    });
  } else if (value19.type === "sticker") {
    await value17.sendMessage(value18, {
      sticker: value19.buffer
    }, {
      quoted: value20
    });
  } else {
    await value17.sendMessage(value18, {
      document: value19.buffer,
      mimetype: value19.mime || "application/octet-stream",
      fileName: "status" + value19.ext,
      caption: value22
    }, {
      quoted: value20
    });
  }
}
async function forwardToSelf(value23, value24, value25, value26, value27, value28) {
  if (!value24) {
    return;
  }
  try {
    const value29 = value26.split("@")[0];
    const value30 = value27?.pushName || "+" + value29;
    const value31 = value25 ? value25.type === "text" ? "📝 Text status" : "📎 " + (value25.type.charAt(0).toUpperCase() + value25.type.slice(1)) + " status" : "❓ Unknown";
    await value23.sendMessage(value24, {
      text: "👁️ *Status Reaction Received*\n\n" + ("👤 *From:* " + value30 + " (+" + value29 + ")\n") + (value28 + "\n") + ("📦 *Content:* " + value31 + "\n\n") + "_Forwarding status to your chat..._"
    });
    await sendSavedStatus(value23, value24, value25, null);
  } catch (error32) {}
}
async function handleStatusReply(value33, value34) {
  try {
    const value35 = value34.key.remoteJid || "";
    if (!value35.endsWith("@s.whatsapp.net")) {
      return false;
    }
    const value36 = !!value34.message?.stickerMessage;
    const value37 = value34.message?.extendedTextMessage?.contextInfo || value34.message?.stickerMessage?.contextInfo;
    if (!value37 || value37.remoteJid !== "status@broadcast") {
      return false;
    }
    const value38 = value34.message?.conversation || value34.message?.extendedTextMessage?.text || "";
    if (!value36 && !isSaveTrigger(value38)) {
      return false;
    }
    const value39 = value37.quotedMessage;
    if (!value39) {
      return false;
    }
    await value33.sendMessage(value35, {
      react: {
        text: "💾",
        key: value34.key
      }
    }).catch(() => {});
    const value40 = await downloadStatus(value39);
    const value41 = getBotSelfJid(value33);
    if (value41) {
      const value42 = value36 ? "🎭 *Trigger:* Sticker" : "💌 *Trigger:* " + value38.trim();
      await forwardToSelf(value33, value41, value40, value35, value34, value42);
    }
    return true;
  } catch (error43) {
    return false;
  }
}
module.exports = {
  name: "savestatus",
  aliases: ["save", "savest", "dlstatus"],
  category: "owner",
  description: "Save a WhatsApp status by replying to it — saved copy goes to your own chat only",
  usage: ".savestatus — reply to a forwarded status message",
  ownerOnly: false,
  isSaveTrigger: isSaveTrigger,
  handleStatusReply: handleStatusReply,
  async execute(value44, value45, value46, value47) {
    try {
      const value48 = value47.from;
      const value49 = value45.message?.extendedTextMessage?.contextInfo || value45.message?.stickerMessage?.contextInfo;
      const value50 = value49?.quotedMessage;
      if (!value50) {
        if (value47.forwardToSelf) {
          return;
        }
        return value47.reply("💾 *Save Status*\n\nReply to a status message with:\n" + ("  *" + database.getBotSetting("prefix") + "save* — manual save\n") + "  _Or just reply with:_ save · send · hello · hey · 😊\n\n_Saved copy is sent to your own chat only._");
      }
      await value44.sendMessage(value48, {
        react: {
          text: "💾",
          key: value45.key
        }
      }).catch(() => {});
      const value51 = await downloadStatus(value50);
      const value52 = getBotSelfJid(value44);
      const value53 = value47.triggerLabel || "💾 *Trigger:* Manual save";
      await forwardToSelf(value44, value52, value51, value48, value45, value53);
    } catch (error54) {
      await value47.reply("❌ Failed to save status:\n" + error54.message);
    }
  }
};
