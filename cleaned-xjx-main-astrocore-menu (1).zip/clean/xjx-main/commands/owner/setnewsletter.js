const database = require("../../database");
module.exports = {
  name: "setnewsletter",
  aliases: ["setnl", "setchannel"],
  category: "owner",
  description: "Set or change the newsletter JID for menu forwarding (owner only)",
  usage: ".setnewsletter <newsletter JID>",
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      let value6 = "";
      if (value2.key.remoteJid && value2.key.remoteJid.endsWith("@newsletter")) {
        value6 = value2.key.remoteJid;
      } else if (value2.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
        const value7 = value2.message.extendedTextMessage.contextInfo;
        const value8 = (value9, value10 = 0) => {
          if (value10 > 5 || !value9 || typeof value9 !== "object") {
            return null;
          }
          for (const value11 in value9) {
            const value12 = value9[value11];
            if (typeof value12 === "string" && value12.endsWith("@newsletter")) {
              return value12;
            }
            if (typeof value12 === "object" && value12 !== null) {
              const value13 = value8(value12, value10 + 1);
              if (value13) {
                return value13;
              }
            }
          }
          return null;
        };
        value6 = value8(value7);
        if (!value6) {
          return value4.reply("❌ The replied message is not from a newsletter!\n\nPlease reply to a newsletter message or provide a newsletter JID directly.");
        }
      } else if (value3[0]) {
        value6 = value3[0].trim();
      } else {
        const value14 = database.getBotSetting("newsletterJid") || "Not set";
        return value4.reply("📰 *Newsletter Configuration*\n\n" + ("Current Newsletter JID: `" + value14 + "`\n") + ("Newsletter Name: " + database.getBotSetting("botName") + "\n\n") + "Usage:\n  .setnewsletter <newsletter JID>\n  Or reply to a newsletter message with .setnewsletter\n\nExample: .setnewsletter 120363161513685998@newsletter");
      }
      if (!value6.endsWith("@newsletter")) {
        return value4.reply("❌ Invalid newsletter JID format!\n\nNewsletter JID must end with `@newsletter`\nExample: `120363161513685998@newsletter`");
      }
      database.setBotSetting("newsletterJid", value6);
      await value4.reply("✅ Newsletter JID updated successfully!\n\n" + ("📰 Newsletter JID: `" + value6 + "`\n") + ("📛 Newsletter Name: " + database.getBotSetting("botName") + "\n\n") + "The menu will now forward from this newsletter.");
    } catch (error15) {
      console.error("SetNewsletter command error:", error15);
      await value4.reply("❌ Failed to set newsletter JID: " + error15.message);
    }
  }
};
