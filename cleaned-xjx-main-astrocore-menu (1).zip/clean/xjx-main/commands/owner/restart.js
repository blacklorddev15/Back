module.exports = {
  name: "restart",
  aliases: ["reboot"],
  category: "owner",
  description: "Restart the bot.",
  ownerOnly: true,
  async execute(value1, value2, value3, {
    reply: value4
  }) {
    await value4("🔄 Restarting...");
    setTimeout(() => process.exit(1), 2000);
  }
};
