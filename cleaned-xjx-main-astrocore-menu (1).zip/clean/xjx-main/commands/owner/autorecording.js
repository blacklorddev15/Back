const {
  runPresenceCommand
} = require("../../utils/presenceSettings");
module.exports = {
  name: "autorecording",
  aliases: ["autorecord", "record"],
  category: "owner",
  description: "Show fake audio-recording presence — pm = PM only, gc = groups only, all = both, off = disabled",
  usage: ".autorecording pm|gc|all|off",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    return runPresenceCommand({
      name: "autorecording",
      mode: "recording",
      args: value3,
      extra: value4,
      emoji: "🎙️",
      label: "Auto Recording"
    });
  }
};
