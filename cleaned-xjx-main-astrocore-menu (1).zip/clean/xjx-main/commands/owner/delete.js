module.exports = {
  name: "delete",
  aliases: ["del", "delmsg"],
  category: "owner",
  description: "Delete messages from a replied user or mentioned user",
  usage: ".delete [count] (reply to or mention a user)",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      const value6 = value2.message?.conversation || value2.message?.extendedTextMessage?.text || "";
      const value7 = value6.trim().split(/\s+/);
      let value8 = 1;
      if (value7.length > 1) {
        const value9 = parseInt(value7[1], 10);
        if (!isNaN(value9) && value9 > 0) {
          value8 = Math.min(value9, 50);
        }
      }
      const value10 = value2.message?.extendedTextMessage?.contextInfo || {};
      const value11 = Array.isArray(value10.mentionedJid) && value10.mentionedJid.length > 0 ? value10.mentionedJid[0] : null;
      const value12 = value10.participant || null;
      let value13 = null;
      let value14 = null;
      if (value12 && value10.stanzaId) {
        value13 = value12;
        value14 = value10.stanzaId;
      } else if (value11) {
        value13 = value11;
      } else {
        value13 = value5.endsWith("@g.us") ? null : value5;
      }
      if (!value13) {
        return await value1.sendMessage(value5, {
          text: "⚠️ Please reply to a message or mention a user to delete their recent messages."
        }, {
          quoted: value2
        });
      }
      const value15 = value1.botStore?.messages?.get(value5);
      const value16 = value15 ? [...value15.values()] : [];
      const value17 = [];
      const value18 = new Set();
      if (value2.key?.id) {
        value17.push({
          key: {
            ...value2.key
          }
        });
        value18.add(value2.key.id);
      }
      if (value14) {
        const value19 = value16.find(value20 => value20.key.id === value14 && (value20.key.participant || value20.key.remoteJid) === value13);
        if (value19 && !value18.has(value19.key.id)) {
          value17.push(value19);
          value18.add(value19.key.id);
        } else {
          try {
            await value1.sendMessage(value5, {
              delete: {
                remoteJid: value5,
                fromMe: false,
                id: value14,
                participant: value12
              }
            });
            value8 = Math.max(0, value8 - 1);
          } catch {}
        }
      }
      for (let value21 = value16.length - 1; value21 >= 0 && value17.length < value8 + 1; value21--) {
        const value22 = value16[value21];
        const value23 = value22.key.participant || value22.key.remoteJid;
        if (value23 === value13 && !value18.has(value22.key.id)) {
          if (!value22.message?.protocolMessage) {
            value17.push(value22);
            value18.add(value22.key.id);
          }
        }
      }
      if (value17.length === 0) {
        return await value1.sendMessage(value5, {
          text: "⚠️ No recent messages found for that user."
        }, {
          quoted: value2
        });
      }
      for (const value24 of value17) {
        try {
          const value25 = value24.key.participant || value13;
          await value1.sendMessage(value5, {
            delete: {
              remoteJid: value5,
              fromMe: false,
              id: value24.key.id,
              participant: value25
            }
          });
          await new Promise(value26 => setTimeout(value26, 300));
        } catch {}
      }
    } catch (error27) {
      console.error("Delete command error:", error27);
      await value1.sendMessage(value5, {
        text: "❌ Failed to delete messages."
      }, {
        quoted: value2
      });
    }
  }
};
