'use strict';

const commandToggle = require("../../utils/commandToggle");
function buildStatusLine() {
  const value1 = commandToggle.getAll();
  if (value1.length) {
    return "🚫 *Disabled commands (" + value1.length + "):*\n" + value1.map(value2 => "• " + value2).join("\n");
  } else {
    return "✅ No commands are disabled.";
  }
}
const makeHandler = value3 => async (value4, value5, value6, value7) => {
  try {
    const value8 = (value6[0] || "").toLowerCase().replace(/^\.+/, "").trim();
    if (!value8 || value8 === "list") {
      return value7.reply((value3 ? "✅" : "🚫") + " *Command Toggle*\n\n" + buildStatusLine() + "\n\n*Usage:*\n" + ("  ." + (value3 ? "enable" : "disable") + " <command>\n") + (value3 ? "  .enable all → re-enable everything\n" : "") + "\n_Owner & sudo can always use every command._");
    }
    if (value3 && value8 === "all") {
      const value9 = commandToggle.enableAll();
      return value7.reply(value9 ? "✅ Re-enabled *" + value9 + "* command" + (value9 === 1 ? "" : "s") + "." : "✅ No commands were disabled.");
    }
    const value10 = value7.commands ? value7.commands.get(value8) : null;
    if (value7.commands && !value10) {
      return value7.reply("❓ No command named *" + value8 + "*. Check the spelling (type `.menu` to see all commands).");
    }
    const value11 = String(value10?.name || value8).toLowerCase();
    if (!value3 && commandToggle.isProtected(value11)) {
      return value7.reply("🛡️ *" + value11 + "* can't be disabled — you'd have no way to re-enable it from chat.");
    }
    if (value3) {
      const value12 = commandToggle.isDisabled(value11);
      commandToggle.enable(value11);
      return value7.reply(value12 ? "✅ Command *" + value11 + "* is now *enabled*." : "✅ Command *" + value11 + "* was not disabled — nothing to do.");
    }
    const value13 = commandToggle.isDisabled(value11);
    commandToggle.disable(value11);
    return value7.reply(value13 ? "🚫 Command *" + value11 + "* is already disabled." : "🚫 Command *" + value11 + "* is now *disabled* for everyone except owner/sudo.\nUse `.enable " + value11 + "` to bring it back.");
  } catch (error14) {
    await value7.reply("❌ Error: " + error14.message);
  }
};
module.exports = [{
  name: "disable",
  aliases: ["cmdoff"],
  category: "owner",
  ownerOnly: true,
  description: "Disable a command at runtime (owner/sudo keep access)",
  usage: ".disable <command | list>",
  execute: makeHandler(false)
}, {
  name: "enable",
  aliases: ["cmdon"],
  category: "owner",
  ownerOnly: true,
  description: "Re-enable a disabled command",
  usage: ".enable <command | all | list>",
  execute: makeHandler(true)
}];
