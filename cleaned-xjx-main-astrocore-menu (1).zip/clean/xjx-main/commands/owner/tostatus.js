const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
const STATUS_JID = "status@broadcast";
const BG_COLOURS = ["#000000", "#1a1a2e", "#16213e", "#0f3460", "#533483", "#6b2d8b", "#b5179e", "#d62828", "#e63946", "#2b9348", "#007f5f", "#023e8a"];
function randomBg() {
  return BG_COLOURS[Math.floor(Math.random() * BG_COLOURS.length)];
}
function sleep(value1) {
  return new Promise(value2 => setTimeout(value2, value1));
}
async function extractMedia(value3) {
  const value4 = {
    imageMessage: {
      type: "image",
      ext: ".jpg"
    },
    videoMessage: {
      type: "video",
      ext: ".mp4"
    }
  };
  for (const [value5, {
    type: value6,
    ext: value7
  }] of Object.entries(value4)) {
    if (!value3[value5]) {
      continue;
    }
    try {
      const value8 = await downloadContentFromMessage(value3[value5], value6);
      const value9 = [];
      for await (const value10 of value8) {
        value9.push(value10);
      }
      return {
        buffer: Buffer.concat(value9),
        type: value6,
        ext: value7,
        mime: value3[value5].mimetype || (value6 === "image" ? "image/jpeg" : "video/mp4"),
        caption: value3[value5].caption || ""
      };
    } catch (error11) {}
  }
  return null;
}
function getStatusJidList(value12) {
  const value13 = new Set();
  const value14 = [].concat(database.getOwners() || []);
  for (const value15 of value14) {
    const value16 = String(value15).replace(/\D/g, "");
    if (value16) {
      value13.add(value16 + "@s.whatsapp.net");
    }
  }
  return [...value13];
}
async function waitForUploadToSettle(value17) {
  if (!value17) {
    await sleep(800);
    return;
  }
  const value18 = value17.buffer.length / 1048576;
  const value19 = value17.type === "video" ? 3000 : 1500;
  const value20 = value17.type === "video" ? 700 : 400;
  const value21 = Math.min(value19 + value18 * value20, 15000);
  await sleep(value21);
}
module.exports = {
  name: "tostatus",
  aliases: ["tst", "tostory", "poststatus"],
  category: "owner",
  description: "Post a story to WhatsApp status (owner only)",
  usage: ".tostatus [text]  OR  reply to image/video with .tostatus [caption]",
  ownerOnly: true,
  async execute(value22, value23, value24, value25) {
    try {
      const value26 = value25.from;
      const value27 = "> Powered by " + database.getBotSetting("botName");
      const value28 = value24.join(" ").trim();
      const value29 = value23.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
      const value30 = value23.message;
      let value31 = null;
      if (value29) {
        value31 = await extractMedia(value29).catch(() => null);
      }
      if (!value31) {
        value31 = await extractMedia(value30).catch(() => null);
      }
      if (!value31 && !value28) {
        return value25.reply("📖 *tostatus — Post to WhatsApp Status*\n\n" + ("*Text story:*\n  " + database.getBotSetting("prefix") + "tostatus Hello World!\n\n") + ("*Image story:*\n  Reply to an image with " + database.getBotSetting("prefix") + "tostatus [caption]\n\n") + ("*Video story:*\n  Reply to a video with " + database.getBotSetting("prefix") + "tostatus [caption]\n\n") + ("_Aliases: " + database.getBotSetting("prefix") + "tst · " + database.getBotSetting("prefix") + "tostory · " + database.getBotSetting("prefix") + "poststatus_"));
      }
      let value32;
      let value33;
      if (value31) {
        const value34 = value28 || value31.caption;
        if (value31.type === "image") {
          value32 = {
            image: value31.buffer,
            mimetype: value31.mime || "image/jpeg",
            caption: value34
          };
          value33 = "🖼️ Image";
        } else if (value31.type === "video") {
          value32 = {
            video: value31.buffer,
            mimetype: value31.mime || "video/mp4",
            caption: value34,
            gifPlayback: false
          };
          value33 = "🎬 Video";
        } else {
          return value25.reply("❌ Only images and videos can be posted as a story.");
        }
      } else {
        value32 = {
          text: value28,
          backgroundColor: randomBg(),
          font: 2
        };
        value33 = "📝 Text";
      }
      const value35 = getStatusJidList(value22);
      await value22.sendMessage(value26, {
        react: {
          text: "⏳",
          key: value23.key
        }
      }).catch(() => {});
      await value22.sendMessage(STATUS_JID, value32, {
        statusJidList: value35,
        backgroundColor: value32.backgroundColor,
        font: value32.font
      });
      await waitForUploadToSettle(value31);
      await value22.sendMessage(value26, {
        react: {
          text: "✅",
          key: value23.key
        }
      }).catch(() => {});
      let value36 = "✅ *Story Posted to Status!*\n\n" + ("📋 *Type:* " + value33 + "\n");
      const value37 = value28 || value31?.caption || "";
      if (value37) {
        value36 += "💬 *Caption:* " + value37 + "\n";
      }
      value36 += "⏱️ *Upload:* fully settled before confirming";
      await sendButtons(value22, value26, {
        text: value36,
        footer: value27,
        buttons: [{
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "📸 Open WhatsApp",
            url: "https://wa.me/"
          })
        }]
      }, {
        quoted: value23
      });
    } catch (error38) {
      console.error("[tostatus] error:", error38);
      await value22.sendMessage(value25.from, {
        react: {
          text: "❌",
          key: value23.key
        }
      }).catch(() => {});
      await value25.reply("❌ Failed to post story:\n" + error38.message);
    }
  }
};
