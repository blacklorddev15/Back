const {
  loadSettings,
  saveSettings
} = require("../../database");
module.exports = {
  name: "autostatusview",
  aliases: ["asv", "viewstatus", "statusview"],
  category: "owner",
  description: "Auto-view WhatsApp statuses",
  usage: ".autostatusview <on/off/get>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = loadSettings();
      const value6 = (value3[0] || "").toLowerCase();
      if (!value6) {
        return value4.reply("👁️ *AUTO STATUS VIEW*\n━━━━━━━━━━━━\n" + ("STATUS: " + (value5.enabled ? "🟢 ON" : "🔴 OFF") + "\n━━━━━━━━━━━━\n") + " ✧ autostatusview on\n ✧ autostatusview off\n ✧ autostatusview get");
      }
      if (value6 === "on") {
        value5.enabled = true;
        saveSettings(value5);
        return value4.reply("👁️ *Auto Status View turned ON*");
      }
      if (value6 === "off") {
        value5.enabled = false;
        saveSettings(value5);
        return value4.reply("👁️ *Auto Status View turned OFF*");
      }
      if (value6 === "get") {
        return value4.reply("📌 View: *" + (value5.enabled ? "ON" : "OFF") + "*");
      }
      return value4.reply("⚠️ Use .autostatusview <on/off/get>");
    } catch (error7) {
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
