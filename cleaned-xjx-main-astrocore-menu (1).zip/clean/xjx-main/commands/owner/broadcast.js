module.exports = {
  name: "broadcast",
  aliases: ["bc"],
  category: "owner",
  description: "Broadcast message to all chats",
  usage: ".broadcast <message>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      if (value3.length === 0) {
        return value4.reply("❌ Usage: .broadcast <message>\n\nExample: .broadcast Hello everyone!");
      }
      const value5 = value3.join(" ");
      const value6 = await value1.groupFetchAllParticipating();
      const value7 = Object.values(value6);
      let value8 = 0;
      let value9 = 0;
      for (const value10 of value7) {
        try {
          await value1.sendMessage(value10.id, {
            text: "\n" + value5 + "\n\n> ©June"
          });
          value8++;
        } catch (error11) {
          value9++;
        }
      }
      await value4.reply("✅ Broadcast complete!\n\n✅ Success: " + value8 + "\n❌ Failed: " + value9);
    } catch (error12) {
      await value4.reply("❌ Error: " + error12.message);
    }
  }
};
