const db = require("../../database");
const KEY = "readReceipts";
function loadConfig() {
  return {
    readReceipts: db.getBotSetting(KEY) || "off"
  };
}
function saveConfig(value1) {
  db.setBotSetting(KEY, value1.readReceipts || "off");
}
const PRIVACY_MAP = {
  off: "all",
  on: "none",
  contacts: "contacts"
};
const STATUS_LABEL = {
  off: "🔵 OFF (default) — Everyone sees blue ticks",
  on: "⚪ ON — Grey ticks (receipts hidden from everyone)",
  contacts: "👥 CONTACTS — Only contacts see blue ticks"
};
module.exports = {
  name: "readreceipts",
  aliases: ["rr", "bluemark", "bluetick", "readreceipt"],
  category: "owner",
  description: "Toggle read receipts — off = blue ticks (default), on = grey ticks",
  usage: ".readreceipts <off | on | contacts>",
  ownerOnly: true,
  async execute(value2, value3, value4, value5) {
    const value6 = value5.from;
    try {
      const value7 = loadConfig();
      const value8 = value4[0]?.toLowerCase();
      if (!value8) {
        const value9 = value7.readReceipts || "off";
        return await value2.sendMessage(value6, {
          text: ["👁️ *Read Receipts*", "", "📊 *Current Status:* " + (STATUS_LABEL[value9] || value9), "", "*Options:*", "  • `.readreceipts off` — Blue ticks (default)", "  • `.readreceipts on` — Grey ticks (hidden from everyone)", "  • `.readreceipts contacts` — Blue ticks for contacts only"].join("\n")
        }, {
          quoted: value3
        });
      }
      if (value8 === "off") {
        saveConfig({
          readReceipts: "off"
        });
        await value2.updateReadReceiptsPrivacy("all");
        return await value2.sendMessage(value6, {
          text: "🔵 *Read Receipts turned OFF*\n\nEveryone will see blue ticks when you read messages."
        }, {
          quoted: value3
        });
      }
      if (value8 === "on") {
        saveConfig({
          readReceipts: "on"
        });
        await value2.updateReadReceiptsPrivacy("none");
        return await value2.sendMessage(value6, {
          text: "⚪ *Read Receipts turned ON*\n\nMessages will show grey ticks — no one will see that you've read them."
        }, {
          quoted: value3
        });
      }
      if (value8 === "contacts") {
        saveConfig({
          readReceipts: "contacts"
        });
        await value2.updateReadReceiptsPrivacy("contacts");
        return await value2.sendMessage(value6, {
          text: "👥 *Read Receipts set to CONTACTS*\n\nOnly your contacts will see blue ticks."
        }, {
          quoted: value3
        });
      }
      return await value2.sendMessage(value6, {
        text: "⚠️ Invalid option.\n\nUsage: `.readreceipts off | on | contacts`"
      }, {
        quoted: value3
      });
    } catch (error10) {
      await value2.sendMessage(value6, {
        text: "❌ Failed to update read receipts: " + error10.message
      }, {
        quoted: value3
      });
    }
  },
  PRIVACY_MAP: PRIVACY_MAP
};
