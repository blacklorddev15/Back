'use strict';

const database = require("../../database");
const MIN = 1;
const MAX = 20;
function box(value1) {
  return "╭━━『 *Warning Limit* 』━━╮\n\n" + value1.join("\n") + "\n\n╰━━━━━━━━━━━━━━━━━━╯";
}
module.exports = {
  name: "setmaxwarn",
  aliases: ["maxwarn", "warnlimit", "setwarnlimit"],
  category: "owner",
  description: "Set how many warnings a member gets before being removed",
  usage: ".setmaxwarn <1-20>",
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(value2, value3, value4, value5) {
    try {
      const value6 = database.getBotSetting("prefix") || ".";
      const value7 = database.getBotSetting("maxWarnings");
      const value8 = String(value4[0] || "").trim();
      if (!value8) {
        return value5.reply(box(["⚠️ *Current limit:* *" + value7 + "* warning" + (value7 === 1 ? "" : "s"), "", "Members are removed once they reach it.", "", "💡 *" + value6 + "setmaxwarn <" + MIN + "-" + MAX + ">*", "   Example: *" + value6 + "setmaxwarn 5*"]));
      }
      if (!/^\d+$/.test(value8)) {
        return value5.reply(box(["❌ *" + value8 + "* is not a number.", "", "Use a whole number from " + MIN + " to " + MAX + "."]));
      }
      const value9 = parseInt(value8, 10);
      if (value9 < MIN || value9 > MAX) {
        return value5.reply(box(["❌ Out of range.", "", "Choose a value from *" + MIN + "* to *" + MAX + "*."]));
      }
      if (value9 === value7) {
        return value5.reply(box(["ℹ️ Already set to *" + value9 + "*."]));
      }
      database.setBotSetting("maxWarnings", value9);
      return value5.reply(box(["✅ *Warning limit set to " + value9 + ".*", "", "Members are now removed after *" + value9 + "* warning" + (value9 === 1 ? "" : "s") + ".", "_Was " + value7 + "._"]));
    } catch (error10) {
      console.error("SetMaxWarn command error:", error10);
      return value5.reply(box(["❌ *Failed to update warning limit*", "", error10.message]));
    }
  }
};
