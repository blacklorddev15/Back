module.exports = {
  name: "leave",
  aliases: ["left", "bye"],
  category: "admin",
  description: "Make the bot leave the current group",
  usage: ".leave",
  groupOnly: true,
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      await value4.reply("👋 Goodbye everyone! Leaving the group now...");
      await value1.groupLeave(value4.from);
    } catch (error5) {
      console.error("Leave command error:", error5);
      await value4.reply("❌ Failed to leave the group.");
    }
  }
};
