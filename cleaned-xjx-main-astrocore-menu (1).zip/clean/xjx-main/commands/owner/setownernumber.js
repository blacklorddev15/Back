const database = require("../../database");
module.exports = {
  name: "setownernumber",
  aliases: ["setowner_number", "setown"],
  category: "owner",
  description: "Change the bot owner number",
  usage: ".setownernumber <number>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      let value5 = "";
      const value6 = value2?.message?.extendedTextMessage?.contextInfo?.mentionedJid;
      if (value6 && value6.length > 0) {
        value5 = value6[0].split("@")[0];
      } else if (value3.length > 0) {
        value5 = value3[0].replace(/[^0-9]/g, "");
      }
      if (!value5) {
        const value7 = database.getOwners();
        const value8 = value7.length ? value7.map(value9 => "*" + value9 + "*").join(", ") : "_none set_";
        return value4.reply("📱 *Set Owner Number*\n\nCurrent: " + value8 + "\n\n" + ("Usage:\n" + database.getBotSetting("prefix") + "setownernumber <number>\n" + database.getBotSetting("prefix") + "setownernumber @mention\n\n") + "_This replaces the entire owner list._\n_Only needed when the bot runs on a different number from yours — the paired account is claimed automatically._");
      }
      if (value5.length < 7 || value5.length > 15) {
        return value4.reply("❌ Invalid phone number! Must be 7-15 digits.");
      }
      database.setOwners([value5], "command");
      await value4.reply("✅ Owner set to: *" + value5 + "*\n\n_Any previous owners have been removed._");
    } catch (error10) {
      await value4.reply("❌ Error: " + error10.message);
    }
  }
};
