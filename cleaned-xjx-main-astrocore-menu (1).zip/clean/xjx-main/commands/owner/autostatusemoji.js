const {
  loadSettings,
  saveSettings
} = require("../../database");
function extractEmojis(value1) {
  const value2 = [...value1.matchAll(/\p{Extended_Pictographic}(\u200D\p{Extended_Pictographic})*/gu)];
  return value2.map(value3 => value3[0]).filter(Boolean);
}
module.exports = {
  name: "autostatusemoji",
  aliases: ["statusemoji", "ase"],
  category: "owner",
  description: "Set the emoji(s) used for status reactions",
  usage: ".autostatusemoji 💙 ✅ 💕 💞 🥰  |  <single emoji>  |  random on/off",
  ownerOnly: true,
  async execute(value4, value5, value6, value7) {
    try {
      const value8 = loadSettings();
      const value9 = value6.join(" ").trim();
      const value10 = (value6[0] || "").toLowerCase();
      if (value10 === "random") {
        const value11 = (value6[1] || "").toLowerCase();
        if (value11 === "on") {
          if (!value8.emojiPool.length) {
            return value7.reply("⚠️ Set a pool first: .autostatusemoji 💙 ✅ 💕 💞 🥰");
          }
          value8.randomEmoji = true;
          saveSettings(value8);
          return value7.reply("🎲 *Random emoji reaction ON*\nPool: " + value8.emojiPool.join("  "));
        }
        if (value11 === "off") {
          value8.randomEmoji = false;
          saveSettings(value8);
          return value7.reply("🎲 *Random emoji reaction OFF*");
        }
        return value7.reply("⚠️ Use: .autostatusemoji random on/off");
      }
      if (!value9) {
        return value7.reply("🎭 *AUTOSTATUSEMOJI SETTINGS*\n━━━━━━━━━━━━\n" + ("Fixed emoji: *" + value8.emoji + "*\n") + ("Random mode: *" + (value8.randomEmoji ? "🟢 ON" : "🔴 OFF") + "*\n") + ("Pool: " + (value8.emojiPool.length ? value8.emojiPool.join("  ") : "(none)") + "\n") + "━━━━━━━━━━━━\n ✧ .autostatusemoji 💙 ✅ 💕 💞 🥰  → random pool\n ✧ .autostatusemoji 💙              → single fixed emoji\n ✧ .autostatusemoji random on/off");
      }
      const value12 = extractEmojis(value9);
      if (!value12.length) {
        return value7.reply("⚠️ No valid emojis found.\nExample: .autostatusemoji 💙 ✅ 💕 💞 🥰");
      }
      if (value12.length === 1) {
        value8.emoji = value12[0];
        value8.randomEmoji = false;
        saveSettings(value8);
        return value7.reply("✅ *React emoji set to:* " + value12[0] + "\n_(Random mode turned OFF)_");
      }
      value8.emojiPool = value12;
      value8.randomEmoji = true;
      saveSettings(value8);
      return value7.reply("✅ *Emoji pool set & random mode ON*\n" + ("Pool (" + value12.length + "): " + value12.join("  ") + "\n\n") + "Each status will react with a random emoji from this list.");
    } catch (error13) {
      await value7.reply("❌ Error: " + error13.message);
    }
  }
};
