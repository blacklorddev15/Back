const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const COUNTRY_CODES = {
  "234": [10, 10],
  "254": [9, 9],
  "233": [9, 9],
  "256": [9, 9],
  "255": [9, 9],
  "251": [9, 9],
  "252": [7, 8],
  "253": [8, 8],
  "257": [8, 8],
  "258": [9, 9],
  "260": [9, 9],
  "261": [9, 9],
  "262": [9, 9],
  "263": [9, 9],
  "264": [9, 9],
  "265": [9, 9],
  "266": [8, 8],
  "267": [8, 8],
  "268": [8, 8],
  "269": [7, 7],
  "237": [9, 9],
  "236": [8, 8],
  "235": [8, 8],
  "241": [7, 8],
  "242": [9, 9],
  "243": [9, 9],
  "244": [9, 9],
  "245": [7, 9],
  "248": [7, 7],
  "249": [9, 9],
  "211": [9, 9],
  "231": [7, 8],
  "232": [8, 8],
  "220": [7, 7],
  "221": [9, 9],
  "222": [8, 8],
  "223": [8, 8],
  "224": [9, 9],
  "225": [10, 10],
  "226": [8, 8],
  "227": [8, 8],
  "228": [8, 8],
  "229": [8, 8],
  "238": [7, 7],
  "239": [7, 7],
  "240": [9, 9],
  "291": [7, 7],
  "212": [9, 9],
  "213": [9, 9],
  "216": [8, 8],
  "218": [9, 9],
  "250": [9, 9],
  "27": [9, 9],
  "20": [10, 10],
  "1": [10, 10],
  "52": [10, 10],
  "53": [8, 8],
  "54": [10, 11],
  "55": [10, 11],
  "56": [9, 9],
  "57": [10, 10],
  "58": [10, 10],
  "51": [9, 9],
  "591": [8, 8],
  "592": [7, 7],
  "593": [9, 9],
  "595": [9, 9],
  "597": [7, 7],
  "598": [8, 9],
  "502": [8, 8],
  "503": [8, 8],
  "504": [8, 8],
  "505": [8, 8],
  "506": [8, 8],
  "507": [8, 8],
  "509": [8, 8],
  "44": [10, 10],
  "33": [9, 9],
  "34": [9, 9],
  "39": [9, 11],
  "41": [9, 9],
  "43": [10, 13],
  "45": [8, 8],
  "46": [9, 9],
  "47": [8, 8],
  "48": [9, 9],
  "49": [10, 12],
  "30": [10, 10],
  "31": [9, 9],
  "32": [9, 9],
  "351": [9, 9],
  "352": [9, 11],
  "353": [9, 9],
  "354": [7, 9],
  "355": [9, 9],
  "356": [8, 8],
  "357": [8, 8],
  "358": [9, 10],
  "359": [9, 9],
  "36": [9, 9],
  "370": [8, 8],
  "371": [8, 8],
  "372": [7, 8],
  "373": [8, 8],
  "374": [8, 8],
  "375": [9, 9],
  "380": [9, 9],
  "381": [8, 9],
  "385": [8, 9],
  "386": [8, 8],
  "387": [8, 8],
  "420": [9, 9],
  "421": [9, 9],
  "7": [10, 10],
  "90": [10, 10],
  "91": [10, 10],
  "92": [10, 10],
  "93": [9, 9],
  "94": [9, 9],
  "95": [8, 10],
  "960": [7, 7],
  "961": [8, 8],
  "962": [9, 9],
  "963": [9, 9],
  "964": [10, 10],
  "965": [8, 8],
  "966": [9, 9],
  "967": [9, 9],
  "968": [8, 8],
  "971": [9, 9],
  "972": [9, 9],
  "973": [8, 8],
  "974": [8, 8],
  "977": [10, 10],
  "98": [10, 10],
  "880": [10, 10],
  "81": [10, 11],
  "82": [9, 10],
  "84": [9, 10],
  "855": [8, 9],
  "856": [8, 9],
  "60": [9, 10],
  "62": [9, 12],
  "63": [10, 10],
  "65": [8, 8],
  "66": [9, 9],
  "86": [11, 11],
  "852": [8, 8],
  "853": [8, 8],
  "886": [9, 9],
  "61": [9, 9],
  "64": [8, 10],
  "675": [8, 8],
  "679": [7, 7]
};
const SORTED_CODES = Object.keys(COUNTRY_CODES).sort((value1, value2) => value2.length - value1.length);
const CC_LABELS = {
  "1": "🇺🇸 USA/Canada",
  "7": "🇷🇺 Russia",
  "20": "🇪🇬 Egypt",
  "27": "🇿🇦 South Africa",
  "30": "🇬🇷 Greece",
  "31": "🇳🇱 Netherlands",
  "32": "🇧🇪 Belgium",
  "33": "🇫🇷 France",
  "34": "🇪🇸 Spain",
  "36": "🇭🇺 Hungary",
  "39": "🇮🇹 Italy",
  "41": "🇨🇭 Switzerland",
  "43": "🇦🇹 Austria",
  "44": "🇬🇧 UK",
  "45": "🇩🇰 Denmark",
  "46": "🇸🇪 Sweden",
  "47": "🇳🇴 Norway",
  "48": "🇵🇱 Poland",
  "49": "🇩🇪 Germany",
  "51": "🇵🇪 Peru",
  "52": "🇲🇽 Mexico",
  "54": "🇦🇷 Argentina",
  "55": "🇧🇷 Brazil",
  "56": "🇨🇱 Chile",
  "57": "🇨🇴 Colombia",
  "58": "🇻🇪 Venezuela",
  "60": "🇲🇾 Malaysia",
  "61": "🇦🇺 Australia",
  "62": "🇮🇩 Indonesia",
  "63": "🇵🇭 Philippines",
  "64": "🇳🇿 New Zealand",
  "65": "🇸🇬 Singapore",
  "66": "🇹🇭 Thailand",
  "81": "🇯🇵 Japan",
  "82": "🇰🇷 South Korea",
  "84": "🇻🇳 Vietnam",
  "86": "🇨🇳 China",
  "90": "🇹🇷 Turkey",
  "91": "🇮🇳 India",
  "92": "🇵🇰 Pakistan",
  "94": "🇱🇰 Sri Lanka",
  "98": "🇮🇷 Iran",
  "212": "🇲🇦 Morocco",
  "213": "🇩🇿 Algeria",
  "216": "🇹🇳 Tunisia",
  "218": "🇱🇾 Libya",
  "220": "🇬🇲 Gambia",
  "221": "🇸🇳 Senegal",
  "223": "🇲🇱 Mali",
  "224": "🇬🇳 Guinea",
  "225": "🇨🇮 Ivory Coast",
  "226": "🇧🇫 Burkina Faso",
  "227": "🇳🇪 Niger",
  "228": "🇹🇬 Togo",
  "229": "🇧🇯 Benin",
  "231": "🇱🇷 Liberia",
  "232": "🇸🇱 Sierra Leone",
  "233": "🇬🇭 Ghana",
  "234": "🇳🇬 Nigeria",
  "235": "🇹🇩 Chad",
  "237": "🇨🇲 Cameroon",
  "240": "🇬🇶 Equatorial Guinea",
  "241": "🇬🇦 Gabon",
  "242": "🇨🇬 Congo",
  "243": "🇨🇩 DR Congo",
  "244": "🇦🇴 Angola",
  "249": "🇸🇩 Sudan",
  "250": "🇷🇼 Rwanda",
  "251": "🇪🇹 Ethiopia",
  "252": "🇸🇴 Somalia",
  "254": "🇰🇪 Kenya",
  "255": "🇹🇿 Tanzania",
  "256": "🇺🇬 Uganda",
  "257": "🇧🇮 Burundi",
  "258": "🇲🇿 Mozambique",
  "260": "🇿🇲 Zambia",
  "263": "🇿🇼 Zimbabwe",
  "264": "🇳🇦 Namibia",
  "265": "🇲🇼 Malawi",
  "351": "🇵🇹 Portugal",
  "353": "🇮🇪 Ireland",
  "358": "🇫🇮 Finland",
  "380": "🇺🇦 Ukraine",
  "420": "🇨🇿 Czech Republic",
  "421": "🇸🇰 Slovakia",
  "502": "🇬🇹 Guatemala",
  "503": "🇸🇻 El Salvador",
  "504": "🇭🇳 Honduras",
  "505": "🇳🇮 Nicaragua",
  "506": "🇨🇷 Costa Rica",
  "507": "🇵🇦 Panama",
  "509": "🇭🇹 Haiti",
  "591": "🇧🇴 Bolivia",
  "593": "🇪🇨 Ecuador",
  "595": "🇵🇾 Paraguay",
  "598": "🇺🇾 Uruguay",
  "852": "🇭🇰 Hong Kong",
  "855": "🇰🇭 Cambodia",
  "880": "🇧🇩 Bangladesh",
  "886": "🇹🇼 Taiwan",
  "961": "🇱🇧 Lebanon",
  "962": "🇯🇴 Jordan",
  "964": "🇮🇶 Iraq",
  "965": "🇰🇼 Kuwait",
  "966": "🇸🇦 Saudi Arabia",
  "968": "🇴🇲 Oman",
  "971": "🇦🇪 UAE",
  "972": "🇮🇱 Israel",
  "973": "🇧🇭 Bahrain",
  "974": "🇶🇦 Qatar"
};
function ccLabel(value3) {
  if (CC_LABELS[value3]) {
    return "+" + value3 + " (" + CC_LABELS[value3] + ")";
  } else {
    return "+" + value3;
  }
}
function classifyRaw(value4) {
  if (!value4) {
    return null;
  }
  for (const value5 of SORTED_CODES) {
    if (!value4.startsWith(value5)) {
      continue;
    }
    const value6 = value4.slice(value5.length);
    const [value7, value8] = COUNTRY_CODES[value5];
    if (value6.length >= value7 && value6.length <= value8) {
      return {
        type: "international",
        cc: value5,
        number: value4
      };
    } else {
      return {
        type: "invalid_international",
        cc: value5,
        number: value4
      };
    }
  }
  if (value4.startsWith("0") && value4.length >= 7 && value4.length <= 13) {
    return {
      type: "local",
      raw: value4
    };
  }
  if (value4.length >= 5 && value4.length <= 12) {
    return {
      type: "local",
      raw: value4
    };
  }
  return null;
}
function classifyNumber(value9) {
  if (!value9) {
    return null;
  }
  let value10 = String(value9).replace(/[^\d+]/g, "");
  if (!value10) {
    return null;
  }
  if (value10.startsWith("+")) {
    value10 = value10.slice(1);
  } else if (value10.startsWith("00")) {
    value10 = value10.slice(2);
  } else if (value10.startsWith("011")) {
    value10 = value10.slice(3);
  }
  if (!value10 || value10.length < 5) {
    return null;
  }
  return classifyRaw(value10);
}
function applyCountryCode(value11, value12) {
  let value13 = value11.replace(/[^\d]/g, "");
  if (value13.startsWith("0")) {
    value13 = value13.slice(1);
  }
  return value12 + value13;
}
function parseVCF(value14) {
  const value15 = [];
  const value16 = [];
  const value17 = [];
  for (const value18 of value14.split("\n")) {
    if (!value18.startsWith("TEL") && !value18.includes("TEL:")) {
      continue;
    }
    const value19 = value18.lastIndexOf(":");
    if (value19 === -1) {
      continue;
    }
    const value20 = value18.slice(value19 + 1).trim();
    const value21 = value20.match(/[\+\d][\d\s\-\(\)\.]{4,}/);
    if (!value21) {
      continue;
    }
    const value22 = classifyNumber(value21[0]);
    if (!value22) {
      continue;
    }
    if (value22.type === "international") {
      if (!value15.includes(value22.number)) {
        value15.push(value22.number);
      }
    } else if (value22.type === "invalid_international") {
      if (!value17.includes(value22.number)) {
        value17.push(value22.number);
      }
    } else if (!value16.includes(value22.raw)) {
      value16.push(value22.raw);
    }
  }
  return {
    international: value15,
    local: value16,
    invalidInternational: value17
  };
}
function waitForReply(value23, value24, value25, value26 = 60000) {
  const value27 = value28 => (value28 || "").split(":")[0];
  const value29 = value27(value25);
  return new Promise((value30, value31) => {
    const value32 = setTimeout(() => {
      value23.ev.off("messages.upsert", handler33);
      value31(new Error("TIMEOUT"));
    }, value26);
    function handler33({
      messages: value34,
      type: value35
    }) {
      if (value35 !== "notify") {
        return;
      }
      for (const value36 of value34) {
        if (value36.key.remoteJid !== value24) {
          continue;
        }
        const value37 = value27(value36.key.participant || value36.key.remoteJid);
        if (value37 !== value29) {
          continue;
        }
        const value38 = (value36.message?.conversation || value36.message?.extendedTextMessage?.text || "").trim();
        if (!value38) {
          continue;
        }
        clearTimeout(value32);
        value23.ev.off("messages.upsert", handler33);
        value30(value38);
        return;
      }
    }
    value23.ev.on("messages.upsert", handler33);
  });
}
function progressBar(value39, value40, value41 = 10) {
  const value42 = Math.round(value39 / value40 * value41);
  return "▰".repeat(value42) + "▱".repeat(value41 - value42);
}
function shuffle(value43) {
  for (let value44 = value43.length - 1; value44 > 0; value44--) {
    const value45 = Math.floor(Math.random() * (value44 + 1));
    [value43[value44], value43[value45]] = [value43[value45], value43[value44]];
  }
  return value43;
}
function sleep(value46) {
  return new Promise(value47 => setTimeout(value47, value46));
}
function parseFlags(value48) {
  const value49 = value48.join(" ");
  const value50 = {
    name: "",
    numbers: "",
    desc: null,
    msg: null,
    lock: false,
    admin: false,
    adminNumbers: [],
    random: null
  };
  const value51 = value49.match(/--desc\s+([\s\S]+?)(?=--|$)/);
  if (value51) {
    value50.desc = value51[1].trim();
  }
  const value52 = value49.match(/--msg\s+([\s\S]+?)(?=--|$)/);
  if (value52) {
    value50.msg = value52[1].trim();
  }
  value50.lock = /--lock/.test(value49);
  const value53 = value49.match(/--admin(?:\s+([\d,\s+]+?))?(?=--|$)/);
  if (value53) {
    value50.admin = true;
    if (value53[1]) {
      value50.adminNumbers = value53[1].split(",").map(value54 => {
        const value55 = classifyNumber(value54.trim());
        if (value55?.type === "international") {
          return value55.number;
        } else {
          return null;
        }
      }).filter(Boolean);
    }
  }
  const value56 = value49.match(/--random\s+(\d+)/);
  if (value56) {
    value50.random = parseInt(value56[1]);
  }
  const value57 = value49.replace(/--desc\s+[\s\S]+?(?=--|$)/, "").replace(/--msg\s+[\s\S]+?(?=--|$)/, "").replace(/--admin(?:\s+[\d,\s+]+?)?(?=--|$)/, "").replace(/--random\s+\d+/, "").replace(/--lock/, "").trim();
  const value58 = value57.split(/\s+/);
  value50.name = value58[0] || "";
  value50.numbers = value58.slice(1).join(" ");
  return value50;
}
module.exports = {
  name: "creategc",
  aliases: ["creategroup", "newgroup"],
  category: "owner",
  description: "Premium group creator — smart phone detection, interactive local-number resolution",
  usage: ".creategc <name> [numbers] [--desc text] [--msg text] [--lock] [--admin] [--random N]",
  async execute(value59, value60, value61, value62) {
    const {
      reply: value63,
      react: value64,
      from: value65,
      sender: value66
    } = value62;
    if (!value61.length) {
      return value63("📱 *creategc v4 — Premium Group Creator*\n\n*Basic:*\n• `.creategc Isaac` — empty group\n• `.creategc Isaac +2348012345678,+254712345678` — with members\n• Reply to VCF: `.creategc Isaac`\n\n*Flags:*\n• `--desc <text>` — set group description\n• `--msg <text>` — send welcome message\n• `--lock` — only admins can send\n• `--admin` — promote all added members\n• `--random N` — pick N random members from VCF\n\n*Smart phone handling:*\nNumbers with a country code (+234, 254, +44...) are processed automatically.\nLocal numbers (07xxx, 08xxx) trigger an interactive prompt — no flag needed!");
    }
    const value67 = parseFlags(value61);
    if (!value67.name) {
      return value63("❌ Group name is required.\nUsage: `.creategc <name>`");
    }
    try {
      await value64("⏳");
      const value68 = value60.message?.extendedTextMessage?.contextInfo?.quotedMessage || value60.message?.imageMessage?.contextInfo?.quotedMessage || value60.message?.videoMessage?.contextInfo?.quotedMessage;
      let value69 = [];
      let value70 = [];
      let value71 = [];
      if (value68?.documentMessage) {
        const value72 = value68.documentMessage;
        const value73 = value72.fileName || "";
        if (value73.endsWith(".vcf") || value72.mimetype === "text/vcard") {
          try {
            const value74 = await downloadContentFromMessage(value72, "document");
            let value75 = Buffer.from([]);
            for await (const value76 of value74) {
              value75 = Buffer.concat([value75, value76]);
            }
            const value77 = parseVCF(value75.toString("utf-8"));
            value69.push(...value77.international);
            value70.push(...value77.local);
            value71.push(...value77.invalidInternational);
          } catch (error78) {
            await value63("⚠️ Could not read VCF — continuing with manual numbers only.");
          }
        }
      }
      if (value67.numbers) {
        for (const value79 of value67.numbers.split(",")) {
          const value80 = classifyNumber(value79.trim());
          if (!value80) {
            continue;
          }
          if (value80.type === "international") {
            if (!value69.includes(value80.number)) {
              value69.push(value80.number);
            }
          } else if (value80.type === "invalid_international") {
            if (!value71.includes(value80.number)) {
              value71.push(value80.number);
            }
          } else if (!value70.includes(value80.raw)) {
            value70.push(value80.raw);
          }
        }
      }
      value69 = [...new Set(value69)];
      value71 = [...new Set(value71)];
      const value81 = value69.length + value70.length + value71.length;
      if (value81 === 0) {
        return value63("❌ No numbers found. Provide numbers directly or reply to a VCF.");
      }
      const value82 = value70.length > 0 || value71.length > 0;
      let value83 = [];
      if (value82) {
        let value84 = "";
        if (value71.length > 0) {
          const value85 = value71.slice(0, 5).map(value86 => {
            let value87 = "?";
            for (const value88 of SORTED_CODES) {
              if (value86.startsWith(value88)) {
                value87 = value88;
                break;
              }
            }
            const value89 = value86.slice(value87.length);
            const [value90, value91] = COUNTRY_CODES[value87] || ["?", "?"];
            return "  • +" + value86 + "  _(+" + value87 + " expects " + value90 + (value90 !== value91 ? "–" + value91 : "") + " digits, got " + value89.length + ")_";
          }).join("\n");
          const value92 = value71.length > 5 ? "\n  _...and " + (value71.length - 5) + " more_" : "";
          value84 = "\n\n*❌ Invalid international (skipped):*\n" + value85 + value92;
        }
        let value93 = "";
        if (value70.length > 0) {
          const value94 = value70.slice(0, 5).map(value95 => "  • " + value95).join("\n");
          const value96 = value70.length > 5 ? "\n  _...and " + (value70.length - 5) + " more_" : "";
          value93 = "\n\n*Sample local numbers:*\n" + value94 + value96;
        }
        await value63("📇 *Found " + value81 + " contact" + (value81 !== 1 ? "s" : "") + "*\n\n" + ("✅ *International:*          " + value69.length + "\n") + ("⚠️ *Local/Uncategorised:*    " + value70.length + "\n") + ("❌ *Invalid International:*  " + value71.length) + value84 + (value70.length > 0 ? value93 + "\n\n❓ *What should I do with the local numbers?*\n\n1️⃣ Skip them\n2️⃣ Treat as 🇳🇬 Nigeria (+234)\n3️⃣ Treat as 🇰🇪 Kenya (+254)\n4️⃣ 🌍 Other country (I'll ask for the code)\n5️⃣ ❌ Cancel\n\n_Reply with a number within 60 seconds._" : "\n\n_Invalid international numbers are automatically skipped. Proceeding..._"));
        if (value70.length > 0) {
          let value97;
          try {
            value97 = await waitForReply(value59, value65, value66, 60000);
          } catch (error98) {
            await value64("⌛");
            return value63("⌛ Timed out waiting for your choice. Operation cancelled.");
          }
          const value99 = value97.trim();
          if (value99.startsWith("5")) {
            await value64("❌");
            return value63("❌ Group creation cancelled.");
          }
          if (value99.startsWith("1")) {
            await value63("⏭️ Skipping " + value70.length + " local number" + (value70.length !== 1 ? "s" : "") + ".");
          } else if (value99.startsWith("2") || value99.startsWith("3")) {
            const value100 = value99.startsWith("2") ? "234" : "254";
            value83 = value70.map(value101 => applyCountryCode(value101, value100));
            await value63("🌍 Converting " + value70.length + " local numbers to " + ccLabel(value100) + ".");
          } else if (value99.startsWith("4")) {
            await value63("🌍 *Enter the country calling code* (digits only, no +)\n\nExamples: `44` for UK, `91` for India, `1` for USA\n\n_Reply within 60 seconds._");
            let value102;
            try {
              value102 = await waitForReply(value59, value65, value66, 60000);
            } catch (error103) {
              await value64("⌛");
              return value63("⌛ Timed out. Operation cancelled.");
            }
            value102 = value102.replace(/\D/g, "");
            if (!value102 || value102.length < 1 || value102.length > 4) {
              await value64("❌");
              return value63("❌ Invalid country code. Operation cancelled.");
            }
            value83 = value70.map(value104 => applyCountryCode(value104, value102));
            await value63("🌍 Converting " + value70.length + " local numbers to " + ccLabel(value102) + ".");
          } else {
            await value63("⚠️ Unrecognised choice. Skipping " + value70.length + " local number" + (value70.length !== 1 ? "s" : "") + " and continuing.");
          }
        }
      }
      let value105 = [...new Set([...value69, ...value83])];
      if (value67.random && value67.random < value105.length) {
        value105 = shuffle(value105).slice(0, value67.random);
        await value63("🎲 Randomly selected *" + value105.length + "* contacts.");
      }
      if (value105.length > 0) {
        const value106 = new Map();
        for (const value107 of value105) {
          let value108 = "Unknown";
          for (const value109 of SORTED_CODES) {
            if (value107.startsWith(value109)) {
              value108 = value109;
              break;
            }
          }
          value106.set(value108, (value106.get(value108) || 0) + 1);
        }
        if (value106.size > 1) {
          const value110 = [...value106.entries()].sort((value111, value112) => value112[1] - value111[1]).map(([value113, value114]) => "  " + ccLabel(value113) + ": " + value114).join("\n");
          await value63("🌍 *Number breakdown by country:*\n" + value110);
        }
      }
      if (value105.length === 0) {
        await value63("⚠️ No participants to add — creating an empty group with just the bot.");
      }
      const value115 = [];
      const value116 = [];
      if (value105.length > 0) {
        await value63("🔍 Validating *" + value105.length + "* number" + (value105.length !== 1 ? "s" : "") + " on WhatsApp...");
        const value117 = 20;
        const value118 = value105.length;
        let value119 = 0;
        let value120 = 0;
        for (let value121 = 0; value121 < value118; value121 += value117) {
          const value122 = value105.slice(value121, value121 + value117);
          await Promise.all(value122.map(async value123 => {
            try {
              const [value124] = await value59.onWhatsApp(value123);
              if (value124?.exists) {
                value115.push(value123 + "@s.whatsapp.net");
              } else {
                value116.push(value123);
              }
            } catch (error125) {
              value116.push(value123);
            }
          }));
          value119 += value122.length;
          const value126 = Math.round(value119 / value118 * 100);
          if (value126 - value120 >= 25 || value119 === value118) {
            await value63("⏳ " + progressBar(value119, value118) + " " + value126 + "%");
            value120 = value126;
          }
          if (value121 + value117 < value118) {
            await sleep(400);
          }
        }
        const value127 = value116.slice(0, 10).map(value128 => "• +" + value128).join("\n");
        const value129 = value116.length > 10 ? "\n_...and " + (value116.length - 10) + " more_" : "";
        await value63("📊 *Validation Report*\n━━━━━━━━━━━━━━━━━\n" + ("✅ Valid WhatsApp:  *" + value115.length + "*\n") + ("❌ Invalid/No WA:   *" + value116.length + "*\n") + (value116.length > 0 ? "\n*Failed:*\n" + value127 + value129 : ""));
      }
      const value130 = await value59.groupCreate(value67.name, value115);
      if (!value130?.id) {
        throw new Error("Group creation returned invalid data");
      }
      const value131 = value130.id;
      if (value67.desc) {
        try {
          await value59.groupUpdateDescription(value131, value67.desc);
        } catch (error132) {}
      }
      let value133 = false;
      let value134 = null;
      const value135 = 5242880;
      if (value60.message?.imageMessage) {
        try {
          const value136 = await downloadContentFromMessage(value60.message.imageMessage, "image");
          let value137 = Buffer.from([]);
          for await (const value138 of value136) {
            value137 = Buffer.concat([value137, value138]);
            if (value137.length > value135) {
              value137 = null;
              break;
            }
          }
          value134 = value137;
        } catch (error139) {}
      }
      if (!value134 && value68?.imageMessage) {
        try {
          const value140 = await downloadContentFromMessage(value68.imageMessage, "image");
          let value141 = Buffer.from([]);
          for await (const value142 of value140) {
            value141 = Buffer.concat([value141, value142]);
            if (value141.length > value135) {
              value141 = null;
              break;
            }
          }
          value134 = value141;
        } catch (error143) {}
      }
      if (value134) {
        try {
          await value59.updateProfilePicture(value131, value134);
          value133 = true;
        } catch (error144) {}
      }
      if (value67.lock) {
        try {
          await value59.groupSettingUpdate(value131, "announcement");
        } catch (error145) {}
      }
      let value146 = 0;
      let value147 = 0;
      if (value67.admin && value115.length > 0) {
        let value148;
        if (value67.adminNumbers.length > 0) {
          value148 = value67.adminNumbers.map(value149 => value149 + "@s.whatsapp.net").filter(value150 => value115.includes(value150));
          value147 = value67.adminNumbers.length - value148.length;
        } else {
          value148 = value115;
        }
        try {
          await value59.groupParticipantsUpdate(value131, value148, "promote");
          value146 = value148.length;
        } catch (error151) {}
      }
      let value152 = "Unable to generate";
      try {
        const value153 = await value59.groupInviteCode(value131);
        value152 = "https://chat.whatsapp.com/" + value153;
      } catch (error154) {}
      const value155 = value67.msg || "🎉 Welcome to *\"" + value67.name + "\"*!\n🔗 " + value152;
      await value59.sendMessage(value131, {
        text: value155
      });
      await value64("✅");
      return value63("🎉 *Group Created Successfully!*\n━━━━━━━━━━━━━━━━━━━━\n" + ("📱 *Name:*     " + value67.name + "\n") + ("👥 *Members:* " + (value115.length + 1) + " (including bot)\n") + (value146 ? "👑 *Admins:*   " + value146 + " promoted\n" : "") + (value147 ? "⚠️ *Admin req skipped:* " + value147 + " (not in group)\n" : "") + (value133 ? "🖼️  *Photo:*    ✅ Set\n" : "") + (value67.desc ? "📝 *Desc:*     ✅ Set\n" : "") + (value67.lock ? "🔒 *Locked:*   ✅ Admins only\n" : "") + "━━━━━━━━━━━━━━━━━━━━\n" + ("🔗 *Link:*\n" + value152));
    } catch (error156) {
      await value64("❌");
      let value157 = "❌ Failed to create group!";
      if (error156.message?.includes("not-authorized")) {
        value157 += "\n\n⚠️ Bot lacks permission to create groups.";
      } else if (error156.message?.includes("rate-limit")) {
        value157 += "\n\n⏰ Rate limited. Please wait and try again.";
      } else {
        value157 += "\n\n🔍 Error: " + error156.message;
      }
      return value63(value157);
    }
  }
};
