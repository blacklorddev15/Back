'use strict';

const database = require("../../database");
module.exports = {
  name: "anticall",
  aliases: ["ac"],
  category: "owner",
  ownerOnly: true,
  description: "Toggle anti-call system (off/decline/block)",
  usage: ".anticall <off|decline|block|on>",
  async execute(value1, value2, value3, value4) {
    const value5 = value3[0]?.toLowerCase().trim();
    const value6 = database.getDefaultGroupSettings().anticall ? "enabled" : "disabled";
    if (!value5) {
      return value4.reply("📵 *Anti-Call System: " + value6.toUpperCase() + "*\n\n*Toggle Commands:*\n• `.anticall off` - Disable anti-call\n• `.anticall decline` - Decline calls only\n• `.anticall block` - Decline & block caller\n• `.anticall on` - Enable (same as block)\n\n_Type `.anticallmsg` for all message options._");
    }
    const value7 = ["off", "decline", "block", "on"];
    if (!value7.includes(value5)) {
      return value4.reply("⚠️ Usage: `.anticall off | decline | block | on`");
    }
    const value8 = value5 !== "off";
    const value9 = value5 === "decline" ? "decline" : "block";
    try {
      database.setBotSetting("anticall", value8);
      database.setBotSetting("anticallAction", value9);
      const value10 = {
        off: {
          emoji: "📵",
          title: "Anti-Call *OFF*",
          desc: "Calls will be accepted normally."
        },
        decline: {
          emoji: "📵",
          title: "Anti-Call: *Decline Mode*",
          desc: "Incoming calls will be automatically declined.\n_Manage messages with `.anticallmsg`_"
        },
        block: {
          emoji: "🚫",
          title: "Anti-Call: *Block Mode*",
          desc: "Incoming calls will be declined and caller blocked.\n_Customize message with `.anticallmsg set`_"
        },
        on: {
          emoji: "🚫",
          title: "Anti-Call: *Block Mode* (Enabled)",
          desc: "Incoming calls will be declined and caller blocked.\n_Use `.anticallmsg` to manage messages._"
        }
      };
      const value11 = value10[value5];
      return value4.reply("✅ " + value11.emoji + " " + value11.title + "\n\n" + value11.desc);
    } catch (error12) {
      console.error("[anticall]", error12.message);
      return value4.reply("❌ Failed to update anti-call setting.");
    }
  }
};
