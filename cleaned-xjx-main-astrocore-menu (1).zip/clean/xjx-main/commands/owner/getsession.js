const sessionServer = require("../../utils/juneDb/sessionServer");
module.exports = {
  name: "getsession",
  aliases: ["sessionid", "mysession", "session"],
  category: "owner",
  description: "Show your Session ID status",
  usage: ".getsession",
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(value1, value2, value3, value4) {
    try {
      if (sessionServer.isTokenModeActive()) {
        const value5 = sessionServer.getConfiguredToken();
        const value6 = value5.slice(0, 8) + "…" + value5.slice(-4);
        const value7 = sessionServer.sha256Hex(value5).slice(0, 8);
        const value8 = sessionServer.getStatus();
        let value9 = "";
        try {
          const value10 = await fetch(sessionServer.getServerUrl() + "/health", {
            signal: AbortSignal.timeout(5000)
          });
          value9 = value10.ok ? "\n📡 Server: reachable" : "\n📡 Server: HTTP " + value10.status;
        } catch (error11) {
          value9 = "\n📡 Could not reach the session server: " + error11.message;
        }
        return value4.reply("╭━━『 *Session ID (active)* 』━━╮\n\n" + ("🔑 Session ID: `" + value6 + "`\n") + ("🔖 Fingerprint: `" + value7 + "`\n") + ("🔗 Server: " + sessionServer.getServerUrl() + "\n") + ("📡 Status: " + (value8.authenticated ? "loaded (active)" : "configured")) + (value9 + "\n\n") + "📋 The full Session ID is in your bot's environment\n(SESSION_ID).\n\n⚠️ Lost it or suspect a leak? Re-pair at\n" + (sessionServer.getServerUrl() + "/pair and set the fresh Session ID.\n") + "╰━━━━━━━━━━━━━━━━━━━━━━━━━━━╯");
      }
      return value4.reply("❌ *No Session ID configured.*\n\n" + ("1️⃣ Pair at " + sessionServer.getServerUrl() + "/pair\n") + "2️⃣ Copy your JUNE-X~ Session ID\n3️⃣ Set it as SESSION_ID in this bot's .env\n4️⃣ Restart the bot");
    } catch (error12) {
      console.log("GetSession command error:", error12.message);
      await value4.reply("❌ Failed to read session status: " + error12.message);
    }
  }
};
