'use strict';

const database = require("../../database");
const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const messageStore = new Map();
const pendingPersistence = new Map();
const PERSIST_DEBOUNCE_MS = 2000;
const PERSIST_RETRY_INTERVAL_MS = 5000;
let persistenceTimer = null;
let lastPersistenceErrorAt = 0;
const getMode = () => database.getAntideleteMode();
const getTimezone = () => database.getTimeZone();
const MEDIA_MAP = {
  imageMessage: "image",
  videoMessage: "video",
  audioMessage: "audio",
  stickerMessage: "sticker",
  documentMessage: "document"
};
function unwrap(value1) {
  return value1.ephemeralMessage?.message || value1.viewOnceMessageV2Extension?.message || value1.viewOnceMessageV2?.message || value1.viewOnceMessage?.message || value1;
}
function recordKey(value2, value3) {
  return String(value2) + "\0" + String(value3);
}
function normaliseTimestamp(value4) {
  const value5 = Number(value4);
  if (Number.isFinite(value5) && value5 > 0) {
    return value5;
  } else {
    return null;
  }
}
function encodeForDatabase(value6, value7 = new WeakSet()) {
  if (value6 === null || value6 === undefined) {
    return value6;
  }
  if (typeof value6 === "string" || typeof value6 === "number" || typeof value6 === "boolean") {
    return value6;
  }
  if (typeof value6 === "bigint") {
    return {
      __juneBigInt: value6.toString()
    };
  }
  if (Buffer.isBuffer(value6)) {
    return {
      __juneBuffer: value6.toString("base64")
    };
  }
  if (value6 instanceof Uint8Array) {
    return {
      __juneBuffer: Buffer.from(value6).toString("base64")
    };
  }
  if (Array.isArray(value6)) {
    return value6.map(value8 => encodeForDatabase(value8, value7));
  }
  if (typeof value6 !== "object") {
    return undefined;
  }
  if (value7.has(value6)) {
    return undefined;
  }
  value7.add(value6);
  const value9 = {};
  for (const [value10, value11] of Object.entries(value6)) {
    const value12 = encodeForDatabase(value11, value7);
    if (value12 !== undefined) {
      value9[value10] = value12;
    }
  }
  value7.delete(value6);
  return value9;
}
function decodeFromDatabase(value13) {
  if (value13 === null || value13 === undefined) {
    return value13;
  }
  if (Array.isArray(value13)) {
    return value13.map(decodeFromDatabase);
  }
  if (typeof value13 !== "object") {
    return value13;
  }
  if (typeof value13.__juneBuffer === "string") {
    try {
      return Buffer.from(value13.__juneBuffer, "base64");
    } catch (error14) {
      return null;
    }
  }
  if (typeof value13.__juneBigInt === "string") {
    return value13.__juneBigInt;
  }
  const value15 = {};
  for (const [value16, value17] of Object.entries(value13)) {
    value15[value16] = decodeFromDatabase(value17);
  }
  return value15;
}
function toPersistentEntry(value18) {
  return {
    sender: String(value18.sender || ""),
    timestamp: normaliseTimestamp(value18.timestamp),
    type: String(value18.type || "text"),
    mtype: value18.mtype ? String(value18.mtype) : null,
    text: value18.text === null || value18.text === undefined ? null : String(value18.text),
    inner: value18.mtype ? encodeForDatabase(value18.inner) : null
  };
}
function fromPersistentEntry(value19) {
  if (!value19 || typeof value19 !== "object") {
    return null;
  }
  const value20 = String(value19.type || "text");
  const value21 = value19.mtype ? String(value19.mtype) : null;
  const value22 = value19.inner ? decodeFromDatabase(value19.inner) : null;
  if (value20 !== "text" && (!value21 || !value22)) {
    return null;
  }
  return {
    sender: String(value19.sender || ""),
    timestamp: normaliseTimestamp(value19.timestamp),
    type: value20,
    mtype: value21,
    inner: value22,
    text: value19.text === null || value19.text === undefined ? null : String(value19.text)
  };
}
function reportPersistenceError(value23) {
  const value24 = Date.now();
  if (value24 - lastPersistenceErrorAt < 60000) {
    return;
  }
  lastPersistenceErrorAt = value24;
  console.error("[ANTIDELETE] SQLite persistence error:", value23?.message || value23);
}
function schedulePersistence() {
  if (persistenceTimer) {
    return;
  }
  persistenceTimer = setTimeout(() => {
    persistenceTimer = null;
    flushPersistentMessages();
  }, PERSIST_DEBOUNCE_MS);
  persistenceTimer.unref?.();
}
function queuePersistentMessage(value25, value26, value27) {
  pendingPersistence.set(recordKey(value25, value26), {
    chatId: String(value25),
    messageId: String(value26),
    payload: toPersistentEntry(value27),
    storedAt: Date.now()
  });
  schedulePersistence();
}
function flushPersistentMessages() {
  if (persistenceTimer) {
    clearTimeout(persistenceTimer);
    persistenceTimer = null;
  }
  let value28 = 0;
  for (const [value29, value30] of [...pendingPersistence.entries()]) {
    try {
      database.saveAntideleteMessage(value30.chatId, value30.messageId, value30.payload, value30.storedAt);
      pendingPersistence.delete(value29);
      value28 += 1;
    } catch (error31) {
      reportPersistenceError(error31);
    }
  }
  return value28;
}
function getCachedEntry(value32, value33) {
  return messageStore.get(value32)?.get(value33) || null;
}
function getStoredEntry(value34, value35) {
  const value36 = getCachedEntry(value34, value35);
  if (value36) {
    return value36;
  }
  try {
    const value37 = database.getAntideleteMessage(value34, value35);
    if (value37) {
      return fromPersistentEntry(value37.payload);
    } else {
      return null;
    }
  } catch (error38) {
    reportPersistenceError(error38);
    return null;
  }
}
function removeStoredEntry(value39, value40) {
  const value41 = messageStore.get(value39);
  if (value41) {
    value41.delete(value40);
    if (value41.size === 0) {
      messageStore.delete(value39);
    }
  }
  pendingPersistence.delete(recordKey(value39, value40));
  try {
    database.deleteAntideleteMessage(value39, value40);
  } catch (error42) {
    reportPersistenceError(error42);
  }
}
const storeMessage = value43 => {
  try {
    if (!value43?.key?.id || !value43.message) {
      return;
    }
    const value44 = value43.key.remoteJid;
    if (!value44 || value44 === "status@broadcast") {
      return;
    }
    const value45 = value43.key.participant || value43.key.remoteJid;
    const value46 = unwrap(value43.message);
    const value47 = value46.conversation || value46.extendedTextMessage?.text || value46.imageMessage?.caption || value46.videoMessage?.caption || value46.documentMessage?.caption || null;
    const value48 = Object.keys(MEDIA_MAP).find(value49 => value46[value49]);
    if (!value47 && !value48) {
      return;
    }
    const value50 = {
      sender: value45,
      timestamp: value43.messageTimestamp,
      type: value48 ? MEDIA_MAP[value48] : "text",
      mtype: value48 || null,
      inner: value46,
      text: value47 || null
    };
    if (!messageStore.has(value44)) {
      messageStore.set(value44, new Map());
    }
    const value51 = messageStore.get(value44);
    value51.set(value43.key.id, value50);
    if (value51.size > 500) {
      value51.delete(value51.keys().next().value);
    }
    queuePersistentMessage(value44, value43.key.id, value50);
  } catch (error52) {}
};
async function downloadMedia(value53) {
  try {
    const {
      inner: value54,
      mtype: value55
    } = value53;
    if (!value54 || !value55 || !value54[value55]) {
      return null;
    }
    const value56 = await downloadContentFromMessage(value54[value55], MEDIA_MAP[value55]);
    const value57 = [];
    for await (const value58 of value56) {
      value57.push(value58);
    }
    return Buffer.concat(value57);
  } catch {
    return null;
  }
}
async function getChatLabel(value59, value60) {
  try {
    if (value60.endsWith("@g.us")) {
      const value61 = await value59.groupMetadata(value60);
      return "👥 *" + value61.subject + "*";
    }
    return "💬 DM (" + value60.split("@")[0] + ")";
  } catch {
    if (value60.endsWith("@g.us")) {
      return "👥 Group (" + value60.split("@")[0] + ")";
    } else {
      return "💬 DM (" + value60.split("@")[0] + ")";
    }
  }
}
async function sendRecovered(value62, value63, value64, value65) {
  const value66 = value64.sender?.split("@")[0]?.split(":")[0] || "Unknown";
  const value67 = {
    image: "🖼️",
    video: "🎬",
    audio: "🎵",
    sticker: "🧩",
    document: "📄",
    text: "📝"
  }[value64.type] || "📝";
  const value68 = String.fromCharCode(8206).repeat(4001);
  const value69 = "━━━━━━━━━━━━━━━━━━━━";
  const value70 = value64.timestamp ? new Date(Number(value64.timestamp) * 1000).toLocaleString("en-GB", {
    hour12: false,
    timeZone: getTimezone(),
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  }) : new Date().toLocaleString();
  const value71 = value65 && value65 !== value63 ? "\n📍 *Chat:* " + (await getChatLabel(value62, value65)) : "";
  const value72 = value64.sender ? [value64.sender] : [];
  const value73 = "🗑️ *DELETED MESSAGE* 🗑️\n" + (value69 + "\n") + ("👤 *From:* @" + value66 + "\n") + ("🕐 *Time:* " + value70 + "\n") + (value67 + " *Type:* " + value64.type) + value71 + "\n" + (value69 + "\n" + value68 + "\n");
  if (value64.type === "text") {
    await value62.sendMessage(value63, {
      text: value73 + "📝 *Message:*\n" + value64.text + "\n" + value69,
      mentions: value72
    });
    return;
  }
  const value74 = await downloadMedia(value64);
  if (!value74) {
    await value62.sendMessage(value63, {
      text: value73 + "⚠️ _Media expired (CDN link gone)._\n" + value69,
      mentions: value72
    });
    return;
  }
  const value75 = "🗑️ *Deleted Message Recovered*\n" + value69 + "\n" + ("👤 *From:* @" + value66 + "\n") + ("🕐 *Time:* " + value70 + "\n") + (value67 + " *Type:* " + value64.type) + value71 + (value64.text ? "\n" + value69 + "\n" + value68 + "\n📝 *Caption:*\n" + value64.text : "") + ("\n" + value69);
  const value76 = "" + value73 + (value64.text ? "📝 *Caption:*\n" + value64.text + "\n" : "") + value69;
  if (value64.type === "image") {
    await value62.sendMessage(value63, {
      image: value74,
      caption: value75,
      mentions: value72
    });
  } else if (value64.type === "video") {
    await value62.sendMessage(value63, {
      video: value74,
      caption: value75,
      mentions: value72,
      mimetype: value64.inner?.videoMessage?.mimetype || "video/mp4"
    });
  } else if (value64.type === "audio") {
    const value77 = value64.inner?.audioMessage?.ptt === true;
    await value62.sendMessage(value63, {
      audio: value74,
      ptt: value77,
      mimetype: value64.inner?.audioMessage?.mimetype || "audio/ogg; codecs=opus"
    });
    await value62.sendMessage(value63, {
      text: value76,
      mentions: value72
    });
  } else if (value64.type === "sticker") {
    await value62.sendMessage(value63, {
      sticker: value74,
      mimetype: value64.inner?.stickerMessage?.mimetype || "image/webp"
    });
    await value62.sendMessage(value63, {
      text: value76,
      mentions: value72
    });
  } else if (value64.type === "document") {
    await value62.sendMessage(value63, {
      document: value74,
      mimetype: value64.inner?.documentMessage?.mimetype || "application/octet-stream",
      fileName: value64.inner?.documentMessage?.fileName || "file",
      caption: value75,
      mentions: value72
    });
  }
}
function ownerJid(value78) {
  const value79 = value78.user?.id;
  if (!value79) {
    return null;
  }
  if (value79.includes(":")) {
    return value79.split(":")[0] + "@s.whatsapp.net";
  } else {
    return value79;
  }
}
const handleDelete = async (value80, value81) => {
  try {
    const value82 = getMode();
    const value83 = ownerJid(value80);
    if (!value82 || value82 === "off") {
      return;
    }
    for (const value84 of value81) {
      const value85 = value84.key?.remoteJid;
      const value86 = value84.key?.id;
      if (!value85 || !value86 || value85 === "status@broadcast") {
        continue;
      }
      const value87 = value82 === "private" && value83 ? value83 : value82 === "chat" ? value85 : null;
      if (!value87) {
        continue;
      }
      const value88 = getStoredEntry(value85, value86);
      if (!value88) {
        continue;
      }
      await sendRecovered(value80, value87, value88, value85);
      removeStoredEntry(value85, value86);
    }
  } catch (error89) {
    console.error("[ANTIDELETE] handleDelete error:", error89.message);
  }
};
function getStoreStats() {
  let value90 = 0;
  for (const value91 of messageStore.values()) {
    value90 += value91.size;
  }
  return {
    mode: getMode(),
    chats: messageStore.size,
    messages: value90,
    pendingPersistence: pendingPersistence.size,
    persistentStore: "SQLite antidelete_messages"
  };
}
setInterval(flushPersistentMessages, PERSIST_RETRY_INTERVAL_MS).unref();
global.__JUNE_FLUSH_ANTIDELETE = flushPersistentMessages;
process.prependListener("exit", flushPersistentMessages);
module.exports = {
  name: "antidelete",
  aliases: ["antidel"],
  category: "owner",
  description: "Recover deleted messages",
  usage: ".antidelete on/private/off/status",
  adminOnly: true,
  storeMessage: storeMessage,
  handleDelete: handleDelete,
  getStoreStats: getStoreStats,
  flush: flushPersistentMessages,
  flushPersistentMessages: flushPersistentMessages,
  async execute(value92, value93, value94, value95) {
    const {
      reply: value96
    } = value95;
    const value97 = (value94[0] || "").toLowerCase();
    const value98 = getMode();
    const value99 = value98 === "chat" ? "✅ ON — Chat" : value98 === "private" ? "✅ ON — Private" : "❌ OFF";
    if (!value97 || value97 === "status") {
      return value96("🗑️ Anti-Delete: *" + value99 + "*\n\n.antidelete on | private | off");
    }
    if (value97 === "on" || value97 === "chat") {
      database.setAntideleteMode("chat");
      return value96("🗑️ Anti-Delete set to *ON* — deleted msgs shown in each chat.");
    }
    if (value97 === "private") {
      database.setAntideleteMode("private");
      return value96("🗑️ Anti-Delete set to *Private* — all deleted msgs go to owner DM.");
    }
    if (value97 === "off") {
      database.setAntideleteMode("off");
      return value96("🗑️ Anti-Delete set to *OFF*.");
    }
    return value96("⚠️ Usage: .antidelete on | private | off | status");
  }
};
