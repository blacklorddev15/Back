const botMode = require("../../utils/botMode");
module.exports = {
  name: "mode",
  aliases: ["botmode", "setmode"],
  description: "Set bot operating mode (public / private / group / pm)",
  usage: ".mode <public|private|group|pm>",
  category: "owner",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = botMode.getMode();
      if (!value3[0]) {
        return value4.reply("🤖 *Bot Mode*\n\n" + ("Current Mode: *" + botMode.getModeLabel() + "*\n\n") + "*Available Modes:*\n  🌐 *.mode public*  — everyone can use commands (groups & DMs)\n  🔒 *.mode private* — only owner & sudo can use commands\n  👥 *.mode group*   — commands work in groups only\n  💬 *.mode pm*      — commands work in private chats only");
      }
      const value6 = value3[0].toLowerCase();
      const value7 = {
        pub: "public",
        priv: "private",
        silent: "private",
        restricted: "private",
        grp: "group",
        groups: "group",
        dm: "pm",
        dms: "pm",
        inbox: "pm"
      };
      const value8 = value7[value6] || value6;
      if (!botMode.VALID_MODES.includes(value8)) {
        return value4.reply("❌ *Invalid mode:* _" + value6 + "_\n\nChoose one of: *public, private, group, pm*");
      }
      if (value8 === value5) {
        return value4.reply("ℹ️ Bot is already in *" + botMode.getModeLabel() + "* mode.");
      }
      botMode.setMode(value8);
      const value9 = {
        public: "Everyone can use commands in groups and DMs.",
        private: "Only owner & sudo users can use commands.",
        group: "Commands only work inside groups.",
        pm: "Commands only work in private/DM chats."
      };
      const value10 = {
        public: "🌐",
        private: "🔒",
        group: "👥",
        pm: "💬"
      };
      return value4.reply(value10[value8] + " *Bot mode changed to " + value8.toUpperCase() + "*\n\n" + ("" + value9[value8]));
    } catch (error11) {
      console.error("Mode command error:", error11);
      await value4.reply("❌ Error changing bot mode.");
    }
  }
};
