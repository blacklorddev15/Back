const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
function resolveQuotedMsg(value1) {
  const value2 = value1.message?.extendedTextMessage?.contextInfo;
  if (!value2?.quotedMessage) {
    return null;
  }
  return {
    key: {
      remoteJid: value1.key.remoteJid,
      id: value2.stanzaId,
      participant: value2.participant
    },
    message: value2.quotedMessage
  };
}
function getMediaType(value3) {
  const value4 = value3?.message || {};
  if (value4.imageMessage) {
    return {
      type: "image",
      key: "image"
    };
  }
  if (value4.videoMessage) {
    return {
      type: "video",
      key: "video"
    };
  }
  if (value4.audioMessage) {
    return {
      type: "audio",
      key: "audio"
    };
  }
  if (value4.documentMessage) {
    return {
      type: "document",
      key: "document"
    };
  }
  if (value4.stickerMessage) {
    return {
      type: "sticker",
      key: "sticker"
    };
  }
  return null;
}
function toJid(value5) {
  if (!value5) {
    return null;
  }
  let value6 = String(value5).trim().replace(/[^0-9]/g, "");
  if (!value6) {
    return null;
  }
  return value6 + "@s.whatsapp.net";
}
module.exports = {
  name: "forward",
  aliases: ["fwd", "sendto"],
  category: "owner",
  description: "Forward a message or quoted media to another number",
  usage: ".forward <number> [custom text] — reply to a message to forward it",
  ownerOnly: true,
  async execute(value7, value8, value9, value10) {
    try {
      const value11 = value10.from || value8.key.remoteJid;
      if (!value9 || value9.length < 1) {
        return value10.reply("❌ *Usage:* .forward <number> [custom text]\n\n*Reply* to any message to forward it to the given number.\n\nExamples:\n• .forward 254712345678\n• .forward 254712345678 Hello check this out");
      }
      const value12 = toJid(value9[0]);
      if (!value12) {
        return value10.reply("❌ Invalid phone number. Please provide a valid number.");
      }
      const value13 = value9.slice(1).join(" ").trim() || undefined;
      const value14 = resolveQuotedMsg(value8);
      const value15 = value14 ? getMediaType(value14) : null;
      if (value14 && value15) {
        await value10.reply("🔄");
        let value16;
        try {
          value16 = await downloadMediaMessage(value14, "buffer", {}, {
            logger: undefined,
            reuploadRequest: value7.updateMediaMessage
          });
        } catch (error17) {
          return value10.reply("❌ Failed to download media: " + error17.message);
        }
        if (!value16 || value16.length === 0) {
          return value10.reply("❌ Media download returned empty buffer.");
        }
        const value18 = {
          [value15.key]: value16
        };
        if (value13) {
          value18.caption = value13;
        } else {
          const value19 = value14.message?.[value15.type + "Message"]?.caption;
          if (value19) {
            value18.caption = value19;
          }
        }
        await value7.sendMessage(value12, value18);
        return value10.reply("✅ Media forwarded to " + value9[0] + ".");
      } else if (value14) {
        const value20 = value14.message?.extendedTextMessage?.text || value14.message?.conversation || value14.message?.[Object.keys(value14.message)[0]]?.text || "";
        const value21 = value13 || value20 || "";
        if (!value21) {
          return value10.reply("❌ Could not extract text from the quoted message.");
        }
        await value7.sendMessage(value12, {
          text: value21
        });
        return value10.reply("✅ Message forwarded to " + value9[0] + ".");
      } else {
        if (value13) {
          await value7.sendMessage(value12, {
            text: value13
          });
          return value10.reply("✅ Message sent to " + value9[0] + ".");
        }
        return value10.reply("❌ Please *reply* to a message to forward it, or provide text after the number.\n\nUsage: .forward <number> [text]");
      }
    } catch (error22) {
      try {
        await value10.reply("❌ Forward failed: " + (error22.message || "Unknown error"));
      } catch (error23) {}
    }
  }
};
