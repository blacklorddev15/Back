const database = require("../../database");
const getMode = () => database.getAntieditMode();
const setMode = value1 => database.setAntieditMode(value1);
const getTimezone = () => database.getTimeZone();
const messageStore = new Map();
function storeMessage(value2) {
  try {
    if (!value2?.key?.id || !value2.message) {
      return;
    }
    const value3 = value2.key.remoteJid;
    const value4 = value2.key.participant || value2.key.remoteJid;
    const value5 = value2.message;
    const value6 = value5.conversation || value5.extendedTextMessage?.text || value5.ephemeralMessage?.message?.conversation || value5.ephemeralMessage?.message?.extendedTextMessage?.text || null;
    if (!value6) {
      return;
    }
    if (!messageStore.has(value3)) {
      messageStore.set(value3, new Map());
    }
    const value7 = messageStore.get(value3);
    value7.set(value2.key.id, {
      sender: value4,
      timestamp: value2.messageTimestamp,
      text: value6,
      pushName: value2.pushName || null
    });
    if (value7.size > 300) {
      value7.delete(value7.keys().next().value);
    }
  } catch (error8) {}
}
function botSelfJid(value9) {
  const value10 = value9.user?.id;
  if (!value10) {
    return null;
  }
  if (value10.includes(":")) {
    return value10.split(":")[0] + "@s.whatsapp.net";
  } else {
    return value10;
  }
}
async function handleAntiEdit(value11, value12) {
  const value13 = getMode();
  if (value13 === "off") {
    return;
  }
  const value14 = botSelfJid(value11);
  for (const {
    key: value15,
    update: value16
  } of value12) {
    try {
      const value17 = value16?.message?.protocolMessage;
      const value18 = value17?.editedMessage || value16?.message?.editedMessage?.message || null;
      if (!value18) {
        continue;
      }
      const value19 = value15.remoteJid;
      const value20 = value17?.key?.id || value15.id;
      const value21 = value13 === "pm" && value14 ? value14 : value19;
      const value22 = messageStore.get(value19)?.get(value20);
      const value23 = value22?.text || null;
      const value24 = value22?.sender || value15.participant || value15.remoteJid || "";
      const value25 = value24.includes(":") ? value24.split(":")[0] + "@s.whatsapp.net" : value24;
      const value26 = value25.split("@")[0];
      const value27 = value18.conversation || value18.extendedTextMessage?.text || null;
      if (!value27) {
        continue;
      }
      if (value23 && value23 === value27) {
        continue;
      }
      const value28 = value22?.timestamp ? new Date(value22.timestamp * 1000).toLocaleString("en-GB", {
        hour12: false,
        timeZone: getTimezone(),
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      }) : new Date().toLocaleString();
      const value29 = value19.endsWith("@g.us");
      const value30 = value21 !== value19 ? "\n💬 *" + (value29 ? "Group" : "DM") + ":* " + value19.split("@")[0] : "";
      const value31 = value29 ? "👥 Group" : "💬 Private Chat";
      const value32 = String.fromCharCode(8206).repeat(4001);
      const value33 = "✏️ *EDITED MESSAGE* ✏️\n━━━━━━━━━━━━━━━━━━━━\n" + ("👤 *Sender:* @" + value26 + "\n") + ("📌 *Chat:* " + value31 + "\n") + ("🕐 *Time:* " + value28) + value30 + "\n" + ("━━━━━━━━━━━━━━━━━━━━\n" + value32 + "\n") + ("📝 *Original:*\n" + (value23 || "_Empty_") + "\n\n") + ("📝 *Edited to:*\n" + value27 + "\n") + "━━━━━━━━━━━━━━━━━━━━";
      await value11.sendMessage(value21, {
        text: value33,
        mentions: value25 ? [value25] : []
      });
      if (value22) {
        messageStore.get(value19).get(value20).text = value27;
      }
    } catch (error34) {
      console.error("[ANTIEDIT] error:", error34.message);
    }
  }
}
module.exports = {
  name: "antiedit",
  aliases: ["antieditmsg", "editdetect"],
  category: "owner",
  description: "Detect and reveal edited messages",
  usage: ".antiedit on | pm | chat | off | status",
  adminOnly: true,
  storeMessage: storeMessage,
  handleAntiEdit: handleAntiEdit,
  async execute(value35, value36, value37, value38) {
    const {
      reply: value39
    } = value38;
    const value40 = (value37[0] || "").toLowerCase();
    const value41 = getMode();
    const value42 = value41 === "chat" ? "✅ ON — Chat" : value41 === "pm" ? "✅ ON — PM" : "❌ OFF";
    if (!value40 || value40 === "status") {
      return value39("✏️ Anti-Edit: *" + value42 + "*\n\n.antiedit on | pm | chat | off");
    }
    if (value40 === "on" || value40 === "chat") {
      setMode("chat");
      return value39("✏️ Anti-Edit set to *ON* — edits revealed in chat.");
    }
    if (value40 === "pm") {
      setMode("pm");
      return value39("✏️ Anti-Edit set to *Private* — edits sent to bot self-chat.");
    }
    if (value40 === "off") {
      setMode("off");
      return value39("✏️ Anti-Edit set to *OFF*.");
    }
    return value39("⚠️ Usage: .antiedit on | pm | chat | off | status");
  }
};
