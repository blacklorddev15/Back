'use strict';

const FOOTER = "⚡ *Engineered by June_Ultra*";
let giftedBtns;
try {
  giftedBtns = require("gifted-btns");
} catch (error1) {
  giftedBtns = null;
}
async function resolveJid(value2, value3, value4 = null) {
  if (!value3) {
    return value3;
  }
  if (/@(g\.us|newsletter|s\.whatsapp\.net)$/.test(value3)) {
    return value3;
  }
  if (value3.endsWith("@lid")) {
    if (value4?.endsWith("@g.us")) {
      try {
        const value5 = (await value2.groupMetadata(value4)).participants?.find(value6 => value6.id === value3);
        if (value5?.phoneNumber) {
          return resolveJid(value2, value5.phoneNumber);
        }
      } catch (error7) {}
    }
    try {
      const value8 = await value2.signalRepository?.lidMapping?.getPNForLID?.(value3);
      if (value8) {
        return resolveJid(value2, value8);
      }
    } catch (error9) {}
    const value10 = global.lidPhoneCache?.get(value3.split("@")[0]);
    if (value10) {
      return value10 + "@s.whatsapp.net";
    } else {
      return value3;
    }
  }
  const value11 = value3.split("@")[0].split(":")[0].replace(/\D/g, "");
  if (value11.length >= 7) {
    return value11 + "@s.whatsapp.net";
  } else {
    return value3;
  }
}
async function sendJid(value12, value13, value14) {
  const value15 = value13.key.remoteJid;
  const value16 = "*JID*\n`" + value14 + "`\n" + FOOTER;
  if (giftedBtns?.sendInteractiveMessage) {
    try {
      return giftedBtns.sendInteractiveMessage(value12, value15, {
        text: value16,
        interactiveButtons: [{
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "📋 Copy JID",
            copy_code: value14
          })
        }]
      });
    } catch (error17) {}
  }
  return value12.sendMessage(value15, {
    text: value16
  }, {
    quoted: value13
  });
}
const command = {
  name: "getjid",
  aliases: ["jid", "id"],
  category: "utility",
  description: "Get the JID of a chat, user, group or channel",
  async execute(value18, value19, value20) {
    const value21 = value19.key.remoteJid;
    try {
      const value22 = value19.message?.extendedTextMessage?.contextInfo;
      const value23 = value22?.mentionedJid?.[0];
      const value24 = value22?.participant;
      let value25 = value21;
      if (value24 || value23) {
        value25 = await resolveJid(value18, value24 || value23, value21);
      } else if (value20.length) {
        const value26 = value20.join(" ");
        const value27 = value26.match(/(?:whatsapp\.com\/channel|chat\.whatsapp\.com\/channel)\/([\w-]+)/i);
        const value28 = value26.match(/chat\.whatsapp\.com\/([\w-]+)/i);
        if (value27) {
          value25 = (await value18.newsletterMetadata("invite", value27[1])).id;
        } else if (value28) {
          value25 = (await value18.groupGetInviteInfo(value28[1])).id;
        } else {
          value25 = await resolveJid(value18, value26, value21);
        }
      } else if (!value21.endsWith("@g.us")) {
        value25 = await resolveJid(value18, value19.key.participant || value21, value21);
      }
      return sendJid(value18, value19, value25);
    } catch (error29) {
      return value18.sendMessage(value21, {
        text: "❌ " + error29.message
      }, {
        quoted: value19
      });
    }
  },
  resolveJid: resolveJid
};
module.exports = command;
module.exports.resolveJid = resolveJid;
