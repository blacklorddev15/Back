const database = require("../../database");
module.exports = {
  name: "invite",
  aliases: ["invitelink", "sendinvite"],
  category: "owner",
  description: "Send the group invite link to a phone number via DM",
  usage: ".invite <number>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    const {
      from: value5,
      reply: value6,
      react: value7
    } = value4;
    if (!value5.endsWith("@g.us")) {
      return value6("❌ This command can only be used inside a group.");
    }
    if (!value3[0]) {
      return value6("❌ *Usage:* " + database.getBotSetting("prefix") + "invite <number>\n\nExample: " + database.getBotSetting("prefix") + "invite 254798952773");
    }
    const value8 = value3[0].replace(/\D/g, "");
    if (value8.length < 7) {
      return value6("❌ Invalid phone number. Include the country code, e.g. 254798952773");
    }
    const value9 = value8 + "@s.whatsapp.net";
    try {
      const value10 = await value1.groupInviteCode(value5);
      const value11 = "https://chat.whatsapp.com/" + value10;
      let value12 = "this group";
      try {
        const value13 = await value1.groupMetadata(value5);
        value12 = value13.subject || "this group";
      } catch (error14) {}
      await value1.sendMessage(value9, {
        text: "👋 You've been invited to join *" + value12 + "*!\n\n" + ("🔗 *Group Link:*\n" + value11 + "\n\n") + ("> Sent via " + (database.getBotSetting("botName") || "June-X Ultra"))
      });
      await value7("✅");
      await value6("✅ Invite link sent to *+" + value8 + "* for *" + value12 + "*.");
    } catch (error15) {
      console.error("[invite] Error:", error15);
      if (error15.message?.includes("not-authorized") || error15.message?.includes("forbidden")) {
        return value6("❌ Bot must be a group admin to fetch the invite link.");
      }
      await value6("❌ Failed to send invite: " + error15.message);
    }
  }
};
