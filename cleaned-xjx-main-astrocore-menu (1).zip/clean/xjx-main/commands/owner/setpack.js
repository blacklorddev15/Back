'use strict';

const database = require("../../database");
const flag = value1 => value1 === undefined || value1 === null || value1 === "" ? "_not set_" : "*" + value1 + "*";
function box(value2) {
  return "╭━━『 *Sticker Pack* 』━━╮\n\n" + value2.join("\n") + "\n\n╰━━━━━━━━━━━━━━━━━━╯";
}
function statusLines(value3) {
  return ["📦 *Pack name:* " + flag(database.getBotSetting("packname")), "✍️ *Author:* " + flag(database.getBotSetting("author")), "", "💡 *" + value3 + "setpack name <text>*", "💡 *" + value3 + "setpack author <text>*", "💡 *" + value3 + "setpack reset*"];
}
module.exports = {
  name: "setpack",
  aliases: ["setpackname", "stickerpack", "setstickerpack"],
  category: "owner",
  description: "Set the sticker pack name and author used on every sticker the bot makes",
  usage: ".setpack name <text> | .setpack author <text> | .setpack reset",
  ownerOnly: true,
  adminOnly: false,
  groupOnly: false,
  botAdminOnly: false,
  async execute(value4, value5, value6, value7) {
    try {
      const value8 = database.getBotSetting("prefix") || ".";
      const value9 = String(value6[0] || "").trim().toLowerCase();
      const value10 = value6.slice(1).join(" ").trim();
      if (!value9 || value9 === "status") {
        return value7.reply(box(statusLines(value8)));
      }
      if (value9 === "reset") {
        const value11 = database.BOT_SETTINGS_DEFAULTS;
        database.setBotSetting("packname", value11.packname);
        database.setBotSetting("author", value11.author);
        database.setBotSetting("stickerAuthor", value11.stickerAuthor);
        return value7.reply(box(["♻️ *Reset to defaults.*", "", ...statusLines(value8).slice(0, 2)]));
      }
      if (value9 !== "name" && value9 !== "author") {
        return value7.reply(box(["❌ *Unknown option.*", "", "Use *name*, *author* or *reset*.", "Example: *" + value8 + "setpack name My Pack*"]));
      }
      if (!value10) {
        return value7.reply(box(["⚠️ Provide a value.", "", "Example: *" + value8 + "setpack " + value9 + " " + (value9 === "name" ? "My Pack" : "My Name") + "*"]));
      }
      if (value10.length > 60) {
        return value7.reply(box(["❌ Too long. Maximum 60 characters."]));
      }
      if (value9 === "name") {
        database.setBotSetting("packname", value10);
      } else {
        database.setBotSetting("author", value10);
        database.setBotSetting("stickerAuthor", value10);
      }
      return value7.reply(box(["✅ *" + (value9 === "name" ? "Pack name" : "Author") + "* updated.", "", ...statusLines(value8).slice(0, 2), "", "_Make a sticker to see the change._"]));
    } catch (error12) {
      console.error("SetPack command error:", error12);
      return value7.reply(box(["❌ *Failed to update sticker pack*", "", error12.message]));
    }
  }
};
