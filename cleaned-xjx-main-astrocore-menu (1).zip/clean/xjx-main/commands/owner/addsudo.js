const database = require("../../database");
const {
  resolvePhone
} = require("../../utils/jidHelper");
async function resolveToPhone(value1, value2) {
  const value3 = await resolvePhone(value1, value2);
  if (value3) {
    return String(value3).replace(/\D/g, "");
  } else {
    return null;
  }
}
module.exports = {
  name: "addsudo",
  aliases: ["addmod", "setsudo"],
  category: "owner",
  description: "Add a sudo (moderator) user who can use owner-level commands",
  usage: ".addsudo @user or .addsudo number",
  ownerOnly: true,
  async execute(value4, value5, value6, value7) {
    const {
      from: value8,
      reply: value9,
      react: value10
    } = value7;
    const value11 = value5.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const value12 = value5.message?.extendedTextMessage?.contextInfo?.participant;
    let value13 = value11[0] || value12 || null;
    if (!value13 && value6[0]) {
      const value14 = value6[0].replace(/\D/g, "");
      if (value14.length >= 7) {
        value13 = value14 + "@s.whatsapp.net";
      }
    }
    if (!value13) {
      return value9("❌ *Usage:* " + database.getBotSetting("prefix") + "addsudo @user or " + database.getBotSetting("prefix") + "addsudo 254712345678");
    }
    let value15 = await resolveToPhone(value4, value13);
    if (!value15) {
      const value16 = value13.split("@")[0].split(":")[0];
      return value9("❌ Could not resolve LID @" + value16 + " to a phone number.\n\nTry using the phone number directly:\n" + database.getBotSetting("prefix") + "addsudo 254712345678");
    }
    if (database.isModerator(value15)) {
      return value4.sendMessage(value8, {
        text: "⚠️ @" + value15 + " is already a sudo user.",
        mentions: [value15 + "@s.whatsapp.net"]
      }, {
        quoted: value5
      });
    }
    database.addModerator(value15);
    await value10("✅");
    const value17 = value15 + "@s.whatsapp.net";
    await value4.sendMessage(value8, {
      text: "✅ *@" + value15 + "* has been added as a sudo user.\n\nThey can now use moderator-level commands.",
      mentions: [value17]
    }, {
      quoted: value5
    });
  }
};
