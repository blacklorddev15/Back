const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
module.exports = {
  name: "mygroups",
  aliases: ["groups", "grouplist", "listgroups"],
  category: "owner",
  description: "List all groups the bot is in. Reply with a number for group details.",
  usage: ".mygroups | .mygroups <number>",
  ownerOnly: true,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      const value6 = value2.key.participant || value2.key.remoteJid;
      const value7 = Array.isArray(database.getOwners()) ? database.getOwners() : [database.getOwners()];
      if (!value7.includes(value6) && !value2.key.fromMe) {
        await value1.sendMessage(value5, {
          react: {
            text: "❌",
            key: value2.key
          }
        });
        return value4.reply("❌ This command is restricted to bot owners.");
      }
      await value1.sendMessage(value5, {
        react: {
          text: "🔄",
          key: value2.key
        }
      });
      const value8 = await value1.groupFetchAllParticipating();
      const value9 = Object.values(value8).sort((value10, value11) => (value10.subject || "").localeCompare(value11.subject || ""));
      if (!value9.length) {
        await value1.sendMessage(value5, {
          react: {
            text: "❌",
            key: value2.key
          }
        });
        return value4.reply("❌ The bot is not in any groups.");
      }
      const value12 = value9.length;
      const value13 = value3[0];
      if (value13 && /^\d+$/.test(value13)) {
        const value14 = parseInt(value13) - 1;
        if (value14 < 0 || value14 >= value12) {
          return value4.reply("❌ Pick a number between 1 and " + value12 + ".");
        }
        const value15 = value9[value14];
        const value16 = value15.participants || [];
        const value17 = value16.filter(value18 => value18.admin).map(value19 => "@" + value19.id.split("@")[0].split(":")[0]);
        const value20 = value16.length;
        const value21 = value15.id;
        const value22 = value15.subject || "(no name)";
        const value23 = value15.desc ? value15.desc.trim() : "No description";
        const value24 = value15.creation ? new Date(value15.creation * 1000).toLocaleString("en-GB", {
          timeZone: database.getTimeZone()
        }) : "Unknown";
        const value25 = value16.find(value26 => {
          const value27 = (value1.user?.id || "").split("@")[0].split(":")[0];
          return value26.id.split("@")[0].split(":")[0] === value27;
        });
        const value28 = value25?.admin === "superadmin" ? "👑 Super Admin" : value25?.admin ? "🔰 Admin" : "👤 Member";
        const value29 = "━━━━━━━━━━━━━━━━━━━\n📋 *Group Details — #" + value13 + "*\n━━━━━━━━━━━━━━━━━━━\n\n🏷️  *Name:* " + value22 + "\n👥  *Members:* " + value20 + "\n🤖  *Bot role:* " + value28 + "\n📅  *Created:* " + value24 + "\n🧩  *GroupJid:* " + value21 + "\n📝  *Description:*\n" + value23 + "\n\n━━━━━━━━━━━━━━━━━━━";
        await sendButtons(value1, value5, {
          text: value29,
          footer: "> Powered by " + database.getBotSetting("botName"),
          buttons: [{
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
              display_text: "📋 Copy JID",
              copy_code: value21
            })
          }]
        }, {
          quoted: value2
        });
        await value1.sendMessage(value5, {
          react: {
            text: "✅",
            key: value2.key
          }
        });
        return;
      }
      let value30 = "📋 *Group List — " + value12 + " group" + (value12 !== 1 ? "s" : "") + "*\n\n";
      value9.forEach((value31, value32) => {
        const value33 = value32 + 1;
        const value34 = value31.subject || "(no name)";
        const value35 = value31.participants?.length ?? "?";
        value30 += "*" + value33 + ".* " + value34 + "\n";
        value30 += "   👥 " + value35 + " member" + (value35 !== 1 ? "s" : "") + "\n\n";
      });
      value30 += "_Total: " + value12 + " group" + (value12 !== 1 ? "s" : "") + "_\n\n";
      value30 += "💡 *Reply to this message with* `.mygroups <number>` *for group details + copy JID.*";
      await value1.sendMessage(value5, {
        text: value30
      }, {
        quoted: value2
      });
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error36) {
      console.error("[mygroups] error:", error36);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      await value4.reply("❌ Failed to fetch groups: " + error36.message);
    }
  }
};
