'use strict';

const database = require("../../database");
module.exports = {
  name: "anticallmsg",
  aliases: ["acmsg", "anticall-message"],
  category: "owner",
  ownerOnly: true,
  description: "Manage anti-call auto-reply messages",
  usage: ".anticallmsg <set|view|reset|off|presets|preset|test>",
  async execute(value1, value2, value3, value4) {
    const value5 = value3[0]?.toLowerCase().trim();
    if (!value5) {
      return value4.reply("📵 *Anti-Call Message Manager*\n\n`.anticallmsg set <text>` - Set custom message\n`.anticallmsg view` - View current message\n`.anticallmsg reset` - Use default message\n`.anticallmsg off` - Disable message sending\n`.anticallmsg presets` - Show preset messages\n`.anticallmsg preset <id>` - Use a preset\n`.anticallmsg test` - Send test message\n\n_Example: `.anticallmsg set Sorry, I don't take calls!`_\n_Aliases: `.acmsg`, `.am`_");
    }
    switch (value5) {
      case "set":
        return handleSet(value1, value2, value3, value4);
      case "view":
        return handleView(value1, value2, value4);
      case "reset":
        return handleReset(value1, value2, value4);
      case "off":
        return handleOff(value1, value2, value4);
      case "presets":
        return handlePresets(value1, value2, value4);
      case "preset":
        return handlePreset(value1, value2, value3, value4);
      case "test":
        return handleTest(value1, value2, value4);
      default:
        return value4.reply("❌ Unknown subcommand. Use `.anticallmsg` for help.");
    }
  }
};
async function handleSet(value6, value7, value8, value9) {
  const value10 = value8.slice(1).join(" ").trim();
  if (!value10) {
    return value9.reply("❌ Please provide a message.\n\nExample: `.anticallmsg set Sorry, I don't accept calls!`");
  }
  if (value10.length > 500) {
    return value9.reply("❌ Message is too long. Maximum 500 characters.");
  }
  try {
    const value11 = require("../../database");
    value11.setBotSetting("anticallMessage", value10);
    value11.setBotSetting("anticallNotify", true);
    return value9.reply("✅ *Custom message set!*\n\n\"" + value10 + "\"");
  } catch (error12) {
    console.error("[anticallmsg set]", error12.message);
    return value9.reply("❌ Failed to update message.");
  }
}
async function handleView(value13, value14, value15) {
  const value16 = database.getDefaultGroupSettings().anticallMessage;
  const value17 = database.getDefaultGroupSettings().anticallNotify;
  if (!value17) {
    return value15.reply("📵 *Message sending is disabled.*\n\nUse `.anticallmsg reset` to enable.");
  }
  if (value16) {
    return value15.reply("📝 *Current Custom Message:*\n\n\"" + value16 + "\"");
  }
  const value18 = database.ANTICALL_PRESETS[0];
  return value15.reply("📝 *Current Message (Default Preset):*\n\n" + (value18.emoji + " \"" + value18.message + "\""));
}
async function handleReset(value19, value20, value21) {
  try {
    const value22 = require("../../database");
    value22.setBotSetting("anticallMessage", value22.BOT_SETTINGS_DEFAULTS.anticallMessage);
    value22.setBotSetting("anticallNotify", value22.BOT_SETTINGS_DEFAULTS.anticallNotify);
    return value21.reply("✅ *Message reset to default preset.*\n\n📵 \"Sorry, I don't accept WhatsApp calls. Please send a message.\"");
  } catch (error23) {
    console.error("[anticallmsg reset]", error23.message);
    return value21.reply("❌ Failed to reset message.");
  }
}
async function handleOff(value24, value25, value26) {
  try {
    const value27 = require("../../database");
    value27.setBotSetting("anticallNotify", false);
    return value26.reply("✅ *Message sending disabled.*\n\nCalls will be declined without sending a message.");
  } catch (error28) {
    console.error("[anticallmsg off]", error28.message);
    return value26.reply("❌ Failed to update settings.");
  }
}
async function handlePresets(value29, value30, value31) {
  const value32 = database.ANTICALL_PRESETS;
  let value33 = "📋 *Available Presets:*\n\n";
  value32.forEach(value34 => {
    value33 += "*" + value34.id + ".* " + value34.emoji + " \"" + value34.message + "\"\n\n";
  });
  value33 += "_Use: `.anticallmsg preset <id>`_\n_Example: `.anticallmsg preset 3`_";
  return value31.reply(value33);
}
async function handlePreset(value35, value36, value37, value38) {
  const value39 = parseInt(value37[1]);
  const value40 = database.ANTICALL_PRESETS;
  if (!value39 || value39 < 1 || value39 > value40.length) {
    return value38.reply("❌ Invalid preset ID. Choose 1-" + value40.length + ".");
  }
  const value41 = value40.find(value42 => value42.id === value39);
  try {
    const value43 = require("../../database");
    value43.setBotSetting("anticallMessage", value41.message);
    value43.setBotSetting("anticallNotify", true);
    return value38.reply("✅ *Preset #" + value39 + " activated!*\n\n" + (value41.emoji + " \"" + value41.message + "\""));
  } catch (error44) {
    console.error("[anticallmsg preset]", error44.message);
    return value38.reply("❌ Failed to apply preset.");
  }
}
async function handleTest(value45, value46, value47) {
  const value48 = database.getDefaultGroupSettings().anticallMessage;
  const value49 = database.getDefaultGroupSettings().anticallNotify;
  if (!value49) {
    return value47.reply("📵 *Message sending is disabled.*\n\nEnable it first with `.anticallmsg reset` or `.anticallmsg set`.");
  }
  const value50 = value48 || database.ANTICALL_PRESETS[0].message;
  try {
    await value45.sendMessage(value46.key.remoteJid, {
      text: "🧪 *Test Message Preview:*\n\n\"" + value50 + "\""
    });
    return value47.reply("✅ Test message sent! Check the chat above.");
  } catch (error51) {
    console.error("[anticallmsg test]", error51.message);
    return value47.reply("❌ Failed to send test message.");
  }
}
