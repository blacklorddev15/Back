const {
  sendButtons
} = require("gifted-btns");
function getChannelInviteCode(value1) {
  try {
    let value2 = value1.trim();
    value2 = value2.split("?")[0].split("#")[0];
    try {
      const value3 = new URL(value2);
      const value4 = value3.pathname.split("/").filter(Boolean);
      const value5 = value4[value4.length - 1];
      if (value5 && value5.length > 0) {
        return value5;
      }
    } catch (error6) {}
    const value7 = [/(?:whatsapp\.com|wa\.me)\/channel\/([A-Za-z0-9]+)/i, /\/channel\/([A-Za-z0-9]+)/i, /channel\/([A-Za-z0-9]+)/i];
    for (const value8 of value7) {
      const value9 = value2.match(value8);
      if (value9 && value9[1]) {
        return value9[1];
      }
    }
    if (/^[A-Za-z0-9]+$/.test(value2)) {
      return value2;
    }
    return null;
  } catch (error10) {
    console.error("Error extracting invite code:", error10);
    return null;
  }
}
module.exports = {
  name: "newsletter",
  aliases: ["channel", "channelinfo", "nl"],
  category: "owner",
  description: "Get newsletter information from WhatsApp channel link",
  usage: ".newsletter <channel link>",
  ownerOnly: true,
  async execute(value11, value12, value13, value14) {
    try {
      const value15 = value14.from;
      let value16 = value13 && value13.length > 0 ? value13.join(" ").trim() : "";
      if (!value16) {
        return value14.reply("❌ Please provide a WhatsApp channel link!\n\nExample: .newsletter https://whatsapp.com/channel/0029VaAbCdEfGhIJkL");
      }
      const value17 = getChannelInviteCode(value16);
      if (!value17) {
        return value14.reply("❌ Could not extract invite code from the link!\n\nPlease provide a valid WhatsApp channel link.\nExample: https://whatsapp.com/channel/0029VaAbCdEfGhIJkL\n\nOr just the invite code: .newsletter 0029VaAbCdEfGhIJkL");
      }
      value16 = value17;
      try {
        const value18 = await value11.newsletterMetadata("invite", value16);
        if (!value18) {
          throw new Error("Newsletter not found");
        }
        const value19 = value18.invite || value17;
        const value20 = "https://whatsapp.com/channel/" + value19;
        let value21 = "┏━━『 *NEWSLETTER INFO* 』━━\n\n" + ("🆔 *ID:* " + (value18.id || "N/A") + "\n");
        if (value18.name) {
          value21 += "📛 *Name:* " + value18.name + "\n";
        }
        if (value18.description) {
          value21 += "📝 *Description:* " + value18.description + "\n";
        }
        if (value18.invite) {
          value21 += "🔗 *Invite Code:* " + value18.invite + "\n";
        }
        if (value18.subscriberCount !== undefined) {
          value21 += "👥 *Subscribers:* " + value18.subscriberCount.toLocaleString() + "\n";
        }
        if (value18.creationTime) {
          const value22 = new Date(value18.creationTime * 1000);
          value21 += "📅 *Created:* " + value22.toLocaleDateString() + " " + value22.toLocaleTimeString() + "\n";
        }
        value21 += "\n┗━━━━━━━━━━━━━━━━";
        const value23 = [{
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🌐 Open Channel",
            url: value20
          })
        }, {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "🔑 Copy Newsletter",
            copy_code: value18.id
          })
        }];
        if (value18.image) {
          await value11.sendMessage(value15, {
            image: {
              url: value18.image
            },
            caption: value21
          }, {
            quoted: value12
          });
          await sendButtons(value11, value15, {
            text: "> Use the buttons below:",
            footer: "> Newsletter Info",
            buttons: value23
          }, {
            quoted: value12
          });
        } else {
          await sendButtons(value11, value15, {
            text: value21,
            footer: "> Newsletter Info",
            buttons: value23
          }, {
            quoted: value12
          });
        }
      } catch (error24) {
        console.error("Newsletter command error:", error24);
        if (error24.message.includes("Invalid channel link")) {
          await value14.reply("❌ Invalid channel link format!\n\nPlease provide a valid WhatsApp channel link.\nExample: https://whatsapp.com/channel/0029VaAbCdEfGhIJkL");
        } else if (error24.message.includes("Newsletter not found")) {
          await value14.reply("❌ Newsletter not found!\n\nThe channel link might be invalid or the newsletter might not exist.");
        } else if (error24.message.includes("newsletterMetadata")) {
          await value14.reply("❌ Newsletter feature not available!\n\nMake sure you are using Baileys v7.0.0-rc or higher.");
        } else {
          await value14.reply("❌ Failed to get newsletter information: " + error24.message);
        }
      }
    } catch (error25) {
      console.error("Newsletter command error:", error25);
      await value14.reply("❌ An error occurred: " + error25.message);
    }
  }
};
