'use strict';

const stealthMode = require("../../utils/stealthMode");
module.exports = {
  name: "stealth",
  aliases: ["stealthmode", "ghost", "ghostmode"],
  category: "owner",
  ownerOnly: true,
  description: "Toggle complete stealth (no presence, no read receipts)",
  usage: ".stealth <on|off>",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = (value3[0] || "").toLowerCase().trim();
      if (!value5 || !["on", "off"].includes(value5)) {
        const value6 = stealthMode.isEnabled();
        return value4.reply("👻 *Stealth Mode:* " + (value6 ? "ON ✅" : "OFF ❌") + "\n\n*Usage:* .stealth <on|off>\n\n*What it does:*\n• Blocks all presence updates (typing, recording, online, last seen)\n• Blocks all read receipts (chats and statuses)\n• Bot connects without the \"online\" mark\n\n*While stealth is ON:*\n✓ No \"typing…\" indicator\n✓ No \"online\" status\n✓ Chats stay grey-ticked (no blue doubles)\n\n_autotyping, autorecording, alwaysonline and autoread are muted while stealth is on — their settings are kept and resume when you turn stealth off._");
      }
      const value7 = value5 === "on";
      stealthMode.setEnabled(value7);
      if (value7) {
        try {
          await value1.sendPresenceUpdate("unavailable");
        } catch (error8) {}
        return value4.reply("👻 *Stealth Mode: ON*\n\n✓ Bot is now completely invisible\n✓ No presence updates\n✓ No read receipts\n\n_Use .stealth off when you want presence again._");
      }
      return value4.reply("👻 *Stealth Mode: OFF*\n\n✓ Presence updates enabled\n✓ Read receipts enabled\n\n_autotyping / autorecording / alwaysonline / autoread resume their own settings now._");
    } catch (error9) {
      await value4.reply("❌ Error: " + error9.message);
    }
  }
};
