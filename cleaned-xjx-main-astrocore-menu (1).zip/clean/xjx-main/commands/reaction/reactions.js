const axios = require("axios");
const NEKOS_ENDPOINTS = new Set(["hug", "kiss", "pat", "slap", "cry", "wave", "poke", "cuddle", "smile", "laugh", "dance", "happy", "wink", "blush", "bite", "bored", "facepalm", "feed", "handhold", "highfive", "kick", "kill", "punch", "shoot", "shrug", "sleep", "stare", "tickle", "yeet", "nom", "bonk", "glomp", "angry", "nod", "run", "smug"]);
const NEKOS_NAME_MAP = {
  thinking: "think",
  kick3: "kick"
};
const fetchReactionImage = async ({
  sock: value1,
  msg: value2,
  extra: value3,
  command: value4
}) => {
  const value5 = value3.from || value2.key.remoteJid;
  try {
    let value6 = null;
    const value7 = NEKOS_NAME_MAP[value4] || value4;
    if (NEKOS_ENDPOINTS.has(value7)) {
      try {
        const {
          data: value8
        } = await axios.get("https://nekos.best/api/v2/" + value7, {
          timeout: 15000
        });
        value6 = value8?.results?.[0]?.url || null;
      } catch (error9) {}
    }
    if (!value6) {
      try {
        const {
          data: value10
        } = await axios.get("https://api.waifu.pics/sfw/" + value4, {
          timeout: 15000
        });
        value6 = value10?.url || null;
      } catch (error11) {}
    }
    if (!value6) {
      throw new Error("No image URL returned from any source");
    }
    const value12 = await axios.get(value6, {
      responseType: "arraybuffer",
      timeout: 20000
    });
    const value13 = Buffer.from(value12.data);
    const value14 = value4.replace(/[0-9]/g, "").replace(/_/g, " ");
    await value1.sendMessage(value5, {
      image: value13,
      caption: "_" + (value14.charAt(0).toUpperCase() + value14.slice(1)) + "_"
    }, {
      quoted: value2
    });
  } catch (error15) {
    await value3.reply(global.mess?.error || "❌ Failed to fetch reaction image.");
  }
};
module.exports = [{
  command: ["kiss", "cium", "beso"],
  name: "kiss",
  category: "reaction",
  description: "Send a kiss reaction GIF",
  usage: ".kiss",
  execute: async (value16, value17, value18, value19) => {
    await fetchReactionImage({
      sock: value16,
      msg: value17,
      extra: value19,
      command: "kiss"
    });
  }
}, {
  command: ["cry"],
  name: "cry",
  category: "reaction",
  description: "Send a cry reaction GIF",
  usage: ".cry",
  execute: async (value20, value21, value22, value23) => {
    await fetchReactionImage({
      sock: value20,
      msg: value21,
      extra: value23,
      command: "cry"
    });
  }
}, {
  command: ["blush"],
  name: "blush",
  category: "reaction",
  description: "Send a blush reaction GIF",
  usage: ".blush",
  execute: async (value24, value25, value26, value27) => {
    await fetchReactionImage({
      sock: value24,
      msg: value25,
      extra: value27,
      command: "blush"
    });
  }
}, {
  command: ["dance"],
  name: "dance",
  category: "reaction",
  description: "Send a dance reaction GIF",
  usage: ".dance",
  execute: async (value28, value29, value30, value31) => {
    await fetchReactionImage({
      sock: value28,
      msg: value29,
      extra: value31,
      command: "dance"
    });
  }
}, {
  command: ["killgif"],
  name: "killgif",
  category: "reaction",
  description: "Send a kill reaction GIF",
  usage: ".killgif",
  execute: async (value32, value33, value34, value35) => {
    await fetchReactionImage({
      sock: value32,
      msg: value33,
      extra: value35,
      command: "kill"
    });
  }
}, {
  command: ["hug"],
  name: "hug",
  category: "reaction",
  description: "Send a hug reaction GIF",
  usage: ".hug",
  execute: async (value36, value37, value38, value39) => {
    await fetchReactionImage({
      sock: value36,
      msg: value37,
      extra: value39,
      command: "hug"
    });
  }
}, {
  command: ["kickgif", "kick3"],
  name: "kickgif",
  category: "reaction",
  description: "Send a kick reaction GIF",
  usage: ".kickgif",
  execute: async (value40, value41, value42, value43) => {
    await fetchReactionImage({
      sock: value40,
      msg: value41,
      extra: value43,
      command: "kick"
    });
  }
}, {
  command: ["slap"],
  name: "slap",
  category: "reaction",
  description: "Send a slap reaction GIF",
  usage: ".slap",
  execute: async (value44, value45, value46, value47) => {
    await fetchReactionImage({
      sock: value44,
      msg: value45,
      extra: value47,
      command: "slap"
    });
  }
}, {
  command: ["happy"],
  name: "happy",
  category: "reaction",
  description: "Send a happy reaction GIF",
  usage: ".happy",
  execute: async (value48, value49, value50, value51) => {
    await fetchReactionImage({
      sock: value48,
      msg: value49,
      extra: value51,
      command: "happy"
    });
  }
}, {
  command: ["bully"],
  name: "bully",
  category: "reaction",
  description: "Send a bully reaction GIF",
  usage: ".bully",
  execute: async (value52, value53, value54, value55) => {
    await fetchReactionImage({
      sock: value52,
      msg: value53,
      extra: value55,
      command: "bully"
    });
  }
}, {
  command: ["pat", "headpat"],
  name: "pat",
  category: "reaction",
  description: "Send a head pat reaction GIF",
  usage: ".pat",
  execute: async (value56, value57, value58, value59) => {
    await fetchReactionImage({
      sock: value56,
      msg: value57,
      extra: value59,
      command: "pat"
    });
  }
}, {
  command: ["wink"],
  name: "wink",
  category: "reaction",
  description: "Send a wink reaction GIF",
  usage: ".wink",
  execute: async (value60, value61, value62, value63) => {
    await fetchReactionImage({
      sock: value60,
      msg: value61,
      extra: value63,
      command: "wink"
    });
  }
}, {
  command: ["poke"],
  name: "poke",
  category: "reaction",
  description: "Send a poke reaction GIF",
  usage: ".poke",
  execute: async (value64, value65, value66, value67) => {
    await fetchReactionImage({
      sock: value64,
      msg: value65,
      extra: value67,
      command: "poke"
    });
  }
}, {
  command: ["cuddle"],
  name: "cuddle",
  category: "reaction",
  description: "Send a cuddle reaction GIF",
  usage: ".cuddle",
  execute: async (value68, value69, value70, value71) => {
    await fetchReactionImage({
      sock: value68,
      msg: value69,
      extra: value71,
      command: "cuddle"
    });
  }
}, {
  command: ["highfive", "hi5"],
  name: "highfive",
  category: "reaction",
  description: "Send a high five reaction GIF",
  usage: ".highfive",
  execute: async (value72, value73, value74, value75) => {
    await fetchReactionImage({
      sock: value72,
      msg: value73,
      extra: value75,
      command: "highfive"
    });
  }
}, {
  command: ["smile"],
  name: "smile",
  category: "reaction",
  description: "Send a smile reaction GIF",
  usage: ".smile",
  execute: async (value76, value77, value78, value79) => {
    await fetchReactionImage({
      sock: value76,
      msg: value77,
      extra: value79,
      command: "smile"
    });
  }
}, {
  command: ["wave"],
  name: "wave",
  category: "reaction",
  description: "Send a wave reaction GIF",
  usage: ".wave",
  execute: async (value80, value81, value82, value83) => {
    await fetchReactionImage({
      sock: value80,
      msg: value81,
      extra: value83,
      command: "wave"
    });
  }
}, {
  command: ["bite"],
  name: "bite",
  category: "reaction",
  description: "Send a bite reaction GIF",
  usage: ".bite",
  execute: async (value84, value85, value86, value87) => {
    await fetchReactionImage({
      sock: value84,
      msg: value85,
      extra: value87,
      command: "bite"
    });
  }
}, {
  command: ["lick"],
  name: "lick",
  category: "reaction",
  description: "Send a lick reaction GIF",
  usage: ".lick",
  execute: async (value88, value89, value90, value91) => {
    await fetchReactionImage({
      sock: value88,
      msg: value89,
      extra: value91,
      command: "lick"
    });
  }
}, {
  command: ["bonk"],
  name: "bonk",
  category: "reaction",
  description: "Send a bonk reaction GIF",
  usage: ".bonk",
  execute: async (value92, value93, value94, value95) => {
    await fetchReactionImage({
      sock: value92,
      msg: value93,
      extra: value95,
      command: "bonk"
    });
  }
}, {
  command: ["yeet"],
  name: "yeet",
  category: "reaction",
  description: "Send a yeet reaction GIF",
  usage: ".yeet",
  execute: async (value96, value97, value98, value99) => {
    await fetchReactionImage({
      sock: value96,
      msg: value97,
      extra: value99,
      command: "yeet"
    });
  }
}, {
  command: ["glomp"],
  name: "glomp",
  category: "reaction",
  description: "Send a glomp reaction GIF",
  usage: ".glomp",
  execute: async (value100, value101, value102, value103) => {
    await fetchReactionImage({
      sock: value100,
      msg: value101,
      extra: value103,
      command: "glomp"
    });
  }
}, {
  command: ["stab"],
  name: "stab",
  category: "reaction",
  description: "Send a stab reaction GIF",
  usage: ".stab",
  execute: async (value104, value105, value106, value107) => {
    await fetchReactionImage({
      sock: value104,
      msg: value105,
      extra: value107,
      command: "stab"
    });
  }
}, {
  command: ["nom"],
  name: "nom",
  category: "reaction",
  description: "Send a nom reaction GIF",
  usage: ".nom",
  execute: async (value108, value109, value110, value111) => {
    await fetchReactionImage({
      sock: value108,
      msg: value109,
      extra: value111,
      command: "nom"
    });
  }
}, {
  command: ["tickle"],
  name: "tickle",
  category: "reaction",
  description: "Send a tickle reaction GIF",
  usage: ".tickle",
  execute: async (value112, value113, value114, value115) => {
    await fetchReactionImage({
      sock: value112,
      msg: value113,
      extra: value115,
      command: "tickle"
    });
  }
}, {
  command: ["throw"],
  name: "throw",
  category: "reaction",
  description: "Send a throw reaction GIF",
  usage: ".throw",
  execute: async (value116, value117, value118, value119) => {
    await fetchReactionImage({
      sock: value116,
      msg: value117,
      extra: value119,
      command: "throw"
    });
  }
}, {
  command: ["facepalm"],
  name: "facepalm",
  category: "reaction",
  description: "Send a facepalm reaction GIF",
  usage: ".facepalm",
  execute: async (value120, value121, value122, value123) => {
    await fetchReactionImage({
      sock: value120,
      msg: value121,
      extra: value123,
      command: "facepalm"
    });
  }
}, {
  command: ["feed"],
  name: "feed",
  category: "reaction",
  description: "Send a feed reaction GIF",
  usage: ".feed",
  execute: async (value124, value125, value126, value127) => {
    await fetchReactionImage({
      sock: value124,
      msg: value125,
      extra: value127,
      command: "feed"
    });
  }
}, {
  command: ["spank"],
  name: "spank",
  category: "reaction",
  description: "Send a spank reaction GIF",
  usage: ".spank",
  execute: async (value128, value129, value130, value131) => {
    await fetchReactionImage({
      sock: value128,
      msg: value129,
      extra: value131,
      command: "spank"
    });
  }
}, {
  command: ["handhold", "holdhands"],
  name: "handhold",
  category: "reaction",
  description: "Send a handhold reaction GIF",
  usage: ".handhold",
  execute: async (value132, value133, value134, value135) => {
    await fetchReactionImage({
      sock: value132,
      msg: value133,
      extra: value135,
      command: "handhold"
    });
  }
}, {
  command: ["shoot"],
  name: "shoot",
  category: "reaction",
  description: "Send a shoot reaction GIF",
  usage: ".shoot",
  execute: async (value136, value137, value138, value139) => {
    await fetchReactionImage({
      sock: value136,
      msg: value137,
      extra: value139,
      command: "shoot"
    });
  }
}, {
  command: ["punch"],
  name: "punch",
  category: "reaction",
  description: "Send a punch reaction GIF",
  usage: ".punch",
  execute: async (value140, value141, value142, value143) => {
    await fetchReactionImage({
      sock: value140,
      msg: value141,
      extra: value143,
      command: "punch"
    });
  }
}, {
  command: ["stare"],
  name: "stare",
  category: "reaction",
  description: "Send a stare reaction GIF",
  usage: ".stare",
  execute: async (value144, value145, value146, value147) => {
    await fetchReactionImage({
      sock: value144,
      msg: value145,
      extra: value147,
      command: "stare"
    });
  }
}, {
  command: ["comfort"],
  name: "comfort",
  category: "reaction",
  description: "Send a comfort reaction GIF",
  usage: ".comfort",
  execute: async (value148, value149, value150, value151) => {
    await fetchReactionImage({
      sock: value148,
      msg: value149,
      extra: value151,
      command: "comfort"
    });
  }
}, {
  command: ["boop", "boopnose"],
  name: "boop",
  category: "reaction",
  description: "Send a boop reaction GIF",
  usage: ".boop",
  execute: async (value152, value153, value154, value155) => {
    await fetchReactionImage({
      sock: value152,
      msg: value153,
      extra: value155,
      command: "boop"
    });
  }
}, {
  command: ["sleep"],
  name: "sleep",
  category: "reaction",
  description: "Send a sleep reaction GIF",
  usage: ".sleep",
  execute: async (value156, value157, value158, value159) => {
    await fetchReactionImage({
      sock: value156,
      msg: value157,
      extra: value159,
      command: "sleep"
    });
  }
}, {
  command: ["shrug"],
  name: "shrug",
  category: "reaction",
  description: "Send a shrug reaction GIF",
  usage: ".shrug",
  execute: async (value160, value161, value162, value163) => {
    await fetchReactionImage({
      sock: value160,
      msg: value161,
      extra: value163,
      command: "shrug"
    });
  }
}, {
  command: ["sip"],
  name: "sip",
  category: "reaction",
  description: "Send a sip reaction GIF",
  usage: ".sip",
  execute: async (value164, value165, value166, value167) => {
    await fetchReactionImage({
      sock: value164,
      msg: value165,
      extra: value167,
      command: "sip"
    });
  }
}, {
  command: ["clap"],
  name: "clap",
  category: "reaction",
  description: "Send a clap reaction GIF",
  usage: ".clap",
  execute: async (value168, value169, value170, value171) => {
    await fetchReactionImage({
      sock: value168,
      msg: value169,
      extra: value171,
      command: "clap"
    });
  }
}, {
  command: ["nervous"],
  name: "nervous",
  category: "reaction",
  description: "Send a nervous reaction GIF",
  usage: ".nervous",
  execute: async (value172, value173, value174, value175) => {
    await fetchReactionImage({
      sock: value172,
      msg: value173,
      extra: value175,
      command: "nervous"
    });
  }
}, {
  command: ["scream"],
  name: "scream",
  category: "reaction",
  description: "Send a scream reaction GIF",
  usage: ".scream",
  execute: async (value176, value177, value178, value179) => {
    await fetchReactionImage({
      sock: value176,
      msg: value177,
      extra: value179,
      command: "scream"
    });
  }
}, {
  command: ["pout"],
  name: "pout",
  category: "reaction",
  description: "Send a pout reaction GIF",
  usage: ".pout",
  execute: async (value180, value181, value182, value183) => {
    await fetchReactionImage({
      sock: value180,
      msg: value181,
      extra: value183,
      command: "pout"
    });
  }
}, {
  command: ["bored"],
  name: "bored",
  category: "reaction",
  description: "Send a bored reaction GIF",
  usage: ".bored",
  execute: async (value184, value185, value186, value187) => {
    await fetchReactionImage({
      sock: value184,
      msg: value185,
      extra: value187,
      command: "bored"
    });
  }
}, {
  command: ["laugh"],
  name: "laugh",
  category: "reaction",
  description: "Send a laugh reaction GIF",
  usage: ".laugh",
  execute: async (value188, value189, value190, value191) => {
    await fetchReactionImage({
      sock: value188,
      msg: value189,
      extra: value191,
      command: "laugh"
    });
  }
}, {
  command: ["shy"],
  name: "shy",
  category: "reaction",
  description: "Send a shy reaction GIF",
  usage: ".shy",
  execute: async (value192, value193, value194, value195) => {
    await fetchReactionImage({
      sock: value192,
      msg: value193,
      extra: value195,
      command: "shy"
    });
  }
}, {
  command: ["confused"],
  name: "confused",
  category: "reaction",
  description: "Send a confused reaction GIF",
  usage: ".confused",
  execute: async (value196, value197, value198, value199) => {
    await fetchReactionImage({
      sock: value196,
      msg: value197,
      extra: value199,
      command: "confused"
    });
  }
}, {
  command: ["angry"],
  name: "angry",
  category: "reaction",
  description: "Send an angry reaction GIF",
  usage: ".angry",
  execute: async (value200, value201, value202, value203) => {
    await fetchReactionImage({
      sock: value200,
      msg: value201,
      extra: value203,
      command: "angry"
    });
  }
}, {
  command: ["excited"],
  name: "excited",
  category: "reaction",
  description: "Send an excited reaction GIF",
  usage: ".excited",
  execute: async (value204, value205, value206, value207) => {
    await fetchReactionImage({
      sock: value204,
      msg: value205,
      extra: value207,
      command: "excited"
    });
  }
}, {
  command: ["fear"],
  name: "fear",
  category: "reaction",
  description: "Send a fear reaction GIF",
  usage: ".fear",
  execute: async (value208, value209, value210, value211) => {
    await fetchReactionImage({
      sock: value208,
      msg: value209,
      extra: value211,
      command: "fear"
    });
  }
}, {
  command: ["surprised"],
  name: "surprised",
  category: "reaction",
  description: "Send a surprised reaction GIF",
  usage: ".surprised",
  execute: async (value212, value213, value214, value215) => {
    await fetchReactionImage({
      sock: value212,
      msg: value213,
      extra: value215,
      command: "surprised"
    });
  }
}, {
  command: ["thinking"],
  name: "thinking",
  category: "reaction",
  description: "Send a thinking reaction GIF",
  usage: ".thinking",
  execute: async (value216, value217, value218, value219) => {
    await fetchReactionImage({
      sock: value216,
      msg: value217,
      extra: value219,
      command: "thinking"
    });
  }
}, {
  command: ["embarrassed"],
  name: "embarrassed",
  category: "reaction",
  description: "Send an embarrassed reaction GIF",
  usage: ".embarrassed",
  execute: async (value220, value221, value222, value223) => {
    await fetchReactionImage({
      sock: value220,
      msg: value221,
      extra: value223,
      command: "embarrassed"
    });
  }
}, {
  command: ["tired"],
  name: "tired",
  category: "reaction",
  description: "Send a tired reaction GIF",
  usage: ".tired",
  execute: async (value224, value225, value226, value227) => {
    await fetchReactionImage({
      sock: value224,
      msg: value225,
      extra: value227,
      command: "tired"
    });
  }
}, {
  command: ["sad"],
  name: "sad",
  category: "reaction",
  description: "Send a sad reaction GIF",
  usage: ".sad",
  execute: async (value228, value229, value230, value231) => {
    await fetchReactionImage({
      sock: value228,
      msg: value229,
      extra: value231,
      command: "sad"
    });
  }
}, {
  command: ["love"],
  name: "love",
  category: "reaction",
  description: "Send a love reaction GIF",
  usage: ".love",
  execute: async (value232, value233, value234, value235) => {
    await fetchReactionImage({
      sock: value232,
      msg: value233,
      extra: value235,
      command: "love"
    });
  }
}, {
  command: ["peace"],
  name: "peace",
  category: "reaction",
  description: "Send a peace reaction GIF",
  usage: ".peace",
  execute: async (value236, value237, value238, value239) => {
    await fetchReactionImage({
      sock: value236,
      msg: value237,
      extra: value239,
      command: "peace"
    });
  }
}, {
  command: ["victory", "victorysign"],
  name: "victory",
  category: "reaction",
  description: "Send a victory reaction GIF",
  usage: ".victory",
  execute: async (value240, value241, value242, value243) => {
    await fetchReactionImage({
      sock: value240,
      msg: value241,
      extra: value243,
      command: "victory"
    });
  }
}, {
  command: ["point"],
  name: "point",
  category: "reaction",
  description: "Send a point reaction GIF",
  usage: ".point",
  execute: async (value244, value245, value246, value247) => {
    await fetchReactionImage({
      sock: value244,
      msg: value245,
      extra: value247,
      command: "point"
    });
  }
}];
