'use strict';

const fs = require("fs");
const path = require("path");
const TicTacToe = require("../../utils/tictactoe");
const {
  sendRichApp,
  RICH_FALLBACK
} = require("../../utils/richApp");
const GAME_HTML = fs.readFileSync(path.join(__dirname, "ttt2-app.html"), "utf8");
const games = {};
const esc = value1 => String(value1).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const displayName = (value2, value3) => value3 || (value2 ? "••" + String(value2.split("@")[0]).slice(-4) : "Player");
function winLine(value4) {
  const value5 = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
  for (const value6 of value5) {
    if (value4[value6[0]] && value4[value6[0]] === value4[value6[1]] && value4[value6[1]] === value4[value6[2]]) {
      return value6;
    }
  }
  return null;
}
const CARD_CSS = "*{box-sizing:border-box}html,body{margin:0;width:100%;background:transparent;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;overflow-x:hidden}\nbody{padding:4px}.card{width:268px;margin:0;padding:12px;border-radius:18px;background:linear-gradient(160deg,#041f22 0%,#062e33 55%,#021417 100%);color:#d7fbf6;box-shadow:0 8px 24px #0009;border:1px solid #0e6e63;text-align:center}\nh1{margin:0;font-size:15px;letter-spacing:.5px;background:linear-gradient(90deg,#2dd4bf,#fbbf24);-webkit-background-clip:text;background-clip:text;color:transparent}\n.mode{margin:2px 0 10px;font-size:10px;color:#fbbf24;font-weight:700;letter-spacing:2px}\n.big{font-size:38px;margin:4px 0 2px}\n.wt{font-size:13.5px;font-weight:800;color:#fbbf24;letter-spacing:1px;margin:0 0 8px}\n.dur{font-size:12px;color:#a7e8de;line-height:1.55;margin:0}\n.dur b{color:#2dd4bf}\n.div{height:1px;margin:10px 6px;background:linear-gradient(90deg,transparent,#0e6e63,transparent)}\n.vs{display:flex;justify-content:space-between;font-size:11px;font-weight:700;margin:0 2px 8px}\n.vs span{max-width:108px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.vs .px{color:#2dd4bf}.vs .po{color:#fbbf24}\n#bd{width:216px;height:216px;margin:0 auto;display:grid;grid-template-columns:repeat(3,1fr);gap:8px}\n.cell{cursor:pointer;border-radius:14px;background:#06272b;border:1px solid #0e5f57;display:flex;align-items:center;justify-content:center;font-size:30px;font-weight:800;color:#2a5f57}\n.cell.x{color:#2dd4bf}.cell.o{color:#fbbf24}\n.cell.win{background:#0e5f57;box-shadow:0 0 16px #2dd4b788}\n.cell:active{transform:scale(.95);background:#0a3d38}\n@keyframes ttpulse{0%,100%{box-shadow:0 0 0 0 #2dd4b755}50%{box-shadow:0 0 0 6px #2dd4b71f}}\n.turn{animation:ttpulse 1.8s infinite}\n.turn{margin:10px 0 2px;font-size:13px;font-weight:700;color:#a7e8de;background:#06272b;border:1px solid #0e5f57;border-radius:10px;padding:8px}\n.fin{margin:10px 0 2px;font-size:14px;font-weight:800;border-radius:10px;padding:9px}\n.fin.win{color:#04262b;background:linear-gradient(135deg,#2dd4bf,#0d9488)}\n.fin.draw{color:#2b1a02;background:linear-gradient(135deg,#fbbf24,#d97706)}\n.fin.lose{color:#2b1a02;background:linear-gradient(135deg,#f87171,#b91c1c);color:#2b0505}\n.hint{margin:8px 0 0;font-size:10px;color:#5da99d}\n.hint b{color:#a7e8de}";
function shell(value7, value8, value9) {
  return "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>" + CARD_CSS + "</style></head><body><div class=\"card\">\n<h1>🎮 TIC-TAC-TOE 2</h1>\n<p class=\"mode\">" + value7 + "</p>\n" + value8 + "\n" + (value9 || "") + "\n</div></body></html>";
}
const COACH_JS = "<script>\n(function(){\nvar tip=document.createElement('div');\ntip.style.cssText='position:fixed;left:50%;bottom:18px;transform:translateX(-50%) translateY(20px);background:#0e5f57;color:#d7fbf6;font-size:12px;font-weight:700;padding:9px 14px;border-radius:999px;border:1px solid #2dd4bf;opacity:0;transition:all .25s;white-space:nowrap;z-index:9;box-shadow:0 4px 14px #000a;pointer-events:none';\ndocument.body.appendChild(tip);\nvar tm=null;\nfunction show(m){tip.textContent=m;tip.style.opacity='1';tip.style.transform='translateX(-50%) translateY(0)';if(tm)clearTimeout(tm);tm=setTimeout(function(){tip.style.opacity='0';tip.style.transform='translateX(-50%) translateY(20px)';},2200);}\nvar cells=document.querySelectorAll('.cell');\nfor(var i=0;i<cells.length;i++){(function(el){\n el.addEventListener('click',function(){\n  if(el.className.indexOf('win')>=0){show('🎉 game over — .ttt2 start for a rematch');return;}\n  var t=el.textContent;\n  if(t==='✖'||t==='◉'){show('taken — pick an empty number');return;}\n  show('✍ type '+t+' in the chat to play it');\n  el.style.transform='scale(.94)';setTimeout(function(){el.style.transform='';},160);\n });\n})(cells[i]);}\n})();\n</script>";
function boardHtml(value10) {
  const value11 = winLine(value10.board);
  let value12 = "";
  for (let value13 = 0; value13 < 9; value13++) {
    const value14 = value10.board[value13];
    const value15 = "cell" + (value14 === "X" ? " x" : value14 === "O" ? " o" : "") + (value11 && value11.includes(value13) ? " win" : "");
    value12 += "<div class=\"" + value15 + "\">" + (value14 === "X" ? "✖" : value14 === "O" ? "◉" : value13 + 1) + "</div>";
  }
  return "<div id=\"bd\">" + value12 + "</div>";
}
function stateCard(value16, value17) {
  const value18 = value16.game;
  const value19 = esc(displayName(value18.playerX, value16.pnameX));
  const value20 = esc(displayName(value18.playerO, value16.pnameO));
  const value21 = "<div class=\"vs\"><span class=\"px\">✖ " + value19 + "</span><span class=\"po\">◉ " + value20 + "</span></div>";
  let value22;
  if (value17) {
    value22 = "<div class=\"fin lose\">" + value17 + "</div>";
  } else if (value18.winner) {
    value22 = "<div class=\"fin win\">🎉 " + esc(value18.winner === value18.playerX ? value19 : value20) + " wins!</div>";
  } else if (value18.turns >= 9) {
    value22 = "<div class=\"fin draw\">🤝 It's a draw!</div>";
  } else {
    const value23 = value18.currentTurn === value18.playerX;
    value22 = "<div class=\"turn\">🎲 " + esc(displayName(value18.currentTurn, value23 ? value16.pnameX : value16.pnameO)) + "'s turn (" + (value23 ? "✖" : "◉") + ")</div>";
  }
  const value24 = value18.winner || value18.turns >= 9;
  const value25 = value24 ? "<p class=\"hint\">run <b>.ttt2 start</b> for a rematch</p>" : "<p class=\"hint\">⌨️ cards can't tap in PvP — <b>type</b> <b>1-9</b> in chat · <b>surrender</b> to give up</p>";
  return shell(value24 ? "GAME OVER" : value16.name ? "ROOM · " + esc(value16.name) : "PvP ROOM", value21 + boardHtml(value18) + value22 + value25, COACH_JS);
}
function waitingCard() {
  return shell("PvP ROOM", "<div class=\"big\">⏳</div>\n<div class=\"wt\">WAITING FOR AN OPPONENT</div>\n<p class=\"dur\">someone should type<br><b>.ttt2 start</b> to join you</p>\n<div class=\"div\"></div>\n<p class=\"dur\">or <b>.ttt2 cancel</b> to drop the room</p>");
}
function noticeCard(value26, value27, value28) {
  return shell("CARD MODE", "<div class=\"big\">" + value26 + "</div>\n<div class=\"wt\">" + value27 + "</div>\n<p class=\"dur\">" + value28 + "</p>");
}
async function sendCard(value29, value30, value31, value32, value33) {
  try {
    await sendRichApp(value29, value30, value32, value31);
  } catch (error34) {
    console.error("[ttt2] card unavailable:", error34.message);
    await value29.sendMessage(value31, {
      text: value33
    }, {
      quoted: value30
    }).catch(() => {});
  }
}
const INFO_HTML = "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>\n*{box-sizing:border-box}html,body{margin:0;width:100%;background:transparent;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;overflow-x:hidden}\nbody{padding:4px}.card{width:268px;margin:0;padding:14px 12px;border-radius:18px;background:linear-gradient(160deg,#041f22 0%,#062e33 55%,#021417 100%);color:#d7fbf6;box-shadow:0 8px 24px #0009;border:1px solid #0e6e63;text-align:center}\nh1{margin:0;font-size:16px;letter-spacing:.5px;background:linear-gradient(90deg,#2dd4bf,#fbbf24);-webkit-background-clip:text;background-clip:text;color:transparent}\n.mode{margin:3px 0 12px;font-size:10px;color:#fbbf24;font-weight:700;letter-spacing:2px}\n.row{display:flex;align-items:flex-start;text-align:left;background:#06272b;border:1px solid #0e5f57;border-radius:12px;padding:9px 10px;margin-bottom:8px}\n.cmd{flex:0 0 auto;font-family:monospace;font-size:12px;font-weight:700;color:#2dd4bf;background:#04262b;border:1px solid #0e5f57;border-radius:8px;padding:3px 7px;margin-right:8px}\n.what{font-size:11.5px;color:#a7e8de;line-height:1.45;padding-top:2px}\n.div{height:1px;margin:12px 6px;background:linear-gradient(90deg,transparent,#0e6e63,transparent)}\n.dur{font-size:11.5px;color:#a7e8de;line-height:1.5;text-align:center;margin:0}\n.dur b{color:#fbbf24}\n</style></head><body><div class=\"card\">\n<h1>🎮 TIC-TAC-TOE 2</h1>\n<p class=\"mode\">CARD MODE</p>\n<div class=\"row\"><span class=\"cmd\">.ttt2 start</span><span class=\"what\">open a room (another player runs the same to join)</span></div>\n<div class=\"row\"><span class=\"cmd\">.ttt2 bot</span><span class=\"what\">play against the bot</span></div>\n<div class=\"row\"><span class=\"cmd\">.ttt2 cancel</span><span class=\"what\">cancel your waiting/active game</span></div>\n<div class=\"div\"></div>\n<p class=\"dur\">During a game: type <b>1-9</b> to move, or <b>surrender</b> to give up.</p>\n</div></body></html>";
module.exports = {
  games: games,
  name: "ttt2",
  aliases: ["xo2", "tictactoebot"],
  category: "fun",
  description: "TEST: Tic-Tac-Toe 2 — fully card based (menu, rooms, board)",
  usage: ".ttt2",
  async execute(value35, value36, value37, value38) {
    try {
      const {
        sender: value39,
        from: value40,
        reply: value41
      } = value38;
      const value42 = value40 || value36.key.remoteJid;
      const value43 = value36.pushName || null;
      const value44 = (value37[0] || "").toLowerCase();
      if (!value44 || ["help", "menu", "info", "?"].includes(value44)) {
        await sendCard(value35, value36, value42, INFO_HTML, "🎮 *Tic-Tac-Toe2 card mode*\n▢ `.ttt2 start` – open a room\n▢ `.ttt2 bot` – play vs bot\n▢ `.ttt2 cancel` – cancel\nDuring a game: type *1-9* or *surrender*.");
        return;
      }
      const value45 = Object.values(games).find(value46 => value46.id.startsWith("ttt2") && [value46.game.playerX, value46.game.playerO].includes(value39));
      if (value44 === "cancel") {
        if (!value45) {
          await sendCard(value35, value36, value42, noticeCard("🤷", "NOT IN ANY GAME", "run <b>.ttt2 start</b> to open a room"), "❌ You are not in any game.");
          return;
        }
        delete games[value45.id];
        await sendCard(value35, value36, value42, noticeCard("🛑", "ROOM CLOSED", "your tic-tac-toe game was cancelled"), "🛑 Your tic-tac-toe game has been cancelled.");
        return;
      }
      if (value45 && value45.state === "PLAYING") {
        await sendCard(value35, value36, value42, noticeCard("🎮", "ALREADY IN A GAME", "type <b>surrender</b> to quit, or <b>.ttt2 cancel</b>"), "❌ You are still in a game. Type *surrender* to quit, or *.ttt2 cancel*.");
        return;
      }
      if (value45 && value45.state === "WAITING") {
        await sendCard(value35, value36, value42, noticeCard("⏳", "ROOM ALREADY WAITING", "type <b>.ttt2 cancel</b> to drop it"), "⏳ You already have a room waiting. Type *.ttt2 cancel* to drop it.");
        return;
      }
      if (value44 === "bot" || value44 === "cpu" || value44 === "ai") {
        try {
          await sendRichApp(value35, value36, GAME_HTML, value42);
        } catch (error47) {
          console.error("[ttt2] mini-app unavailable:", error47.message);
          await value35.sendMessage(value42, {
            text: RICH_FALLBACK("TIC-TAC-TOE 2")
          }, {
            quoted: value36
          }).catch(() => {});
        }
        return;
      }
      const value48 = value44 === "start" ? value37.slice(1).join(" ").trim() || "" : value37.join(" ").trim();
      const value49 = Object.values(games).find(value50 => value50.state === "WAITING" && value50.id.startsWith("ttt2") && (value48 ? value50.name === value48 : !value50.name));
      if (value49) {
        value49.o = value40;
        value49.game.playerO = value39;
        value49.pnameO = value43;
        value49.state = "PLAYING";
        await sendCard(value35, value36, value42, stateCard(value49), "🎮 Tic-Tac-Toe 2 Started!");
        return;
      }
      const value51 = {
        id: "ttt2-" + Date.now(),
        x: value40,
        o: "",
        game: new TicTacToe(value39, "o"),
        pnameX: value43,
        state: "WAITING"
      };
      if (value48) {
        value51.name = value48;
      }
      games[value51.id] = value51;
      await sendCard(value35, value36, value42, waitingCard(), "⏳ Waiting for an opponent… have someone type .ttt2 start to join.");
    } catch (error52) {
      console.error("Error in ttt2 command:", error52);
      await value38.reply("❌ Error starting game. Please try again.");
    }
  }
};
async function handleTtt2Move(value53, value54, value55) {
  try {
    const {
      sender: value56,
      from: value57
    } = value55;
    const value58 = (value54.message?.conversation || value54.message?.extendedTextMessage?.text || "").trim();
    const value59 = Object.values(games).find(value60 => value60.id.startsWith("ttt2") && [value60.game.playerX, value60.game.playerO].includes(value56) && value60.state === "PLAYING");
    if (!value59) {
      return false;
    }
    const value61 = /^(surrender|give up)$/i.test(value58);
    if (!value61 && !/^[1-9]$/.test(value58)) {
      return false;
    }
    if (value56 !== value59.game.currentTurn && !value61) {
      await sendCard(value53, value54, value57, noticeCard("✋", "NOT YOUR TURN", "wait for your turn — check the 🎲 banner"), "❌ Not your turn!");
      return true;
    }
    if (value61) {
      const value62 = value56 === value59.game.playerX;
      const value63 = value62 ? value59.pnameX : value59.pnameO;
      const value64 = value62 ? value59.pnameO : value59.pnameX;
      await sendCard(value53, value54, value59.x, stateCard(value59, "🏳️ " + esc(displayName(value56, value63)) + " surrendered — " + esc(displayName(value62 ? value59.game.playerO : value59.game.playerX, value64)) + " wins!"), "🏳️ Surrender — game over.");
      if (!value59.botMode && value59.x !== value59.o) {
        await sendCard(value53, value54, value59.o, stateCard(value59, "🏳️ " + esc(displayName(value56, value63)) + " surrendered!"), "🏳️ Surrender — game over.");
      }
      delete games[value59.id];
      return true;
    }
    const value65 = value59.game.turn(value56 === value59.game.playerO, parseInt(value58) - 1);
    if (!value65) {
      await sendCard(value53, value54, value57, noticeCard("✖", "CELL ALREADY TAKEN", "pick an empty number (1-9)"), "❌ Invalid move! That position is already taken.");
      return true;
    }
    await sendCard(value53, value54, value59.x, stateCard(value59), "🎮 Tic-Tac-Toe 2");
    if (value59.x !== value59.o) {
      await sendCard(value53, value54, value59.o, stateCard(value59), "🎮 Tic-Tac-Toe 2");
    }
    if (value59.game.winner || value59.game.turns === 9 && !value59.game.winner) {
      delete games[value59.id];
    }
    return true;
  } catch (error66) {
    console.error("Error in ttt2 move:", error66);
    return false;
  }
}
module.exports.handleTtt2Move = handleTtt2Move;
