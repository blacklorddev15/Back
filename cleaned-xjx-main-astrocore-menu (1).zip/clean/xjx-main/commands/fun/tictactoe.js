const TicTacToe = require("../../utils/tictactoe");
const BOT_ID = "bot@tictactoe.local";
const BOT_TAG = "🤖 Bot";
const games = {};
const SYMBOLS = {
  X: "❎",
  O: "⭕",
  "1": "1️⃣",
  "2": "2️⃣",
  "3": "3️⃣",
  "4": "4️⃣",
  "5": "5️⃣",
  "6": "6️⃣",
  "7": "7️⃣",
  "8": "8️⃣",
  "9": "9️⃣"
};
const renderBoard = value1 => {
  const value2 = value1.render().map(value3 => SYMBOLS[value3] || value3);
  return value2.slice(0, 3).join("") + "\n" + value2.slice(3, 6).join("") + "\n" + value2.slice(6).join("");
};
const playerLabel = value4 => value4 === BOT_ID ? BOT_TAG : "@" + value4.split("@")[0];
const mentionsOf = (...value5) => value5.filter(value6 => value6 && value6 !== BOT_ID);
function bestBotMove(value7, value8, value9) {
  const value10 = value7.slice();
  const value11 = value12 => {
    const value13 = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
    for (const [value14, value15, value16] of value13) {
      if (value12[value14] && value12[value14] === value12[value15] && value12[value14] === value12[value16]) {
        return value12[value14];
      }
    }
    return null;
  };
  const value17 = (value18, value19, value20) => {
    const value21 = value11(value18);
    if (value21 === value8) {
      return 10 - value20;
    }
    if (value21 === value9) {
      return value20 - 10;
    }
    if (value18.every(value22 => value22)) {
      return 0;
    }
    let value23 = value19 ? -Infinity : Infinity;
    for (let value24 = 0; value24 < 9; value24++) {
      if (value18[value24]) {
        continue;
      }
      value18[value24] = value19 ? value8 : value9;
      const value25 = value17(value18, !value19, value20 + 1);
      value18[value24] = null;
      value23 = value19 ? Math.max(value23, value25) : Math.min(value23, value25);
    }
    return value23;
  };
  let value26 = -Infinity;
  let value27 = value10.findIndex(value28 => !value28);
  for (let value29 = 0; value29 < 9; value29++) {
    if (value10[value29]) {
      continue;
    }
    value10[value29] = value8;
    const value30 = value17(value10, false, 0);
    value10[value29] = null;
    if (value30 > value26) {
      value26 = value30;
      value27 = value29;
    }
  }
  return value27;
}
module.exports = {
  games: games,
  name: "tictactoe",
  aliases: ["ttt", "xo"],
  category: "fun",
  description: "Play Tic-Tac-Toe (vs another player or vs the bot)",
  usage: ".ttt start | .ttt bot | .ttt cancel",
  async execute(value31, value32, value33, value34) {
    try {
      const {
        sender: value35,
        from: value36,
        reply: value37
      } = value34;
      const value38 = (value33[0] || "").toLowerCase();
      if (!value38) {
        return value37("🎮 *Tic-Tac-Toe*\n━━━━━━━━━━━━━━━\n▢ `.ttt start`  – open a room (another player runs the same to join)\n▢ `.ttt bot`    – play against the bot\n▢ `.ttt cancel` – cancel your waiting/active game\n\nDuring a game: type *1-9* to move, or *surrender* to give up.");
      }
      const value39 = Object.values(games).find(value40 => value40.id.startsWith("tictactoe") && [value40.game.playerX, value40.game.playerO].includes(value35));
      if (value38 === "cancel") {
        if (!value39) {
          return value37("❌ You are not in any game.");
        }
        delete games[value39.id];
        return value37("🛑 Your tic-tac-toe game has been cancelled.");
      }
      if (value39 && value39.state === "PLAYING") {
        return value37("❌ You are still in a game. Type *surrender* to quit, or *.ttt cancel*.");
      }
      if (value39 && value39.state === "WAITING") {
        return value37("⏳ You already have a room waiting. Type *.ttt cancel* to drop it.");
      }
      if (value38 === "bot") {
        const value41 = {
          id: "tictactoe-" + Date.now(),
          x: value36,
          o: value36,
          botMode: true,
          game: new TicTacToe(value35, BOT_ID),
          state: "PLAYING"
        };
        games[value41.id] = value41;
        await value31.sendMessage(value36, {
          text: "🎮 *Tic-Tac-Toe vs " + BOT_TAG + "*\n\n" + (renderBoard(value41.game) + "\n\n") + "▢ You: ❎  |  Bot: ⭕\n▢ Your move first — type *1-9*\n▢ Type *surrender* to give up",
          mentions: mentionsOf(value35)
        }, {
          quoted: value32
        });
        return;
      }
      const value42 = value38 === "start" ? value33.slice(1).join(" ").trim() || "" : value33.join(" ").trim();
      const value43 = Object.values(games).find(value44 => value44.state === "WAITING" && value44.id.startsWith("tictactoe") && !value44.botMode && (value42 ? value44.name === value42 : !value44.name));
      if (value43) {
        value43.o = value36;
        value43.game.playerO = value35;
        value43.state = "PLAYING";
        const value45 = "🎮 *Tic-Tac-Toe Started!*\n\n" + (renderBoard(value43.game) + "\n\n") + ("▢ ❎ " + playerLabel(value43.game.playerX) + "\n") + ("▢ ⭕ " + playerLabel(value43.game.playerO) + "\n\n") + ("🎲 Turn: " + playerLabel(value43.game.currentTurn) + "\n") + "▢ Type *1-9* to play, *surrender* to give up.";
        await value31.sendMessage(value36, {
          text: value45,
          mentions: mentionsOf(value43.game.playerX, value43.game.playerO)
        });
        return;
      }
      const value46 = {
        id: "tictactoe-" + Date.now(),
        x: value36,
        o: "",
        game: new TicTacToe(value35, "o"),
        state: "WAITING"
      };
      if (value42) {
        value46.name = value42;
      }
      games[value46.id] = value46;
      await value37("⏳ *Waiting for an opponent…*\n" + ("Have someone type *.ttt start" + (value42 ? " " + value42 : "") + "* to join.\n\n") + "Or type *.ttt cancel* to drop the room.");
    } catch (error47) {
      console.error("Error in tictactoe command:", error47);
      await value34.reply("❌ Error starting game. Please try again.");
    }
  }
};
async function handleTicTacToeMove(value48, value49, value50) {
  try {
    const {
      sender: value51,
      from: value52
    } = value50;
    const value53 = (value49.message?.conversation || value49.message?.extendedTextMessage?.text || "").trim();
    const value54 = Object.values(games).find(value55 => value55.id.startsWith("tictactoe") && [value55.game.playerX, value55.game.playerO].includes(value51) && value55.state === "PLAYING");
    if (!value54) {
      return false;
    }
    const value56 = /^(surrender|give up)$/i.test(value53);
    if (!value56 && !/^[1-9]$/.test(value53)) {
      return false;
    }
    if (value51 !== value54.game.currentTurn && !value56) {
      await value48.sendMessage(value52, {
        text: "❌ Not your turn!"
      });
      return true;
    }
    if (value56) {
      const value57 = value51 === value54.game.playerX ? value54.game.playerO : value54.game.playerX;
      await value48.sendMessage(value52, {
        text: "🏳️ " + playerLabel(value51) + " surrendered! " + playerLabel(value57) + " wins!",
        mentions: mentionsOf(value51, value57)
      });
      delete games[value54.id];
      return true;
    }
    const value58 = value54.game.turn(value51 === value54.game.playerO, parseInt(value53) - 1);
    if (!value58) {
      await value48.sendMessage(value52, {
        text: "❌ Invalid move! That position is already taken."
      });
      return true;
    }
    if (value54.botMode && !value54.game.winner && value54.game.turns < 9 && value54.game.currentTurn === BOT_ID) {
      const value59 = "O";
      const value60 = "X";
      const value61 = bestBotMove(value54.game.board, value59, value60);
      value54.game.turn(true, value61);
    }
    await sendBoard(value48, value54);
    if (value54.game.winner || value54.game.turns === 9 && !value54.game.winner) {
      delete games[value54.id];
    }
    return true;
  } catch (error62) {
    console.error("Error in tictactoe move:", error62);
    return false;
  }
}
async function sendBoard(value63, value64) {
  const value65 = value64.game.winner;
  const value66 = value64.game.turns === 9 && !value65;
  let value67;
  if (value65) {
    value67 = value65 === BOT_ID ? "🤖 " + BOT_TAG + " wins! Better luck next time." : "🎉 " + playerLabel(value65) + " wins the game!";
  } else if (value66) {
    value67 = "🤝 It's a draw!";
  } else {
    const value68 = value64.game.currentTurn === value64.game.playerX ? "❎" : "⭕";
    value67 = "🎲 Turn: " + playerLabel(value64.game.currentTurn) + " (" + value68 + ")";
  }
  const value69 = "🎮 *Tic-Tac-Toe" + (value64.botMode ? " vs " + BOT_TAG : "") + "*\n\n" + (value67 + "\n\n") + (renderBoard(value64.game) + "\n\n") + ("▢ ❎ " + playerLabel(value64.game.playerX) + "\n") + ("▢ ⭕ " + playerLabel(value64.game.playerO)) + (!value65 && !value66 ? "\n\n• Type *1-9* to move\n• Type *surrender* to give up" : "");
  const value70 = mentionsOf(value64.game.playerX, value64.game.playerO, value65 || value64.game.currentTurn);
  await value63.sendMessage(value64.x, {
    text: value69,
    mentions: value70
  });
  if (!value64.botMode && value64.x !== value64.o) {
    await value63.sendMessage(value64.o, {
      text: value69,
      mentions: value70
    });
  }
}
module.exports.handleTicTacToeMove = handleTicTacToeMove;
