const axios = require("axios");
module.exports = {
  name: "question",
  aliases: ["randomq"],
  category: "fun",
  description: "Get a random trivia question",
  usage: ".question",
  async execute(value1, value2, value3, value4) {
    await value4.react("❓");
    try {
      const {
        data: value5
      } = await axios.get("https://opentdb.com/api.php?amount=1&type=multiple&encode=url3986");
      if (value5.response_code !== 0 || !value5.results?.length) {
        return value4.reply("❌ Could not fetch a question. Try again.");
      }
      const value6 = value5.results[0];
      const value7 = value8 => decodeURIComponent(value8);
      const value9 = value7(value6.question);
      const value10 = value7(value6.category);
      const value11 = value7(value6.difficulty);
      const value12 = value7(value6.correct_answer);
      const value13 = [value12, ...value6.incorrect_answers.map(value7)].sort(() => Math.random() - 0.5);
      const value14 = ["🅰️", "🅱️", "🅲️", "🅳️"];
      const value15 = value13.map((value16, value17) => value14[value17] + " " + value16).join("\n");
      const value18 = value14[value13.indexOf(value12)];
      const value19 = "❓ *Random Question*\n\n" + ("📂 _" + value10 + "_ • 🔥 _" + value11 + "_\n\n") + ("*" + value9 + "*\n\n") + (value15 + "\n\n") + ("||✅ Answer: " + value18 + " " + value12 + "||");
      await value4.reply(value19);
    } catch (error20) {
      await value4.reply("❌ Error: " + error20.message);
    }
  }
};
