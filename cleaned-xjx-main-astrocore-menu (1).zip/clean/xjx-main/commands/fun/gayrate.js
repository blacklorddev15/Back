module.exports = {
  name: "gayrate",
  aliases: ["gay"],
  category: "fun",
  description: "Playful gay percentage. Reply or mention a user.",
  usage: ".gayrate (reply or @user)",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value2.message?.extendedTextMessage?.contextInfo || {};
      const value6 = value5.mentionedJid || [];
      let value7 = null;
      if (value6.length) {
        value7 = value6[0];
      } else if (value5.participant) {
        value7 = value5.participant;
      } else {
        value7 = value4.sender;
      }
      const value8 = "@" + (value7 || value4.sender).split("@")[0];
      const value9 = (value7 || value4.sender).toString().split("").reduce((value10, value11) => value10 + value11.charCodeAt(0), 0);
      const value12 = (value9 % 101 + Math.floor(Math.random() * 7)) % 101;
      const value13 = [value8 + " is " + value12 + "% fabulous 🌈", "💖 Compatibility with rainbows: " + value12 + "% for " + value8, value8 + " score: " + value12 + "% pure glitter ✨"];
      const value14 = value13[Math.floor(Math.random() * value13.length)];
      await value1.sendMessage(value4.from, {
        text: value14,
        mentions: [value7]
      }, {
        quoted: value2
      });
    } catch (error15) {
      console.error("[gayrate] ERROR:", error15);
      await value4.reply("❌ Something went wrong.");
    }
  }
};
