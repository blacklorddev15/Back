const axios = require("axios");
module.exports = {
  name: "wasted",
  aliases: ["waste", "rip"],
  category: "fun",
  description: "Put a wasted effect on someone's profile picture",
  usage: ".wasted @user or reply to a message",
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    let value6 = value2.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || value2.message?.extendedTextMessage?.contextInfo?.participant || null;
    if (!value6) {
      return await value1.sendMessage(value5, {
        text: "⚰️ Please mention someone or reply to their message to waste them!"
      }, {
        quoted: value2
      });
    }
    await value1.sendMessage(value5, {
      react: {
        text: "💀",
        key: value2.key
      }
    });
    try {
      let value7;
      try {
        value7 = await value1.profilePictureUrl(value6, "image");
      } catch {
        value7 = "https://i.imgur.com/2wzGhpF.jpeg";
      }
      const value8 = await axios.get("https://some-random-api.com/canvas/overlay/wasted?avatar=" + encodeURIComponent(value7), {
        responseType: "arraybuffer",
        timeout: 15000
      });
      const value9 = value6.split("@")[0];
      const value10 = "⚰️ *Wasted:* @" + value9 + "\n💀 _Rest in pieces!_";
      await value1.sendMessage(value5, {
        image: Buffer.from(value8.data),
        caption: value10,
        mentions: [value6]
      }, {
        quoted: value2
      });
    } catch (error11) {
      console.error("[WASTED] Error:", error11?.message || error11);
      await value1.sendMessage(value5, {
        text: "❌ Failed to create wasted image. Try again later."
      }, {
        quoted: value2
      });
    }
  }
};
