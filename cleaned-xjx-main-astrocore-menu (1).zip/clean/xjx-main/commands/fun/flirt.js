const axios = require("axios");
module.exports = {
  name: "flirt",
  aliases: ["pickup"],
  category: "fun",
  desc: "Get a random flirty pickup line",
  usage: "flirt [@user]",
  execute: async (value1, value2, value3, value4) => {
    try {
      const value5 = await axios.get("https://api.shizo.top/quote/flirt?apikey=shizo");
      if (!value5.data || !value5.data.status || !value5.data.result) {
        throw new Error("Invalid API response");
      }
      const value6 = value5.data.result;
      const value7 = value2.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
      if (value7.length > 0) {
        await value1.sendMessage(value4.from, {
          text: value6,
          mentions: value7
        }, {
          quoted: value2
        });
      } else {
        await value4.reply(value6);
      }
    } catch (error8) {
      console.error("Flirt Error:", error8);
      await value4.reply("❌ Error: " + error8.message);
    }
  }
};
