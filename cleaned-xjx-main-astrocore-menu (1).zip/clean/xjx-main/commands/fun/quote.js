const axios = require("axios");
module.exports = {
  name: "quotes",
  aliases: ["quote"],
  category: "fun",
  description: "Get a random fact or quote",
  usage: ".fact",
  async execute(value1, value2, value3, value4) {
    await value4.react("💡");
    try {
      const {
        data: value5
      } = await axios.get("https://api.shizo.top/quote/quotes?apikey=shizo");
      if (!value5.status || !value5.result) {
        throw new Error("No result returned.");
      }
      await value4.reply("💡 *Random Fact*\n\n_" + value5.result + "_");
      await value4.react("✅");
    } catch (error6) {
      await value4.react("❌");
      await value4.reply("❌ Error: " + error6.message);
    }
  }
};
