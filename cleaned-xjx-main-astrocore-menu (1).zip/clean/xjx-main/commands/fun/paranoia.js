const axios = require("axios");
module.exports = {
  name: "paranoia",
  aliases: [],
  category: "fun",
  description: "Get a random paranoia question",
  usage: ".paranoia",
  async execute(value1, value2, value3, value4) {
    await value4.react("😱");
    try {
      const {
        data: value5
      } = await axios.get("https://api.truthordarebot.xyz/v1/paranoia");
      const value6 = value5.question || value5.result || JSON.stringify(value5);
      await value4.reply("😱 *Paranoia*\n\n_" + value6 + "_");
    } catch (error7) {
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
