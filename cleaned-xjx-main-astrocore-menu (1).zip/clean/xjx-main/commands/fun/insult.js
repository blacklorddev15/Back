module.exports = {
  name: "insult",
  aliases: ["insultme", "burn"],
  category: "fun",
  description: "Give a silly insult to a user. Reply or mention to target someone.",
  usage: ".insult (reply or @user)",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value2.message?.extendedTextMessage?.contextInfo || {};
      const value6 = value5.mentionedJid || [];
      let value7 = null;
      if (value6.length) {
        value7 = value6[0];
      } else if (value5.participant) {
        value7 = value5.participant;
      } else {
        value7 = value4.sender;
      }
      const value8 = "@" + (value7 || value4.sender).split("@")[0];
      const value9 = ["You're as useful as a white crayon.", "I'd call you sharp, but that would be offensive to pencils.", "You're like a cloud. When you disappear, it's a beautiful day.", "You bring everyone so much joy... when you leave the room.", "If laziness was an Olympic sport, you'd come in fourth — so you wouldn't have to walk up to the podium."];
      const value10 = value9[Math.floor(Math.random() * value9.length)];
      await value1.sendMessage(value4.from, {
        text: "" + value10,
        mentions: [value7]
      }, {
        quoted: value2
      });
    } catch (error11) {
      console.error("[insult] ERROR:", error11);
      await value4.reply("❌ Something went wrong.");
    }
  }
};
