module.exports = {
  name: "ship",
  aliases: ["shipit", "match"],
  category: "fun",
  description: "Ship two users randomly or mention/reply to specific users.",
  usage: ".ship (random) OR .ship @user1 @user2 OR reply with .ship",
  groupOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value2.message?.extendedTextMessage?.contextInfo || {};
      const value6 = value5.mentionedJid || [];
      let value7 = null;
      let value8 = null;
      if (value6.length >= 2) {
        value7 = value6[0];
        value8 = value6[1];
      } else if (value6.length === 1) {
        value7 = value6[0];
        value8 = value4.sender;
      } else if (value5.participant) {
        value7 = value5.participant;
        value8 = value4.sender;
      } else if (value4.isGroup && value4.groupMetadata?.participants) {
        const value9 = value4.groupMetadata.participants.map(value10 => value10.id).filter(value11 => value11 !== value1.user.id);
        if (value9.length >= 2) {
          const value12 = value9.sort(() => Math.random() - 0.5);
          value7 = value12[0];
          value8 = value12[1];
        } else {
          return value4.reply("❌ Not enough members to ship!");
        }
      } else {
        return value4.reply("❌ This command works only in groups!");
      }
      const value13 = value14 => "@" + value14.split("@")[0];
      const value15 = (value7 + value8).split("").reduce((value16, value17) => value16 + value17.charCodeAt(0), 0);
      const value18 = Math.abs(value15 * 7 % 101);
      const value19 = ["💖", "💕", "💘", "💞", "💓"];
      const value20 = value19[Math.floor(Math.random() * value19.length)];
      const value21 = [value13(value7) + " + " + value13(value8) + " = " + value18 + "% " + value20 + "\nLooks promising!", value13(value7) + " x " + value13(value8) + " = " + value18 + "%\nNot bad, keep flirting 😉", value13(value7) + " & " + value13(value8) + " Compatibility: " + value18 + "%\n" + (value18 > 75 ? "A strong match ❤️" : value18 > 40 ? "Could work 🤝" : "Mostly chaos 😂")];
      const value22 = value21[Math.floor(Math.random() * value21.length)];
      await value1.sendMessage(value4.from, {
        text: value22,
        mentions: [value7, value8]
      }, {
        quoted: value2
      });
    } catch (error23) {
      console.error("[ship] ERROR:", error23);
      await value4.reply("❌ Something went wrong while shipping.");
    }
  }
};
