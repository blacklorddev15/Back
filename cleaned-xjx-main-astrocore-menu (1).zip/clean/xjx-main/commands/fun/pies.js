const axios = require("axios");
const database = require("../../database");
const BASE = "https://api.shizo.top/pies";
const VALID_COUNTRIES = ["india", "malaysia", "thailand", "china", "indonesia", "japan", "korea", "vietnam"];
module.exports = {
  name: "pies",
  aliases: ["pie", "india", "malaysia", "thailand", "china", "indonesia", "japan", "korea", "vietnam"],
  category: "fun",
  desc: "Get random pies images by country",
  usage: "pies <country>",
  execute: async (value1, value2, value3, value4) => {
    try {
      const value5 = value2.message?.conversation || value2.message?.extendedTextMessage?.text || "";
      const value6 = database.getBotSetting("prefix") || ".";
      const value7 = value5.trim().split(/\s+/);
      const value8 = value7[0]?.replace(value6, "").toLowerCase() || "";
      let value9 = "";
      if (VALID_COUNTRIES.includes(value8)) {
        value9 = value8;
      } else {
        value9 = (value3[0] || "").toLowerCase();
      }
      if (!value9) {
        return await value4.reply("Usage: .pies <country>\n\nCountries: " + VALID_COUNTRIES.join(", "));
      }
      if (!VALID_COUNTRIES.includes(value9)) {
        return await value4.reply("❌ Unsupported country: " + value9 + "\n\nTry one of: " + VALID_COUNTRIES.join(", "));
      }
      const value10 = BASE + "/" + value9 + "?apikey=shizo";
      const value11 = await axios.get(value10, {
        responseType: "arraybuffer",
        headers: {
          "User-Agent": "Mozilla/5.0"
        }
      });
      const value12 = Buffer.from(value11.data);
      const value13 = value11.headers["content-type"] || "";
      if (!value13.includes("image")) {
        throw new Error("API did not return an image");
      }
      await value1.sendMessage(value4.from, {
        image: value12,
        caption: "pies: " + value9
      }, {
        quoted: value2
      });
    } catch (error14) {
      console.error("Error in pies command:", error14);
      await value4.reply("❌ Failed to fetch image: " + error14.message);
    }
  }
};
