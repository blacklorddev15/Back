const axios = require("axios");
module.exports = {
  name: "wyr",
  aliases: ["wouldyourather"],
  category: "fun",
  description: "Would you rather question",
  usage: ".wyr",
  async execute(value1, value2, value3, value4) {
    await value4.react("🤔");
    try {
      const {
        data: value5
      } = await axios.get("https://api.truthordarebot.xyz/v1/wyr");
      const value6 = value5.question;
      const value7 = value6.split(" or ");
      const value8 = value7[0]?.trim() || value6;
      const value9 = value7.slice(1).join(" or ")?.trim() || "";
      const value10 = value9 ? "🤔 *Would You Rather...*\n\n🅰️ " + value8 + "\n\n*OR*\n\n🅱️ " + value9 : "🤔 *Would You Rather...*\n\n" + value6;
      await value4.reply(value10);
    } catch (error11) {
      await value4.reply("❌ Error: " + error11.message);
    }
  }
};
