const APIs = require("../../utils/api");
module.exports = {
  name: "joke",
  aliases: ["jokes"],
  category: "fun",
  description: "Get random joke",
  usage: ".joke",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = await APIs.getJoke();
      let value6 = value5.setup + "\n\n" + value5.punchline;
      await value4.reply(value6);
    } catch (error7) {
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
