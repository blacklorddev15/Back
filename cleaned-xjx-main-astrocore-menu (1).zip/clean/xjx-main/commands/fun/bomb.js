const gameState = new Map();
module.exports = {
  gameState: gameState,
  name: "bomb",
  aliases: ["bom"],
  category: "fun",
  description: "Play bomb game - pick numbers 1-9, avoid the bomb!",
  usage: ".bomb",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.sender;
      const value6 = 180000;
      if (gameState.has(value5)) {
        const value7 = gameState.get(value5);
        const value8 = value2.message?.conversation || value2.message?.extendedTextMessage?.text || "";
        if (value8.toLowerCase().trim() === "suren" || value8.toLowerCase().trim() === "surrender") {
          const value9 = value7.array.find(value10 => value10.emot === "💥");
          await value4.reply("*You surrendered!* 💣\n\nThe bomb was in box number " + value9.number + ".", {
            quoted: value7.msg
          });
          clearTimeout(value7.timeoutId);
          gameState.delete(value5);
          return;
        }
        const value11 = parseInt(value8.trim());
        if (isNaN(value11) || value11 < 1 || value11 > 9) {
          return;
        }
        const value12 = value7.array.find(value13 => value13.position === value11);
        if (!value12 || value12.state) {
          return;
        }
        value12.state = true;
        if (value12.emot === "💥") {
          let value14 = "💥 *B O M B  E X P L O D E D!*\n\n";
          value14 += "You selected box number " + value12.number + " and...\n\n";
          value14 += "💣 *BOOM!* 💣\n\n";
          value14 += "Game Over! Points deducted.\n\n";
          value14 += "*Final Result:*\n";
          for (let value15 = 0; value15 < value7.array.length; value15 += 3) {
            value14 += value7.array.slice(value15, value15 + 3).map(value16 => value16.emot).join("") + "\n";
          }
          await value1.sendMessage(value4.from, {
            text: value14
          }, {
            quoted: value7.msg
          });
          clearTimeout(value7.timeoutId);
          gameState.delete(value5);
          return;
        }
        const value17 = value7.array.filter(value18 => value18.emot === "✅");
        const value19 = value17.filter(value20 => value20.state);
        if (value19.length === value17.length) {
          let value21 = "🎉 *YOU WIN!*\n\n";
          value21 += "Congratulations! You successfully opened all safe boxes!\n\n";
          value21 += "*Final Result:*\n";
          for (let value22 = 0; value22 < value7.array.length; value22 += 3) {
            value21 += value7.array.slice(value22, value22 + 3).map(value23 => value23.emot).join("") + "\n";
          }
          value21 += "\n✅ Points added!";
          await value1.sendMessage(value4.from, {
            text: value21
          }, {
            quoted: value7.msg
          });
          clearTimeout(value7.timeoutId);
          gameState.delete(value5);
          return;
        }
        let value24 = "乂  *B O M B*\n\n";
        value24 += "Box number " + value12.number + " opened: " + value12.emot + "\n\n";
        value24 += "Send number *1* - *9* to open a box:\n\n";
        for (let value25 = 0; value25 < value7.array.length; value25 += 3) {
          value24 += value7.array.slice(value25, value25 + 3).map(value26 => value26.state ? value26.emot : value26.number).join("") + "\n";
        }
        value24 += "\nTimeout : [ *" + value6 / 1000 / 60 + " minutes* ]\n";
        value24 += "Type *suren* to surrender.";
        await value1.sendMessage(value4.from, {
          text: value24
        }, {
          quoted: value7.msg
        });
        return;
      }
      const value27 = ["💥", "✅", "✅", "✅", "✅", "✅", "✅", "✅", "✅"].sort(() => Math.random() - 0.5);
      const value28 = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣"];
      const value29 = value27.map((value30, value31) => ({
        emot: value30,
        number: value28[value31],
        position: value31 + 1,
        state: false
      }));
      let value32 = "乂  *B O M B*\n\n";
      value32 += "Send number *1* - *9* to open the *9* boxes below:\n\n";
      for (let value33 = 0; value33 < value29.length; value33 += 3) {
        value32 += value29.slice(value33, value33 + 3).map(value34 => value34.state ? value34.emot : value34.number).join("") + "\n";
      }
      value32 += "\nTimeout : [ *" + value6 / 1000 / 60 + " minutes* ]\n";
      value32 += "If you get the box with the bomb, points will be deducted. Type *suren* to surrender.";
      const value35 = await value1.sendMessage(value4.from, {
        text: value32,
        contextInfo: {
          externalAdReply: {
            title: "Bomb Game",
            body: "Avoid the bomb!",
            thumbnailUrl: "https://telegra.ph/file/b3138928493e78b55526f.jpg",
            sourceUrl: "",
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, {
        quoted: value2
      });
      const value36 = setTimeout(() => {
        if (gameState.has(value5)) {
          const value37 = gameState.get(value5);
          const value38 = value37.array.find(value39 => value39.emot === "💥");
          value1.sendMessage(value4.from, {
            text: "*Time's up!* ⏰\n\nThe bomb was in box number " + value38.number + "."
          }, {
            quoted: value37.msg
          });
          gameState.delete(value5);
        }
      }, value6);
      gameState.set(value5, {
        msg: value35,
        array: value29,
        timeoutId: value36
      });
      setTimeout(() => {
        if (gameState.has(value5)) {
          gameState.delete(value5);
        }
      }, value6 + 60000);
    } catch (error40) {
      console.error("Error in bomb command:", error40);
      return value4.reply("❌ Error: " + (error40.message || "Unknown error occurred"));
    }
  }
};
