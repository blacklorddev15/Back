const APIs = require("../../utils/api");
const axios = require("axios");
module.exports = {
  name: "meme",
  aliases: ["memes"],
  category: "fun",
  description: "Get random memes",
  usage: ".meme",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = await APIs.getMeme();
      const value6 = await axios.get(value5.url, {
        responseType: "arraybuffer"
      });
      await value1.sendMessage(value4.from, {
        image: Buffer.from(value6.data),
        caption: "😂 *" + value5.title + "*\n\n📱 From: r/" + value5.subreddit + "\n👤 By: " + value5.author + "\n⬆️ Upvotes: " + value5.ups
      }, {
        quoted: value2
      });
    } catch (error7) {
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
