const axios = require("axios");
const fs = require("fs");
const path = require("path");
const {
  exec
} = require("child_process");
const ffmpegPath = require("../../utils/ffmpegPath");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const BASE = "https://api.shizo.top/tools/meme-search";
module.exports = {
  name: "memesearch",
  aliases: ["sm", "smeme", "gifsearch", "gif"],
  category: "fun",
  desc: "Search and get memes",
  usage: "memesearch <query>",
  execute: async (value1, value2, value3, value4) => {
    try {
      const value5 = value3.join(" ").trim();
      if (!value5) {
        return await value4.reply("Usage: .memesearch <query>\n\nExample: .memesearch hello");
      }
      const value6 = BASE + "?apikey=shizo&query=" + encodeURIComponent(value5);
      const value7 = await axios.get(value6, {
        responseType: "arraybuffer",
        headers: {
          "User-Agent": "Mozilla/5.0"
        }
      });
      const value8 = Buffer.from(value7.data);
      if (!value8 || value8.length === 0) {
        throw new Error("Empty response from API");
      }
      const value9 = 16777216;
      const value10 = 5242880;
      const value11 = value7.headers["content-type"] || "";
      const value12 = value8.slice(0, 6).toString("ascii");
      const value13 = value12 === "GIF89a" || value12 === "GIF87a" || value11.includes("gif");
      if (value13) {
        if (value8.length > value9) {
          throw new Error("GIF file too large: " + (value8.length / 1024 / 1024).toFixed(2) + "MB (max 16MB)");
        }
        const value14 = getTempDir();
        const value15 = Date.now();
        const value16 = path.join(value14, "meme_gif_" + value15 + ".gif");
        const value17 = path.join(value14, "meme_mp4_" + value15 + ".mp4");
        let value18 = null;
        try {
          fs.writeFileSync(value16, value8);
          const value19 = "\"" + ffmpegPath() + "\" -i \"" + value16 + "\" -vf \"fps=15,scale=512:512:flags=lanczos:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000\" -c:v libx264 -pix_fmt yuv420p -movflags +faststart -fps_mode vfr -y \"" + value17 + "\"";
          await new Promise((value20, value21) => {
            exec(value19, {
              maxBuffer: 10485760
            }, value22 => {
              if (value22) {
                value21(value22);
              } else {
                value20();
              }
            });
          });
          if (!fs.existsSync(value17)) {
            throw new Error("MP4 output file not found");
          }
          value18 = fs.readFileSync(value17);
          if (value18.length > value9) {
            throw new Error("MP4 file too large: " + (value18.length / 1024 / 1024).toFixed(2) + "MB");
          }
          const value23 = await value1.sendMessage(value4.from, {
            video: value18,
            mimetype: "video/mp4",
            gifPlayback: true
          }, {
            quoted: value2
          });
          if (!value23) {
            throw new Error("Video send returned no result");
          }
        } catch (error24) {
          try {
            const value25 = await value1.sendMessage(value4.from, {
              document: value8,
              mimetype: "image/gif",
              fileName: "meme_" + value5.replace(/\s+/g, "_") + ".gif"
            }, {
              quoted: value2
            });
            if (!value25) {
              throw new Error("Document send returned no result");
            }
          } catch (error26) {
            throw new Error("Failed to send meme: " + error24.message);
          }
        } finally {
          try {
            deleteTempFile(value16);
            deleteTempFile(value17);
          } catch (error27) {}
        }
      } else if (value11.includes("video") || value11.includes("mp4")) {
        if (value8.length > value9) {
          throw new Error("Video file too large: " + (value8.length / 1024 / 1024).toFixed(2) + "MB (max 16MB)");
        }
        await value1.sendMessage(value4.from, {
          video: value8,
          mimetype: "video/mp4"
        }, {
          quoted: value2
        });
      } else {
        if (value8.length > value10) {
          throw new Error("Image file too large: " + (value8.length / 1024 / 1024).toFixed(2) + "MB (max 5MB)");
        }
        await value1.sendMessage(value4.from, {
          image: value8
        }, {
          quoted: value2
        });
      }
    } catch (error28) {
      await value4.reply("❌ Failed to fetch meme: " + error28.message);
    }
  }
};
