'use strict';

const fs = require("fs");
const path = require("path");
const {
  sendRichApp,
  RICH_FALLBACK
} = require("../../utils/richApp");
const APP_HTML = fs.readFileSync(path.join(__dirname, "tod-app.html"), "utf8");
module.exports = {
  name: "tod",
  aliases: ["truthordare", "spin"],
  category: "fun",
  description: "TEST: Truth or Dare wheel — mini-app version (render in chat)",
  usage: ".tod",
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from || value2.key.remoteJid;
    try {
      await sendRichApp(value1, value2, APP_HTML, value5);
    } catch (error6) {
      console.error("[ToD] mini-app unavailable:", error6.message);
      await value1.sendMessage(value5, {
        text: RICH_FALLBACK("TRUTH OR DARE")
      }, {
        quoted: value2
      }).catch(() => {});
    }
  }
};
