const axios = require("axios");
module.exports = {
  name: "pickupline",
  aliases: ["rizz"],
  category: "fun",
  description: "Get a random pickup line",
  usage: ".pickupline",
  async execute(value1, value2, value3, value4) {
    await value4.react("😏");
    try {
      const {
        data: value5
      } = await axios.get("https://api.jcwyt.com/pickup");
      const value6 = typeof value5 === "string" ? value5 : value5.line || value5.pickup || JSON.stringify(value5);
      await value4.reply("😏 *Pickup Line*\n\n_" + value6 + "_");
    } catch (error7) {
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
