module.exports = {
  name: "compliment",
  aliases: ["praise"],
  category: "fun",
  desc: "Get a random compliment",
  usage: "compliment [@user]",
  execute: async (value1, value2, value3) => {
    try {
      const value4 = ["You're an awesome friend! 💙", "You light up the room! ✨", "You're someone's reason to smile! 😊", "You're even better than a unicorn! 🦄", "You're a gift to those around you! 🎁", "You're a smart cookie! 🍪", "You're awesome! 🌟", "You have the best laugh! 😄", "You're gorgeous! 💖", "You're more helpful than you realize! 🤝", "You have a great sense of humor! 😂", "You're really something special! ⭐", "You're an incredible friend! 🫂", "Your perspective is refreshing! 🌈", "You're making a difference! 🌍", "You're stronger than you think! 💪", "Your smile is contagious! 😁", "You're one of a kind! 💎", "You bring out the best in people! 👏", "You're inspiring! 🌟"];
      const value5 = value2.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
      const value6 = value4[Math.floor(Math.random() * value4.length)];
      if (value5.length > 0) {
        await value1.sendMessage(value2.key.remoteJid, {
          text: "" + value6,
          mentions: value5
        }, {
          quoted: value2
        });
      } else {
        await value1.sendMessage(value2.key.remoteJid, {
          text: "" + value6
        }, {
          quoted: value2
        });
      }
    } catch (error7) {
      console.error("Compliment Error:", error7);
      await value1.sendMessage(value2.key.remoteJid, {
        text: "❌ Error: " + error7.message
      }, {
        quoted: value2
      });
    }
  }
};
