const axios = require("axios");
const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
const sleep = value1 => new Promise(value2 => setTimeout(value2, value1));
module.exports = {
  name: "pair",
  aliases: ["paircode", "linkdevice"],
  category: "general",
  description: "Generate a pairing code to link a WhatsApp number",
  usage: ".pair <number>  e.g. .pair 254712345678",
  async execute(value3, value4, value5, value6) {
    const value7 = value6.from;
    try {
      const value8 = value5.join(" ").trim();
      if (!value8) {
        await value3.sendMessage(value7, {
          text: "⚠️ *Oops!* You forgot the number 😅\n\n👉 Example:\n.pair 25478467XXXX"
        }, {
          quoted: value4
        });
        await value3.sendMessage(value7, {
          react: {
            text: "⚠️",
            key: value4.key
          }
        });
        return;
      }
      const value9 = value8.split(",").map(value10 => value10.replace(/[^0-9]/g, "")).filter(value11 => value11.length >= 6 && value11.length <= 20);
      if (value9.length === 0) {
        await value3.sendMessage(value7, {
          text: "❌ *Invalid number format!* 🚫\n\n👉 Please use digits only (6–20 digits)."
        }, {
          quoted: value4
        });
        await value3.sendMessage(value7, {
          react: {
            text: "❌",
            key: value4.key
          }
        });
        return;
      }
      for (const value12 of value9) {
        const value13 = value12 + "@s.whatsapp.net";
        const value14 = await value3.onWhatsApp(value13);
        if (!value14?.[0]?.exists) {
          await value3.sendMessage(value7, {
            text: "🚫 Number *" + value12 + "* is not registered on WhatsApp ❌"
          });
          await value3.sendMessage(value7, {
            react: {
              text: "🚫",
              key: value4.key
            }
          });
          continue;
        }
        await value3.sendMessage(value7, {
          text: "⏳ Generating code for: *" + value12 + "* 🔐"
        }, {
          quoted: value4
        });
        await value3.sendMessage(value7, {
          react: {
            text: "⏳",
            key: value4.key
          }
        });
        try {
          const value15 = await axios.get("https://pair-junex.onrender.com/code?number=" + value12, {
            timeout: 20000
          });
          const value16 = value15.data?.code;
          if (!value16 || value16 === "Service Unavailable") {
            throw new Error("Service Unavailable");
          }
          await sleep(3000);
          await sendButtons(value3, value7, {
            text: "🔐 *Pairing Code for " + value12 + "*\n\n```" + value16 + "```\n\n📲 *How to link your device:*\n1️⃣ Open WhatsApp on your phone\n2️⃣ Tap *Menu* (⋮) or *Settings*\n3️⃣ Go to *Linked Devices*\n4️⃣ Tap *Link a Device*\n5️⃣ Tap *Link with phone number instead*\n6️⃣ Enter the code above 👆\n\n⏱️ _Code expires in a few minutes. Act fast!_",
            footer: "Powered by " + database.getBotSetting("botName"),
            buttons: [{
              name: "cta_copy",
              buttonParamsJson: JSON.stringify({
                display_text: "📋 Copy Code",
                copy_code: value16
              })
            }]
          }, {
            quoted: value4
          });
          await value3.sendMessage(value7, {
            react: {
              text: "✅",
              key: value4.key
            }
          });
        } catch (error17) {
          console.error("Pair API Error:", error17.message);
          const value18 = error17.message === "Service Unavailable" ? "⚠️ Service is currently unavailable 🙏 Please try again later." : "❌ Failed to generate pairing code 😔 Please try again later.";
          await value3.sendMessage(value7, {
            text: value18
          }, {
            quoted: value4
          });
          await value3.sendMessage(value7, {
            react: {
              text: "⚠️",
              key: value4.key
            }
          });
        }
      }
    } catch (error19) {
      console.error("Pair command error:", error19);
      await value3.sendMessage(value7, {
        text: "💥 Unexpected error occurred 😵\n\nPlease try again later 🙏"
      }, {
        quoted: value4
      });
      await value3.sendMessage(value7, {
        react: {
          text: "💥",
          key: value4.key
        }
      });
    }
  }
};
