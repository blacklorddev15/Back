const {
  getStats
} = require("../../utils/groupstats");
module.exports = {
  name: "myactivity",
  aliases: ["mystats", "mymsgs", "rank"],
  category: "general",
  description: "Check your activity stats for today",
  usage: ".myactivity",
  groupOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      const value6 = value4.sender;
      const value7 = getStats(value5);
      if (!value7 || !value7.users || !value7.users[value6]) {
        return value4.reply("📊 You haven't sent any messages today yet!");
      }
      const value8 = value7.users[value6];
      const value9 = value7.total;
      const value10 = (value8 / value9 * 100).toFixed(1);
      const value11 = Object.entries(value7.users).sort((value12, value13) => value13[1] - value12[1]);
      const value14 = value11.findIndex(([value15]) => value15 === value6) + 1;
      const value16 = ("\n📊 *Your Activity Today*\n\n👤 *User:* @" + value6.split("@")[0] + "\n📝 *Messages Sent:* " + value8 + "\n📈 *Your Share:* " + value10 + "%\n🏆 *Rank:* #" + value14 + " of " + value11.length + "\n\nKeep chatting! 💬\n").trim();
      await value1.sendMessage(value5, {
        text: value16,
        mentions: [value6]
      }, {
        quoted: value2
      });
    } catch (error17) {
      console.error("[myactivity cmd] error:", error17);
      value4.reply("❌ Error loading your activity stats.");
    }
  }
};
