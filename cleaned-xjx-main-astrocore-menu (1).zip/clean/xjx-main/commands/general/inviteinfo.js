const {
  jidUser,
  resolvePhone,
  rememberLidMapping
} = require("../../utils/jidHelper");
const database = require("../../database");
function extractInviteCode(value1) {
  if (!value1) {
    return null;
  }
  const value2 = String(value1).trim();
  const value3 = value2.match(/chat\.whatsapp\.com\/(?:invite\/)?([A-Za-z0-9_-]{10,})/i);
  if (value3) {
    return value3[1];
  }
  if (/^[A-Za-z0-9_-]{10,}$/.test(value2)) {
    return value2;
  }
  return null;
}
function getQuotedText(value4) {
  const value5 = value4.message?.extendedTextMessage?.contextInfo;
  const value6 = value5?.quotedMessage;
  if (!value6) {
    return "";
  }
  return value6.conversation || value6.extendedTextMessage?.text || value6.imageMessage?.caption || value6.videoMessage?.caption || "";
}
function formatWhen(value7, value8) {
  if (!value7) {
    return "Unknown";
  }
  try {
    return new Date(value7 * 1000).toLocaleString("en-GB", {
      timeZone: value8 || "UTC",
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch (error9) {
    return new Date(value7 * 1000).toISOString();
  }
}
function displayId(value10) {
  if (!value10) {
    return "Unknown";
  }
  return jidUser(value10) || String(value10).split("@")[0];
}
async function preferPn(value11, value12, value13) {
  if (value13) {
    return value13;
  }
  if (!value12) {
    return null;
  }
  if (!String(value12).endsWith("@lid")) {
    return value12;
  }
  const value14 = await resolvePhone(value11, value12);
  if (value14) {
    rememberLidMapping(value12, value14);
    if (value14.includes("@")) {
      return value14;
    } else {
      return value14 + "@s.whatsapp.net";
    }
  }
  return value12;
}
module.exports = {
  name: "inviteinfo",
  aliases: ["inspect", "gclinkinfo", "linkinfo"],
  category: "general",
  description: "Preview a group from its invite link without joining",
  usage: ".inviteinfo https://chat.whatsapp.com/XXXX",
  async execute(value15, value16, value17, value18) {
    const value19 = [(value17 || []).join(" "), getQuotedText(value16)].filter(Boolean).join(" ");
    const value20 = extractInviteCode(value19);
    if (!value20) {
      return value18.reply("🔎 *Invite Info*\n\nUsage: .inviteinfo https://chat.whatsapp.com/XXXX\nOr reply to a message that contains the link.\n\n_Does not join the group._");
    }
    try {
      if (value18.react) {
        await value18.react("🔎").catch(() => {});
      }
      const value21 = await value15.groupGetInviteInfo(value20);
      const value22 = database.getTimeZone();
      const value23 = await preferPn(value15, value21.owner, value21.ownerPn);
      const value24 = await preferPn(value15, value21.subjectOwner, value21.subjectOwnerPn);
      const value25 = ["┏━━『 INVITE INFO 』━━", "", "➥ Name      ➜ " + (value21.subject || "Unknown"), "➥ ID        ➜ " + (value21.id || "Unknown"), "➥ Members   ➜ " + (value21.size ?? (value21.participants || []).length), "➥ Created   ➜ " + formatWhen(value21.creation, value22), "➥ Owner     ➜ " + (value23 ? "@" + displayId(value23) : "Unknown")];
      if (value24) {
        value25.push("➥ Named by  ➜ @" + displayId(value24));
      }
      value25.push("➥ Announce  ➜ " + (value21.announce ? "admins only" : "everyone"));
      value25.push("➥ Locked    ➜ " + (value21.restrict ? "admins change info" : "anyone can change"));
      value25.push("➥ Join ask  ➜ " + (value21.joinApprovalMode ? "approval required" : "open"));
      value25.push("➥ Add mode  ➜ " + (value21.memberAddMode ? "any member" : "admins only"));
      if (value21.isCommunity) {
        value25.push("➥ Type      ➜ community");
      }
      if (value21.linkedParent) {
        value25.push("➥ Parent    ➜ " + value21.linkedParent);
      }
      if (value21.ephemeralDuration) {
        const value26 = Math.round(value21.ephemeralDuration / 3600);
        value25.push("➥ Disappear ➜ " + value26 + "h");
      }
      if (value21.desc) {
        const value27 = String(value21.desc).trim();
        value25.push("");
        value25.push("┃ Description");
        value25.push(value27.length > 400 ? value27.slice(0, 400) + "…" : value27);
      }
      value25.push("");
      value25.push("➥ Link      ➜ https://chat.whatsapp.com/" + value20);
      value25.push("");
      value25.push("┗━━━━━━━━━━━━━━━━");
      const value28 = [value23, value24].filter(Boolean);
      await value15.sendMessage(value18.from, {
        text: value25.join("\n"),
        mentions: value28
      }, {
        quoted: value16
      });
      if (value18.react) {
        await value18.react("✅").catch(() => {});
      }
    } catch (error29) {
      console.error("[inviteinfo]", error29.message);
      if (value18.react) {
        await value18.react("❌").catch(() => {});
      }
      const value30 = /404|not-found|gone|invalid|item-not-found/i.test(error29.message || "");
      await value18.reply(value30 ? "❌ That invite link is invalid or has been reset." : "❌ Could not read invite: " + error29.message);
    }
  }
};
