module.exports = {
  name: "delpp",
  aliases: ["deleteprofile", "deppf", "delprofilep", "removedp"],
  category: "owner",
  description: "Remove the bot's profile picture",
  usage: ".delpp",
  async execute(value1, value2, value3, value4) {
    try {
      if (!value4.isOwner) {
        return value4.reply("❌ This command is only available for the owner!");
      }
      await value4.react("⏳");
      const value5 = value1.user?.id || value1.user?.lid;
      if (!value5) {
        await value4.react("❌");
        return value4.reply("❌ Could not determine bot JID.");
      }
      await value1.removeProfilePicture(value5);
      await value4.react("✅");
      await value1.sendMessage(value4.from, {
        text: "✅ Successfully removed bot profile picture!"
      }, {
        quoted: value2
      });
    } catch (error6) {
      console.error("Error in delpp command:", error6);
      try {
        await value4.react("❌");
      } catch (error7) {}
      try {
        await value4.reply("❌ Failed to remove profile picture: " + error6.message);
      } catch (error8) {}
    }
  }
};
