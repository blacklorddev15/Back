const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const {
  exec
} = require("child_process");
const ffmpegPath = require("../../utils/ffmpegPath");
const axios = require("axios");
const webp = require("node-webpmux");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const database = require("../../database");
module.exports = {
  name: "egif",
  aliases: ["emojisticker", "emojigif", "emosticker"],
  description: "Convert emoji to animated sticker (GIF)",
  usage: ".egif <emoji>",
  category: "general",
  async execute(value1, value2, value3, value4) {
    const value5 = getTempDir();
    const value6 = path.join(value5, "emoji_" + Date.now() + ".gif");
    const value7 = path.join(value5, "emoji_" + Date.now() + ".webp");
    const value8 = [value6, value7];
    try {
      const value9 = value3.join(" ").trim();
      if (!value9) {
        return value4.reply("😂 Provide an emoji!\nExample: .egif 😂");
      }
      const value10 = value9.match(/([\p{Emoji_Presentation}|\p{Extended_Pictographic}])/u);
      if (!value10) {
        return value4.reply("❌ Please provide a valid emoji!");
      }
      const value11 = value10[0];
      const value12 = value11.codePointAt(0).toString(16);
      const value13 = "https://fonts.gstatic.com/s/e/notoemoji/latest/" + value12 + "/512.gif";
      const value14 = await axios.get(value13, {
        responseType: "arraybuffer"
      });
      if (!value14.data) {
        return value4.reply("❌ Failed to fetch emoji GIF!");
      }
      fs.writeFileSync(value6, value14.data);
      const value15 = "\"" + ffmpegPath() + "\" -i \"" + value6 + "\" -vf \"scale=512:512:force_original_aspect_ratio=decrease,fps=15,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 80 -compression_level 6 \"" + value7 + "\"";
      await new Promise((value16, value17) => {
        exec(value15, (value18, value19, value20) => {
          if (value18) {
            console.error("FFmpeg error:", value18);
            console.error("FFmpeg stderr:", value20);
            value17(value18);
          } else {
            value16();
          }
        });
      });
      if (!fs.existsSync(value7)) {
        throw new Error("FFmpeg failed to create output file");
      }
      const value21 = fs.statSync(value7);
      if (value21.size === 0) {
        throw new Error("FFmpeg created empty output file");
      }
      let value22 = fs.readFileSync(value7);
      const value23 = value22.length / 1024;
      console.log("Final emoji sticker size: " + Math.round(value23) + " KB");
      if (value23 > 1000) {
        console.log("⚠️ Warning: Sticker size (" + Math.round(value23) + " KB) exceeds recommended limit but will be sent anyway");
      }
      const value24 = new webp.Image();
      await value24.load(value22);
      const value25 = {
        "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
        "sticker-pack-name": database.getBotSetting("packname") || "June-X",
        emojis: [value11]
      };
      const value26 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
      const value27 = Buffer.from(JSON.stringify(value25), "utf8");
      const value28 = Buffer.concat([value26, value27]);
      value28.writeUIntLE(value27.length, 14, 4);
      value24.exif = value28;
      const value29 = await value24.save(null);
      await value1.sendMessage(value4.from, {
        sticker: value29
      }, {
        quoted: value2
      });
    } catch (error30) {
      console.error("Egif command error:", error30);
      await value4.reply("❌ Error: " + error30.message);
    } finally {
      value8.forEach(value31 => deleteTempFile(value31));
    }
  }
};
