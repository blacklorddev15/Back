const {
  getStats
} = require("../../utils/groupstats");
module.exports = {
  name: "groupstats",
  aliases: ["stats", "leaderboard", "gstats", "topmembers", "msgs", "messagestats"],
  category: "general",
  description: "Show today's group chat statistics",
  usage: ".groupstats",
  groupOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      const value6 = getStats(value5);
      if (!value6) {
        return value4.reply("📊 No activity recorded today.");
      }
      const {
        total: value7,
        users: value8
      } = value6;
      const value9 = Object.entries(value8).sort((value10, value11) => value11[1] - value10[1]).slice(0, 5);
      let value12 = value9.length ? value9.map(([value13, value14], value15) => value15 + 1 + ") @" + value13.split("@")[0] + " — " + value14 + " msgs").join("\n") : "No active users yet.";
      const value16 = ("\n📊 *Group Stats — Today*\n\n📌 *Total Messages:* " + value7 + "\n\n👥 *Top Active Members:*\n" + value12 + "\n\nType .myactivity to see your stats.\n").trim();
      await value1.sendMessage(value5, {
        text: value16,
        mentions: value9.map(value17 => value17[0])
      }, {
        quoted: value2
      });
    } catch (error18) {
      console.error("[groupstats cmd] error:", error18);
      value4.reply("❌ Error loading stats.");
    }
  }
};
