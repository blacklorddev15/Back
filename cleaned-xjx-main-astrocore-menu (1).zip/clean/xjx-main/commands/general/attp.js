const {
  spawn
} = require("child_process");
const ffmpegPath = require("../../utils/ffmpegPath");
const fs = require("fs");
const path = require("path");
const {
  writeExifVid
} = require("../../utils/exif");
module.exports = {
  name: "attp",
  aliases: ["ttp"],
  category: "general",
  description: "Create animated text sticker",
  usage: "<text>",
  async execute(value1, value2, value3, value4) {
    try {
      if (value3.length === 0) {
        return value4.reply("❌ Please provide text!\n\nExample: " + (value4.prefix || ".") + "attp Hello World");
      }
      const value5 = value3.join(" ");
      if (value5.length > 50) {
        return value4.reply("❌ Text is too long! Maximum 50 characters.");
      }
      try {
        const value6 = await renderBlinkingVideoWithFfmpeg(value5);
        const value7 = await writeExifVid(value6, {
          packname: "Knight Bot"
        });
        await value1.sendMessage(value4.from, {
          sticker: value7
        }, {
          quoted: value2
        });
      } catch (error8) {
        console.error("Error generating attp sticker:", error8);
        await value4.reply("❌ Failed to generate the sticker.");
      }
    } catch (error9) {
      console.error("ATTP command error:", error9);
      await value4.reply("❌ An error occurred while creating animated sticker!");
    }
  }
};
function renderBlinkingVideoWithFfmpeg(value10) {
  return new Promise((value11, value12) => {
    const value13 = process.platform === "win32" ? "C:/Windows/Fonts/arialbd.ttf" : "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf";
    const value14 = value15 => value15.replace(/\\/g, "\\\\").replace(/:/g, "\\:").replace(/,/g, "\\,").replace(/'/g, "\\'").replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/%/g, "\\%");
    const value16 = value14(value10);
    const value17 = process.platform === "win32" ? value13.replace(/\\/g, "/").replace(":", "\\:") : value13;
    const value18 = 0.3;
    const value19 = 1.8;
    const value20 = "drawtext=fontfile='" + value17 + "':text='" + value16 + "':fontcolor=red:borderw=2:bordercolor=black@0.6:fontsize=56:x=(w-text_w)/2:y=(h-text_h)/2:enable='lt(mod(t\\," + value18 + ")\\,0.1)'";
    const value21 = "drawtext=fontfile='" + value17 + "':text='" + value16 + "':fontcolor=blue:borderw=2:bordercolor=black@0.6:fontsize=56:x=(w-text_w)/2:y=(h-text_h)/2:enable='between(mod(t\\," + value18 + ")\\,0.1\\,0.2)'";
    const value22 = "drawtext=fontfile='" + value17 + "':text='" + value16 + "':fontcolor=green:borderw=2:bordercolor=black@0.6:fontsize=56:x=(w-text_w)/2:y=(h-text_h)/2:enable='gte(mod(t\\," + value18 + ")\\,0.2)'";
    const value23 = value20 + "," + value21 + "," + value22;
    const value24 = ["-y", "-f", "lavfi", "-i", "color=c=black:s=512x512:d=" + value19 + ":r=20", "-vf", value23, "-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart+frag_keyframe+empty_moov", "-t", String(value19), "-f", "mp4", "pipe:1"];
    const value25 = spawn(ffmpegPath(), value24);
    const value26 = [];
    const value27 = [];
    value25.stdout.on("data", value28 => value26.push(value28));
    value25.stderr.on("data", value29 => value27.push(value29));
    value25.on("error", value12);
    value25.on("close", value30 => {
      if (value30 === 0) {
        return value11(Buffer.concat(value26));
      }
      value12(new Error(Buffer.concat(value27).toString() || "ffmpeg exited with code " + value30));
    });
  });
}
