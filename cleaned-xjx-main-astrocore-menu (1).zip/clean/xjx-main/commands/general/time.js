const database = require("../../database");
module.exports = {
  name: "time",
  aliases: ["clock", "date", "now"],
  category: "general",
  description: "Show current date and time",
  usage: ".time or .time <timezone>",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value3.join(" ").trim() || database.getTimeZone();
      let value6 = true;
      try {
        new Date().toLocaleString("en-US", {
          timeZone: value5
        });
      } catch {
        value6 = false;
      }
      if (!value6) {
        return value4.reply("❌ Invalid timezone: *" + value5 + "*\n\nExample: *" + database.getBotSetting("prefix") + "time Africa/Nairobi*");
      }
      const value7 = new Date();
      const value8 = value7.toLocaleString("en-US", {
        timeZone: value5,
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true
      });
      const value9 = value7.toLocaleString("en-US", {
        timeZone: value5,
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric"
      });
      const value10 = parseInt(value7.toLocaleString("en-US", {
        timeZone: value5,
        hour: "numeric",
        hour12: false
      }));
      let value11;
      let value12;
      if (value10 >= 5 && value10 < 12) {
        value11 = "Good Morning";
        value12 = "🌅";
      } else if (value10 >= 12 && value10 < 17) {
        value11 = "Good Afternoon";
        value12 = "☀️";
      } else if (value10 >= 17 && value10 < 21) {
        value11 = "Good Evening";
        value12 = "🌇";
      } else {
        value11 = "Good Night";
        value12 = "🌙";
      }
      const value13 = value7.toLocaleString("en-US", {
        timeZone: value5,
        timeZoneName: "longOffset"
      }).split(" ").pop();
      let value14 = "🕐 *Current Time*\n━━━━━━━━━━━━━━━\n\n";
      value14 += value12 + " " + value11 + "!\n\n";
      value14 += "⏰ *Time:* " + value8 + "\n";
      value14 += "📅 *Date:* " + value9 + "\n";
      value14 += "🌍 *Timezone:* " + value5 + "\n";
      value14 += "🔄 *UTC Offset:* " + value13 + "\n";
      value14 += "\n━━━━━━━━━━━━━━━";
      await value4.reply(value14);
    } catch (error15) {
      await value4.reply("❌ Error: " + error15.message);
    }
  }
};
