const axios = require("axios");
const LANG_CODES = new Set(["af", "sq", "am", "ar", "hy", "az", "eu", "be", "bn", "bs", "bg", "ca", "ceb", "zh", "co", "hr", "cs", "da", "nl", "en", "eo", "et", "fi", "fr", "fy", "gl", "ka", "de", "el", "gu", "ht", "ha", "haw", "iw", "hi", "hmn", "hu", "is", "ig", "id", "ga", "it", "ja", "jw", "kn", "kk", "km", "rw", "ko", "ku", "ky", "lo", "la", "lv", "lt", "lb", "mk", "mg", "ms", "ml", "mt", "mi", "mr", "mn", "my", "ne", "no", "ny", "or", "ps", "fa", "pl", "pt", "pa", "ro", "ru", "sm", "gd", "sr", "st", "sn", "sd", "si", "sk", "sl", "so", "es", "su", "sw", "sv", "tl", "tg", "ta", "tt", "te", "th", "tr", "tk", "uk", "ur", "ug", "uz", "vi", "cy", "xh", "yi", "yo", "zu"]);
function getQuotedText(value1) {
  const value2 = value1.message?.extendedTextMessage?.contextInfo;
  if (!value2?.quotedMessage) {
    return null;
  }
  const value3 = value2.quotedMessage;
  return value3.conversation || value3.extendedTextMessage?.text || value3.imageMessage?.caption || value3.videoMessage?.caption || value3.documentMessage?.caption || null;
}
module.exports = {
  name: "tts",
  aliases: ["speak", "say"],
  category: "general",
  description: "Convert text to speech",
  usage: ".say <text>  |  .say <lang> <text>  |  reply to a message with .say",
  async execute(value4, value5, value6, value7) {
    try {
      let value8 = "en";
      let value9 = value6;
      if (value6.length >= 1 && LANG_CODES.has(value6[0].toLowerCase())) {
        value8 = value6[0].toLowerCase();
        value9 = value6.slice(1);
      }
      let value10 = value9.join(" ").trim();
      if (!value10) {
        const value11 = getQuotedText(value5);
        if (value11) {
          value10 = value11.trim();
        } else {
          const value12 = value7.prefix || ".";
          return value7.reply("🔊 *Text to Speech*\n\n*Usage:*\n" + ("• _" + value12 + "say <text>_ — speak text in English\n") + ("• _" + value12 + "say <lang> <text>_ — speak in a specific language\n") + ("• Reply to any message with _" + value12 + "say_ — speak the quoted text\n") + ("• Reply with _" + value12 + "say <lang>_ — speak quoted text in chosen language\n\n") + "*Common language codes:*\n`en` English  |  `sw` Swahili  |  `fr` French\n`ar` Arabic   |  `hi` Hindi    |  `es` Spanish\n`de` German   |  `zh` Chinese  |  `pt` Portuguese\n`ja` Japanese |  `ko` Korean   |  `ru` Russian\n\n*Examples:*\n" + ("_" + value12 + "say Hello World_\n") + ("_" + value12 + "say sw Habari yako_\n") + ("_" + value12 + "say fr_ _(reply to a message)_"));
        }
      }
      if (value10.length > 200) {
        return value7.reply("❌ Text too long! Maximum 200 characters.");
      }
      await value7.reply("🔊 Generating speech...");
      const value13 = "https://translate.google.com/translate_tts?ie=UTF-8&q=" + encodeURIComponent(value10) + "&tl=" + value8 + "&client=tw-ob";
      const value14 = await axios.get(value13, {
        responseType: "arraybuffer",
        timeout: 30000,
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          Referer: "https://translate.google.com/"
        }
      });
      const value15 = Buffer.from(value14.data);
      if (value15.length < 100) {
        throw new Error("Empty audio returned from TTS service");
      }
      await value4.sendMessage(value7.from, {
        audio: value15,
        mimetype: "audio/mpeg",
        ptt: false
      }, {
        quoted: value5
      });
    } catch (error16) {
      console.error("TTS command error:", error16);
      await value7.reply("❌ Failed to generate speech: " + error16.message);
    }
  }
};
