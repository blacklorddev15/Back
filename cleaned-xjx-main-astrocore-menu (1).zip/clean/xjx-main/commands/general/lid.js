const {
  jidDecode
} = require("@whiskeysockets/baileys");
const {
  jidUser,
  getLidMappingValue,
  rememberLidMapping,
  rememberParticipantLidMapping,
  resolvePhone
} = require("../../utils/jidHelper");
function isLidJid(value1) {
  try {
    const value2 = jidDecode(String(value1 || ""))?.server;
    return value2 === "lid" || value2 === "hosted.lid";
  } catch (error3) {
    return false;
  }
}
function isPnJid(value4) {
  try {
    const value5 = jidDecode(String(value4 || ""))?.server;
    return value5 === "s.whatsapp.net" || value5 === "hosted" || value5 === "c.us";
  } catch (error6) {
    return false;
  }
}
function asPnJid(value7) {
  const value8 = jidUser(value7);
  if (value8) {
    return value8 + "@s.whatsapp.net";
  } else {
    return null;
  }
}
function asLidJid(value9) {
  const value10 = jidUser(value9);
  if (value10) {
    return value10 + "@lid";
  } else {
    return null;
  }
}
function botUsers(value11) {
  const value12 = new Set();
  for (const value13 of [value11?.user?.id, value11?.user?.lid, value11?.user?.phoneNumber]) {
    const value14 = jidUser(value13);
    if (value14) {
      value12.add(value14);
    }
  }
  return value12;
}
function isBotJid(value15, value16) {
  const value17 = jidUser(value16);
  return !!value17 && !!botUsers(value15).has(value17);
}
function pairFromJid(value18) {
  if (!value18) {
    return {
      lid: null,
      pn: null
    };
  }
  return {
    lid: isLidJid(value18) ? value18 : null,
    pn: isPnJid(value18) ? value18 : null
  };
}
function collectInput(value19, value20, value21, value22) {
  const value23 = value19.message?.extendedTextMessage?.contextInfo || value19.message?.imageMessage?.contextInfo || value19.message?.videoMessage?.contextInfo || null;
  const value24 = value23?.mentionedJid?.[0];
  if (value24) {
    return {
      raw: value24,
      lid: isLidJid(value24) ? value24 : null,
      pn: isPnJid(value24) ? value24 : null,
      hint: "mention"
    };
  }
  if (value23?.quotedMessage && (value23.participant || value23.participantAlt)) {
    return {
      raw: value23.participantAlt || value23.participant,
      lid: isLidJid(value23.participant) ? value23.participant : isLidJid(value23.participantAlt) ? value23.participantAlt : null,
      pn: isPnJid(value23.participantAlt) ? value23.participantAlt : isPnJid(value23.participant) ? value23.participant : null,
      hint: "quoted"
    };
  }
  const value25 = (value20 || []).join(" ").trim();
  if (value25) {
    if (value25.includes("@lid") || value25.includes("@hosted.lid")) {
      return {
        raw: value25,
        lid: value25.includes("@") ? value25 : asLidJid(value25),
        pn: null,
        hint: "arg-lid"
      };
    }
    if (value25.includes("@s.whatsapp.net") || value25.includes("@hosted")) {
      return {
        raw: value25,
        lid: null,
        pn: value25,
        hint: "arg-pn"
      };
    }
    const value26 = value25.replace(/\D/g, "");
    if (value26.length >= 14) {
      return {
        raw: value25,
        lid: value26 + "@lid",
        pn: null,
        hint: "arg-lid"
      };
    }
    if (value26.length >= 7 && value26.length <= 15) {
      return {
        raw: value25,
        lid: null,
        pn: value26 + "@s.whatsapp.net",
        hint: "arg-pn"
      };
    }
    return {
      raw: value25,
      lid: null,
      pn: null,
      hint: "arg-unknown"
    };
  }
  const value27 = value21.isGroup ? [value19.key?.participantAlt, value19.key?.participant, value21.sender] : [value19.key?.remoteJidAlt, value21.from, value21.sender, value19.key?.remoteJid];
  let value28 = null;
  for (const value29 of value27) {
    if (!value29) {
      continue;
    }
    if (String(value29).endsWith("@g.us")) {
      continue;
    }
    if (isBotJid(value22, value29)) {
      continue;
    }
    value28 = value29;
    break;
  }
  if (!value28) {
    return {
      raw: null,
      lid: null,
      pn: null,
      hint: "need-target"
    };
  }
  const value30 = pairFromJid(value28);
  return {
    raw: value28,
    lid: value30.lid,
    pn: value30.pn,
    hint: value21.isGroup ? "sender" : "chat"
  };
}
function findParticipant(value31, value32) {
  if (!value31?.participants || !value32) {
    return null;
  }
  const value33 = jidUser(value32);
  return value31.participants.find(value34 => {
    if (!value34 || typeof value34 === "string") {
      return false;
    }
    const value35 = [value34.id, value34.lid, value34.userJid, value34.phoneNumber, value34.pn].filter(Boolean);
    return value35.includes(value32) || value35.some(value36 => jidUser(value36) === value33);
  }) || null;
}
async function resolvePair(value37, value38, value39) {
  const value40 = value37.signalRepository?.lidMapping;
  let value41 = value39.lid || null;
  let value42 = value39.pn && isPnJid(value39.pn) ? value39.pn : value39.pn ? asPnJid(value39.pn) : null;
  const value43 = [];
  const value44 = findParticipant(value38.groupMetadata, value41 || value42 || value39.raw);
  if (value44) {
    rememberParticipantLidMapping(value44);
    if (!value41 && (value44.lid || isLidJid(value44.id))) {
      value41 = value44.lid || value44.id;
      value43.push("group");
    }
    if (!value42 && (value44.phoneNumber || value44.pn || isPnJid(value44.id))) {
      const value45 = value44.phoneNumber || value44.pn || value44.id;
      value42 = value45.includes("@") ? value45 : value45 + "@s.whatsapp.net";
      value43.push("group");
    }
  }
  if (value41 && !value42) {
    try {
      if (value40?.getPNForLID) {
        const value46 = await value40.getPNForLID(value41);
        if (value46) {
          value42 = isPnJid(value46) ? value46 : asPnJid(value46);
          value43.push("baileys");
        }
      }
    } catch (error47) {}
    if (!value42) {
      const value48 = getLidMappingValue(jidUser(value41), "lidToPn");
      if (value48) {
        value42 = asPnJid(value48);
        value43.push("sqlite");
      }
    }
    if (!value42) {
      const value49 = await resolvePhone(value37, value41);
      if (value49) {
        value42 = asPnJid(value49);
        value43.push("helper");
      }
    }
  }
  if (value42 && !value41) {
    try {
      if (value40?.getLIDForPN) {
        const value50 = await value40.getLIDForPN(value42);
        if (value50) {
          value41 = isLidJid(value50) ? value50 : asLidJid(value50);
          value43.push("baileys");
        }
      }
    } catch (error51) {}
    if (!value41) {
      try {
        if (value40?.getLIDsForPNs) {
          const value52 = await value40.getLIDsForPNs([value42]);
          const value53 = Array.isArray(value52) ? value52[0] : null;
          const value54 = value53?.lid || null;
          if (value54) {
            value41 = isLidJid(value54) ? value54 : asLidJid(value54);
            value43.push("baileys");
          }
        }
      } catch (error55) {}
    }
    if (!value41) {
      const value56 = getLidMappingValue(jidUser(value42), "pnToLid");
      if (value56) {
        value41 = asLidJid(value56);
        value43.push("sqlite");
      }
    }
  }
  if (value41 && value42) {
    rememberLidMapping(value41, value42);
  }
  return {
    lid: value41,
    pn: value42,
    sources: [...new Set(value43)]
  };
}
module.exports = {
  name: "lid",
  aliases: ["lidinfo", "pn2lid", "resolve"],
  category: "general",
  description: "Resolve WhatsApp phone number ↔ LID",
  usage: ".lid [@user | number | reply]",
  async execute(value57, value58, value59, value60) {
    const value61 = collectInput(value58, value59, value60, value57);
    if (value61.hint === "need-target") {
      return value60.reply("🆔 *LID Resolver — No Target*\n\nProvide a target to resolve:\n\nUsage:\n  .lid @user\n  .lid 2348072642047\n  .lid 233256100331525@lid\n  reply + .lid");
    }
    if (value61.hint === "arg-unknown") {
      return value60.reply("🆔 *LID Resolver*\n\n" + ("Could not parse: *" + value61.raw + "*\n\n") + "Usage:\n  .lid @user\n  .lid 2348072642047\n  .lid 233256100331525@lid\n  reply + .lid");
    }
    try {
      if (value60.react) {
        await value60.react("🆔").catch(() => {});
      }
      const value62 = await resolvePair(value57, value60, value61);
      const value63 = value62.sources.length ? value62.sources.join(" · ") : value61.hint || "none";
      const value64 = ["┏━━『 LID MAP 』━━", "", "➥ Target    ➜ " + value61.raw, "➥ Phone     ➜ " + (value62.pn || "not cached"), "➥ LID       ➜ " + (value62.lid || "not cached"), "➥ Source    ➜ " + value63, "", "┗━━━━━━━━━━━━━━━━"];
      if (!value62.pn && value62.lid) {
        value64.splice(value64.length - 2, 0, "_PN is only known after WhatsApp has seen this user._");
      }
      if (value60.react) {
        await value60.react(value62.pn || value62.lid ? "✅" : "⚠️").catch(() => {});
      }
      await value60.reply(value64.join("\n"));
    } catch (error65) {
      console.error("[lid]", error65.message);
      if (value60.react) {
        await value60.react("❌").catch(() => {});
      }
      await value60.reply("❌ LID lookup failed: " + error65.message);
    }
  }
};
