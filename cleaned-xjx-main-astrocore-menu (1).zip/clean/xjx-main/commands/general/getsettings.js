const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
const on = "✅ ON";
const off = "❌ OFF";
const flag = value1 => value1 ? on : off;
module.exports = {
  name: "getsettings",
  aliases: ["settings", "gsettings", "setup", "howtoset"],
  category: "general",
  description: "Shows the current value of every bot and group setting",
  usage: ".settings",
  async execute(value2, value3, value4, value5) {
    try {
      const value6 = value5.from;
      const value7 = value6.endsWith("@g.us");
      const value8 = database.getBotSetting("prefix") || ".";
      const value9 = "> ᴘᴏᴡᴇʀᴇᴅ ʙʏ " + database.getBotSetting("botName");
      const value10 = [].concat(database.getOwners() || []).map(value11 => String(value11).replace(/\D/g, "")).filter(Boolean);
      const value12 = value10[0] || "";
      const value13 = (Array.isArray(database.getOwnerNames()) ? database.getOwnerNames()[0] : database.getOwnerNames()) || value12 || "N/A";
      const value14 = [{
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "👑 Contact Owner",
          url: value12 ? "https://wa.me/" + value12 : "https://wa.me"
        })
      }, {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "🔗 GitHub Repo",
          url: database.SOCIAL?.github || "https://github.com/Vinpink2/June-X-Ultra"
        })
      }];
      let value15 = "🌐 Public";
      try {
        value15 = require("../../utils/botMode").getModeLabel();
      } catch (error16) {}
      let value17 = {
        pm: "off",
        group: "off"
      };
      try {
        value17 = require("../../utils/presenceSettings").getModes();
      } catch (error18) {}
      const value19 = {
        typing: "⌨️ typing",
        recording: "🎙️ recording",
        recordtype: "🎙️⌨️ record+type",
        off: "off"
      };
      const value20 = value21 => value19[value21] || value21;
      const value22 = database.getBotSetting("autoReadMode") || "off";
      const value23 = database.getBotSetting("autoReact") || false;
      const value24 = database.getBotSetting("autoReactMode") || "bot";
      const value25 = database.getBotSetting("alwaysOnline") || false;
      const value26 = database.getBotSetting("selfMode") || false;
      const value27 = database.getBotSetting("autoBio") || false;
      const value28 = database.getAutoDownloadStatusSettings();
      const value29 = value28.enabled;
      const value30 = database.getMenuSettings();
      const value31 = database.getMenuImageSettings();
      const value32 = value30.menuStyle;
      const value33 = database.getBotSetting("fontStyle") || "normal";
      const value34 = database.getBotSetting("readReceipts") || "off";
      const value35 = {
        off: "🔵 off (blue ticks)",
        on: "⚪ on (grey ticks)",
        contacts: "👥 contacts only"
      }[value34] || value34;
      const value36 = database.loadSettings ? database.loadSettings() : {};
      const value37 = value36.enabled ?? database.getBotSetting("autoStatusView") ?? false;
      const value38 = value36.react ?? database.getBotSetting("autoStatusReact") ?? false;
      const value39 = value36.emoji ?? database.getBotSetting("autoStatusEmoji") ?? "💙";
      const value40 = value36.emojiPool ?? database.getBotSetting("autoStatusEmojiPool") ?? [];
      const value41 = value36.randomEmoji ?? database.getBotSetting("autoStatusRandomEmoji") ?? false;
      const value42 = value41 && value40.length ? "random pool: " + value40.join(" ") : value39;
      const value43 = database.getBotSetting("antibug") || false;
      const value44 = database.getBotSetting("antibugAction") || "delete";
      const value45 = database.getAntideleteMode();
      const value46 = database.getAntieditMode();
      const value47 = database.isAntideleteStatusEnabled();
      const value48 = database.getBotSetting("anticall") || false;
      const value49 = database.getBotSetting("anticallAction") || "decline";
      let value50 = "*CURRENT BOT SETTINGS*\n\n" + ("🔹 *prefix* : " + value8 + "\n") + ("🔹 *owner* : " + value13 + "\n") + ("🔹 *timezone* : " + database.getTimeZone() + "\n") + ("🔹 *botname* : " + database.getBotSetting("botName") + "\n") + ("🔹 *botmode* : " + value15 + "\n") + ("🔹 *selfmode* : " + flag(value26) + "\n") + ("🔹 *alwaysonline* : " + flag(value25) + "\n") + ("🔹 *presence (pm)*     : " + value20(value17.pm) + "\n") + ("🔹 *presence (group)*  : " + value20(value17.group) + "\n") + ("🔹 *readreceipts* : " + value35 + "\n") + ("🔹 *autoread* : " + value22 + "\n") + ("🔹 *autoreact* : " + flag(value23) + (value23 ? " — " + value24 : "") + "\n") + ("🔹 *autobio* : " + flag(value27) + "\n") + ("🔹 *autodownload* : " + flag(value29) + (value29 ? " — " + value28.mode : "") + "\n") + ("🔹 *autostatusview* : " + flag(value37) + "\n") + ("🔹 *autostatusreact* : " + flag(value38) + "\n") + ("🔹 *autostatusemoji* : " + value42 + "\n") + ("🔹 *antideletestatus* : " + flag(value47) + "\n") + ("🔹 *antibug* : " + flag(value43) + (value43 ? " — " + value44 : "") + "\n") + ("🔹 *antidelete* : " + value45 + "\n") + ("🔹 *antiedit* : " + value46 + "\n") + ("🔹 *anticall* : " + flag(value48) + (value48 ? " — " + value49 : "") + "\n") + ("🔹 *menustyle* : " + value32 + "\n") + ("🔹 *menumemory* : " + flag(value30.showMemory) + "\n") + ("🔹 *menuuptime* : " + flag(value30.showUptime) + "\n") + ("🔹 *menucommands* : " + flag(value30.showPluginCount) + "\n") + ("🔹 *menuprogress* : " + flag(value30.showProgressBar) + "\n") + ("🔹 *menuimage* : " + (value31.custom ? "custom (SQLite)" : "bundled default") + "\n") + ("🔹 *fontstyle* : " + value33 + "\n");
      if (value7) {
        let value51 = "This Group";
        try {
          const value52 = await value2.groupMetadata(value6);
          value51 = value52?.subject || "This Group";
        } catch (error53) {}
        const value54 = database.getGroupSettings(value6);
        const value55 = database.getAntiTagAdminsSettings(value6);
        const value56 = database.isAntiAllEnabled(value6);
        const value57 = value58 => value54[value58] ? " — " + value54[value58] : "";
        value50 += "\n*GROUP: " + value51 + "*\n\n" + ("🔹 *antilink* : " + flag(value54.antilink) + value57("antilinkAction") + "\n") + ("🔹 *antitag* : " + flag(value54.antitag) + value57("antitagAction") + "\n") + ("🔹 *antitagadmins* : " + flag(value55.enabled) + (value55.enabled ? " — " + value55.action : "") + "\n") + ("🔹 *antiimage* : " + flag(value54.antiimage) + value57("antiimageAction") + "\n") + ("🔹 *antisticker* : " + flag(value54.antisticker) + value57("antistickerAction") + "\n") + ("🔹 *antiaudio* : " + flag(value54.antiaudio) + value57("antiaudioAction") + "\n") + ("🔹 *antigif* : " + flag(value54.antigif) + value57("antigifAction") + "\n") + ("🔹 *anticontact* : " + flag(value54.anticontact) + value57("anticontactAction") + "\n") + ("🔹 *antibadword* : " + flag(value54.antibadword) + value57("antibadwordAction") + "\n") + ("🔹 *antiviewonce* : " + flag(value54.antiviewonce) + "\n") + ("🔹 *antiforward* : " + flag(value54.antiforward) + "\n") + ("🔹 *antibot* : " + flag(value54.antibot) + "\n") + ("🔹 *antiall* : " + flag(value56) + "\n") + ("🔹 *antivideo* : " + flag(value54.antivideo) + "\n") + ("🔹 *antidemote* : " + flag(value54.antidemote) + "\n") + ("🔹 *antipromote* : " + flag(value54.antipromote) + "\n") + ("🔹 *antikickall* : " + flag(value54.antikickall) + "\n") + ("🔹 *antigroupmention* : " + flag(value54.antigroupmention) + value57("antigroupmentionAction") + "\n") + ("🔹 *antigroupstatus* : " + flag(value54.antigroupstatus) + value57("antigroupstatusAction") + "\n") + ("🔹 *antispam* : " + flag(value54.antiSpam) + (value54.antiSpam ? " — " + (value54.antiSpamLimit || 5) + " msgs/" + (value54.antiSpamWindow || 5) + "s → " + (value54.antiSpamAction || "delete") : "") + "\n") + ("🔹 *welcome* : " + flag(value54.welcome) + "\n") + ("🔹 *goodbye* : " + flag(value54.goodbye) + "\n") + ("🔹 *chatbot* : " + flag(value54.chatbot) + "\n") + ("🔹 *autosticker* : " + flag(value54.autosticker) + "\n") + ("🔹 *nsfw* : " + flag(value54.nsfw) + "\n");
      }
      try {
        await sendButtons(value2, value6, {
          text: value50,
          footer: value9,
          buttons: value14
        }, {
          quoted: value3
        });
      } catch (error59) {
        console.error("getsettings interactive buttons unavailable:", error59.message);
        await value2.sendMessage(value6, {
          text: value50,
          footer: value9
        }, {
          quoted: value3
        });
      }
    } catch (error60) {
      console.error("getsettings error:", error60);
      await value5.reply("❌ Error: " + error60.message);
    }
  }
};
