const {
  FONTS
} = require("../../utils/fontConverter");
const NORMAL_LOWER = "abcdefghijklmnopqrstuvwxyz";
const NORMAL_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const NORMAL_DIGITS = "0123456789";
const COMBINING_STYLES = [{
  label: "Underline",
  char: "̲"
}, {
  label: "Double Underline",
  char: "̳"
}, {
  label: "Overline",
  char: "̅"
}, {
  label: "Wavy Below",
  char: "̰"
}, {
  label: "Dotted Above",
  char: "̇"
}, {
  label: "Ring Above",
  char: "̊"
}, {
  label: "Tilde Above",
  char: "̃"
}, {
  label: "Tilde Overlay",
  char: "̴"
}, {
  label: "Acute Above",
  char: "́"
}, {
  label: "Grave Above",
  char: "̀"
}, {
  label: "Circumflex",
  char: "̂"
}, {
  label: "Diaeresis",
  char: "̈"
}, {
  label: "Slash Through",
  char: "̸"
}];
const FONT_LABELS = {
  bold: "Bold",
  italic: "Italic",
  bolditalic: "Bold Italic",
  serif: "Serif Bold",
  serifitalic: "Serif Italic",
  serifbolditalic: "Serif Bold Italic",
  script: "Script Bold",
  scriptlight: "Script",
  gothic: "Gothic",
  gothicbold: "Gothic Bold",
  mono: "Monospace",
  double: "Double Struck",
  circled: "Circled",
  squared: "Squared",
  fullwidth: "Full Width",
  smallcaps: "Small Caps",
  superscript: "Superscript",
  inverted: "Inverted/Flip",
  bubbles: "Bubbles",
  strikethrough: "Strikethrough",
  sansserif: "Sans Serif",
  parenthesized: "Parenthesized"
};
function convertChar(value1, value2) {
  const value3 = NORMAL_LOWER.indexOf(value1);
  if (value3 !== -1) {
    const value4 = [...value2.lower];
    return value4[value3] || value1;
  }
  const value5 = NORMAL_UPPER.indexOf(value1);
  if (value5 !== -1) {
    const value6 = [...value2.upper];
    return value6[value5] || value1;
  }
  const value7 = NORMAL_DIGITS.indexOf(value1);
  if (value7 !== -1) {
    const value8 = [...value2.digits];
    return value8[value7] || value1;
  }
  return value1;
}
function applyFontStyle(value9, value10) {
  return [...value9].map(value11 => convertChar(value11, value10)).join("");
}
function applyCombining(value12, value13) {
  return [...value12].map(value14 => /\s/.test(value14) ? value14 : value14 + value13).join("");
}
function buildLines(value15) {
  const value16 = [];
  let value17 = 1;
  for (const [value18, value19] of Object.entries(FONTS)) {
    if (value18 === "normal") {
      continue;
    }
    const value20 = FONT_LABELS[value18] || value18;
    value16.push("*" + value17 + ".* " + applyFontStyle(value15, value19) + "  _[" + value20 + "]_");
    value17++;
  }
  for (const value21 of COMBINING_STYLES) {
    value16.push("*" + value17 + ".* " + applyCombining(value15, value21.char) + "  _[" + value21.label + "]_");
    value17++;
  }
  return value16;
}
function extractStyledText(value22) {
  return value22.replace(/^\*\d+\.\*\s*/, "").replace(/\s{2}_\[.+?\]_$/, "").trim();
}
module.exports = {
  name: "fancy",
  aliases: ["fancytext", "stylish", "fonts"],
  category: "general",
  description: "Show text in all 35 Unicode font styles",
  usage: ".fancy <text>  |  reply to fancy list with .fancy <number>",
  async execute(value23, value24, value25, value26) {
    const value27 = value24.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const value28 = value27?.conversation || value27?.extendedTextMessage?.text || "";
    const value29 = value28.includes("Fancy Styles for:");
    const value30 = value25.length === 1 && /^\d+$/.test(value25[0]);
    if (value29 && value30) {
      const value31 = parseInt(value25[0]);
      const value32 = value28.split("\n");
      const value33 = "*" + value31 + ".*";
      const value34 = value32.find(value35 => value35.trimStart().startsWith(value33));
      if (!value34) {
        const value36 = value32.filter(value37 => /^\*\d+\.\*/.test(value37.trimStart())).length;
        const value38 = value36 > 0 ? " Pick a number between 1 and " + value36 + "." : "";
        return value26.reply("❌ Style #" + value31 + " not found." + value38);
      }
      const value39 = extractStyledText(value34);
      return value26.reply(value39);
    }
    let value40 = value25.join(" ").trim();
    if (!value40 && value28 && !value29) {
      value40 = value28.trim();
    }
    if (!value40) {
      return value26.reply("❌ Provide some text.\n\nExample: *.fancy Hello World*\nOr reply to any message with *.fancy*\n\n_Then reply to the result with_ *.fancy <number>* _to pick one style._");
    }
    await value26.react("✨");
    const value41 = buildLines(value40);
    const value42 = value41.length;
    const value43 = "✨ *Fancy Styles for:* _" + value40 + "_\n" + ("━━━━━━━━━━━━━━━ (" + value42 + " styles)\n\n");
    const value44 = "\n━━━━━━━━━━━━━━━\n_Reply to this message with_ *.fancy <number>* or <number>";
    const value45 = value43 + value41.join("\n") + value44;
    const value46 = 60000;
    if (value45.length <= value46) {
      await value26.reply(value45);
    } else {
      let value47 = value43;
      for (const value48 of value41) {
        if ((value47 + value48 + "\n").length > value46) {
          await value26.reply(value47.trimEnd());
          value47 = "";
        }
        value47 += value48 + "\n";
      }
      if (value47.trim()) {
        await value26.reply(value47.trimEnd() + value44);
      }
    }
  }
};
