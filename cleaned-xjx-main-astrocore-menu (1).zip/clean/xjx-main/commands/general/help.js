'use strict';

const fs = require("fs");
const path = require("path");
const {
  loadCommands
} = require("../../utils/commandLoader");
const {
  sendRichApp,
  RICH_FALLBACK
} = require("../../utils/richApp");
const TEMPLATE = fs.readFileSync(path.join(__dirname, "help.html"), "utf8");
function collectCommands() {
  const value1 = new Set();
  const value2 = {};
  for (const [, value3] of loadCommands() || new Map()) {
    if (!value3 || !value3.name || value1.has(value3.name)) {
      continue;
    }
    value1.add(value3.name);
    const value4 = String(value3.category || "other").toLowerCase();
    (value2[value4] = value2[value4] || []).push({
      n: value3.name,
      a: Array.isArray(value3.aliases) ? value3.aliases.slice(0, 4) : [],
      d: String(value3.description || "").slice(0, 90),
      u: String(value3.usage || "." + value3.name).slice(0, 40)
    });
  }
  const value5 = {};
  for (const value6 of Object.keys(value2).sort()) {
    value5[value6] = value2[value6].sort((value7, value8) => value7.n.localeCompare(value8.n));
  }
  return value5;
}
function buildHtml(value9, value10) {
  const value11 = JSON.stringify({
    prefix: value10,
    cats: value9
  }).replace(/</g, "\\u003c");
  return TEMPLATE.replace("__MENUDATA__", value11);
}
module.exports = {
  name: "help",
  aliases: ["help"],
  category: "games",
  description: "BETA interactive menu card — tappable command list (mini-app)",
  usage: ".help",
  async execute(value12, value13, value14, value15) {
    const value16 = value15.from || value13.key.remoteJid;
    try {
      const value17 = value15.prefix || ".";
      await sendRichApp(value12, value13, buildHtml(collectCommands(), value17), value16);
    } catch (error18) {
      console.error("[help] command unavailable:", error18.message);
      await value12.sendMessage(value16, {
        text: RICH_FALLBACK("MINI MENU")
      }, {
        quoted: value13
      }).catch(() => {});
    }
  }
};
