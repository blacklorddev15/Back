const APIs = require("../../utils/api");
module.exports = {
  name: "ssweb",
  aliases: ["screenshot", "ss", "webss"],
  category: "general",
  description: "Take a screenshot of a website",
  usage: ".ssweb <url>",
  async execute(value1, value2, value3, value4) {
    try {
      if (value3.length === 0) {
        return value4.reply("❌ Please provide a website URL!\n\nExample: .ssweb https://github.com");
      }
      const value5 = value3.join(" ");
      if (!value5.startsWith("http://") && !value5.startsWith("https://")) {
        return value4.reply("❌ Please provide a valid URL starting with http:// or https://");
      }
      await value1.sendMessage(value4.from, {
        react: {
          text: "📥",
          key: value2.key
        }
      });
      const value6 = await APIs.screenshotWebsite(value5);
      const value7 = typeof value6 === "string" ? {
        url: value6
      } : value6;
      await value1.sendMessage(value4.from, {
        image: value7
      }, {
        quoted: value2
      });
    } catch (error8) {
      console.error("SSWeb command error:", error8);
      await value4.reply("❌ Failed to screenshot website: " + error8.message);
    }
  }
};
