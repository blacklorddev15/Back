const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const {
  exec
} = require("child_process");
const ffmpegPath = require("../../utils/ffmpegPath");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const webp = require("node-webpmux");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const database = require("../../database");
const MAX_FILE_SIZE = 52428800;
const getQuotedMessage = value1 => value1.message?.extendedTextMessage?.contextInfo?.quotedMessage || value1.message?.buttonsResponseMessage?.contextInfo?.quotedMessage || value1.message?.listResponseMessage?.contextInfo?.quotedMessage || null;
const resolveMedia = value2 => {
  const value3 = Object.keys(value2.message || {})[0];
  if (value3 === "imageMessage" || value3 === "stickerMessage" || value3 === "videoMessage" || value3 === "documentMessage") {
    return {
      type: value3,
      media: value2.message[value3]
    };
  }
  const value4 = getQuotedMessage(value2);
  if (!value4) {
    return null;
  }
  const value5 = Object.keys(value4 || {})[0];
  if (value5 === "imageMessage" || value5 === "stickerMessage" || value5 === "videoMessage" || value5 === "documentMessage") {
    return {
      type: value5,
      media: value4[value5]
    };
  }
  return null;
};
module.exports = {
  name: "crop",
  aliases: ["square", "cropper"],
  description: "Crop sticker/image/video to a perfect square sticker (animated for videos)",
  usage: ".crop (reply to sticker/image/video)",
  category: "general",
  async execute(value6, value7, value8, value9) {
    const value10 = getTempDir();
    const value11 = path.join(value10, "temp_" + Date.now());
    const value12 = path.join(value10, "crop_" + Date.now() + ".webp");
    const value13 = [value11, value12];
    try {
      const value14 = value7;
      let value15 = value7;
      if (value7.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
        const value16 = value7.message.extendedTextMessage.contextInfo;
        value15 = {
          key: {
            remoteJid: value9.from,
            id: value16.stanzaId,
            participant: value16.participant
          },
          message: value16.quotedMessage
        };
      }
      const value17 = resolveMedia(value15);
      if (!value17) {
        return value9.reply("✂️ Reply to a *sticker*, *image*, or *video* that you want to crop.");
      }
      const {
        type: value18,
        media: value19
      } = value17;
      const value20 = value19;
      if (!value20) {
        return value9.reply("✂️ Please reply to an image/video/sticker with .crop, or send an image/video/sticker with .crop as the caption.");
      }
      const value21 = await downloadMediaMessage(value15, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value6.updateMediaMessage
      });
      if (!value21) {
        return value9.reply("❌ Failed to download media. Please try again.");
      }
      if (value21.length > MAX_FILE_SIZE) {
        return value9.reply("❌ File too large: " + (value21.length / 1024 / 1024).toFixed(2) + "MB (max: " + MAX_FILE_SIZE / 1024 / 1024 + "MB)");
      }
      fs.writeFileSync(value11, value21);
      const value22 = value20.mimetype?.includes("gif") || value20.mimetype?.includes("video") || value20.seconds > 0 || value18 === "videoMessage";
      const value23 = value21.length / 1024;
      const value24 = value23 > 5000;
      let value25;
      if (value22) {
        if (value24) {
          value25 = "\"" + ffmpegPath() + "\" -i \"" + value11 + "\" -t 2 -vf \"crop=min(iw\\,ih):min(iw\\,ih),scale=512:512,fps=8\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 30 -compression_level 6 -b:v 100k -max_muxing_queue_size 1024 \"" + value12 + "\"";
        } else {
          value25 = "\"" + ffmpegPath() + "\" -i \"" + value11 + "\" -t 3 -vf \"crop=min(iw\\,ih):min(iw\\,ih),scale=512:512,fps=12\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 50 -compression_level 6 -b:v 150k -max_muxing_queue_size 1024 \"" + value12 + "\"";
        }
      } else {
        value25 = "\"" + ffmpegPath() + "\" -i \"" + value11 + "\" -vf \"crop=min(iw\\,ih):min(iw\\,ih),scale=512:512,format=rgba\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 75 -compression_level 6 \"" + value12 + "\"";
      }
      await new Promise((value26, value27) => {
        exec(value25, (value28, value29, value30) => {
          if (value28) {
            console.error("FFmpeg error:", value28);
            console.error("FFmpeg stderr:", value30);
            value27(value28);
          } else {
            console.log("FFmpeg stdout:", value29);
            value26();
          }
        });
      });
      if (!fs.existsSync(value12)) {
        throw new Error("FFmpeg failed to create output file");
      }
      const value31 = fs.statSync(value12);
      if (value31.size === 0) {
        throw new Error("FFmpeg created empty output file");
      }
      let value32 = fs.readFileSync(value12);
      const value33 = value32.length / 1024;
      console.log("Final sticker size: " + Math.round(value33) + " KB");
      if (value33 > 1000) {
        console.log("⚠️ Warning: Sticker size (" + Math.round(value33) + " KB) exceeds recommended limit but will be sent anyway");
      }
      const value34 = new webp.Image();
      await value34.load(value32);
      const value35 = {
        "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
        "sticker-pack-name": database.getBotSetting("packname") || "June-X",
        emojis: ["✂️"]
      };
      const value36 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
      const value37 = Buffer.from(JSON.stringify(value35), "utf8");
      const value38 = Buffer.concat([value36, value37]);
      value38.writeUIntLE(value37.length, 14, 4);
      value34.exif = value38;
      const value39 = await value34.save(null);
      await value6.sendMessage(value9.from, {
        sticker: value39
      }, {
        quoted: value14
      });
    } catch (error40) {
      console.error("Crop command error:", error40);
      await value9.reply("❌ Failed to crop sticker! Try with an image or video.");
    } finally {
      value13.forEach(value41 => deleteTempFile(value41));
    }
  }
};
