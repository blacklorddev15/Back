const os = require("os");
const botStartTime = Date.now() - Math.floor(process.uptime() * 1000);
const detectPlatform = () => {
  if (process.env.DYNO) {
    return "☁️ Heroku";
  }
  if (process.env.RENDER) {
    return "⚡ Render";
  }
  if (process.env.RAILWAY_ENVIRONMENT || process.env.RAILWAY_PROJECT_ID) {
    return "🚉 Railway";
  }
  if (process.env.REPLIT_SLUG || process.env.REPL_ID) {
    return "🔵 Replit";
  }
  if (process.env.P_SERVER_UUID) {
    return "🖥️ Panel";
  }
  switch (os.platform()) {
    case "win32":
      return "🪟 Windows";
    case "darwin":
      return "🍎 macOS";
    case "linux":
      return "🐧 Linux";
    default:
      return "❓ Unknown";
  }
};
const formatUptime = value1 => {
  const value2 = Math.floor(value1 / 1000);
  const value3 = Math.floor(value2 / 86400);
  const value4 = Math.floor(value2 % 86400 / 3600);
  const value5 = Math.floor(value2 % 3600 / 60);
  const value6 = value2 % 60;
  const value7 = [];
  if (value3 > 0) {
    value7.push(value3 + "d");
  }
  if (value4 > 0) {
    value7.push(value4 + "h");
  }
  if (value5 > 0) {
    value7.push(value5 + "m");
  }
  value7.push(value6 + "s");
  return value7.join(" ");
};
module.exports = {
  name: "alive",
  aliases: ["botcheck"],
  category: "general",
  description: "Check if the bot is alive and running",
  usage: ".alive",
  ownerOnly: false,
  async execute(value8, value9, value10, value11) {
    const {
      reply: value12
    } = value11;
    const value13 = Date.now() - botStartTime;
    const value14 = process.memoryUsage();
    const value15 = (value14.heapUsed / 1024 / 1024).toFixed(1);
    const value16 = (value14.heapTotal / 1024 / 1024).toFixed(1);
    const value17 = [" 🍎 *Bot is Alive for:* " + formatUptime(value13), " 🔹 *Running on:* " + detectPlatform(), " 🔹 *Bot Memory:* " + value15 + "MB / " + value16 + "MB"].join("\n");
    await value12(value17);
  }
};
