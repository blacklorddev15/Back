const qrcode = require("qrcode");
module.exports = {
  name: "qr",
  aliases: ["qrcode"],
  category: "general",
  description: "Generate QR code from text",
  usage: ".qr <text>",
  async execute(value1, value2, value3, value4) {
    try {
      if (value3.length === 0) {
        return value4.reply("❌ Usage: .qr <text>\n\nExample: .qr https://google.com");
      }
      const value5 = value3.join(" ");
      const value6 = await qrcode.toBuffer(value5, {
        type: "png",
        width: 500,
        margin: 2
      });
      await value1.sendMessage(value4.from, {
        image: value6,
        caption: "✅ QR Code Generated!\n\n📝 Text: " + value5
      }, {
        quoted: value2
      });
    } catch (error7) {
      await value4.reply("❌ Error: " + error7.message);
    }
  }
};
