const axios = require("axios");
const {
  tryFetchProfilePictureUrl,
  displayUserTag
} = require("../../utils/jidHelper");
function toJid(value1) {
  if (!value1) {
    return null;
  }
  let value2 = String(value1).trim();
  if (value2.includes("@")) {
    return value2;
  }
  value2 = value2.replace(/[^0-9]/g, "");
  if (!value2) {
    return null;
  }
  return value2 + "@s.whatsapp.net";
}
async function downloadBuffer(value3, value4 = 3) {
  for (let value5 = 0; value5 < value4; value5++) {
    try {
      const value6 = await axios.get(value3, {
        responseType: "arraybuffer",
        timeout: 30000,
        headers: {
          "User-Agent": "WhatsApp/2.24.6.77 A"
        }
      });
      return Buffer.from(value6.data);
    } catch (error7) {
      if (value5 === value4 - 1) {
        throw error7;
      }
      await new Promise(value8 => setTimeout(value8, (value5 + 1) * 1000));
    }
  }
}
module.exports = {
  name: "getpp",
  aliases: ["gp", "getpic", "getdp", "profilepic", "pp", "pfp"],
  category: "general",
  description: "Get profile picture of a user (works in DMs and groups, supports @lid)",
  usage: ".getpp <phone> | reply | tag | (no arg = your own)",
  async execute(value9, value10, value11, value12) {
    try {
      let value13 = null;
      const value14 = value10.message?.extendedTextMessage?.contextInfo || value10.message?.imageMessage?.contextInfo || value10.message?.videoMessage?.contextInfo || {};
      if (Array.isArray(value14.mentionedJid) && value14.mentionedJid.length) {
        value13 = value14.mentionedJid[0];
      }
      if (!value13 && value11 && value11.length && value11[0] && !value11[0].startsWith("@")) {
        value13 = toJid(value11[0]);
      }
      if (!value13 && value14.quotedMessage) {
        if (value14.participant) {
          value13 = value14.participant;
        } else if (value14.remoteJid && value14.remoteJid.endsWith("@s.whatsapp.net")) {
          value13 = value14.remoteJid;
        }
      }
      if (!value13) {
        value13 = value12.sender || value10.key.participant || value10.key.remoteJid;
      }
      if (!value13) {
        return value12.reply("❌ Could not identify target user.\n\nUsage:\n• .getpp 254798570132\n• .getpp @user\n• Reply to a message with .getpp");
      }
      const value15 = value12.from || value10.key.remoteJid;
      const value16 = value12.groupMetadata || null;
      const value17 = displayUserTag(value13, value16);
      let value18;
      try {
        value18 = await tryFetchProfilePictureUrl(value9, value13, value16);
      } catch (error19) {
        const value20 = error19?.output?.statusCode;
        const value21 = (error19?.message || "").toLowerCase();
        if (value20 === 401 || value21.includes("forbidden") || value21.includes("unauthorized")) {
          return value12.reply("❌ @" + value17 + "'s profile picture is private.");
        }
        if (value20 === 404 || value20 === 500 || value21.includes("not found") || value21.includes("item-not-found")) {
          return value12.reply("❌ No profile picture set for @" + value17 + ".");
        }
        return value12.reply("❌ Could not fetch profile picture for @" + value17 + ".");
      }
      if (!value18 || !value18.url) {
        return value12.reply("❌ No profile picture found for @" + value17 + ".");
      }
      let value22;
      try {
        value22 = await downloadBuffer(value18.url);
      } catch (error23) {
        return value12.reply("❌ Failed to download profile picture for @" + value17 + ". Try again later.");
      }
      await value9.sendMessage(value15, {
        image: value22,
        caption: "👤 Profile picture of @" + value17,
        mentions: [value13, value18.jid].filter((value24, value25, value26) => value24 && value26.indexOf(value24) === value25)
      }, {
        quoted: value10
      });
    } catch (error27) {
      try {
        await value12.reply("❌ Profile picture not found for this user.");
      } catch (error28) {}
    }
  }
};
