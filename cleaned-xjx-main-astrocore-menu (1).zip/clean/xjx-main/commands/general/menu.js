const {
  loadCommands
} = require("../../utils/commandLoader");
const {
  generateWAMessageFromContent,
  proto
} = require("@whiskeysockets/baileys");
const {
  sendButtons
} = require("gifted-btns");
const {
  applyFont
} = require("../../utils/fontConverter");
const fs = require("fs");
const path = require("path");
const os = require("os");
const db = require("../../database");
const MENU_SETTINGS_FILE = path.join(__dirname, "../../data/menuSettings.json");
function createFakeContact(value1) {
  const value2 = "ASTROCORE";
  const value3 = String(global.currentSock?.user?.id || global.phoneNumber || "").split("@")[0].split(":")[0].replace(/\D/g, "") || "0";
  return {
    key: {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      id: "ASTROCORE" + Math.random().toString(36).substring(2, 12).toUpperCase()
    },
    message: {
      contactMessage: {
        displayName: value2,
        vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;" + value2 + ";;;;\nFN:" + value2 + "\nitem1.TEL;waid=" + value3 + ":" + value3 + "\nitem1.X-ABLabel:Ponsel\nEND:VCARD"
      }
    }
  };
}
const detectPlatform = () => {
  if (process.env.RAILWAY_ENVIRONMENT || process.env.RAILWAY_PROJECT_ID) {
    return "🚉 Railway";
  }
  if (process.env.DYNO) {
    return "☁️ Heroku";
  }
  if (process.env.RENDER) {
    return "⚡ Render";
  }
  if (process.env.REPL_ID || process.env.REPL_SLUG) {
    return "🔵 Replit";
  }
  if (process.env.PREFIX && process.env.PREFIX.includes("termux")) {
    return "📱 Termux";
  }
  if (process.env.PORTS && process.env.CYPHERX_HOST_ID) {
    return "🌀 CypherX Platform";
  }
  if (process.env.P_SERVER_UUID) {
    return "🖥️ Panel";
  }
  if (process.env.LXC) {
    return "📦 Linux Container (LXC)";
  }
  switch (os.platform()) {
    case "win32":
      return "🪟 Windows";
    case "darwin":
      return "🍎 macOS";
    case "linux":
      return "🐧 Linux";
    default:
      return "❓ Unknown";
  }
};
function getMenuStyle() {
  try {
    const value5 = require("../../database");
    const value6 = value5.getMenuSettings ? value5.getMenuSettings() : null;
    if (value6 && value6.menuStyle) {
      return String(value6.menuStyle);
    }
  } catch {}
  try {
    const value7 = require("../../utils/settings");
    const value8 = value7.get("menuStyle");
    if (value8 && value8 !== "1") {
      return value8;
    }
    if (!fs.existsSync(MENU_SETTINGS_FILE)) {
      return value8 || "5";
    }
    return JSON.parse(fs.readFileSync(MENU_SETTINGS_FILE, "utf8")).menuStyle || value8 || "1";
  } catch {
    return "1";
  }
}
function formatUptime() {
  const value9 = Math.floor(process.uptime());
  const value10 = Math.floor(value9 / 86400);
  const value11 = Math.floor(value9 % 86400 / 3600);
  const value12 = Math.floor(value9 % 3600 / 60);
  const value13 = value9 % 60;
  const value14 = [];
  if (value10) {
    value14.push(value10 + "d");
  }
  if (value11) {
    value14.push(value11 + "h");
  }
  if (value12) {
    value14.push(value12 + "m");
  }
  value14.push(value13 + "s");
  return value14.join(" ");
}
function formatMemory(value15) {
  if (value15 >= 1073741824) {
    return (value15 / 1073741824).toFixed(2) + " GB";
  }
  if (value15 >= 1048576) {
    return (value15 / 1048576).toFixed(1) + " MB";
  }
  return (value15 / 1024).toFixed(0) + " KB";
}
const progressBar = (value16, value17, value18 = 10) => {
  const value19 = Math.round(value16 / value17 * value18);
  const value20 = "█".repeat(value19) + "░".repeat(value18 - value19);
  return "[" + value20 + "] " + Math.round(value16 / value17 * 100) + "%";
};
const CATEGORY_ORDER = ["general", "ai", "admin", "owner", "media", "sports", "fun", "utility", "anime", "textmaker"];
const CATEGORY_LABELS = {
  general: "GEN-CMD",
  ai: "AI-CMD",
  admin: "ADM-CMD",
  owner: "OWN-CMD",
  media: "MEDIA-CMD",
  sports: "SPORT-CMD",
  fun: "FUN-CMD",
  utility: "UTIL-CMD",
  anime: "ANIME-CMD",
  textmaker: "MAKER-CMD"
};
function buildMenuText(value21, value22, value23, value24) {
  const value25 = db.getBotSetting("prefix");
  const value26 = db.getBotSetting("botName") || "JuneX-Ultra";
  const value27 = (Array.isArray(db.getOwnerNames()) ? db.getOwnerNames()[0] : db.getOwnerNames()) || "Bot Owner";
  const value28 = detectPlatform();
  const value29 = formatUptime();
  const {
    getModeLabel: value30
  } = require("../../utils/botMode");
  const value31 = value30();
  const value32 = os.totalmem();
  const value33 = process.memoryUsage().rss;
  const value34 = value32 - os.freemem();
  const value35 = "";
  const value36 = Number.isInteger(value24) ? "" + value24 : value24.toFixed(2);
  let value37 = {
    showUptime: true,
    showMemory: true,
    showProgressBar: true,
    showPluginCount: true
  };
  try {
    const value38 = require("../../database");
    if (value38.getMenuSettings) {
      value37 = {
        ...value37,
        ...value38.getMenuSettings()
      };
    }
  } catch {}
  let value39 = "┏━━❐◈  " + value26 + " ◈\n";
  value39 += "┃ *ᴘʀᴇꜰɪx:* [ " + value25 + " ]\n";
  value39 += "┃ *ᴏᴡɴᴇʀ:* " + value27 + "\n";
  value39 += "┃ *ᴍᴏᴅᴇ:* " + value31 + "\n";
  value39 += "┃ *ᴘʟᴀᴛꜰᴏʀᴍ:* " + value28 + "\n";
  value39 += "┃ *ꜱᴘᴇᴇᴅ:* " + value36 + " ms\n";
  if (value37.showUptime) {
    value39 += "┃ *ᴜᴘᴛɪᴍᴇ:* " + value29 + "\n";
  }
  value39 += "┃ *Vᴇʀꜱɪᴏɴ:* v" + db.VERSION + "\n";
  if (value37.showMemory) {
    value39 += "┃ *ᴜꜱᴀɢᴇ:* " + formatMemory(value33) + " of " + formatMemory(value32) + "\n";
  }
  if (value37.showProgressBar) {
    value39 += "┃ *ʀᴀᴍ:* " + progressBar(value34, value32) + "\n";
  }
  if (value37.showPluginCount) {
    value39 += "┃ *Cᴏᴍᴍᴀɴᴅꜱ:* " + value23 + "\n";
  }
  value39 += "┗❐\n" + value35 + "\n";
  const value40 = Object.keys(value21).filter(value41 => value21[value41]?.length > 0);
  const value42 = [...CATEGORY_ORDER.filter(value43 => value40.includes(value43)), ...value40.filter(value44 => !CATEGORY_ORDER.includes(value44)).sort()];
  let value45 = 0;
  for (const value46 of value42) {
    const value47 = value21[value46];
    if (!value47 || value47.length === 0) {
      continue;
    }
    const value48 = CATEGORY_LABELS[value46] || value46.toUpperCase() + "-CMD";
    value39 += "┏━━❐◈  `" + value48 + "` ◈\n";
    for (const value49 of value47) {
      value39 += "┃◈" + value49.name + "\n";
    }
    value39 += "┗❐\n";
    value45++;
    if (value45 % 3 === 0) {
      value39 += value35 + "\n";
    } else {
      value39 += "\n";
    }
  }
  return value39;
}
function getThumbnail() {
  try {
    const value50 = require("../../database");
    const value51 = value50.getMenuImageSettings ? value50.getMenuImageSettings() : null;
    if (value51 && value51.custom && value51.imageData) {
      let value52 = String(value51.imageData).trim();
      if (value52.startsWith("data:")) {
        value52 = value52.slice(value52.indexOf(",") + 1);
      }
      const value53 = Buffer.from(value52, "base64");
      if (value53 && value53.length) {
        return value53;
      }
    }
  } catch (error54) {}
  const value55 = path.join(__dirname, "../../data/custom_menu.jpg");
  if (fs.existsSync(value55)) {
    try {
      return fs.readFileSync(value55);
    } catch {}
  }
  const value56 = [path.join(__dirname, "../../assets/menu1.jpg"), path.join(__dirname, "../../utils/bot_image.jpg"), path.join(__dirname, "../../utils/menu2.jpg"), path.join(__dirname, "../../utils/menu3.jpg"), path.join(__dirname, "../../utils/menu4.jpg"), path.join(__dirname, "../../utils/menu5.jpg")];
  const value57 = value56.filter(value58 => {
    try {
      return fs.existsSync(value58);
    } catch {
      return false;
    }
  });
  if (!value57.length) {
    return null;
  }
  const value59 = value57[Math.floor(Math.random() * value57.length)];
  try {
    return fs.readFileSync(value59);
  } catch {
    return null;
  }
}
module.exports = {
  name: "menu",
  aliases: ["menulist", "fullmenu"],
  category: "general",
  description: "Show all available commands",
  usage: ".menu",
  async execute(value60, value61, value62, value63) {
    try {
      const value64 = loadCommands();
      const value65 = {};
      let value66 = 0;
      value64.forEach((value67, value68) => {
        if (value67.name === value68) {
          if (!value65[value67.category]) {
            value65[value67.category] = [];
          }
          value65[value67.category].push(value67);
          value66++;
        }
      });
      const value69 = getMenuStyle();
      const value70 = createFakeContact(value61);
      const value71 = await value60.sendMessage(value63.from, {
        text: applyFont("⏳ Loading....")
      }, {
        quoted: value70
      });
      const value72 = () => value60.sendMessage(value63.from, {
        text: applyFont("_" + db.getBotSetting("botName") + "..._"),
        edit: value71.key
      }).catch(() => {});
      const value73 = value61.messageTimestamp ? value61.messageTimestamp * 1000 : Date.now();
      const value74 = Date.now() - value73;
      const value75 = buildMenuText(value65, value63, value66, value74);
      const value76 = getThumbnail();
      const value77 = db.getBotSetting("botName") || "June Ultra";
      const value78 = (Array.isArray(db.getOwnerNames()) ? db.getOwnerNames()[0] : db.getOwnerNames()) || "Bot Owner";
      const value79 = db.SOCIAL?.github || "https://github.com";
      const value80 = value63.from;
      const value81 = applyFont(value75);
      const value82 = "Powered by " + value78;
      if (value69 === "1") {
        await value60.sendMessage(value80, {
          document: {
            url: "https://i.ibb.co/2W0H9Jq/avatar-contact.png"
          },
          caption: value81,
          mimetype: "application/zip",
          fileName: value77 + ".zip",
          fileLength: "9999999",
          contextInfo: {
            mentionedJid: [value63.sender],
            externalAdReply: {
              showAdAttribution: false,
              title: value77,
              body: value78,
              thumbnail: value76,
              sourceUrl: value79,
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        }, {
          quoted: value70
        });
        await value72();
      } else if (value69 === "2") {
        await value60.sendMessage(value80, {
          text: value81,
          footer: value82,
          mentions: [value63.sender]
        }, {
          quoted: value70
        });
        await value72();
      } else if (value69 === "3") {
        const value83 = db.getBotSetting("prefix") || ".";
        const value84 = db.SOCIAL?.github || "https://github.com";
        await sendButtons(value60, value80, {
          image: value76 ? {
            buffer: value76,
            mimetype: "image/jpeg"
          } : undefined,
          text: value81,
          footer: value82,
          mentions: [value63.sender],
          contextInfo: {
            externalAdReply: {
              showAdAttribution: false,
              title: value77,
              body: value78,
              thumbnail: value76,
              sourceUrl: value84,
              mediaType: 1,
              renderLargerThumbnail: true
            }
          },
          buttons: [{
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "🔗 𝙾𝙿𝙴𝙽 𝚁𝙴𝙿𝙾",
              url: value84
            })
          }, {
            id: value83 + "ping",
            text: "📍 𝙿𝙸𝙽𝙶"
          }]
        }, {
          quoted: value70
        });
        await value72();
      } else if (value69 === "4") {
        await value60.sendMessage(value80, {
          image: value76 || {
            url: "https://i.ibb.co/2W0H9Jq/avatar-contact.png"
          },
          caption: value81,
          mentions: [value63.sender]
        }, {
          quoted: value70
        });
        await value72();
      } else if (value69 === "5") {
        try {
          const value85Interactive = proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({
              text: value81
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
              text: "ASTROCORE"
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
              messageVersion: 1,
              buttons: [{
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "📋 MENU",
                  id: (db.getBotSetting("prefix") || ".") + "menu"
                })
              }, {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "📍 PING",
                  id: (db.getBotSetting("prefix") || ".") + "ping"
                })
              }, {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "ℹ️ HELP",
                  id: (db.getBotSetting("prefix") || ".") + "help"
                })
              }]
            })
          });
          const value85 = generateWAMessageFromContent(value80, {
            viewOnceMessage: {
              message: {
                messageContextInfo: {
                  deviceListMetadata: {},
                  deviceListMetadataVersion: 2
                },
                interactiveMessage: value85Interactive
              }
            }
          }, {
            quoted: value70,
            userJid: value60.user?.id
          });
          await value60.relayMessage(value80, value85.message, {
            messageId: value85.key.id,
            additionalNodes: [{
              tag: "biz",
              attrs: {},
              content: [{
                tag: "interactive",
                attrs: {
                  type: "native_flow",
                  v: "1"
                },
                content: [{
                  tag: "native_flow",
                  attrs: {
                    v: "9",
                    name: "mixed"
                  }
                }]
              }]
            }]
          });
          await value72();
        } catch {
          await value60.sendMessage(value80, {
            text: value81,
            mentions: [value63.sender]
          }, {
            quoted: value70
          });
          await value72();
        }
      } else if (value69 === "6") {
        try {
          const value86 = generateWAMessageFromContent(value80, {
            requestPaymentMessage: {
              currencyCodeIso4217: "USD",
              requestFrom: "0@s.whatsapp.net",
              amount1000: "1",
              noteMessage: {
                extendedTextMessage: {
                  text: value81,
                  contextInfo: {
                    mentionedJid: [value63.sender],
                    externalAdReply: {
                      showAdAttribution: false
                    }
                  }
                }
              }
            }
          }, {
            quoted: value70,
            userJid: value60.user?.id
          });
          await value60.relayMessage(value80, value86.message, {
            messageId: value86.key.id
          });
          await value72();
        } catch {
          await value60.sendMessage(value80, {
            text: value81,
            mentions: [value63.sender]
          }, {
            quoted: value70
          });
          await value72();
        }
      } else {
        await value60.sendMessage(value80, {
          text: value81,
          mentions: [value63.sender]
        }, {
          quoted: value70
        });
        await value72();
      }
    } catch (error87) {
      console.error("Menu error:", error87);
      await value63.reply("❌ Error: " + error87.message);
    }
  }
};
