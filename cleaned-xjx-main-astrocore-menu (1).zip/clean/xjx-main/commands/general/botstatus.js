const os = require("os");
const database = require("../../database");
const {
  sendButtons
} = require("gifted-btns");
const {
  applyFont
} = require("../../utils/fontConverter");
const {
  loadCommands
} = require("../../utils/commandLoader");
function formatUptime(value1) {
  const value2 = Math.floor(value1 / 1000);
  const value3 = Math.floor(value2 / 86400);
  const value4 = Math.floor(value2 % 86400 / 3600);
  const value5 = Math.floor(value2 % 3600 / 60);
  const value6 = value2 % 60;
  const value7 = [];
  if (value3) {
    value7.push(value3 + "d");
  }
  if (value4) {
    value7.push(value4 + "h");
  }
  if (value5) {
    value7.push(value5 + "m");
  }
  value7.push(value6 + "s");
  return value7.join(" ");
}
function detectPlatform() {
  if (process.env.HEROKU) {
    return "☁️ Heroku";
  }
  if (process.env.RAILWAY_STATIC_URL) {
    return "🚉 Railway";
  }
  if (process.env.RENDER) {
    return "⚡ Render";
  }
  if (process.env.REPLIT_DB_URL || process.env.REPL_ID) {
    return "🔵 Replit";
  }
  if (process.env.P_SERVER_UUID) {
    return "🖥️ Pterodactyl";
  }
  const value8 = os.platform();
  if (value8 === "linux") {
    return "🐧 Linux VPS";
  }
  if (value8 === "win32") {
    return "🪟 Windows";
  }
  if (value8 === "darwin") {
    return "🍎 macOS";
  }
  return value8;
}
function extractButtonResponseId(value9) {
  return value9.message?.buttonsResponseMessage?.selectedButtonId || value9.message?.templateButtonReplyMessage?.selectedId || value9.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || null;
}
function getResponseSender(value10) {
  return value10.key?.participant || value10.key?.remoteJid;
}
module.exports = {
  name: "botstatus",
  aliases: ["status", "run"],
  category: "general",
  description: "View bot status, uptime, and system info",
  usage: ".botstatus",
  async execute(value11, value12, value13, value14) {
    try {
      const value15 = value14.from;
      const value16 = database.getBotSetting("prefix") === "" ? "none" : database.getBotSetting("prefix") || ".";
      const value17 = value12.key?.participant || value12.key?.remoteJid;
      const value18 = Date.now();
      const value19 = formatUptime(process.uptime() * 1000);
      const value20 = (os.totalmem() / 1024 / 1024).toFixed(0);
      const value21 = ((os.totalmem() - os.freemem()) / 1024 / 1024).toFixed(0);
      const value22 = ((1 - os.freemem() / os.totalmem()) * 100).toFixed(1);
      const value23 = os.cpus();
      const value24 = value23[0]?.model?.trim() || "Unknown";
      const value25 = value23.length;
      const value26 = detectPlatform();
      const value27 = process.version;
      const value28 = (Array.isArray(database.getOwnerNames()) ? database.getOwnerNames()[0] : database.getOwnerNames()) || "Bot Owner";
      const value29 = value14.getCommandCount ? value14.getCommandCount() : "N/A";
      const value30 = Date.now() - value12.messageTimestamp * 1000;
      const value31 = database.getAutoDownloadStatusSettings();
      const {
        getModeLabel: value32
      } = require("../../utils/botMode");
      const value33 = applyFont("┏━━『 BOT STATUS 』━━\n\n" + ("➥ Bot Name  ➜ " + database.getBotSetting("botName") + "\n") + ("➥ Prefix    ➜ [ " + value16 + " ]\n") + ("➥ Owner     ➜ " + value28 + "\n") + ("➥ Commands  ➜ " + value29 + "\n") + ("➥ Uptime    ➜ " + value19 + "\n") + ("➥ Speed     ➜ " + value30 + "ms\n\n") + "┃ System\n" + ("➥ Platform  ➜ " + value26 + "\n") + ("➥ Node.js   ➜ " + value27 + "\n") + ("➥ RAM       ➜ " + value21 + "/" + value20 + " MB (" + value22 + "%)\n") + ("➥ CPU       ➜ " + value24 + "\n") + ("➥ Cores     ➜ " + value25 + "\n") + ("➥ Timezone  ➜ " + database.getTimeZone() + "\n\n") + "┃ Behavior\n" + ("➥ Mode          ➜ " + value32() + "\n") + ("➥ Auto Read     ➜ " + ({
        all: "✅",
        contacts: "👥",
        pm: "📩",
        gc: "💬"
      }[database.getBotSetting("autoReadMode") || "off"] || "❌") + " (" + (database.getBotSetting("autoReadMode") || "off").toUpperCase() + ")\n") + ("➥ Auto Typing   ➜ " + (database.getBotSetting("autoTyping") ? "✅" : "❌") + "\n") + ("➥ Auto React    ➜ " + (database.getBotSetting("autoReact") ? "✅" : "❌") + " (" + (database.getBotSetting("autoReactMode") || "bot") + ")\n") + ("➥ Auto Sticker  ➜ " + (database.getBotSetting("autoSticker") ? "✅" : "❌") + "\n") + ("➥ Auto Download ➜ " + (value31.enabled ? "✅ (" + value31.mode + ")" : "❌") + "\n\n") + "┗━━━━━━━━━━━━━━━━");
      await sendButtons(value11, value15, {
        title: "",
        text: value33,
        footer: "> Powered by " + database.getBotSetting("botName"),
        buttons: [{
          id: value16 + "ping_" + value18,
          text: "🏓 Ping"
        }, {
          id: value16 + "uptime_" + value18,
          text: "⏱️ Uptime"
        }, {
          id: value16 + "restart_" + value18,
          text: "🔄 Restart"
        }]
      }, {
        quoted: value12
      });
      const value34 = async value35 => {
        const value36 = value35.messages[0];
        if (!value36?.message) {
          return;
        }
        const value37 = extractButtonResponseId(value36);
        if (!value37) {
          return;
        }
        if (!value37.includes("_" + value18)) {
          return;
        }
        if (value36.key?.remoteJid !== value15) {
          return;
        }
        const value38 = getResponseSender(value36);
        if (value38 !== value17) {
          return;
        }
        const value39 = value37.replace("_" + value18, "").replace(value16, "").trim();
        const value40 = loadCommands().get(value39);
        if (!value40) {
          return await value11.sendMessage(value15, {
            text: applyFont("┏━━『 ERROR 』━━\n\n" + ("➥ Reason ➜ Command *" + value39 + "* not found\n\n") + "┗━━━━━━━━━━━━━━━━")
          }, {
            quoted: value36
          });
        }
        try {
          const value41 = {
            from: value15,
            sender: value38,
            isGroup: value15.endsWith("@g.us"),
            reply: value42 => value11.sendMessage(value15, {
              text: value42
            }, {
              quoted: value36
            }),
            quoted: value36
          };
          await value40.execute(value11, value36, [], value41);
        } catch (error43) {
          console.error("[botstatus] button error (" + value39 + "):", error43.message);
          await value11.sendMessage(value15, {
            text: applyFont("┏━━『 ERROR 』━━\n\n" + ("➥ Command ➜ " + value39 + "\n") + ("➥ Reason  ➜ " + error43.message + "\n\n") + "┗━━━━━━━━━━━━━━━━")
          }, {
            quoted: value36
          });
        }
      };
      value11.ev.on("messages.upsert", value34);
    } catch (error44) {
      console.error("[botstatus] error:", error44);
      await value14.reply("❌ Error: " + error44.message);
    }
  }
};
