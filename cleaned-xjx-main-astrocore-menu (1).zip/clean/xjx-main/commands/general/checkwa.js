const {
  jidUser,
  rememberLidMapping,
  getLidMappingValue
} = require("../../utils/jidHelper");
const MAX_NUMBERS = 8;
function digitsOnly(value1) {
  return String(value1 || "").replace(/\D/g, "");
}
function collectTargets(value2, value3) {
  const value4 = [];
  const value5 = [];
  const value6 = (value7, value8) => {
    if (!value7) {
      return;
    }
    if (String(value7).endsWith("@lid") || String(value7).endsWith("@hosted.lid")) {
      if (!value5.includes(String(value7))) {
        value5.push(String(value7));
      }
      return;
    }
    const value9 = digitsOnly(value7);
    if (value9.length < 7 || value9.length > 15) {
      return;
    }
    if (value4.some(value10 => value10.digits === value9)) {
      return;
    }
    value4.push({
      digits: value9,
      hint: value8 || value9
    });
  };
  const value11 = value2.message?.extendedTextMessage?.contextInfo || value2.message?.imageMessage?.contextInfo || value2.message?.videoMessage?.contextInfo || null;
  for (const value12 of value11?.mentionedJid || []) {
    value6(value12, String(value12).split("@")[0]);
  }
  if (value11?.participantAlt) {
    value6(value11.participantAlt, "quoted");
  }
  if (value11?.participant) {
    value6(value11.participant, "quoted");
  }
  const value13 = (value3 || []).join(" ");
  for (const value14 of value13.split(/[\s,;]+/)) {
    if (!value14) {
      continue;
    }
    if (value14.startsWith("@")) {
      value6(value14.slice(1), value14);
      continue;
    }
    value6(value14, value14);
  }
  return {
    found: value4,
    lids: value5
  };
}
async function resolveLidToPn(value15, value16, value17) {
  const value18 = await resolvePhone(value15, value17);
  if (value18) {
    return digitsOnly(value18);
  }
  const value19 = value16.groupMetadata?.participants || [];
  const value20 = jidUser(value17);
  const value21 = value19.find(value22 => {
    if (!value22 || typeof value22 === "string") {
      return false;
    }
    const value23 = [value22.id, value22.lid, value22.userJid].filter(Boolean);
    return value23.includes(value17) || value23.some(value24 => jidUser(value24) === value20);
  });
  if (value21) {
    rememberParticipantLidMapping(value21);
    const value25 = value21.phoneNumber || value21.pn;
    if (value25) {
      return digitsOnly(value25);
    }
  }
  return null;
}
async function lookupLid(value26, value27) {
  const value28 = value26.signalRepository?.lidMapping;
  try {
    if (value28?.getLIDForPN) {
      const value29 = await value28.getLIDForPN(value27);
      if (value29) {
        return value29;
      }
    }
  } catch (error30) {}
  try {
    if (value28?.getLIDsForPNs) {
      const value31 = await value28.getLIDsForPNs([value27]);
      const value32 = Array.isArray(value31) ? value31[0] : null;
      const value33 = value32?.lid || value32?.[value27] || null;
      if (value33) {
        if (typeof value33 === "string") {
          return value33;
        } else {
          return null;
        }
      }
    }
  } catch (error34) {}
  const value35 = getLidMappingValue(jidUser(value27), "pnToLid");
  if (value35) {
    return value35 + "@lid";
  } else {
    return null;
  }
}
module.exports = {
  name: "checkwa",
  aliases: ["onwa", "nowa", "iswa", "checknum"],
  category: "general",
  description: "Check if a number is registered on WhatsApp",
  usage: ".checkwa <number> [, number...]",
  async execute(value36, value37, value38, value39) {
    const value40 = collectTargets(value37, value38);
    const value41 = value40.found.slice();
    for (const value42 of value40.lids) {
      const value43 = await resolveLidToPn(value36, value39, value42);
      if (value43 && !value41.some(value44 => value44.digits === value43)) {
        value41.push({
          digits: value43,
          hint: value42
        });
      }
    }
    if (!value41.length) {
      const value45 = value40.lids.length ? "\n\n_That mention is a LID and the phone number is not cached yet. Try the number itself._" : "";
      return value39.reply("📱 *WhatsApp Check*\n\nUsage:\n  .checkwa 2348072642047\n  .checkwa 234xxx, 254xxx\n  .checkwa @user\n  .checkwa  _(reply to a message)_\n\n" + ("_Use the full country code. Max " + MAX_NUMBERS + " numbers._") + value45);
    }
    const value46 = value41.slice(0, MAX_NUMBERS);
    try {
      if (value39.react) {
        await value39.react("🔎").catch(() => {});
      }
      const value47 = value46.map(value48 => value48.digits + "@s.whatsapp.net");
      const value49 = await value36.onWhatsApp(...value47);
      const value50 = new Map();
      for (const value51 of value49 || []) {
        const value52 = jidUser(value51?.jid) || digitsOnly(value51?.jid);
        if (value52) {
          value50.set(value52, value51);
        }
      }
      const value53 = ["┏━━『 WHATSAPP CHECK 』━━", ""];
      for (const value54 of value46) {
        const value55 = value50.get(value54.digits);
        const value56 = !!value55?.exists;
        const value57 = value55?.jid || value54.digits + "@s.whatsapp.net";
        value53.push("➥ " + value54.digits);
        value53.push("   Status  ➜ " + (value56 ? "registered" : "not on WhatsApp"));
        if (value56) {
          value53.push("   JID     ➜ " + value57);
          const value58 = await lookupLid(value36, value57);
          if (value58) {
            rememberLidMapping(value58, value57);
            value53.push("   LID     ➜ " + value58);
          }
        }
        value53.push("");
      }
      value53.push("┗━━━━━━━━━━━━━━━━");
      if (value39.react) {
        await value39.react("✅").catch(() => {});
      }
      await value39.reply(value53.join("\n"));
    } catch (error59) {
      console.error("[checkwa]", error59.message);
      if (value39.react) {
        await value39.react("❌").catch(() => {});
      }
      await value39.reply("❌ Check failed: " + error59.message);
    }
  }
};
