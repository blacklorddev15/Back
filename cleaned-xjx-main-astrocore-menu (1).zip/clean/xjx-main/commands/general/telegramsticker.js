const fetch = require("node-fetch");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const {
  spawn
} = require("child_process");
const webp = require("node-webpmux");
const ffmpegPath = require("../../utils/ffmpegPath");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const database = require("../../database");
const PACK_SIZE = 59;
const TG_TOKEN = "8773913673:AAGRx9OBJHP1u1mEOKa741Cmmz6woXgXSNY";
const delay = value1 => new Promise(value2 => setTimeout(value2, value1));
async function fetchBuffer(value3) {
  const value4 = await fetch(value3, {
    headers: {
      "User-Agent": "JuneXUltra/2.0"
    }
  });
  if (!value4.ok) {
    throw new Error("HTTP " + value4.status + " for " + value3);
  }
  return value4.buffer();
}
async function toWebp(value5, value6, value7) {
  const value8 = value7 ? ["-y", "-i", value5, "-vf", "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000", "-c:v", "libwebp", "-lossless", "0", "-q:v", "60", "-loop", "0", "-vsync", "0", "-pix_fmt", "yuva420p", "-an", "-t", "6", value6] : ["-y", "-i", value5, "-vf", "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000", "-c:v", "libwebp", "-lossless", "0", "-q:v", "75", value6];
  await new Promise((value9, value10) => {
    const value11 = spawn(ffmpegPath(), value8);
    const value12 = [];
    value11.stderr.on("data", value13 => value12.push(value13));
    value11.on("error", value10);
    value11.on("close", value14 => value14 === 0 ? value9() : value10(new Error(Buffer.concat(value12).toString().slice(-200))));
  });
}
async function embedExif(value15, value16, value17, value18) {
  const value19 = new webp.Image();
  await value19.load(value15);
  const value20 = {
    "sticker-pack-id": value16,
    "sticker-pack-name": value17,
    emojis: value18 ? [value18] : ["🤖"]
  };
  const value21 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
  const value22 = Buffer.from(JSON.stringify(value20), "utf8");
  const value23 = Buffer.concat([value21, value22]);
  value23.writeUIntLE(value22.length, 14, 4);
  value19.exif = value23;
  return value19.save(null);
}
module.exports = {
  name: "telegramsticker",
  aliases: ["tgs", "tgms", "tgsticker"],
  category: "general",
  description: "Download a Telegram sticker pack and send as WhatsApp sticker pack(s) of 59",
  usage: ".tgs https://t.me/addstickers/<PackName>",
  async execute(value24, value25, value26, value27) {
    const {
      from: value28,
      reply: value29
    } = value27;
    const value30 = value26[0] || "";
    if (!value30) {
      return value29("📦 *Telegram Sticker Pack*\n━━━━━━━━━━━━━━━\n" + ("Send an entire Telegram sticker pack as WhatsApp sticker packs (" + PACK_SIZE + " per pack).\n\n") + "*Usage:*\n  .tgs https://t.me/addstickers/PackName\n\n*Example:*\n  .tgs https://t.me/addstickers/Porcientoreal");
    }
    if (!value30.match(/https?:\/\/t\.me\/addstickers\//i)) {
      return value29("❌ Invalid URL.\nUse a Telegram sticker pack link:\n_https://t.me/addstickers/PackName_");
    }
    const value31 = value30.replace(/https?:\/\/t\.me\/addstickers\//i, "").split("/")[0].trim();
    let value32;
    try {
      const value33 = await fetch("https://api.telegram.org/bot" + TG_TOKEN + "/getStickerSet?name=" + encodeURIComponent(value31));
      const value34 = await value33.json();
      if (!value34.ok) {
        throw new Error(value34.description || "Unknown error");
      }
      value32 = value34.result;
    } catch (error35) {
      return value29("❌ Could not fetch sticker pack.\n" + error35.message + "\n\nMake sure the pack link is correct.");
    }
    const value36 = value32.stickers;
    const value37 = value36.length;
    const value38 = value32.title || value31;
    if (value32.is_animated === true) {
      return value29("❌ *" + value38 + "* is a Lottie-animated pack (.tgs / vector JSON).\nThese can't be converted to WhatsApp stickers without extra dependencies.\n\nTry a *static* or *video* pack instead.");
    }
    const value39 = [];
    for (let value40 = 0; value40 < value36.length; value40 += PACK_SIZE) {
      value39.push(value36.slice(value40, value40 + PACK_SIZE));
    }
    const value41 = value39.length;
    const value42 = value39.map(() => crypto.randomBytes(32).toString("hex"));
    const value43 = value25.pushName || "User";
    const value44 = await value24.sendMessage(value28, {
      text: "📦 *" + value38 + "*\n" + ("🎯 *" + value37 + "* stickers → *" + value41 + "* pack" + (value41 > 1 ? "s" : "") + " of up to " + PACK_SIZE + "\n") + "⏳ _Starting download…_"
    }, {
      quoted: value25
    });
    const value45 = value44?.key;
    const value46 = async value47 => {
      if (!value45) {
        return;
      }
      try {
        await value24.sendMessage(value28, {
          edit: value45,
          text: value47
        });
      } catch (error48) {}
    };
    const value49 = getTempDir();
    let value50 = 0;
    let value51 = 0;
    let value52 = 0;
    for (let value53 = 0; value53 < value39.length; value53++) {
      const value54 = value39[value53];
      const value55 = value42[value53];
      const value56 = value53 + 1;
      const value57 = value41 > 1 ? value43 + " (" + value56 + "/" + value41 + ")" : value43;
      for (let value58 = 0; value58 < value54.length; value58++) {
        const value59 = value53 * PACK_SIZE + value58;
        const value60 = value54[value58];
        const value61 = path.join(value49, "tg_in_" + Date.now() + "_" + value59);
        const value62 = path.join(value49, "tg_out_" + Date.now() + "_" + value59 + ".webp");
        if (value59 === 0 || value59 % 5 === 0) {
          await value46("📦 *" + value38 + "*\n" + ("🗂 Pack *" + value56 + "/" + value41 + "* — sticker *" + (value59 + 1) + "/" + value37 + "*\n") + ("✅ Sent: " + value50 + "  ⏭ Skipped: " + value52 + "  ❌ Failed: " + value51));
        }
        try {
          if (value60.is_animated && !value60.is_video) {
            value52++;
            continue;
          }
          const value63 = await fetch("https://api.telegram.org/bot" + TG_TOKEN + "/getFile?file_id=" + value60.file_id);
          const value64 = await value63.json();
          if (!value64.ok) {
            throw new Error("getFile failed");
          }
          const value65 = value64.result.file_path || "";
          const value66 = "https://api.telegram.org/file/bot" + TG_TOKEN + "/" + value65;
          const value67 = await fetchBuffer(value66);
          fs.writeFileSync(value61, value67);
          const value68 = !!value60.is_video || value65.endsWith(".webm");
          const value69 = value65.endsWith(".webp") && !value68;
          let value70;
          if (value69) {
            value70 = value67;
          } else {
            await toWebp(value61, value62, value68);
            value70 = fs.readFileSync(value62);
          }
          const value71 = await embedExif(value70, value55, value57, value60.emoji);
          await value24.sendMessage(value28, {
            sticker: value71
          });
          value50++;
          await delay(400);
        } catch (error72) {
          console.error("[TGS] Sticker " + (value59 + 1) + " failed:", error72.message);
          value51++;
        } finally {
          try {
            deleteTempFile(value61);
          } catch (error73) {}
          try {
            deleteTempFile(value62);
          } catch (error74) {}
        }
      }
      if (value53 < value39.length - 1) {
        await delay(1000);
      }
    }
    await value46("✅ *" + value38 + "* — Done!\n" + ("📊 Sent: *" + value50 + "/" + value37 + "* across *" + value41 + "* pack" + (value41 > 1 ? "s" : "") + "\n") + (value52 ? "⏭ Skipped (Lottie): " + value52 + "\n" : "") + (value51 ? "❌ Failed: " + value51 + "\n" : "") + ("\n> Powered by " + (database.getBotSetting("botName") || "JuneX-Ultra")));
  }
};
