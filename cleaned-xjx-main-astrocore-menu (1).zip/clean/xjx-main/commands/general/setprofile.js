const fs = require("fs");
const path = require("path");
const axios = require("axios");
const {
  Jimp
} = require("jimp");
const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const {
  tryFetchProfilePictureUrl,
  displayUserTag
} = require("../../utils/jidHelper");
function toJid(value1) {
  if (!value1) {
    return null;
  }
  let value2 = String(value1).trim();
  if (value2.includes("@")) {
    return value2;
  }
  value2 = value2.replace(/[^0-9]/g, "");
  if (!value2) {
    return null;
  }
  return value2 + "@s.whatsapp.net";
}
module.exports = {
  name: "setprofile",
  aliases: ["setdpfull", "setppfull", "setfullpp", "setfulldp"],
  category: "owner",
  description: "Set bot full (uncropped) profile picture — from image reply, tagged user, phone number, or replied user",
  usage: ".setprofile (reply to image) | .setppfull @user | .setppfull <phone>",
  async execute(value3, value4, value5, value6) {
    let value7 = null;
    try {
      if (!value6.isOwner) {
        return value6.reply("❌ This command is only available for the owner!");
      }
      const value8 = value4.message?.extendedTextMessage?.contextInfo || value4.message?.imageMessage?.contextInfo || {};
      const value9 = value6.groupMetadata || null;
      let value10 = null;
      let value11 = "";
      let value12 = null;
      if (Array.isArray(value8.mentionedJid) && value8.mentionedJid.length) {
        value12 = value8.mentionedJid[0];
      }
      if (!value12 && value5 && value5.length && value5[0] && !value5[0].startsWith("@")) {
        value12 = toJid(value5[0]);
      }
      const value13 = value8.quotedMessage;
      if (!value10 && value13) {
        let value14;
        let value15;
        if (value13.imageMessage) {
          value14 = value13.imageMessage;
          value15 = "image";
        } else if (value13.stickerMessage) {
          value14 = value13.stickerMessage;
          value15 = "sticker";
        } else if (value13.viewOnceMessageV2?.message?.imageMessage) {
          value14 = value13.viewOnceMessageV2.message.imageMessage;
          value15 = "image";
        }
        if (value14) {
          await value6.react("⏳");
          const value16 = await downloadContentFromMessage(value14, value15);
          value10 = Buffer.from([]);
          for await (const value17 of value16) {
            value10 = Buffer.concat([value10, value17]);
          }
          value11 = "replied media";
        } else if (!value12) {
          value12 = value8.participant || value8.remoteJid || null;
        }
      }
      if (!value10 && value12) {
        await value6.react("⏳");
        const value18 = displayUserTag(value12, value9);
        let value19;
        try {
          value19 = await tryFetchProfilePictureUrl(value3, value12, value9);
        } catch (error20) {
          const value21 = error20?.output?.statusCode;
          const value22 = (error20?.message || "").toLowerCase();
          if (value21 === 401 || value22.includes("forbidden") || value22.includes("unauthorized")) {
            return value6.reply("❌ @" + value18 + "'s profile picture is private.");
          }
          if (value21 === 404 || value21 === 500 || value22.includes("not found") || value22.includes("item-not-found")) {
            return value6.reply("❌ No profile picture set for @" + value18 + ".");
          }
          return value6.reply("❌ Could not fetch that user's profile picture.");
        }
        if (!value19 || !value19.url) {
          return value6.reply("❌ No profile picture found for @" + value18 + ".");
        }
        const value23 = await axios.get(value19.url, {
          responseType: "arraybuffer",
          timeout: 30000
        });
        value10 = Buffer.from(value23.data);
        value11 = "@" + value18 + "'s profile picture";
      }
      if (!value10) {
        return value6.reply("⚠️ Provide a source.\n\nUsage:\n• Reply to an image/sticker with .setppfull\n• .setppfull @user\n• .setppfull 254798570132\n• Reply to a user's message with .setppfull");
      }
      const value24 = path.join(process.cwd(), "tmp");
      if (!fs.existsSync(value24)) {
        fs.mkdirSync(value24, {
          recursive: true
        });
      }
      const value25 = await Jimp.read(value10);
      const value26 = value25.bitmap.width;
      const value27 = value25.bitmap.height;
      const value28 = Math.max(value26, value27);
      const value29 = new Jimp({
        width: value28,
        height: value28,
        color: 4294967295
      });
      value29.composite(value25, Math.floor((value28 - value26) / 2), Math.floor((value28 - value27) / 2));
      const value30 = await value29.getBuffer("image/jpeg");
      value7 = path.join(value24, "profile_full_" + Date.now() + ".jpg");
      fs.writeFileSync(value7, value30);
      const value31 = value3.user?.id || value3.user?.lid;
      await value3.updateProfilePicture(value31, {
        url: value7
      });
      await value6.react("✅");
      const value32 = value11 ? " (from " + value11 + ")" : "";
      const value33 = value12 ? [value12] : [];
      await value3.sendMessage(value6.from, {
        text: "✅ Successfully updated bot *FULL* profile picture" + value32 + "!",
        mentions: value33
      }, {
        quoted: value4
      });
    } catch (error34) {
      console.error("Error in setprofile command:", error34);
      try {
        await value6.react("❌");
      } catch (error35) {}
      try {
        await value6.reply("❌ Failed to update full profile picture: " + error34.message);
      } catch (error36) {}
    } finally {
      if (value7 && fs.existsSync(value7)) {
        try {
          fs.unlinkSync(value7);
        } catch (error37) {}
      }
    }
  }
};
