const fetchJSON = async value1 => (await fetch(value1)).json();
const react = (value2, value3, value4) => value2.sendMessage(value3.key.remoteJid, {
  react: {
    text: value4,
    key: value3.key
  }
});
const send = (value5, value6, value7) => value5.sendMessage(value6.key.remoteJid, {
  text: value7
}, {
  quoted: value6
});
const BASE = "https://api.giftedtech.co.ke/api/search/googlesearch?apikey=gifted&q=";
module.exports = [{
  name: "google",
  aliases: ["search", "g", "gsearch"],
  category: "general",
  description: "Search Google and get top results",
  usage: ".google <query>",
  async execute(value8, value9, value10, value11) {
    const value12 = value10.join(" ").trim();
    if (!value12) {
      return value11.reply("❌ *Please provide a search query*\n\n*Usage:* .google <query>\n*Example:* .google How to learn JavaScript");
    }
    await react(value8, value9, "🔍");
    await value11.reply("⏳ *Searching Google...*");
    try {
      const value13 = await fetchJSON("" + BASE + encodeURIComponent(value12));
      if (!value13.success || !value13.results?.length) {
        await react(value8, value9, "❌");
        return value11.reply("❌ No results found for *\"" + value12 + "\"*");
      }
      const value14 = value13.results.slice(0, 5);
      let value15 = "🔍 *Google Search*\n" + ("📝 Query: *" + value12 + "*\n") + ("📊 Showing top *" + value14.length + "* results\n\n") + "━━━━━━━━━━━━━━━━━━\n\n";
      value14.forEach((value16, value17) => {
        value15 += "*" + (value17 + 1) + ". " + (value16.title || "No Title") + "*\n" + ("📄 " + (value16.description || value16.snippet || "No description available.") + "\n") + ("🔗 " + (value16.url || value16.link || "N/A") + "\n\n");
      });
      value15 += "━━━━━━━━━━━━━━━━━━\n_Powered by Google Search_";
      await send(value8, value9, value15);
      await react(value8, value9, "✅");
    } catch (error18) {
      console.error("[google]", error18.message);
      await react(value8, value9, "❌");
      value11.reply("❌ Search failed. Please try again later.");
    }
  }
}, {
  name: "image2",
  aliases: ["imagesearch2", "img2", "gimage"],
  category: "general",
  description: "Search Google Images and get top result",
  usage: ".image <query>",
  async execute(value19, value20, value21, value22) {
    const value23 = value21.join(" ").trim();
    if (!value23) {
      return value22.reply("❌ *Please provide a search query*\n\n*Usage:* .image <query>\n*Example:* .image sunset over mountains");
    }
    await react(value19, value20, "🖼️");
    await value22.reply("⏳ *Searching Google Images...*");
    try {
      const value24 = await fetchJSON("https://api.giftedtech.co.ke/api/search/googleimagesearch?apikey=gifted&q=" + encodeURIComponent(value23));
      if (!value24.success || !value24.results?.length) {
        await react(value19, value20, "❌");
        return value22.reply("❌ No images found for *\"" + value23 + "\"*");
      }
      const value25 = value24.results.slice(0, 4);
      let value26 = 0;
      for (const value27 of value25) {
        const value28 = value27.image || value27.url || value27.thumbnail;
        if (!value28) {
          continue;
        }
        try {
          await value19.sendMessage(value20.key.remoteJid, {
            image: {
              url: value28
            },
            caption: value26 === 0 ? "🖼️ *Google Images*\n🔍 Query: *" + value23 + "*\n\n_Result " + (value26 + 1) + " of " + value25.length + "_" : "_Result " + (value26 + 1) + " of " + value25.length + "_"
          }, {
            quoted: value26 === 0 ? value20 : undefined
          });
          value26++;
        } catch {}
      }
      if (value26 === 0) {
        await react(value19, value20, "❌");
        return value22.reply("❌ Could not load any images. Please try again.");
      }
      await react(value19, value20, "✅");
    } catch (error29) {
      console.error("[image]", error29.message);
      await react(value19, value20, "❌");
      value22.reply("❌ Image search failed. Please try again later.");
    }
  }
}, {
  name: "define",
  aliases: ["meaning", "definition", "dict"],
  category: "general",
  description: "Search Google for the definition of a word",
  usage: ".define <word>",
  async execute(value30, value31, value32, value33) {
    const value34 = value32.join(" ").trim();
    if (!value34) {
      return value33.reply("❌ *Please provide a word*\n\n*Usage:* .define <word>\n*Example:* .define photosynthesis");
    }
    await react(value30, value31, "📖");
    try {
      const value35 = await fetchJSON("https://api.dictionaryapi.dev/api/v2/entries/en/" + encodeURIComponent(value34));
      if (!Array.isArray(value35) || !value35.length) {
        await react(value30, value31, "❌");
        return value33.reply("❌ No definition found for *\"" + value34 + "\"*");
      }
      const value36 = value35[0];
      const value37 = value36.phonetic || value36.phonetics?.find(value38 => value38.text)?.text || "";
      let value39 = "📖 *" + value36.word + "* " + (value37 ? "_(" + value37 + ")_" : "") + "\n\n";
      value36.meanings?.slice(0, 3).forEach(value40 => {
        value39 += "🔹 *" + value40.partOfSpeech + "*\n";
        value40.definitions?.slice(0, 2).forEach((value41, value42) => {
          value39 += "   " + (value42 + 1) + ". " + value41.definition + "\n";
          if (value41.example) {
            value39 += "   _\"" + value41.example + "\"_\n";
          }
        });
        if (value40.synonyms?.length) {
          value39 += "   ✅ Synonyms: " + value40.synonyms.slice(0, 5).join(", ") + "\n";
        }
        if (value40.antonyms?.length) {
          value39 += "   ❌ Antonyms: " + value40.antonyms.slice(0, 5).join(", ") + "\n";
        }
        value39 += "\n";
      });
      value39 += "━━━━━━━━━━━━━━━━━━\n_Powered by Free Dictionary API_";
      await send(value30, value31, value39);
      await react(value30, value31, "✅");
    } catch (error43) {
      console.error("[define]", error43.message);
      await react(value30, value31, "❌");
      value33.reply("❌ Definition lookup failed. Please try again later.");
    }
  }
}, {
  name: "news2",
  aliases: ["gnews", "latestnews"],
  category: "general",
  description: "Search Google News for latest articles",
  usage: ".news <topic>",
  async execute(value44, value45, value46, value47) {
    const value48 = value46.join(" ").trim();
    if (!value48) {
      return value47.reply("❌ *Please provide a news topic*\n\n*Usage:* .news <topic>\n*Example:* .news Kenya elections");
    }
    await react(value44, value45, "📰");
    await value47.reply("⏳ *Fetching latest news...*");
    try {
      const value49 = await fetchJSON("https://api.giftedtech.co.ke/api/search/googlenews?apikey=gifted&q=" + encodeURIComponent(value48));
      if (!value49.success || !value49.results?.length) {
        await react(value44, value45, "❌");
        return value47.reply("❌ No news found for *\"" + value48 + "\"*");
      }
      const value50 = value49.results.slice(0, 5);
      let value51 = "📰 *Google News*\n" + ("🔍 Topic: *" + value48 + "*\n\n") + "━━━━━━━━━━━━━━━━━━\n\n";
      value50.forEach((value52, value53) => {
        value51 += "*" + (value53 + 1) + ". " + (value52.title || "No Title") + "*\n" + ("🗞️ " + (value52.source || "Unknown Source") + "\n") + ("📅 " + (value52.date || value52.published || "N/A") + "\n") + ("🔗 " + (value52.url || value52.link || "N/A") + "\n\n");
      });
      value51 += "━━━━━━━━━━━━━━━━━━\n_Powered by Google News_";
      await send(value44, value45, value51);
      await react(value44, value45, "✅");
    } catch (error54) {
      console.error("[news]", error54.message);
      await react(value44, value45, "❌");
      value47.reply("❌ News search failed. Please try again later.");
    }
  }
}];
