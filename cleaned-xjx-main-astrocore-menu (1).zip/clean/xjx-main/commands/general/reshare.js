const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const database = require("../../database");
const STATUS_JID = "status@broadcast";
function isStatusReply(value1) {
  const value2 = value1.message?.extendedTextMessage?.contextInfo;
  return value2 && value2.remoteJid === STATUS_JID;
}
function getStatusJidList(value3) {
  const value4 = new Set();
  const value5 = [].concat(database.getOwners() || []);
  for (const value6 of value5) {
    const value7 = String(value6).replace(/\D/g, "");
    if (value7) {
      value4.add(value7 + "@s.whatsapp.net");
    }
  }
  try {
    const value8 = value3.botStore?.messages;
    if (value8 instanceof Map) {
      for (const value9 of value8.keys()) {
        if (value9 && value9.endsWith("@s.whatsapp.net")) {
          value4.add(value9);
        }
      }
    }
  } catch (error10) {}
  return [...value4];
}
async function downloadStatusMedia(value11) {
  const value12 = value11;
  const value13 = {
    imageMessage: {
      type: "image",
      ext: ".jpg"
    },
    videoMessage: {
      type: "video",
      ext: ".mp4"
    },
    audioMessage: {
      type: "audio",
      ext: ".mp3"
    },
    stickerMessage: {
      type: "sticker",
      ext: ".webp"
    },
    documentMessage: {
      type: "document",
      ext: ".bin"
    }
  };
  for (const [value14, {
    type: value15,
    ext: value16
  }] of Object.entries(value13)) {
    if (!value12[value14]) {
      continue;
    }
    try {
      const value17 = await downloadContentFromMessage(value12[value14], value15);
      const value18 = [];
      for await (const value19 of value17) {
        value18.push(value19);
      }
      return {
        buffer: Buffer.concat(value18),
        type: value15,
        ext: value16,
        mime: value12[value14].mimetype || "",
        caption: value12[value14].caption || ""
      };
    } catch (error20) {}
  }
  const value21 = value12.conversation || value12.extendedTextMessage?.text || value12.ephemeralMessage?.message?.conversation || "";
  if (value21) {
    return {
      type: "text",
      text: value21
    };
  }
  return null;
}
module.exports = {
  name: "reshare",
  aliases: ["rs", "repost"],
  category: "general",
  description: "Re-share a WhatsApp status you replied to as your own status",
  usage: ".reshare [custom text] — reply to a status to re-share it",
  async execute(value22, value23, value24, value25) {
    try {
      const value26 = value25.from || value23.key.remoteJid;
      const value27 = value23.message?.extendedTextMessage?.contextInfo;
      const value28 = value27?.quotedMessage;
      if (!value28) {
        return value25.reply("❌ *Usage:* .reshare [custom text]\n\n*Reply* to a status message to re-share it as your own status.\n\nExamples:\n• .reshare (reply to a status)\n• .reshare hello (reply to a status with custom caption)\n\n_Supports: images, videos, audio, text statuses_");
      }
      if (!isStatusReply(value23)) {
        return value25.reply("❌ The replied message is not a *status* update.\n\nPlease reply to a WhatsApp status to re-share it.");
      }
      await value22.sendMessage(value26, {
        react: {
          text: "🔄",
          key: value23.key
        }
      }).catch(() => {});
      const value29 = await downloadStatusMedia(value28);
      if (!value29) {
        return value25.reply("❌ Could not download the status. It may have expired.");
      }
      const value30 = value24.join(" ").trim() || undefined;
      const value31 = getStatusJidList(value22);
      if (value29.type === "text") {
        const value32 = value30 || value29.text || "";
        if (!value32) {
          return value25.reply("❌ No text found to re-share.");
        }
        await value22.sendMessage(STATUS_JID, {
          text: value32,
          backgroundColor: "#000000",
          font: 2
        }, {
          statusJidList: value31
        });
        return value25.reply("✅ Text status re-shared successfully.");
      } else if (value29.type === "image") {
        const value33 = value30 || value29.caption || "";
        await value22.sendMessage(STATUS_JID, {
          image: value29.buffer,
          mimetype: value29.mime || "image/jpeg",
          caption: value33 || undefined
        }, {
          statusJidList: value31
        });
        return value25.reply("✅ Image status re-shared successfully.");
      } else if (value29.type === "video") {
        const value34 = value30 || value29.caption || "";
        await value22.sendMessage(STATUS_JID, {
          video: value29.buffer,
          mimetype: value29.mime || "video/mp4",
          caption: value34 || undefined,
          gifPlayback: false
        }, {
          statusJidList: value31
        });
        return value25.reply("✅ Video status re-shared successfully.");
      } else if (value29.type === "audio") {
        await value22.sendMessage(STATUS_JID, {
          audio: value29.buffer,
          mimetype: value29.mime || "audio/mp4",
          ptt: false
        }, {
          statusJidList: value31
        });
        return value25.reply("✅ Audio status re-shared successfully.");
      } else if (value29.type === "sticker") {
        await value22.sendMessage(STATUS_JID, {
          sticker: value29.buffer
        }, {
          statusJidList: value31
        });
        return value25.reply("✅ Sticker status re-shared successfully.");
      } else {
        await value22.sendMessage(STATUS_JID, {
          document: value29.buffer,
          mimetype: value29.mime || "application/octet-stream",
          fileName: "reshared_status",
          caption: value30 || ""
        }, {
          statusJidList: value31
        });
        return value25.reply("✅ Status re-shared successfully.");
      }
    } catch (error35) {
      try {
        await value25.reply("❌ Re-share failed: " + (error35.message || "Unknown error"));
      } catch (error36) {}
    }
  }
};
