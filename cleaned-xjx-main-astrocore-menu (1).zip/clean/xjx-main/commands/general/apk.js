const axios = require("axios");
const downloadRequests = new Map();
const COOLDOWN_MS = 5000;
module.exports = {
  name: "apk",
  aliases: ["apksearch", "apkdl"],
  category: "general",
  description: "Search and download an APK by app name",
  usage: ".apk <app name>",
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    const value6 = value3.join(" ").trim();
    try {
      if (!value6 || value6.length < 2) {
        return value4.reply("❌ Usage: .apk <app name>");
      }
      const value7 = downloadRequests.get(value5);
      if (value7 && Date.now() - value7 < COOLDOWN_MS) {
        const value8 = Math.ceil((COOLDOWN_MS - (Date.now() - value7)) / 1000);
        return value4.reply("⏳ Wait " + value8 + "s");
      }
      downloadRequests.set(value5, Date.now());
      await value1.sendMessage(value5, {
        react: {
          text: "🔍",
          key: value2.key
        }
      });
      const value9 = "http://ws75.aptoide.com/api/7/apps/search/query=" + encodeURIComponent(value6) + "/limit=10";
      const {
        data: value10
      } = await axios.get(value9, {
        timeout: 30000,
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
      });
      const value11 = value10?.datalist?.list?.[0];
      if (!value11?.file?.path_alt) {
        return value4.reply("❌ App not found.");
      }
      const value12 = value11.size ? (value11.size / 1048576).toFixed(1) : null;
      const value13 = (value11.name || "app").replace(/[^a-zA-Z0-9]/g, "_") + ".apk";
      try {
        const value14 = await axios.head(value11.file.path_alt, {
          timeout: 10000
        });
        const value15 = value14.headers["content-length"];
        if (value15 && parseInt(value15) > 104857600) {
          return value4.reply("❌ Too large (" + value12 + "MB, max 100MB)");
        }
      } catch {}
      await value1.sendMessage(value5, {
        react: {
          text: "⬆️",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        document: {
          url: value11.file.path_alt
        },
        fileName: value13,
        mimetype: "application/vnd.android.package-archive"
      }, {
        quoted: value2
      });
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
      console.log("[apk]", value11.name, "-", value6);
    } catch (error16) {
      console.error("[apk]", error16.message);
      downloadRequests.delete(value5);
      await value4.reply("❌ Download failed.");
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
    }
  }
};
