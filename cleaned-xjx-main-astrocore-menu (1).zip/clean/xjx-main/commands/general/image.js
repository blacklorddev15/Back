const axios = require("axios");
const MAX_LIMIT = 10;
const DEFAULT_LIMIT = 5;
const SEND_DELAY = 1500;
const DOWNLOAD_TIMEOUT = 30000;
async function react(value1, value2, value3, value4) {
  await value1.sendMessage(value2, {
    react: {
      text: value4,
      key: value3
    }
  });
}
function sleep(value5) {
  return new Promise(value6 => setTimeout(value6, value5));
}
async function searchImages(value7, value8) {
  const value9 = "https://api.cod3uchiha.com/downloaders/img?text=" + encodeURIComponent(value7) + "&_limit=" + value8;
  const {
    data: value10
  } = await axios.get(value9, {
    timeout: 30000
  });
  if (!value10?.status || !value10?.result?.images?.length) {
    throw new Error("No images found");
  }
  return value10.result;
}
async function downloadImage(value11) {
  try {
    const value12 = await axios.get(value11, {
      responseType: "arraybuffer",
      timeout: DOWNLOAD_TIMEOUT,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        Referer: "https://commons.wikimedia.org/",
        Accept: "image/*"
      }
    });
    return Buffer.from(value12.data);
  } catch (error13) {
    console.error("[img] download error:", error13.message);
    throw new Error("Failed to download image: " + error13.message);
  }
}
module.exports = [{
  name: "img",
  aliases: ["image", "images", "imgsearch"],
  category: "general",
  description: "Search and send images from the web",
  usage: ".img <query> [limit]",
  async execute(value14, value15, value16, value17) {
    const value18 = value17.from;
    if (!value16.length) {
      return value17.reply("🖼️ *Image Search*\n\n*Usage:*\n" + ("• `.img zoo` — search + send " + DEFAULT_LIMIT + " images\n") + ("• `.img zoo 8` — search + send up to 8 images (max " + MAX_LIMIT + ")"));
    }
    let value19 = DEFAULT_LIMIT;
    const value20 = value16[value16.length - 1];
    if (/^\d+$/.test(value20)) {
      value19 = Math.min(Math.max(parseInt(value20, 10), 1), MAX_LIMIT);
      value16 = value16.slice(0, -1);
    }
    const value21 = value16.join(" ").trim();
    if (!value21) {
      return value17.reply("🖼️ Provide a search term.\nExample: `.img zoo`");
    }
    if (value21.length > 100) {
      return value17.reply("📝 Search term too long! Max 100 chars.");
    }
    await react(value14, value18, value15.key, "🖼️");
    let value22;
    try {
      value22 = await searchImages(value21, value19);
    } catch (error23) {
      console.error("[img]", error23.message);
      await react(value14, value18, value15.key, "❌");
      return value17.reply("❌ Search failed: " + error23.message);
    }
    const value24 = value22.images.slice(0, value19);
    let value25 = 0;
    for (let value26 = 0; value26 < value24.length; value26++) {
      const value27 = value24[value26];
      try {
        const value28 = await downloadImage(value27.url);
        await value14.sendMessage(value18, {
          image: value28
        }, {
          quoted: value15
        });
        value25++;
        if (value26 < value24.length - 1) {
          await sleep(SEND_DELAY);
        }
      } catch (error29) {
        console.error("[img] send error:", error29.message);
        continue;
      }
    }
    if (value25 === 0) {
      await react(value14, value18, value15.key, "❌");
      return await value14.sendMessage(value18, {
        text: "🚫 Failed to download any images."
      }, {
        quoted: value15
      });
    }
    await react(value14, value18, value15.key, "✅");
  }
}];
