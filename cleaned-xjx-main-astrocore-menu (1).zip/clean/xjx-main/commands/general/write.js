const fs = require("fs");
const path = require("path");
const {
  exec,
  execSync
} = require("child_process");
const crypto = require("crypto");
const sharp = require("sharp");
const webp = require("node-webpmux");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const database = require("../../database");
let _ffmpegPath = null;
function resolveFFmpeg() {
  if (_ffmpegPath) {
    return _ffmpegPath;
  }
  const value1 = [];
  try {
    const value2 = execSync("which ffmpeg 2>/dev/null", {
      encoding: "utf8"
    }).trim();
    if (value2) {
      value1.push(value2);
    }
  } catch (error3) {}
  value1.push("/usr/bin/ffmpeg", "/usr/local/bin/ffmpeg");
  try {
    const value4 = execSync("find /nix/store -maxdepth 3 -name ffmpeg -type f 2>/dev/null | head -5", {
      encoding: "utf8",
      timeout: 4000
    }).split("\n").filter(Boolean);
    value1.push(...value4);
  } catch (error5) {}
  try {
    value1.push(require("ffmpeg-static"));
  } catch (error6) {}
  for (const value7 of value1) {
    try {
      if (!value7 || !fs.existsSync(value7)) {
        continue;
      }
      const value8 = execSync("\"" + value7 + "\" -filters 2>&1", {
        encoding: "utf8",
        timeout: 5000
      });
      if (value8.includes("drawtext")) {
        _ffmpegPath = value7;
        return value7;
      }
    } catch (error9) {}
  }
  return null;
}
const POSITION_ALIASES = {
  mid: "center",
  middle: "center",
  up: "top",
  down: "bottom",
  r: "right",
  l: "left"
};
function svgCoords(value10, value11, value12, value13, value14) {
  const value15 = 24;
  const value16 = value13 * 1.2;
  const value17 = value16 * value14;
  const value18 = value11 / 2;
  switch (value10) {
    case "top":
      return {
        x: value18,
        y: value15 + value13,
        anchor: "middle"
      };
    case "bottom":
      return {
        x: value18,
        y: value12 - value15 - value17 + value13,
        anchor: "middle"
      };
    case "left":
      return {
        x: value15,
        y: (value12 - value17) / 2 + value13,
        anchor: "start"
      };
    case "right":
      return {
        x: value11 - value15,
        y: (value12 - value17) / 2 + value13,
        anchor: "end"
      };
    case "topleft":
      return {
        x: value15,
        y: value15 + value13,
        anchor: "start"
      };
    case "topright":
      return {
        x: value11 - value15,
        y: value15 + value13,
        anchor: "end"
      };
    case "bottomleft":
      return {
        x: value15,
        y: value12 - value15 - value17 + value13,
        anchor: "start"
      };
    case "bottomright":
      return {
        x: value11 - value15,
        y: value12 - value15 - value17 + value13,
        anchor: "end"
      };
    default:
      return {
        x: value18,
        y: (value12 - value17) / 2 + value13,
        anchor: "middle"
      };
  }
}
function wrapText(value19, value20 = 20) {
  const value21 = value19.split(" ");
  const value22 = [];
  let value23 = "";
  for (const value24 of value21) {
    if ((value23 + (value23 ? " " : "") + value24).length > value20) {
      if (value23) {
        value22.push(value23);
      }
      value23 = value24;
    } else {
      value23 = value23 ? value23 + " " + value24 : value24;
    }
  }
  if (value23) {
    value22.push(value23);
  }
  return value22;
}
function xmlEsc(value25) {
  return value25.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
async function overlayTextSharp(value26, value27, value28, value29, value30 = {}) {
  const value31 = await sharp(value26).metadata();
  const value32 = value31.width || 512;
  const value33 = value31.height || 512;
  const value34 = Math.max(28, Math.min(72, Math.floor(value32 / 7)));
  const value35 = Math.max(10, Math.floor(value32 / (value34 * 0.55)));
  const value36 = wrapText(value27, value35);
  const value37 = value34 * 1.2;
  const {
    x: value38,
    y: value39,
    anchor: value40
  } = svgCoords(value28, value32, value33, value34, value36.length);
  const value41 = value36.map((value42, value43) => {
    const value44 = value43 === 0 ? 0 : value37;
    return "<tspan x=\"" + value38 + "\" dy=\"" + value44 + "\">" + xmlEsc(value42) + "</tspan>";
  }).join("");
  const value45 = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" + value32 + "\" height=\"" + value33 + "\">\n  <text\n    x=\"" + value38 + "\" y=\"" + value39 + "\"\n    text-anchor=\"" + value40 + "\"\n    font-family=\"DejaVu Sans Bold, Arial Bold, sans-serif\"\n    font-size=\"" + value34 + "\"\n    font-weight=\"bold\"\n    fill=\"white\"\n    stroke=\"black\"\n    stroke-width=\"" + Math.max(2, Math.round(value34 / 14)) + "\"\n    paint-order=\"stroke\"\n  >" + value41 + "</text>\n</svg>";
  let value46 = sharp(value26).composite([{
    input: Buffer.from(value45),
    top: 0,
    left: 0
  }]);
  if (value29 === "webp") {
    value46 = value46.webp({
      quality: 85,
      ...value30
    });
  } else {
    value46 = value46.jpeg({
      quality: 88,
      ...value30
    });
  }
  return value46.toBuffer();
}
function ffmpegDrawtext(value47, value48, value49, value50, value51, value52, value53) {
  const value54 = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf";
  const value55 = {
    center: "x=(w-text_w)/2:y=(h-text_h)/2",
    top: "x=(w-text_w)/2:y=30",
    bottom: "x=(w-text_w)/2:y=h-text_h-30",
    left: "x=20:y=(h-text_h)/2",
    right: "x=w-text_w-20:y=(h-text_h)/2",
    topleft: "x=20:y=20",
    topright: "x=w-text_w-20:y=20",
    bottomleft: "x=20:y=h-text_h-30",
    bottomright: "x=w-text_w-20:y=h-text_h-30"
  };
  const value56 = value55[value51] || value55.bottom;
  const value57 = "fontfile='" + value54 + "':textfile='" + value53 + "':fontsize=60:fontcolor=white:borderw=4:bordercolor=black:" + value56;
  const value58 = "scale=512:512:force_original_aspect_ratio=decrease";
  const value59 = "pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000";
  const value60 = value52 ? value58 + ",fps=15," + value59 + ",drawtext=" + value57 : value58 + ",format=rgba," + value59 + ",drawtext=" + value57;
  const value61 = "\"" + value47 + "\" -y -i \"" + value48 + "\" -vf \"" + value60 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 80 \"" + value49 + "\"";
  return new Promise((value62, value63) => exec(value61, {
    maxBuffer: 52428800
  }, value64 => value64 ? value63(value64) : value62()));
}
async function addExif(value65) {
  const value66 = new webp.Image();
  await value66.load(value65);
  const value67 = {
    "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
    "sticker-pack-name": database.getBotSetting("packname") || database.getBotSetting("botName"),
    emojis: ["✍️"]
  };
  const value68 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
  const value69 = Buffer.from(JSON.stringify(value67), "utf8");
  const value70 = Buffer.concat([value68, value69]);
  value70.writeUIntLE(value69.length, 14, 4);
  value66.exif = value70;
  return value66.save(null);
}
module.exports = {
  name: "write",
  aliases: ["memetext", "addtext", "textwrite", "wrt"],
  category: "general",
  description: "Write meme text on stickers or images (static & animated)",
  usage: ".write <text> [center|top|bottom|left|right] — reply to sticker/image",
  async execute(value71, value72, value73, value74) {
    const value75 = value74.from;
    if (!value73.length) {
      return value74.reply("✍️ *Write text on stickers / images*\n\n*Usage:* .write <text> [position]\n\n*Positions:*\n• center (default)\n• top  •  bottom\n• left  •  right\n• topleft  •  topright\n• bottomleft  •  bottomright\n\n*Examples:*\n_.write Supreme center_\n_.write It's me bottom_\n_.write LOL topleft_\n\nReply to an image or sticker.");
    }
    const value76 = ["center", "top", "bottom", "left", "right", "topleft", "topright", "bottomleft", "bottomright"];
    let value77 = "bottom";
    let value78 = [...value73];
    const value79 = value73[value73.length - 1].toLowerCase();
    const value80 = POSITION_ALIASES[value79] || (value76.includes(value79) ? value79 : null);
    if (value80) {
      value77 = value80;
      value78 = value73.slice(0, -1);
    }
    const value81 = value78.join(" ").trim();
    if (!value81) {
      return value74.reply("❌ Please provide the text to write.");
    }
    const value82 = value72.message?.extendedTextMessage?.contextInfo;
    if (!value82?.quotedMessage) {
      return value74.reply("❌ Reply to a sticker or image with this command.");
    }
    const value83 = value82.quotedMessage;
    const value84 = !!value83.stickerMessage;
    const value85 = !!value83.imageMessage;
    const value86 = !!value83.videoMessage;
    const value87 = value84 ? value83.stickerMessage?.isAnimated ?? false : value86;
    if (!value84 && !value85 && !value86) {
      return value74.reply("❌ Reply to a sticker or image.");
    }
    await value71.sendMessage(value75, {
      react: {
        text: "⏳",
        key: value72.key
      }
    });
    const value88 = getTempDir();
    const value89 = Date.now();
    const value90 = path.join(value88, "wrt_in_" + value89);
    const value91 = path.join(value88, "wrt_txt_" + value89 + ".txt");
    const value92 = path.join(value88, "wrt_out_" + value89 + ".webp");
    const value93 = path.join(value88, "wrt_out_" + value89 + ".jpg");
    const value94 = [value90, value91, value92, value93];
    try {
      const value95 = {
        key: {
          remoteJid: value75,
          id: value82.stanzaId,
          participant: value82.participant
        },
        message: value83
      };
      const value96 = await downloadMediaMessage(value95, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value71.updateMediaMessage
      });
      if (!value96) {
        return value74.reply("❌ Failed to download media.");
      }
      if (value87) {
        const value97 = resolveFFmpeg();
        if (!value97) {
          return value74.reply("❌ Animated stickers require ffmpeg with the *drawtext* filter, which is not available on this server.\n\nTry with a *static* sticker or image instead.");
        }
        fs.writeFileSync(value90, value96);
        fs.writeFileSync(value91, value81, "utf8");
        await ffmpegDrawtext(value97, value90, value92, value81, value77, true, value91);
        let value98 = fs.readFileSync(value92);
        value98 = await addExif(value98);
        await value71.sendMessage(value75, {
          sticker: value98
        }, {
          quoted: value72
        });
      } else if (value84) {
        let value99 = await overlayTextSharp(value96, value81, value77, "webp");
        value99 = await addExif(value99);
        await value71.sendMessage(value75, {
          sticker: value99
        }, {
          quoted: value72
        });
      } else {
        const value100 = await overlayTextSharp(value96, value81, value77, "jpeg");
        await value71.sendMessage(value75, {
          image: value100,
          caption: "✍️ " + value81
        }, {
          quoted: value72
        });
      }
      await value71.sendMessage(value75, {
        react: {
          text: "✅",
          key: value72.key
        }
      });
    } catch (error101) {
      console.error("[write] error:", error101.message || error101);
      await value71.sendMessage(value75, {
        react: {
          text: "❌",
          key: value72.key
        }
      });
      await value74.reply("❌ Failed to write text: " + error101.message);
    } finally {
      value94.forEach(value102 => {
        try {
          deleteTempFile(value102);
        } catch (error103) {}
      });
    }
  }
};
