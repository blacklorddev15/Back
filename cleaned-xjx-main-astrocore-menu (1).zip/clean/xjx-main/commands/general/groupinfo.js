module.exports = {
  name: "groupinfo",
  aliases: ["ginfo"],
  category: "general",
  description: "Show group information",
  usage: ".groupinfo",
  groupOnly: true,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.groupMetadata;
      const value6 = value5.participants.filter(value7 => value7.admin === "admin" || value7.admin === "superadmin");
      const value8 = value5.participants.filter(value9 => !value9.admin);
      let value10 = "📋 *GROUP INFORMATION*\n\n";
      value10 += "🏷️ Name: " + value5.subject + "\n";
      value10 += "🆔 ID: " + value5.id + "\n";
      value10 += "👥 Members: " + value5.participants.length + "\n";
      value10 += "👑 Admins: " + value6.length + "\n";
      value10 += "📝 Description: " + (value5.desc || "No description") + "\n";
      value10 += "🔒 Restricted: " + (value5.restrict ? "Yes" : "No") + "\n";
      value10 += "📢 Announce: " + (value5.announce ? "Yes" : "No") + "\n";
      value10 += "📅 Created: " + new Date(value5.creation * 1000).toLocaleDateString() + "\n\n";
      value10 += "👑 *Admins:*\n";
      value6.forEach((value11, value12) => {
        value10 += value12 + 1 + ". @" + value11.id.split("@")[0] + "\n";
      });
      await value1.sendMessage(value4.from, {
        text: value10,
        mentions: value6.map(value13 => value13.id)
      }, {
        quoted: value2
      });
    } catch (error14) {
      await value4.reply("❌ Error: " + error14.message);
    }
  }
};
