const {
  applyFont
} = require("../../utils/fontConverter");
const database = require("../../database");
module.exports = {
  name: "ping",
  aliases: ["pong", "p"],
  category: "general",
  description: "Check bot response speed with high precision (edits message)",
  usage: ".ping",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      const value6 = database.getBotSetting("botName") || "June-Ultra";
      const value7 = performance.now();
      const value8 = await value1.sendMessage(value5, {
        text: applyFont("🔸 pong!...")
      }, {
        quoted: value2
      });
      const value9 = (performance.now() - value7).toFixed(3);
      const value10 = applyFont("🔹 " + value6 + " Speed: " + value9 + " ms");
      await value1.sendMessage(value5, {
        text: value10,
        edit: value8.key
      }, {
        quoted: value2
      });
    } catch (error11) {
      console.error("[ping]", error11.message);
      await value4.reply("❌ Failed to measure speed.");
    }
  }
};
