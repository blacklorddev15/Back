const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const {
  webp2png,
  webp2mp4
} = require("../../utils/webp2mp4");
module.exports = {
  name: "simage",
  aliases: ["toimg", "toimage", "stickertoimg", "sticker2img", "svideo"],
  category: "general",
  description: "Convert sticker to image (PNG) or animated sticker to video (MP4)",
  usage: ".toimage (reply to sticker, or send sticker with .toimage as caption)",
  async execute(value1, value2, value3, value4) {
    try {
      let value5 = null;
      let value6 = null;
      if (value2.message?.stickerMessage) {
        value5 = value2;
        value6 = value2.message.stickerMessage;
      }
      if (!value6) {
        const value7 = value2.message?.extendedTextMessage?.contextInfo;
        if (value7?.quotedMessage?.stickerMessage) {
          value5 = {
            key: {
              remoteJid: value2.key.remoteJid,
              fromMe: false,
              id: value7.stanzaId,
              participant: value7.participant
            },
            message: value7.quotedMessage
          };
          value6 = value7.quotedMessage.stickerMessage;
        }
      }
      if (!value6 || !value5) {
        return await value4.reply("📎 Send a sticker with *.toimage* as caption, or reply to a sticker with *.toimage*");
      }
      const value8 = await downloadMediaMessage(value5, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value1.updateMediaMessage
      });
      if (!value8 || value8.length === 0) {
        return await value4.reply("❌ Failed to download sticker. Please try again.");
      }
      const value9 = value6.isAnimated === true;
      if (value9) {
        const value10 = await webp2mp4(value8);
        if (!value10 || value10.length === 0) {
          throw new Error("MP4 conversion returned empty output");
        }
        const value11 = 16777216;
        if (value10.length > value11) {
          throw new Error("MP4 too large: " + (value10.length / 1024 / 1024).toFixed(2) + "MB");
        }
        await value1.sendMessage(value4.from, {
          video: value10,
          mimetype: "video/mp4",
          gifPlayback: true
        }, {
          quoted: value2
        });
      } else {
        const value12 = await webp2png(value8);
        await value1.sendMessage(value4.from, {
          image: value12
        }, {
          quoted: value2
        });
      }
    } catch (error13) {
      console.log("[FFMPEG-ERR] simage/toimage command:", error13);
      await value4.reply("❌ Failed to convert sticker.\n\nError: " + error13.message);
    }
  }
};
