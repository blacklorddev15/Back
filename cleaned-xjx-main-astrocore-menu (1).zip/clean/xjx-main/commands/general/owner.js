const database = require("../../database");
module.exports = {
  name: "owner",
  aliases: ["creator", "dev", "botowner"],
  category: "general",
  description: "Show bot owner contact information",
  usage: ".owner",
  ownerOnly: false,
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      const value6 = Array.isArray(database.getOwnerNames()) ? database.getOwnerNames() : [database.getOwnerNames()];
      if (!database.getOwners().length) {
        return value4.reply("👑 *No owner is set yet.*\n\nThe paired account is claimed automatically when the bot connects.\nIf this persists, set one with:\n_.setownernumber <number>_");
      }
      const value7 = database.getOwners().map((value8, value9) => {
        const value10 = value6[value9] || value6[0] || "Bot Owner";
        return {
          vcard: ("\nBEGIN:VCARD\nVERSION:3.0\nFN:" + value10 + "\nTEL;waid=" + value8 + ":" + value8 + "\nEND:VCARD\n                    ").trim()
        };
      });
      const value11 = value6[0] || database.getOwnerNames() || "Bot Owner";
      await value1.sendMessage(value5, {
        contacts: {
          displayName: value11,
          contacts: value7
        }
      });
      await value4.reply("👑 Here is the contact of my *Owner*.");
    } catch (error12) {
      console.error("Owner command error:", error12);
      await value4.reply("❌ Error: " + error12.message);
    }
  }
};
