const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const {
  exec
} = require("child_process");
const ffmpegPath = require("../../utils/ffmpegPath");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const webp = require("node-webpmux");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const database = require("../../database");
const MAX_FILE_SIZE = 52428800;
const getQuotedMessage = value1 => value1.message?.extendedTextMessage?.contextInfo?.quotedMessage || value1.message?.buttonsResponseMessage?.contextInfo?.quotedMessage || value1.message?.listResponseMessage?.contextInfo?.quotedMessage || null;
const resolveMedia = value2 => {
  const value3 = Object.keys(value2.message || {})[0];
  if (value3 === "imageMessage" || value3 === "stickerMessage" || value3 === "videoMessage" || value3 === "documentMessage") {
    return {
      type: value3,
      media: value2.message[value3]
    };
  }
  const value4 = getQuotedMessage(value2);
  if (!value4) {
    return null;
  }
  const value5 = Object.keys(value4 || {})[0];
  if (value5 === "imageMessage" || value5 === "stickerMessage" || value5 === "videoMessage" || value5 === "documentMessage") {
    return {
      type: value5,
      media: value4[value5]
    };
  }
  return null;
};
module.exports = {
  name: "circlesticker",
  aliases: ["cs", "circsticker", "rsticker"],
  description: "Convert image/video/gif to a circular sticker (animated for videos)",
  usage: ".circlesticker (reply to image/video/gif) [packname|author]",
  category: "general",
  async execute(value6, value7, value8, value9) {
    const value10 = getTempDir();
    const value11 = path.join(value10, "temp_" + Date.now());
    const value12 = path.join(value10, "circlesticker_" + Date.now() + ".webp");
    const value13 = [value11, value12];
    try {
      const value14 = value7;
      let value15 = value7;
      if (value7.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
        const value16 = value7.message.extendedTextMessage.contextInfo;
        value15 = {
          key: {
            remoteJid: value9.from,
            id: value16.stanzaId,
            participant: value16.participant
          },
          message: value16.quotedMessage
        };
      }
      const value17 = resolveMedia(value15);
      if (!value17) {
        return value9.reply("🔵 Reply to an *image*, *video*, or *gif* that you want to turn into a circle sticker.");
      }
      const {
        type: value18,
        media: value19
      } = value17;
      const value20 = value19;
      if (!value20) {
        return value9.reply("🔵 Please reply to an image/video/gif with .circlesticker, or send one with .circlesticker as the caption.");
      }
      const value21 = await downloadMediaMessage(value15, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value6.updateMediaMessage
      });
      if (!value21) {
        return value9.reply("❌ Failed to download media. Please try again.");
      }
      if (value21.length > MAX_FILE_SIZE) {
        return value9.reply("❌ File too large: " + (value21.length / 1024 / 1024).toFixed(2) + "MB (max: " + MAX_FILE_SIZE / 1024 / 1024 + "MB)");
      }
      fs.writeFileSync(value11, value21);
      const value22 = value20.mimetype?.includes("gif") || value20.mimetype?.includes("video") || value20.seconds > 0 || value18 === "videoMessage";
      const value23 = value21.length / 1024;
      const value24 = value23 > 5000;
      const value25 = "crop=min(iw\\,ih):min(iw\\,ih),scale=512:512,format=rgba,geq=r='r(X\\,Y)':g='g(X\\,Y)':b='b(X\\,Y)':a='if(lte(pow(X-256\\,2)+pow(Y-256\\,2)\\,pow(256\\,2))\\,alpha(X\\,Y)\\,0)'";
      let value26;
      if (value22) {
        if (value24) {
          value26 = "\"" + ffmpegPath() + "\" -i \"" + value11 + "\" -t 2 -vf \"" + value25 + ",fps=8\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 30 -compression_level 6 -b:v 100k -max_muxing_queue_size 1024 \"" + value12 + "\"";
        } else {
          value26 = "\"" + ffmpegPath() + "\" -i \"" + value11 + "\" -t 3 -vf \"" + value25 + ",fps=12\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 50 -compression_level 6 -b:v 150k -max_muxing_queue_size 1024 \"" + value12 + "\"";
        }
      } else {
        value26 = "\"" + ffmpegPath() + "\" -i \"" + value11 + "\" -vf \"" + value25 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 75 -compression_level 6 \"" + value12 + "\"";
      }
      await new Promise((value27, value28) => {
        exec(value26, (value29, value30, value31) => {
          if (value29) {
            console.error("FFmpeg error:", value29);
            console.error("FFmpeg stderr:", value31);
            value28(value29);
          } else {
            console.log("FFmpeg stdout:", value30);
            value27();
          }
        });
      });
      if (!fs.existsSync(value12)) {
        throw new Error("FFmpeg failed to create output file");
      }
      const value32 = fs.statSync(value12);
      if (value32.size === 0) {
        throw new Error("FFmpeg created empty output file");
      }
      let value33 = fs.readFileSync(value12);
      const value34 = value33.length / 1024;
      console.log("Final sticker size: " + Math.round(value34) + " KB");
      if (value34 > 1000) {
        console.log("⚠️ Warning: Sticker size (" + Math.round(value34) + " KB) exceeds recommended limit but will be sent anyway");
      }
      const value35 = new webp.Image();
      await value35.load(value33);
      const value36 = value8.join(" ").trim();
      const [value37, value38] = value36 ? value36.split("|").map(value39 => value39.trim()) : [];
      const value40 = {
        "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
        "sticker-pack-name": value37 || database.getBotSetting("packname") || "✮⃝ˢᵘᵖʳᵉᵐᵉ ᴸᵒʳᵈ",
        "sticker-pack-publisher": value38 || database.getBotSetting("author") || "",
        emojis: ["⭕"]
      };
      const value41 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
      const value42 = Buffer.from(JSON.stringify(value40), "utf8");
      const value43 = Buffer.concat([value41, value42]);
      value43.writeUIntLE(value42.length, 14, 4);
      value35.exif = value43;
      const value44 = await value35.save(null);
      await value6.sendMessage(value9.from, {
        sticker: value44
      }, {
        quoted: value14
      });
    } catch (error45) {
      console.error("Circle sticker command error:", error45);
      await value9.reply("❌ Failed to create circle sticker! Try with an image, video, or gif.");
    } finally {
      value13.forEach(value46 => deleteTempFile(value46));
    }
  }
};
