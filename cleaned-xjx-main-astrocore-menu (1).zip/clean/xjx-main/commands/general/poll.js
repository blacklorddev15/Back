const MAX_OPTIONS = 12;
const MAX_QUESTION = 255;
const MAX_OPTION = 100;
function parsePollInput(value1) {
  const value2 = (value1 || []).join(" ").trim();
  if (!value2) {
    return {
      error: "usage"
    };
  }
  const value3 = value2.split(/\s+/);
  let value4 = 1;
  let value5 = value2;
  const value6 = (value3[0] || "").toLowerCase();
  if (["multi", "multiple", "m", "--multi"].includes(value6)) {
    value4 = 0;
    value5 = value3.slice(1).join(" ").trim();
  }
  if (!value5) {
    return {
      error: "usage"
    };
  }
  const value7 = value5.split(/\s*[|\/]\s*/).map(value8 => value8.replace(/\s+/g, " ").trim()).filter(Boolean);
  if (value7.length < 3) {
    return {
      error: "need-options"
    };
  }
  const value9 = value7[0].slice(0, MAX_QUESTION);
  const value10 = new Set();
  const value11 = [];
  for (const value12 of value7.slice(1)) {
    const value13 = value12.slice(0, MAX_OPTION);
    const value14 = value13.toLowerCase();
    if (value10.has(value14)) {
      continue;
    }
    value10.add(value14);
    value11.push(value13);
    if (value11.length >= MAX_OPTIONS) {
      break;
    }
  }
  if (value11.length < 2) {
    return {
      error: "need-options"
    };
  }
  if (value4 === 0) {
    value4 = value11.length;
  }
  return {
    question: value9,
    values: value11,
    selectableCount: value4
  };
}
module.exports = {
  name: "poll",
  aliases: ["vote", "createpoll", "wapoll"],
  category: "general",
  description: "Create a native WhatsApp poll",
  usage: ".poll Question | Option 1 | Option 2",
  async execute(value15, value16, value17, value18) {
    const value19 = parsePollInput(value17);
    if (value19.error) {
      return value18.reply("📊 *Create a Poll*\n\n*Usage:*\n  .poll Question | Option 1 | Option 2\n  .poll multi Question | A | B | C\n\n*Rules:*\n  • Separate question and options with `|`\n" + ("  • Minimum 2 options, maximum " + MAX_OPTIONS + "\n") + "  • `multi` lets people pick more than one\n\n*Example:*\n  .poll Dinner? | Rice | Beans | Pizza");
    }
    try {
      if (value18.react) {
        await value18.react("📊").catch(() => {});
      }
      await value15.sendMessage(value18.from, {
        poll: {
          name: value19.question,
          values: value19.values,
          selectableCount: value19.selectableCount,
          toAnnouncementGroup: false
        }
      }, {
        quoted: value16
      });
      if (value18.react) {
        await value18.react("✅").catch(() => {});
      }
    } catch (error20) {
      console.error("[poll]", error20.message);
      if (value18.react) {
        await value18.react("❌").catch(() => {});
      }
      await value18.reply("❌ Could not create the poll.\n" + (error20.message || "WhatsApp rejected the poll."));
    }
  }
};
