const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const webp = require("node-webpmux");
const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const path = require("path");
const {
  execSync
} = require("child_process");
const database = require("../../database");
let ffmpegPath;
try {
  ffmpegPath = require("ffmpeg-static");
} catch {
  ffmpegPath = "ffmpeg";
}
const stickerAuthor = () => database.getBotSetting("stickerAuthor") || database.getBotSetting("author") || database.getBotSetting("botName") || "JuneX";
async function injectExif(value1, value2, value3) {
  const value4 = new webp.Image();
  await value4.load(value1);
  const value5 = {
    "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
    "sticker-pack-name": value2,
    "sticker-pack-publisher": value3,
    emojis: ["🤖"]
  };
  const value6 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
  const value7 = Buffer.from(JSON.stringify(value5), "utf8");
  const value8 = Buffer.concat([value6, value7]);
  value8.writeUIntLE(value7.length, 14, 4);
  value4.exif = value8;
  return value4.save(null);
}
function toWebpViaFfmpeg(value9, value10, value11 = 10) {
  const value12 = path.join(os.tmpdir(), "take_" + Date.now() + ".webp");
  const value13 = value10 ? "scale=512:512:force_original_aspect_ratio=decrease,fps=" + value11 + ",pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black@0" : "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black@0";
  const value14 = value10 ? "-t 6" : "";
  const value15 = value10 ? "-loop 0" : "";
  execSync("\"" + ffmpegPath + "\" -y -i \"" + value9 + "\" " + value14 + " -vf \"" + value13 + "\" " + ("-an " + value15 + " -vcodec libwebp -preset default -qscale 60 \"" + value12 + "\""), {
    timeout: 30000,
    stdio: "pipe"
  });
  const value16 = fs.readFileSync(value12);
  try {
    fs.unlinkSync(value12);
  } catch {}
  return value16;
}
module.exports = [{
  name: "take",
  aliases: ["steal"],
  description: "Retake/repack an image, short video, or sticker as a JuneX sticker.",
  usage: ".take (reply to image/video/sticker)",
  category: "general",
  async execute(value17, value18, value19, value20) {
    const value21 = value18.message?.extendedTextMessage?.contextInfo;
    const value22 = value21?.quotedMessage;
    if (!value22) {
      return value20.reply("❌ Quote an image, a short video, or a sticker to retake it.");
    }
    let value23;
    if (value22.imageMessage) {
      value23 = "image";
    } else if (value22.videoMessage) {
      value23 = "video";
    } else if (value22.stickerMessage) {
      value23 = "sticker";
    } else {
      return value20.reply("❌ This is neither a sticker, image, nor a video.");
    }
    await value20.react("⏳");
    const value24 = {
      key: {
        remoteJid: value20.from,
        id: value21.stanzaId,
        participant: value21.participant,
        fromMe: false
      },
      message: value22
    };
    const value25 = value18.pushName || value20.sender.split("@")[0];
    const value26 = stickerAuthor();
    let value27;
    try {
      const value28 = await downloadMediaMessage(value24, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value17.updateMediaMessage
      });
      if (!value28) {
        await value20.react("❌");
        return value20.reply("❌ Failed to download media. Please try again.");
      }
      let value29;
      if (value23 === "sticker") {
        value29 = await injectExif(value28, value25, value26);
      } else {
        value27 = path.join(os.tmpdir(), "take_in_" + Date.now());
        fs.writeFileSync(value27, value28);
        const value30 = value23 === "video";
        let value31;
        try {
          value31 = toWebpViaFfmpeg(value27, value30, 10);
        } catch (error32) {
          console.error("[take] ffmpeg failed", error32.message);
          await value20.react("❌");
          return value20.reply("❌ Sticker conversion failed — ffmpeg may be unavailable on this server.");
        }
        if (value30 && value31.length > 972800) {
          try {
            value31 = toWebpViaFfmpeg(value27, true, 5);
          } catch (error33) {
            console.error("[take] ffmpeg retry failed", error33.message);
          }
        }
        if (value31.length > 1048576) {
          await value20.react("❌");
          return value20.reply("❌ Sticker still too large (" + (value31.length / 1024 / 1024).toFixed(2) + " MB) after compression.\n💡 Tip: Try a shorter clip (< 4s) or send an image instead.");
        }
        value29 = await injectExif(value31, value25, value26);
      }
      await value17.sendMessage(value20.from, {
        sticker: value29
      }, {
        quoted: value18
      });
      await value20.react("✅");
    } catch (error34) {
      console.error("[take]", error34.message);
      await value20.react("❌");
      await value20.reply("❌ Failed to retake sticker. Please try again.");
    } finally {
      if (value27) {
        try {
          fs.unlinkSync(value27);
        } catch {}
      }
    }
  }
}];
