const os = require("os");
const database = require("../../database");
const {
  loadCommands
} = require("../../utils/commandLoader");
const {
  sendButtons
} = require("gifted-btns");
const {
  applyFont
} = require("../../utils/fontConverter");
const {
  getSQLiteAuthStats
} = require("../../utils/juneDb/auth-state");
const botStartTime = Date.now() - Math.floor(process.uptime() * 1000);
const detectPlatform = () => {
  if (process.env.DYNO) {
    return "☁️ Heroku";
  }
  if (process.env.RENDER) {
    return "⚡ Render";
  }
  if (process.env.REPLIT_SLUG || process.env.REPL_ID) {
    return "🔵 Replit";
  }
  if (process.env.P_SERVER_UUID) {
    return "🖥️ Panel";
  }
  switch (os.platform()) {
    case "win32":
      return "🪟 Windows";
    case "darwin":
      return "🍎 macOS";
    case "linux":
      return "🐧 Linux";
    default:
      return "❓ Unknown";
  }
};
const formatUptime = value1 => {
  const value2 = Math.floor(value1 / 1000);
  const value3 = Math.floor(value2 / 86400);
  const value4 = Math.floor(value2 % 86400 / 3600);
  const value5 = Math.floor(value2 % 3600 / 60);
  const value6 = value2 % 60;
  const value7 = [];
  if (value3 > 0) {
    value7.push(value3 + "d");
  }
  if (value4 > 0) {
    value7.push(value4 + "h");
  }
  if (value5 > 0) {
    value7.push(value5 + "m");
  }
  value7.push(value6 + "s");
  return value7.join(" ");
};
const formatBytes = value8 => {
  if (value8 < 1048576) {
    return (value8 / 1024).toFixed(1) + " KB";
  }
  if (value8 < 1073741824) {
    return (value8 / 1024 / 1024).toFixed(1) + " MB";
  }
  return (value8 / 1024 / 1024 / 1024).toFixed(1) + " GB";
};
const formatAgo = value9 => {
  const value10 = Number(value9);
  if (!Number.isFinite(value10) || value10 <= 0) {
    return null;
  }
  const value11 = Math.max(0, Math.floor((Date.now() - value10) / 1000));
  if (value11 < 60) {
    return value11 + "s ago";
  }
  if (value11 < 3600) {
    return Math.floor(value11 / 60) + "m ago";
  }
  if (value11 < 86400) {
    return Math.floor(value11 / 3600) + "h ago";
  }
  return Math.floor(value11 / 86400) + "d ago";
};
const remoteLabel = value12 => {
  if (!value12?.configured) {
    return "not set";
  }
  if (value12.available) {
    return "connected";
  }
  return "unavailable";
};
const getDatabaseLines = () => {
  try {
    const value13 = database.getDatabaseHealth() || {};
    const value14 = value13.ok === false ? "SQLite degraded" : "SQLite ready";
    let value15 = "none";
    if (value13.backupExists && value13.backupValid === false) {
      value15 = "invalid";
    } else if (value13.backupExists) {
      const value16 = formatAgo(value13.lastBackup?.timestamp);
      value15 = value16 ? "ok · " + value16 : "ok";
    }
    let value17 = "unknown";
    try {
      const value18 = getSQLiteAuthStats(database._db);
      const value19 = Number(value18?.totalKeys || 0);
      if (value18?.verified) {
        value17 = "verified · " + value19 + " keys";
      } else if (value18?.hasCreds) {
        value17 = "active · " + value19 + " keys";
      } else {
        value17 = "not verified";
      }
    } catch (error20) {
      value17 = "unknown";
    }
    return {
      engine: value14,
      backup: value15,
      postgres: remoteLabel(value13.postgres),
      mongo: remoteLabel(value13.mongo),
      session: value17
    };
  } catch (error21) {
    return {
      engine: "SQLite unknown",
      backup: "unknown",
      postgres: "unknown",
      mongo: "unknown",
      session: "unknown"
    };
  }
};
module.exports = {
  name: "botinfo",
  aliases: ["info", "about"],
  category: "general",
  description: "Show detailed bot information and system stats",
  usage: ".botinfo",
  ownerOnly: false,
  async execute(value22, value23, value24, value25) {
    const value26 = value25.from;
    const value27 = database.getBotSetting("prefix") || ".";
    const value28 = Date.now() - botStartTime;
    const value29 = process.memoryUsage();
    const value30 = os.cpus();
    const value31 = value30[0]?.model?.trim() || "Unknown";
    const value32 = value30.length;
    const value33 = getDatabaseLines();
    let value34 = 0;
    try {
      value34 = loadCommands().size;
    } catch (error35) {}
    const value36 = Array.isArray(database.getOwnerNames()) ? database.getOwnerNames().join(", ") : database.getOwnerNames();
    const value37 = applyFont("┏━━『 BOT INFORMATION 』━━\n\n" + ("➥ Bot Name  ➜ " + database.getBotSetting("botName") + "\n") + ("➥ Prefix    ➜ " + value27 + "\n") + ("➥ Owner     ➜ " + value36 + "\n") + ("➥ Commands  ➜ " + value34 + "\n") + ("➥ Version   ➜ v" + (database.VERSION || "1.0.0") + "\n") + ("➥ Node.js   ➜ " + process.version + "\n\n") + "┃ System\n" + ("➥ Platform  ➜ " + detectPlatform() + "\n") + ("➥ CPU       ➜ " + value31 + "\n") + ("➥ Cores     ➜ " + value32 + "\n") + ("➥ Uptime    ➜ " + formatUptime(value28) + "\n\n") + "┃ Memory\n" + ("➥ Heap Used  ➜ " + formatBytes(value29.heapUsed) + "\n") + ("➥ Heap Total ➜ " + formatBytes(value29.heapTotal) + "\n") + ("➥ RAM Total  ➜ " + formatBytes(os.totalmem()) + "\n") + ("➥ RAM Free   ➜ " + formatBytes(os.freemem()) + "\n\n") + "┃ Database\n" + ("➥ Engine    ➜ " + value33.engine + "\n") + ("➥ Backup    ➜ " + value33.backup + "\n") + ("➥ Postgres  ➜ " + value33.postgres + "\n") + ("➥ Mongo     ➜ " + value33.mongo + "\n") + ("➥ Session   ➜ " + value33.session + "\n\n") + "┗━━━━━━━━━━━━━━━━");
    await sendButtons(value22, value26, {
      title: "",
      text: value37,
      footer: "> Powered by " + database.getBotSetting("botName"),
      buttons: [{
        id: value27 + "ping",
        text: "🏓 Ping"
      }, {
        id: value27 + "uptime",
        text: "⏱️ Uptime"
      }, {
        id: value27 + "restart",
        text: "🔄 Restart Bot"
      }]
    }, {
      quoted: value23
    });
  }
};
