const axios = require("axios");
const BASE = "https://apiskeith2-production-ec66.up.railway.app";
async function keithApi(value1, value2 = {}) {
  const value3 = "" + BASE + value1;
  const {
    data: value4
  } = await axios.get(value3, {
    params: value2,
    timeout: 30000
  });
  if (!value4) {
    throw new Error("No response from API");
  }
  if (value4.status === false) {
    throw new Error(value4.error || value4.message || "API error");
  }
  if (value4.result !== undefined) {
    return value4.result;
  } else {
    return value4;
  }
}
const react = (value5, value6, value7) => value5.sendMessage(value6.key.remoteJid, {
  react: {
    text: value7,
    key: value6.key
  }
});
const send = (value8, value9, value10) => value8.sendMessage(value9.key.remoteJid, {
  text: value10
}, {
  quoted: value9
});
async function sendLong(value11, value12, value13, value14, value15 = "┗━━━━━━━━━━━━━━━━") {
  const value16 = 4000;
  const value17 = value14.split("\n");
  const value18 = [];
  let value19 = "";
  for (const value20 of value17) {
    if ((value19 + value20 + "\n").length > value16) {
      if (value19) {
        value18.push(value19);
      }
      value19 = "";
    }
    value19 += value20 + "\n";
  }
  if (value19.trim()) {
    value18.push(value19);
  }
  if (!value18.length) {
    value18.push("_No data available_");
  }
  for (let value21 = 0; value21 < value18.length; value21++) {
    const value22 = value21 === 0;
    const value23 = value21 === value18.length - 1;
    const value24 = value18.length > 1 ? " (" + (value21 + 1) + "/" + value18.length + ")" : "";
    const value25 = "" + value13 + value24 + "\n\n" + value18[value21] + (value23 ? "\n" + value15 : "\n_continued..._");
    await value11.sendMessage(value12.key.remoteJid, {
      text: value25
    }, {
      quoted: value22 ? value12 : undefined
    });
    if (!value23) {
      await new Promise(value26 => setTimeout(value26, 800));
    }
  }
}
function fmtPlayers(value27) {
  const value28 = Array.isArray(value27) ? value27 : [];
  if (!value28.length) {
    return "_No players found_";
  }
  return value28.slice(0, 10).map((value29, value30) => {
    let value31 = "*" + (value30 + 1) + ". " + (value29.name || value29.strPlayer || "Unknown") + "*\n";
    if (value29.team) {
      value31 += "   🏟️ Team: " + value29.team + "\n";
    }
    if (value29.sport) {
      value31 += "   🏅 Sport: " + value29.sport + "\n";
    }
    if (value29.nationality) {
      value31 += "   🌍 Nationality: " + value29.nationality + "\n";
    }
    if (value29.position) {
      value31 += "   📍 Position: " + value29.position + "\n";
    }
    if (value29.birthDate) {
      value31 += "   🎂 Born: " + value29.birthDate + "\n";
    }
    if (value29.status) {
      value31 += "   ✅ Status: " + value29.status + "\n";
    }
    return value31;
  }).join("\n");
}
function fmtTeams(value32) {
  const value33 = Array.isArray(value32) ? value32 : [];
  if (!value33.length) {
    return "_No teams found_";
  }
  return value33.slice(0, 5).map((value34, value35) => {
    let value36 = "*" + (value35 + 1) + ". " + (value34.name || "Unknown") + "*\n";
    if (value34.league) {
      value36 += "   🏆 League: " + value34.league + "\n";
    }
    if (value34.sport) {
      value36 += "   🏅 Sport: " + value34.sport + "\n";
    }
    if (value34.stadium) {
      value36 += "   🏟️ Stadium: " + value34.stadium + "\n";
    }
    if (value34.stadiumCapacity) {
      value36 += "   👥 Capacity: " + Number(value34.stadiumCapacity).toLocaleString() + "\n";
    }
    if (value34.location) {
      value36 += "   📍 Location: " + value34.location + "\n";
    }
    if (value34.country) {
      value36 += "   🌍 Country: " + value34.country + "\n";
    }
    if (value34.formedYear) {
      value36 += "   📅 Founded: " + value34.formedYear + "\n";
    }
    if (value34.social?.website) {
      value36 += "   🌐 " + value34.social.website + "\n";
    }
    if (value34.description) {
      value36 += "   📝 " + String(value34.description).slice(0, 200).trim() + "...\n";
    }
    return value36;
  }).join("\n");
}
function fmtVenues(value37) {
  const value38 = Array.isArray(value37) ? value37 : [];
  if (!value38.length) {
    return "_No venues found_";
  }
  return value38.slice(0, 5).map((value39, value40) => {
    let value41 = "*" + (value40 + 1) + ". " + (value39.name || "Unknown") + "*\n";
    if (value39.sport) {
      value41 += "   🏅 Sport: " + value39.sport + "\n";
    }
    if (value39.capacity) {
      value41 += "   👥 Capacity: " + Number(value39.capacity).toLocaleString() + "\n";
    }
    if (value39.location) {
      value41 += "   📍 Location: " + value39.location + "\n";
    }
    if (value39.country) {
      value41 += "   🌍 Country: " + value39.country + "\n";
    }
    if (value39.description) {
      value41 += "   📝 " + String(value39.description).slice(0, 200).trim() + "...\n";
    }
    return value41;
  }).join("\n");
}
function fmtGameEvents(value42) {
  const value43 = Array.isArray(value42) ? value42 : [];
  if (!value43.length) {
    return "_No events found_";
  }
  return value43.slice(0, 10).map(value44 => {
    const value45 = value44.teams?.home?.name || value44.homeTeam || "?";
    const value46 = value44.teams?.away?.name || value44.awayTeam || "?";
    const value47 = value44.teams?.home?.score;
    const value48 = value44.teams?.away?.score;
    const value49 = value44.dateTime?.date || value44.date || "";
    const value50 = value44.dateTime?.time?.slice(0, 5) || "";
    const value51 = value44.venue?.name || "";
    const value52 = value44.status || "";
    const value53 = value44.season || "";
    let value54 = "┏ *" + value45 + "* vs *" + value46 + "*\n";
    if (value47 !== null && value47 !== undefined && value48 !== null && value48 !== undefined) {
      value54 += "┃ 📊 Score: " + value47 + " - " + value48 + "\n";
    }
    if (value49) {
      value54 += "┃ 📅 " + value49 + (value50 ? " " + value50 : "") + "\n";
    }
    if (value51) {
      value54 += "┃ 🏟️ " + value51 + "\n";
    }
    if (value52) {
      value54 += "┃ 🔄 " + value52 + "\n";
    }
    if (value53) {
      value54 += "┃ 📋 Season: " + value53 + "\n";
    }
    value54 += "┗━━━━━━━━━━━━━━━\n";
    return value54;
  }).join("\n");
}
function fmtStandings(value55) {
  const value56 = value55?.standings || (Array.isArray(value55) ? value55 : []);
  if (!value56.length) {
    return "_No standings data available_";
  }
  const value57 = value55?.competition ? value55.competition + "\n\n" : "";
  const value58 = value56.slice(0, 25).map(value59 => {
    const value60 = String(value59.position || "").padStart(2);
    const value61 = (value59.team || value59.name || "?").padEnd(28);
    const value62 = value59.played ?? value59.mp ?? 0;
    const value63 = value59.won ?? value59.w ?? 0;
    const value64 = value59.draw ?? value59.drawn ?? value59.d ?? 0;
    const value65 = value59.lost ?? value59.l ?? 0;
    const value66 = value59.points ?? value59.pts ?? 0;
    const value67 = value59.goalDifference ?? value59.gd ?? "";
    return value60 + ". " + value61 + " P" + value62 + " W" + value63 + " D" + value64 + " L" + value65 + (value67 !== "" ? " GD" + value67 : "") + " | *" + value66 + "pts*";
  });
  return value57 + value58.join("\n");
}
function fmtScorers(value68) {
  const value69 = value68?.topScorers || value68?.scorers || (Array.isArray(value68) ? value68 : []);
  if (!value69.length) {
    return "_No scorers data available_";
  }
  const value70 = value68?.competition ? value68.competition + "\n\n" : "";
  const value71 = value69.slice(0, 20).map((value72, value73) => {
    const value74 = value72.rank || value72.position || value73 + 1;
    const value75 = value72.player || value72.name || value72.strPlayer || "?";
    const value76 = value72.team || value72.club || "";
    const value77 = value72.goals ?? value72.scored ?? value72.numberOfGoals ?? "?";
    const value78 = value72.assists ?? "";
    let value79 = "*" + value74 + ".* ⚽ " + value75 + (value76 ? " (" + value76 + ")" : "") + "\n";
    value79 += "    Goals: *" + value77 + "*" + (value78 !== "" ? " │ Assists: " + value78 : "") + "\n";
    return value79;
  });
  return value70 + value71.join("");
}
function fmtMatches(value80) {
  const value81 = value80?.upcomingMatches || value80?.matches || value80?.fixtures || (Array.isArray(value80) ? value80 : []);
  if (!value81.length) {
    return "_No matches data available_";
  }
  const value82 = value80?.competition ? value80.competition + "\n\n" : "";
  const value83 = value81.slice(0, 15).map(value84 => {
    const value85 = value84.homeTeam || value84.home || value84.team1 || "?";
    const value86 = value84.awayTeam || value84.away || value84.team2 || "?";
    const value87 = value84.score || (value84.homeScore !== undefined ? value84.homeScore + " - " + value84.awayScore : null);
    const value88 = value84.date || value84.utcDate || "";
    const value89 = value84.matchday ? "MD" + value84.matchday : "";
    let value90 = "┏ " + value85 + " vs " + value86 + "\n";
    if (value87) {
      value90 += "┃ 📊 " + value87 + "\n";
    }
    if (value89) {
      value90 += "┃ 📋 " + value89 + "\n";
    }
    if (value88) {
      value90 += "┃ 📅 " + value88 + "\n";
    }
    value90 += "┗━━━━━━━━━━━━━━━\n";
    return value90;
  });
  return value82 + value83.join("\n");
}
function fmtFifaUpcoming(value91) {
  const value92 = value91?.upcomingMatches || (Array.isArray(value91) ? value91 : []);
  if (!value92.length) {
    return "_No upcoming FIFA World Cup matches found_";
  }
  const value93 = value91?.competition ? "🌍 *" + value91.competition + "*\n\n" : "";
  const value94 = value92.map((value95, value96) => {
    const value97 = value95.homeTeam || "TBD";
    const value98 = value95.awayTeam || "TBD";
    const value99 = value95.matchday && value95.matchday !== "N/A" ? "MD" + value95.matchday : "";
    const value100 = value95.date || "";
    let value101 = "┏ *Match " + (value96 + 1) + "*\n";
    value101 += "┃ ⚔️ " + value97 + " vs " + value98 + "\n";
    if (value100) {
      value101 += "┃ 📅 " + value100 + "\n";
    }
    if (value99) {
      value101 += "┃ 📋 " + value99 + "\n";
    }
    value101 += "┗━━━━━━━━━━━━━━━\n";
    return value101;
  });
  return value93 + value94.join("\n");
}
function fmtFifaMatches(value102) {
  const value103 = value102?.matches || (Array.isArray(value102) ? value102 : []);
  if (!value103.length) {
    return "_No FIFA World Cup match results found_";
  }
  const value104 = value102?.competition ? "🌍 *" + value102.competition + "*\n\n" : "";
  const value105 = value103.map((value106, value107) => {
    const value108 = value106.homeTeam || "TBD";
    const value109 = value106.awayTeam || "TBD";
    const value110 = value106.matchday ? "MD" + value106.matchday : "";
    const value111 = value106.score || "";
    const value112 = value106.status || "";
    const value113 = value106.winner || "";
    let value114 = "┏ *Match " + (value107 + 1) + "*\n";
    value114 += "┃ ⚔️ " + value108 + " vs " + value109 + "\n";
    if (value111) {
      value114 += "┃ 📊 Score: *" + value111 + "*\n";
    }
    if (value110) {
      value114 += "┃ 📋 " + value110 + "\n";
    }
    if (value112) {
      value114 += "┃ 🔄 " + value112 + "\n";
    }
    if (value113) {
      value114 += "┃ 🏆 " + (value113 === "Draw" ? "Draw" : "Winner: " + value113) + "\n";
    }
    value114 += "┗━━━━━━━━━━━━━━━\n";
    return value114;
  });
  return value104 + value105.join("\n");
}
function fmtFifaStandings(value115) {
  const value116 = value115?.standings || (Array.isArray(value115) ? value115 : []);
  if (!value116.length) {
    return "_No FIFA World Cup standings found_";
  }
  const value117 = value115?.competition ? "🌍 *" + value115.competition + "*\n\n" : "";
  const value118 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let value119 = "";
  for (let value120 = 0; value120 < value116.length; value120 += 4) {
    const value121 = value116.slice(value120, value120 + 4);
    const value122 = value116.length > 4 ? "🔷 *GROUP " + value118[Math.floor(value120 / 4)] + "*\n" : "";
    value119 += value122;
    value119 += "─".repeat(46) + "\n";
    value119 += "  Team                   MP  W  D  L GF GA GD Pts\n";
    value119 += "─".repeat(46) + "\n";
    value121.forEach((value123, value124) => {
      const value125 = value124 < 2 ? "✅" : "❌";
      const value126 = (value123.team || "?").padEnd(20);
      const value127 = String(value123.played ?? 0).padStart(2);
      const value128 = String(value123.won ?? 0).padStart(2);
      const value129 = String(value123.draw ?? 0).padStart(2);
      const value130 = String(value123.lost ?? 0).padStart(2);
      const value131 = String(value123.goalsFor ?? 0).padStart(3);
      const value132 = String(value123.goalsAgainst ?? 0).padStart(3);
      const value133 = String(value123.goalDifference ?? 0).padStart(3);
      const value134 = String(value123.points ?? 0).padStart(3);
      value119 += value125 + " " + value126 + value127 + " " + value128 + " " + value129 + " " + value130 + value131 + value132 + value133 + value134 + "\n";
    });
    value119 += "\n";
  }
  return value117 + value119.trim();
}
function fmtFifaScorers(value135) {
  const value136 = value135?.topScorers || (Array.isArray(value135) ? value135 : []);
  if (!value136.length) {
    return "_No FIFA World Cup top scorers found_";
  }
  const value137 = value135?.competition ? "🌍 *" + value135.competition + "*\n\n" : "";
  const value138 = value136.map((value139, value140) => {
    const value141 = value139.rank || value140 + 1;
    const value142 = value139.player || "?";
    const value143 = value139.team || "";
    const value144 = value139.goals ?? "?";
    const value145 = value139.assists;
    const value146 = value139.penalties;
    let value147 = "*" + value141 + ".* ⚽ " + value142 + (value143 ? " (" + value143 + ")" : "") + "\n";
    value147 += "    Goals: *" + value144 + "*";
    if (value145 !== undefined && value145 !== "N/A") {
      value147 += " │ Assists: " + value145;
    }
    if (value146 !== undefined && value146 !== "N/A") {
      value147 += " │ Penalties: " + value146;
    }
    value147 += "\n";
    return value147;
  });
  return value137 + value138.join("");
}
function fmtLivescore(value148) {
  const value149 = value148?.games || value148;
  let value150 = Array.isArray(value149) ? value149 : Object.values(value149 || {});
  if (!value150.length) {
    return "_No live games right now_";
  }
  return value150.slice(0, 20).map(value151 => {
    const value152 = value151.p1 || value151.home || "?";
    const value153 = value151.p2 || value151.away || "?";
    const value154 = value151.R?.r1 ?? value151.homeScore ?? "";
    const value155 = value151.R?.r2 ?? value151.awayScore ?? "";
    const value156 = value151.R?.st || value151.status || "";
    const value157 = value151.dt || "";
    const value158 = value151.tm || "";
    let value159 = "┏ " + value152 + " *" + value154 + "* - *" + value155 + "* " + value153 + "\n";
    if (value156) {
      value159 += "┃ ⏱ " + value156 + "\n";
    }
    if (value157) {
      value159 += "┃ 📅 " + value157 + (value158 ? " " + value158 : "") + "\n";
    }
    value159 += "┗━━━━━━━━━━━━━━━\n";
    return value159;
  }).join("\n");
}
function fmtLivescore2(value160) {
  const value161 = value160?.data?.list || value160?.list || (Array.isArray(value160) ? value160 : []);
  if (!value161.length) {
    return "_No live highlights right now_";
  }
  return value161.slice(0, 15).map(value162 => {
    const value163 = value162.team1?.name || "?";
    const value164 = value162.team2?.name || "?";
    const value165 = value162.team1?.score ?? "";
    const value166 = value162.team2?.score ?? "";
    const value167 = value162.status || "";
    let value168 = "┏ " + value163 + " *" + value165 + "* - *" + value166 + "* " + value164 + "\n";
    if (value167) {
      value168 += "┃ 🔴 " + value167 + "\n";
    }
    if (value162.playPath) {
      value168 += "┃ 🎬 " + value162.playPath + "\n";
    }
    value168 += "┗━━━━━━━━━━━━━━━\n";
    return value168;
  }).join("\n");
}
function fmtNews(value169) {
  const value170 = value169?.data?.items || value169?.items || (Array.isArray(value169) ? value169 : []);
  if (!value170.length) {
    return "_No news available_";
  }
  return value170.slice(0, 10).map((value171, value172) => {
    const value173 = value171.title || value171.headline || "";
    const value174 = value171.summary || value171.description || "";
    const value175 = value171.date || (value171.createdAt ? new Date(Number(value171.createdAt)).toLocaleDateString() : "");
    let value176 = "*" + (value172 + 1) + ". " + value173 + "*\n";
    if (value175) {
      value176 += "📅 " + value175 + "\n";
    }
    if (value174) {
      value176 += String(value174).slice(0, 250) + "\n";
    }
    return value176 + "\n";
  }).join("");
}
function fmtBet(value177) {
  const value178 = Array.isArray(value177) ? value177 : value177?.tips || value177?.bets || [];
  if (!value178.length) {
    return "_No bet tips available right now. Try again later._";
  }
  return value178.slice(0, 15).map((value179, value180) => {
    const value181 = value179.match || value179.game || value179.fixture || "Match " + (value180 + 1);
    const value182 = value179.tip || value179.prediction || value179.pick || "";
    const value183 = value179.odds || value179.odd || "";
    const value184 = value179.confidence || value179.probability || "";
    let value185 = "*" + (value180 + 1) + ". " + value181 + "*\n";
    if (value182) {
      value185 += "   🎯 Tip: " + value182 + "\n";
    }
    if (value183) {
      value185 += "   💰 Odds: " + value183 + "\n";
    }
    if (value184) {
      value185 += "   📊 Confidence: " + value184 + "\n";
    }
    return value185;
  }).join("\n");
}
async function leagueHandler(value186, value187, value188, value189, value190, value191) {
  const value192 = (value188[0] || "").toLowerCase();
  const value193 = Object.keys(value191);
  if (!value192 || !value193.includes(value192)) {
    return send(value186, value187, "┏━━『 " + value190 + " 』━━\n\n" + ("Usage: ." + value189.command + " <option>\n\n") + "Options:\n" + value193.map(value194 => "  • *" + value194 + "*").join("\n") + "\n\n┗━━━━━━━━━━━━━━━━");
  }
  await react(value186, value187, "⏳");
  try {
    const {
      endpoint: value195,
      format: value196,
      title: value197
    } = value191[value192];
    const value198 = await keithApi(value195);
    const value199 = value196(value198);
    await sendLong(value186, value187, "┏━━『 " + value190 + " — " + value197 + " 』━━", value199);
    await react(value186, value187, "✅");
  } catch (error200) {
    console.error("[" + value190 + "/" + value192 + "]", error200.message);
    await react(value186, value187, "❌");
    value189.reply("❌ " + value190 + " " + value192 + " failed: " + error200.message);
  }
}
module.exports = [{
  name: "playersearch",
  aliases: ["psearch", "kplayer"],
  category: "sports",
  description: "Search for any sport player",
  usage: ".playersearch <player name>",
  async execute(value201, value202, value203, value204) {
    const value205 = value203.join(" ").trim();
    if (!value205) {
      return value204.reply("❌ Provide a player name.\n\nExample: *.playersearch Bukayo Saka*");
    }
    await react(value201, value202, "🔍");
    try {
      const value206 = await keithApi("/sport/playersearch", {
        q: value205
      });
      await sendLong(value201, value202, "┏━━『 🔍 Player Search: \"" + value205 + "\" 』━━", fmtPlayers(value206));
      await react(value201, value202, "✅");
    } catch (error207) {
      await react(value201, value202, "❌");
      value204.reply("❌ Search failed: " + error207.message);
    }
  }
}, {
  name: "kteamsearch",
  aliases: ["tsearch", "kteam"],
  category: "sports",
  description: "Search for any sport team",
  usage: ".kteamsearch <team name>",
  async execute(value208, value209, value210, value211) {
    const value212 = value210.join(" ").trim();
    if (!value212) {
      return value211.reply("❌ Provide a team name.\n\nExample: *.kteamsearch Arsenal*");
    }
    await react(value208, value209, "🔍");
    try {
      const value213 = await keithApi("/sport/teamsearch", {
        q: value212
      });
      await sendLong(value208, value209, "┏━━『 🔍 Team Search: \"" + value212 + "\" 』━━", fmtTeams(value213));
      await react(value208, value209, "✅");
    } catch (error214) {
      await react(value208, value209, "❌");
      value211.reply("❌ Search failed: " + error214.message);
    }
  }
}, {
  name: "venuesearch",
  aliases: ["stadium", "findvenue"],
  category: "sports",
  description: "Search for a stadium/venue",
  usage: ".venuesearch <venue name>",
  async execute(value215, value216, value217, value218) {
    const value219 = value217.join(" ").trim();
    if (!value219) {
      return value218.reply("❌ Provide a venue name.\n\nExample: *.venuesearch Emirates*");
    }
    await react(value215, value216, "🔍");
    try {
      const value220 = await keithApi("/sport/venuesearch", {
        q: value219
      });
      await sendLong(value215, value216, "┏━━『 🏟️ Venue Search: \"" + value219 + "\" 』━━", fmtVenues(value220));
      await react(value215, value216, "✅");
    } catch (error221) {
      await react(value215, value216, "❌");
      value218.reply("❌ Search failed: " + error221.message);
    }
  }
}, {
  name: "gameevents",
  aliases: ["matchhistory", "h2h"],
  category: "sports",
  description: "Game events/history between two teams",
  usage: ".gameevents <team vs team>",
  async execute(value222, value223, value224, value225) {
    const value226 = value224.join(" ").trim();
    if (!value226) {
      return value225.reply("❌ Provide a match query.\n\nExample: *.gameevents Arsenal vs Chelsea*");
    }
    await react(value222, value223, "⏳");
    try {
      const value227 = await keithApi("/sport/gameevents", {
        q: value226
      });
      await sendLong(value222, value223, "┏━━『 📋 Game Events: \"" + value226 + "\" 』━━", fmtGameEvents(value227));
      await react(value222, value223, "✅");
    } catch (error228) {
      await react(value222, value223, "❌");
      value225.reply("❌ Failed: " + error228.message);
    }
  }
}, {
  name: "fifaupcoming",
  aliases: ["wcupcoming", "fifafixtures", "worldcupfixtures"],
  category: "sports",
  description: "FIFA World Cup — upcoming matches",
  usage: ".fifaupcoming",
  async execute(value229, value230, value231, value232) {
    await react(value229, value230, "⏳");
    try {
      const value233 = await keithApi("/fifa/upcomingmatches");
      await sendLong(value229, value230, "┏━━『 🌍 FIFA World Cup — Upcoming Matches 』━━", fmtFifaUpcoming(value233));
      await react(value229, value230, "✅");
    } catch (error234) {
      console.error("[fifaupcoming]", error234.message);
      await react(value229, value230, "❌");
      value232.reply("❌ Failed to fetch upcoming FIFA matches: " + error234.message);
    }
  }
}, {
  name: "fifamatches",
  aliases: ["wcmatches", "fifaresults", "worldcupresults"],
  category: "sports",
  description: "FIFA World Cup — match results",
  usage: ".fifamatches",
  async execute(value235, value236, value237, value238) {
    await react(value235, value236, "⏳");
    try {
      const value239 = await keithApi("/fifa/matches");
      await sendLong(value235, value236, "┏━━『 🌍 FIFA World Cup — Match Results 』━━", fmtFifaMatches(value239));
      await react(value235, value236, "✅");
    } catch (error240) {
      console.error("[fifamatches]", error240.message);
      await react(value235, value236, "❌");
      value238.reply("❌ Failed to fetch FIFA match results: " + error240.message);
    }
  }
}, {
  name: "fifastandings",
  aliases: ["wcstandings", "fifatable", "worldcupstandings"],
  category: "sports",
  description: "FIFA World Cup — group standings",
  usage: ".fifastandings",
  async execute(value241, value242, value243, value244) {
    await react(value241, value242, "⏳");
    try {
      const value245 = await keithApi("/fifa/standings");
      await sendLong(value241, value242, "┏━━『 🌍 FIFA World Cup — Standings 』━━", fmtFifaStandings(value245));
      await react(value241, value242, "✅");
    } catch (error246) {
      console.error("[fifastandings]", error246.message);
      await react(value241, value242, "❌");
      value244.reply("❌ Failed to fetch FIFA standings: " + error246.message);
    }
  }
}, {
  name: "fifascorers",
  aliases: ["wcscorers", "fifatopscorers", "worldcupscorers"],
  category: "sports",
  description: "FIFA World Cup — top scorers",
  usage: ".fifascorers",
  async execute(value247, value248, value249, value250) {
    await react(value247, value248, "⏳");
    try {
      const value251 = await keithApi("/fifa/scorers");
      await sendLong(value247, value248, "┏━━『 🌍 FIFA World Cup — Top Scorers 』━━", fmtFifaScorers(value251));
      await react(value247, value248, "✅");
    } catch (error252) {
      console.error("[fifascorers]", error252.message);
      await react(value247, value248, "❌");
      value250.reply("❌ Failed to fetch FIFA top scorers: " + error252.message);
    }
  }
}, {
  name: "livescore",
  aliases: ["live", "liveresults"],
  category: "sports",
  description: "Get current football live scores",
  usage: ".livescore",
  async execute(value253, value254, value255, value256) {
    await react(value253, value254, "⏳");
    try {
      const value257 = await keithApi("/livescore");
      await sendLong(value253, value254, "┏━━『 🔴 LIVE SCORES 』━━", fmtLivescore(value257));
      await react(value253, value254, "✅");
    } catch (error258) {
      await react(value253, value254, "❌");
      value256.reply("❌ Failed: " + error258.message);
    }
  }
}, {
  name: "livehighlights",
  aliases: ["livescore2", "livehl"],
  category: "sports",
  description: "Get live scores with highlight stream links",
  usage: ".livehighlights",
  async execute(value259, value260, value261, value262) {
    await react(value259, value260, "⏳");
    try {
      const value263 = await keithApi("/livescore2");
      await sendLong(value259, value260, "┏━━『 🔴 LIVE SCORES + HIGHLIGHTS 』━━", fmtLivescore2(value263));
      await react(value259, value260, "✅");
    } catch (error264) {
      await react(value259, value260, "❌");
      value262.reply("❌ Failed: " + error264.message);
    }
  }
}, {
  name: "epl",
  aliases: ["premierleague", "pl"],
  category: "sports",
  description: "EPL — upcoming, matches, standings, scorers",
  usage: ".epl <upcoming|matches|standings|scorers>",
  async execute(value265, value266, value267, value268) {
    await leagueHandler(value265, value266, value267, value268, "⚽ Premier League", {
      upcoming: {
        endpoint: "/epl/upcomingmatches",
        format: fmtMatches,
        title: "Upcoming Matches"
      },
      matches: {
        endpoint: "/epl/matches",
        format: fmtMatches,
        title: "Matches"
      },
      standings: {
        endpoint: "/epl/standings",
        format: fmtStandings,
        title: "Standings"
      },
      scorers: {
        endpoint: "/epl/scorers",
        format: fmtScorers,
        title: "Top Scorers"
      }
    });
  }
}, {
  name: "bundesliga",
  aliases: ["bund", "germansoccer"],
  category: "sports",
  description: "Bundesliga — upcoming, matches, standings, scorers",
  usage: ".bundesliga <upcoming|matches|standings|scorers>",
  async execute(value269, value270, value271, value272) {
    await leagueHandler(value269, value270, value271, value272, "🇩🇪 Bundesliga", {
      upcoming: {
        endpoint: "/bundesliga/upcomingmatches",
        format: fmtMatches,
        title: "Upcoming Matches"
      },
      matches: {
        endpoint: "/bundesliga/matches",
        format: fmtMatches,
        title: "Matches"
      },
      standings: {
        endpoint: "/bundesliga/standings",
        format: fmtStandings,
        title: "Standings"
      },
      scorers: {
        endpoint: "/bundesliga/scorers",
        format: fmtScorers,
        title: "Top Scorers"
      }
    });
  }
}, {
  name: "euros",
  aliases: ["eurocup", "euro"],
  category: "sports",
  description: "Euros — upcoming, matches, standings, scorers",
  usage: ".euros <upcoming|matches|standings|scorers>",
  async execute(value273, value274, value275, value276) {
    await leagueHandler(value273, value274, value275, value276, "🏆 Euros", {
      upcoming: {
        endpoint: "/euros/upcomingmatches",
        format: fmtMatches,
        title: "Upcoming Matches"
      },
      matches: {
        endpoint: "/euros/matches",
        format: fmtMatches,
        title: "Matches"
      },
      standings: {
        endpoint: "/euros/standings",
        format: fmtStandings,
        title: "Standings"
      },
      scorers: {
        endpoint: "/euros/scorers",
        format: fmtScorers,
        title: "Top Scorers"
      }
    });
  }
}, {
  name: "laliga",
  aliases: ["ll", "spanishleague"],
  category: "sports",
  description: "La Liga — upcoming, matches, standings, scorers",
  usage: ".laliga <upcoming|matches|standings|scorers>",
  async execute(value277, value278, value279, value280) {
    await leagueHandler(value277, value278, value279, value280, "🇪🇸 La Liga", {
      upcoming: {
        endpoint: "/laliga/upcomingmatches",
        format: fmtMatches,
        title: "Upcoming Matches"
      },
      matches: {
        endpoint: "/laliga/matches",
        format: fmtMatches,
        title: "Matches"
      },
      standings: {
        endpoint: "/laliga/standings",
        format: fmtStandings,
        title: "Standings"
      },
      scorers: {
        endpoint: "/laliga/scorers",
        format: fmtScorers,
        title: "Top Scorers"
      }
    });
  }
}, {
  name: "ligue1",
  aliases: ["ligue", "frenchleague"],
  category: "sports",
  description: "Ligue 1 — upcoming, matches, standings, scorers",
  usage: ".ligue1 <upcoming|matches|standings|scorers>",
  async execute(value281, value282, value283, value284) {
    await leagueHandler(value281, value282, value283, value284, "🇫🇷 Ligue 1", {
      upcoming: {
        endpoint: "/ligue1/upcomingmatches",
        format: fmtMatches,
        title: "Upcoming Matches"
      },
      matches: {
        endpoint: "/ligue1/matches",
        format: fmtMatches,
        title: "Matches"
      },
      standings: {
        endpoint: "/ligue1/standings",
        format: fmtStandings,
        title: "Standings"
      },
      scorers: {
        endpoint: "/ligue1/scorers",
        format: fmtScorers,
        title: "Top Scorers"
      }
    });
  }
}, {
  name: "seriea",
  aliases: ["seria", "italianleague"],
  category: "sports",
  description: "Serie A — upcoming, matches, standings, scorers",
  usage: ".seriea <upcoming|matches|standings|scorers>",
  async execute(value285, value286, value287, value288) {
    await leagueHandler(value285, value286, value287, value288, "🇮🇹 Serie A", {
      upcoming: {
        endpoint: "/seriea/upcomingmatches",
        format: fmtMatches,
        title: "Upcoming Matches"
      },
      matches: {
        endpoint: "/seriea/matches",
        format: fmtMatches,
        title: "Matches"
      },
      standings: {
        endpoint: "/seriea/standings",
        format: fmtStandings,
        title: "Standings"
      },
      scorers: {
        endpoint: "/seriea/scorers",
        format: fmtScorers,
        title: "Top Scorers"
      }
    });
  }
}, {
  name: "ucl",
  aliases: ["championsleague", "cl"],
  category: "sports",
  description: "UCL Champions League — upcoming, matches, standings, scorers",
  usage: ".ucl <upcoming|matches|standings|scorers>",
  async execute(value289, value290, value291, value292) {
    await leagueHandler(value289, value290, value291, value292, "🏆 UCL Champions League", {
      upcoming: {
        endpoint: "/ucl/upcomingmatches",
        format: fmtMatches,
        title: "Upcoming Matches"
      },
      matches: {
        endpoint: "/ucl/matches",
        format: fmtMatches,
        title: "Matches"
      },
      standings: {
        endpoint: "/ucl/standings",
        format: fmtStandings,
        title: "Standings"
      },
      scorers: {
        endpoint: "/ucl/scorers",
        format: fmtScorers,
        title: "Top Scorers"
      }
    });
  }
}, {
  name: "bet",
  aliases: ["surebets", "bettips", "betodds"],
  category: "sports",
  description: "Get sure bet tips and free odds",
  usage: ".bet",
  async execute(value293, value294, value295, value296) {
    await react(value293, value294, "⏳");
    try {
      const value297 = await keithApi("/bet");
      await sendLong(value293, value294, "┏━━『 🎰 Sure Bet Tips & Free Odds 』━━", fmtBet(value297));
      await react(value293, value294, "✅");
    } catch (error298) {
      await react(value293, value294, "❌");
      value296.reply("❌ Failed: " + error298.message);
    }
  }
}, {
  name: "footballnews",
  aliases: ["fnews", "sportnews"],
  category: "sports",
  description: "Get latest football news",
  usage: ".footballnews",
  async execute(value299, value300, value301, value302) {
    await react(value299, value300, "⏳");
    try {
      const value303 = await keithApi("/football/news");
      await sendLong(value299, value300, "┏━━『 📰 Football News 』━━", fmtNews(value303));
      await react(value299, value300, "✅");
    } catch (error304) {
      await react(value299, value300, "❌");
      value302.reply("❌ Failed: " + error304.message);
    }
  }
}];
