const axios = require("axios");
const FormData = require("form-data");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const BASE = "https://apiskeith2-production-3679.up.railway.app";
const react = (value1, value2, value3) => value1.sendMessage(value2.key.remoteJid, {
  react: {
    text: value3,
    key: value2.key
  }
});
const send = (value4, value5, value6) => value4.sendMessage(value5.key.remoteJid, {
  text: value6
}, {
  quoted: value5
});
function cleanResult(value7) {
  if (value7 == null) {
    return "";
  }
  if (typeof value7 === "string") {
    return value7.trim();
  }
  if (typeof value7 === "number" || typeof value7 === "boolean") {
    return String(value7);
  }
  if (Array.isArray(value7)) {
    return value7.map(value8 => cleanResult(value8)).filter(Boolean).join("\n\n");
  }
  if (typeof value7 === "object") {
    const value9 = value7.text ?? value7.message ?? value7.response ?? value7.answer ?? value7.result ?? value7.output ?? value7.content ?? value7.reply ?? null;
    if (value9 != null) {
      return cleanResult(value9);
    }
    return Object.entries(value7).filter(([, value10]) => value10 != null && typeof value10 !== "object").map(([value11, value12]) => value11 + ": " + value12).join("\n") || JSON.stringify(value7);
  }
  return String(value7);
}
async function ravenn(value13, value14 = {}) {
  const {
    data: value15
  } = await axios.get(value13, {
    params: value14,
    timeout: 60000
  });
  if (!value15 || !value15.status) {
    throw new Error(value15?.err || value15?.error || "Service temporarily unavailable");
  }
  if (value15.result && typeof value15.result === "object" && value15.result.status === false) {
    throw new Error(value15.result.err || value15.result.error || "API error from upstream");
  }
  return value15.result;
}
async function ravennBinary(value16, value17 = {}) {
  const value18 = await axios.get(value16, {
    params: value17,
    responseType: "arraybuffer",
    timeout: 60000
  });
  const value19 = Buffer.from(value18.data);
  if (value19.length < 2048) {
    let value20 = null;
    try {
      value20 = JSON.parse(value19.toString("utf8"));
    } catch {}
    if (value20 && value20.status === false) {
      throw new Error(value20.err || value20.error || "API returned an error instead of an image");
    }
  }
  return value19;
}
async function uploadToUguu(value21, value22 = "image.jpg", value23 = "image/jpeg") {
  const value24 = new FormData();
  value24.append("files[]", value21, {
    filename: value22,
    contentType: value23
  });
  const {
    data: value25
  } = await axios.post("https://uguu.se/upload", value24, {
    headers: value24.getHeaders(),
    timeout: 30000
  });
  const value26 = Array.isArray(value25) ? value25[0] : Array.isArray(value25?.files) ? value25.files[0] : null;
  const value27 = value26?.url;
  if (!value27) {
    throw new Error("Failed to upload file to Uguu");
  }
  return value27;
}
function getContextInfo(value28) {
  const value29 = value28.message || {};
  return value29.extendedTextMessage?.contextInfo || value29.imageMessage?.contextInfo || value29.videoMessage?.contextInfo || value29.audioMessage?.contextInfo || value29.documentMessage?.contextInfo || null;
}
async function downloadQuoted(value30, value31, value32, value33) {
  const value34 = {
    key: {
      remoteJid: value31.key.remoteJid,
      id: value32.stanzaId,
      participant: value32.participant
    },
    message: value33
  };
  return downloadMediaMessage(value34, "buffer", {}, {
    logger: undefined,
    reuploadRequest: value30.updateMediaMessage
  });
}
async function resolveImageUrl(value35, value36, value37) {
  if (value37[0] && /^https?:\/\//i.test(value37[0])) {
    return {
      url: value37[0],
      remainingArgs: value37.slice(1)
    };
  }
  const value38 = getContextInfo(value36);
  const value39 = value38?.quotedMessage;
  const value40 = value39?.imageMessage || value39?.stickerMessage;
  if (!value40) {
    return {
      url: null,
      remainingArgs: value37
    };
  }
  const value41 = await downloadQuoted(value35, value36, value38, value39);
  if (!value41 || !value41.length) {
    throw new Error("Could not download image from the replied message");
  }
  const value42 = await uploadToUguu(value41);
  return {
    url: value42,
    remainingArgs: value37
  };
}
async function resolveAudioUrl(value43, value44, value45) {
  if (value45[0] && /^https?:\/\//i.test(value45[0])) {
    return {
      url: value45[0],
      remainingArgs: value45.slice(1)
    };
  }
  const value46 = getContextInfo(value44);
  const value47 = value46?.quotedMessage;
  const value48 = value47?.audioMessage;
  if (!value48) {
    return {
      url: null,
      remainingArgs: value45
    };
  }
  const value49 = await downloadQuoted(value43, value44, value46, value47);
  if (!value49 || !value49.length) {
    throw new Error("Could not download audio from the replied message");
  }
  const value50 = value48.mimetype || "audio/ogg";
  const value51 = value50.includes("mpeg") ? "mp3" : value50.includes("mp4") ? "m4a" : "ogg";
  const value52 = await uploadToUguu(value49, "audio." + value51, value50);
  return {
    url: value52,
    remainingArgs: value45
  };
}
function chatCommand({
  name: value53,
  aliases: value54,
  emoji: value55,
  label: value56,
  description: value57,
  usage: value58,
  example: value59,
  path: value60
}) {
  return {
    name: value53,
    aliases: value54,
    category: "ai",
    description: value57,
    usage: value58,
    apiUrl: "" + BASE + value60,
    async execute(value61, value62, value63, value64) {
      const value65 = value63.join(" ").trim();
      if (!value65) {
        return value64.reply("❌ Please provide a question\n\nExample: " + value59);
      }
      await react(value61, value62, value55);
      try {
        const value66 = await ravenn(this.apiUrl, {
          q: value65
        });
        const value67 = cleanResult(value66);
        if (!value67) {
          throw new Error("Empty response from the AI");
        }
        await send(value61, value62, value55 + " *" + value56 + "*\n\n" + value67);
        await react(value61, value62, "✅");
      } catch (error68) {
        console.error("[" + value53 + "]", error68.message);
        await react(value61, value62, "❌");
        value64.reply("❌ " + value56 + " error: " + error68.message);
      }
    }
  };
}
module.exports = [chatCommand({
  name: "ai",
  aliases: ["keithai", "supremeai"],
  emoji: "⚡",
  label: "Keith AI",
  description: "Ask Keith AI (custom model) a question",
  usage: ".ai <question>",
  example: ".ai How does the internet work?",
  path: "/keithai"
}), chatCommand({
  name: "chatgpt",
  aliases: ["gpt", "gpt2", "gptai"],
  emoji: "🤖",
  label: "ChatGPT",
  description: "Ask GPT AI a question",
  usage: ".chatgpt <question>",
  example: ".chatgpt What is JavaScript?",
  path: "/ai/gpt"
}), chatCommand({
  name: "gpt4o",
  aliases: ["gpt4", "chatgpt4", "gpt4nano", "gpt41nano"],
  emoji: "🤖",
  label: "GPT-4",
  description: "Ask GPT-4 a question",
  usage: ".gpt4o <question>",
  example: ".gpt4o How does a black hole form?",
  path: "/ai/chatgpt4"
}), chatCommand({
  name: "claude",
  aliases: ["claudeai"],
  emoji: "🧠",
  label: "Claude AI",
  description: "Ask Claude AI a question",
  usage: ".claude <question>",
  example: ".claude Explain recursion",
  path: "/ai/claudeai"
}), chatCommand({
  name: "gemini",
  aliases: ["geminai"],
  emoji: "♊",
  label: "Google Gemini",
  description: "Ask Google Gemini a question",
  usage: ".gemini <question>",
  example: ".gemini Explain quantum physics",
  path: "/ai/gemini"
}), chatCommand({
  name: "mistral",
  aliases: ["mistralai"],
  emoji: "🔍",
  label: "Mistral AI",
  description: "Ask Mistral AI a question",
  usage: ".mistral <question>",
  example: ".mistral What is machine learning?",
  path: "/ai/mistral"
}), chatCommand({
  name: "copilot",
  aliases: ["microsoftai"],
  emoji: "🪟",
  label: "Microsoft Copilot",
  description: "Ask Microsoft Copilot a question",
  usage: ".copilot <question>",
  example: ".copilot How are you?",
  path: "/ai/copilot"
}), chatCommand({
  name: "metaai",
  aliases: ["meta", "metalai"],
  emoji: "💭",
  label: "Meta AI",
  description: "Ask Meta AI a question",
  usage: ".metaai <question>",
  example: ".metaai Hello, how are you?",
  path: "/ai/metai"
}), chatCommand({
  name: "aiLlama",
  aliases: ["llama", "llamaai", "ilama"],
  emoji: "🦙",
  label: "Llama AI",
  description: "Ask Llama AI a question",
  usage: ".llama <question>",
  example: ".llama What is deep learning?",
  path: "/ai/ilama"
}), chatCommand({
  name: "blackbox",
  aliases: ["bb", "blackboxai"],
  emoji: "📦",
  label: "Blackbox AI",
  description: "Ask Blackbox AI a question",
  usage: ".blackbox <question>",
  example: ".blackbox Explain recursion",
  path: "/ai/blackbox"
}), chatCommand({
  name: "bard",
  aliases: ["googlebard"],
  emoji: "✨",
  label: "Google Bard",
  description: "Ask Google Bard a question",
  usage: ".bard <question>",
  example: ".bard Explain black holes",
  path: "/ai/bard"
}), chatCommand({
  name: "perplexity",
  aliases: ["perplexai"],
  emoji: "🔎",
  label: "Perplexity AI",
  description: "Ask Perplexity AI a question",
  usage: ".perplexity <question>",
  example: ".perplexity What is quantum computing?",
  path: "/ai/perplexity"
}), chatCommand({
  name: "venice",
  aliases: ["vai", "veniceai"],
  emoji: "🌊",
  label: "Venice AI",
  description: "Ask Venice AI a question",
  usage: ".venice <question>",
  example: ".venice What is life?",
  path: "/ai/venice"
}), chatCommand({
  name: "o3",
  aliases: ["o3ai", "openai03"],
  emoji: "🔵",
  label: "O3 AI",
  description: "Ask O3 AI a question",
  usage: ".o3 <question>",
  example: ".o3 What is consciousness?",
  path: "/ai/o3"
})];
module.exports.helpers = {
  ravenn: ravenn,
  ravennBinary: ravennBinary,
  resolveImageUrl: resolveImageUrl,
  resolveAudioUrl: resolveAudioUrl,
  uploadToUguu: uploadToUguu,
  cleanResult: cleanResult,
  react: react,
  send: send
};
