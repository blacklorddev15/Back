const axios = require("axios");
const database = require("../../database");
module.exports = {
  name: "lyrics",
  aliases: ["lyric", "lirik"],
  category: "media",
  description: "Get lyrics of a song",
  usage: "<song name>",
  async execute(value1, value2, value3) {
    const value4 = value2.key.remoteJid;
    if (value3.length === 0) {
      return await value1.sendMessage(value4, {
        text: "❌ Please provide a song name!\n\nExample: " + database.getBotSetting("prefix") + "lyrics Despacito"
      });
    }
    const value5 = value3.join(" ");
    try {
      const value6 = await axios.get("https://apiskeith2-production-3020.up.railway.app/search/lyrics?query=" + encodeURIComponent(value5), {
        timeout: 15000
      });
      if (!value6.data?.status || !Array.isArray(value6.data?.result) || value6.data.result.length === 0) {
        return await value1.sendMessage(value4, {
          text: "❌ Could not find lyrics for that song. Try a different song name or spelling."
        });
      }
      const value7 = value6.data.result[0];
      let value8 = value7.lyrics || "No lyrics found.";
      if (value8.length > 4000) {
        value8 = value8.substring(0, 4000) + "...\n\n_Lyrics truncated — showing first part only_";
      }
      const value9 = "🎵 *" + (value7.song || "Unknown Title") + "*\n" + ("👤 *Artist:* " + (value7.artist || "Unknown Artist") + "\n\n") + ("📝 *Lyrics:*\n" + value8 + "\n\n") + ("_Fetched by " + database.getBotSetting("botName") + "_");
      if (value7.thumbnail) {
        await value1.sendMessage(value4, {
          image: {
            url: value7.thumbnail
          },
          caption: value9
        }, {
          quoted: value2
        });
      } else {
        await value1.sendMessage(value4, {
          text: value9
        }, {
          quoted: value2
        });
      }
    } catch (error10) {
      console.error("Lyrics command error:", error10);
      await value1.sendMessage(value4, {
        text: "❌ An error occurred while fetching lyrics!"
      });
    }
  }
};
