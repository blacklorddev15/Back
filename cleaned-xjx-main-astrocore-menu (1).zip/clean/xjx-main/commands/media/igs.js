const {
  igdl
} = require("ruhend-scraper");
const axios = require("axios");
const {
  exec
} = require("child_process");
const ffmpegPath = require("../../utils/ffmpegPath");
const fs = require("fs");
const path = require("path");
const webp = require("node-webpmux");
const crypto = require("crypto");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const database = require("../../database");
function extractUniqueMedia(value1) {
  const value2 = [];
  const value3 = new Set();
  for (const value4 of value1) {
    if (!value4.url) {
      continue;
    }
    if (!value3.has(value4.url)) {
      value3.add(value4.url);
      value2.push(value4);
    }
  }
  return value2;
}
function extractInstagramUrl(value5) {
  try {
    const value6 = new URL(value5);
    const value7 = value6.searchParams.get("token");
    if (!value7) {
      return null;
    }
    const value8 = value7.split(".");
    if (value8.length < 2) {
      return null;
    }
    const value9 = JSON.parse(Buffer.from(value8[1].replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
    if (value9.url && typeof value9.url === "string" && value9.url.startsWith("http")) {
      return value9.url;
    }
  } catch (error10) {}
  return null;
}
function pickMediaUrl(value11) {
  if (!value11) {
    return null;
  }
  const value12 = [value11.downloadUrl, value11.url, value11.original, value11.mediaUrl, value11.videoUrl, value11.imageUrl, value11.urls?.[0]];
  for (const value13 of value12) {
    if (value13 && typeof value13 === "string" && value13.startsWith("http")) {
      if (value13.includes("rapidcdn.app") && value13.includes("token=")) {
        const value14 = extractInstagramUrl(value13);
        if (value14) {
          return value14;
        }
      }
      return value13;
    }
  }
  return null;
}
const MAX_INPUT_SIZE = 52428800;
const MAX_DURATION_SECONDS = 300;
const TARGET_SIZE = 1024;
async function convertBufferToStickerWebp(value15, value16, value17) {
  if (value15.length > MAX_INPUT_SIZE) {
    throw new Error("File too large: " + (value15.length / 1024 / 1024).toFixed(2) + "MB (max: " + MAX_INPUT_SIZE / 1024 / 1024 + "MB)");
  }
  const value18 = getTempDir();
  const value19 = path.join(value18, "igs_" + Date.now() + "_" + Math.random().toString(36).slice(2));
  const value20 = value16 ? value19 + ".mp4" : value19 + ".jpg";
  const value21 = path.join(value18, "igs_out_" + Date.now() + "_" + Math.random().toString(36).slice(2) + ".webp");
  const value22 = [value20, value21];
  try {
    fs.writeFileSync(value20, value15);
    const value23 = TARGET_SIZE;
    const value24 = "crop=min(iw\\,ih):min(iw\\,ih),scale=" + value23 + ":" + value23;
    const value25 = "scale=" + value23 + ":" + value23 + ":force_original_aspect_ratio=decrease,pad=" + value23 + ":" + value23 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000";
    let value26;
    if (value16) {
      const value27 = value15.length > 3145728;
      if (value17) {
        value26 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -t 2 -vf \"crop=min(iw\\,ih):min(iw\\,ih),scale=" + value23 + ":" + value23 + ",fps=6\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 30 -compression_level 6 -b:v 80k -max_muxing_queue_size 1024 \"" + value21 + "\"";
      } else {
        value26 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -t 2 -vf \"scale=" + value23 + ":" + value23 + ":force_original_aspect_ratio=decrease,pad=" + value23 + ":" + value23 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000,fps=6\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 30 -compression_level 6 -b:v 80k -max_muxing_queue_size 1024 \"" + value21 + "\"";
      }
    } else {
      const value28 = (value17 ? value24 : value25) + ",format=rgba";
      value26 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -vf \"" + value28 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 70 -compression_level 6 \"" + value21 + "\"";
    }
    await new Promise((value29, value30) => {
      exec(value26, (value31, value32, value33) => {
        if (value31) {
          return value30(value31);
        }
        value29();
      });
    });
    let value34 = fs.readFileSync(value21);
    let value35 = 0;
    const value36 = 10;
    let value37 = TARGET_SIZE;
    while (value34.length > 972800 && value35 < value36) {
      value35++;
      value37 = Math.floor(value37 * 0.8);
      if (value37 < 128) {
        value37 = 128;
      }
      try {
        const value38 = path.join(value18, "igs_out" + value35 + "_" + Date.now() + "_" + Math.random().toString(36).slice(2) + ".webp");
        value22.push(value38);
        let value39;
        if (value16) {
          const value40 = Math.max(3, 6 - Math.floor(value35 / 2));
          const value41 = Math.max(10, 30 - value35 * 2);
          const value42 = Math.max(30, 80 - value35 * 5);
          const value43 = Math.max(1, 2 - value35 * 0.2);
          if (value17) {
            value39 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -t " + value43 + " -vf \"crop=min(iw\\,ih):min(iw\\,ih),scale=" + value37 + ":" + value37 + ",fps=" + value40 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality " + value41 + " -compression_level 6 -b:v " + value42 + "k -max_muxing_queue_size 1024 \"" + value38 + "\"";
          } else {
            value39 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -t " + value43 + " -vf \"scale=" + value37 + ":" + value37 + ":force_original_aspect_ratio=decrease,pad=" + value37 + ":" + value37 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000,fps=" + value40 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality " + value41 + " -compression_level 6 -b:v " + value42 + "k -max_muxing_queue_size 1024 \"" + value38 + "\"";
          }
        } else {
          const value44 = Math.max(30, 70 - value35 * 5);
          const value45 = value17 ? "crop=min(iw\\,ih):min(iw\\,ih),scale=" + value37 + ":" + value37 + ",format=rgba" : "scale=" + value37 + ":" + value37 + ":force_original_aspect_ratio=decrease,pad=" + value37 + ":" + value37 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000,format=rgba";
          value39 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -vf \"" + value45 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality " + value44 + " -compression_level 6 \"" + value38 + "\"";
        }
        await new Promise((value46, value47) => {
          exec(value39, value48 => value48 ? value47(value48) : value46());
        });
        if (fs.existsSync(value38)) {
          const value49 = fs.readFileSync(value38);
          value34 = value49;
        }
      } catch (error50) {
        if (value35 >= value36) {
          break;
        }
      }
    }
    const value51 = new webp.Image();
    await value51.load(value34);
    const value52 = {
      "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
      "sticker-pack-name": database.getBotSetting("packname") || "Made by",
      emojis: ["📸"]
    };
    const value53 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
    const value54 = Buffer.from(JSON.stringify(value52), "utf8");
    const value55 = Buffer.concat([value53, value54]);
    value55.writeUIntLE(value54.length, 14, 4);
    value51.exif = value55;
    let value56 = await value51.save(null);
    if (value56.length > 972800) {
      const value57 = await forceMiniSticker(value15, value16, value17);
      if (value57) {
        value56 = value57;
      }
    }
    return value56;
  } finally {
    value22.forEach(value58 => deleteTempFile(value58));
  }
}
async function fetchBufferFromUrl(value59, value60 = 0) {
  const value61 = 3;
  const value62 = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    Accept: "*/*",
    "Cache-Control": "no-cache, no-store, must-revalidate",
    Pragma: "no-cache",
    Expires: "0"
  };
  const value63 = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Referer: "https://www.instagram.com/",
    Origin: "https://www.instagram.com",
    Accept: "image/avif,image/webp,image/*,*/*;q=0.8",
    "Cache-Control": "no-cache, no-store, must-revalidate",
    Pragma: "no-cache",
    Expires: "0"
  };
  function handler64(value65) {
    if (!value65 || value65.length < 10) {
      return false;
    }
    const value66 = value65.toString("utf8", 0, 100).toLowerCase().trim();
    return value66.startsWith("<!doctype html") || value66.startsWith("<html");
  }
  function handler67(value68) {
    if (!value68) {
      return true;
    }
    const value69 = value68.toLowerCase();
    return value69.startsWith("image/") || value69.startsWith("video/") || value69 === "application/octet-stream";
  }
  let value70;
  for (let value71 = 0; value71 < value61; value71++) {
    try {
      const value72 = value71 === 0 ? value62 : value63;
      const value73 = {
        responseType: "arraybuffer",
        headers: value72,
        timeout: 30000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        decompress: true,
        maxRedirects: 5,
        validateStatus: value74 => value74 >= 200 && value74 < 300
      };
      const value75 = await axios.get(value59, value73);
      const value76 = Buffer.from(value75.data);
      const value77 = value75.headers["content-type"];
      if (!handler67(value77)) {
        throw new Error("Invalid content-type: " + value77 + " (expected image/* or video/*)");
      }
      if (handler64(value76)) {
        throw new Error("Response is HTML (blocked/login required)");
      }
      return value76;
    } catch (error78) {
      value70 = error78;
      if (value71 === value61 - 1) {
        try {
          const value79 = value63;
          const value80 = await axios.get(value59, {
            responseType: "stream",
            headers: value79,
            timeout: 40000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
            maxRedirects: 5,
            validateStatus: value81 => value81 >= 200 && value81 < 300
          });
          const value82 = [];
          await new Promise((value83, value84) => {
            value80.data.on("data", value85 => value82.push(value85));
            value80.data.on("end", value83);
            value80.data.on("error", value84);
          });
          const value86 = Buffer.concat(value82);
          const value87 = value80.headers["content-type"];
          if (!handler67(value87)) {
            throw new Error("Invalid content-type: " + value87);
          }
          if (handler64(value86)) {
            throw new Error("Stream response is HTML (blocked/login required)");
          }
          return value86;
        } catch (error88) {
          throw new Error("Failed to download media after " + value61 + " attempts: " + (value70?.message || value70));
        }
      }
      if (value71 < value61 - 1) {
        await new Promise(value89 => setTimeout(value89, (value71 + 1) * 500));
      }
    }
  }
  throw new Error("Failed to download media after " + value61 + " attempts: " + (value70?.message || value70));
}
async function forceMiniSticker(value90, value91, value92) {
  const value93 = getTempDir();
  const value94 = [];
  try {
    const value95 = [512, 400, 320, 256, 200, 180, 160];
    for (const value96 of value95) {
      const value97 = path.join(value93, "mini_" + value96 + "_" + Date.now() + "." + (value91 ? "mp4" : "jpg"));
      const value98 = path.join(value93, "mini_out_" + value96 + "_" + Date.now() + ".webp");
      value94.push(value97, value98);
      try {
        fs.writeFileSync(value97, value90);
        const value99 = value92 ? "crop=min(iw\\,ih):min(iw\\,ih),scale=" + value96 + ":" + value96 + (value91 ? ",fps=3" : "") : "scale=" + value96 + ":" + value96 + ":force_original_aspect_ratio=decrease,pad=" + value96 + ":" + value96 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000" + (value91 ? ",fps=3" : "");
        const value100 = "\"" + ffmpegPath() + "\" -y -i \"" + value97 + "\" " + (value91 ? "-t 0.5" : "") + " -vf \"" + value99 + "\" -c:v libwebp -preset default -loop 0 -pix_fmt yuva420p -quality " + (value91 ? 15 : 30) + " -compression_level 6 -b:v 30k \"" + value98 + "\"";
        await new Promise((value101, value102) => {
          exec(value100, value103 => value103 ? value102(value103) : value101());
        });
        if (fs.existsSync(value98)) {
          const value104 = fs.readFileSync(value98);
          if (value104.length <= 972800) {
            const value105 = new webp.Image();
            await value105.load(value104);
            const value106 = {
              "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
              "sticker-pack-name": database.getBotSetting("packname") || "Made by",
              emojis: ["📸"]
            };
            const value107 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
            const value108 = Buffer.from(JSON.stringify(value106), "utf8");
            const value109 = Buffer.concat([value107, value108]);
            value109.writeUIntLE(value108.length, 14, 4);
            value105.exif = value109;
            const value110 = await value105.save(null);
            return value110;
          }
        }
      } catch (error111) {}
    }
    return null;
  } finally {
    value94.forEach(value112 => deleteTempFile(value112));
  }
}
async function igsCommand(value113, value114, value115, value116, value117 = false) {
  try {
    const value118 = value114.message?.conversation || value114.message?.extendedTextMessage?.text || value115.join(" ");
    const value119 = value118.match(/https?:\/\/\S+/);
    if (!value119) {
      return value116.reply("Send an Instagram post/reel link.\nUsage:\n.igs <url>\n.igsc <url>");
    }
    await value113.sendMessage(value116.from, {
      react: {
        text: "📥",
        key: value114.key
      }
    });
    const value120 = await igdl(value119[0]).catch(() => null);
    if (!value120 || !value120.data) {
      return value116.reply("❌ Failed to fetch media from Instagram link.");
    }
    const value121 = value120.data || [];
    const value122 = value121.filter(value123 => value123 && pickMediaUrl(value123));
    const value124 = value122.slice(0, 10);
    if (value124.length === 0) {
      return value116.reply("❌ No media found at the provided link.");
    }
    const value125 = value124.length;
    let value126 = 0;
    let value127 = 0;
    let value128 = 0;
    const value129 = new Set();
    for (let value130 = 0; value130 < value125; value130++) {
      try {
        const value131 = value124[value130];
        const value132 = pickMediaUrl(value131);
        if (!value132) {
          value128++;
          continue;
        }
        const value133 = value131?.type === "video" || /\.(mp4|mov|avi|mkv|webm)$/i.test(value132);
        const value134 = await fetchBufferFromUrl(value132, value130);
        const value135 = crypto.createHash("md5").update(value134).digest("hex");
        if (value129.has(value135)) {
          value128++;
          continue;
        }
        value129.add(value135);
        let value136 = await convertBufferToStickerWebp(value134, value133, value117);
        let value137 = value136;
        if (value137.length > 972800) {
          try {
            const value138 = await forceMiniSticker(value134, value133, value117);
            if (value138) {
              value137 = value138;
            }
          } catch (error139) {}
        }
        if (value137.length > 972800) {
          const value140 = getTempDir();
          const value141 = path.join(value140, "ultra_" + Date.now() + "_" + value130 + "." + (value133 ? "mp4" : "jpg"));
          const value142 = path.join(value140, "ultra_out_" + Date.now() + "_" + value130 + ".webp");
          const value143 = [value141, value142];
          try {
            fs.writeFileSync(value141, value134);
            const value144 = 180;
            const value145 = value117 ? "crop=min(iw\\,ih):min(iw\\,ih),scale=" + value144 + ":" + value144 + (value133 ? ",fps=3" : "") : "scale=" + value144 + ":" + value144 + ":force_original_aspect_ratio=decrease,pad=" + value144 + ":" + value144 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000" + (value133 ? ",fps=3" : "");
            const value146 = "\"" + ffmpegPath() + "\" -y -i \"" + value141 + "\" " + (value133 ? "-t 0.5" : "") + " -vf \"" + value145 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality " + (value133 ? 12 : 25) + " -compression_level 6 -b:v 25k -max_muxing_queue_size 1024 \"" + value142 + "\"";
            await new Promise((value147, value148) => {
              exec(value146, value149 => value149 ? value148(value149) : value147());
            });
            if (fs.existsSync(value142)) {
              const value150 = fs.readFileSync(value142);
              const value151 = new webp.Image();
              await value151.load(value150);
              const value152 = {
                "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
                "sticker-pack-name": database.getBotSetting("packname") || "Made by",
                emojis: ["📸"]
              };
              const value153 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
              const value154 = Buffer.from(JSON.stringify(value152), "utf8");
              const value155 = Buffer.concat([value153, value154]);
              value155.writeUIntLE(value154.length, 14, 4);
              value151.exif = value155;
              value137 = await value151.save(null);
            }
          } catch (error156) {} finally {
            value143.forEach(value157 => deleteTempFile(value157));
          }
        }
        try {
          await value113.sendMessage(value116.from, {
            sticker: value137
          }, {
            quoted: value114
          });
          value126++;
        } catch (error158) {
          value127++;
        }
        if (value130 < value125 - 1) {
          await new Promise(value159 => setTimeout(value159, 800));
        }
      } catch (error160) {
        value127++;
      }
    }
    if (value125 > 1) {
      const value161 = "✅ Stickers: " + value126 + " sent | ❌ Failed: " + value127 + " | ⏭️ Skipped: " + value128;
      await value116.reply(value161);
    }
  } catch (error162) {
    console.error("Error in igs command:", error162);
    await value116.reply("❌ Failed to create sticker from Instagram link.");
  }
}
module.exports = {
  name: "igs",
  aliases: ["igsticker"],
  description: "Convert Instagram post/reel to sticker (maintains aspect ratio with padding) – now produces larger stickers up to 1024×1024!",
  usage: ".igs <Instagram URL>",
  category: "media",
  async execute(value163, value164, value165, value166) {
    await igsCommand(value163, value164, value165, value166, false);
  }
};
