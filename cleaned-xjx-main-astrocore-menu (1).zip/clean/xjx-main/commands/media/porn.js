const database = require("../../database");
const {
  getInput,
  isHttpUrl,
  safeFileName,
  downloadVideoBuffer,
  fetchXvideos,
  fetchXhamster,
  searchXvideos
} = require("./adultVideoHelpers");
function detectSite(value1) {
  if (/xvideos\.com/i.test(value1)) {
    return "xvideos";
  }
  if (/xhamster\.(com|desi)/i.test(value1)) {
    return "xhamster";
  }
  return null;
}
module.exports = {
  name: "porn",
  aliases: ["pornhub", "porno", "adultvid", "18plus"],
  category: "media",
  description: "Download adult videos by name or supported URL",
  usage: (database.getBotSetting("prefix") || ".") + "porn <name or URL>",
  async execute(value2, value3, value4, value5 = {}) {
    const value6 = value3.key.remoteJid;
    const value7 = getInput(value3, value4);
    if (!value7) {
      return value2.sendMessage(value6, {
        text: "Usage: " + (value5.prefix || database.getBotSetting("prefix") || ".") + "porn <name or URL>\nSupports XVideos and XHamster."
      }, {
        quoted: value3
      });
    }
    try {
      let value8;
      if (isHttpUrl(value7)) {
        const value9 = detectSite(value7);
        if (!value9) {
          return value2.sendMessage(value6, {
            text: "Unsupported URL. Use an XVideos or XHamster URL."
          }, {
            quoted: value3
          });
        }
        value8 = value9 === "xvideos" ? await fetchXvideos(value7) : await fetchXhamster(value7);
      } else {
        const value10 = await searchXvideos(value7);
        value8 = value10?.url ? await fetchXvideos(value10.url) : null;
      }
      if (!value8?.downloadUrl) {
        return value2.sendMessage(value6, {
          text: "No video was found. Try a different name or direct URL."
        }, {
          quoted: value3
        });
      }
      const value11 = await downloadVideoBuffer(value8.downloadUrl);
      const value12 = [value8.title || "Adult video", value8.duration].filter(Boolean).join("\n");
      await value2.sendMessage(value6, {
        video: value11,
        caption: value12 + "\n" + (database.getBotSetting("botName") || "JuneX-Ultra"),
        mimetype: "video/mp4",
        fileName: safeFileName(value8.title, "adult-video")
      }, {
        quoted: value3
      });
    } catch (error13) {
      console.error("[PORN] Download error:", error13);
      await value2.sendMessage(value6, {
        text: "Download failed: " + (error13.message || "Unknown error")
      }, {
        quoted: value3
      });
    }
  }
};
