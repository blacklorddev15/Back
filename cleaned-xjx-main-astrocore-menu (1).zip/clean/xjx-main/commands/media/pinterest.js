const axios = require("axios");
const database = require("../../database");
const processedMessages = new Set();
module.exports = {
  name: "pinterest",
  aliases: ["pindl", "pinterestdl"],
  category: "media",
  description: "Download images/videos from Pinterest",
  usage: ".pinterest <Pinterest URL>",
  async execute(value1, value2, value3, value4) {
    try {
      if (processedMessages.has(value2.key.id)) {
        return;
      }
      processedMessages.add(value2.key.id);
      setTimeout(() => {
        processedMessages.delete(value2.key.id);
      }, 300000);
      const value5 = value2.message?.conversation || value2.message?.extendedTextMessage?.text || value3.join(" ");
      if (!value5) {
        return await value4.reply("📌 *Pinterest Downloader*\n\nDownload images or videos from Pinterest.\n\n" + ("Usage: " + database.getBotSetting("prefix") + "pinterest <Pinterest URL>\n\n") + "Example:\n" + (database.getBotSetting("prefix") + "pinterest https://in.pinterest.com/pin/1109363320773690068/"));
      }
      let value6 = value5.match(/https?:\/\/[^\s]*pinterest[^\s]*\/pin\/[^\s]+/i);
      if (!value6) {
        value6 = value5.match(/https?:\/\/pin\.it\/[^\s]+/i);
      }
      if (!value6) {
        value6 = value5.match(/pin\.it\/[^\s]+/i);
      }
      if (!value6) {
        return await value4.reply("❌ Please provide a valid Pinterest pin URL!\n\nExamples:\n• https://in.pinterest.com/pin/1109363320773690068/\n• https://pin.it/dddddd\n• pin.it/dddddd");
      }
      const value7 = value6[0];
      await value1.sendMessage(value4.from, {
        react: {
          text: "📥",
          key: value2.key
        }
      });
      const value8 = "https://api.nexray.web.id/downloader/pinterest?url=" + encodeURIComponent(value7);
      let value9;
      try {
        value9 = await axios.get(value8, {
          timeout: 30000,
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
          }
        });
      } catch (error10) {
        console.error("Pinterest API Error:", error10);
        if (error10.response) {
          const value11 = error10.response.status;
          if (value11 === 400) {
            return await value4.reply("❌ Bad Request: Invalid Pinterest URL. Please check the link.");
          } else if (value11 === 429) {
            return await value4.reply("❌ Rate limit exceeded. Please try again later.");
          } else if (value11 === 500) {
            return await value4.reply("❌ Server error. Please try again later.");
          }
        }
        return await value4.reply("❌ Failed to fetch Pinterest content. Please try again.");
      }
      if (!value9.data || !value9.data.status || !value9.data.result) {
        return await value4.reply("❌ Invalid response from API. The pin might not exist or be private.");
      }
      const value12 = value9.data.result;
      console.log("Pinterest API Response:", JSON.stringify(value12, null, 2));
      const value13 = !!value12.video;
      const value14 = value12.video || value12.image || value12.url;
      const value15 = value12.thumbnail;
      const value16 = value12.title || "Pinterest Pin";
      const value17 = value12.author || "Unknown";
      console.log("Media URL found:", value14);
      console.log("Is video check:", {
        hasVideoField: !!value12.video,
        hasImageField: !!value12.image,
        isVideo: value13,
        url: value14
      });
      if (!value14) {
        console.error("Pinterest API response structure:", JSON.stringify(value12, null, 2));
        return await value4.reply("❌ No media URL found in API response. The pin might be a video or have a different format.");
      }
      let value18 = "📌 *" + value16 + "*\n\n";
      if (value17 && value17 !== "Unknown") {
        value18 += "👤 Author: " + value17 + "\n";
      }
      value18 += "\n*Downloaded by " + database.getBotSetting("botName") + "*";
      if (value13) {
        try {
          const value19 = await axios.get(value14, {
            responseType: "arraybuffer",
            timeout: 120000,
            maxContentLength: 104857600,
            headers: {
              "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
              Accept: "video/mp4,video/*,*/*",
              Referer: "https://www.pinterest.com/"
            }
          });
          const value20 = Buffer.from(value19.data);
          if (!value20 || value20.length === 0) {
            throw new Error("Empty video buffer");
          }
          if (value20.length < 100) {
            throw new Error("Video buffer too small, likely corrupted");
          }
          console.log("Video downloaded successfully: " + (value20.length / 1024 / 1024).toFixed(2) + "MB");
          await value1.sendMessage(value4.from, {
            video: value20,
            caption: value18
          }, {
            quoted: value2
          });
        } catch (error21) {
          console.error("Video download/send error:", error21.message);
          return await value4.reply("❌ Failed to download or send video. The video might be expired or require authentication.");
        }
      } else {
        await value1.sendMessage(value4.from, {
          image: {
            url: value14
          },
          caption: value18
        }, {
          quoted: value2
        });
      }
    } catch (error22) {
      console.error("Error in pinterest command:", error22);
      return await value4.reply("❌ Error: " + (error22.message || "Unknown error occurred"));
    }
  }
};
