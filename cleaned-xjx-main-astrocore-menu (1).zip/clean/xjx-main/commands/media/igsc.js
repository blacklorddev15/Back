const {
  igdl
} = require("ruhend-scraper");
const axios = require("axios");
const {
  exec
} = require("child_process");
const ffmpegPath = require("../../utils/ffmpegPath");
const fs = require("fs");
const path = require("path");
const webp = require("node-webpmux");
const crypto = require("crypto");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const database = require("../../database");
function extractUniqueMedia(value1) {
  const value2 = [];
  const value3 = new Set();
  for (const value4 of value1) {
    if (!value4.url) {
      continue;
    }
    if (!value3.has(value4.url)) {
      value3.add(value4.url);
      value2.push(value4);
    }
  }
  return value2;
}
function extractInstagramUrl(value5) {
  try {
    const value6 = new URL(value5);
    const value7 = value6.searchParams.get("token");
    if (!value7) {
      return null;
    }
    const value8 = value7.split(".");
    if (value8.length < 2) {
      return null;
    }
    const value9 = JSON.parse(Buffer.from(value8[1].replace(/-/g, "+").replace(/_/g, "/"), "base64").toString());
    if (value9.url && typeof value9.url === "string" && value9.url.startsWith("http")) {
      return value9.url;
    }
  } catch (error10) {}
  return null;
}
function pickMediaUrl(value11) {
  if (!value11) {
    return null;
  }
  const value12 = [value11.downloadUrl, value11.url, value11.original, value11.mediaUrl, value11.videoUrl, value11.imageUrl, value11.urls?.[0]];
  for (const value13 of value12) {
    if (value13 && typeof value13 === "string" && value13.startsWith("http")) {
      if (value13.includes("rapidcdn.app") && value13.includes("token=")) {
        const value14 = extractInstagramUrl(value13);
        if (value14) {
          return value14;
        }
      }
      return value13;
    }
  }
  return null;
}
const MAX_FILE_SIZE = 52428800;
const MAX_DURATION_SECONDS = 300;
async function convertBufferToStickerWebp(value15, value16, value17) {
  if (value15.length > MAX_FILE_SIZE) {
    throw new Error("File too large: " + (value15.length / 1024 / 1024).toFixed(2) + "MB (max: " + MAX_FILE_SIZE / 1024 / 1024 + "MB)");
  }
  const value18 = getTempDir();
  const value19 = path.join(value18, "igs_" + Date.now() + "_" + Math.random().toString(36).slice(2));
  const value20 = value16 ? value19 + ".mp4" : value19 + ".jpg";
  const value21 = path.join(value18, "igs_out_" + Date.now() + "_" + Math.random().toString(36).slice(2) + ".webp");
  const value22 = [value20, value21];
  try {
    fs.writeFileSync(value20, value15);
    const value23 = "crop=min(iw\\,ih):min(iw\\,ih),scale=512:512";
    const value24 = "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000";
    let value25;
    if (value16) {
      const value26 = value15.length > 3145728;
      if (value17) {
        value25 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -t 2 -vf \"crop=min(iw\\,ih):min(iw\\,ih),scale=512:512,fps=6\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 25 -compression_level 6 -b:v 60k -max_muxing_queue_size 1024 \"" + value21 + "\"";
      } else {
        value25 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -t 2 -vf \"scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000,fps=6\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 25 -compression_level 6 -b:v 60k -max_muxing_queue_size 1024 \"" + value21 + "\"";
      }
    } else {
      const value27 = (value17 ? value23 : value24) + ",format=rgba";
      value25 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -vf \"" + value27 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 60 -compression_level 6 \"" + value21 + "\"";
    }
    await new Promise((value28, value29) => {
      exec(value25, (value30, value31, value32) => {
        if (value30) {
          return value29(value30);
        }
        value28();
      });
    });
    let value33 = fs.readFileSync(value21);
    let value34 = 0;
    const value35 = 8;
    while (value33.length > 972800 && value34 < value35) {
      value34++;
      try {
        const value36 = path.join(value18, "igs_out" + value34 + "_" + Date.now() + "_" + Math.random().toString(36).slice(2) + ".webp");
        value22.push(value36);
        let value37;
        if (value16) {
          const value38 = Math.max(3, 6 - value34);
          const value39 = Math.max(10, 25 - value34 * 3);
          const value40 = Math.max(30, 60 - value34 * 5);
          const value41 = Math.max(0.5, 2 - value34 * 0.25);
          const value42 = value34 <= 2 ? 512 : value34 <= 4 ? 400 : value34 <= 6 ? 320 : 256;
          if (value17) {
            value37 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -t " + value41 + " -vf \"crop=min(iw\\,ih):min(iw\\,ih),scale=" + value42 + ":" + value42 + ",fps=" + value38 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality " + value39 + " -compression_level 6 -b:v " + value40 + "k -max_muxing_queue_size 1024 \"" + value36 + "\"";
          } else {
            value37 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -t " + value41 + " -vf \"scale=" + value42 + ":" + value42 + ":force_original_aspect_ratio=decrease,pad=" + value42 + ":" + value42 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000,fps=" + value38 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality " + value39 + " -compression_level 6 -b:v " + value40 + "k -max_muxing_queue_size 1024 \"" + value36 + "\"";
          }
        } else {
          const value43 = Math.max(30, 60 - value34 * 5);
          const value44 = value34 === 1 ? 512 : value34 === 2 ? 400 : value34 === 3 ? 320 : value34 === 4 ? 256 : 200;
          const value45 = value17 ? "crop=min(iw\\,ih):min(iw\\,ih),scale=" + value44 + ":" + value44 + ",format=rgba" : "scale=" + value44 + ":" + value44 + ":force_original_aspect_ratio=decrease,pad=" + value44 + ":" + value44 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000,format=rgba";
          value37 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" -vf \"" + value45 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality " + value43 + " -compression_level 6 \"" + value36 + "\"";
        }
        await new Promise((value46, value47) => {
          exec(value37, value48 => value48 ? value47(value48) : value46());
        });
        if (fs.existsSync(value36)) {
          const value49 = fs.readFileSync(value36);
          value33 = value49;
        }
      } catch (error50) {
        if (value34 >= value35) {
          break;
        }
      }
    }
    const value51 = new webp.Image();
    await value51.load(value33);
    const value52 = {
      "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
      "sticker-pack-name": database.getBotSetting("packname") || "Made by",
      emojis: ["📸"]
    };
    const value53 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
    const value54 = Buffer.from(JSON.stringify(value52), "utf8");
    const value55 = Buffer.concat([value53, value54]);
    value55.writeUIntLE(value54.length, 14, 4);
    value51.exif = value55;
    let value56 = await value51.save(null);
    if (value56.length > 972800) {
      try {
        const value57 = [256, 200, 180, 160, 128];
        for (const value58 of value57) {
          const value59 = path.join(value18, "igs_mini_" + value58 + "_" + Date.now() + "_" + Math.random().toString(36).slice(2) + ".webp");
          value22.push(value59);
          const value60 = value17 ? "crop=min(iw\\,ih):min(iw\\,ih),scale=" + value58 + ":" + value58 + (value16 ? ",fps=3" : "") : "scale=" + value58 + ":" + value58 + ":force_original_aspect_ratio=decrease,pad=" + value58 + ":" + value58 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000" + (value16 ? ",fps=3" : "");
          const value61 = "\"" + ffmpegPath() + "\" -y -i \"" + value20 + "\" " + (value16 ? "-t 0.5" : "") + " -vf \"" + value60 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality " + (value16 ? 15 : 30) + " -compression_level 6 -b:v 30k -max_muxing_queue_size 1024 \"" + value59 + "\"";
          await new Promise((value62, value63) => {
            exec(value61, value64 => value64 ? value63(value64) : value62());
          });
          if (fs.existsSync(value59)) {
            const value65 = fs.readFileSync(value59);
            const value66 = new webp.Image();
            await value66.load(value65);
            const value67 = {
              "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
              "sticker-pack-name": database.getBotSetting("packname") || "Made by",
              emojis: ["📸"]
            };
            const value68 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
            const value69 = Buffer.from(JSON.stringify(value67), "utf8");
            const value70 = Buffer.concat([value68, value69]);
            value70.writeUIntLE(value69.length, 14, 4);
            value66.exif = value70;
            const value71 = await value66.save(null);
            if (value71.length <= 972800) {
              value56 = value71;
              break;
            }
          }
        }
      } catch {}
    }
    return value56;
  } finally {
    value22.forEach(value72 => deleteTempFile(value72));
  }
}
async function fetchBufferFromUrl(value73, value74 = 0) {
  const value75 = 3;
  const value76 = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    Accept: "*/*",
    "Cache-Control": "no-cache, no-store, must-revalidate",
    Pragma: "no-cache",
    Expires: "0"
  };
  const value77 = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Referer: "https://www.instagram.com/",
    Origin: "https://www.instagram.com",
    Accept: "image/avif,image/webp,image/*,*/*;q=0.8",
    "Cache-Control": "no-cache, no-store, must-revalidate",
    Pragma: "no-cache",
    Expires: "0"
  };
  function handler78(value79) {
    if (!value79 || value79.length < 10) {
      return false;
    }
    const value80 = value79.toString("utf8", 0, 100).toLowerCase().trim();
    return value80.startsWith("<!doctype html") || value80.startsWith("<html");
  }
  function handler81(value82) {
    if (!value82) {
      return true;
    }
    const value83 = value82.toLowerCase();
    return value83.startsWith("image/") || value83.startsWith("video/") || value83 === "application/octet-stream";
  }
  let value84;
  for (let value85 = 0; value85 < value75; value85++) {
    try {
      const value86 = value85 === 0 ? value76 : value77;
      const value87 = {
        responseType: "arraybuffer",
        headers: value86,
        timeout: 30000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        decompress: true,
        maxRedirects: 5,
        validateStatus: value88 => value88 >= 200 && value88 < 300
      };
      const value89 = await axios.get(value73, value87);
      const value90 = Buffer.from(value89.data);
      const value91 = value89.headers["content-type"];
      if (!handler81(value91)) {
        throw new Error("Invalid content-type: " + value91 + " (expected image/* or video/*)");
      }
      if (handler78(value90)) {
        throw new Error("Response is HTML (blocked/login required)");
      }
      return value90;
    } catch (error92) {
      value84 = error92;
      if (value85 === value75 - 1) {
        try {
          const value93 = value77;
          const value94 = await axios.get(value73, {
            responseType: "stream",
            headers: value93,
            timeout: 40000,
            maxContentLength: Infinity,
            maxBodyLength: Infinity,
            maxRedirects: 5,
            validateStatus: value95 => value95 >= 200 && value95 < 300
          });
          const value96 = [];
          await new Promise((value97, value98) => {
            value94.data.on("data", value99 => value96.push(value99));
            value94.data.on("end", value97);
            value94.data.on("error", value98);
          });
          const value100 = Buffer.concat(value96);
          const value101 = value94.headers["content-type"];
          if (!handler81(value101)) {
            throw new Error("Invalid content-type: " + value101);
          }
          if (handler78(value100)) {
            throw new Error("Stream response is HTML (blocked/login required)");
          }
          return value100;
        } catch (error102) {
          throw new Error("Failed to download media after " + value75 + " attempts: " + (value84?.message || value84));
        }
      }
      if (value85 < value75 - 1) {
        await new Promise(value103 => setTimeout(value103, (value85 + 1) * 500));
      }
    }
  }
  throw new Error("Failed to download media after " + value75 + " attempts: " + (value84?.message || value84));
}
async function forceMiniSticker(value104, value105, value106) {
  const value107 = getTempDir();
  const value108 = [];
  try {
    for (const value109 of [256, 200, 180, 160]) {
      const value110 = path.join(value107, "mini_" + value109 + "_" + Date.now() + "." + (value105 ? "mp4" : "jpg"));
      const value111 = path.join(value107, "mini_out_" + value109 + "_" + Date.now() + ".webp");
      value108.push(value110, value111);
      try {
        fs.writeFileSync(value110, value104);
        const value112 = value106 ? "crop=min(iw\\,ih):min(iw\\,ih),scale=" + value109 + ":" + value109 + (value105 ? ",fps=3" : "") : "scale=" + value109 + ":" + value109 + ":force_original_aspect_ratio=decrease,pad=" + value109 + ":" + value109 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000" + (value105 ? ",fps=3" : "");
        const value113 = "\"" + ffmpegPath() + "\" -y -i \"" + value110 + "\" " + (value105 ? "-t 0.5" : "") + " -vf \"" + value112 + "\" -c:v libwebp -preset default -loop 0 -pix_fmt yuva420p -quality " + (value105 ? 15 : 30) + " -compression_level 6 -b:v 30k \"" + value111 + "\"";
        await new Promise((value114, value115) => {
          exec(value113, value116 => value116 ? value115(value116) : value114());
        });
        if (fs.existsSync(value111)) {
          const value117 = fs.readFileSync(value111);
          if (value117.length <= 972800) {
            const value118 = new webp.Image();
            await value118.load(value117);
            const value119 = {
              "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
              "sticker-pack-name": database.getBotSetting("packname") || "Made by",
              emojis: ["📸"]
            };
            const value120 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
            const value121 = Buffer.from(JSON.stringify(value119), "utf8");
            const value122 = Buffer.concat([value120, value121]);
            value122.writeUIntLE(value121.length, 14, 4);
            value118.exif = value122;
            const value123 = await value118.save(null);
            return value123;
          }
        }
      } catch (error124) {}
    }
    return null;
  } finally {
    value108.forEach(value125 => deleteTempFile(value125));
  }
}
async function igsCommand(value126, value127, value128, value129, value130 = false) {
  try {
    const value131 = value127.message?.conversation || value127.message?.extendedTextMessage?.text || value128.join(" ");
    const value132 = value131.match(/https?:\/\/\S+/);
    if (!value132) {
      return value129.reply("Send an Instagram post/reel link.\nUsage:\n.igs <url>\n.igsc <url>");
    }
    await value126.sendMessage(value129.from, {
      react: {
        text: "📥",
        key: value127.key
      }
    });
    const value133 = await igdl(value132[0]).catch(() => null);
    if (!value133 || !value133.data) {
      return value129.reply("❌ Failed to fetch media from Instagram link.");
    }
    const value134 = value133.data || [];
    const value135 = value134.filter(value136 => value136 && pickMediaUrl(value136));
    const value137 = value135.slice(0, 3).map((value138, value139) => pickMediaUrl(value138));
    console.log("[DEBUG] Extracted " + value135.length + " items. First 3 URLs after extraction:", value137.map((value140, value141) => "Item" + (value141 + 1) + "=" + value140?.substring(0, 80)));
    fetch("http://127.0.0.1:7242/ingest/44c87b60-b6ab-47d5-9224-5cb012ce57ee", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        location: "igsc.js:430",
        message: "Items extracted",
        data: {
          totalItems: value134.length,
          filteredItems: value135.length,
          firstFewUrls: value137.map(value142 => value142?.substring(0, 80))
        },
        timestamp: Date.now(),
        sessionId: "debug-session",
        runId: "run2",
        hypothesisId: "E"
      })
    }).catch(() => {});
    const value143 = value135.slice(0, 10);
    if (value143.length === 0) {
      return value129.reply("❌ No valid media found to download. This might be a private post or the scraper failed.");
    }
    let value144 = 0;
    let value145 = 0;
    const value146 = new Set();
    for (let value147 = 0; value147 < value143.length; value147++) {
      try {
        const value148 = value143[value147];
        const value149 = pickMediaUrl(value148);
        if (!value149) {
          value145++;
          continue;
        }
        const value150 = /\.(mp4|mov|avi|mkv|webm)$/i.test(value149) || value148.type === "video" || value132[0].includes("/reel/") || value132[0].includes("/tv/");
        const value151 = await fetchBufferFromUrl(value149, value147);
        const value152 = crypto.createHash("md5").update(value151).digest("hex");
        console.log("[DEBUG] Item " + (value147 + 1) + ": Hash=" + value152.substring(0, 8) + ", size=" + value151.length + ", isDuplicate=" + value146.has(value152));
        fetch("http://127.0.0.1:7242/ingest/44c87b60-b6ab-47d5-9224-5cb012ce57ee", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            location: "igsc.js:465",
            message: "Hash check",
            data: {
              item: value147 + 1,
              hash: value152.substring(0, 8),
              bufferSize: value151.length,
              seenHashesCount: value146.size,
              isDuplicate: value146.has(value152)
            },
            timestamp: Date.now(),
            sessionId: "debug-session",
            runId: "run2",
            hypothesisId: "F"
          })
        }).catch(() => {});
        if (value146.has(value152)) {
          continue;
        }
        value146.add(value152);
        let value153 = await convertBufferToStickerWebp(value151, value150, value130);
        let value154 = value153;
        if (value154.length > 972800) {
          try {
            const value155 = await forceMiniSticker(value151, value150, value130);
            if (value155) {
              value154 = value155;
            }
          } catch (error156) {}
        }
        if (value154.length > 972800) {
          const value157 = getTempDir();
          const value158 = path.join(value157, "ultra_" + Date.now() + "_" + value147 + "." + (value150 ? "mp4" : "jpg"));
          const value159 = path.join(value157, "ultra_out_" + Date.now() + "_" + value147 + ".webp");
          const value160 = [value158, value159];
          try {
            fs.writeFileSync(value158, value151);
            const value161 = 180;
            const value162 = value130 ? "crop=min(iw\\,ih):min(iw\\,ih),scale=" + value161 + ":" + value161 + (value150 ? ",fps=3" : "") : "scale=" + value161 + ":" + value161 + ":force_original_aspect_ratio=decrease,pad=" + value161 + ":" + value161 + ":(ow-iw)/2:(oh-ih)/2:color=#00000000" + (value150 ? ",fps=3" : "");
            const value163 = "\"" + ffmpegPath() + "\" -y -i \"" + value158 + "\" " + (value150 ? "-t 0.5" : "") + " -vf \"" + value162 + "\" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality " + (value150 ? 12 : 25) + " -compression_level 6 -b:v 25k -max_muxing_queue_size 1024 \"" + value159 + "\"";
            await new Promise((value164, value165) => {
              exec(value163, value166 => value166 ? value165(value166) : value164());
            });
            if (fs.existsSync(value159)) {
              const value167 = fs.readFileSync(value159);
              const value168 = new webp.Image();
              await value168.load(value167);
              const value169 = {
                "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
                "sticker-pack-name": database.getBotSetting("packname") || "Made by",
                emojis: ["📸"]
              };
              const value170 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
              const value171 = Buffer.from(JSON.stringify(value169), "utf8");
              const value172 = Buffer.concat([value170, value171]);
              value172.writeUIntLE(value171.length, 14, 4);
              value168.exif = value172;
              value154 = await value168.save(null);
            }
          } catch (error173) {} finally {
            value160.forEach(value174 => deleteTempFile(value174));
          }
        }
        try {
          await value126.sendMessage(value129.from, {
            sticker: value154
          }, {
            quoted: value127
          });
          value144++;
        } catch (error175) {
          value145++;
        }
        if (value147 < value143.length - 1) {
          await new Promise(value176 => setTimeout(value176, 800));
        }
      } catch (error177) {
        value145++;
      }
    }
  } catch (error178) {
    console.error("Error in igsc command:", error178);
    await value129.reply("❌ Failed to create sticker from Instagram link.");
  }
}
module.exports = {
  name: "igsc",
  aliases: ["igstickercrop"],
  description: "Convert Instagram post/reel to cropped square sticker",
  usage: ".igsc <Instagram URL>",
  category: "media",
  async execute(value179, value180, value181, value182) {
    await igsCommand(value179, value180, value181, value182, true);
  }
};
