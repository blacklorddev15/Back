const axios = require("axios");
const database = require("../../database");
const processedMessages = new Set();
module.exports = {
  name: "facebook",
  aliases: ["fb", "fbdl", "facebookdl"],
  category: "media",
  description: "Download Facebook videos",
  usage: ".facebook <Facebook URL>",
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      if (processedMessages.has(value2.key.id)) {
        return;
      }
      processedMessages.add(value2.key.id);
      setTimeout(() => processedMessages.delete(value2.key.id), 300000);
      const value6 = value3.join(" ").trim();
      if (!value6) {
        return await value1.sendMessage(value5, {
          text: "Please provide a Facebook link for the video."
        }, {
          quoted: value2
        });
      }
      const value7 = [/https?:\/\/(?:www\.)?facebook\.com\//, /https?:\/\/fb\.watch\//, /https?:\/\/m\.facebook\.com\//, /https?:\/\/web\.facebook\.com\//, /https?:\/\/(?:www\.)?facebook\.com\/share\//];
      const value8 = value7.some(value9 => value9.test(value6));
      if (!value8) {
        return await value1.sendMessage(value5, {
          text: "That is not a valid Facebook link. Please provide a valid Facebook video link."
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "↘️",
          key: value2.key
        }
      });
      try {
        const value10 = await axios.get("https://apissupreme.vercel.app/media/facebook?apikey=supreme&url=" + encodeURIComponent(value6));
        const value11 = value10.data;
        const value12 = value11?.data?.videos?.hd || value11?.data?.videos?.sd;
        if (value11 && value11.status && value12) {
          const value13 = value11.data.title ? value11.data.title + "\n\n" + database.getBotSetting("botName") : database.getBotSetting("botName");
          await value1.sendMessage(value5, {
            video: {
              url: value12
            },
            mimetype: "video/mp4",
            caption: value13
          }, {
            quoted: value2
          });
          await value1.sendMessage(value5, {
            react: {
              text: "✅",
              key: value2.key
            }
          });
        } else {
          await value1.sendMessage(value5, {
            react: {
              text: "❌",
              key: value2.key
            }
          });
          return await value1.sendMessage(value5, {
            text: "Failed to fetch video. Please check the link or try again later."
          }, {
            quoted: value2
          });
        }
      } catch (error14) {
        console.error("[facebook]", error14.message || error14);
        await value1.sendMessage(value5, {
          react: {
            text: "❌",
            key: value2.key
          }
        });
        await value1.sendMessage(value5, {
          text: "Failed to download the Facebook video. Please try again later."
        }, {
          quoted: value2
        });
      }
    } catch (error15) {
      console.error("[facebook]", error15.message || error15);
      await value1.sendMessage(value5, {
        text: "An unexpected error occurred. Please try again."
      }, {
        quoted: value2
      });
    }
  }
};
