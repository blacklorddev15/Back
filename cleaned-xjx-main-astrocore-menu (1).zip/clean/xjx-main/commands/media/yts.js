const yts = require("yt-search");
async function safeSearch(value1, value2 = 1) {
  try {
    return await yts(value1);
  } catch (error3) {
    console.error("[ytsearch] yts() failed (attempt " + value2 + "):", error3.stack || error3.message);
    if (value2 < 2) {
      await new Promise(value4 => setTimeout(value4, 800));
      return safeSearch(value1, value2 + 1);
    }
    throw error3;
  }
}
module.exports = {
  name: "ytsearch",
  aliases: ["youtubesearch", "yts"],
  category: "media",
  description: "Search YouTube videos",
  usage: ".ytsearch <query>",
  async execute(value5, value6, value7, value8) {
    const value9 = value7.join(" ");
    if (!value9) {
      return value8.reply("☆━━━━━━━━━━━━━━━☆\n   ★ YOUTUBE SEARCH ★\n☆━━━━━━━━━━━━━━━☆\n\n◈ Usage  : .ytsearch <query>\n\n◉ Examples:\n  ▸ .ytsearch Godzilla\n  ▸ .ytsearch latest songs");
    }
    await value8.react("☆");
    let value10;
    try {
      value10 = await safeSearch(value9);
    } catch (error11) {
      console.error("[ytsearch] final failure after retry:", error11.stack || error11.message);
      return value8.reply("◈ YouTube search is glitching right now.\n▸ Try rephrasing the query or search again shortly.");
    }
    try {
      const value12 = Array.isArray(value10?.videos) ? value10.videos : [];
      const value13 = value12.filter(value14 => value14 && typeof value14.title === "string" && value14.title.trim().length > 0 && value14.url).slice(0, 15).map(value15 => ({
        title: value15.title.trim(),
        url: String(value15.url),
        timestamp: typeof value15.timestamp === "string" ? value15.timestamp : "N/A",
        views: typeof value15.views === "number" ? value15.views.toLocaleString() : "N/A",
        ago: typeof value15.ago === "string" ? value15.ago : "N/A",
        thumbnail: value15.thumbnail || value15.image || null
      }));
      if (value13.length === 0) {
        return value8.reply("◈ No results found for:\n" + ("  \"" + value9 + "\"\n\n") + "▸ Try different keywords.");
      }
      let value16 = "☆━━━━━━━━━━━━━━━☆\n";
      value16 += " ★ YOUTUBE SEARCH ★\n";
      value16 += "☆━━━━━━━━━━━━━━━☆\n";
      value16 += "◈ Query » " + value9 + "\n\n";
      value13.forEach((value17, value18) => {
        const value19 = String(value18 + 1).padStart(2, "0");
        value16 += "◆ " + value19 + ". " + value17.title + "\n";
        value16 += "  ◈ " + value17.url + "\n";
        value16 += "  ◇ Duration : " + value17.timestamp + "\n";
        value16 += "  ◇ Views    : " + value17.views + "\n";
        value16 += "  ◇ Uploaded : " + value17.ago + "\n";
        value16 += "  ·  ·  ·  ·  ·  ·  ·\n";
      });
      value16 += "\n☆━━━━━━━━━━━━━━━☆\n";
      value16 += "◉ #play <url>  » audio\n";
      value16 += "◉ #video <url> » video\n";
      value16 += "☆━━━━━━━━━━━━━━━☆";
      const value20 = value13[0].thumbnail;
      if (value20) {
        await value5.sendMessage(value6.key.remoteJid, {
          image: {
            url: value20
          },
          caption: value16
        }, {
          quoted: value6
        });
      } else {
        await value8.reply(value16);
      }
    } catch (error21) {
      console.error("[ytsearch]", error21.stack || error21.message);
      value8.reply("☆━━━━━━━━━━━━━━━☆\n       ★ ERROR ★\n☆━━━━━━━━━━━━━━━☆\n" + ("◈ " + error21.message));
    }
  }
};
