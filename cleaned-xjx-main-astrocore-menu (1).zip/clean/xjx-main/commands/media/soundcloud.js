const axios = require("axios");
const fs = require("fs");
const path = require("path");
const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
const RETRY_DELAY = 3000;
const MAX_RESULTS = 5;
const BASE = "https://api.nexray.eu.cc";
function extractButtonResponseId(value1) {
  return value1.message?.buttonsResponseMessage?.selectedButtonId || value1.message?.templateButtonReplyMessage?.selectedId || value1.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || null;
}
function getResponseSender(value2) {
  return value2.key?.participant || value2.key?.remoteJid;
}
function isSoundCloudUrl(value3) {
  return /https?:\/\/(www\.|m\.)?soundcloud\.com\/[^\s]+/i.test(value3);
}
async function withRetry(value4, value5 = 3, value6 = RETRY_DELAY) {
  let value7;
  for (let value8 = 0; value8 < value5; value8++) {
    try {
      return await value4();
    } catch (error9) {
      value7 = error9;
      const value10 = error9.message?.toLowerCase().includes("busy") || error9.message?.toLowerCase().includes("try again");
      if (value8 < value5 - 1 && value10) {
        await new Promise(value11 => setTimeout(value11, value6));
      } else if (!value10) {
        throw error9;
      }
    }
  }
  throw value7;
}
async function searchSoundCloud(value12) {
  return withRetry(async () => {
    const value13 = await axios.get(BASE + "/search/soundcloud?q=" + encodeURIComponent(value12), {
      timeout: 30000
    });
    if (!value13.data?.status || !Array.isArray(value13.data?.result) || !value13.data.result.length) {
      throw new Error("No results found");
    }
    return value13.data.result.slice(0, MAX_RESULTS);
  });
}
async function downloadSoundCloud(value14) {
  return withRetry(async () => {
    console.log("[soundcloud] downloading:", value14);
    const value15 = await axios.get(BASE + "/downloader/soundcloud?url=" + encodeURIComponent(value14), {
      timeout: 90000
    });
    const value16 = value15.data?.result;
    if (!value15.data?.status || !value16?.download_url) {
      throw new Error("Download API returned no URL");
    }
    console.log("[soundcloud] delivering:", value16.title);
    return {
      downloadUrl: value16.download_url,
      title: value16.title || "",
      thumbnail: value16.thumbnail || "",
      duration: value16.duration || ""
    };
  });
}
function getTrackButtons(value17, value18) {
  const value19 = database.getBotSetting("prefix") || ".";
  return value17.map((value20, value21) => ({
    id: value19 + "sctrack_" + value21 + "_" + value18,
    text: value21 + 1 + ". " + value20.title.substring(0, 22) + (value20.title.length > 22 ? "…" : "")
  }));
}
function getFormatButtons(value22) {
  const value23 = database.getBotSetting("prefix") || ".";
  return [{
    id: value23 + "scfmt_audio_" + value22,
    text: "🎶 Audio"
  }, {
    id: value23 + "scfmt_audiodoc_" + value22,
    text: "📄 Audio Document"
  }];
}
module.exports = {
  name: "soundcloud",
  aliases: ["sc", "scdl", "scplay"],
  category: "media",
  description: "Search and download SoundCloud tracks",
  usage: ".soundcloud <track name | soundcloud link>",
  async execute(value24, value25, value26, value27) {
    if (!value26.length) {
      return value27.reply("🎧 *SoundCloud Downloader*\n\n*Usage:*\n• `.soundcloud faded` — search by name\n• `.soundcloud https://soundcloud.com/...` — download via link\n• Reply to a message with `.soundcloud` — use replied text as query");
    }
    let value28 = value26.join(" ").trim();
    if (!value28) {
      const value29 = value27?.quoted;
      value28 = value29?.conversation || value29?.extendedTextMessage?.text || "";
    }
    if (!value28) {
      return value27.reply("🎧 Provide a track name or SoundCloud link.\nExample: `.soundcloud Faded`");
    }
    if (value28.length > 200) {
      return value27.reply("📝 Query too long! Max 200 chars.");
    }
    const value30 = value27.from;
    const value31 = database.getBotSetting("prefix") || ".";
    const value32 = value25.key.participant || value25.key.remoteJid;
    if (isSoundCloudUrl(value28)) {
      await value24.sendMessage(value30, {
        react: {
          text: "🔗",
          key: value25.key
        }
      });
      const value33 = Date.now();
      await sendButtons(value24, value30, {
        title: "🎧 SOUNDCLOUD LINK",
        text: "⿻ *Link:* " + value28 + "\n\n*Select download format:*",
        footer: "Made by " + database.getBotSetting("botName"),
        buttons: getFormatButtons(value33)
      }, {
        quoted: value25
      });
      await value24.sendMessage(value30, {
        react: {
          text: "✅",
          key: value25.key
        }
      });
      const value34 = async value35 => {
        const value36 = value35.messages[0];
        if (!value36?.message) {
          return;
        }
        const value37 = extractButtonResponseId(value36);
        if (!value37) {
          return;
        }
        if (!value37.includes("scfmt_") || !value37.includes("_" + value33)) {
          return;
        }
        if (value36.key?.remoteJid !== value30) {
          return;
        }
        const value38 = getResponseSender(value36);
        if (value30.endsWith("@g.us") && value38 !== value32) {
          return;
        }
        const value39 = value37.replace(value31, "").split("_")[1];
        await value24.sendMessage(value30, {
          react: {
            text: "⏬",
            key: value25.key
          }
        });
        try {
          const value40 = await downloadSoundCloud(value28);
          const value41 = path.join(__dirname, "temp");
          if (!fs.existsSync(value41)) {
            fs.mkdirSync(value41);
          }
          const value42 = path.join(value41, "sc_" + value33 + ".mp3");
          const value43 = await axios({
            method: "get",
            url: value40.downloadUrl,
            responseType: "stream",
            timeout: 600000
          });
          const value44 = fs.createWriteStream(value42);
          value43.data.pipe(value44);
          await new Promise((value45, value46) => {
            value44.on("finish", value45);
            value44.on("error", value46);
          });
          if (!fs.existsSync(value42) || fs.statSync(value42).size === 0) {
            throw new Error("Download failed — file is empty");
          }
          const value47 = (value40.title || "").replace(/[^\w\s.-]/gi, "").substring(0, 100);
          if (value39 === "audio") {
            await value24.sendMessage(value30, {
              audio: {
                url: value42
              },
              mimetype: "audio/mpeg"
            }, {
              quoted: value36
            });
          } else if (value39 === "audiodoc") {
            await value24.sendMessage(value30, {
              document: {
                url: value42
              },
              mimetype: "audio/mpeg",
              fileName: value47 + ".mp3",
              caption: "🎧 " + value40.title + "\n> " + database.getBotSetting("botName")
            }, {
              quoted: value36
            });
          }
          if (fs.existsSync(value42)) {
            fs.unlinkSync(value42);
          }
          await value24.sendMessage(value30, {
            react: {
              text: "✅",
              key: value25.key
            }
          });
        } catch (error48) {
          console.error("[soundcloud] link download error:", error48.message);
          await value24.sendMessage(value30, {
            react: {
              text: "❌",
              key: value25.key
            }
          });
          await value24.sendMessage(value30, {
            text: "🚫 Error: " + error48.message + "\n\n_Try again later._"
          }, {
            quoted: value36
          });
        }
      };
      value24.ev.on("messages.upsert", value34);
      return;
    }
    await value24.sendMessage(value30, {
      react: {
        text: "🔍",
        key: value25.key
      }
    });
    let value49;
    try {
      value49 = await searchSoundCloud(value28);
    } catch (error50) {
      console.error("[soundcloud] search error:", error50.message);
      return value27.reply("❌ Search failed: " + error50.message);
    }
    const value51 = Date.now();
    const value52 = value49.map((value53, value54) => "*" + (value54 + 1) + ".* " + value53.title + "\n" + ("    🎤 " + (value53.author?.name || "N/A") + "  •  ⏱ " + (value53.duration || "N/A") + "\n") + ("    ❤️ " + (value53.like_count || "0") + "  •  ▶️ " + (value53.play_count || "0"))).join("\n\n");
    await sendButtons(value24, value30, {
      title: "🎧 SOUNDCLOUD SEARCH",
      text: "*Query:* _" + value28 + "_\n\n" + (value52 + "\n\n") + "*Select a track to download:*",
      footer: "Made by " + database.getBotSetting("botName"),
      buttons: getTrackButtons(value49, value51)
    }, {
      quoted: value25
    });
    await value24.sendMessage(value30, {
      react: {
        text: "✅",
        key: value25.key
      }
    });
    const value55 = async value56 => {
      const value57 = value56.messages[0];
      if (!value57?.message) {
        return;
      }
      const value58 = extractButtonResponseId(value57);
      if (!value58) {
        return;
      }
      if (!value58.includes("sctrack_") || !value58.includes("_" + value51)) {
        return;
      }
      if (value57.key?.remoteJid !== value30) {
        return;
      }
      const value59 = getResponseSender(value57);
      if (value30.endsWith("@g.us") && value59 !== value32) {
        return;
      }
      const value60 = value58.replace(value31, "").match(/^sctrack_(\d+)_/);
      if (!value60) {
        return;
      }
      const value61 = value49[parseInt(value60[1])];
      if (!value61) {
        return;
      }
      const value62 = Date.now();
      await sendButtons(value24, value30, {
        title: "🎧 " + value61.title,
        text: "⿻ *Title:*    " + value61.title + "\n" + ("⿻ *Artist:*   " + (value61.author?.name || "N/A") + "\n") + ("⿻ *Duration:* " + (value61.duration || "N/A") + "\n") + ("⿻ *Likes:*    " + (value61.like_count || "0") + "\n") + ("⿻ *Plays:*    " + (value61.play_count || "0") + "\n") + ("⿻ *Released:* " + (value61.release_date || "N/A") + "\n") + ("⿻ *Link:*     " + (value61.url || "N/A") + "\n\n") + "*Select download format:*",
        footer: "Made by " + database.getBotSetting("botName"),
        buttons: getFormatButtons(value62)
      }, {
        quoted: value57
      });
      await value24.sendMessage(value30, {
        react: {
          text: "⬇️",
          key: value25.key
        }
      });
      const value63 = async value64 => {
        const value65 = value64.messages[0];
        if (!value65?.message) {
          return;
        }
        const value66 = extractButtonResponseId(value65);
        if (!value66) {
          return;
        }
        if (!value66.includes("scfmt_") || !value66.includes("_" + value62)) {
          return;
        }
        if (value65.key?.remoteJid !== value30) {
          return;
        }
        const value67 = getResponseSender(value65);
        if (value30.endsWith("@g.us") && value67 !== value32) {
          return;
        }
        const value68 = value66.replace(value31, "").split("_")[1];
        await value24.sendMessage(value30, {
          react: {
            text: "⏬",
            key: value25.key
          }
        });
        try {
          if (!value61.url || !isSoundCloudUrl(value61.url)) {
            throw new Error("Track has no valid SoundCloud URL");
          }
          const value69 = await downloadSoundCloud(value61.url);
          const value70 = path.join(__dirname, "temp");
          if (!fs.existsSync(value70)) {
            fs.mkdirSync(value70);
          }
          const value71 = path.join(value70, "sc_" + value62 + ".mp3");
          const value72 = await axios({
            method: "get",
            url: value69.downloadUrl,
            responseType: "stream",
            timeout: 600000
          });
          const value73 = fs.createWriteStream(value71);
          value72.data.pipe(value73);
          await new Promise((value74, value75) => {
            value73.on("finish", value74);
            value73.on("error", value75);
          });
          if (!fs.existsSync(value71) || fs.statSync(value71).size === 0) {
            throw new Error("Download failed — file is empty");
          }
          const value76 = value69.title || value61.title || "";
          const value77 = value76.replace(/[^\w\s.-]/gi, "").substring(0, 100);
          if (value68 === "audio") {
            await value24.sendMessage(value30, {
              audio: {
                url: value71
              },
              mimetype: "audio/mpeg"
            }, {
              quoted: value65
            });
          } else if (value68 === "audiodoc") {
            await value24.sendMessage(value30, {
              document: {
                url: value71
              },
              mimetype: "audio/mpeg",
              fileName: value77 + ".mp3",
              caption: "🎧 " + value76 + "\n> " + database.getBotSetting("botName")
            }, {
              quoted: value65
            });
          }
          if (fs.existsSync(value71)) {
            fs.unlinkSync(value71);
          }
          await value24.sendMessage(value30, {
            react: {
              text: "✅",
              key: value25.key
            }
          });
        } catch (error78) {
          console.error("[soundcloud] download error:", error78.message);
          await value24.sendMessage(value30, {
            react: {
              text: "❌",
              key: value25.key
            }
          });
          await value24.sendMessage(value30, {
            text: "🚫 Error: " + error78.message + "\n\n_Try again later._"
          }, {
            quoted: value65
          });
        }
      };
      value24.ev.on("messages.upsert", value63);
    };
    value24.ev.on("messages.upsert", value55);
  }
};
