const fs = require("fs");
const path = require("path");
const {
  execFile
} = require("child_process");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const ffmpegPath = require("../../utils/ffmpegPath");
module.exports = {
  name: "trim",
  aliases: ["trimvid", "trimaudio", "cut"],
  category: "media",
  description: "Trim an audio or video file to a specific time range",
  usage: ".trim <start> <end> (reply to an audio or video)",
  async execute(value1, value2, value3) {
    const value4 = value2.key.remoteJid;
    const value5 = path.join(getTempDir(), "input_" + Date.now());
    const value6 = path.join(getTempDir(), "trim_" + Date.now());
    try {
      await value1.sendMessage(value4, {
        react: {
          text: "✂️",
          key: value2.key
        }
      });
      if (!value3 || value3.length < 2) {
        return value1.sendMessage(value4, {
          text: "❌ Reply to an audio or video file with start and end time.\n\nExample: `.trim 0:10 0:30`"
        }, {
          quoted: value2
        });
      }
      const [value7, value8] = value3;
      const value9 = /^(\d{1,2}:)?[0-5]?\d:[0-5]?\d$/;
      if (!value9.test(value7) || !value9.test(value8)) {
        return value1.sendMessage(value4, {
          text: "⚠️ Invalid time format. Use MM:SS or HH:MM:SS\nExample: `.trim 0:30 1:45`"
        }, {
          quoted: value2
        });
      }
      const value10 = value2.message?.extendedTextMessage?.contextInfo;
      if (!value10?.quotedMessage) {
        return value1.sendMessage(value4, {
          text: "❌ Please reply to an audio or video file with this command."
        }, {
          quoted: value2
        });
      }
      const value11 = value10.quotedMessage;
      const value12 = value11.audioMessage;
      const value13 = value11.videoMessage;
      if (!value12 && !value13) {
        return value1.sendMessage(value4, {
          text: "❌ Unsupported media type. Please reply to an audio or video file."
        }, {
          quoted: value2
        });
      }
      const value14 = {
        key: {
          remoteJid: value10.remoteJid || value4,
          fromMe: false,
          id: value10.stanzaId,
          participant: value10.participant
        },
        message: value11
      };
      const value15 = await downloadMediaMessage(value14, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value1.updateMediaMessage
      });
      if (!value15 || value15.length === 0) {
        return value1.sendMessage(value4, {
          text: "❌ Failed to download the media. Please try again."
        }, {
          quoted: value2
        });
      }
      const value16 = !!value12;
      const value17 = value5 + (value16 ? ".tmp" : ".tmp");
      const value18 = value6 + (value16 ? ".mp3" : ".mp4");
      fs.writeFileSync(value17, value15);
      const value19 = value16 ? ["-y", "-i", value17, "-ss", value7, "-to", value8, "-vn", "-c:a", "libmp3lame", "-q:a", "2", value18] : ["-y", "-i", value17, "-ss", value7, "-to", value8, "-c:v", "copy", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", value18];
      await new Promise((value20, value21) => {
        execFile(ffmpegPath(), value19, (value22, value23, value24) => {
          deleteTempFile(value17);
          if (value22) {
            console.error("[Trim] FFmpeg stderr:", value24);
            return value21(new Error("FFmpeg failed: " + (value24?.split("\n").slice(-4).join(" ").trim() || value22.message)));
          }
          value20();
        });
      });
      if (!fs.existsSync(value18) || fs.statSync(value18).size === 0) {
        throw new Error("Trim produced an empty file — check the time range.");
      }
      await value1.sendMessage(value4, {
        text: "_✂️ Trimmed clip ready!_"
      }, {
        quoted: value2
      });
      const value25 = fs.readFileSync(value18);
      const value26 = value16 ? {
        audio: value25,
        mimetype: "audio/mpeg",
        fileName: "trimmed.mp3"
      } : {
        video: value25,
        mimetype: "video/mp4",
        fileName: "trimmed.mp4"
      };
      await value1.sendMessage(value4, value26, {
        quoted: value2
      });
    } catch (error27) {
      console.error("[Trim] Error:", error27);
      return value1.sendMessage(value4, {
        text: "🚫 Error: " + error27.message
      }, {
        quoted: value2
      });
    } finally {
      [value5 + ".tmp", value6 + ".mp3", value6 + ".mp4"].forEach(value28 => {
        try {
          if (fs.existsSync(value28)) {
            fs.unlinkSync(value28);
          }
        } catch (error29) {}
      });
    }
  }
};
