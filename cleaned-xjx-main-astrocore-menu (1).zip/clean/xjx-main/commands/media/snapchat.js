const axios = require("axios");
const database = require("../../database");
const USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36";
function isValidSnapchatUrl(value1) {
  return /^https?:\/\/(?:www\.)?snapchat\.com\/spotlight\/[a-zA-Z0-9_-]+/i.test(value1);
}
async function getDownloadUrl(value2) {
  const value3 = [async () => {
    const value4 = await axios.get("https://api.tiklydown.eu.org/api/download", {
      params: {
        url: value2
      },
      timeout: 15000
    });
    return value4.data?.videoUrl;
  }, async () => {
    const value5 = await axios.post("https://ssstik.io/api", {
      url: value2
    }, {
      headers: {
        "Content-Type": "application/json"
      },
      timeout: 15000
    });
    return value5.data?.downloadUrl;
  }, async () => {
    const value6 = await axios.get("https://savetik.co/api/ajaxSearch", {
      params: {
        text: value2,
        lang: "en"
      },
      timeout: 15000
    });
    return value6.data?.links?.[0]?.a;
  }, async () => {
    const value7 = await axios.get("https://www.tikwm.com/api/", {
      params: {
        url: value2,
        hd: 1
      },
      timeout: 15000
    });
    return value7.data?.data?.play;
  }, async () => {
    const value8 = await axios.get("https://api16-normal-c-useast1a.tiktokv.com/aweme/v1/feed/", {
      params: {
        aweme_id: value2.split("/").pop().split("?")[0]
      },
      headers: {
        "User-Agent": "TikTok 26.2.0 rv:262018 (iPhone; iOS 14.4.2; en_US) Cronet"
      },
      timeout: 15000
    });
    return value8.data?.aweme_list?.[0]?.video?.play_addr?.url_list?.[0];
  }, async () => {
    const value9 = await axios.post("https://musicallydown.com/download", "video_url=" + encodeURIComponent(value2), {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": USER_AGENT
      },
      timeout: 15000
    });
    const value10 = String(value9.data).match(/href=["']([^"']+\.mp4[^"']*)["']/i);
    if (value10?.[1]) {
      return new URL(value10[1], "https://musicallydown.com").href;
    } else {
      return null;
    }
  }];
  for (const value11 of value3) {
    try {
      const value12 = await value11();
      if (value12) {
        return value12;
      }
    } catch {}
  }
  return null;
}
async function downloadVideo(value13) {
  const value14 = await axios.get(value13, {
    responseType: "arraybuffer",
    timeout: 60000,
    maxRedirects: 5,
    maxContentLength: 50331648,
    maxBodyLength: 50331648,
    headers: {
      "User-Agent": USER_AGENT,
      Accept: "video/mp4,video/*;q=0.9,*/*;q=0.8"
    }
  });
  const value15 = Buffer.from(value14.data);
  if (value15.length < 5000) {
    throw new Error("Received invalid or empty video data");
  }
  return value15;
}
module.exports = {
  name: "snapchat",
  aliases: ["snap"],
  category: "media",
  description: "Download Snapchat Spotlight videos",
  usage: (database.getBotSetting("prefix") || ".") + "snapchat <Spotlight URL>",
  async execute(value16, value17, value18, value19 = {}) {
    const value20 = value17.key.remoteJid;
    const value21 = value19.prefix || database.getBotSetting("prefix") || ".";
    const value22 = value18[0]?.trim();
    if (!value22) {
      return value16.sendMessage(value20, {
        text: "Usage: " + value21 + "snapchat <Snapchat Spotlight URL>"
      }, {
        quoted: value17
      });
    }
    if (!isValidSnapchatUrl(value22)) {
      return value16.sendMessage(value20, {
        text: "Please provide a valid Snapchat Spotlight URL."
      }, {
        quoted: value17
      });
    }
    try {
      const value23 = await getDownloadUrl(value22);
      if (!value23) {
        return value16.sendMessage(value20, {
          text: "No Snapchat download service returned a video."
        }, {
          quoted: value17
        });
      }
      const value24 = await downloadVideo(value23);
      await value16.sendMessage(value20, {
        video: value24,
        caption: "Snapchat Spotlight\n" + (database.getBotSetting("botName") || "JuneX-Ultra"),
        mimetype: "video/mp4"
      }, {
        quoted: value17
      });
    } catch (error25) {
      console.error("[SNAPCHAT] Download error:", error25);
      await value16.sendMessage(value20, {
        text: "Download failed: " + (error25.message || "Unknown error")
      }, {
        quoted: value17
      });
    }
  }
};
