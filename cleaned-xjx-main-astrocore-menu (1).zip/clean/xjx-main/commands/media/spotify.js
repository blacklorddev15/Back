const axios = require("axios");
const fs = require("fs");
const path = require("path");
const database = require("../../database");
const RETRY_DELAY = 3000;
const MAX_RESULTS = 5;
const SELECTION_TIMEOUT = 60000;
function getResponseSender(value1) {
  return value1.key?.participant || value1.key?.remoteJid;
}
async function withRetry(value2, value3 = 3, value4 = RETRY_DELAY) {
  let value5;
  for (let value6 = 0; value6 < value3; value6++) {
    try {
      return await value2();
    } catch (error7) {
      value5 = error7;
      const value8 = error7.message?.toLowerCase().includes("busy") || error7.message?.toLowerCase().includes("try again");
      if (value6 < value3 - 1 && value8) {
        await new Promise(value9 => setTimeout(value9, value4));
      } else if (!value8) {
        throw error7;
      }
    }
  }
  throw value5;
}
async function searchSpotify(value10) {
  return withRetry(async () => {
    const value11 = await axios.get("https://api.nexray.eu.cc/search/spotify?q=" + encodeURIComponent(value10), {
      timeout: 30000
    });
    if (!value11.data?.status || !Array.isArray(value11.data?.result) || !value11.data.result.length) {
      throw new Error("No results found");
    }
    return value11.data.result.slice(0, MAX_RESULTS);
  });
}
async function downloadSpotify(value12) {
  return withRetry(async () => {
    const value13 = await axios.get("https://api.nexray.eu.cc/downloader/spotifyplay?q=" + encodeURIComponent(value12), {
      timeout: 90000
    });
    const value14 = value13.data?.result;
    if (!value13.data?.status || !value14?.download_url) {
      throw new Error("Download API returned no URL");
    }
    return {
      downloadUrl: value14.download_url,
      title: value14.title || "",
      artist: value14.artist || "",
      album: value14.album || "",
      duration: value14.duration || "",
      thumbnail: value14.thumbnail || ""
    };
  });
}
module.exports = {
  name: "spotify",
  aliases: ["sp", "spdl", "spplay"],
  category: "media",
  description: "Search and download Spotify songs",
  usage: ".spotify <song name>",
  async execute(value15, value16, value17, value18) {
    if (!value17.length) {
      return value18.reply("🎵 *Spotify Downloader*\n\n*Usage:*\n• `.spotify faded` — search + download\n• Reply to a message with `.spotify` — use replied text as query");
    }
    let value19 = value17.join(" ").trim();
    if (!value19) {
      const value20 = value18?.quoted;
      value19 = value20?.conversation || value20?.extendedTextMessage?.text || "";
    }
    if (!value19) {
      return value18.reply("🎵 Provide a song name.\nExample: `.spotify Faded`");
    }
    if (value19.length > 100) {
      return value18.reply("📝 Song name too long! Max 100 chars.");
    }
    const value21 = value18.from;
    const value22 = value16.key.participant || value16.key.remoteJid;
    await value15.sendMessage(value21, {
      react: {
        text: "🔍",
        key: value16.key
      }
    });
    let value23;
    try {
      value23 = await searchSpotify(value19);
    } catch (error24) {
      console.error("[spotify] search error:", error24.message);
      return value18.reply("❌ Search failed: " + error24.message);
    }
    const value25 = value23.map((value26, value27) => "*" + (value27 + 1) + ".* " + value26.title + "\n" + ("    👤 " + value26.artist + "  •  ⏱ " + value26.duration + "  •  💿 " + value26.album)).join("\n\n");
    await value18.reply("🎵 *Spotify Search Results*\n" + ("*Query:* _" + value19 + "_\n\n") + (value25 + "\n\n") + ("_Reply with a number (1–" + value23.length + ") to download_"));
    await value15.sendMessage(value21, {
      react: {
        text: "✅",
        key: value16.key
      }
    });
    const value28 = async value29 => {
      const value30 = value29.messages[0];
      if (!value30?.message) {
        return;
      }
      if (value30.key?.remoteJid !== value21) {
        return;
      }
      const value31 = getResponseSender(value30);
      if (value21.endsWith("@g.us") && value31 !== value22) {
        return;
      }
      const value32 = (value30.message?.conversation || value30.message?.extendedTextMessage?.text || "").trim();
      if (!/^[1-5]$/.test(value32)) {
        return;
      }
      const value33 = parseInt(value32) - 1;
      const value34 = value23[value33];
      if (!value34) {
        return;
      }
      value15.ev.off("messages.upsert", value28);
      clearTimeout(value35);
      await value15.sendMessage(value21, {
        react: {
          text: "⬇️",
          key: value16.key
        }
      });
      try {
        const value36 = value34.artist + " - " + value34.title;
        const value37 = await downloadSpotify(value36);
        const value38 = path.join(__dirname, "temp");
        if (!fs.existsSync(value38)) {
          fs.mkdirSync(value38);
        }
        const value39 = path.join(value38, "sp_" + Date.now() + ".mp3");
        const value40 = await axios({
          method: "get",
          url: value37.downloadUrl,
          responseType: "stream",
          timeout: 600000
        });
        const value41 = fs.createWriteStream(value39);
        value40.data.pipe(value41);
        await new Promise((value42, value43) => {
          value41.on("finish", value42);
          value41.on("error", value43);
        });
        if (!fs.existsSync(value39) || fs.statSync(value39).size === 0) {
          throw new Error("Download failed — file is empty");
        }
        const value44 = value37.title || value34.title || "";
        const value45 = value44.replace(/[^\w\s.-]/gi, "").substring(0, 100);
        await value15.sendMessage(value21, {
          audio: {
            url: value39
          },
          mimetype: "audio/mpeg"
        }, {
          quoted: value30
        });
        await value15.sendMessage(value21, {
          document: {
            url: value39
          },
          mimetype: "audio/mpeg",
          fileName: value45 + ".mp3",
          caption: "> " + database.getBotSetting("botName")
        }, {
          quoted: value30
        });
        if (fs.existsSync(value39)) {
          fs.unlinkSync(value39);
        }
        await value15.sendMessage(value21, {
          react: {
            text: "✅",
            key: value16.key
          }
        });
      } catch (error46) {
        console.error("[spotify] download error:", error46.message);
        await value15.sendMessage(value21, {
          react: {
            text: "❌",
            key: value16.key
          }
        });
        await value15.sendMessage(value21, {
          text: "🚫 Error: " + error46.message + "\n\n_Try again later._"
        }, {
          quoted: value30
        });
      }
    };
    value15.ev.on("messages.upsert", value28);
    const value35 = setTimeout(() => {
      value15.ev.off("messages.upsert", value28);
      value15.sendMessage(value21, {
        text: "⏳ Selection timed out. Run `.spotify " + value19 + "` again."
      });
    }, SELECTION_TIMEOUT);
  }
};
