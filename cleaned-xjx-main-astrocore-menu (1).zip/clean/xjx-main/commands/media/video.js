const yts = require("yt-search");
const APIs = require("../../utils/api");
module.exports = {
  name: "ytvideo",
  aliases: ["ytv", "ytmp4", "ytvid", "video"],
  category: "media",
  description: "Download video from YouTube",
  usage: ".video <video name or URL>",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value2.key.remoteJid;
      const value6 = value3.join(" ").trim();
      if (!value6) {
        return await value1.sendMessage(value5, {
          text: "🎬 Please provide a video name or YouTube URL."
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "🎬",
          key: value2.key
        }
      });
      const value7 = value6.startsWith("http://") || value6.startsWith("https://");
      let value8 = value6;
      let value9 = value6;
      if (!value7) {
        const {
          videos: value10
        } = await yts(value6);
        if (!value10 || value10.length === 0) {
          return await value1.sendMessage(value5, {
            text: "❌ No videos found for that search."
          }, {
            quoted: value2
          });
        }
        const value11 = value10[0];
        value8 = value11.url;
        value9 = value11.title;
      } else {
        try {
          const value12 = (value8.match(/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/) || [])[1];
          if (value12) {
            const value13 = await yts({
              videoId: value12
            });
            if (value13 && value13.title) {
              value9 = value13.title;
            }
          }
        } catch (error14) {}
      }
      const value15 = value8.match(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch\?v=|v\/|embed\/|shorts\/|playlist\?list=)?)([a-zA-Z0-9_-]{11})/gi);
      if (!value15) {
        return await value1.sendMessage(value5, {
          text: "❌ This is not a valid YouTube link!"
        }, {
          quoted: value2
        });
      }
      const value16 = [() => APIs.getEliteProTechVideoByUrl(value8)];
      let value17 = null;
      for (const value18 of value16) {
        try {
          const value19 = await value18();
          if (value19 && value19.download) {
            value17 = value19;
            break;
          }
        } catch (error20) {
          continue;
        }
      }
      if (!value17 || !value17.download) {
        return await value1.sendMessage(value5, {
          text: "❌ Failed to fetch video. Please try again later."
        }, {
          quoted: value2
        });
      }
      const value21 = value17.title || value9;
      const value22 = value21.replace(/[^\w\s\-()]/g, "").trim() || "video";
      await value1.sendMessage(value5, {
        video: {
          url: value17.download
        },
        mimetype: "video/mp4",
        fileName: value22 + ".mp4",
        caption: value21
      }, {
        quoted: value2
      });
    } catch (error23) {
      console.error("[VIDEO] Command Error:", error23?.message || error23);
      await value1.sendMessage(value2.key.remoteJid, {
        text: "❌ Download failed: " + (error23?.message || "Unknown error")
      }, {
        quoted: value2
      });
    }
  }
};
