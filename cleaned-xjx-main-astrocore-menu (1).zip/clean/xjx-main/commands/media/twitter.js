const axios = require("axios");
const fs = require("fs");
const path = require("path");
const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
const RETRY_DELAY = 3000;
const BASE = "https://api.hostify.indevs.in";
function extractButtonResponseId(value1) {
  return value1.message?.buttonsResponseMessage?.selectedButtonId || value1.message?.templateButtonReplyMessage?.selectedId || value1.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || null;
}
function getResponseSender(value2) {
  return value2.key?.participant || value2.key?.remoteJid;
}
function isTwitterUrl(value3) {
  return /https?:\/\/(www\.)?(twitter\.com|x\.com)\/[^\s]+/i.test(value3);
}
async function withRetry(value4, value5 = 3, value6 = RETRY_DELAY) {
  let value7;
  for (let value8 = 0; value8 < value5; value8++) {
    try {
      return await value4();
    } catch (error9) {
      value7 = error9;
      const value10 = error9.message?.toLowerCase().includes("busy") || error9.message?.toLowerCase().includes("try again");
      if (value8 < value5 - 1 && value10) {
        await new Promise(value11 => setTimeout(value11, value6));
      } else if (!value10) {
        throw error9;
      }
    }
  }
  throw value7;
}
async function fetchTwitterMedia(value12) {
  return withRetry(async () => {
    console.log("[twitter] fetching:", value12);
    const value13 = await axios.get(BASE + "/api/downloader/x", {
      params: {
        url: value12
      },
      timeout: 60000
    });
    if (!value13.data?.success || !value13.data?.result?.success) {
      throw new Error("API returned success: false");
    }
    const value14 = value13.data.result;
    if (!Array.isArray(value14.results) || !value14.results.length) {
      throw new Error("No media found in this tweet");
    }
    console.log("[twitter] found", value14.results.length, "media item(s):", value14.title);
    return {
      title: value14.title || "",
      results: value14.results
    };
  });
}
function getItemButtons(value15, value16) {
  const value17 = database.getBotSetting("prefix") || ".";
  return value15.map((value18, value19) => ({
    id: value17 + "tw_item_" + value19 + "_" + value16,
    text: (value18.type === "video" ? "🎬" : "🖼️") + " " + (value18.type === "video" ? "Video" : "Image") + " #" + value18.id
  }));
}
function getVideoFormatButtons(value20, value21) {
  const value22 = database.getBotSetting("prefix") || ".";
  return [{
    id: value22 + "tw_vfmt_video_" + value20 + "_" + value21,
    text: "🎬 Video"
  }, {
    id: value22 + "tw_vfmt_videodoc_" + value20 + "_" + value21,
    text: "📄 Video Document"
  }];
}
function getImageFormatButtons(value23, value24) {
  const value25 = database.getBotSetting("prefix") || ".";
  return [{
    id: value25 + "tw_ifmt_image_" + value23 + "_" + value24,
    text: "🖼️ Image"
  }, {
    id: value25 + "tw_ifmt_imagedoc_" + value23 + "_" + value24,
    text: "📄 Image Document"
  }];
}
module.exports = {
  name: "twitter",
  aliases: ["tw", "xdl", "twdl", "xdown"],
  category: "media",
  description: "Download Twitter/X videos and images",
  usage: ".twitter <tweet url>",
  async execute(value26, value27, value28, value29) {
    if (!value28.length) {
      return value29.reply("🐦 *Twitter/X Downloader*\n\n*Usage:*\n• `.twitter https://twitter.com/user/status/...` — download media\n• `.twitter https://x.com/user/status/...` — also works\n• Reply to a message with `.twitter` — use replied text as link");
    }
    let value30 = value28.join(" ").trim();
    if (!value30) {
      const value31 = value29?.quoted;
      value30 = value31?.conversation || value31?.extendedTextMessage?.text || "";
    }
    if (!value30) {
      return value29.reply("🐦 Provide a Twitter/X tweet URL.\nExample: `.twitter https://x.com/user/status/123`");
    }
    if (!isTwitterUrl(value30)) {
      return value29.reply("❌ Invalid URL. Please provide a valid Twitter/X tweet link.");
    }
    const value32 = value29.from;
    const value33 = database.getBotSetting("prefix") || ".";
    const value34 = value27.key.participant || value27.key.remoteJid;
    await value26.sendMessage(value32, {
      react: {
        text: "🔍",
        key: value27.key
      }
    });
    let value35;
    try {
      value35 = await fetchTwitterMedia(value30);
    } catch (error36) {
      console.error("[twitter] fetch error:", error36.message);
      return value29.reply("❌ Failed: " + error36.message);
    }
    const {
      title: value37,
      results: value38
    } = value35;
    const value39 = Date.now();
    if (value38.length === 1) {
      const value40 = value38[0];
      const value41 = Date.now();
      const value42 = value40.type === "video";
      await sendButtons(value26, value32, {
        title: "🐦 TWITTER DOWNLOADER",
        text: "⿻ *Tweet:* " + value37.substring(0, 200) + "\n\n" + ("⿻ *Type:* " + (value42 ? "🎬 Video" : "🖼️ Image") + "\n\n") + "*Select how to receive:*",
        footer: "Made by " + database.getBotSetting("botName"),
        buttons: value42 ? getVideoFormatButtons(0, value41) : getImageFormatButtons(0, value41)
      }, {
        quoted: value27
      });
      await value26.sendMessage(value32, {
        react: {
          text: "✅",
          key: value27.key
        }
      });
      const value43 = async value44 => {
        const value45 = value44.messages[0];
        if (!value45?.message) {
          return;
        }
        const value46 = extractButtonResponseId(value45);
        if (!value46) {
          return;
        }
        if (!value46.includes("_0_" + value41)) {
          return;
        }
        if (value45.key?.remoteJid !== value32) {
          return;
        }
        const value47 = getResponseSender(value45);
        if (value32.endsWith("@g.us") && value47 !== value34) {
          return;
        }
        await value26.sendMessage(value32, {
          react: {
            text: "⏬",
            key: value27.key
          }
        });
        try {
          await downloadAndSend({
            sock: value26,
            from: value32,
            msg: value45,
            item: value40,
            title: value37,
            fmtId: value46,
            prefix: value33,
            dateNow: value41
          });
          await value26.sendMessage(value32, {
            react: {
              text: "✅",
              key: value27.key
            }
          });
        } catch (error48) {
          console.error("[twitter] send error:", error48.message);
          await value26.sendMessage(value32, {
            react: {
              text: "❌",
              key: value27.key
            }
          });
          await value26.sendMessage(value32, {
            text: "🚫 Error: " + error48.message + "\n\n_Try again later._"
          }, {
            quoted: value45
          });
        }
      };
      value26.ev.on("messages.upsert", value43);
      return;
    }
    const value49 = value38.map((value50, value51) => "*" + (value51 + 1) + ".* " + (value50.type === "video" ? "🎬 Video" : "🖼️ Image") + " #" + value50.id).join("\n");
    await sendButtons(value26, value32, {
      title: "🐦 TWITTER DOWNLOADER",
      text: "⿻ *Tweet:* " + value37.substring(0, 200) + "\n\n" + (value49 + "\n\n") + "*Select media to download:*",
      footer: "Made by " + database.getBotSetting("botName"),
      buttons: getItemButtons(value38, value39)
    }, {
      quoted: value27
    });
    await value26.sendMessage(value32, {
      react: {
        text: "✅",
        key: value27.key
      }
    });
    const value52 = async value53 => {
      const value54 = value53.messages[0];
      if (!value54?.message) {
        return;
      }
      const value55 = extractButtonResponseId(value54);
      if (!value55) {
        return;
      }
      if (!value55.includes("tw_item_") || !value55.includes("_" + value39)) {
        return;
      }
      if (value54.key?.remoteJid !== value32) {
        return;
      }
      const value56 = getResponseSender(value54);
      if (value32.endsWith("@g.us") && value56 !== value34) {
        return;
      }
      const value57 = value55.replace(value33, "").match(/^tw_item_(\d+)_/);
      if (!value57) {
        return;
      }
      const value58 = parseInt(value57[1]);
      const value59 = value38[value58];
      if (!value59) {
        return;
      }
      const value60 = value59.type === "video";
      const value61 = Date.now();
      await sendButtons(value26, value32, {
        title: "🐦 " + (value60 ? "🎬 VIDEO" : "🖼️ IMAGE") + " — SEND AS",
        text: "⿻ *Type:*  " + (value60 ? "🎬 Video" : "🖼️ Image") + "\n" + ("⿻ *Item:*  #" + value59.id + "\n\n") + "*Select how to receive:*",
        footer: "Made by " + database.getBotSetting("botName"),
        buttons: value60 ? getVideoFormatButtons(value58, value61) : getImageFormatButtons(value58, value61)
      }, {
        quoted: value54
      });
      await value26.sendMessage(value32, {
        react: {
          text: "⬇️",
          key: value27.key
        }
      });
      const value62 = async value63 => {
        const value64 = value63.messages[0];
        if (!value64?.message) {
          return;
        }
        const value65 = extractButtonResponseId(value64);
        if (!value65) {
          return;
        }
        if (!value65.includes("_" + value58 + "_" + value61)) {
          return;
        }
        if (value64.key?.remoteJid !== value32) {
          return;
        }
        const value66 = getResponseSender(value64);
        if (value32.endsWith("@g.us") && value66 !== value34) {
          return;
        }
        await value26.sendMessage(value32, {
          react: {
            text: "⏬",
            key: value27.key
          }
        });
        try {
          await downloadAndSend({
            sock: value26,
            from: value32,
            msg: value64,
            item: value59,
            title: value37,
            fmtId: value65,
            prefix: value33,
            dateNow: value61
          });
          await value26.sendMessage(value32, {
            react: {
              text: "✅",
              key: value27.key
            }
          });
        } catch (error67) {
          console.error("[twitter] download error:", error67.message);
          await value26.sendMessage(value32, {
            react: {
              text: "❌",
              key: value27.key
            }
          });
          await value26.sendMessage(value32, {
            text: "🚫 Error: " + error67.message + "\n\n_Try again later._"
          }, {
            quoted: value64
          });
        }
      };
      value26.ev.on("messages.upsert", value62);
    };
    value26.ev.on("messages.upsert", value52);
  }
};
async function downloadAndSend({
  sock: value68,
  from: value69,
  msg: value70,
  item: value71,
  title: value72,
  fmtId: value73,
  prefix: value74,
  dateNow: value75
}) {
  const value76 = value71.type === "video";
  const value77 = value73.replace(value74, "").split("_");
  const value78 = value77[2];
  const value79 = value76 ? "mp4" : "jpg";
  const value80 = path.join(__dirname, "temp");
  if (!fs.existsSync(value80)) {
    fs.mkdirSync(value80);
  }
  const value81 = path.join(value80, "tw_" + value75 + "." + value79);
  let value82 = value71.url;
  try {
    const value83 = await axios({
      method: "get",
      url: value82,
      responseType: "stream",
      timeout: 600000
    });
    const value84 = fs.createWriteStream(value81);
    value83.data.pipe(value84);
    await new Promise((value85, value86) => {
      value84.on("finish", value85);
      value84.on("error", value86);
    });
  } catch {
    console.warn("[twitter] direct URL failed, trying proxy_link");
    value82 = value71.proxy_link;
    const value87 = await axios({
      method: "get",
      url: value82,
      responseType: "stream",
      timeout: 600000
    });
    const value88 = fs.createWriteStream(value81);
    value87.data.pipe(value88);
    await new Promise((value89, value90) => {
      value88.on("finish", value89);
      value88.on("error", value90);
    });
  }
  if (!fs.existsSync(value81) || fs.statSync(value81).size === 0) {
    throw new Error("Download failed — file is empty");
  }
  const value91 = (value72 || "twitter_media").replace(/[^\w\s.-]/gi, "").substring(0, 80);
  if (value78 === "video") {
    await value68.sendMessage(value69, {
      video: {
        url: value81
      },
      mimetype: "video/mp4",
      caption: "🐦 " + value72.substring(0, 200) + "\n> " + database.getBotSetting("botName")
    }, {
      quoted: value70
    });
  } else if (value78 === "videodoc") {
    await value68.sendMessage(value69, {
      document: {
        url: value81
      },
      mimetype: "video/mp4",
      fileName: value91 + ".mp4",
      caption: "🐦 " + value72.substring(0, 200) + "\n> " + database.getBotSetting("botName")
    }, {
      quoted: value70
    });
  } else if (value78 === "image") {
    await value68.sendMessage(value69, {
      image: {
        url: value81
      },
      caption: "🐦 " + value72.substring(0, 200) + "\n> " + database.getBotSetting("botName")
    }, {
      quoted: value70
    });
  } else if (value78 === "imagedoc") {
    await value68.sendMessage(value69, {
      document: {
        url: value81
      },
      mimetype: "image/jpeg",
      fileName: value91 + ".jpg",
      caption: "🐦 " + value72.substring(0, 200) + "\n> " + database.getBotSetting("botName")
    }, {
      quoted: value70
    });
  }
  if (fs.existsSync(value81)) {
    fs.unlinkSync(value81);
  }
}
