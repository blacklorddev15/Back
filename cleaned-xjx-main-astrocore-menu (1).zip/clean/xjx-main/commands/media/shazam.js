const axios = require("axios");
const FormData = require("form-data");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const {
  sendButtons
} = require("gifted-btns");
const fs = require("fs");
const path = require("path");
const os = require("os");
const {
  exec
} = require("child_process");
const ffmpegPath = require("../../utils/ffmpegPath");
const APIs = require("../../utils/api");
const {
  promisify
} = require("util");
const yts = require("yt-search");
const execAsync = promisify(exec);
function unwrapMessage(value1) {
  let value2 = value1;
  for (let value3 = 0; value3 < 5 && value2; value3++) {
    const value4 = value2.ephemeralMessage?.message || value2.viewOnceMessage?.message || value2.viewOnceMessageV2?.message || value2.viewOnceMessageV2Extension?.message || value2.documentWithCaptionMessage?.message || value2.editedMessage?.message;
    if (!value4) {
      break;
    }
    value2 = value4;
  }
  return value2;
}
function extractButtonResponse(value5) {
  const value6 = unwrapMessage(value5);
  if (!value6) {
    return {
      id: null,
      text: null
    };
  }
  if (value6.buttonsResponseMessage) {
    return {
      id: value6.buttonsResponseMessage.selectedButtonId || null,
      text: value6.buttonsResponseMessage.selectedDisplayText || null
    };
  }
  if (value6.templateButtonReplyMessage) {
    return {
      id: value6.templateButtonReplyMessage.selectedId || null,
      text: value6.templateButtonReplyMessage.selectedDisplayText || null
    };
  }
  if (value6.interactiveResponseMessage) {
    const value7 = value6.interactiveResponseMessage.nativeFlowResponseMessage;
    if (value7?.paramsJson) {
      try {
        const value8 = JSON.parse(value7.paramsJson);
        return {
          id: value8.id || null,
          text: value8.display_text || value6.interactiveResponseMessage.body?.text || null
        };
      } catch {}
    }
    return {
      id: null,
      text: value6.interactiveResponseMessage.body?.text || null
    };
  }
  if (value6.listResponseMessage) {
    return {
      id: value6.listResponseMessage.singleSelectReply?.selectedRowId || null,
      text: value6.listResponseMessage.title || null
    };
  }
  return {
    id: null,
    text: null
  };
}
async function extractAudioClip(value9, value10 = 15) {
  const value11 = path.join(process.cwd(), "tmp", "shazam");
  if (!fs.existsSync(value11)) {
    fs.mkdirSync(value11, {
      recursive: true
    });
  }
  const value12 = Date.now();
  const value13 = path.join(value11, "shazam_in_" + value12 + ".ogg");
  const value14 = path.join(value11, "shazam_out_" + value12 + ".mp3");
  fs.writeFileSync(value13, value9);
  try {
    await execAsync("\"" + ffmpegPath() + "\" -v quiet -nostats -i \"" + value13 + "\" -t " + value10 + " -ar 44100 -ac 1 -b:a 128k -y \"" + value14 + "\"", {
      timeout: 30000
    });
    const value15 = fs.readFileSync(value14);
    try {
      fs.unlinkSync(value13);
    } catch {}
    try {
      fs.unlinkSync(value14);
    } catch {}
    return value15;
  } catch {
    try {
      fs.unlinkSync(value13);
    } catch {}
    return value9;
  }
}
async function identifySong(value16) {
  const value17 = [{
    name: "AudD",
    identify: async value18 => {
      const value19 = value18.toString("base64");
      const value20 = await axios.post("https://api.audd.io/", {
        audio: value19,
        return: "apple_music,spotify",
        api_token: "test"
      }, {
        timeout: 30000
      });
      if (value20.data?.status === "success" && value20.data?.result) {
        const value21 = value20.data.result;
        return {
          title: value21.title || "Unknown",
          artist: value21.artist || "Unknown",
          album: value21.album || "",
          releaseDate: value21.release_date || "",
          label: value21.label || "",
          timecode: value21.timecode || "",
          songLink: value21.song_link || "",
          spotify: value21.spotify?.external_urls?.spotify || "",
          appleMusic: value21.apple_music?.url || ""
        };
      }
      return null;
    }
  }, {
    name: "Keith Shazam",
    identify: async value22 => {
      const value23 = new FormData();
      value23.append("file", value22, {
        filename: "audio.mp3",
        contentType: "audio/mpeg"
      });
      const value24 = await axios.post("https://apiskeith2-production-ec66.up.railway.app/ai/shazam", value23, {
        headers: value23.getHeaders(),
        timeout: 30000
      });
      const value25 = value24.data?.result || value24.data;
      if (value25 && (value25.title || value25.track)) {
        return {
          title: value25.title || value25.track?.title || "Unknown",
          artist: value25.artist || value25.track?.subtitle || "Unknown",
          album: value25.album || value25.track?.sections?.[0]?.metadata?.[0]?.text || "",
          releaseDate: value25.release_date || "",
          label: value25.label || "",
          songLink: value25.url || value25.track?.url || "",
          spotify: "",
          appleMusic: ""
        };
      }
      return null;
    }
  }, {
    name: "Ryzen Shazam",
    identify: async value26 => {
      const value27 = new FormData();
      value27.append("file", value26, {
        filename: "audio.mp3",
        contentType: "audio/mpeg"
      });
      const value28 = await axios.post("https://api.ryzendesu.vip/api/ai/shazam", value27, {
        headers: value27.getHeaders(),
        timeout: 30000
      });
      const value29 = value28.data?.result || value28.data;
      if (value29 && (value29.title || value29.track)) {
        return {
          title: value29.title || value29.track?.title || "Unknown",
          artist: value29.artist || value29.track?.subtitle || "Unknown",
          album: value29.album || "",
          releaseDate: "",
          label: "",
          songLink: value29.url || "",
          spotify: "",
          appleMusic: ""
        };
      }
      return null;
    }
  }];
  for (const value30 of value17) {
    try {
      const value31 = await value30.identify(value16);
      if (value31) {
        return value31;
      }
    } catch (error32) {
      console.log("[SHAZAM] " + value30.name + " failed: " + error32.message);
    }
  }
  return null;
}
function resolveQuotedMsg(value33) {
  const value34 = unwrapMessage(value33.message) || {};
  const value35 = value34.extendedTextMessage?.contextInfo || value34.audioMessage?.contextInfo || value34.videoMessage?.contextInfo;
  if (!value35?.quotedMessage) {
    return null;
  }
  return {
    key: {
      remoteJid: value33.key.remoteJid,
      id: value35.stanzaId,
      participant: value35.participant
    },
    message: value35.quotedMessage
  };
}
function getMediaType(value36) {
  const value37 = unwrapMessage(value36?.message) || {};
  if (value37.audioMessage) {
    return {
      type: "audio",
      ext: "ogg"
    };
  }
  if (value37.videoMessage) {
    return {
      type: "video",
      ext: "mp4"
    };
  }
  return null;
}
async function searchYouTube(value38) {
  const value39 = await yts(value38 + " official audio");
  if (!value39?.videos?.length) {
    throw new Error("No YouTube results found");
  }
  return value39.videos[0];
}
async function downloadAudio(value40) {
  const value41 = [{
    name: "Izumi",
    fn: APIs.getIzumiDownloadByUrl
  }, {
    name: "EliteProTech",
    fn: APIs.getEliteProTechDownloadByUrl
  }];
  let value42;
  for (const value43 of value41) {
    try {
      const value44 = await value43.fn(value40);
      if (value44?.download) {
        return {
          result: value44.download,
          title: value44.title
        };
      }
    } catch (error45) {
      value42 = error45;
      console.log("[SHAZAM] " + value43.name + " download failed: " + error45.message);
    }
  }
  throw new Error(value42?.message || "All download APIs failed");
}
module.exports = {
  name: "shazam",
  aliases: ["whatsong", "findsong", "identify", "musicid"],
  category: "media",
  description: "Identify a song from audio. Reply to audio/voice note or search by name.",
  usage: ".shazam — reply to audio  |  .shazam <song name> — text search",
  async execute(value46, value47, value48, value49) {
    const value50 = value49.from;
    if (value48.length > 0) {
      const value51 = value48.join(" ");
      await value46.sendMessage(value50, {
        react: {
          text: "🔍",
          key: value47.key
        }
      });
      try {
        const value52 = await yts(value51);
        if (!value52?.videos?.length) {
          return value49.reply("❌ No results found for *\"" + value51 + "\"*");
        }
        const value53 = value52.videos.slice(0, 5);
        let value54 = "🎵 *Search Results for:* \"" + value51 + "\"\n\n";
        value53.forEach((value55, value56) => {
          value54 += value56 + 1 + ". *" + value55.title + "*\n";
          value54 += "   👤 " + value55.author.name + "\n";
          value54 += "   ⏱️ " + value55.timestamp + " | 👁️ " + (value55.views?.toLocaleString() || "N/A") + "\n";
          value54 += "   🔗 " + value55.url + "\n\n";
        });
        await value46.sendMessage(value50, {
          text: value54
        }, {
          quoted: value47
        });
        await value46.sendMessage(value50, {
          react: {
            text: "✅",
            key: value47.key
          }
        });
      } catch (error57) {
        await value46.sendMessage(value50, {
          react: {
            text: "❌",
            key: value47.key
          }
        });
        await value49.reply("❌ Search failed: " + error57.message);
      }
      return;
    }
    let value58 = value47;
    let value59 = getMediaType(value47);
    if (!value59) {
      const value60 = resolveQuotedMsg(value47);
      if (value60) {
        value59 = getMediaType(value60);
        if (value59) {
          value58 = value60;
        }
      }
    }
    if (!value59) {
      return value49.reply("🎵 *SHAZAM* \n⏭️ *.shazam* Reply to audio/video to identify\n⚡ *.shazam <song name>* Search by text\n🌠 *🎵 Powered by SHAZAM*");
    }
    await value46.sendMessage(value50, {
      react: {
        text: "⏳",
        key: value47.key
      }
    });
    try {
      const value61 = await downloadMediaMessage(value58, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value46.updateMediaMessage
      });
      if (!value61 || value61.length === 0) {
        throw new Error("Failed to download media");
      }
      await value46.sendMessage(value50, {
        react: {
          text: "📥",
          key: value47.key
        }
      });
      const value62 = await extractAudioClip(value61, 15);
      const value63 = await identifySong(value62);
      if (!value63) {
        await value46.sendMessage(value50, {
          react: {
            text: "❌",
            key: value47.key
          }
        });
        return value49.reply("❌ *Song not identified*\n\nCould not recognize this audio.\n\n*Tips:*\n• Use clear audio (not distorted)\n• 10–15 seconds of the main melody\n• Avoid excessive background noise");
      }
      let value64 = "🎶 *Song Identified!*\n\n";
      value64 += "📝 *Title:*    " + value63.title + "\n";
      value64 += "🎤 *Artist:*   " + value63.artist + "\n";
      if (value63.album) {
        value64 += "💿 *Album:*    " + value63.album + "\n";
      }
      if (value63.releaseDate) {
        value64 += "📅 *Released:* " + value63.releaseDate + "\n";
      }
      if (value63.label) {
        value64 += "🏷️ *Label:*    " + value63.label + "\n";
      }
      if (value63.timecode) {
        value64 += "⏱️ *Timecode:* " + value63.timecode + "\n";
      }
      await value46.sendMessage(value50, {
        react: {
          text: "✅",
          key: value47.key
        }
      });
      console.log("[SHAZAM] Identified: " + value63.artist + " - " + value63.title);
      const value65 = Date.now();
      const value66 = encodeURIComponent(value63.title + " " + value63.artist);
      const value67 = "https://www.youtube.com/results?search_query=" + value66;
      const value68 = "shazam_play_" + value65;
      const value69 = "▶️ Play";
      const value70 = [{
        id: value68,
        text: value69
      }, {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: "▶️ YouTube Search",
          url: value67
        })
      }];
      try {
        await sendButtons(value46, value50, {
          text: value64,
          footer: "🎵 Powered by Shazam",
          buttons: value70
        }, {
          quoted: value47
        });
      } catch (error71) {
        let value72 = value64;
        value72 += "\n🔗 *YouTube:* " + value67;
        value72 += "\n\n▶️ *To download:* `.play " + value63.title + " " + value63.artist + "`";
        await value46.sendMessage(value50, {
          text: value72
        }, {
          quoted: value47
        });
      }
      let value73 = false;
      let value74;
      const value75 = async value76 => {
        if (value73) {
          return;
        }
        const value77 = value76?.messages || [];
        for (const value78 of value77) {
          if (!value78?.message) {
            continue;
          }
          const {
            id: value79,
            text: value80
          } = extractButtonResponse(value78.message);
          if (!value79 && !value80) {
            continue;
          }
          console.log("[SHAZAM] tap id=" + value79 + " text=" + value80);
          const value81 = value79 === value68 || !value79 && value80 === value69;
          if (!value81) {
            continue;
          }
          value73 = true;
          value46.ev.off("messages.upsert", value75);
          clearTimeout(value74);
          await value46.sendMessage(value50, {
            react: {
              text: "🔍",
              key: value47.key
            }
          });
          let value82;
          try {
            const value83 = value63.title + " " + value63.artist;
            const value84 = await searchYouTube(value83);
            await value46.sendMessage(value50, {
              react: {
                text: "⬇️",
                key: value47.key
              }
            });
            const value85 = await downloadAudio(value84.url);
            value82 = path.join(os.tmpdir(), "shazam_play_" + value65 + ".mp3");
            const value86 = await axios({
              method: "get",
              url: value85.result,
              responseType: "stream",
              timeout: 600000
            });
            const value87 = fs.createWriteStream(value82);
            value86.data.pipe(value87);
            await new Promise((value88, value89) => {
              value87.on("finish", value88);
              value87.on("error", value89);
            });
            if (!fs.existsSync(value82) || fs.statSync(value82).size === 0) {
              throw new Error("Download failed — file is empty");
            }
            await value46.sendMessage(value50, {
              react: {
                text: "📤",
                key: value47.key
              }
            });
            await value46.sendMessage(value50, {
              audio: fs.readFileSync(value82),
              mimetype: "audio/mpeg"
            }, {
              quoted: value78
            });
            await value46.sendMessage(value50, {
              react: {
                text: "✅",
                key: value47.key
              }
            });
          } catch (error90) {
            console.error("[SHAZAM play]", error90.message);
            await value46.sendMessage(value50, {
              react: {
                text: "❌",
                key: value47.key
              }
            });
            await value46.sendMessage(value50, {
              text: "❌ Download failed: " + error90.message + "\n\n_Try: `.play " + value63.title + " " + value63.artist + "`_"
            }, {
              quoted: value78
            });
          } finally {
            if (value82 && fs.existsSync(value82)) {
              try {
                fs.unlinkSync(value82);
              } catch {}
            }
          }
          return;
        }
      };
      value46.ev.on("messages.upsert", value75);
      value74 = setTimeout(() => {
        value46.ev.off("messages.upsert", value75);
      }, 600000);
    } catch (error91) {
      await value46.sendMessage(value50, {
        react: {
          text: "❌",
          key: value47.key
        }
      });
      let value92 = "Failed to identify the song.";
      if (error91.message?.includes("download") || error91.message?.includes("media")) {
        value92 = "Failed to download media. Try again in a moment.";
      } else if (error91.code === "ECONNABORTED" || error91.message?.includes("timeout")) {
        value92 = "Request timed out. Try a shorter or clearer clip.";
      } else if (error91.response?.status === 404) {
        value92 = "Song not found in the Shazam database.";
      } else if (error91.response?.status >= 500) {
        value92 = "Shazam service is temporarily unavailable.";
      }
      await value49.reply("❌ *Shazam Error*\n\n" + value92);
    }
  }
};
