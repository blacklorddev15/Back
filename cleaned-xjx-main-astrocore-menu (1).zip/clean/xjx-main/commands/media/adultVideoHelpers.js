const axios = require("axios");
const GIFTED_BASE = "https://api.giftedtech.co.ke/api";
const USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36";
function getInput(value1, value2) {
  return value2.join(" ").trim() || value1.quoted?.text?.trim() || value1.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation?.trim() || "";
}
function isHttpUrl(value3) {
  return /^https?:\/\//i.test(value3);
}
function formatDuration(value4) {
  const value5 = parseInt(value4, 10);
  if (Number.isNaN(value5)) {
    return value4 || "N/A";
  }
  return Math.floor(value5 / 60) + "m " + value5 % 60 + "s";
}
function safeFileName(value6, value7) {
  const value8 = String(value6 || value7).replace(/[^a-zA-Z0-9 ]/g, "").trim().slice(0, 50);
  return (value8 || value7) + ".mp4";
}
const MAX_VIDEO_BYTES = 67108864;
async function downloadVideoBuffer(value9, value10 = 120000) {
  const value11 = await axios.get(value9, {
    responseType: "arraybuffer",
    timeout: value10,
    maxRedirects: 5,
    maxContentLength: MAX_VIDEO_BYTES,
    maxBodyLength: MAX_VIDEO_BYTES,
    headers: {
      "User-Agent": USER_AGENT,
      Accept: "video/mp4,video/*;q=0.9,*/*;q=0.8"
    }
  });
  const value12 = Buffer.from(value11.data);
  if (value12.length < 5000) {
    throw new Error("Received invalid or empty video data");
  }
  if (value12.length > MAX_VIDEO_BYTES) {
    throw new Error("The video is larger than the 64 MB WhatsApp limit");
  }
  return value12;
}
async function fetchXvideos(value13) {
  const value14 = await axios.get(GIFTED_BASE + "/download/xvideosdl", {
    params: {
      apikey: "gifted",
      url: value13
    },
    timeout: 30000
  });
  const value15 = value14.data?.result;
  if (!value14.data?.success || !value15?.download_url) {
    return null;
  }
  return {
    title: value15.title,
    downloadUrl: value15.download_url
  };
}
async function fetchXhamster(value16) {
  const value17 = await axios.get(GIFTED_BASE + "/download/xhamsterdl", {
    params: {
      apikey: "gifted",
      url: value16
    },
    timeout: 30000
  });
  const value18 = value17.data?.result || value17.data?.data || {};
  const value19 = value18.download_url || value18.url || value18.hd || value18.sd;
  if (!value17.data?.success || !value19) {
    return null;
  }
  return {
    title: value18.title,
    downloadUrl: value19
  };
}
async function searchXvideos(value20) {
  const value21 = await axios.get(GIFTED_BASE + "/search/xvideossearch", {
    params: {
      apikey: "gifted",
      query: value20
    },
    timeout: 20000
  });
  return value21.data?.success && value21.data?.results?.[0] || null;
}
module.exports = {
  getInput: getInput,
  isHttpUrl: isHttpUrl,
  safeFileName: safeFileName,
  downloadVideoBuffer: downloadVideoBuffer,
  fetchXvideos: fetchXvideos,
  fetchXhamster: fetchXhamster,
  searchXvideos: searchXvideos
};
