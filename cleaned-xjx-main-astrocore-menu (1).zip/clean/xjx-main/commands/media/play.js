const yts = require("yt-search");
const APIs = require("../../utils/api");
module.exports = {
  name: "play2",
  aliases: ["song2", "yta2"],
  category: "media",
  description: "Download audio from YouTube (audio format)",
  usage: ".play2 <song name or URL>",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      const value6 = value3.join(" ").trim();
      if (!value6) {
        return await value1.sendMessage(value5, {
          text: "🎵 Please provide a song name or YouTube URL."
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "🎼",
          key: value2.key
        }
      });
      const value7 = value6.startsWith("http://") || value6.startsWith("https://");
      let value8 = value6;
      let value9 = value6;
      let value10 = "";
      let value11 = "";
      let value12 = "";
      let value13 = "";
      if (!value7) {
        const {
          videos: value14
        } = await yts(value6);
        if (!value14 || value14.length === 0) {
          return await value1.sendMessage(value5, {
            text: "❌ No songs found for that search."
          }, {
            quoted: value2
          });
        }
        const value15 = value14[0];
        value8 = value15.url;
        value9 = value15.title;
        value10 = value15.timestamp || "";
        value11 = value15.views ? value15.views.toLocaleString() : "";
        value12 = value15.thumbnail || "";
        value13 = value15.author?.name || "";
      } else {
        try {
          const value16 = (value8.match(/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/) || [])[1];
          if (value16) {
            const value17 = await yts({
              videoId: value16
            });
            if (value17 && value17.title) {
              value9 = value17.title;
              value10 = value17.timestamp || "";
              value11 = value17.views ? value17.views.toLocaleString() : "";
              value12 = value17.thumbnail || "";
              value13 = value17.author?.name || "";
            }
          }
        } catch (error18) {}
      }
      const value19 = [() => APIs.getIzumiDownloadByUrl(value8), () => APIs.getEliteProTechDownloadByUrl(value8), () => APIs.getIzumiDownloadByQuery(value6)];
      let value20 = null;
      for (const value21 of value19) {
        try {
          const value22 = await value21();
          if (value22 && value22.download) {
            value20 = value22;
            break;
          }
        } catch (error23) {
          continue;
        }
      }
      if (!value20 || !value20.download) {
        return await value1.sendMessage(value5, {
          text: "❌ Failed to fetch audio. Please try again later."
        }, {
          quoted: value2
        });
      }
      const value24 = value20.title || value9;
      await value1.sendMessage(value5, {
        text: "_" + value24 + "_"
      });
      await value1.sendMessage(value5, {
        audio: {
          url: value20.download
        },
        mimetype: "audio/mpeg",
        ptt: false
      }, {
        quoted: value2
      });
    } catch (error25) {
      console.error("Error in play2/song2 command:", error25);
      await value1.sendMessage(value2.key.remoteJid, {
        text: "❌ Download failed. Please try again later."
      }, {
        quoted: value2
      });
    }
  }
};
