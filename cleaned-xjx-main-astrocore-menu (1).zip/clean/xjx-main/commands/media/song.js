const yts = require("yt-search");
const APIs = require("../../utils/api");
module.exports = {
  name: "play",
  aliases: ["song", "yta"],
  category: "media",
  description: "Download audio from YouTube",
  usage: ".play <song name or URL>",
  async execute(value1, value2, value3, value4) {
    try {
      const value5 = value4.from;
      const value6 = value3.join(" ").trim();
      if (!value6) {
        return await value1.sendMessage(value5, {
          text: "🎵 Please provide a song name or YouTube URL."
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "🎼",
          key: value2.key
        }
      });
      const value7 = value6.startsWith("http://") || value6.startsWith("https://");
      let value8 = value6;
      let value9 = value6;
      if (!value7) {
        const {
          videos: value10
        } = await yts(value6);
        if (!value10 || value10.length === 0) {
          return await value1.sendMessage(value5, {
            text: "❌ No songs found for that search."
          }, {
            quoted: value2
          });
        }
        const value11 = value10[0];
        value8 = value11.url;
        value9 = value11.title;
      } else {
        try {
          const value12 = (value8.match(/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/) || [])[1];
          if (value12) {
            const value13 = await yts({
              videoId: value12
            });
            if (value13 && value13.title) {
              value9 = value13.title;
            }
          }
        } catch (error14) {}
      }
      const value15 = [() => APIs.getIzumiDownloadByUrl(value8), () => APIs.getEliteProTechDownloadByUrl(value8), () => APIs.getIzumiDownloadByQuery(value6)];
      let value16 = null;
      for (const value17 of value15) {
        try {
          const value18 = await value17();
          if (value18 && value18.download) {
            value16 = value18;
            break;
          }
        } catch (error19) {
          continue;
        }
      }
      if (!value16 || !value16.download) {
        return await value1.sendMessage(value5, {
          text: "❌ Failed to fetch audio. Please try again later."
        }, {
          quoted: value2
        });
      }
      const value20 = value9 || value16.title || "Unknown Title";
      const value21 = value20.replace(/[^\w\s\-()]/g, "").trim() || "audio";
      await value1.sendMessage(value5, {
        text: "_" + value20 + "_"
      });
      await value1.sendMessage(value5, {
        audio: {
          url: value16.download
        },
        mimetype: "audio/mpeg",
        fileName: value21 + ".mp3",
        ptt: false
      }, {
        quoted: value2
      });
      await value1.sendMessage(value5, {
        document: {
          url: value16.download
        },
        mimetype: "audio/mpeg",
        fileName: value21 + ".mp3"
      }, {
        quoted: value2
      });
    } catch (error22) {
      console.error("Error in play/song command:", error22);
      await value1.sendMessage(value2.key.remoteJid, {
        text: "❌ Download failed. Please try again later."
      }, {
        quoted: value2
      });
    }
  }
};
