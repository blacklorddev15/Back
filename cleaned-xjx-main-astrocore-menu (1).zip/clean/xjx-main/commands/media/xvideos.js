const database = require("../../database");
const {
  getInput,
  isHttpUrl,
  safeFileName,
  downloadVideoBuffer,
  fetchXvideos,
  searchXvideos
} = require("./adultVideoHelpers");
module.exports = {
  name: "xvideos",
  aliases: ["xvdl", "xnxx", "xvid"],
  category: "media",
  description: "Download or search XVideos videos",
  usage: (database.getBotSetting("prefix") || ".") + "xvideos <URL or name>",
  async execute(value1, value2, value3, value4 = {}) {
    const value5 = value2.key.remoteJid;
    const value6 = getInput(value2, value3);
    if (!value6) {
      return value1.sendMessage(value5, {
        text: "Usage: " + (value4.prefix || database.getBotSetting("prefix") || ".") + "xvideos <URL or name>"
      }, {
        quoted: value2
      });
    }
    try {
      let value7 = value6;
      let value8;
      if (!isHttpUrl(value6)) {
        const value9 = await searchXvideos(value6);
        if (!value9?.url) {
          return value1.sendMessage(value5, {
            text: "No XVideos result was found."
          }, {
            quoted: value2
          });
        }
        value7 = value9.url;
      }
      const value10 = await fetchXvideos(value7);
      if (!value10?.downloadUrl) {
        return value1.sendMessage(value5, {
          text: "No downloadable XVideos video was found for that URL."
        }, {
          quoted: value2
        });
      }
      value8 = value10.title;
      const value11 = await downloadVideoBuffer(value10.downloadUrl);
      await value1.sendMessage(value5, {
        video: value11,
        caption: (value8 || "XVideos video") + "\n" + (database.getBotSetting("botName") || "JuneX-Ultra"),
        mimetype: "video/mp4",
        fileName: safeFileName(value8, "xvideos")
      }, {
        quoted: value2
      });
    } catch (error12) {
      console.error("[XVIDEOS] Download error:", error12);
      await value1.sendMessage(value5, {
        text: "Download failed: " + (error12.message || "Unknown error")
      }, {
        quoted: value2
      });
    }
  }
};
