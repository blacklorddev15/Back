const axios = require("axios");
const yts = require("yt-search");
const fs = require("fs");
const path = require("path");
const os = require("os");
const database = require("../../database");
module.exports = {
  name: "video3",
  aliases: ["vid3", "ytv3", "mp4doc"],
  category: "media",
  description: "Download a YouTube video and send as document (MP4)",
  usage: ".video3 <youtube url or search>",
  ownerOnly: false,
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    const value6 = value3.join(" ").trim();
    if (!value6) {
      return value4.reply("Usage: " + (database.getBotSetting("prefix") || ".") + "video3 <youtube url or search>");
    }
    await value4.react("⏳");
    let value7;
    try {
      const value8 = await yts(value6);
      const value9 = value8?.videos?.[0];
      if (!value9) {
        throw new Error("No results found for that query");
      }
      const {
        title: value10,
        url: value11
      } = value9;
      const value12 = "https://apiskeith2-production-3020.up.railway.app/download/video?url=" + encodeURIComponent(value11) + "&quality=best";
      const {
        data: value13
      } = await axios.get(value12, {
        timeout: 30000
      });
      const value14 = value13?.result;
      if (!value14) {
        throw new Error("API did not return a download URL");
      }
      value7 = path.join(os.tmpdir(), "video3-" + Date.now() + ".mp4");
      const {
        data: value15
      } = await axios.get(value14, {
        responseType: "stream",
        timeout: 180000,
        maxRedirects: 5
      });
      await new Promise((value16, value17) => {
        const value18 = fs.createWriteStream(value7);
        value15.pipe(value18);
        value18.on("finish", value16);
        value18.on("error", value17);
        value15.on("error", value17);
      });
      const value19 = fs.statSync(value7);
      if (!value19 || value19.size === 0) {
        throw new Error("Download failed — file is empty");
      }
      const value20 = value10.replace(/[<>:"/\\|?*]/g, "").trim().slice(0, 80);
      await value1.sendMessage(value5, {
        document: fs.readFileSync(value7),
        mimetype: "video/mp4",
        fileName: value20 + ".mp4"
      }, {
        quoted: value2
      });
      await value4.react("✅");
    } catch (error21) {
      console.error("[video3]", error21.message);
      await value4.react("❌");
      await value4.reply("❌ " + error21.message);
    } finally {
      try {
        if (value7 && fs.existsSync(value7)) {
          fs.unlinkSync(value7);
        }
      } catch {}
    }
  }
};
