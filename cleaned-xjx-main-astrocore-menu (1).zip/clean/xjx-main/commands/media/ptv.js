const fs = require("fs");
const path = require("path");
const {
  execFile
} = require("child_process");
const {
  downloadMediaMessage
} = require("@whiskeysockets/baileys");
const ffmpegPath = require("../../utils/ffmpegPath");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const MAX_DURATION = 60;
const SIZE = 480;
function probeDuration(value1) {
  return new Promise(value2 => {
    execFile(ffmpegPath(), ["-i", value1], (value3, value4, value5) => {
      const value6 = (value5 || "").match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
      if (!value6) {
        return value2(0);
      }
      value2(+value6[1] * 3600 + +value6[2] * 60 + parseFloat(value6[3]));
    });
  });
}
module.exports = {
  name: "ptv",
  aliases: ["videonote", "vn", "tovideonote", "circlevid"],
  category: "media",
  description: "Convert a video to a WhatsApp video note (round/PTV)",
  usage: ".ptv  (reply to a video, gif, or sticker)",
  async execute(value7, value8, value9, value10) {
    const value11 = value10?.from || value8.key.remoteJid;
    const value12 = Date.now();
    const value13 = path.join(getTempDir(), "ptv_in_" + value12 + ".tmp");
    const value14 = path.join(getTempDir(), "ptv_out_" + value12 + ".mp4");
    try {
      await value7.sendMessage(value11, {
        react: {
          text: "🎥",
          key: value8.key
        }
      });
      const value15 = value8.message?.extendedTextMessage?.contextInfo;
      const value16 = value15?.quotedMessage;
      const value17 = value8.message?.videoMessage;
      const value18 = value16?.videoMessage;
      const value19 = value18?.gifPlayback ? value18 : null;
      const value20 = value18 ? {
        key: {
          remoteJid: value15.remoteJid || value11,
          fromMe: false,
          id: value15.stanzaId,
          participant: value15.participant
        },
        message: value16
      } : value17 ? value8 : null;
      if (!value20) {
        await value7.sendMessage(value11, {
          react: {
            text: "❌",
            key: value8.key
          }
        });
        return value7.sendMessage(value11, {
          text: "❌ Reply to a *video* (or gif) with `.ptv` to convert it to a video note."
        }, {
          quoted: value8
        });
      }
      const value21 = await downloadMediaMessage(value20, "buffer", {}, {
        logger: undefined,
        reuploadRequest: value7.updateMediaMessage
      });
      if (!value21 || value21.length === 0) {
        throw new Error("Failed to download the video.");
      }
      fs.writeFileSync(value13, value21);
      const value22 = await probeDuration(value13);
      const value23 = value22 > MAX_DURATION ? ["-t", String(MAX_DURATION)] : [];
      const value24 = "scale=" + SIZE + ":" + SIZE + ":force_original_aspect_ratio=increase,crop=" + SIZE + ":" + SIZE;
      const value25 = ["-y", "-i", value13, ...value23, "-vf", value24, "-c:v", "libx264", "-preset", "veryfast", "-crf", "28", "-pix_fmt", "yuv420p", "-r", "30", "-c:a", "aac", "-b:a", "96k", "-ac", "2", "-ar", "44100", "-movflags", "+faststart", "-f", "mp4", value14];
      await new Promise((value26, value27) => {
        execFile(ffmpegPath(), value25, (value28, value29, value30) => {
          if (value28) {
            const value31 = (value30 || "").split("\n").slice(-4).join(" ").trim();
            return value27(new Error("FFmpeg failed: " + (value31 || value28.message)));
          }
          value26();
        });
      });
      if (!fs.existsSync(value14) || fs.statSync(value14).size === 0) {
        throw new Error("Conversion produced an empty file.");
      }
      const value32 = fs.readFileSync(value14);
      await value7.sendMessage(value11, {
        video: value32,
        ptv: true,
        mimetype: "video/mp4"
      }, {
        quoted: value8
      });
      await value7.sendMessage(value11, {
        react: {
          text: "✅",
          key: value8.key
        }
      });
    } catch (error33) {
      console.error("[PTV] Error:", error33);
      await value7.sendMessage(value11, {
        react: {
          text: "❌",
          key: value8.key
        }
      });
      await value7.sendMessage(value11, {
        text: "🚫 PTV error: " + error33.message
      }, {
        quoted: value8
      });
    } finally {
      [value13, value14].forEach(value34 => {
        try {
          if (fs.existsSync(value34)) {
            fs.unlinkSync(value34);
          }
        } catch (error35) {}
      });
    }
  }
};
