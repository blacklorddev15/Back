const {
  igdl
} = require("ruhend-scraper");
const database = require("../../database");
const processedMessages = new Set();
function extractUniqueMedia(value1) {
  const value2 = [];
  const value3 = new Set();
  for (const value4 of value1) {
    if (!value4.url) {
      continue;
    }
    if (!value3.has(value4.url)) {
      value3.add(value4.url);
      value2.push(value4);
    }
  }
  return value2;
}
function isValidMediaUrl(value5) {
  if (!value5 || typeof value5 !== "string") {
    return false;
  }
  return value5.includes("cdninstagram.com") || value5.includes("instagram") || value5.includes("http");
}
module.exports = {
  name: "instagram",
  aliases: ["ig", "insta", "igdl", "reels"],
  category: "media",
  description: "Download Instagram photos/videos/reels",
  usage: "<Instagram URL>",
  async execute(value6, value7, value8, value9) {
    try {
      const value10 = value9.from;
      if (processedMessages.has(value7.key.id)) {
        return;
      }
      processedMessages.add(value7.key.id);
      setTimeout(() => {
        processedMessages.delete(value7.key.id);
      }, 300000);
      const value11 = value7.message?.conversation || value7.message?.extendedTextMessage?.text || value8.join(" ");
      if (!value11) {
        return value9.reply("Please provide an Instagram link for the video.");
      }
      const value12 = [/https?:\/\/(?:www\.)?instagram\.com\//, /https?:\/\/(?:www\.)?instagr\.am\//, /https?:\/\/(?:www\.)?instagram\.com\/p\//, /https?:\/\/(?:www\.)?instagram\.com\/reel\//, /https?:\/\/(?:www\.)?instagram\.com\/tv\//];
      const value13 = value12.some(value14 => value14.test(value11));
      if (!value13) {
        return value9.reply("That is not a valid Instagram link. Please provide a valid Instagram post, reel, or video link.");
      }
      await value6.sendMessage(value10, {
        react: {
          text: "📥",
          key: value7.key
        }
      });
      const value15 = await igdl(value11);
      if (!value15 || !value15.data || value15.data.length === 0) {
        return value9.reply("❌ No media found at the provided link. The post might be private or the link is invalid.");
      }
      const value16 = value15.data;
      const value17 = extractUniqueMedia(value16);
      const value18 = value17.slice(0, 20);
      if (value18.length === 0) {
        return value9.reply("❌ No valid media found to download. This might be a private post or the scraper failed.");
      }
      for (let value19 = 0; value19 < value18.length; value19++) {
        try {
          const value20 = value18[value19];
          const value21 = value20.url;
          const value22 = /\.(mp4|mov|avi|mkv|webm)$/i.test(value21) || value20.type === "video" || value11.includes("/reel/") || value11.includes("/tv/");
          if (value22) {
            await value6.sendMessage(value10, {
              video: {
                url: value21
              },
              mimetype: "video/mp4",
              caption: "*DOWNLOADED BY " + database.getBotSetting("botName").toUpperCase() + "*"
            }, {
              quoted: value7
            });
          } else {
            await value6.sendMessage(value10, {
              image: {
                url: value21
              },
              caption: "*DOWNLOADED BY " + database.getBotSetting("botName").toUpperCase() + "*"
            }, {
              quoted: value7
            });
          }
          if (value19 < value18.length - 1) {
            await new Promise(value23 => setTimeout(value23, 1000));
          }
        } catch (error24) {
          console.error("Error downloading media " + (value19 + 1) + ":", error24);
        }
      }
    } catch (error25) {
      console.error("Error in Instagram command:", error25);
      await value9.reply("❌ An error occurred while processing the Instagram request. Please try again.");
    }
  }
};
