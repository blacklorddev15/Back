const yts = require("yt-search");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
const RETRY_DELAY = 3000;
function extractButtonResponseId(value1) {
  return value1.message?.buttonsResponseMessage?.selectedButtonId || value1.message?.templateButtonReplyMessage?.selectedId || value1.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || null;
}
function getResponseSender(value2) {
  return value2.key?.participant || value2.key?.remoteJid;
}
async function withRetry(value3, value4 = 3, value5 = RETRY_DELAY) {
  let value6;
  for (let value7 = 0; value7 < value4; value7++) {
    try {
      return await value3();
    } catch (error8) {
      value6 = error8;
      const value9 = error8.message?.toLowerCase().includes("busy") || error8.message?.toLowerCase().includes("try again");
      if (value7 < value4 - 1 && value9) {
        await new Promise(value10 => setTimeout(value10, value5));
      } else if (!value9) {
        throw error8;
      }
    }
  }
  throw value6;
}
async function searchYouTube(value11) {
  return withRetry(async () => {
    const value12 = await yts(value11 + " official");
    if (!value12?.videos?.length) {
      throw new Error("No results found");
    }
    return value12.videos[0];
  });
}
async function downloadVideo(value13) {
  return withRetry(async () => {
    const value14 = await axios.get("https://apissupreme.vercel.app/media/ytmp4?apikey=supreme&url=" + encodeURIComponent(value13), {
      timeout: 60000
    });
    if (!value14.data?.status) {
      throw new Error("TKM API failed to fetch video");
    }
    return {
      result: value14.data.downloadUrl,
      title: value14.data.title
    };
  });
}
function getVideoButtons(value15, value16) {
  const value17 = database.getBotSetting("prefix") || ".";
  return [{
    id: value17 + "video_" + value15 + "_" + value16,
    text: "🎬 Video"
  }, {
    id: value17 + "videodoc_" + value15 + "_" + value16,
    text: "📄 Video Document"
  }];
}
module.exports = {
  name: "video2",
  aliases: ["ytvideo2", "mp42", "ytv2"],
  category: "media",
  description: "Search and download YouTube videos as MP4",
  usage: ".ytmp4 <video name>",
  async execute(value18, value19, value20, value21) {
    if (!value20.length) {
      return value21.reply("🎬 *YouTube Video Downloader*\n\n*Usage:*\n• `.ytmp4 not like us` — search + download\n• Reply to a message with `.ytmp4` — use replied text as query");
    }
    let value22 = value20.join(" ").trim();
    if (!value22) {
      const value23 = value21?.quoted;
      value22 = value23?.conversation || value23?.extendedTextMessage?.text || "";
    }
    if (!value22) {
      return value21.reply("🎬 Provide a video name.\nExample: `.ytmp4 Not Like Us`");
    }
    if (value22.length > 100) {
      return value21.reply("📝 Video name too long! Max 100 chars.");
    }
    const value24 = value21.from;
    await value18.sendMessage(value24, {
      react: {
        text: "🎥",
        key: value19.key
      }
    });
    let value25;
    try {
      value25 = await searchYouTube(value22);
    } catch (error26) {
      console.error("[ytmp4] search error:", error26.message);
      return value21.reply("❌ Search failed: " + error26.message);
    }
    const value27 = Date.now();
    const value28 = database.getBotSetting("prefix") || ".";
    const value29 = value19.key.participant || value19.key.remoteJid;
    await sendButtons(value18, value24, {
      title: "🎬 VIDEO DOWNLOADER",
      text: "⿻ *Title:* " + value25.title + "\n" + ("⿻ *Duration:* " + (value25.timestamp || "N/A") + "\n") + ("⿻ *Views:* " + (value25.views?.toLocaleString() ?? "N/A") + "\n") + ("⿻ *Channel:* " + (value25.author?.name || "N/A") + "\n") + ("⿻ *Link:* " + value25.url + "\n\n") + "*Select download format:*",
      footer: "Made by " + database.getBotSetting("botName"),
      buttons: getVideoButtons(value25.videoId, value27)
    }, {
      quoted: value19
    });
    await value18.sendMessage(value24, {
      react: {
        text: "✅",
        key: value19.key
      }
    });
    const value30 = async value31 => {
      const value32 = value31.messages[0];
      if (!value32?.message) {
        return;
      }
      const value33 = extractButtonResponseId(value32);
      if (!value33) {
        return;
      }
      if (!value33.includes("_" + value27)) {
        return;
      }
      if (value32.key?.remoteJid !== value24) {
        return;
      }
      const value34 = getResponseSender(value32);
      if (value24.endsWith("@g.us") && value34 !== value29) {
        return;
      }
      await value18.sendMessage(value24, {
        react: {
          text: "⬇️",
          key: value19.key
        }
      });
      try {
        const value35 = value33.replace(value28, "").split("_")[0];
        const value36 = await downloadVideo(value25.url);
        const value37 = path.join(__dirname, "temp");
        if (!fs.existsSync(value37)) {
          fs.mkdirSync(value37);
        }
        const value38 = path.join(value37, "video_" + value27 + ".mp4");
        const value39 = await axios({
          method: "get",
          url: value36.result,
          responseType: "stream",
          timeout: 600000
        });
        const value40 = fs.createWriteStream(value38);
        value39.data.pipe(value40);
        await new Promise((value41, value42) => {
          value40.on("finish", value41);
          value40.on("error", value42);
        });
        if (!fs.existsSync(value38) || fs.statSync(value38).size === 0) {
          throw new Error("Download failed — file is empty");
        }
        const value43 = value36.title || value25.title || "YouTube Video";
        const value44 = value43.replace(/[^\w\s.-]/gi, "").substring(0, 100);
        if (value35 === "video") {
          await value18.sendMessage(value24, {
            video: {
              url: value38
            },
            mimetype: "video/mp4",
            caption: "🎬 " + value43
          }, {
            quoted: value32
          });
        } else if (value35 === "videodoc") {
          await value18.sendMessage(value24, {
            document: {
              url: value38
            },
            mimetype: "video/mp4",
            fileName: value44 + ".mp4",
            caption: "🎬 " + value43 + "\n\n> Downloaded via " + database.getBotSetting("botName")
          }, {
            quoted: value32
          });
        }
        if (fs.existsSync(value38)) {
          fs.unlinkSync(value38);
        }
        await value18.sendMessage(value24, {
          react: {
            text: "✅",
            key: value19.key
          }
        });
      } catch (error45) {
        console.error("[ytmp4] download error:", error45.message);
        await value18.sendMessage(value24, {
          react: {
            text: "❌",
            key: value19.key
          }
        });
        await value18.sendMessage(value24, {
          text: "🚫 Error: " + error45.message + "\n\n_Try again later._"
        }, {
          quoted: value32
        });
      }
    };
    value18.ev.on("messages.upsert", value30);
  }
};
