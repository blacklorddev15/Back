const axios = require("axios");
const fs = require("fs");
const path = require("path");
const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
const RETRY_DELAY = 3000;
const MAX_RESULTS = 5;
function extractButtonResponseId(value1) {
  return value1.message?.buttonsResponseMessage?.selectedButtonId || value1.message?.templateButtonReplyMessage?.selectedId || value1.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || null;
}
function getResponseSender(value2) {
  return value2.key?.participant || value2.key?.remoteJid;
}
async function withRetry(value3, value4 = 3, value5 = RETRY_DELAY) {
  let value6;
  for (let value7 = 0; value7 < value4; value7++) {
    try {
      return await value3();
    } catch (error8) {
      value6 = error8;
      const value9 = error8.message?.toLowerCase().includes("busy") || error8.message?.toLowerCase().includes("try again");
      if (value7 < value4 - 1 && value9) {
        await new Promise(value10 => setTimeout(value10, value5));
      } else if (!value9) {
        throw error8;
      }
    }
  }
  throw value6;
}
async function searchSpotify(value11) {
  return withRetry(async () => {
    const value12 = await axios.get("https://api.nexray.eu.cc/search/spotify?q=" + encodeURIComponent(value11), {
      timeout: 30000
    });
    if (!value12.data?.status || !Array.isArray(value12.data?.result) || !value12.data.result.length) {
      throw new Error("No results found");
    }
    return value12.data.result.slice(0, MAX_RESULTS);
  });
}
async function downloadSpotify(value13) {
  return withRetry(async () => {
    const value14 = await axios.get("https://api.nexray.eu.cc/downloader/spotifyplay?q=" + encodeURIComponent(value13), {
      timeout: 90000
    });
    const value15 = value14.data?.result;
    if (!value14.data?.status || !value15?.download_url) {
      throw new Error("Download API returned no URL");
    }
    return {
      downloadUrl: value15.download_url,
      title: value15.title || "",
      artist: value15.artist || "",
      album: value15.album || "",
      duration: value15.duration || "",
      thumbnail: value15.thumbnail || ""
    };
  });
}
function getTrackButtons(value16, value17) {
  const value18 = database.getBotSetting("prefix") || ".";
  return value16.map((value19, value20) => ({
    id: value18 + "sptrack_" + value20 + "_" + value17,
    text: value20 + 1 + ". " + value19.title.substring(0, 22) + (value19.title.length > 22 ? "…" : "")
  }));
}
function getFormatButtons(value21) {
  const value22 = database.getBotSetting("prefix") || ".";
  return [{
    id: value22 + "spfmt_audio_" + value21,
    text: "🎶 Audio"
  }, {
    id: value22 + "spfmt_audiodoc_" + value21,
    text: "📄 Audio Document"
  }];
}
module.exports = {
  name: "spotify2",
  aliases: ["sp2", "spdl2", "spplay2"],
  category: "media",
  description: "Search and download Spotify songs",
  usage: ".spotify <song name>",
  async execute(value23, value24, value25, value26) {
    if (!value25.length) {
      return value26.reply("🎵 *Spotify Downloader*\n\n*Usage:*\n• `.spotify faded` — search + download\n• Reply to a message with `.spotify` — use replied text as query");
    }
    let value27 = value25.join(" ").trim();
    if (!value27) {
      const value28 = value26?.quoted;
      value27 = value28?.conversation || value28?.extendedTextMessage?.text || "";
    }
    if (!value27) {
      return value26.reply("🎵 Provide a song name.\nExample: `.spotify Faded`");
    }
    if (value27.length > 100) {
      return value26.reply("📝 Song name too long! Max 100 chars.");
    }
    const value29 = value26.from;
    const value30 = database.getBotSetting("prefix") || ".";
    const value31 = value24.key.participant || value24.key.remoteJid;
    await value23.sendMessage(value29, {
      react: {
        text: "🔍",
        key: value24.key
      }
    });
    let value32;
    try {
      value32 = await searchSpotify(value27);
    } catch (error33) {
      console.error("[spotify] search error:", error33.message);
      return value26.reply("❌ Search failed: " + error33.message);
    }
    const value34 = Date.now();
    const value35 = value32.map((value36, value37) => "*" + (value37 + 1) + ".* " + value36.title + "\n" + ("    ⏱ " + value36.duration + "  •  🔥 " + (value36.popularity ?? "N/A") + "  •  💿 " + value36.album)).join("\n\n");
    await sendButtons(value23, value29, {
      title: "🎵 SPOTIFY SEARCH",
      text: "*Query:* _" + value27 + "_\n\n" + (value35 + "\n\n") + "*Select a track to download:*",
      footer: "Made by " + database.getBotSetting("botName"),
      buttons: getTrackButtons(value32, value34)
    }, {
      quoted: value24
    });
    await value23.sendMessage(value29, {
      react: {
        text: "✅",
        key: value24.key
      }
    });
    const value38 = async value39 => {
      const value40 = value39.messages[0];
      if (!value40?.message) {
        return;
      }
      const value41 = extractButtonResponseId(value40);
      if (!value41) {
        return;
      }
      if (!value41.includes("sptrack_") || !value41.includes("_" + value34)) {
        return;
      }
      if (value40.key?.remoteJid !== value29) {
        return;
      }
      const value42 = getResponseSender(value40);
      if (value29.endsWith("@g.us") && value42 !== value31) {
        return;
      }
      const value43 = value41.replace(value30, "").match(/^sptrack_(\d+)_/);
      if (!value43) {
        return;
      }
      const value44 = parseInt(value43[1]);
      const value45 = value32[value44];
      if (!value45) {
        return;
      }
      const value46 = Date.now();
      await sendButtons(value23, value29, {
        title: "🎵 " + value45.title,
        text: "⿻ *Title:*    " + value45.title + "\n" + ("⿻ *Artist:*   " + value45.artist + "\n") + ("⿻ *Album:*    " + value45.album + "\n") + ("⿻ *Duration:* " + value45.duration + "\n") + ("⿻ *Released:* " + (value45.release_date || "N/A") + "\n") + ("⿻ *Link:*     " + value45.url + "\n\n") + "*Select download format:*",
        footer: "Made by " + database.getBotSetting("botName"),
        buttons: getFormatButtons(value46)
      }, {
        quoted: value40
      });
      await value23.sendMessage(value29, {
        react: {
          text: "⬇️",
          key: value24.key
        }
      });
      const value47 = async value48 => {
        const value49 = value48.messages[0];
        if (!value49?.message) {
          return;
        }
        const value50 = extractButtonResponseId(value49);
        if (!value50) {
          return;
        }
        if (!value50.includes("spfmt_") || !value50.includes("_" + value46)) {
          return;
        }
        if (value49.key?.remoteJid !== value29) {
          return;
        }
        const value51 = getResponseSender(value49);
        if (value29.endsWith("@g.us") && value51 !== value31) {
          return;
        }
        await value23.sendMessage(value29, {
          react: {
            text: "⏬",
            key: value24.key
          }
        });
        try {
          const value52 = value50.replace(value30, "").split("_")[1];
          const value53 = value45.artist + " - " + value45.title;
          const value54 = await downloadSpotify(value53);
          const value55 = path.join(__dirname, "temp");
          if (!fs.existsSync(value55)) {
            fs.mkdirSync(value55);
          }
          const value56 = path.join(value55, "sp_" + value46 + ".mp3");
          const value57 = await axios({
            method: "get",
            url: value54.downloadUrl,
            responseType: "stream",
            timeout: 600000
          });
          const value58 = fs.createWriteStream(value56);
          value57.data.pipe(value58);
          await new Promise((value59, value60) => {
            value58.on("finish", value59);
            value58.on("error", value60);
          });
          if (!fs.existsSync(value56) || fs.statSync(value56).size === 0) {
            throw new Error("Download failed — file is empty");
          }
          const value61 = value54.title || value45.title || "";
          const value62 = value61.replace(/[^\w\s.-]/gi, "").substring(0, 100);
          if (value52 === "audio") {
            await value23.sendMessage(value29, {
              audio: {
                url: value56
              },
              mimetype: "audio/mpeg"
            }, {
              quoted: value49
            });
          } else if (value52 === "audiodoc") {
            await value23.sendMessage(value29, {
              document: {
                url: value56
              },
              mimetype: "audio/mpeg",
              fileName: value62 + ".mp3",
              caption: "> " + database.getBotSetting("botName")
            }, {
              quoted: value49
            });
          }
          if (fs.existsSync(value56)) {
            fs.unlinkSync(value56);
          }
          await value23.sendMessage(value29, {
            react: {
              text: "✅",
              key: value24.key
            }
          });
        } catch (error63) {
          console.error("[spotify] download error:", error63.message);
          await value23.sendMessage(value29, {
            react: {
              text: "❌",
              key: value24.key
            }
          });
          await value23.sendMessage(value29, {
            text: "🚫 Error: " + error63.message + "\n\n_Try again later._"
          }, {
            quoted: value49
          });
        }
      };
      value23.ev.on("messages.upsert", value47);
    };
    value23.ev.on("messages.upsert", value38);
  }
};
