const axios = require("axios");
const database = require("../../database");
const processedMessages = new Set();
const tiktokPattern = /https?:\/\/(?:(?:www|vm|vt|m)\.)?tiktok\.com\/\S+/i;
module.exports = {
  name: "tiktok2",
  aliases: ["tt2", "ttdl2", "tiktokdl2"],
  category: "media",
  description: "Download TikTok videos without watermark",
  usage: ".tiktok <TikTok URL>",
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from;
    try {
      if (processedMessages.has(value2.key.id)) {
        return;
      }
      processedMessages.add(value2.key.id);
      setTimeout(() => processedMessages.delete(value2.key.id), 300000);
      const value6 = value3.join(" ").trim();
      if (!value6) {
        return await value1.sendMessage(value5, {
          text: "❌ Please provide a TikTok URL.\n\nUsage: `" + (database.getBotSetting("prefix") || ".") + "tiktok <URL>`"
        }, {
          quoted: value2
        });
      }
      if (!tiktokPattern.test(value6)) {
        return await value1.sendMessage(value5, {
          text: "❌ Invalid TikTok URL. Please send a valid TikTok video link."
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "⏳",
          key: value2.key
        }
      });
      const value7 = await axios.get("https://www.tikwm.com/api/", {
        params: {
          url: value6,
          hd: 1
        },
        timeout: 15000,
        headers: {
          "User-Agent": "Mozilla/5.0"
        }
      });
      const {
        code: value8,
        msg: value9,
        data: value10
      } = value7.data;
      if (value8 !== 0 || !value10) {
        console.error("[tiktok] API error:", value9);
        await value1.sendMessage(value5, {
          react: {
            text: "❌",
            key: value2.key
          }
        });
        return await value1.sendMessage(value5, {
          text: "❌ Failed to fetch video: " + (value9 || "Unknown error") + ". Try again later."
        }, {
          quoted: value2
        });
      }
      const value11 = value10.hdplay || value10.play || value10.wmplay;
      if (!value11) {
        await value1.sendMessage(value5, {
          react: {
            text: "❌",
            key: value2.key
          }
        });
        return await value1.sendMessage(value5, {
          text: "❌ No download URL found for this video."
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        video: {
          url: value11
        },
        mimetype: "video/mp4",
        caption: database.getBotSetting("botName")
      }, {
        quoted: value2
      });
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error12) {
      console.error("[tiktok] command error:", error12.message || error12);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        text: "❌ An unexpected error occurred. Please try again."
      }, {
        quoted: value2
      });
    }
  }
};
