'use strict';

const fs = require("fs");
const path = require("path");
const {
  randomUUID
} = require("crypto");
const {
  generateWAMessageFromContent
} = require("@whiskeysockets/baileys");
const APP_HTML = fs.readFileSync(path.join(__dirname, "tetris-app.html"), "utf8");
const FALLBACK_TEXT = "╭─❏ 「 TETRIS 」\n│ This mini-app could not render on this client.\n╰───────────────";
function buildPayload(value1) {
  return {
    __typename: "GenAIUnifiedResponse",
    response_id: randomUUID(),
    sections: [{
      __typename: "GenAIUnifiedResponseSection",
      view_model: {
        __typename: "GenAISingleLayoutViewModel",
        primitive: {
          __typename: "FOAHtmlPrimitiveDemoDONOTUSE",
          trusted_sources: [],
          payload: String(value1).trim()
        }
      }
    }]
  };
}
function buildMessage(value2) {
  const value3 = Buffer.from(JSON.stringify(buildPayload(APP_HTML))).toString("base64");
  return generateWAMessageFromContent(value2, {
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          unifiedResponse: {
            data: value3
          },
          contextInfo: {
            isForwarded: true,
            forwardOrigin: 4
          }
        }
      }
    }
  }, {});
}
module.exports = {
  name: "tetris",
  aliases: ["blocks", "brickgame"],
  category: "games",
  description: "Play a live Tetris canvas mini-app (renders inside WhatsApp)",
  usage: ".tetris",
  async execute(value4, value5, value6, value7) {
    const value8 = value7.from || value5.key.remoteJid;
    try {
      let value9 = value8;
      let value10 = buildMessage(value9);
      try {
        await value4.relayMessage(value9, value10.message, {
          messageId: value10.key.id
        });
      } catch (error11) {
        const value12 = value5.key.remoteJidAlt;
        if (!value12 || value12 === value9) {
          throw error11;
        }
        value9 = value12;
        value10 = buildMessage(value9);
        await value4.relayMessage(value9, value10.message, {
          messageId: value10.key.id
        });
      }
    } catch (error13) {
      console.error("[Tetris] HTML app unavailable:", error13.message);
      await value4.sendMessage(value8, {
        text: FALLBACK_TEXT
      }, {
        quoted: value5
      }).catch(() => {});
    }
  }
};
