'use strict';

const fs = require("fs");
const path = require("path");
const {
  sendRichApp,
  RICH_FALLBACK
} = require("../../utils/richApp");
const APP_HTML = fs.readFileSync(path.join(__dirname, "snake-app.html"), "utf8");
module.exports = {
  name: "snake",
  aliases: ["worm"],
  category: "games",
  description: "Play a live Snake canvas mini-app (renders inside WhatsApp)",
  usage: ".snake",
  async execute(value1, value2, value3, value4) {
    const value5 = value4.from || value2.key.remoteJid;
    try {
      await sendRichApp(value1, value2, APP_HTML, value5);
    } catch (error6) {
      console.error("[Snake] mini-app unavailable:", error6.message);
      await value1.sendMessage(value5, {
        text: RICH_FALLBACK("SNAKE")
      }, {
        quoted: value2
      }).catch(() => {});
    }
  }
};
