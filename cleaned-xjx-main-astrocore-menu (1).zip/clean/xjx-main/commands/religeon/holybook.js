const axios = require("axios");
const QURAN_BASE = "https://api.alquran.cloud/v1";
const GITA_BASE = "https://vedicscriptures.github.io";
const BIBLE_BASE = "https://bible-api.com";
const SURAH_NAMES = ["", "Al-Fatihah", "Al-Baqarah", "Ali Imran", "An-Nisa", "Al-Maidah", "Al-Anam", "Al-Araf", "Al-Anfal", "At-Tawbah", "Yunus", "Hud", "Yusuf", "Ar-Rad", "Ibrahim", "Al-Hijr", "An-Nahl", "Al-Isra", "Al-Kahf", "Maryam", "Ta-Ha", "Al-Anbiya", "Al-Hajj", "Al-Muminun", "An-Nur", "Al-Furqan", "Ash-Shuara", "An-Naml", "Al-Qasas", "Al-Ankabut", "Ar-Rum", "Luqman", "As-Sajdah", "Al-Ahzab", "Saba", "Fatir", "Ya-Sin", "As-Saffat", "Sad", "Az-Zumar", "Ghafir", "Fussilat", "Ash-Shura", "Az-Zukhruf", "Ad-Dukhan", "Al-Jathiyah", "Al-Ahqaf", "Muhammad", "Al-Fath", "Al-Hujurat", "Qaf", "Ad-Dhariyat", "At-Tur", "An-Najm", "Al-Qamar", "Ar-Rahman", "Al-Waqiah", "Al-Hadid", "Al-Mujadilah", "Al-Hashr", "Al-Mumtahanah", "As-Saf", "Al-Jumuah", "Al-Munafiqun", "At-Taghabun", "At-Talaq", "At-Tahrim", "Al-Mulk", "Al-Qalam", "Al-Haqqah", "Al-Maarij", "Nuh", "Al-Jinn", "Al-Muzzammil", "Al-Muddathir", "Al-Qiyamah", "Al-Insan", "Al-Mursalat", "An-Naba", "An-Naziat", "Abasa", "At-Takwir", "Al-Infitar", "Al-Mutaffifin", "Al-Inshiqaq", "Al-Buruj", "At-Tariq", "Al-Ala", "Al-Ghashiyah", "Al-Fajr", "Al-Balad", "Ash-Shams", "Al-Layl", "Ad-Duha", "Ash-Sharh", "At-Tin", "Al-Alaq", "Al-Qadr", "Al-Bayyinah", "Az-Zalzalah", "Al-Adiyat", "Al-Qariah", "At-Takathur", "Al-Asr", "Al-Humazah", "Al-Fil", "Quraysh", "Al-Maun", "Al-Kawthar", "Al-Kafirun", "An-Nasr", "Al-Masad", "Al-Ikhlas", "Al-Falaq", "An-Nas"];
const GITA_CHAPTER_NAMES = ["", "Arjuna Vishada Yoga", "Sankhya Yoga", "Karma Yoga", "Jnana Karma Sanyasa Yoga", "Karma Vairagya Yoga", "Abhyasa Yoga", "Paramahamsa Vijnana Yoga", "Aksara Parabrahma Yoga", "Raja Vidya Raja Guhya Yoga", "Vibhuti Yoga", "Visvarupa Darsana Yoga", "Bhakti Yoga", "Ksetra Ksetrajna Vibhaga Yoga", "Gunatraya Vibhaga Yoga", "Purusottama Yoga", "Daivasura Sampad Vibhaga Yoga", "Shraddhatraya Vibhaga Yoga", "Moksha Sanyasa Yoga"];
module.exports = [{
  name: "bible",
  aliases: ["verse", "scripture", "bibleverse"],
  category: "religion",
  description: "Look up a Bible verse or passage",
  usage: ".bible <reference>  e.g. .bible John 3:16",
  async execute(value1, value2, value3, {
    reply: value4,
    react: value5
  }) {
    if (!value3.length) {
      return value4("❌ Usage: *.bible John 3:16*");
    }
    await value5("📖");
    const value6 = value2.key.remoteJid;
    try {
      const value7 = value3.join(" ").trim();
      const {
        data: value8
      } = await axios.get(BIBLE_BASE + "/" + encodeURIComponent(value7));
      const value9 = "📖 *The Holy Bible*\n━━━━━━━━━━━━━━━\n" + ("*Reference:* " + value8.reference + "\n") + ("*Translation:* " + value8.translation_name + "\n") + ("*Verses:* " + value8.verses.length + "\n\n") + ("" + value8.text.trim());
      await value1.sendMessage(value6, {
        text: value9
      }, {
        quoted: value2
      });
    } catch {
      value4("❌ Could not find that reference.\nExample: *.bible John 3:16*");
    }
  }
}, {
  name: "biblelist",
  aliases: ["biblebooks"],
  category: "religion",
  description: "Show the complete list of Bible books",
  usage: ".biblelist",
  async execute(value10, value11, value12, {
    reply: value13
  }) {
    const value14 = value11.key.remoteJid;
    const value15 = "📜 *Old Testament (39 books)*\nGenesis · Exodus · Leviticus · Numbers · Deuteronomy · Joshua · Judges · Ruth · 1 Samuel · 2 Samuel · 1 Kings · 2 Kings · 1 Chronicles · 2 Chronicles · Ezra · Nehemiah · Esther · Job · Psalms · Proverbs · Ecclesiastes · Song of Solomon · Isaiah · Jeremiah · Lamentations · Ezekiel · Daniel · Hosea · Joel · Amos · Obadiah · Jonah · Micah · Nahum · Habakkuk · Zephaniah · Haggai · Zechariah · Malachi\n\n📖 *New Testament (27 books)*\nMatthew · Mark · Luke · John · Acts · Romans · 1 Corinthians · 2 Corinthians · Galatians · Ephesians · Philippians · Colossians · 1 Thessalonians · 2 Thessalonians · 1 Timothy · 2 Timothy · Titus · Philemon · Hebrews · James · 1 Peter · 2 Peter · 1 John · 2 John · 3 John · Jude · Revelation";
    try {
      await value10.sendMessage(value14, {
        image: {
          url: "https://files.catbox.moe/ptpl5c.jpeg"
        },
        caption: "📖 *Complete Bible Book List*\n\n" + value15
      }, {
        quoted: value11
      });
    } catch {
      value13("📖 *Complete Bible Book List*\n\n" + value15);
    }
  }
}, {
  name: "biblerandom",
  aliases: ["rvs", "randomverse", "devotion"],
  category: "religion",
  description: "Get a random Bible verse",
  usage: ".biblerandom",
  async execute(value16, value17, value18, {
    reply: value19,
    react: value20
  }) {
    await value20("🙏");
    const value21 = value17.key.remoteJid;
    const value22 = ["John 3:16", "Psalm 23:1", "Proverbs 3:5", "Romans 8:28", "Philippians 4:13", "Isaiah 40:31", "Jeremiah 29:11", "Matthew 6:33", "Psalm 46:1", "Romans 8:38", "Joshua 1:9", "1 Corinthians 13:4", "Psalm 121:1", "John 14:6", "Hebrews 11:1", "Galatians 5:22", "Psalm 27:1", "Matthew 5:9", "Romans 12:2", "2 Timothy 1:7"];
    const value23 = value22[Math.floor(Math.random() * value22.length)];
    try {
      const {
        data: value24
      } = await axios.get(BIBLE_BASE + "/" + encodeURIComponent(value23));
      const value25 = "✨ *Daily Bible Verse*\n━━━━━━━━━━━━━━━\n" + ("*" + value24.reference + "*\n\n") + ("_\"" + value24.text.trim() + "\"_\n\n") + ("📖 " + value24.translation_name);
      await value16.sendMessage(value21, {
        text: value25
      }, {
        quoted: value17
      });
    } catch {
      value19("❌ Could not fetch a verse. Try again.");
    }
  }
}, {
  name: "quran",
  aliases: ["surah"],
  category: "religion",
  description: "Get a Quran surah with English translation and recitation audio",
  usage: ".quran <surah 1-114>",
  async execute(value26, value27, value28, {
    reply: value29,
    react: value30
  }) {
    const value31 = value27.key.remoteJid;
    const value32 = parseInt(value28[0]);
    if (!value28[0] || isNaN(value32) || value32 < 1 || value32 > 114) {
      return value29("❌ Usage: *.quran <number>*  (1–114)\nExample: *.quran 1*");
    }
    await value30("🕌");
    try {
      const {
        data: value33
      } = await axios.get(QURAN_BASE + "/surah/" + value32 + "/editions/quran-uthmani,en.sahih");
      const value34 = value33.data[0];
      const value35 = value33.data[1];
      const value36 = SURAH_NAMES[value32] || value34.englishName;
      const value37 = value35.ayahs.slice(0, 3).map(value38 => "[" + value38.numberInSurah + "] " + value38.text).join("\n");
      const value39 = "🕌 *Surah " + value32 + ": " + value36 + "*\n━━━━━━━━━━━━━━━\n" + ("*Arabic Name:* " + value34.name + "\n") + ("*Revelation:* " + value34.revelationType + "\n") + ("*Total Ayahs:* " + value34.numberOfAyahs + "\n\n") + ("📝 *Translation (first 3 ayahs):*\n" + value37 + "\n\n") + ("_Use .ayah " + value32 + ":<number> for a specific verse_");
      await value26.sendMessage(value31, {
        text: value39
      }, {
        quoted: value27
      });
      const value40 = "https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/" + value32 + ".mp3";
      await value26.sendMessage(value31, {
        audio: {
          url: value40
        },
        mimetype: "audio/mp4",
        ptt: true
      }, {
        quoted: value27
      });
    } catch (error41) {
      value29("❌ Error fetching Surah: " + error41.message);
    }
  }
}, {
  name: "ayah",
  aliases: ["verse2", "qverse"],
  category: "religion",
  description: "Get a specific Quran ayah with Arabic and English",
  usage: ".ayah <surah>:<ayah>  e.g. .ayah 2:255",
  async execute(value42, value43, value44, {
    reply: value45,
    react: value46
  }) {
    const value47 = value43.key.remoteJid;
    const value48 = value44[0] || "";
    const value49 = value48.match(/^(\d+):(\d+)$/);
    if (!value49) {
      return value45("❌ Usage: *.ayah <surah>:<ayah>*\nExample: *.ayah 2:255*");
    }
    const [, value50, value51] = value49;
    await value46("📿");
    try {
      const {
        data: value52
      } = await axios.get(QURAN_BASE + "/ayah/" + value50 + ":" + value51 + "/editions/quran-uthmani,en.sahih");
      const value53 = value52.data[0];
      const value54 = value52.data[1];
      const value55 = SURAH_NAMES[parseInt(value50)] || value53.surah?.englishName || "";
      const value56 = "📿 *Quran — " + value55 + " " + value50 + ":" + value51 + "*\n━━━━━━━━━━━━━━━\n" + ("🔤 *Arabic:*\n" + value53.text + "\n\n") + ("📖 *English (Sahih Int'l):*\n" + value54.text);
      await value42.sendMessage(value47, {
        text: value56
      }, {
        quoted: value43
      });
    } catch (error57) {
      value45("❌ Could not find that ayah.\nCheck: surah (1–114), ayah number.\nError: " + error57.message);
    }
  }
}, {
  name: "quranrandom",
  aliases: ["randomayah", "qrandom"],
  category: "religion",
  description: "Get a random Quran ayah",
  usage: ".quranrandom",
  async execute(value58, value59, value60, {
    reply: value61,
    react: value62
  }) {
    const value63 = value59.key.remoteJid;
    await value62("🌙");
    const value64 = Math.floor(Math.random() * 6236) + 1;
    try {
      const {
        data: value65
      } = await axios.get(QURAN_BASE + "/ayah/" + value64 + "/editions/quran-uthmani,en.sahih");
      const value66 = value65.data[0];
      const value67 = value65.data[1];
      const value68 = value66.surah.number + ":" + value66.numberInSurah;
      const value69 = SURAH_NAMES[value66.surah.number] || value66.surah.englishName;
      const value70 = "🌙 *Random Ayah — " + value69 + " (" + value68 + ")*\n━━━━━━━━━━━━━━━\n" + ("🔤 *Arabic:*\n" + value66.text + "\n\n") + ("📖 *English:*\n_\"" + value67.text + "\"_");
      await value58.sendMessage(value63, {
        text: value70
      }, {
        quoted: value59
      });
    } catch (error71) {
      value61("❌ Error: " + error71.message);
    }
  }
}, {
  name: "gita",
  aliases: ["bhagavadgita", "shlok", "slok"],
  category: "religion",
  description: "Get a Bhagavad Gita shlok with Sanskrit, transliteration and meaning",
  usage: ".gita <chapter>:<verse>  e.g. .gita 2:47",
  async execute(value72, value73, value74, {
    reply: value75,
    react: value76
  }) {
    const value77 = value73.key.remoteJid;
    const value78 = value74[0] || "";
    const value79 = value78.match(/^(\d+):(\d+)$/);
    if (!value79) {
      return value75("❌ Usage: *.gita <chapter>:<verse>*\nExample: *.gita 2:47* (18 chapters)");
    }
    const [, value80, value81] = value79;
    await value76("🪔");
    try {
      const {
        data: value82
      } = await axios.get(GITA_BASE + "/slok/" + value80 + "/" + value81);
      if (!value82 || !value82.slok) {
        return value75("❌ Verse not found. Check chapter (1–18) and verse number.");
      }
      const value83 = GITA_CHAPTER_NAMES[parseInt(value80)] || "Chapter " + value80;
      const value84 = value82.tej?.ht || value82.siva?.et || value82.purohit?.et || value82.gambir?.et || "_(no English meaning available)_";
      const value85 = "🪔 *Bhagavad Gita " + value80 + "." + value81 + "*\n" + ("📚 _" + value83 + "_\n") + "━━━━━━━━━━━━━━━\n" + ("🔤 *Sanskrit (Devanagari):*\n" + value82.slok + "\n\n") + ("🔡 *Transliteration:*\n" + (value82.transliteration || "—") + "\n\n") + ("📖 *Meaning (English):*\n" + value84);
      await value72.sendMessage(value77, {
        text: value85
      }, {
        quoted: value73
      });
    } catch (error86) {
      value75("❌ Error fetching shlok: " + error86.message);
    }
  }
}, {
  name: "gitarandom",
  aliases: ["randomshlok", "krishna"],
  category: "religion",
  description: "Get a random Bhagavad Gita shlok",
  usage: ".gitarandom",
  async execute(value87, value88, value89, {
    reply: value90,
    react: value91
  }) {
    const value92 = value88.key.remoteJid;
    await value91("🪔");
    const value93 = [0, 47, 72, 43, 42, 29, 47, 30, 28, 34, 42, 55, 20, 35, 27, 20, 24, 28, 78];
    const value94 = Math.floor(Math.random() * 18) + 1;
    const value95 = Math.floor(Math.random() * value93[value94]) + 1;
    try {
      const {
        data: value96
      } = await axios.get(GITA_BASE + "/slok/" + value94 + "/" + value95);
      if (!value96?.slok) {
        return value90("❌ Could not fetch a shlok. Try again.");
      }
      const value97 = value96.tej?.ht || value96.siva?.et || value96.purohit?.et || "_(no meaning available)_";
      const value98 = GITA_CHAPTER_NAMES[value94] || "Chapter " + value94;
      const value99 = "🪔 *Bhagavad Gita " + value94 + "." + value95 + "*\n" + ("📚 _" + value98 + "_\n") + "━━━━━━━━━━━━━━━\n" + ("🔤 *Sanskrit:*\n" + value96.slok + "\n\n") + ("📖 *Meaning:*\n_\"" + value97 + "\"_");
      await value87.sendMessage(value92, {
        text: value99
      }, {
        quoted: value88
      });
    } catch (error100) {
      value90("❌ Error: " + error100.message);
    }
  }
}, {
  name: "gitachapter",
  aliases: ["gitainfo", "chapter"],
  category: "religion",
  description: "Get summary and details of a Bhagavad Gita chapter",
  usage: ".gitachapter <1-18>",
  async execute(value101, value102, value103, {
    reply: value104,
    react: value105
  }) {
    const value106 = value102.key.remoteJid;
    const value107 = parseInt(value103[0]);
    if (!value103[0] || isNaN(value107) || value107 < 1 || value107 > 18) {
      return value104("❌ Usage: *.gitachapter <number>*  (1–18)");
    }
    await value105("📚");
    try {
      const {
        data: value108
      } = await axios.get(GITA_BASE + "/chapter/" + value107);
      if (!value108) {
        return value104("❌ Chapter not found.");
      }
      const value109 = "📚 *Bhagavad Gita — Chapter " + value107 + "*\n━━━━━━━━━━━━━━━\n" + ("*Name:* " + (value108.translation || GITA_CHAPTER_NAMES[value107]) + "\n") + ("*Sanskrit:* " + (value108.name || "—") + "\n") + ("*Transliteration:* " + (value108.transliteration || "—") + "\n") + ("*Total Verses:* " + (value108.verses_count || "—") + "\n\n") + ("📖 *Summary:*\n" + (value108.summary?.en || "—").slice(0, 700) + "...");
      await value101.sendMessage(value106, {
        text: value109
      }, {
        quoted: value102
      });
    } catch (error110) {
      value104("❌ Error: " + error110.message);
    }
  }
}];
