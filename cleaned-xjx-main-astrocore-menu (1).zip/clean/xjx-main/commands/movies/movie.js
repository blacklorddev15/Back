const axios = require("axios");
const BASE = "https://apiskeith2-production-ec66.up.railway.app";
async function keithApi(value1, value2 = {}) {
  const value3 = "" + BASE + value1;
  const {
    data: value4
  } = await axios.get(value3, {
    params: value2,
    timeout: 30000
  });
  if (!value4) {
    throw new Error("No response from API");
  }
  if (value4.status === false) {
    throw new Error(value4.error || value4.message || "API error");
  }
  if (value4.result !== undefined) {
    return value4.result;
  } else {
    return value4;
  }
}
const react = (value5, value6, value7) => value5.sendMessage(value6.key.remoteJid, {
  react: {
    text: value7,
    key: value6.key
  }
});
const send = (value8, value9, value10) => value8.sendMessage(value9.key.remoteJid, {
  text: value10
}, {
  quoted: value9
});
async function sendLong(value11, value12, value13, value14, value15 = "┗━━━━━━━━━━━━━━━━") {
  const value16 = 3500;
  const value17 = value14.split("\n");
  const value18 = [];
  let value19 = "";
  for (const value20 of value17) {
    if ((value19 + value20 + "\n").length > value16) {
      value18.push(value19);
      value19 = "";
    }
    value19 += value20 + "\n";
  }
  if (value19.trim()) {
    value18.push(value19);
  }
  if (!value18.length) {
    value18.push("_No data available_");
  }
  for (let value21 = 0; value21 < value18.length; value21++) {
    const value22 = value18.length > 1 ? " (" + (value21 + 1) + "/" + value18.length + ")" : "";
    const value23 = value21 === value18.length - 1;
    const value24 = (value21 === 0 ? "" + value13 + value22 + "\n\n" : "" + value13 + value22 + " cont...\n\n") + value18[value21] + (value23 ? "\n" + value15 : "");
    await value11.sendMessage(value12.key.remoteJid, {
      text: value24
    }, {
      quoted: value21 === 0 ? value12 : undefined
    });
  }
}
function fixRating(value25) {
  if (!value25) {
    return "N/A";
  }
  const value26 = String(value25);
  const value27 = value26.slice(0, Math.floor(value26.length / 2));
  if (value27 === value26.slice(Math.floor(value26.length / 2))) {
    return value27;
  } else {
    return value26;
  }
}
function fmtIboxListing(value28, value29) {
  const value30 = (value28.trending || []).slice(0, 5);
  const value31 = (value28.items || []).slice(0, 8);
  const value32 = value28.page || 1;
  const value33 = value28.totalPages || "?";
  let value34 = "";
  if (value30.length) {
    value34 += "🔥 *Trending*\n";
    value34 += value30.map((value35, value36) => value36 + 1 + ". *" + value35.title + "*\n   🔗 " + value35.url).join("\n") + "\n\n";
  }
  if (value31.length) {
    value34 += "🆕 *Latest*\n";
    value34 += value31.map((value37, value38) => {
      let value39 = value38 + 1 + ". *" + value37.title + "*";
      if (value37.episode) {
        value39 += "\n   📺 " + value37.episode.replace(/\s+/g, " ").trim();
      }
      value39 += "\n   🔗 " + value37.url;
      return value39;
    }).join("\n");
  }
  value34 += "\n\n📄 Page " + value32 + " of " + value33;
  return value34;
}
function fmtDetail(value40) {
  let value41 = "";
  if (value40.title) {
    value41 += "🎬 *" + value40.title + "*\n";
  }
  if (value40.episodeTitle) {
    value41 += "📺 " + value40.episodeTitle + "\n";
  }
  if (value40.year) {
    value41 += "📅 Year: " + value40.year + "\n";
  }
  if (value40.rating) {
    value41 += "⭐ Rating: " + value40.rating + "/10\n";
  }
  if (value40.overview) {
    value41 += "\n📝 " + value40.overview.slice(0, 400).trim() + "\n";
  }
  if (value40.downloadUrl) {
    value41 += "\n📥 *Download:* " + value40.downloadUrl + "\n";
  }
  if (value40.telegramChannel) {
    value41 += "📢 Telegram: " + value40.telegramChannel + "\n";
  }
  if (value40.url) {
    value41 += "🔗 Source: " + value40.url + "\n";
  }
  return value41 || "_No details found_";
}
function fmtSearch(value42, value43) {
  const value44 = Array.isArray(value42) ? value42 : [];
  if (!value44.length) {
    return "_No " + value43 + " found_";
  }
  return value44.slice(0, 10).map((value45, value46) => {
    let value47 = value46 + 1 + ". *" + (value45.title || value45.name || "Untitled") + "*";
    if (value45.episode) {
      value47 += " — " + value45.episode.replace(/\s+/g, " ").trim();
    }
    if (value45.url) {
      value47 += "\n   🔗 " + value45.url;
    }
    return value47;
  }).join("\n");
}
function fmtMovieBoxSearch(value48) {
  const value49 = Array.isArray(value48.results) ? value48.results : [];
  if (!value49.length) {
    return "_No results found_";
  }
  return value49.slice(0, 10).map((value50, value51) => {
    let value52 = value51 + 1 + ". *" + value50.title + "*";
    if (value50.type) {
      value52 += " [" + value50.type + "]";
    }
    if (value50.rating) {
      value52 += " ⭐ " + fixRating(value50.rating);
    }
    if (value50.url) {
      value52 += "\n   🔗 " + value50.url;
    }
    return value52;
  }).join("\n");
}
function fmtActor(value53) {
  if (!value53.length) {
    return "_No actors found_";
  }
  return value53.slice(0, 5).map((value54, value55) => {
    let value56 = value55 + 1 + ". *" + value54.name + "*";
    if (value54.knownFor) {
      value56 += "\n   🎭 " + value54.knownFor;
    }
    if (value54.detailUrl) {
      value56 += "\n   🔗 " + value54.detailUrl;
    }
    return value56;
  }).join("\n\n");
}
function fmtTrailer(value57) {
  let value58 = "";
  if (value57.title) {
    value58 += "🎬 *" + value57.title + "*\n";
  }
  if (value57.description) {
    value58 += "\n📝 " + value57.description.slice(0, 300).trim() + "\n";
  }
  if (value57.thumbnail) {
    value58 += "\n🖼️ Thumbnail: " + value57.thumbnail + "\n";
  }
  if (value57.trailerUrl) {
    value58 += "\n▶️ *Trailer:* " + value57.trailerUrl + "\n";
  }
  if (value57.url) {
    value58 += "🔗 Source: " + value57.url + "\n";
  }
  return value58 || "_No trailer info found_";
}
module.exports = [{
  name: "iboxtv",
  aliases: ["tvtrending", "tvshows"],
  description: "Trending TV shows from iBox",
  category: "Movies",
  usage: ".iboxtv [page]",
  execute: async (value59, value60, value61) => {
    await react(value59, value60, "📺");
    const value62 = parseInt(value61[0]) || 1;
    try {
      const value63 = await keithApi("/iboxtv", {
        page: value62
      });
      const value64 = fmtIboxListing(value63, "TV Shows");
      await sendLong(value59, value60, "┏━━━ 📺 *iBox TV Trending* ━━━", value64);
    } catch (error65) {
      await react(value59, value60, "❌");
      await send(value59, value60, "❌ " + error65.message);
    }
  }
}, {
  name: "tvdetail",
  aliases: ["iboxtvdetail", "showdetail"],
  description: "Get details and download link for a TV show",
  category: "Movies",
  usage: ".tvdetail <iboxtv_url>",
  execute: async (value66, value67, value68) => {
    if (!value68[0]) {
      return send(value66, value67, "❌ Usage: .tvdetail <iboxtv_url>");
    }
    await react(value66, value67, "🔍");
    const value69 = value68.join(" ").trim();
    try {
      const value70 = await keithApi("/iboxtv/detail", {
        url: value69
      });
      const value71 = fmtDetail(value70);
      if (value70.image) {
        await value66.sendMessage(value67.key.remoteJid, {
          image: {
            url: value70.image
          },
          caption: "┏━━━ 📺 *TV Show Detail* ━━━\n\n" + value71 + "\n┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value67
        });
      } else {
        await sendLong(value66, value67, "┏━━━ 📺 *TV Show Detail* ━━━", value71);
      }
    } catch (error72) {
      await react(value66, value67, "❌");
      await send(value66, value67, "❌ " + error72.message);
    }
  }
}, {
  name: "tvsearch",
  aliases: ["iboxsearch", "searchtv"],
  description: "Search TV shows on iBox",
  category: "Movies",
  usage: ".tvsearch <query> [page]",
  execute: async (value73, value74, value75) => {
    if (!value75[0]) {
      return send(value73, value74, "❌ Usage: .tvsearch <query>");
    }
    await react(value73, value74, "🔍");
    const value76 = value75[value75.length - 1];
    const value77 = !isNaN(value76) && value75.length > 1;
    const value78 = value77 ? parseInt(value76) : 1;
    const value79 = value77 ? value75.slice(0, -1).join(" ") : value75.join(" ");
    try {
      const value80 = await keithApi("/iboxtv/search", {
        q: value79,
        page: value78
      });
      const value81 = value80.results || value80.items || value80 || [];
      const value82 = fmtSearch(Array.isArray(value81) ? value81 : [], "TV shows");
      await sendLong(value73, value74, "┏━━━ 🔍 *TV Search: \"" + value79 + "\"* ━━━", value82);
    } catch (error83) {
      await react(value73, value74, "❌");
      await send(value73, value74, "❌ " + error83.message);
    }
  }
}, {
  name: "iboxmovies",
  aliases: ["movietrending", "latestmovies"],
  description: "Trending movies from iBox",
  category: "Movies",
  usage: ".iboxmovies [page]",
  execute: async (value84, value85, value86) => {
    await react(value84, value85, "🎬");
    const value87 = parseInt(value86[0]) || 1;
    try {
      const value88 = await keithApi("/iboxmovies", {
        page: value87
      });
      const value89 = fmtIboxListing(value88, "Movies");
      await sendLong(value84, value85, "┏━━━ 🎬 *iBox Movies Trending* ━━━", value89);
    } catch (error90) {
      await react(value84, value85, "❌");
      await send(value84, value85, "❌ " + error90.message);
    }
  }
}, {
  name: "moviedetail",
  aliases: ["iboxmoviedetail"],
  description: "Get details and download link for a movie",
  category: "Movies",
  usage: ".moviedetail <iboxmovies_url>",
  execute: async (value91, value92, value93) => {
    if (!value93[0]) {
      return send(value91, value92, "❌ Usage: .moviedetail <iboxmovies_url>");
    }
    await react(value91, value92, "🔍");
    const value94 = value93.join(" ").trim();
    try {
      const value95 = await keithApi("/iboxmovies/detail", {
        url: value94
      });
      const value96 = fmtDetail(value95);
      if (value95.image) {
        await value91.sendMessage(value92.key.remoteJid, {
          image: {
            url: value95.image
          },
          caption: "┏━━━ 🎬 *Movie Detail* ━━━\n\n" + value96 + "\n┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value92
        });
      } else {
        await sendLong(value91, value92, "┏━━━ 🎬 *Movie Detail* ━━━", value96);
      }
    } catch (error97) {
      await react(value91, value92, "❌");
      await send(value91, value92, "❌ " + error97.message);
    }
  }
}, {
  name: "moviesearch",
  aliases: ["iboxmoviesearch", "searchmovie"],
  description: "Search movies on iBox",
  category: "Movies",
  usage: ".moviesearch <query> [page]",
  execute: async (value98, value99, value100) => {
    if (!value100[0]) {
      return send(value98, value99, "❌ Usage: .moviesearch <query>");
    }
    await react(value98, value99, "🔍");
    const value101 = value100[value100.length - 1];
    const value102 = !isNaN(value101) && value100.length > 1;
    const value103 = value102 ? parseInt(value101) : 1;
    const value104 = value102 ? value100.slice(0, -1).join(" ") : value100.join(" ");
    try {
      const value105 = await keithApi("/iboxmovies/search", {
        q: value104,
        page: value103
      });
      const value106 = value105.results || value105.items || value105 || [];
      const value107 = fmtSearch(Array.isArray(value106) ? value106 : [], "movies");
      await sendLong(value98, value99, "┏━━━ 🔍 *Movie Search: \"" + value104 + "\"* ━━━", value107);
    } catch (error108) {
      await react(value98, value99, "❌");
      await send(value98, value99, "❌ " + error108.message);
    }
  }
}, {
  name: "iboxanime",
  aliases: ["animetrending", "latestanime"],
  description: "Trending anime from iBox",
  category: "Movies",
  usage: ".iboxanime [page]",
  execute: async (value109, value110, value111) => {
    await react(value109, value110, "🎌");
    const value112 = parseInt(value111[0]) || 1;
    try {
      const value113 = await keithApi("/iboxanime", {
        page: value112
      });
      const value114 = fmtIboxListing(value113, "Anime");
      await sendLong(value109, value110, "┏━━━ 🎌 *iBox Anime Trending* ━━━", value114);
    } catch (error115) {
      await react(value109, value110, "❌");
      await send(value109, value110, "❌ " + error115.message);
    }
  }
}, {
  name: "animedetail",
  aliases: ["iboxanimedetail"],
  description: "Get details and download link for an anime",
  category: "Movies",
  usage: ".animedetail <iboxanime_url>",
  execute: async (value116, value117, value118) => {
    if (!value118[0]) {
      return send(value116, value117, "❌ Usage: .animedetail <iboxanime_url>");
    }
    await react(value116, value117, "🔍");
    const value119 = value118.join(" ").trim();
    try {
      const value120 = await keithApi("/iboxanime/detail", {
        url: value119
      });
      const value121 = fmtDetail(value120);
      if (value120.image) {
        await value116.sendMessage(value117.key.remoteJid, {
          image: {
            url: value120.image
          },
          caption: "┏━━━ 🎌 *Anime Detail* ━━━\n\n" + value121 + "\n┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value117
        });
      } else {
        await sendLong(value116, value117, "┏━━━ 🎌 *Anime Detail* ━━━", value121);
      }
    } catch (error122) {
      await react(value116, value117, "❌");
      await send(value116, value117, "❌ " + error122.message);
    }
  }
}, {
  name: "animesearch",
  aliases: ["iboxanimesearch", "searchanime"],
  description: "Search anime on iBox",
  category: "Movies",
  usage: ".animesearch <query> [page]",
  execute: async (value123, value124, value125) => {
    if (!value125[0]) {
      return send(value123, value124, "❌ Usage: .animesearch <query>");
    }
    await react(value123, value124, "🔍");
    const value126 = value125[value125.length - 1];
    const value127 = !isNaN(value126) && value125.length > 1;
    const value128 = value127 ? parseInt(value126) : 1;
    const value129 = value127 ? value125.slice(0, -1).join(" ") : value125.join(" ");
    try {
      const value130 = await keithApi("/iboxanime/search", {
        q: value129,
        page: value128
      });
      const value131 = value130.results || value130.items || value130 || [];
      const value132 = fmtSearch(Array.isArray(value131) ? value131 : [], "anime");
      await sendLong(value123, value124, "┏━━━ 🔍 *Anime Search: \"" + value129 + "\"* ━━━", value132);
    } catch (error133) {
      await react(value123, value124, "❌");
      await send(value123, value124, "❌ " + error133.message);
    }
  }
}, {
  name: "dramabox",
  aliases: ["drama", "dramastream"],
  description: "Get DramaBox episode stream/download link",
  category: "Movies",
  usage: ".dramabox <bookId> [episode]",
  execute: async (value134, value135, value136) => {
    if (!value136[0]) {
      return send(value134, value135, "❌ Usage: .dramabox <bookId> [episode]\n\nExample: .dramabox 41000105764 1");
    }
    await react(value134, value135, "🎭");
    const value137 = value136[0];
    const value138 = parseInt(value136[1]) || 1;
    try {
      const value139 = await keithApi("/dramabox/stream", {
        bookId: value137,
        episode: value138
      });
      let value140 = "🎭 *DramaBox Stream*\n\n";
      value140 += "📚 Book ID: `" + value137 + "`\n";
      value140 += "📺 Episode: " + value138 + "\n";
      if (typeof value139 === "string") {
        value140 += "\n▶️ *Stream Link:*\n" + value139;
      } else if (value139.url || value139.streamUrl || value139.link) {
        const value141 = value139.url || value139.streamUrl || value139.link;
        value140 += "\n▶️ *Stream Link:*\n" + value141;
        if (value139.title) {
          value140 += "\n\n🎬 " + value139.title;
        }
        if (value139.quality) {
          value140 += "\n📹 Quality: " + value139.quality;
        }
      } else {
        value140 += "\n📦 Response:\n" + JSON.stringify(value139, null, 2).slice(0, 800);
      }
      await send(value134, value135, "┏━━━ 🎭 *DramaBox* ━━━\n\n" + value140 + "\n\n┗━━━━━━━━━━━━━━━━");
    } catch (error142) {
      await react(value134, value135, "❌");
      await send(value134, value135, "❌ " + error142.message);
    }
  }
}, {
  name: "actor",
  aliases: ["actorsearch", "findactor"],
  description: "Search actors on IMDb",
  category: "Movies",
  usage: ".actor <name>",
  execute: async (value143, value144, value145) => {
    if (!value145[0]) {
      return send(value143, value144, "❌ Usage: .actor <name>");
    }
    await react(value143, value144, "🎭");
    const value146 = value145.join(" ");
    try {
      const value147 = await keithApi("/actor/search", {
        q: value146
      });
      const value148 = Array.isArray(value147) ? value147 : [];
      const value149 = fmtActor(value148);
      const value150 = value148.find(value151 => value151.image);
      if (value150?.image) {
        await value143.sendMessage(value144.key.remoteJid, {
          image: {
            url: value150.image
          },
          caption: "┏━━━ 🎭 *Actor Search: \"" + value146 + "\"* ━━━\n\n" + value149 + "\n\n┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value144
        });
      } else {
        await sendLong(value143, value144, "┏━━━ 🎭 *Actor Search: \"" + value146 + "\"* ━━━", value149);
      }
    } catch (error152) {
      await react(value143, value144, "❌");
      await send(value143, value144, "❌ " + error152.message);
    }
  }
}, {
  name: "moviebox",
  aliases: ["mbsearch", "mbmovie"],
  description: "Search movies on MovieBox (returns URLs usable with .trailer / .moviedl)",
  category: "Movies",
  usage: ".moviebox <query>",
  execute: async (value153, value154, value155) => {
    if (!value155[0]) {
      return send(value153, value154, "❌ Usage: .moviebox <query>");
    }
    await react(value153, value154, "🎬");
    const value156 = value155.join(" ");
    try {
      const value157 = await keithApi("/moviebox/search", {
        q: value156
      });
      const value158 = fmtMovieBoxSearch(value157);
      await sendLong(value153, value154, "┏━━━ 🎬 *MovieBox: \"" + value156 + "\"* ━━━", value158, "\n💡 Use .trailer <url> to view info\n💡 Use .moviedl <url> to download trailer MP4\n┗━━━━━━━━━━━━━━━━");
    } catch (error159) {
      await react(value153, value154, "❌");
      await send(value153, value154, "❌ " + error159.message);
    }
  }
}, {
  name: "trailer",
  aliases: ["movietrailer", "gettrailer"],
  description: "Get movie trailer info from a MovieBox URL",
  category: "Movies",
  usage: ".trailer <moviebox_url>",
  execute: async (value160, value161, value162) => {
    if (!value162[0]) {
      return send(value160, value161, "❌ Usage: .trailer <moviebox_url>\n\nGet URL from .moviebox <query>");
    }
    await react(value160, value161, "▶️");
    const value163 = value162.join(" ").trim();
    try {
      const value164 = await keithApi("/movie/trailer", {
        q: value163
      });
      const value165 = fmtTrailer(value164);
      if (value164.thumbnail) {
        await value160.sendMessage(value161.key.remoteJid, {
          image: {
            url: value164.thumbnail
          },
          caption: "┏━━━ ▶️ *Movie Trailer* ━━━\n\n" + value165 + "\n┗━━━━━━━━━━━━━━━━"
        }, {
          quoted: value161
        });
      } else {
        await sendLong(value160, value161, "┏━━━ ▶️ *Movie Trailer* ━━━", value165);
      }
    } catch (error166) {
      await react(value160, value161, "❌");
      await send(value160, value161, "❌ " + error166.message);
    }
  }
}, {
  name: "moviedl",
  aliases: ["trailerdownload", "dltrailer"],
  description: "Download and send movie trailer MP4 from a MovieBox URL",
  category: "Movies",
  usage: ".moviedl <moviebox_url>",
  execute: async (value167, value168, value169) => {
    if (!value169[0]) {
      return send(value167, value168, "❌ Usage: .moviedl <moviebox_url>\n\nGet URL from: .moviebox <query>");
    }
    await react(value167, value168, "⬇️");
    const value170 = value169.join(" ").trim();
    try {
      const value171 = await keithApi("/movie/trailer", {
        q: value170
      });
      if (!value171.trailerUrl) {
        await react(value167, value168, "❌");
        return send(value167, value168, "❌ No downloadable trailer MP4 found for this title.\n\n💡 Try .trailer <url> to see what info is available.");
      }
      const value172 = value171.title || "Movie Trailer";
      const value173 = value171.trailerUrl;
      await send(value167, value168, "┏━━━ ⬇️ *Downloading Trailer* ━━━\n\n" + ("🎬 *" + value172 + "*\n") + "📥 Fetching MP4, please wait...\n\n┗━━━━━━━━━━━━━━━━");
      let value174 = "┏━━━ 🎬 *Movie Trailer* ━━━\n\n" + ("🎬 *" + value172 + "*\n");
      if (value171.description) {
        value174 += "\n📝 " + value171.description.slice(0, 200).trim() + "\n";
      }
      value174 += "\n▶️ Enjoy the trailer!\n\n┗━━━━━━━━━━━━━━━━";
      await value167.sendMessage(value168.key.remoteJid, {
        video: {
          url: value173
        },
        caption: value174,
        mimetype: "video/mp4",
        gifPlayback: false
      }, {
        quoted: value168
      });
      await react(value167, value168, "✅");
    } catch (error175) {
      await react(value167, value168, "❌");
      await send(value167, value168, "❌ " + error175.message);
    }
  }
}];
