module.exports = [{
  name: "waifu",
  aliases: ["randomwaifu"],
  category: "anime",
  description: "Get a random SFW waifu image",
  usage: ".waifu",
  async execute(value1, value2, value3, value4) {
    await value4.react("✨");
    try {
      await value1.sendMessage(value2.key.remoteJid, {
        image: {
          url: "https://api.shizo.top/sfw/waifu?apikey=shizo"
        },
        caption: "✨ *Random Waifu*"
      }, {
        quoted: value2
      });
      await value4.react("✅");
    } catch (error5) {
      await value4.react("❌");
      await value4.reply("❌ Error: " + error5.message);
    }
  }
}, {
  name: "neko",
  aliases: ["catgirl", "nekogirl"],
  category: "fun",
  description: "Get a random SFW neko image",
  usage: ".neko",
  async execute(value6, value7, value8, value9) {
    await value9.react("🐱");
    try {
      await value6.sendMessage(value7.key.remoteJid, {
        image: {
          url: "https://api.shizo.top/sfw/neko?apikey=shizo"
        },
        caption: "🐱 *Random Neko*"
      }, {
        quoted: value7
      });
      await value9.react("✅");
    } catch (error10) {
      await value9.react("❌");
      await value9.reply("❌ Error: " + error10.message);
    }
  }
}, {
  name: "loli",
  aliases: ["animeloli"],
  category: "anime",
  description: "Get a random SFW happy anime image",
  usage: ".happy",
  async execute(value11, value12, value13, value14) {
    await value14.react("😜");
    try {
      await value11.sendMessage(value12.key.remoteJid, {
        image: {
          url: "https://api.shizo.top/sfw/loli?apikey=shizo"
        },
        caption: "😊 *loli Anime*"
      }, {
        quoted: value12
      });
      await value14.react("✅");
    } catch (error15) {
      await value14.react("❌");
      await value14.reply("❌ Error: " + error15.message);
    }
  }
}, {
  name: "shota",
  aliases: ["animeshota"],
  category: "anime",
  description: "Get a random SFW sad anime image",
  usage: ".shota",
  async execute(value16, value17, value18, value19) {
    await value19.react("😢");
    try {
      await value16.sendMessage(value17.key.remoteJid, {
        image: {
          url: "https://api.shizo.top/sfw/shota?apikey=shizo"
        },
        caption: "😢 *Sad Anime*"
      }, {
        quoted: value17
      });
      await value19.react("✅");
    } catch (error20) {
      await value19.react("❌");
      await value19.reply("❌ Error: " + error20.message);
    }
  }
}, {
  name: "husby",
  aliases: ["husband", "husbando"],
  category: "anime",
  description: "Get a random SFW anime husby image",
  usage: ".husby",
  async execute(value21, value22, value23, value24) {
    await value24.react("💙");
    try {
      await value21.sendMessage(value22.key.remoteJid, {
        image: {
          url: "https://api.shizo.top/sfw/husbando?apikey=shizo"
        },
        caption: "💙 *Random Husby*"
      }, {
        quoted: value22
      });
      await value24.react("✅");
    } catch (error25) {
      await value24.react("❌");
      await value24.reply("❌ Error: " + error25.message);
    }
  }
}];
