const axios = require("axios");
const fs = require("fs");
const path = require("path");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const BASE = "https://api.princetechn.com/api/anime/random";
const API_KEY = "prince";
module.exports = {
  name: "random",
  aliases: ["animerandom", "randomanime"],
  category: "anime",
  desc: "Get random anime data",
  usage: "random",
  execute: async (value1, value2, value3, value4) => {
    try {
      const value5 = BASE + "?apikey=" + API_KEY;
      const value6 = await axios.get(value5, {
        headers: {
          "User-Agent": "Mozilla/5.0",
          Accept: "application/json"
        },
        timeout: 30000
      });
      if (!value6.data || !value6.data.result) {
        throw new Error("Invalid API response: missing anime data");
      }
      const value7 = value6.data.result;
      let value8 = null;
      if (value7.thumbnail) {
        try {
          const value9 = await axios.get(value7.thumbnail, {
            responseType: "arraybuffer",
            headers: {
              "User-Agent": "Mozilla/5.0",
              Accept: "image/*"
            },
            timeout: 30000
          });
          value8 = Buffer.from(value9.data);
          if (value8 && value8.length > 0) {
            const value10 = 5242880;
            if (value8.length > value10) {
              value8 = null;
            }
          }
        } catch (error11) {
          console.error("Error downloading thumbnail:", error11);
          value8 = null;
        }
      }
      let value12 = "*" + (value7.title || "Unknown") + "*\n\n";
      if (value7.episodes) {
        value12 += "📺 Episodes: " + value7.episodes + "\n";
      }
      if (value7.status) {
        value12 += "📊 Status: " + value7.status + "\n";
      }
      if (value7.synopsis) {
        value12 += "\n📝 " + value7.synopsis + "\n";
      }
      if (value7.link) {
        value12 += "\n🔗 " + value7.link;
      }
      if (value8) {
        const value13 = "image/jpeg";
        let value14 = "jpg";
        if (value7.thumbnail.match(/\.(png|jpg|jpeg)$/i)) {
          const value15 = value7.thumbnail.match(/\.(png|jpg|jpeg)$/i);
          value14 = value15[1].toLowerCase();
        }
        const value16 = getTempDir();
        const value17 = Date.now();
        const value18 = path.join(value16, "anime_" + value17 + "." + value14);
        try {
          fs.writeFileSync(value18, value8);
          const value19 = fs.readFileSync(value18);
          await value1.sendMessage(value4.from, {
            image: value19,
            caption: value12
          }, {
            quoted: value2
          });
        } finally {
          try {
            deleteTempFile(value18);
          } catch (error20) {}
        }
      } else {
        await value1.sendMessage(value4.from, {
          text: value12
        }, {
          quoted: value2
        });
      }
    } catch (error21) {
      console.error("Error in random command:", error21);
      if (error21.response?.status === 404) {
        await value4.reply("❌ Anime data not found. Please try again.");
      } else if (error21.response?.status === 429) {
        await value4.reply("❌ Rate limit exceeded. Please try again later.");
      } else if (error21.code === "ECONNABORTED" || error21.message.includes("timeout")) {
        await value4.reply("❌ Request timed out. Please try again.");
      } else {
        await value4.reply("❌ Failed to fetch anime data: " + error21.message);
      }
    }
  }
};
