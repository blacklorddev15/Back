const axios = require("axios");
const fs = require("fs");
const path = require("path");
const {
  getTempDir,
  deleteTempFile
} = require("../../utils/tempManager");
const BASE = "https://api.princetechn.com/api/anime/konachan";
const API_KEY = "prince";
module.exports = {
  name: "konachan",
  aliases: ["konachansfw"],
  category: "anime",
  desc: "Get random konachan SFW anime images",
  usage: "konachan",
  execute: async (value1, value2, value3, value4) => {
    try {
      const value5 = BASE + "?apikey=" + API_KEY;
      const value6 = await axios.get(value5, {
        headers: {
          "User-Agent": "Mozilla/5.0",
          Accept: "application/json"
        },
        timeout: 30000
      });
      if (!value6.data || !value6.data.result) {
        throw new Error("Invalid API response: missing image URL");
      }
      const value7 = value6.data.result;
      if (!value7 || typeof value7 !== "string") {
        throw new Error("Invalid image URL in API response");
      }
      const value8 = await axios.get(value7, {
        responseType: "arraybuffer",
        headers: {
          "User-Agent": "Mozilla/5.0",
          Accept: "image/*"
        },
        timeout: 30000
      });
      const value9 = Buffer.from(value8.data);
      if (!value9 || value9.length === 0) {
        throw new Error("Empty image response");
      }
      const value10 = 5242880;
      if (value9.length > value10) {
        throw new Error("Image too large: " + (value9.length / 1024 / 1024).toFixed(2) + "MB (max 5MB)");
      }
      const value11 = value8.headers["content-type"] || "";
      let value12 = "jpg";
      if (value11.includes("png")) {
        value12 = "png";
      } else if (value11.includes("jpeg")) {
        value12 = "jpg";
      } else if (value7.match(/\.(png|jpg|jpeg)$/i)) {
        const value13 = value7.match(/\.(png|jpg|jpeg)$/i);
        value12 = value13[1].toLowerCase();
      }
      const value14 = getTempDir();
      const value15 = Date.now();
      const value16 = path.join(value14, "konachan_" + value15 + "." + value12);
      let value17 = null;
      try {
        fs.writeFileSync(value16, value9);
        value17 = fs.readFileSync(value16);
        if (!value17 || value17.length === 0) {
          throw new Error("Failed to read image from temp file");
        }
        await value1.sendMessage(value4.from, {
          image: value17
        }, {
          quoted: value2
        });
      } finally {
        try {
          deleteTempFile(value16);
        } catch (error18) {}
      }
    } catch (error19) {
      console.error("Error in konachan command:", error19);
      if (error19.response?.status === 404) {
        await value4.reply("❌ Image not found. Please try again.");
      } else if (error19.response?.status === 429) {
        await value4.reply("❌ Rate limit exceeded. Please try again later.");
      } else if (error19.code === "ECONNABORTED" || error19.message.includes("timeout")) {
        await value4.reply("❌ Request timed out. Please try again.");
      } else {
        await value4.reply("❌ Failed to fetch konachan image: " + error19.message);
      }
    }
  }
};
