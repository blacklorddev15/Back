const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "gradientlogo",
  description: "Create beautiful gradient style text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🌈 *GRADIENT LOGO*\n\n*gradientlogo*\ngradientlogo <text>\n\n*Example:*\ngradientlogo WOLF\ngradientlogo GRADIENT\ngradientlogo COLORFUL\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateGradientLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🌈 *Gradient Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [GRADIENTLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateGradientLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  const value17 = getRandomGradientColors();
  const value18 = value16.createLinearGradient(0, 0, value13, value14);
  value18.addColorStop(0, value17[0]);
  value18.addColorStop(0.5, value17[1]);
  value18.addColorStop(1, value17[2]);
  value16.fillStyle = value18;
  value16.fillRect(0, 0, value13, value14);
  addPatternOverlay(value16, value13, value14);
  const value19 = value16.createLinearGradient(0, 150, 0, 250);
  value19.addColorStop(0, getContrastColor(value17[0]));
  value19.addColorStop(0.5, getContrastColor(value17[1]));
  value19.addColorStop(1, getContrastColor(value17[2]));
  value16.font = "bold 80px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  value16.shadowColor = "rgba(0, 0, 0, 0.5)";
  value16.shadowBlur = 15;
  value16.shadowOffsetX = 3;
  value16.shadowOffsetY = 3;
  value16.fillStyle = value19;
  value16.fillText(value12.toUpperCase(), value13 / 2, value14 / 2);
  value16.strokeStyle = "rgba(255, 255, 255, 0.3)";
  value16.lineWidth = 2;
  value16.strokeText(value12.toUpperCase(), value13 / 2, value14 / 2);
  value16.shadowColor = "transparent";
  value16.shadowBlur = 0;
  value16.shadowOffsetX = 0;
  value16.shadowOffsetY = 0;
  drawModernBorder(value16, value13, value14, value17);
  addFloatingParticles(value16, value13, value14, value17);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function getRandomGradientColors() {
  const value20 = [["#667eea", "#764ba2", "#f093fb"], ["#4facfe", "#00f2fe", "#43e97b"], ["#fa709a", "#fee140", "#ff6b6b"], ["#a8edea", "#fed6e3", "#a8edea"], ["#ff9a9e", "#fecfef", "#fecfef"], ["#a1c4fd", "#c2e9fb", "#a1c4fd"], ["#d4fc79", "#96e6a1", "#d4fc79"], ["#fad0c4", "#ffd1ff", "#fad0c4"], ["#ffecd2", "#fcb69f", "#ffecd2"], ["#a3bded", "#6991c7", "#a3bded"], ["#ff9a8b", "#ff6a88", "#ff99ac"], ["#cd9cf2", "#f6f3ff", "#cd9cf2"], ["#6a11cb", "#2575fc", "#6a11cb"], ["#ff8177", "#ff867a", "#ff8c7f"], ["#74ebd5", "#9face6", "#74ebd5"]];
  return value20[Math.floor(Math.random() * value20.length)];
}
function getContrastColor(value21) {
  const value22 = parseInt(value21.slice(1, 3), 16);
  const value23 = parseInt(value21.slice(3, 5), 16);
  const value24 = parseInt(value21.slice(5, 7), 16);
  const value25 = (value22 * 0.299 + value23 * 0.587 + value24 * 0.114) / 255;
  if (value25 > 0.5) {
    return "#000000";
  } else {
    return "#FFFFFF";
  }
}
function addPatternOverlay(value26, value27, value28) {
  value26.globalAlpha = 0.1;
  value26.strokeStyle = "#FFFFFF";
  value26.lineWidth = 1;
  for (let value29 = -value27; value29 < value27 * 2; value29 += 25) {
    value26.beginPath();
    value26.moveTo(value29, 0);
    value26.lineTo(value29 + value28, value28);
    value26.stroke();
  }
  for (let value30 = -value27; value30 < value27 * 2; value30 += 25) {
    value26.beginPath();
    value26.moveTo(value30, value28);
    value26.lineTo(value30 + value28, 0);
    value26.stroke();
  }
  value26.globalAlpha = 1;
}
function drawModernBorder(value31, value32, value33, value34) {
  const value35 = value31.createLinearGradient(0, 0, value32, value33);
  value35.addColorStop(0, value34[0]);
  value35.addColorStop(0.5, value34[1]);
  value35.addColorStop(1, value34[2]);
  value31.strokeStyle = value35;
  value31.lineWidth = 6;
  value31.shadowColor = value34[1];
  value31.shadowBlur = 10;
  value31.strokeRect(15, 15, value32 - 30, value33 - 30);
  value31.strokeStyle = "rgba(255, 255, 255, 0.3)";
  value31.lineWidth = 2;
  value31.shadowBlur = 0;
  value31.strokeRect(25, 25, value32 - 50, value33 - 50);
}
function addFloatingParticles(value36, value37, value38, value39) {
  value36.globalAlpha = 0.6;
  for (let value40 = 0; value40 < 30; value40++) {
    const value41 = Math.random() * value37;
    const value42 = Math.random() * value38;
    const value43 = Math.random() * 4 + 1;
    const value44 = Math.floor(Math.random() * value39.length);
    value36.fillStyle = value39[value44];
    value36.beginPath();
    value36.arc(value41, value42, value43, 0, Math.PI * 2);
    value36.fill();
  }
  value36.globalAlpha = 1;
}
async function generateCustomGradientLogo(value45, value46, value47, value48) {
  const value49 = 800;
  const value50 = 400;
  const value51 = createCanvas(value49, value50);
  const value52 = value51.getContext("2d");
  const value53 = value52.createLinearGradient(0, 0, value49, value50);
  value53.addColorStop(0, value46 || "#667eea");
  value53.addColorStop(0.5, value47 || "#764ba2");
  value53.addColorStop(1, value48 || "#f093fb");
  value52.fillStyle = value53;
  value52.fillRect(0, 0, value49, value50);
  value52.font = "bold 80px \"Arial\"";
  value52.fillStyle = getContrastColor(value46);
  value52.textAlign = "center";
  value52.textBaseline = "middle";
  value52.shadowColor = "rgba(0, 0, 0, 0.5)";
  value52.shadowBlur = 10;
  value52.fillText(value45.toUpperCase(), value49 / 2, value50 / 2);
  return value51.toBuffer("image/png");
}
