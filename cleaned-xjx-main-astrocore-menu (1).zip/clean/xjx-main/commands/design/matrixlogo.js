const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "matrixlogo",
  description: "Create Matrix-style digital rain text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🟢 *MATRIX LOGO*\n\n*matrixlogo*\nmatrixlogo <text>\n\n*Example:*\nmatrixlogo WOLF\nmatrixlogo MATRIX\nmatrixlogo NEO\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 12) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 12 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateMatrixLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🟢 *Matrix Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [MATRIXLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateMatrixLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#000000";
  value16.fillRect(0, 0, value13, value14);
  generateDigitalRain(value16, value13, value14);
  createMatrixText(value16, value12, value13, value14);
  addMatrixEffects(value16, value13, value14);
  addBinaryBackground(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function generateDigitalRain(value17, value18, value19) {
  const value20 = Math.floor(value18 / 20);
  const value21 = Array(value20).fill(1);
  for (let value22 = 0; value22 < 3; value22++) {
    const value23 = 2 + value22;
    const value24 = 12 - value22 * 2;
    const value25 = 0.3 + value22 * 0.2;
    value17.font = value24 + "px \"Courier New\", monospace";
    for (let value26 = 0; value26 < value21.length; value26++) {
      const value27 = "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ0123456789#$%&@*";
      const value28 = value27[Math.floor(Math.random() * value27.length)];
      const value29 = value26 * 20;
      const value30 = value21[value26] * value24;
      const value31 = value30 / value19;
      const value32 = value25 * (1 - value31);
      const value33 = Math.floor(100 + (1 - value31) * 155);
      value17.fillStyle = "rgba(0, " + value33 + ", 0, " + value32 + ")";
      value17.fillText(value28, value29, value30);
      if (value30 > value19 && Math.random() > 0.975) {
        value21[value26] = 0;
      }
      value21[value26]++;
    }
  }
}
function createMatrixText(value34, value35, value36, value37) {
  const value38 = value36 / 2;
  const value39 = value37 / 2;
  for (let value40 = 0; value40 < 5; value40++) {
    const value41 = (Math.random() - 0.5) * 4;
    const value42 = (Math.random() - 0.5) * 4;
    const value43 = 0.1 + value40 * 0.1;
    const value44 = ["#00FF00", "#00CC00", "#009900", "#00FF66", "#66FF00"];
    value34.fillStyle = "" + value44[value40] + Math.floor(value43 * 255).toString(16).padStart(2, "0");
    value34.font = "bold 70px \"Courier New\", monospace";
    value34.textAlign = "center";
    value34.textBaseline = "middle";
    value34.fillText(value35.toUpperCase(), value38 + value41, value39 + value42);
  }
  value34.fillStyle = "#00FF00";
  value34.font = "bold 72px \"Courier New\", monospace";
  value34.textAlign = "center";
  value34.textBaseline = "middle";
  value34.shadowColor = "#00FF00";
  value34.shadowBlur = 20;
  value34.fillText(value35.toUpperCase(), value38, value39);
  value34.shadowColor = "transparent";
  value34.shadowBlur = 0;
  addTextGlitches(value34, value35, value36, value37);
}
function addTextGlitches(value45, value46, value47, value48) {
  const value49 = value47 / 2;
  const value50 = value48 / 2;
  const value51 = value45.measureText(value46.toUpperCase()).width;
  value45.save();
  for (let value52 = 0; value52 < 15; value52++) {
    const value53 = value49 - value51 / 2 + Math.random() * value51;
    const value54 = value50 - 35 + Math.random() * 70;
    const value55 = 2 + Math.random() * 8;
    const value56 = 1 + Math.random() * 3;
    const value57 = 0.3 + Math.random() * 0.7;
    value45.fillStyle = "rgba(0, 255, 0, " + value57 + ")";
    value45.fillRect(value53, value54, value55, value56);
  }
  const value58 = "01";
  for (let value59 = 0; value59 < 8; value59++) {
    const value60 = value49 - value51 / 2 + Math.random() * value51;
    const value61 = value50 + 40;
    const value62 = 10 + Math.floor(Math.random() * 20);
    const value63 = 2 + Math.random() * 3;
    value45.font = "12px \"Courier New\", monospace";
    value45.fillStyle = "#00FF00";
    for (let value64 = 0; value64 < value62; value64++) {
      const value65 = value58[Math.floor(Math.random() * value58.length)];
      const value66 = 1 - value64 / value62;
      value45.globalAlpha = value66;
      value45.fillText(value65, value60, value61 + value64 * value63);
    }
    value45.globalAlpha = 1;
  }
  value45.restore();
}
function addMatrixEffects(value67, value68, value69) {
  value67.strokeStyle = "rgba(0, 255, 0, 0.1)";
  value67.lineWidth = 1;
  for (let value70 = 0; value70 < value69; value70 += 4) {
    value67.beginPath();
    value67.moveTo(0, value70);
    value67.lineTo(value68, value70);
    value67.stroke();
  }
  for (let value71 = 0; value71 < 200; value71++) {
    const value72 = Math.random() * value68;
    const value73 = Math.random() * value69;
    const value74 = Math.random() * 2;
    const value75 = 0.1 + Math.random() * 0.3;
    value67.fillStyle = "rgba(0, 255, 0, " + value75 + ")";
    value67.fillRect(value72, value73, value74, value74);
  }
  for (let value76 = 0; value76 < 5; value76++) {
    const value77 = Math.random() * value68;
    const value78 = Math.random() * value69;
    const value79 = 50 + Math.random() * 100;
    const value80 = 2 + Math.random() * 5;
    const value81 = 0.05 + Math.random() * 0.1;
    value67.fillStyle = "rgba(255, 255, 255, " + value81 + ")";
    value67.fillRect(value77, value78, value79, value80);
  }
}
function addBinaryBackground(value82, value83, value84) {
  value82.save();
  value82.globalAlpha = 0.1;
  value82.font = "10px \"Courier New\", monospace";
  value82.fillStyle = "#00FF00";
  const value85 = "01";
  const value86 = Math.floor(value83 / 15);
  const value87 = Math.floor(value84 / 15);
  for (let value88 = 0; value88 < value86; value88++) {
    for (let value89 = 0; value89 < value87; value89++) {
      if (Math.random() > 0.7) {
        const value90 = value85[Math.floor(Math.random() * value85.length)];
        value82.fillText(value90, value88 * 15, value89 * 15);
      }
    }
  }
  value82.restore();
}
async function generateSimpleMatrixLogo(value91) {
  const value92 = 600;
  const value93 = 300;
  const value94 = createCanvas(value92, value93);
  const value95 = value94.getContext("2d");
  value95.fillStyle = "#000000";
  value95.fillRect(0, 0, value92, value93);
  for (let value96 = 0; value96 < 50; value96++) {
    const value97 = Math.random() * value92;
    const value98 = Math.random() * value93;
    const value99 = 0.1 + Math.random() * 0.3;
    value95.fillStyle = "rgba(0, 255, 0, " + value99 + ")";
    value95.font = "12px \"Courier New\", monospace";
    value95.fillText(Math.random() > 0.5 ? "0" : "1", value97, value98);
  }
  value95.fillStyle = "#00FF00";
  value95.font = "bold 60px \"Courier New\", monospace";
  value95.textAlign = "center";
  value95.textBaseline = "middle";
  value95.shadowColor = "#00FF00";
  value95.shadowBlur = 15;
  value95.fillText(value91.toUpperCase(), value92 / 2, value93 / 2);
  value95.strokeStyle = "rgba(0, 255, 0, 0.1)";
  value95.lineWidth = 1;
  for (let value100 = 0; value100 < value93; value100 += 3) {
    value95.beginPath();
    value95.moveTo(0, value100);
    value95.lineTo(value92, value100);
    value95.stroke();
  }
  return value94.toBuffer("image/png");
}
