const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "aqualogo",
  category: "design",
  description: "Create stunning aquatic text logos with water effects and ocean themes",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🌊 *AQUA LOGO*\n\n*aqualogo*\naqualogo <text>\n\n*Example:*\naqualogo OCEAN\naqualogo WATER\naqualogo MARINE\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateAquaLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🌊 *Aqua Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [AQUALOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateAquaLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createUnderwaterBackground(value16, value13, value14);
  addWaterSurface(value16, value13, value14);
  drawWaterText(value16, value12, value13, value14);
  addBubbles(value16, value13, value14);
  addAquaticLife(value16, value13, value14);
  addLightRays(value16, value13, value14);
  addCaustics(value16, value13, value14);
  addWaterDistortion(value16, value13, value14);
  drawAquaticBorder(value16, value13, value14);
  addAquaSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createUnderwaterBackground(value17, value18, value19) {
  const value20 = value17.createLinearGradient(0, 0, 0, value19);
  value20.addColorStop(0, "#006994");
  value20.addColorStop(0.3, "#005a7a");
  value20.addColorStop(0.6, "#004a66");
  value20.addColorStop(1, "#00394d");
  value17.fillStyle = value20;
  value17.fillRect(0, 0, value18, value19);
  addOceanDepthTexture(value17, value18, value19);
  addCoralReefs(value17, value18, value19);
}
function addOceanDepthTexture(value21, value22, value23) {
  value21.save();
  value21.globalAlpha = 0.1;
  for (let value24 = 0; value24 < 500; value24++) {
    const value25 = Math.random() * value22;
    const value26 = Math.random() * value23;
    const value27 = 2 + Math.random() * 8;
    const value28 = 30 + Math.random() * 40;
    value21.fillStyle = "rgba(" + value28 + ", " + (value28 + 50) + ", " + (value28 + 70) + ", 0.3)";
    value21.beginPath();
    value21.arc(value25, value26, value27, 0, Math.PI * 2);
    value21.fill();
  }
  value21.strokeStyle = "rgba(0, 80, 120, 0.2)";
  value21.lineWidth = 1;
  for (let value29 = 50; value29 < value23; value29 += 40) {
    value21.beginPath();
    value21.moveTo(0, value29);
    value21.lineTo(value22, value29);
    value21.stroke();
  }
  value21.restore();
}
function addWaterSurface(value30, value31, value32) {
  value30.save();
  const value33 = value30.createLinearGradient(0, 0, 0, value32 * 0.3);
  value33.addColorStop(0, "rgba(0, 150, 200, 0.6)");
  value33.addColorStop(0.5, "rgba(0, 100, 150, 0.3)");
  value33.addColorStop(1, "transparent");
  value30.fillStyle = value33;
  value30.fillRect(0, 0, value31, value32 * 0.3);
  drawSurfaceWaves(value30, value31, value32);
  addSunlightPenetration(value30, value31, value32);
  value30.restore();
}
function drawSurfaceWaves(value34, value35, value36) {
  value34.save();
  value34.globalAlpha = 0.4;
  for (let value37 = 0; value37 < 3; value37++) {
    const value38 = 5 + value37 * 3;
    const value39 = value36 * 0.1 + value37 * 15;
    value34.strokeStyle = "rgba(255, 255, 255, " + (0.3 - value37 * 0.1) + ")";
    value34.lineWidth = 1;
    value34.beginPath();
    for (let value40 = 0; value40 <= value35; value40 += 2) {
      const value41 = value39 + Math.sin(value40 * 0.02 + value37) * value38;
      if (value40 === 0) {
        value34.moveTo(value40, value41);
      } else {
        value34.lineTo(value40, value41);
      }
    }
    value34.stroke();
  }
  value34.strokeStyle = "rgba(255, 255, 255, 0.6)";
  value34.lineWidth = 1;
  value34.beginPath();
  for (let value42 = 0; value42 <= value35; value42 += 3) {
    const value43 = value36 * 0.08 + Math.sin(value42 * 0.015) * 8;
    if (value42 === 0) {
      value34.moveTo(value42, value43);
    } else {
      value34.lineTo(value42, value43);
    }
  }
  value34.stroke();
  value34.restore();
}
function addSunlightPenetration(value44, value45, value46) {
  value44.save();
  value44.globalCompositeOperation = "screen";
  value44.globalAlpha = 0.2;
  const value47 = value44.createRadialGradient(value45 * 0.5, 0, 0, value45 * 0.5, 0, value45 * 0.8);
  value47.addColorStop(0, "rgba(255, 255, 200, 0.6)");
  value47.addColorStop(0.5, "rgba(200, 230, 255, 0.3)");
  value47.addColorStop(1, "transparent");
  value44.fillStyle = value47;
  value44.fillRect(0, 0, value45, value46 * 0.5);
  for (let value48 = 0; value48 < 8; value48++) {
    const value49 = value45 * 0.2 + value48 / 7 * value45 * 0.6;
    const value50 = 20 + Math.random() * 30;
    const value51 = value44.createLinearGradient(value49, 0, value49, value46);
    value51.addColorStop(0, "rgba(255, 255, 220, 0.4)");
    value51.addColorStop(0.3, "rgba(200, 230, 255, 0.2)");
    value51.addColorStop(1, "transparent");
    value44.fillStyle = value51;
    value44.fillRect(value49 - value50 / 2, 0, value50, value46);
  }
  value44.restore();
}
function drawWaterText(value52, value53, value54, value55) {
  const value56 = value54 * 0.5;
  const value57 = value55 * 0.6;
  value52.save();
  value52.shadowColor = "rgba(0, 150, 200, 0.8)";
  value52.shadowBlur = 30;
  const value58 = value52.createLinearGradient(value56 - 100, value57 - 50, value56 + 100, value57 + 50);
  value58.addColorStop(0, "#ffffff");
  value58.addColorStop(0.3, "#aaddff");
  value58.addColorStop(0.6, "#66bbff");
  value58.addColorStop(1, "#3399ff");
  value52.font = "bold 68px \"Arial\"";
  value52.textAlign = "center";
  value52.textBaseline = "middle";
  value52.fillStyle = value58;
  value52.fillText(value53.toUpperCase(), value56, value57);
  addWaterDroplets(value52, value53, value56, value57);
  value52.shadowColor = "transparent";
  value52.strokeStyle = "rgba(255, 255, 255, 0.8)";
  value52.lineWidth = 2;
  value52.strokeText(value53.toUpperCase(), value56, value57);
  value52.fillStyle = "rgba(200, 230, 255, 0.6)";
  value52.fillText(value53.toUpperCase(), value56, value57);
  addTextDistortion(value52, value53, value56, value57);
  value52.restore();
}
function addWaterDroplets(value59, value60, value61, value62) {
  value59.save();
  value59.globalCompositeOperation = "screen";
  const value63 = value59.measureText(value60.toUpperCase());
  const value64 = value63.width;
  const value65 = 68;
  for (let value66 = 0; value66 < 20; value66++) {
    const value67 = value61 - value64 / 2 + Math.random() * value64;
    const value68 = value62 - value65 / 2 + Math.random() * value65;
    const value69 = 2 + Math.random() * 8;
    if (Math.random() > 0.3) {
      value59.fillStyle = "rgba(255, 255, 255, 0.9)";
      value59.beginPath();
      value59.arc(value67, value68, value69 * 0.3, 0, Math.PI * 2);
      value59.fill();
      const value70 = value59.createRadialGradient(value67, value68, 0, value67, value68, value69);
      value70.addColorStop(0, "rgba(150, 200, 255, 0.8)");
      value70.addColorStop(1, "rgba(100, 150, 255, 0.4)");
      value59.fillStyle = value70;
      value59.beginPath();
      value59.arc(value67, value68, value69, 0, Math.PI * 2);
      value59.fill();
      value59.fillStyle = "rgba(0, 50, 100, 0.3)";
      value59.beginPath();
      value59.arc(value67 + value69 * 0.3, value68 + value69 * 0.3, value69 * 0.8, 0, Math.PI * 2);
      value59.fill();
    }
  }
  value59.restore();
}
function addTextDistortion(value71, value72, value73, value74) {
  value71.save();
  value71.globalAlpha = 0.3;
  const value75 = value71.measureText(value72.toUpperCase());
  const value76 = value75.width;
  for (let value77 = value73 - value76 / 2; value77 < value73 + value76 / 2; value77 += 10) {
    const value78 = 2 + Math.sin(value77 * 0.1) * 5;
    const value79 = value74 + 35 + value78;
    value71.strokeStyle = "rgba(255, 255, 255, 0.4)";
    value71.lineWidth = 1;
    value71.beginPath();
    value71.moveTo(value77, value74 + 35);
    value71.lineTo(value77, value79);
    value71.stroke();
  }
  value71.restore();
}
function addBubbles(value80, value81, value82) {
  value80.save();
  for (let value83 = 0; value83 < 15; value83++) {
    const value84 = Math.random() * value81;
    const value85 = value82 * 0.2 + Math.random() * value82 * 0.7;
    const value86 = 8 + Math.random() * 25;
    drawBubble(value80, value84, value85, value86);
  }
  for (let value87 = 0; value87 < 30; value87++) {
    const value88 = Math.random() * value81;
    const value89 = value82 * 0.3 + Math.random() * value82 * 0.6;
    const value90 = 4 + Math.random() * 12;
    drawBubble(value80, value88, value89, value90);
  }
  for (let value91 = 0; value91 < 100; value91++) {
    const value92 = Math.random() * value81;
    const value93 = value82 * 0.4 + Math.random() * value82 * 0.5;
    const value94 = 1 + Math.random() * 6;
    drawBubble(value80, value92, value93, value94);
  }
  addBubbleStreams(value80, value81, value82);
  value80.restore();
}
function drawBubble(value95, value96, value97, value98) {
  const value99 = value95.createRadialGradient(value96, value97, 0, value96, value97, value98);
  value99.addColorStop(0, "rgba(255, 255, 255, 0.9)");
  value99.addColorStop(0.7, "rgba(200, 230, 255, 0.6)");
  value99.addColorStop(1, "rgba(150, 200, 255, 0.3)");
  value95.fillStyle = value99;
  value95.beginPath();
  value95.arc(value96, value97, value98, 0, Math.PI * 2);
  value95.fill();
  value95.fillStyle = "rgba(255, 255, 255, 0.8)";
  value95.beginPath();
  value95.arc(value96 - value98 * 0.3, value97 - value98 * 0.3, value98 * 0.4, 0, Math.PI * 2);
  value95.fill();
  value95.fillStyle = "rgba(255, 255, 255, 0.4)";
  value95.beginPath();
  value95.arc(value96 + value98 * 0.2, value97 + value98 * 0.2, value98 * 0.3, 0, Math.PI * 2);
  value95.fill();
}
function addBubbleStreams(value100, value101, value102) {
  value100.save();
  value100.globalAlpha = 0.6;
  const value103 = [{
    x: value101 * 0.2,
    count: 12
  }, {
    x: value101 * 0.4,
    count: 8
  }, {
    x: value101 * 0.6,
    count: 10
  }, {
    x: value101 * 0.8,
    count: 15
  }];
  value103.forEach(value104 => {
    for (let value105 = 0; value105 < value104.count; value105++) {
      const value106 = value102 * 0.7 + value105 / value104.count * value102 * 0.3;
      const value107 = 3 + Math.random() * 8;
      const value108 = (Math.random() - 0.5) * 20;
      drawBubble(value100, value104.x + value108, value106, value107);
    }
  });
  value100.restore();
}
function addAquaticLife(value109, value110, value111) {
  value109.save();
  for (let value112 = 0; value112 < 6; value112++) {
    const value113 = value110 * 0.1 + Math.random() * value110 * 0.8;
    const value114 = value111 * 0.3 + Math.random() * value111 * 0.5;
    const value115 = 15 + Math.random() * 20;
    const value116 = Math.random() > 0.5 ? 1 : -1;
    drawFish(value109, value113, value114, value115, value116);
  }
  addSeaweed(value109, value110, value111);
  value109.restore();
}
function drawFish(value117, value118, value119, value120, value121) {
  value117.save();
  value117.globalAlpha = 0.7;
  const value122 = value117.createLinearGradient(value118 - value120 * value121, value119, value118 + value120 * value121, value119);
  value122.addColorStop(0, "#ff6b6b");
  value122.addColorStop(0.5, "#ff8e8e");
  value122.addColorStop(1, "#ff5252");
  value117.fillStyle = value122;
  value117.beginPath();
  value117.ellipse(value118, value119, value120, value120 * 0.5, 0, 0, Math.PI * 2);
  value117.fill();
  value117.fillStyle = "#ff4444";
  value117.beginPath();
  value117.moveTo(value118 + value120 * value121, value119);
  value117.lineTo(value118 + value120 * 1.5 * value121, value119 - value120 * 0.5);
  value117.lineTo(value118 + value120 * 1.5 * value121, value119 + value120 * 0.5);
  value117.closePath();
  value117.fill();
  value117.fillStyle = "black";
  value117.beginPath();
  value117.arc(value118 - value120 * 0.5 * value121, value119, value120 * 0.15, 0, Math.PI * 2);
  value117.fill();
  value117.fillStyle = "#ff7777";
  value117.beginPath();
  value117.moveTo(value118 - value120 * 0.2 * value121, value119 - value120 * 0.3);
  value117.lineTo(value118 + value120 * 0.3 * value121, value119 - value120 * 0.6);
  value117.lineTo(value118 + value120 * 0.1 * value121, value119 - value120 * 0.3);
  value117.closePath();
  value117.fill();
  value117.restore();
}
function addSeaweed(value123, value124, value125) {
  value123.save();
  value123.globalAlpha = 0.6;
  const value126 = [{
    x: value124 * 0.1,
    height: 80
  }, {
    x: value124 * 0.9,
    height: 120
  }, {
    x: value124 * 0.3,
    height: 90
  }, {
    x: value124 * 0.7,
    height: 110
  }];
  value126.forEach(value127 => {
    value123.strokeStyle = "#2e8b57";
    value123.lineWidth = 3;
    value123.lineCap = "round";
    value123.beginPath();
    value123.moveTo(value127.x, value125 - 20);
    for (let value128 = 0; value128 <= 10; value128++) {
      const value129 = value125 - 20 - value128 / 10 * value127.height;
      const value130 = Math.sin(value128 * 0.8) * 15;
      value123.lineTo(value127.x + value130, value129);
    }
    value123.stroke();
    value123.strokeStyle = "#3cb371";
    value123.lineWidth = 2;
    for (let value131 = 2; value131 <= 8; value131 += 2) {
      const value132 = value125 - 20 - value131 / 10 * value127.height;
      const value133 = Math.sin(value131 * 0.8) * 15;
      value123.beginPath();
      value123.moveTo(value127.x + value133, value132);
      value123.lineTo(value127.x + value133 + 20, value132 - 15);
      value123.stroke();
      value123.beginPath();
      value123.moveTo(value127.x + value133, value132);
      value123.lineTo(value127.x + value133 - 20, value132 - 10);
      value123.stroke();
    }
  });
  value123.restore();
}
function addLightRays(value134, value135, value136) {
  value134.save();
  value134.globalCompositeOperation = "screen";
  value134.globalAlpha = 0.15;
  for (let value137 = 0; value137 < 5; value137++) {
    const value138 = value135 * 0.2 + value137 / 4 * value135 * 0.6;
    const value139 = 15 + Math.random() * 25;
    const value140 = value134.createLinearGradient(value138, 0, value138, value136);
    value140.addColorStop(0, "rgba(255, 255, 220, 0.6)");
    value140.addColorStop(0.5, "rgba(200, 230, 255, 0.3)");
    value140.addColorStop(1, "transparent");
    value134.fillStyle = value140;
    value134.fillRect(value138 - value139 / 2, 0, value139, value136);
  }
  value134.restore();
}
function addCaustics(value141, value142, value143) {
  value141.save();
  value141.globalCompositeOperation = "screen";
  value141.globalAlpha = 0.1;
  for (let value144 = value143 * 0.3; value144 < value143; value144 += 40) {
    for (let value145 = 0; value145 < value142; value145 += 50) {
      const value146 = 0.3 + Math.sin(value145 * 0.02 + value144 * 0.01) * 0.3;
      const value147 = 20 + Math.sin(value145 * 0.03) * 10;
      value141.fillStyle = "rgba(255, 255, 255, " + value146 + ")";
      value141.beginPath();
      value141.arc(value145 + Math.sin(value144 * 0.02) * 10, value144, value147, 0, Math.PI * 2);
      value141.fill();
    }
  }
  value141.restore();
}
function addCoralReefs(value148, value149, value150) {
  value148.save();
  value148.globalAlpha = 0.3;
  const value151 = [{
    x: value149 * 0.05,
    y: value150 * 0.8,
    color: "#ff6b6b",
    size: 30
  }, {
    x: value149 * 0.15,
    y: value150 * 0.75,
    color: "#ffa726",
    size: 25
  }, {
    x: value149 * 0.85,
    y: value150 * 0.82,
    color: "#ab47bc",
    size: 35
  }, {
    x: value149 * 0.95,
    y: value150 * 0.78,
    color: "#26c6da",
    size: 28
  }];
  value151.forEach(value152 => {
    value148.fillStyle = value152.color;
    for (let value153 = 0; value153 < 5; value153++) {
      const value154 = value153 / 5 * Math.PI * 2;
      const value155 = value152.size * (0.5 + Math.random() * 0.5);
      value148.beginPath();
      value148.moveTo(value152.x, value152.y);
      value148.lineTo(value152.x + Math.cos(value154) * value155, value152.y + Math.sin(value154) * value155);
      value148.stroke();
      value148.beginPath();
      value148.arc(value152.x + Math.cos(value154) * value155, value152.y + Math.sin(value154) * value155, value152.size * 0.2, 0, Math.PI * 2);
      value148.fill();
    }
  });
  value148.restore();
}
function addWaterDistortion(value156, value157, value158) {
  value156.save();
  value156.globalAlpha = 0.05;
  for (let value159 = 0; value159 < 8; value159++) {
    const value160 = Math.random() * value157;
    const value161 = Math.random() * value158;
    const value162 = 50 + Math.random() * 100;
    value156.strokeStyle = "rgba(255, 255, 255, 0.3)";
    value156.lineWidth = 1;
    for (let value163 = 0; value163 < 3; value163++) {
      const value164 = value162 + value163 * 30;
      value156.beginPath();
      value156.arc(value160, value161, value164, 0, Math.PI * 2);
      value156.stroke();
    }
  }
  value156.restore();
}
function drawAquaticBorder(value165, value166, value167) {
  value165.save();
  const value168 = value165.createLinearGradient(0, 0, value166, value167);
  value168.addColorStop(0, "#006994");
  value168.addColorStop(0.3, "#0088cc");
  value168.addColorStop(0.7, "#00aaff");
  value168.addColorStop(1, "#006994");
  value165.strokeStyle = value168;
  value165.lineWidth = 8;
  value165.shadowColor = "rgba(0, 150, 255, 0.6)";
  value165.shadowBlur = 20;
  value165.strokeRect(10, 10, value166 - 20, value167 - 20);
  value165.strokeStyle = "rgba(200, 230, 255, 0.6)";
  value165.lineWidth = 2;
  value165.shadowBlur = 10;
  value165.strokeRect(20, 20, value166 - 40, value167 - 40);
  value165.restore();
}
function addAquaSignature(value169, value170, value171) {
  value169.save();
  const value172 = value170 - 110;
  const value173 = value171 - 25;
  value169.font = "italic 14px \"Arial\"";
  value169.fillStyle = "rgba(150, 220, 255, 0.9)";
  value169.textAlign = "right";
  value169.textBaseline = "bottom";
  value169.shadowColor = "rgba(0, 150, 255, 0.5)";
  value169.shadowBlur = 15;
  value169.fillText("by " + getBotName(), value172, value173);
  const value174 = value169.createRadialGradient(value172 + 5, value173 - 8, 0, value172 + 5, value173 - 8, 6);
  value174.addColorStop(0, "rgba(150, 200, 255, 0.8)");
  value174.addColorStop(1, "rgba(100, 150, 255, 0.4)");
  value169.fillStyle = value174;
  value169.beginPath();
  value169.arc(value172 + 5, value173 - 8, 6, 0, Math.PI * 2);
  value169.fill();
  value169.fillStyle = "rgba(255, 255, 255, 0.8)";
  value169.beginPath();
  value169.arc(value172 + 3, value173 - 10, 2, 0, Math.PI * 2);
  value169.fill();
  value169.restore();
}
