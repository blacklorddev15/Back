const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "bronzelogo",
  category: "design",
  description: "Create authentic bronze metallic text logos with patina effects",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🟫 *BRONZE LOGO*\n\n*bronzelogo*\nbronzelogo <text>\n\n*Example:*\nbronzelogo WOLF\nbronzelogo BRONZE\nbronzelogo ANCIENT\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateBronzeLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🟫 *Bronze Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [BRONZELOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateBronzeLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#2a1e0f";
  value16.fillRect(0, 0, value13, value14);
  drawAntiqueBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 100, 0, 300);
  value17.addColorStop(0, "#CD7F32");
  value17.addColorStop(0.15, "#B87333");
  value17.addColorStop(0.3, "#A65A29");
  value17.addColorStop(0.45, "#8B4513");
  value17.addColorStop(0.6, "#654321");
  value17.addColorStop(0.75, "#5D4037");
  value17.addColorStop(0.9, "#4E342E");
  value17.addColorStop(1, "#3E2723");
  value16.font = "bold 84px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createBronze3DEffect(value16, value12, value13, value14, value17);
  addBronzePatina(value16, value12, value13, value14);
  addBronzeHighlights(value16, value12, value13, value14);
  drawAgedBorder(value16, value13, value14);
  addBronzeTexture(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawAntiqueBackground(value18, value19, value20) {
  const value21 = value18.createLinearGradient(0, 0, value19, value20);
  value21.addColorStop(0, "#3a2c1a");
  value21.addColorStop(0.5, "#2a1e0f");
  value21.addColorStop(1, "#1a140a");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  value18.strokeStyle = "rgba(90, 70, 40, 0.1)";
  value18.lineWidth = 1;
  for (let value22 = 0; value22 < 200; value22++) {
    const value23 = Math.random() * value19;
    const value24 = Math.random() * value20;
    const value25 = 20 + Math.random() * 50;
    const value26 = Math.random() * Math.PI;
    value18.beginPath();
    value18.moveTo(value23, value24);
    value18.lineTo(value23 + Math.cos(value26) * value25, value24 + Math.sin(value26) * value25);
    value18.stroke();
  }
  value18.fillStyle = "rgba(60, 45, 20, 0.3)";
  for (let value27 = 0; value27 < 30; value27++) {
    const value28 = Math.random() * value19;
    const value29 = Math.random() * value20;
    const value30 = 5 + Math.random() * 15;
    value18.beginPath();
    value18.arc(value28, value29, value30, 0, Math.PI * 2);
    value18.fill();
  }
}
function createBronze3DEffect(value31, value32, value33, value34, value35) {
  const value36 = value33 / 2;
  const value37 = value34 / 2;
  const value38 = 8;
  for (let value39 = value38; value39 > 0; value39--) {
    const value40 = value39 * 1.5;
    const value41 = 0.08 + value39 / value38 * 0.25;
    const value42 = 30 - value39 * 3;
    value31.fillStyle = "rgba(" + value42 + ", " + (value42 - 10) + ", " + (value42 - 20) + ", " + value41 + ")";
    value31.fillText(value32.toUpperCase(), value36 + value40, value37 + value40);
  }
  value31.fillStyle = value35;
  value31.fillText(value32.toUpperCase(), value36, value37);
  value31.strokeStyle = "rgba(139, 69, 19, 0.4)";
  value31.lineWidth = 1.5;
  value31.strokeText(value32.toUpperCase(), value36, value37);
}
function addBronzePatina(value43, value44, value45, value46) {
  const value47 = value45 / 2;
  const value48 = value46 / 2;
  value43.save();
  const value49 = value43.createLinearGradient(value47 - 200, value48 + 30, value47 + 200, value48 - 20);
  value49.addColorStop(0, "rgba(83, 130, 85, 0.3)");
  value49.addColorStop(0.3, "rgba(67, 111, 77, 0.4)");
  value49.addColorStop(0.6, "rgba(53, 94, 59, 0.3)");
  value49.addColorStop(1, "transparent");
  value43.globalCompositeOperation = "overlay";
  value43.fillStyle = value49;
  value43.font = "bold 84px \"Arial\"";
  value43.textAlign = "center";
  value43.textBaseline = "middle";
  value43.fillText(value44.toUpperCase(), value47, value48);
  value43.globalCompositeOperation = "source-over";
  const value50 = value43.measureText(value44.toUpperCase()).width;
  const value51 = [{
    x: -0.35,
    y: 0.2,
    size: 8,
    alpha: 0.4
  }, {
    x: -0.15,
    y: -0.1,
    size: 6,
    alpha: 0.3
  }, {
    x: 0.1,
    y: 0.3,
    size: 10,
    alpha: 0.5
  }, {
    x: 0.3,
    y: -0.2,
    size: 7,
    alpha: 0.4
  }, {
    x: 0.4,
    y: 0.1,
    size: 5,
    alpha: 0.3
  }];
  value51.forEach(value52 => {
    const value53 = value47 + value52.x * value50 / 2;
    const value54 = value48 + value52.y * 40;
    value43.fillStyle = "rgba(64, 130, 109, " + value52.alpha + ")";
    value43.beginPath();
    value43.arc(value53, value54, value52.size, 0, Math.PI * 2);
    value43.fill();
    value43.fillStyle = "rgba(83, 150, 120, " + value52.alpha * 0.7 + ")";
    value43.beginPath();
    value43.arc(value53 - value52.size * 0.3, value54 - value52.size * 0.3, value52.size * 0.5, 0, Math.PI * 2);
    value43.fill();
  });
  value43.restore();
}
function addBronzeHighlights(value55, value56, value57, value58) {
  const value59 = value57 / 2;
  const value60 = value58 / 2;
  value55.save();
  const value61 = value55.createLinearGradient(value59 - 250, value60 - 50, value59 + 250, value60 - 10);
  value61.addColorStop(0, "rgba(255, 215, 0, 0.4)");
  value61.addColorStop(0.3, "rgba(255, 200, 100, 0.3)");
  value61.addColorStop(0.6, "rgba(205, 170, 80, 0.2)");
  value61.addColorStop(1, "transparent");
  value55.globalCompositeOperation = "screen";
  value55.fillStyle = value61;
  value55.font = "bold 84px \"Arial\"";
  value55.textAlign = "center";
  value55.textBaseline = "middle";
  value55.fillText(value56.toUpperCase(), value59, value60 - 2);
  value55.globalCompositeOperation = "source-over";
  const value62 = value55.measureText(value56.toUpperCase()).width;
  const value63 = [{
    x: -0.3,
    y: -0.35,
    size: 4,
    alpha: 0.6
  }, {
    x: -0.1,
    y: -0.4,
    size: 5,
    alpha: 0.7
  }, {
    x: 0.15,
    y: -0.35,
    size: 3,
    alpha: 0.5
  }, {
    x: 0.35,
    y: -0.3,
    size: 4,
    alpha: 0.6
  }];
  value63.forEach(value64 => {
    const value65 = value59 + value64.x * value62 / 2;
    const value66 = value60 + value64.y * 45;
    value55.fillStyle = "rgba(255, 230, 150, " + value64.alpha + ")";
    value55.beginPath();
    value55.arc(value65, value66, value64.size, 0, Math.PI * 2);
    value55.fill();
  });
  value55.restore();
}
function drawAgedBorder(value67, value68, value69) {
  const value70 = value67.createLinearGradient(0, 0, value68, value69);
  value70.addColorStop(0, "#CD7F32");
  value70.addColorStop(0.3, "#B87333");
  value70.addColorStop(0.5, "#8B4513");
  value70.addColorStop(0.7, "#B87333");
  value70.addColorStop(1, "#CD7F32");
  value67.strokeStyle = value70;
  value67.lineWidth = 8;
  value67.shadowColor = "rgba(139, 69, 19, 0.5)";
  value67.shadowBlur = 15;
  value67.strokeRect(18, 18, value68 - 36, value69 - 36);
  value67.strokeStyle = "rgba(139, 69, 19, 0.4)";
  value67.lineWidth = 2;
  value67.shadowBlur = 0;
  value67.strokeRect(30, 30, value68 - 60, value69 - 60);
  drawBronzeRivets(value67, value68, value69);
}
function drawBronzeRivets(value71, value72, value73) {
  value71.fillStyle = "#B87333";
  const value74 = [{
    x: 30,
    y: 30
  }, {
    x: value72 - 30,
    y: 30
  }, {
    x: 30,
    y: value73 - 30
  }, {
    x: value72 - 30,
    y: value73 - 30
  }];
  value74.forEach(value75 => {
    value71.beginPath();
    value71.arc(value75.x, value75.y, 6, 0, Math.PI * 2);
    value71.fill();
    value71.fillStyle = "rgba(255, 215, 0, 0.6)";
    value71.beginPath();
    value71.arc(value75.x - 2, value75.y - 2, 2, 0, Math.PI * 2);
    value71.fill();
    value71.fillStyle = "#B87333";
  });
}
function addBronzeTexture(value76, value77, value78) {
  value76.save();
  value76.globalAlpha = 0.3;
  for (let value79 = 0; value79 < 100; value79++) {
    const value80 = Math.random() * value77;
    const value81 = Math.random() * value78;
    const value82 = 0.5 + Math.random() * 2;
    value76.fillStyle = "rgba(" + (180 + Math.random() * 40) + ", " + (120 + Math.random() * 30) + ", " + (50 + Math.random() * 20) + ", 0.8)";
    value76.beginPath();
    value76.arc(value80, value81, value82, 0, Math.PI * 2);
    value76.fill();
  }
  value76.strokeStyle = "rgba(139, 69, 19, 0.4)";
  value76.lineWidth = 1;
  for (let value83 = 0; value83 < 30; value83++) {
    const value84 = Math.random() * value77;
    const value85 = Math.random() * value78;
    const value86 = 10 + Math.random() * 40;
    const value87 = Math.random() * Math.PI;
    value76.beginPath();
    value76.moveTo(value84, value85);
    value76.lineTo(value84 + Math.cos(value87) * value86, value85 + Math.sin(value87) * value86);
    value76.stroke();
  }
  value76.restore();
}
async function generateSimpleBronzeLogo(value88) {
  const value89 = 600;
  const value90 = 300;
  const value91 = createCanvas(value89, value90);
  const value92 = value91.getContext("2d");
  value92.fillStyle = "#2a1e0f";
  value92.fillRect(0, 0, value89, value90);
  const value93 = value92.createLinearGradient(0, 50, 0, 250);
  value93.addColorStop(0, "#CD7F32");
  value93.addColorStop(0.4, "#B87333");
  value93.addColorStop(0.7, "#8B4513");
  value93.addColorStop(1, "#654321");
  value92.font = "bold 70px Arial";
  value92.fillStyle = value93;
  value92.textAlign = "center";
  value92.textBaseline = "middle";
  value92.shadowColor = "rgba(139, 69, 19, 0.5)";
  value92.shadowBlur = 15;
  value92.shadowOffsetX = 4;
  value92.shadowOffsetY = 4;
  value92.fillText(value88.toUpperCase(), value89 / 2, value90 / 2);
  value92.strokeStyle = "#B87333";
  value92.lineWidth = 5;
  value92.strokeRect(15, 15, value89 - 30, value90 - 30);
  return value91.toBuffer("image/png");
}
