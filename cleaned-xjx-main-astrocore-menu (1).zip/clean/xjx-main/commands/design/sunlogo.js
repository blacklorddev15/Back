const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "sunlogo",
  description: "Create radiant sun text logos with brilliant light and solar flare effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "☀️ *SUN LOGO*\n\n*sunlogo*\nsunlogo <text>\n\n*Example:*\nsunlogo SUN\nsunlogo LIGHT\nsunlogo SOLAR\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateSunLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "☀️ *Sun Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [SUNLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateSunLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createSkyBackground(value16, value13, value14);
  const value17 = value13 * 0.75;
  const value18 = value14 * 0.35;
  const value19 = 80;
  drawRealisticSun(value16, value17, value18, value19);
  addSolarFlares(value16, value17, value18, value19);
  addSunProminences(value16, value17, value18, value19);
  addSunRays(value16, value17, value18, value19);
  addLightBeams(value16, value13, value14);
  drawRadiantText(value16, value12, value13, value14);
  addLensFlare(value16, value17, value18, value19);
  addHeatHaze(value16, value13, value14);
  addSolarParticles(value16, value13, value14);
  addSunSparkles(value16, value13, value14);
  drawSolarBorder(value16, value13, value14);
  addSunSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createSkyBackground(value20, value21, value22) {
  const value23 = value20.createLinearGradient(0, 0, 0, value22);
  value23.addColorStop(0, "#87CEEB");
  value23.addColorStop(0.3, "#4682B4");
  value23.addColorStop(0.7, "#FF8C00");
  value23.addColorStop(1, "#FF4500");
  value20.fillStyle = value23;
  value20.fillRect(0, 0, value21, value22);
  addSkyClouds(value20, value21, value22);
}
function addSkyClouds(value24, value25, value26) {
  value24.save();
  value24.globalAlpha = 0.3;
  const value27 = [{
    x: value25 * 0.2,
    y: value26 * 0.2,
    size: 60
  }, {
    x: value25 * 0.6,
    y: value26 * 0.15,
    size: 80
  }, {
    x: value25 * 0.4,
    y: value26 * 0.25,
    size: 50
  }, {
    x: value25 * 0.8,
    y: value26 * 0.3,
    size: 70
  }];
  value27.forEach(value28 => {
    const value29 = value24.createRadialGradient(value28.x, value28.y, 0, value28.x, value28.y, value28.size);
    value29.addColorStop(0, "rgba(255, 255, 255, 0.8)");
    value29.addColorStop(1, "rgba(255, 255, 255, 0.2)");
    value24.fillStyle = value29;
    value24.beginPath();
    value24.arc(value28.x, value28.y, value28.size, 0, Math.PI * 2);
    value24.fill();
  });
  value24.restore();
}
function drawRealisticSun(value30, value31, value32, value33) {
  value30.save();
  const value34 = value30.createRadialGradient(value31, value32, 0, value31, value32, value33 * 3);
  value34.addColorStop(0, "rgba(255, 255, 200, 0.8)");
  value34.addColorStop(0.3, "rgba(255, 200, 100, 0.6)");
  value34.addColorStop(0.7, "rgba(255, 150, 50, 0.3)");
  value34.addColorStop(1, "transparent");
  value30.fillStyle = value34;
  value30.beginPath();
  value30.arc(value31, value32, value33 * 3, 0, Math.PI * 2);
  value30.fill();
  const value35 = value30.createRadialGradient(value31, value32, 0, value31, value32, value33 * 2);
  value35.addColorStop(0, "rgba(255, 255, 150, 0.9)");
  value35.addColorStop(0.5, "rgba(255, 200, 100, 0.7)");
  value35.addColorStop(1, "rgba(255, 150, 50, 0.4)");
  value30.fillStyle = value35;
  value30.beginPath();
  value30.arc(value31, value32, value33 * 2, 0, Math.PI * 2);
  value30.fill();
  const value36 = value30.createRadialGradient(value31 - value33 * 0.2, value32 - value33 * 0.2, 0, value31, value32, value33);
  value36.addColorStop(0, "#FFFF00");
  value36.addColorStop(0.3, "#FFD700");
  value36.addColorStop(0.7, "#FF8C00");
  value36.addColorStop(1, "#FF4500");
  value30.fillStyle = value36;
  value30.beginPath();
  value30.arc(value31, value32, value33, 0, Math.PI * 2);
  value30.fill();
  addSunSurfaceDetails(value30, value31, value32, value33);
  value30.fillStyle = "rgba(255, 255, 200, 0.6)";
  value30.beginPath();
  value30.arc(value31, value32, value33 * 0.7, 0, Math.PI * 2);
  value30.fill();
  value30.fillStyle = "rgba(255, 255, 255, 0.8)";
  value30.beginPath();
  value30.arc(value31, value32, value33 * 0.3, 0, Math.PI * 2);
  value30.fill();
  value30.restore();
}
function addSunSurfaceDetails(value37, value38, value39, value40) {
  value37.save();
  value37.globalAlpha = 0.4;
  const value41 = [{
    x: -0.3,
    y: -0.2,
    size: 0.1
  }, {
    x: 0.4,
    y: 0.1,
    size: 0.08
  }, {
    x: -0.2,
    y: 0.4,
    size: 0.12
  }, {
    x: 0.3,
    y: -0.3,
    size: 0.09
  }];
  value41.forEach(value42 => {
    const value43 = value38 + value42.x * value40;
    const value44 = value39 + value42.y * value40;
    const value45 = value42.size * value40;
    value37.fillStyle = "rgba(200, 100, 50, 0.6)";
    value37.beginPath();
    value37.arc(value43, value44, value45, 0, Math.PI * 2);
    value37.fill();
    value37.fillStyle = "rgba(150, 70, 30, 0.8)";
    value37.beginPath();
    value37.arc(value43, value44, value45 * 0.5, 0, Math.PI * 2);
    value37.fill();
  });
  for (let value46 = 0; value46 < 30; value46++) {
    const value47 = Math.random() * Math.PI * 2;
    const value48 = Math.random() * value40 * 0.8;
    const value49 = value38 + Math.cos(value47) * value48;
    const value50 = value39 + Math.sin(value47) * value48;
    const value51 = 2 + Math.random() * 5;
    value37.fillStyle = "rgba(255, 255, 200, 0.7)";
    value37.beginPath();
    value37.arc(value49, value50, value51, 0, Math.PI * 2);
    value37.fill();
  }
  value37.restore();
}
function addSolarFlares(value52, value53, value54, value55) {
  value52.save();
  value52.globalCompositeOperation = "screen";
  value52.globalAlpha = 0.6;
  const value56 = [{
    angle: 0.8,
    length: value55 * 4,
    intensity: 0.8
  }, {
    angle: 2.2,
    length: value55 * 3,
    intensity: 0.7
  }, {
    angle: 3.8,
    length: value55 * 5,
    intensity: 0.9
  }, {
    angle: 5.1,
    length: value55 * 3.5,
    intensity: 0.6
  }];
  value56.forEach(value57 => {
    const value58 = value52.createLinearGradient(value53, value54, value53 + Math.cos(value57.angle) * value57.length, value54 + Math.sin(value57.angle) * value57.length);
    value58.addColorStop(0, "rgba(255, 255, 200, " + value57.intensity + ")");
    value58.addColorStop(0.5, "rgba(255, 200, 100, " + value57.intensity * 0.7 + ")");
    value58.addColorStop(1, "rgba(255, 150, 50, " + value57.intensity * 0.3 + ")");
    value52.strokeStyle = value58;
    value52.lineWidth = 15;
    value52.lineCap = "round";
    value52.beginPath();
    value52.moveTo(value53, value54);
    value52.lineTo(value53 + Math.cos(value57.angle) * value57.length, value54 + Math.sin(value57.angle) * value57.length);
    value52.stroke();
    value52.strokeStyle = "rgba(255, 200, 100, " + value57.intensity * 0.4 + ")";
    value52.lineWidth = 30;
    value52.beginPath();
    value52.moveTo(value53, value54);
    value52.lineTo(value53 + Math.cos(value57.angle) * value57.length, value54 + Math.sin(value57.angle) * value57.length);
    value52.stroke();
  });
  value52.restore();
}
function addSunProminences(value59, value60, value61, value62) {
  value59.save();
  value59.globalCompositeOperation = "screen";
  value59.globalAlpha = 0.5;
  for (let value63 = 0; value63 < 6; value63++) {
    const value64 = value63 / 6 * Math.PI * 2;
    const value65 = value64 + Math.PI * 0.3;
    const value66 = value64 + Math.PI * 0.6;
    const value67 = value60 + Math.cos(value64) * value62;
    const value68 = value61 + Math.sin(value64) * value62;
    const value69 = value60 + Math.cos(value65) * value62 * 2;
    const value70 = value61 + Math.sin(value65) * value62 * 2;
    const value71 = value60 + Math.cos(value66) * value62 * 1.5;
    const value72 = value61 + Math.sin(value66) * value62 * 1.5;
    const value73 = value59.createLinearGradient(value67, value68, value71, value72);
    value73.addColorStop(0, "rgba(255, 100, 50, 0.8)");
    value73.addColorStop(1, "rgba(255, 200, 100, 0.4)");
    value59.strokeStyle = value73;
    value59.lineWidth = 8;
    value59.lineCap = "round";
    value59.beginPath();
    value59.moveTo(value67, value68);
    value59.quadraticCurveTo(value69, value70, value71, value72);
    value59.stroke();
    value59.strokeStyle = "rgba(255, 150, 50, 0.3)";
    value59.lineWidth = 20;
    value59.beginPath();
    value59.moveTo(value67, value68);
    value59.quadraticCurveTo(value69, value70, value71, value72);
    value59.stroke();
  }
  value59.restore();
}
function addSunRays(value74, value75, value76, value77) {
  value74.save();
  value74.globalCompositeOperation = "screen";
  value74.globalAlpha = 0.4;
  for (let value78 = 0; value78 < 3; value78++) {
    const value79 = 24 + value78 * 8;
    const value80 = value77 * (3 + value78);
    const value81 = 4 - value78;
    for (let value82 = 0; value82 < value79; value82++) {
      const value83 = value82 / value79 * Math.PI * 2;
      const value84 = Math.sin(value83 * 5 + value78) * 0.2;
      const value85 = value83 + value84;
      const value86 = value74.createLinearGradient(value75, value76, value75 + Math.cos(value85) * value80, value76 + Math.sin(value85) * value80);
      value86.addColorStop(0, "rgba(255, 255, 200, " + (0.8 - value78 * 0.2) + ")");
      value86.addColorStop(0.7, "rgba(255, 200, 100, " + (0.5 - value78 * 0.15) + ")");
      value86.addColorStop(1, "transparent");
      value74.strokeStyle = value86;
      value74.lineWidth = value81;
      value74.lineCap = "round";
      value74.beginPath();
      value74.moveTo(value75, value76);
      value74.lineTo(value75 + Math.cos(value85) * value80, value76 + Math.sin(value85) * value80);
      value74.stroke();
    }
  }
  value74.restore();
}
function addLightBeams(value87, value88, value89) {
  value87.save();
  value87.globalCompositeOperation = "screen";
  value87.globalAlpha = 0.2;
  for (let value90 = 0; value90 < 5; value90++) {
    const value91 = value88 * 0.75 + (Math.random() - 0.5) * 100;
    const value92 = 30 + Math.random() * 50;
    const value93 = value87.createLinearGradient(value91, 0, value91, value89);
    value93.addColorStop(0, "rgba(255, 255, 200, 0.6)");
    value93.addColorStop(0.5, "rgba(255, 200, 100, 0.3)");
    value93.addColorStop(1, "transparent");
    value87.fillStyle = value93;
    value87.fillRect(value91 - value92 / 2, 0, value92, value89);
  }
  value87.restore();
}
function drawRadiantText(value94, value95, value96, value97) {
  const value98 = value96 * 0.35;
  const value99 = value97 * 0.6;
  value94.save();
  value94.shadowColor = "rgba(255, 200, 50, 0.8)";
  value94.shadowBlur = 40;
  const value100 = value94.createLinearGradient(value98 - 100, value99 - 50, value98 + 100, value99 + 50);
  value100.addColorStop(0, "#FFFF00");
  value100.addColorStop(0.3, "#FFD700");
  value100.addColorStop(0.7, "#FF8C00");
  value100.addColorStop(1, "#FF4500");
  value94.font = "bold 70px \"Arial\"";
  value94.textAlign = "center";
  value94.textBaseline = "middle";
  value94.fillStyle = value100;
  value94.fillText(value95.toUpperCase(), value98, value99);
  value94.shadowColor = "transparent";
  value94.fillStyle = "rgba(255, 255, 200, 0.8)";
  value94.fillText(value95.toUpperCase(), value98, value99);
  value94.strokeStyle = "rgba(255, 255, 255, 0.9)";
  value94.lineWidth = 2;
  value94.strokeText(value95.toUpperCase(), value98, value99);
  addTextSolarEnergy(value94, value95, value98, value99);
  value94.restore();
}
function addTextSolarEnergy(value101, value102, value103, value104) {
  value101.save();
  value101.globalCompositeOperation = "screen";
  const value105 = value101.measureText(value102.toUpperCase());
  const value106 = value105.width;
  const value107 = 70;
  for (let value108 = 0; value108 < 25; value108++) {
    const value109 = value103 - value106 / 2 + Math.random() * value106;
    const value110 = value104 - value107 / 2 + Math.random() * value107;
    const value111 = 1 + Math.random() * 4;
    const value112 = Math.random() * Math.PI * 2;
    const value113 = 5 + Math.random() * 15;
    value101.strokeStyle = "rgba(255, 255, 200, " + (0.5 + Math.random() * 0.4) + ")";
    value101.lineWidth = value111;
    value101.lineCap = "round";
    value101.beginPath();
    value101.moveTo(value109, value110);
    value101.lineTo(value109 + Math.cos(value112) * value113, value110 + Math.sin(value112) * value113);
    value101.stroke();
  }
  value101.restore();
}
function addLensFlare(value114, value115, value116, value117) {
  value114.save();
  value114.globalCompositeOperation = "screen";
  value114.globalAlpha = 0.3;
  const value118 = value114.createRadialGradient(value115 - value117 * 0.5, value116 - value117 * 0.5, 0, value115, value116, value117 * 4);
  value118.addColorStop(0, "rgba(255, 255, 200, 0.8)");
  value118.addColorStop(0.3, "rgba(255, 200, 100, 0.5)");
  value118.addColorStop(1, "transparent");
  value114.fillStyle = value118;
  value114.beginPath();
  value114.arc(value115, value116, value117 * 4, 0, Math.PI * 2);
  value114.fill();
  for (let value119 = 0; value119 < 3; value119++) {
    const value120 = value119 / 3 * Math.PI * 2;
    const value121 = value117 * 2;
    const value122 = value115 + Math.cos(value120) * value121;
    const value123 = value116 + Math.sin(value120) * value121;
    const value124 = value117 * (0.5 + Math.random() * 0.5);
    const value125 = value114.createRadialGradient(value122, value123, 0, value122, value123, value124);
    value125.addColorStop(0, "rgba(255, 255, 200, 0.6)");
    value125.addColorStop(1, "transparent");
    value114.fillStyle = value125;
    value114.beginPath();
    value114.arc(value122, value123, value124, 0, Math.PI * 2);
    value114.fill();
  }
  value114.restore();
}
function addHeatHaze(value126, value127, value128) {
  value126.save();
  value126.globalAlpha = 0.1;
  for (let value129 = value128 * 0.3; value129 < value128 * 0.8; value129 += 10) {
    value126.strokeStyle = "rgba(255, 200, 100, " + (0.2 + Math.random() * 0.3) + ")";
    value126.lineWidth = 1;
    value126.beginPath();
    for (let value130 = 0; value130 <= value127; value130 += 5) {
      const value131 = value129 + Math.sin(value130 * 0.02 + value129 * 0.01) * 3;
      if (value130 === 0) {
        value126.moveTo(value130, value131);
      } else {
        value126.lineTo(value130, value131);
      }
    }
    value126.stroke();
  }
  value126.restore();
}
function addSolarParticles(value132, value133, value134) {
  value132.save();
  value132.globalCompositeOperation = "screen";
  for (let value135 = 0; value135 < 60; value135++) {
    const value136 = Math.random() * value133;
    const value137 = Math.random() * value134;
    const value138 = 1 + Math.random() * 5;
    const value139 = 0.6 + Math.random() * 0.4;
    value132.fillStyle = "rgba(255, 255, 200, " + value139 + ")";
    value132.beginPath();
    value132.arc(value136, value137, value138, 0, Math.PI * 2);
    value132.fill();
    value132.fillStyle = "rgba(255, 200, 100, " + value139 * 0.3 + ")";
    value132.beginPath();
    value132.arc(value136, value137, value138 * 2, 0, Math.PI * 2);
    value132.fill();
  }
  value132.restore();
}
function addSunSparkles(value140, value141, value142) {
  value140.save();
  value140.globalCompositeOperation = "screen";
  for (let value143 = 0; value143 < 30; value143++) {
    const value144 = Math.random() * value141;
    const value145 = Math.random() * value142;
    const value146 = 1 + Math.random() * 3;
    value140.fillStyle = "rgba(255, 255, 255, 0.9)";
    value140.beginPath();
    value140.arc(value144, value145, value146, 0, Math.PI * 2);
    value140.fill();
    for (let value147 = 0; value147 < 4; value147++) {
      const value148 = value147 / 4 * Math.PI * 2;
      const value149 = value146 * 4;
      value140.strokeStyle = "rgba(255, 255, 200, 0.7)";
      value140.lineWidth = 1;
      value140.lineCap = "round";
      value140.beginPath();
      value140.moveTo(value144, value145);
      value140.lineTo(value144 + Math.cos(value148) * value149, value145 + Math.sin(value148) * value149);
      value140.stroke();
    }
  }
  value140.restore();
}
function drawSolarBorder(value150, value151, value152) {
  value150.save();
  const value153 = value150.createLinearGradient(0, 0, value151, 0);
  value153.addColorStop(0, "#FFFF00");
  value153.addColorStop(0.3, "#FFD700");
  value153.addColorStop(0.7, "#FF8C00");
  value153.addColorStop(1, "#FF4500");
  value150.strokeStyle = value153;
  value150.lineWidth = 8;
  value150.shadowColor = "rgba(255, 200, 50, 0.8)";
  value150.shadowBlur = 25;
  value150.strokeRect(10, 10, value151 - 20, value152 - 20);
  value150.strokeStyle = "rgba(255, 255, 200, 0.6)";
  value150.lineWidth = 3;
  value150.shadowBlur = 15;
  value150.strokeRect(20, 20, value151 - 40, value152 - 40);
  addCornerSunSymbols(value150, value151, value152);
  value150.restore();
}
function addCornerSunSymbols(value154, value155, value156) {
  value154.save();
  value154.globalAlpha = 0.7;
  const value157 = [{
    x: 30,
    y: 30
  }, {
    x: value155 - 30,
    y: 30
  }, {
    x: 30,
    y: value156 - 30
  }, {
    x: value155 - 30,
    y: value156 - 30
  }];
  value157.forEach(value158 => {
    value154.fillStyle = "#FFD700";
    value154.beginPath();
    value154.arc(value158.x, value158.y, 8, 0, Math.PI * 2);
    value154.fill();
    for (let value159 = 0; value159 < 8; value159++) {
      const value160 = value159 / 8 * Math.PI * 2;
      const value161 = 12;
      value154.strokeStyle = "#FFD700";
      value154.lineWidth = 2;
      value154.lineCap = "round";
      value154.beginPath();
      value154.moveTo(value158.x, value158.y);
      value154.lineTo(value158.x + Math.cos(value160) * value161, value158.y + Math.sin(value160) * value161);
      value154.stroke();
    }
  });
  value154.restore();
}
function addSunSignature(value162, value163, value164) {
  value162.save();
  const value165 = value163 - 110;
  const value166 = value164 - 25;
  value162.font = "italic 14px \"Arial\"";
  value162.fillStyle = "rgba(255, 255, 200, 0.9)";
  value162.textAlign = "right";
  value162.textBaseline = "bottom";
  value162.shadowColor = "rgba(255, 200, 50, 0.6)";
  value162.shadowBlur = 15;
  value162.fillText("by " + getBotName(), value165, value166);
  value162.fillStyle = "#FFD700";
  value162.beginPath();
  value162.arc(value165 + 5, value166 - 8, 4, 0, Math.PI * 2);
  value162.fill();
  for (let value167 = 0; value167 < 4; value167++) {
    const value168 = value167 / 4 * Math.PI * 2;
    const value169 = 6;
    value162.strokeStyle = "#FFD700";
    value162.lineWidth = 1;
    value162.lineCap = "round";
    value162.beginPath();
    value162.moveTo(value165 + 5, value166 - 8);
    value162.lineTo(value165 + 5 + Math.cos(value168) * value169, value166 - 8 + Math.sin(value168) * value169);
    value162.stroke();
  }
  value162.restore();
}
