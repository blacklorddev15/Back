const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "smokelogo",
  description: "Create ethereal smoke text logos with vapor and mist effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "💨 *SMOKE LOGO*\n\n*smokelogo*\nsmokelogo <text>\n\n*Example:*\nsmokelogo SMOKE\nsmokelogo VAPOR\nsmokelogo MIST\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateSmokeLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "💨 *Smoke Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [SMOKELOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateSmokeLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createSmokyBackground(value16, value13, value14);
  const value17 = value13 * 0.75;
  const value18 = value14 * 0.7;
  drawSmokePlume(value16, value17, value18);
  addSmokeWisps(value16, value13, value14);
  addVaporTrails(value16, value13, value14);
  drawSmokyText(value16, value12, value13, value14);
  addMistLayers(value16, value13, value14);
  addSmokeParticles(value16, value13, value14);
  addFloatingEmbers(value16, value13, value14);
  addAshParticles(value16, value13, value14);
  drawSmokeBorder(value16, value13, value14);
  addSmokeSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createSmokyBackground(value19, value20, value21) {
  const value22 = value19.createLinearGradient(0, 0, 0, value21);
  value22.addColorStop(0, "#1a1a2a");
  value22.addColorStop(0.3, "#2d2d4a");
  value22.addColorStop(0.6, "#4a4a6a");
  value22.addColorStop(1, "#1a1a2a");
  value19.fillStyle = value22;
  value19.fillRect(0, 0, value20, value21);
  addBackgroundSmoke(value19, value20, value21);
}
function addBackgroundSmoke(value23, value24, value25) {
  value23.save();
  value23.globalAlpha = 0.1;
  for (let value26 = 0; value26 < 8; value26++) {
    const value27 = Math.random() * value24;
    const value28 = Math.random() * value25;
    const value29 = 80 + Math.random() * 120;
    const value30 = value23.createRadialGradient(value27, value28, 0, value27, value28, value29);
    value30.addColorStop(0, "rgba(150, 150, 180, 0.4)");
    value30.addColorStop(1, "transparent");
    value23.fillStyle = value30;
    value23.beginPath();
    value23.arc(value27, value28, value29, 0, Math.PI * 2);
    value23.fill();
  }
  value23.restore();
}
function drawSmokePlume(value31, value32, value33) {
  value31.save();
  const value34 = [{
    size: 120,
    alpha: 0.3,
    yOffset: -80
  }, {
    size: 100,
    alpha: 0.4,
    yOffset: -120
  }, {
    size: 80,
    alpha: 0.5,
    yOffset: -160
  }, {
    size: 60,
    alpha: 0.6,
    yOffset: -200
  }, {
    size: 40,
    alpha: 0.7,
    yOffset: -240
  }];
  value34.forEach((value35, value36) => {
    drawSmokeLayer(value31, value32, value33 + value35.yOffset, value35.size, value35.alpha, value36);
  });
  drawSmokeSource(value31, value32, value33);
  value31.restore();
}
function drawSmokeLayer(value37, value38, value39, value40, value41, value42) {
  const value43 = value37.createRadialGradient(value38, value39, 0, value38, value39, value40);
  value43.addColorStop(0, "rgba(220, 220, 240, " + value41 + ")");
  value43.addColorStop(0.5, "rgba(180, 180, 200, " + value41 * 0.7 + ")");
  value43.addColorStop(1, "rgba(120, 120, 150, " + value41 * 0.3 + ")");
  value37.fillStyle = value43;
  value37.beginPath();
  const value44 = value40 * 0.3;
  value37.moveTo(value38 - value40 * 0.3, value39);
  value37.bezierCurveTo(value38 - value40 * 0.6, value39 - value40 * 0.2 + Math.sin(value42) * value44, value38 - value40 * 0.4, value39 - value40 * 0.6 + Math.cos(value42 * 0.7) * value44, value38, value39 - value40);
  value37.bezierCurveTo(value38 + value40 * 0.4, value39 - value40 * 0.6 + Math.sin(value42 * 0.5) * value44, value38 + value40 * 0.6, value39 - value40 * 0.2 + Math.cos(value42 * 0.3) * value44, value38 + value40 * 0.3, value39);
  value37.bezierCurveTo(value38 + value40 * 0.2, value39 + value40 * 0.1, value38 - value40 * 0.2, value39 + value40 * 0.1, value38 - value40 * 0.3, value39);
  value37.closePath();
  value37.fill();
  addSmokeWispsToLayer(value37, value38, value39 - value40 * 0.5, value40 * 0.8, value41);
}
function addSmokeWispsToLayer(value45, value46, value47, value48, value49) {
  value45.save();
  value45.globalAlpha = value49 * 0.8;
  for (let value50 = 0; value50 < 5; value50++) {
    const value51 = value50 / 5 * Math.PI * 2;
    const value52 = value48 * 0.3;
    const value53 = value46 + Math.cos(value51) * value52;
    const value54 = value47 + Math.sin(value51) * value52;
    const value55 = value48 * 0.2;
    const value56 = value45.createRadialGradient(value53, value54, 0, value53, value54, value55);
    value56.addColorStop(0, "rgba(240, 240, 255, " + value49 + ")");
    value56.addColorStop(1, "transparent");
    value45.fillStyle = value56;
    value45.beginPath();
    value45.arc(value53, value54, value55, 0, Math.PI * 2);
    value45.fill();
  }
  value45.restore();
}
function drawSmokeSource(value57, value58, value59) {
  const value60 = value57.createRadialGradient(value58, value59, 0, value58, value59, 15);
  value60.addColorStop(0, "rgba(255, 100, 50, 0.9)");
  value60.addColorStop(0.5, "rgba(255, 50, 0, 0.6)");
  value60.addColorStop(1, "transparent");
  value57.fillStyle = value60;
  value57.beginPath();
  value57.arc(value58, value59, 15, 0, Math.PI * 2);
  value57.fill();
  value57.fillStyle = "rgba(255, 150, 100, 0.8)";
  value57.beginPath();
  value57.arc(value58, value59, 8, 0, Math.PI * 2);
  value57.fill();
  value57.fillStyle = "rgba(255, 255, 200, 0.9)";
  value57.beginPath();
  value57.arc(value58, value59, 4, 0, Math.PI * 2);
  value57.fill();
}
function addSmokeWisps(value61, value62, value63) {
  value61.save();
  value61.globalAlpha = 0.6;
  for (let value64 = 0; value64 < 12; value64++) {
    const value65 = Math.random() * value62;
    const value66 = Math.random() * value63;
    const value67 = 20 + Math.random() * 40;
    const value68 = 0.3 + Math.random() * 0.4;
    drawSmokeWisp(value61, value65, value66, value67, value68);
  }
  for (let value69 = 0; value69 < 20; value69++) {
    const value70 = Math.random() * value62;
    const value71 = Math.random() * value63;
    const value72 = 10 + Math.random() * 20;
    const value73 = 0.4 + Math.random() * 0.3;
    drawSmokeWisp(value61, value70, value71, value72, value73);
  }
  value61.restore();
}
function drawSmokeWisp(value74, value75, value76, value77, value78) {
  const value79 = value74.createRadialGradient(value75, value76, 0, value75, value76, value77);
  value79.addColorStop(0, "rgba(220, 220, 240, " + value78 + ")");
  value79.addColorStop(0.7, "rgba(180, 180, 200, " + value78 * 0.6 + ")");
  value79.addColorStop(1, "rgba(120, 120, 150, " + value78 * 0.2 + ")");
  value74.fillStyle = value79;
  value74.beginPath();
  const value80 = value77 * 0.4;
  value74.moveTo(value75 - value77 * 0.3, value76);
  value74.bezierCurveTo(value75 - value77 * 0.5, value76 - value77 * 0.2 + Math.random() * value80, value75 - value77 * 0.3, value76 - value77 * 0.5 + Math.random() * value80, value75, value76 - value77);
  value74.bezierCurveTo(value75 + value77 * 0.3, value76 - value77 * 0.5 + Math.random() * value80, value75 + value77 * 0.5, value76 - value77 * 0.2 + Math.random() * value80, value75 + value77 * 0.3, value76);
  value74.bezierCurveTo(value75 + value77 * 0.2, value76 + value77 * 0.1, value75 - value77 * 0.2, value76 + value77 * 0.1, value75 - value77 * 0.3, value76);
  value74.closePath();
  value74.fill();
}
function addVaporTrails(value81, value82, value83) {
  value81.save();
  value81.globalAlpha = 0.4;
  for (let value84 = 0; value84 < 8; value84++) {
    const value85 = Math.random() * value82;
    const value86 = value83 + 20;
    const value87 = value85 + (Math.random() - 0.5) * 60;
    const value88 = Math.random() * value83 * 0.5;
    const value89 = 5 + Math.random() * 10;
    const value90 = value81.createLinearGradient(value85, value86, value87, value88);
    value90.addColorStop(0, "rgba(200, 200, 220, 0.6)");
    value90.addColorStop(0.5, "rgba(160, 160, 180, 0.4)");
    value90.addColorStop(1, "transparent");
    value81.strokeStyle = value90;
    value81.lineWidth = value89;
    value81.lineCap = "round";
    value81.beginPath();
    value81.moveTo(value85, value86);
    value81.bezierCurveTo(value85 + (Math.random() - 0.5) * 40, value86 - 80, value87 + (Math.random() - 0.5) * 40, value88 + 40, value87, value88);
    value81.stroke();
  }
  value81.restore();
}
function drawSmokyText(value91, value92, value93, value94) {
  const value95 = value93 * 0.35;
  const value96 = value94 * 0.6;
  value91.save();
  value91.shadowColor = "rgba(150, 150, 180, 0.8)";
  value91.shadowBlur = 30;
  const value97 = value91.createLinearGradient(value95 - 100, value96 - 50, value95 + 100, value96 + 50);
  value97.addColorStop(0, "#E8E8F0");
  value97.addColorStop(0.3, "#C8C8D8");
  value97.addColorStop(0.7, "#A8A8C0");
  value97.addColorStop(1, "#E8E8F0");
  value91.font = "bold 70px \"Arial\"";
  value91.textAlign = "center";
  value91.textBaseline = "middle";
  value91.fillStyle = value97;
  value91.fillText(value92.toUpperCase(), value95, value96);
  value91.shadowColor = "transparent";
  value91.fillStyle = "rgba(240, 240, 255, 0.7)";
  value91.fillText(value92.toUpperCase(), value95, value96);
  value91.strokeStyle = "rgba(200, 200, 220, 0.8)";
  value91.lineWidth = 2;
  value91.strokeText(value92.toUpperCase(), value95, value96);
  addTextSmoke(value91, value92, value95, value96);
  value91.restore();
}
function addTextSmoke(value98, value99, value100, value101) {
  value98.save();
  value98.globalCompositeOperation = "overlay";
  value98.globalAlpha = 0.3;
  const value102 = value98.measureText(value99.toUpperCase());
  const value103 = value102.width;
  const value104 = 70;
  for (let value105 = 0; value105 < 15; value105++) {
    const value106 = value100 - value103 / 2 + Math.random() * value103;
    const value107 = value101 + value104 / 2;
    const value108 = 10 + Math.random() * 30;
    const value109 = 2 + Math.random() * 4;
    const value110 = value98.createLinearGradient(value106, value107, value106, value107 - value108);
    value110.addColorStop(0, "rgba(200, 200, 220, 0.6)");
    value110.addColorStop(1, "transparent");
    value98.strokeStyle = value110;
    value98.lineWidth = value109;
    value98.lineCap = "round";
    value98.beginPath();
    value98.moveTo(value106, value107);
    value98.lineTo(value106, value107 - value108);
    value98.stroke();
  }
  for (let value111 = 0; value111 < 8; value111++) {
    const value112 = value100 - value103 / 2 + Math.random() * value103;
    const value113 = value101 - value104 / 2 + Math.random() * value104;
    const value114 = 5 + Math.random() * 10;
    const value115 = value98.createRadialGradient(value112, value113, 0, value112, value113, value114);
    value115.addColorStop(0, "rgba(220, 220, 240, 0.5)");
    value115.addColorStop(1, "transparent");
    value98.fillStyle = value115;
    value98.beginPath();
    value98.arc(value112, value113, value114, 0, Math.PI * 2);
    value98.fill();
  }
  value98.restore();
}
function addMistLayers(value116, value117, value118) {
  value116.save();
  value116.globalAlpha = 0.2;
  const value119 = value116.createLinearGradient(0, value118 * 0.7, 0, value118);
  value119.addColorStop(0, "rgba(120, 120, 150, 0.4)");
  value119.addColorStop(1, "transparent");
  value116.fillStyle = value119;
  value116.fillRect(0, value118 * 0.7, value117, value118 * 0.3);
  for (let value120 = 0; value120 < 5; value120++) {
    const value121 = Math.random() * value117;
    const value122 = value118 * 0.3 + Math.random() * value118 * 0.4;
    const value123 = 60 + Math.random() * 80;
    const value124 = value116.createRadialGradient(value121, value122, 0, value121, value122, value123);
    value124.addColorStop(0, "rgba(150, 150, 180, 0.3)");
    value124.addColorStop(1, "transparent");
    value116.fillStyle = value124;
    value116.beginPath();
    value116.arc(value121, value122, value123, 0, Math.PI * 2);
    value116.fill();
  }
  value116.restore();
}
function addSmokeParticles(value125, value126, value127) {
  value125.save();
  value125.globalAlpha = 0.6;
  for (let value128 = 0; value128 < 50; value128++) {
    const value129 = Math.random() * value126;
    const value130 = Math.random() * value127;
    const value131 = 1 + Math.random() * 4;
    const value132 = 180 + Math.random() * 40;
    const value133 = 0.3 + Math.random() * 0.4;
    value125.fillStyle = "rgba(" + value132 + ", " + value132 + ", " + (value132 + 20) + ", " + value133 + ")";
    value125.beginPath();
    value125.arc(value129, value130, value131, 0, Math.PI * 2);
    value125.fill();
    const value134 = 3 + Math.random() * 8;
    const value135 = Math.random() * Math.PI * 2;
    value125.strokeStyle = "rgba(" + value132 + ", " + value132 + ", " + (value132 + 20) + ", " + value133 * 0.5 + ")";
    value125.lineWidth = value131 * 0.5;
    value125.lineCap = "round";
    value125.beginPath();
    value125.moveTo(value129, value130);
    value125.lineTo(value129 + Math.cos(value135) * value134, value130 + Math.sin(value135) * value134);
    value125.stroke();
  }
  value125.restore();
}
function addFloatingEmbers(value136, value137, value138) {
  value136.save();
  value136.globalCompositeOperation = "screen";
  for (let value139 = 0; value139 < 20; value139++) {
    const value140 = value137 * 0.7 + (Math.random() - 0.5) * 100;
    const value141 = value138 * 0.5 + Math.random() * value138 * 0.4;
    const value142 = 1 + Math.random() * 3;
    const value143 = 0.6 + Math.random() * 0.4;
    value136.fillStyle = "rgba(255, 200, 100, " + value143 + ")";
    value136.beginPath();
    value136.arc(value140, value141, value142, 0, Math.PI * 2);
    value136.fill();
    const value144 = 5 + Math.random() * 10;
    const value145 = -Math.PI * 0.5 + (Math.random() - 0.5) * 0.5;
    value136.strokeStyle = "rgba(255, 150, 50, " + value143 * 0.5 + ")";
    value136.lineWidth = value142 * 0.5;
    value136.lineCap = "round";
    value136.beginPath();
    value136.moveTo(value140, value141);
    value136.lineTo(value140 + Math.cos(value145) * value144, value141 + Math.sin(value145) * value144);
    value136.stroke();
  }
  value136.restore();
}
function addAshParticles(value146, value147, value148) {
  value146.save();
  value146.globalAlpha = 0.5;
  for (let value149 = 0; value149 < 30; value149++) {
    const value150 = Math.random() * value147;
    const value151 = Math.random() * value148;
    const value152 = 1 + Math.random() * 2;
    const value153 = 80 + Math.random() * 40;
    value146.fillStyle = "rgba(" + value153 + ", " + value153 + ", " + value153 + ", 0.7)";
    value146.beginPath();
    value146.arc(value150, value151, value152, 0, Math.PI * 2);
    value146.fill();
    const value154 = 3 + Math.random() * 6;
    value146.strokeStyle = "rgba(" + value153 + ", " + value153 + ", " + value153 + ", 0.4)";
    value146.lineWidth = value152 * 0.5;
    value146.lineCap = "round";
    value146.beginPath();
    value146.moveTo(value150, value151);
    value146.lineTo(value150, value151 + value154);
    value146.stroke();
  }
  value146.restore();
}
function drawSmokeBorder(value155, value156, value157) {
  value155.save();
  const value158 = value155.createLinearGradient(0, 0, value156, 0);
  value158.addColorStop(0, "#A8A8C0");
  value158.addColorStop(0.3, "#C8C8D8");
  value158.addColorStop(0.5, "#E8E8F0");
  value158.addColorStop(0.7, "#C8C8D8");
  value158.addColorStop(1, "#A8A8C0");
  value155.strokeStyle = value158;
  value155.lineWidth = 10;
  value155.shadowColor = "rgba(150, 150, 180, 0.6)";
  value155.shadowBlur = 20;
  value155.strokeRect(10, 10, value156 - 20, value157 - 20);
  value155.strokeStyle = "rgba(200, 200, 220, 0.6)";
  value155.lineWidth = 3;
  value155.shadowBlur = 15;
  value155.strokeRect(20, 20, value156 - 40, value157 - 40);
  addSmokeCorners(value155, value156, value157);
  value155.restore();
}
function addSmokeCorners(value159, value160, value161) {
  value159.save();
  value159.globalAlpha = 0.7;
  const value162 = [{
    x: 25,
    y: 25
  }, {
    x: value160 - 25,
    y: 25
  }, {
    x: 25,
    y: value161 - 25
  }, {
    x: value160 - 25,
    y: value161 - 25
  }];
  value162.forEach(value163 => {
    const value164 = value159.createRadialGradient(value163.x, value163.y, 0, value163.x, value163.y, 12);
    value164.addColorStop(0, "rgba(220, 220, 240, 0.8)");
    value164.addColorStop(1, "transparent");
    value159.fillStyle = value164;
    value159.beginPath();
    value159.arc(value163.x, value163.y, 12, 0, Math.PI * 2);
    value159.fill();
  });
  value159.restore();
}
function addSmokeSignature(value165, value166, value167) {
  value165.save();
  const value168 = value166 - 110;
  const value169 = value167 - 25;
  value165.font = "italic 14px \"Arial\"";
  value165.fillStyle = "rgba(200, 200, 220, 0.9)";
  value165.textAlign = "right";
  value165.textBaseline = "bottom";
  value165.shadowColor = "rgba(150, 150, 180, 0.6)";
  value165.shadowBlur = 10;
  value165.fillText("by " + getBotName(), value168, value169);
  const value170 = value165.createRadialGradient(value168 + 5, value169 - 8, 0, value168 + 5, value169 - 8, 6);
  value170.addColorStop(0, "rgba(220, 220, 240, 0.8)");
  value170.addColorStop(1, "transparent");
  value165.fillStyle = value170;
  value165.beginPath();
  value165.arc(value168 + 5, value169 - 8, 6, 0, Math.PI * 2);
  value165.fill();
  value165.restore();
}
