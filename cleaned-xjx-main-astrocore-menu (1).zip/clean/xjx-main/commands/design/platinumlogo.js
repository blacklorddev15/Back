const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "platinumlogo",
  description: "Create premium platinum metallic text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🔷 *PLATINUM LOGO*\n\n*platinumlogo*\nplatinumlogo <text>\n\n*Example:*\nplatinumlogo WOLF\nplatinumlogo PLATINUM\nplatinumlogo ELITE\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generatePlatinumLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🔷 *Platinum Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [PLATINUMLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generatePlatinumLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#0a0a14";
  value16.fillRect(0, 0, value13, value14);
  drawPlatinumBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 100, 0, 300);
  value17.addColorStop(0, "#F8F8FF");
  value17.addColorStop(0.15, "#E8E8F0");
  value17.addColorStop(0.3, "#D0D0E0");
  value17.addColorStop(0.45, "#B8B8D0");
  value17.addColorStop(0.6, "#A0A0C0");
  value17.addColorStop(0.75, "#8888B0");
  value17.addColorStop(0.9, "#7070A0");
  value17.addColorStop(1, "#585890");
  value16.font = "bold 86px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createPlatinum3DEffect(value16, value12, value13, value14, value17);
  addPlatinumHighlights(value16, value12, value13, value14);
  drawPlatinumBorder(value16, value13, value14);
  addDiamondReflections(value16, value13, value14);
  addPrestigeElements(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawPlatinumBackground(value18, value19, value20) {
  const value21 = value18.createRadialGradient(value19 / 2, value20 / 2, 0, value19 / 2, value20 / 2, Math.max(value19, value20) / 1.5);
  value21.addColorStop(0, "#1a1a2e");
  value21.addColorStop(0.4, "#0f0f23");
  value21.addColorStop(0.8, "#050514");
  value21.addColorStop(1, "#000005");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  value18.strokeStyle = "rgba(100, 100, 150, 0.1)";
  value18.lineWidth = 1;
  const value22 = 40;
  for (let value23 = 0; value23 < value19; value23 += value22) {
    for (let value24 = 0; value24 < value20; value24 += value22) {
      value18.beginPath();
      value18.moveTo(value23, value24);
      value18.lineTo(value23 + value22, value24);
      value18.lineTo(value23 + value22, value24 + value22);
      value18.lineTo(value23, value24 + value22);
      value18.closePath();
      value18.stroke();
    }
  }
  drawPrestigeCorners(value18, value19, value20);
}
function createPlatinum3DEffect(value25, value26, value27, value28, value29) {
  const value30 = value27 / 2;
  const value31 = value28 / 2;
  const value32 = 10;
  for (let value33 = value32; value33 > 0; value33--) {
    const value34 = value33 * 1.2;
    const value35 = 0.08 + value33 / value32 * 0.25;
    const value36 = 150 - value33 * 10;
    value25.fillStyle = "rgba(0, 0, " + value36 + ", " + value35 + ")";
    value25.fillText(value26.toUpperCase(), value30 + value34, value31 + value34);
  }
  value25.shadowColor = "rgba(100, 100, 255, 0.3)";
  value25.shadowBlur = 15;
  value25.fillStyle = value29;
  value25.fillText(value26.toUpperCase(), value30, value31);
  value25.shadowColor = "transparent";
  value25.shadowBlur = 0;
  value25.strokeStyle = "rgba(200, 200, 255, 0.4)";
  value25.lineWidth = 1.5;
  value25.strokeText(value26.toUpperCase(), value30, value31);
}
function addPlatinumHighlights(value37, value38, value39, value40) {
  const value41 = value39 / 2;
  const value42 = value40 / 2;
  value37.save();
  const value43 = value37.createLinearGradient(value41 - 250, value42 - 60, value41 + 250, value42 - 10);
  value43.addColorStop(0, "rgba(240, 240, 255, 0.9)");
  value43.addColorStop(0.3, "rgba(220, 220, 255, 0.6)");
  value43.addColorStop(0.6, "rgba(200, 200, 255, 0.3)");
  value43.addColorStop(1, "transparent");
  value37.globalCompositeOperation = "screen";
  value37.fillStyle = value43;
  value37.font = "bold 86px \"Arial\"";
  value37.textAlign = "center";
  value37.textBaseline = "middle";
  value37.fillText(value38.toUpperCase(), value41, value42 - 3);
  value37.globalCompositeOperation = "source-over";
  value37.fillStyle = "rgba(255, 255, 255, 0.8)";
  value37.globalAlpha = 0.4;
  const value44 = value37.measureText(value38.toUpperCase()).width;
  const value45 = [{
    x: -0.4,
    y: -0.3
  }, {
    x: -0.2,
    y: -0.4
  }, {
    x: 0,
    y: -0.35
  }, {
    x: 0.2,
    y: -0.4
  }, {
    x: 0.4,
    y: -0.3
  }];
  value45.forEach(value46 => {
    const value47 = value41 + value46.x * value44 / 2;
    const value48 = value42 + value46.y * 40;
    const value49 = 4 + Math.random() * 3;
    value37.shadowColor = "rgba(200, 200, 255, 0.6)";
    value37.shadowBlur = 8;
    value37.beginPath();
    value37.arc(value47, value48, value49, 0, Math.PI * 2);
    value37.fill();
  });
  value37.restore();
}
function drawPlatinumBorder(value50, value51, value52) {
  const value53 = value50.createLinearGradient(0, 0, value51, value52);
  value53.addColorStop(0, "#E8E8FF");
  value53.addColorStop(0.25, "#C0C0E0");
  value53.addColorStop(0.5, "#A0A0C0");
  value53.addColorStop(0.75, "#C0C0E0");
  value53.addColorStop(1, "#E8E8FF");
  value50.strokeStyle = value53;
  value50.lineWidth = 8;
  value50.shadowColor = "rgba(100, 100, 200, 0.5)";
  value50.shadowBlur = 20;
  value50.strokeRect(15, 15, value51 - 30, value52 - 30);
  value50.strokeStyle = "rgba(200, 200, 255, 0.6)";
  value50.lineWidth = 2;
  value50.shadowBlur = 0;
  value50.strokeRect(25, 25, value51 - 50, value52 - 50);
  value50.strokeStyle = "rgba(150, 150, 255, 0.3)";
  value50.lineWidth = 1;
  value50.strokeRect(35, 35, value51 - 70, value52 - 70);
}
function addDiamondReflections(value54, value55, value56) {
  value54.save();
  value54.globalAlpha = 0.7;
  const value57 = 12;
  for (let value58 = 0; value58 < value57; value58++) {
    const value59 = 50 + Math.random() * (value55 - 100);
    const value60 = 50 + Math.random() * (value56 - 100);
    const value61 = 2 + Math.random() * 4;
    value54.fillStyle = "rgba(255, 255, 255, 0.9)";
    value54.beginPath();
    value54.moveTo(value59, value60 - value61);
    value54.lineTo(value59 + value61, value60);
    value54.lineTo(value59, value60 + value61);
    value54.lineTo(value59 - value61, value60);
    value54.closePath();
    value54.fill();
    value54.shadowColor = "rgba(200, 200, 255, 0.8)";
    value54.shadowBlur = 5;
    value54.fill();
  }
  value54.restore();
}
function drawPrestigeCorners(value62, value63, value64) {
  value62.strokeStyle = "rgba(150, 150, 255, 0.4)";
  value62.lineWidth = 3;
  const value65 = 30;
  const value66 = 8;
  value62.beginPath();
  value62.moveTo(20, 20 + value65);
  value62.lineTo(20, 20 + value66);
  value62.moveTo(20, 20);
  value62.lineTo(20 + value66, 20);
  value62.moveTo(20 + value65 - value66, 20);
  value62.lineTo(20 + value65, 20);
  value62.moveTo(20 + value65, 20);
  value62.lineTo(20 + value65, 20 + value66);
  value62.stroke();
  value62.beginPath();
  value62.moveTo(value63 - 20, 20 + value65);
  value62.lineTo(value63 - 20, 20 + value66);
  value62.moveTo(value63 - 20, 20);
  value62.lineTo(value63 - 20 - value66, 20);
  value62.moveTo(value63 - 20 - value65 + value66, 20);
  value62.lineTo(value63 - 20 - value65, 20);
  value62.moveTo(value63 - 20 - value65, 20);
  value62.lineTo(value63 - 20 - value65, 20 + value66);
  value62.stroke();
  value62.beginPath();
  value62.moveTo(20, value64 - 20 - value65);
  value62.lineTo(20, value64 - 20 - value66);
  value62.moveTo(20, value64 - 20);
  value62.lineTo(20 + value66, value64 - 20);
  value62.moveTo(20 + value65 - value66, value64 - 20);
  value62.lineTo(20 + value65, value64 - 20);
  value62.moveTo(20 + value65, value64 - 20);
  value62.lineTo(20 + value65, value64 - 20 - value66);
  value62.stroke();
  value62.beginPath();
  value62.moveTo(value63 - 20, value64 - 20 - value65);
  value62.lineTo(value63 - 20, value64 - 20 - value66);
  value62.moveTo(value63 - 20, value64 - 20);
  value62.lineTo(value63 - 20 - value66, value64 - 20);
  value62.moveTo(value63 - 20 - value65 + value66, value64 - 20);
  value62.lineTo(value63 - 20 - value65, value64 - 20);
  value62.moveTo(value63 - 20 - value65, value64 - 20);
  value62.lineTo(value63 - 20 - value65, value64 - 20 - value66);
  value62.stroke();
}
function addPrestigeElements(value67, value68, value69) {
  value67.fillStyle = "rgba(100, 100, 200, 0.1)";
  value67.beginPath();
  value67.arc(50, 50, 30, 0, Math.PI * 2);
  value67.fill();
  value67.beginPath();
  value67.arc(value68 - 50, 50, 30, 0, Math.PI * 2);
  value67.fill();
  value67.beginPath();
  value67.arc(50, value69 - 50, 30, 0, Math.PI * 2);
  value67.fill();
  value67.beginPath();
  value67.arc(value68 - 50, value69 - 50, 30, 0, Math.PI * 2);
  value67.fill();
}
async function generateSimplePlatinumLogo(value70) {
  const value71 = 600;
  const value72 = 300;
  const value73 = createCanvas(value71, value72);
  const value74 = value73.getContext("2d");
  value74.fillStyle = "#0a0a1a";
  value74.fillRect(0, 0, value71, value72);
  const value75 = value74.createLinearGradient(0, 50, 0, 250);
  value75.addColorStop(0, "#F0F0FF");
  value75.addColorStop(0.3, "#D0D0E0");
  value75.addColorStop(0.6, "#A0A0C0");
  value75.addColorStop(1, "#8080A0");
  value74.font = "bold 72px Arial";
  value74.fillStyle = value75;
  value74.textAlign = "center";
  value74.textBaseline = "middle";
  value74.shadowColor = "rgba(0, 0, 50, 0.5)";
  value74.shadowBlur = 15;
  value74.shadowOffsetX = 4;
  value74.shadowOffsetY = 4;
  value74.fillText(value70.toUpperCase(), value71 / 2, value72 / 2);
  value74.strokeStyle = "#C0C0E0";
  value74.lineWidth = 5;
  value74.strokeRect(15, 15, value71 - 30, value72 - 30);
  return value73.toBuffer("image/png");
}
