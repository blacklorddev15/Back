const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "steellogo",
  description: "Create industrial steel metallic text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🔩 *STEEL LOGO*\n\n*steelogo*\nsteelogo <text>\n\n*Example:*\nsteelogo WOLF\nsteelogo STEEL\nsteelogo INDUSTRIAL\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateSteelLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🔩 *Steel Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [STEELOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateSteelLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#1a1a1a";
  value16.fillRect(0, 0, value13, value14);
  drawIndustrialBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 100, 0, 300);
  value17.addColorStop(0, "#F0F0F0");
  value17.addColorStop(0.15, "#D8D8D8");
  value17.addColorStop(0.3, "#B8B8B8");
  value17.addColorStop(0.45, "#989898");
  value17.addColorStop(0.6, "#787878");
  value17.addColorStop(0.75, "#585858");
  value17.addColorStop(0.9, "#404040");
  value17.addColorStop(1, "#282828");
  value16.font = "bold 84px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createSteel3DEffect(value16, value12, value13, value14, value17);
  addSteelHighlights(value16, value12, value13, value14);
  drawIndustrialBorder(value16, value13, value14);
  addMetalTexture(value16, value13, value14);
  addSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawIndustrialBackground(value18, value19, value20) {
  const value21 = value18.createRadialGradient(value19 / 2, value20 / 2, 0, value19 / 2, value20 / 2, Math.max(value19, value20) / 1.5);
  value21.addColorStop(0, "#2a2a2a");
  value21.addColorStop(0.4, "#1a1a1a");
  value21.addColorStop(0.8, "#0a0a0a");
  value21.addColorStop(1, "#000000");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  value18.strokeStyle = "rgba(100, 100, 100, 0.1)";
  value18.lineWidth = 1;
  for (let value22 = 0; value22 < value20; value22 += 3) {
    value18.beginPath();
    value18.moveTo(0, value22);
    value18.lineTo(value19, value22);
    value18.stroke();
  }
  value18.strokeStyle = "rgba(80, 80, 80, 0.2)";
  value18.lineWidth = 0.5;
  for (let value23 = 0; value23 < value19; value23 += 40) {
    value18.beginPath();
    value18.moveTo(value23, 0);
    value18.lineTo(value23, value20);
    value18.stroke();
  }
  for (let value24 = 0; value24 < value20; value24 += 40) {
    value18.beginPath();
    value18.moveTo(0, value24);
    value18.lineTo(value19, value24);
    value18.stroke();
  }
}
function createSteel3DEffect(value25, value26, value27, value28, value29) {
  const value30 = value27 / 2;
  const value31 = value28 / 2;
  const value32 = 8;
  for (let value33 = value32; value33 > 0; value33--) {
    const value34 = value33 * 1.5;
    const value35 = 0.1 + value33 / value32 * 0.3;
    value25.fillStyle = "rgba(0, 0, 0, " + value35 + ")";
    value25.fillText(value26.toUpperCase(), value30 + value34, value31 + value34);
  }
  value25.fillStyle = value29;
  value25.fillText(value26.toUpperCase(), value30, value31);
  value25.strokeStyle = "rgba(200, 200, 200, 0.4)";
  value25.lineWidth = 1.5;
  value25.strokeText(value26.toUpperCase(), value30, value31);
}
function addSteelHighlights(value36, value37, value38, value39) {
  const value40 = value38 / 2;
  const value41 = value39 / 2;
  value36.save();
  const value42 = value36.createLinearGradient(value40 - 250, value41 - 50, value40 + 250, value41 - 10);
  value42.addColorStop(0, "rgba(255, 255, 255, 0)");
  value42.addColorStop(0.3, "rgba(255, 255, 255, 0.7)");
  value42.addColorStop(0.5, "rgba(255, 255, 255, 0.8)");
  value42.addColorStop(0.7, "rgba(255, 255, 255, 0.6)");
  value42.addColorStop(1, "rgba(255, 255, 255, 0)");
  value36.globalCompositeOperation = "screen";
  value36.fillStyle = value42;
  value36.font = "bold 84px \"Arial\"";
  value36.textAlign = "center";
  value36.textBaseline = "middle";
  value36.fillText(value37.toUpperCase(), value40, value41 - 2);
  value36.globalCompositeOperation = "source-over";
  const value43 = value36.measureText(value37.toUpperCase()).width;
  const value44 = [{
    x: -0.35,
    y: -0.35,
    size: 5,
    alpha: 0.8
  }, {
    x: -0.15,
    y: -0.4,
    size: 6,
    alpha: 0.9
  }, {
    x: 0.05,
    y: -0.35,
    size: 4,
    alpha: 0.7
  }, {
    x: 0.25,
    y: -0.4,
    size: 5,
    alpha: 0.8
  }, {
    x: 0.4,
    y: -0.3,
    size: 3,
    alpha: 0.6
  }];
  value44.forEach(value45 => {
    const value46 = value40 + value45.x * value43 / 2;
    const value47 = value41 + value45.y * 45;
    value36.fillStyle = "rgba(255, 255, 255, " + value45.alpha + ")";
    value36.beginPath();
    value36.arc(value46, value47, value45.size, 0, Math.PI * 2);
    value36.fill();
  });
  value36.restore();
}
function drawIndustrialBorder(value48, value49, value50) {
  const value51 = value48.createLinearGradient(0, 0, value49, value50);
  value51.addColorStop(0, "#E0E0E0");
  value51.addColorStop(0.25, "#B0B0B0");
  value51.addColorStop(0.5, "#808080");
  value51.addColorStop(0.75, "#B0B0B0");
  value51.addColorStop(1, "#E0E0E0");
  value48.strokeStyle = value51;
  value48.lineWidth = 8;
  value48.shadowColor = "rgba(0, 0, 0, 0.5)";
  value48.shadowBlur = 15;
  value48.strokeRect(16, 16, value49 - 32, value50 - 32);
  value48.strokeStyle = "rgba(150, 150, 150, 0.4)";
  value48.lineWidth = 2;
  value48.shadowBlur = 0;
  value48.strokeRect(28, 28, value49 - 56, value50 - 56);
  drawIndustrialRivets(value48, value49, value50);
}
function drawIndustrialRivets(value52, value53, value54) {
  value52.fillStyle = "#909090";
  const value55 = [{
    x: 30,
    y: 30
  }, {
    x: value53 - 30,
    y: 30
  }, {
    x: 30,
    y: value54 - 30
  }, {
    x: value53 - 30,
    y: value54 - 30
  }, {
    x: value53 / 2,
    y: 30
  }, {
    x: value53 / 2,
    y: value54 - 30
  }, {
    x: 30,
    y: value54 / 2
  }, {
    x: value53 - 30,
    y: value54 / 2
  }];
  value55.forEach(value56 => {
    value52.beginPath();
    value52.arc(value56.x, value56.y, 5, 0, Math.PI * 2);
    value52.fill();
    value52.fillStyle = "rgba(255, 255, 255, 0.6)";
    value52.beginPath();
    value52.arc(value56.x - 1.5, value56.y - 1.5, 1.5, 0, Math.PI * 2);
    value52.fill();
    value52.fillStyle = "#909090";
  });
}
function addMetalTexture(value57, value58, value59) {
  value57.save();
  value57.globalAlpha = 0.3;
  for (let value60 = 0; value60 < 50; value60++) {
    const value61 = Math.random() * value58;
    const value62 = Math.random() * value59;
    const value63 = 10 + Math.random() * 30;
    const value64 = Math.random() * Math.PI;
    value57.strokeStyle = "rgba(150, 150, 150, 0.4)";
    value57.lineWidth = 0.5;
    value57.beginPath();
    value57.moveTo(value61, value62);
    value57.lineTo(value61 + Math.cos(value64) * value63, value62 + Math.sin(value64) * value63);
    value57.stroke();
  }
  for (let value65 = 0; value65 < 20; value65++) {
    const value66 = Math.random() * value58;
    const value67 = Math.random() * value59;
    const value68 = 2 + Math.random() * 4;
    const value69 = value57.createRadialGradient(value66, value67, 0, value66, value67, value68 * 2);
    value69.addColorStop(0, "rgba(255, 200, 100, 0.6)");
    value69.addColorStop(1, "transparent");
    value57.fillStyle = value69;
    value57.beginPath();
    value57.arc(value66, value67, value68 * 2, 0, Math.PI * 2);
    value57.fill();
    value57.fillStyle = "rgba(255, 150, 50, 0.8)";
    value57.beginPath();
    value57.arc(value66, value67, value68 * 0.5, 0, Math.PI * 2);
    value57.fill();
  }
  value57.restore();
}
function addSignature(value70, value71, value72) {
  value70.save();
  const value73 = value71 - 120;
  const value74 = value72 - 20;
  value70.font = "italic 12px \"Arial\"";
  value70.fillStyle = "rgba(150, 150, 150, 0.6)";
  value70.textAlign = "right";
  value70.textBaseline = "bottom";
  value70.fillText("by " + getBotName(), value73, value74);
  value70.strokeStyle = "rgba(150, 150, 150, 0.3)";
  value70.lineWidth = 0.5;
  const value75 = value70.measureText("by " + getBotName()).width;
  value70.beginPath();
  value70.moveTo(value73 - value75, value74 + 2);
  value70.lineTo(value73, value74 + 2);
  value70.stroke();
  value70.restore();
}
async function generateSimpleSteelLogo(value76) {
  const value77 = 600;
  const value78 = 300;
  const value79 = createCanvas(value77, value78);
  const value80 = value79.getContext("2d");
  value80.fillStyle = "#1a1a1a";
  value80.fillRect(0, 0, value77, value78);
  const value81 = value80.createLinearGradient(0, 50, 0, 250);
  value81.addColorStop(0, "#E0E0E0");
  value81.addColorStop(0.4, "#B0B0B0");
  value81.addColorStop(0.7, "#808080");
  value81.addColorStop(1, "#606060");
  value80.font = "bold 70px Arial";
  value80.fillStyle = value81;
  value80.textAlign = "center";
  value80.textBaseline = "middle";
  value80.shadowColor = "rgba(0, 0, 0, 0.5)";
  value80.shadowBlur = 15;
  value80.shadowOffsetX = 4;
  value80.shadowOffsetY = 4;
  value80.fillText(value76.toUpperCase(), value77 / 2, value78 / 2);
  value80.strokeStyle = "#B0B0B0";
  value80.lineWidth = 5;
  value80.strokeRect(15, 15, value77 - 30, value78 - 30);
  value80.font = "italic 10px \"Arial\"";
  value80.fillStyle = "rgba(150, 150, 150, 0.6)";
  value80.textAlign = "right";
  value80.textBaseline = "bottom";
  value80.fillText("by " + getBotName(), value77 - 20, value78 - 15);
  return value79.toBuffer("image/png");
}
