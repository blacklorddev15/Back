const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "diamondlogo",
  description: "Create brilliant diamond crystal text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "💎 *DIAMOND LOGO*\n\n*diamondlogo*\ndiamondlogo <text>\n\n*Example:*\ndiamondlogo WOLF\ndiamondlogo DIAMOND\ndiamondlogo CRYSTAL\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 12) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 12 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateDiamondLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "💎 *Diamond Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [DIAMONDLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateDiamondLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#050514";
  value16.fillRect(0, 0, value13, value14);
  drawStarfieldBackground(value16, value13, value14);
  createDiamondFacets(value16, value12, value13, value14);
  addDiamondReflections(value16, value12, value13, value14);
  addRainbowRefraction(value16, value13, value14);
  addDiamondSparkles(value16, value13, value14);
  drawDiamondBorder(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawStarfieldBackground(value17, value18, value19) {
  value17.fillStyle = "#FFFFFF";
  for (let value20 = 0; value20 < 200; value20++) {
    const value21 = Math.random() * value18;
    const value22 = Math.random() * value19;
    const value23 = Math.random() * 1.5;
    const value24 = 0.3 + Math.random() * 0.7;
    value17.globalAlpha = value24;
    value17.beginPath();
    value17.arc(value21, value22, value23, 0, Math.PI * 2);
    value17.fill();
  }
  value17.globalAlpha = 1;
  const value25 = value17.createRadialGradient(value18 * 0.7, value19 * 0.3, 0, value18 * 0.7, value19 * 0.3, 300);
  value25.addColorStop(0, "rgba(30, 30, 80, 0.3)");
  value25.addColorStop(1, "transparent");
  value17.fillStyle = value25;
  value17.fillRect(0, 0, value18, value19);
}
function createDiamondFacets(value26, value27, value28, value29) {
  const value30 = value28 / 2;
  const value31 = value29 / 2;
  const value32 = 8;
  for (let value33 = 0; value33 < value32; value33++) {
    const value34 = value33 * 1.5;
    const value35 = 0.1 + value33 / value32 * 0.4;
    const value36 = 210 + value33 * 5;
    const value37 = "hsla(" + value36 + ", 30%, " + (80 - value33 * 5) + "%, " + value35 + ")";
    value26.fillStyle = value37;
    value26.font = "bold 90px \"Arial\"";
    value26.textAlign = "center";
    value26.textBaseline = "middle";
    value26.fillText(value27.toUpperCase(), value30 + value34, value31 + value34);
  }
  value26.fillStyle = "rgba(255, 255, 255, 0.9)";
  value26.font = "bold 90px \"Arial\"";
  value26.textAlign = "center";
  value26.textBaseline = "middle";
  value26.fillText(value27.toUpperCase(), value30, value31);
}
function addDiamondReflections(value38, value39, value40, value41) {
  const value42 = value40 / 2;
  const value43 = value41 / 2;
  value38.save();
  const value44 = value38.createLinearGradient(value42 - 250, value43 - 60, value42 + 250, value43 + 40);
  value44.addColorStop(0, "rgba(255, 255, 255, 0)");
  value44.addColorStop(0.3, "rgba(255, 255, 255, 0.9)");
  value44.addColorStop(0.5, "rgba(255, 255, 255, 0.95)");
  value44.addColorStop(0.7, "rgba(255, 255, 255, 0.8)");
  value44.addColorStop(1, "rgba(255, 255, 255, 0)");
  value38.globalCompositeOperation = "screen";
  value38.fillStyle = value44;
  value38.font = "bold 90px \"Arial\"";
  value38.textAlign = "center";
  value38.textBaseline = "middle";
  value38.fillText(value39.toUpperCase(), value42, value43);
  value38.globalCompositeOperation = "source-over";
  const value45 = value38.measureText(value39.toUpperCase()).width;
  const value46 = [{
    x: -0.4,
    y: -0.3,
    size: 12,
    brightness: 0.9
  }, {
    x: -0.25,
    y: -0.4,
    size: 8,
    brightness: 0.8
  }, {
    x: -0.1,
    y: -0.35,
    size: 10,
    brightness: 0.85
  }, {
    x: 0.05,
    y: -0.4,
    size: 9,
    brightness: 0.8
  }, {
    x: 0.2,
    y: -0.35,
    size: 11,
    brightness: 0.9
  }, {
    x: 0.35,
    y: -0.3,
    size: 7,
    brightness: 0.75
  }, {
    x: -0.3,
    y: 0.2,
    size: 6,
    brightness: 0.7
  }, {
    x: 0.25,
    y: 0.25,
    size: 5,
    brightness: 0.6
  }];
  value46.forEach(value47 => {
    const value48 = value42 + value47.x * value45 / 2;
    const value49 = value43 + value47.y * 50;
    value38.fillStyle = "rgba(255, 255, 255, " + value47.brightness + ")";
    value38.beginPath();
    const value50 = value47.size;
    value38.moveTo(value48, value49 - value50);
    value38.lineTo(value48 + value50 * 0.7, value49);
    value38.lineTo(value48, value49 + value50);
    value38.lineTo(value48 - value50 * 0.7, value49);
    value38.closePath();
    value38.fill();
    value38.shadowColor = "rgba(255, 255, 255, 0.8)";
    value38.shadowBlur = 15;
    value38.fill();
  });
  value38.restore();
}
function addRainbowRefraction(value51, value52, value53) {
  const value54 = value52 / 2;
  const value55 = value53 / 2;
  value51.save();
  value51.globalCompositeOperation = "screen";
  const value56 = [{
    color: "rgba(255, 0, 0, 0.3)",
    angle: -0.3
  }, {
    color: "rgba(255, 165, 0, 0.25)",
    angle: -0.15
  }, {
    color: "rgba(255, 255, 0, 0.2)",
    angle: 0
  }, {
    color: "rgba(0, 255, 0, 0.25)",
    angle: 0.15
  }, {
    color: "rgba(0, 0, 255, 0.3)",
    angle: 0.3
  }, {
    color: "rgba(75, 0, 130, 0.25)",
    angle: 0.45
  }, {
    color: "rgba(238, 130, 238, 0.2)",
    angle: 0.6
  }];
  value56.forEach((value57, value58) => {
    const value59 = value57.angle;
    const value60 = 60 + value58 * 8;
    const value61 = value51.createRadialGradient(value54 + Math.cos(value59) * value60, value55 + Math.sin(value59) * value60, 0, value54 + Math.cos(value59) * value60, value55 + Math.sin(value59) * value60, 80);
    value61.addColorStop(0, value57.color);
    value61.addColorStop(1, "transparent");
    value51.fillStyle = value61;
    value51.beginPath();
    value51.arc(value54 + Math.cos(value59) * value60, value55 + Math.sin(value59) * value60, 80, 0, Math.PI * 2);
    value51.fill();
  });
  value51.restore();
}
function addDiamondSparkles(value62, value63, value64) {
  value62.save();
  value62.globalAlpha = 0.9;
  for (let value65 = 0; value65 < 50; value65++) {
    const value66 = Math.random() * value63;
    const value67 = Math.random() * value64;
    const value68 = 1 + Math.random() * 3;
    const value69 = 0.7 + Math.random() * 0.3;
    value62.fillStyle = "rgba(255, 255, 255, " + value69 + ")";
    value62.beginPath();
    value62.moveTo(value66, value67 - value68);
    value62.lineTo(value66 + value68 * 0.3, value67 - value68 * 0.3);
    value62.lineTo(value66 + value68, value67);
    value62.lineTo(value66 + value68 * 0.3, value67 + value68 * 0.3);
    value62.lineTo(value66, value67 + value68);
    value62.lineTo(value66 - value68 * 0.3, value67 + value68 * 0.3);
    value62.lineTo(value66 - value68, value67);
    value62.lineTo(value66 - value68 * 0.3, value67 - value68 * 0.3);
    value62.closePath();
    value62.fill();
    value62.shadowColor = "rgba(255, 255, 255, 0.8)";
    value62.shadowBlur = 10;
    value62.fill();
  }
  value62.shadowColor = "transparent";
  value62.shadowBlur = 0;
  value62.restore();
}
function drawDiamondBorder(value70, value71, value72) {
  value70.strokeStyle = "rgba(200, 220, 255, 0.6)";
  value70.lineWidth = 6;
  value70.shadowColor = "rgba(100, 150, 255, 0.4)";
  value70.shadowBlur = 20;
  value70.strokeRect(15, 15, value71 - 30, value72 - 30);
  const value73 = [{
    x: 30,
    y: 30
  }, {
    x: value71 - 30,
    y: 30
  }, {
    x: 30,
    y: value72 - 30
  }, {
    x: value71 - 30,
    y: value72 - 30
  }];
  value73.forEach(value74 => {
    drawDiamondStud(value70, value74.x, value74.y, 8);
  });
  value70.shadowColor = "transparent";
  value70.shadowBlur = 0;
}
function drawDiamondStud(value75, value76, value77, value78) {
  value75.save();
  value75.fillStyle = "rgba(255, 255, 255, 0.9)";
  value75.beginPath();
  value75.moveTo(value76, value77 - value78);
  value75.lineTo(value76 + value78, value77);
  value75.lineTo(value76, value77 + value78);
  value75.lineTo(value76 - value78, value77);
  value75.closePath();
  value75.fill();
  value75.fillStyle = "rgba(255, 255, 255, 0.6)";
  value75.beginPath();
  value75.moveTo(value76 - value78 * 0.3, value77 - value78 * 0.3);
  value75.lineTo(value76, value77 - value78 * 0.1);
  value75.lineTo(value76 + value78 * 0.1, value77);
  value75.lineTo(value76 - value78 * 0.1, value77 + value78 * 0.3);
  value75.closePath();
  value75.fill();
  value75.restore();
}
async function generateSimpleDiamondLogo(value79) {
  const value80 = 600;
  const value81 = 300;
  const value82 = createCanvas(value80, value81);
  const value83 = value82.getContext("2d");
  value83.fillStyle = "#0a0a1a";
  value83.fillRect(0, 0, value80, value81);
  const value84 = value83.createLinearGradient(0, 40, 0, 260);
  value84.addColorStop(0, "#FFFFFF");
  value84.addColorStop(0.3, "#E0F0FF");
  value84.addColorStop(0.6, "#A0C0FF");
  value84.addColorStop(1, "#6080FF");
  value83.font = "bold 70px Arial";
  value83.fillStyle = value84;
  value83.textAlign = "center";
  value83.textBaseline = "middle";
  value83.shadowColor = "rgba(100, 150, 255, 0.6)";
  value83.shadowBlur = 20;
  value83.fillText(value79.toUpperCase(), value80 / 2, value81 / 2);
  value83.shadowBlur = 0;
  for (let value85 = 0; value85 < 10; value85++) {
    const value86 = 50 + Math.random() * (value80 - 100);
    const value87 = 50 + Math.random() * (value81 - 100);
    const value88 = 2 + Math.random() * 4;
    value83.fillStyle = "rgba(255, 255, 255, 0.8)";
    value83.beginPath();
    value83.arc(value86, value87, value88, 0, Math.PI * 2);
    value83.fill();
  }
  return value82.toBuffer("image/png");
}
