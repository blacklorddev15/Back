const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "lightninglogo",
  description: "Create electrifying text logos with realistic lightning and storm effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "⚡ *LIGHTNING LOGO*\n\n*lightninglogo*\nlightninglogo <text>\n\n*Example:*\nlightninglogo BOLT\nlightninglogo THOR\nlightninglogo STORM\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateLightningLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "⚡ *Lightning Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [LIGHTNINGLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateLightningLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createStormBackground(value16, value13, value14);
  const value17 = generateLightningBolts(value16, value13, value14);
  addLightningGlow(value16, value17);
  addElectricalArcs(value16, value13, value14);
  drawElectrifiedText(value16, value12, value13, value14);
  addStormClouds(value16, value13, value14);
  addRainEffects(value16, value13, value14);
  addEnergyParticles(value16, value13, value14);
  drawElectricBorder(value16, value13, value14);
  addLightningSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createStormBackground(value18, value19, value20) {
  const value21 = value18.createLinearGradient(0, 0, 0, value20);
  value21.addColorStop(0, "#0a0a1a");
  value21.addColorStop(0.3, "#1a1a2a");
  value21.addColorStop(0.6, "#2a2a3a");
  value21.addColorStop(1, "#1a1a2a");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  addBackgroundLightningFlashes(value18, value19, value20);
}
function generateLightningBolts(value22, value23, value24) {
  const value25 = [];
  const value26 = createLightningBolt(value22, value23 * 0.7, value24 * 0.1, value23 * 0.3, value24 * 0.9, 5, 0.7);
  value25.push(value26);
  value25.push(createLightningBolt(value22, value23 * 0.8, value24 * 0.05, value23 * 0.5, value24 * 0.7, 4, 0.5));
  value25.push(createLightningBolt(value22, value23 * 0.6, value24 * 0.15, value23 * 0.2, value24 * 0.8, 3, 0.4));
  for (let value27 = 0; value27 < 8; value27++) {
    const value28 = value23 * 0.7 + (Math.random() - 0.5) * 100;
    const value29 = value24 * 0.1 + Math.random() * value24 * 0.3;
    const value30 = value23 * 0.3 + (Math.random() - 0.5) * 200;
    const value31 = value24 * 0.7 + Math.random() * value24 * 0.2;
    value25.push(createLightningBolt(value22, value28, value29, value30, value31, 2, 0.3));
  }
  return value25;
}
function createLightningBolt(value32, value33, value34, value35, value36, value37, value38) {
  value32.save();
  const value39 = generateLightningPath(value33, value34, value35, value36, value37);
  value32.strokeStyle = "rgba(255, 255, 255, " + value38 + ")";
  value32.lineWidth = 3;
  value32.lineCap = "round";
  value32.lineJoin = "round";
  value32.beginPath();
  value32.moveTo(value39[0].x, value39[0].y);
  for (let value40 = 1; value40 < value39.length; value40++) {
    value32.lineTo(value39[value40].x, value39[value40].y);
  }
  value32.stroke();
  value32.strokeStyle = "rgba(200, 220, 255, " + value38 * 1.2 + ")";
  value32.lineWidth = 1.5;
  value32.beginPath();
  value32.moveTo(value39[0].x, value39[0].y);
  for (let value41 = 1; value41 < value39.length; value41++) {
    value32.lineTo(value39[value41].x, value39[value41].y);
  }
  value32.stroke();
  value32.restore();
  return {
    points: value39,
    intensity: value38,
    startX: value33,
    startY: value34,
    endX: value35,
    endY: value36
  };
}
function generateLightningPath(value42, value43, value44, value45, value46) {
  const value47 = [{
    x: value42,
    y: value43
  }];
  function handler48(value49, value50, value51) {
    if (value51 <= 0) {
      return;
    }
    const value52 = (value49.x + value50.x) / 2;
    const value53 = (value49.y + value50.y) / 2;
    const value54 = (Math.random() - 0.5) * (50 / value51);
    const value55 = Math.atan2(value50.y - value49.y, value50.x - value49.x);
    const value56 = value52 + Math.cos(value55 + Math.PI / 2) * value54;
    const value57 = value53 + Math.sin(value55 + Math.PI / 2) * value54;
    const value58 = {
      x: value56,
      y: value57
    };
    handler48(value49, value58, value51 - 1);
    value47.push(value58);
    handler48(value58, value50, value51 - 1);
  }
  handler48({
    x: value42,
    y: value43
  }, {
    x: value44,
    y: value45
  }, value46);
  value47.push({
    x: value44,
    y: value45
  });
  return value47;
}
function addLightningGlow(value59, value60) {
  value59.save();
  value59.globalCompositeOperation = "screen";
  value60.forEach(value61 => {
    const value62 = value59.createRadialGradient(value61.startX, value61.startY, 0, value61.startX, value61.startY, 100);
    value62.addColorStop(0, "rgba(100, 150, 255, " + value61.intensity * 0.3 + ")");
    value62.addColorStop(1, "transparent");
    value59.fillStyle = value62;
    value59.beginPath();
    value59.arc(value61.startX, value61.startY, 100, 0, Math.PI * 2);
    value59.fill();
    value59.strokeStyle = "rgba(80, 120, 255, " + value61.intensity * 0.4 + ")";
    value59.lineWidth = 20;
    value59.lineCap = "round";
    value59.beginPath();
    value59.moveTo(value61.points[0].x, value61.points[0].y);
    for (let value63 = 1; value63 < value61.points.length; value63++) {
      value59.lineTo(value61.points[value63].x, value61.points[value63].y);
    }
    value59.stroke();
    value59.strokeStyle = "rgba(150, 200, 255, " + value61.intensity * 0.6 + ")";
    value59.lineWidth = 10;
    value59.beginPath();
    value59.moveTo(value61.points[0].x, value61.points[0].y);
    for (let value64 = 1; value64 < value61.points.length; value64++) {
      value59.lineTo(value61.points[value64].x, value61.points[value64].y);
    }
    value59.stroke();
  });
  value59.restore();
}
function addElectricalArcs(value65, value66, value67) {
  value65.save();
  value65.globalCompositeOperation = "screen";
  for (let value68 = 0; value68 < 15; value68++) {
    const value69 = value66 * 0.3 + Math.random() * value66 * 0.4;
    const value70 = value67 * 0.4 + Math.random() * value67 * 0.3;
    const value71 = 20 + Math.random() * 50;
    drawElectricalArc(value65, value69, value70, value71);
  }
  for (let value72 = 0; value72 < 5; value72++) {
    const value73 = value66 * 0.2 + Math.random() * value66 * 0.6;
    const value74 = value67 * 0.85;
    drawGroundStrike(value65, value73, value74);
  }
  value65.restore();
}
function drawElectricalArc(value75, value76, value77, value78) {
  const value79 = [];
  value79.push({
    x: value76,
    y: value77
  });
  for (let value80 = 0; value80 < 8; value80++) {
    value79.push({
      x: value76 + (Math.random() - 0.5) * value78 * 2,
      y: value77 + (Math.random() - 0.5) * value78
    });
  }
  const value81 = ["rgba(100, 150, 255, 0.8)", "rgba(150, 200, 255, 0.6)", "rgba(200, 230, 255, 0.4)"];
  value81.forEach((value82, value83) => {
    value75.strokeStyle = value82;
    value75.lineWidth = 3 - value83;
    value75.lineCap = "round";
    value75.beginPath();
    value75.moveTo(value79[0].x, value79[0].y);
    for (let value84 = 1; value84 < value79.length; value84++) {
      value75.lineTo(value79[value84].x, value79[value84].y);
    }
    value75.stroke();
  });
  addSparkParticles(value75, value79[value79.length - 1].x, value79[value79.length - 1].y);
}
function drawGroundStrike(value85, value86, value87) {
  const value88 = value85.createRadialGradient(value86, value87, 0, value86, value87, 60);
  value88.addColorStop(0, "rgba(100, 150, 255, 0.6)");
  value88.addColorStop(0.5, "rgba(80, 120, 255, 0.3)");
  value88.addColorStop(1, "transparent");
  value85.fillStyle = value88;
  value85.beginPath();
  value85.arc(value86, value87, 60, 0, Math.PI * 2);
  value85.fill();
  value85.strokeStyle = "rgba(200, 220, 255, 0.8)";
  value85.lineWidth = 2;
  for (let value89 = 0; value89 < 5; value89++) {
    const value90 = value89 / 5 * Math.PI * 2;
    const value91 = 15 + Math.random() * 25;
    value85.beginPath();
    value85.moveTo(value86, value87);
    value85.lineTo(value86 + Math.cos(value90) * value91, value87 + Math.sin(value90) * value91);
    value85.stroke();
  }
  addSparkParticles(value85, value86, value87);
}
function addSparkParticles(value92, value93, value94) {
  value92.save();
  value92.globalCompositeOperation = "screen";
  for (let value95 = 0; value95 < 8; value95++) {
    const value96 = Math.random() * Math.PI * 2;
    const value97 = 5 + Math.random() * 20;
    const value98 = 1 + Math.random() * 3;
    const value99 = value93 + Math.cos(value96) * value97;
    const value100 = value94 + Math.sin(value96) * value97;
    value92.fillStyle = "rgba(150, 200, 255, 0.8)";
    value92.beginPath();
    value92.arc(value99, value100, value98 * 2, 0, Math.PI * 2);
    value92.fill();
    value92.fillStyle = "rgba(255, 255, 255, 1)";
    value92.beginPath();
    value92.arc(value99, value100, value98 * 0.5, 0, Math.PI * 2);
    value92.fill();
  }
  value92.restore();
}
function drawElectrifiedText(value101, value102, value103, value104) {
  const value105 = value103 * 0.35;
  const value106 = value104 * 0.6;
  value101.save();
  value101.shadowColor = "rgba(100, 150, 255, 0.8)";
  value101.shadowBlur = 40;
  const value107 = value101.createLinearGradient(value105 - 100, value106 - 50, value105 + 100, value106 + 50);
  value107.addColorStop(0, "#ffffff");
  value107.addColorStop(0.3, "#aaccff");
  value107.addColorStop(0.7, "#6688ff");
  value107.addColorStop(1, "#4466cc");
  value101.font = "bold 70px \"Arial\"";
  value101.textAlign = "center";
  value101.textBaseline = "middle";
  value101.fillStyle = value107;
  value101.fillText(value102.toUpperCase(), value105, value106);
  value101.shadowColor = "transparent";
  value101.strokeStyle = "rgba(200, 220, 255, 0.9)";
  value101.lineWidth = 3;
  value101.strokeText(value102.toUpperCase(), value105, value106);
  addTextLightning(value101, value102, value105, value106);
  value101.restore();
}
function addTextLightning(value108, value109, value110, value111) {
  value108.save();
  value108.globalCompositeOperation = "screen";
  const value112 = value108.measureText(value109.toUpperCase());
  const value113 = value112.width;
  const value114 = 70;
  for (let value115 = 0; value115 < value109.length * 2; value115++) {
    const value116 = value115 / (value109.length * 2);
    const value117 = value110 - value113 / 2 + value113 * value116;
    const value118 = value111 - value114 / 2 + Math.random() * value114;
    if (Math.random() > 0.7) {
      const value119 = 10 + Math.random() * 30;
      const value120 = Math.random() * Math.PI * 2;
      value108.strokeStyle = "rgba(150, 200, 255, " + (0.3 + Math.random() * 0.4) + ")";
      value108.lineWidth = 1 + Math.random() * 2;
      value108.beginPath();
      value108.moveTo(value117, value118);
      value108.lineTo(value117 + Math.cos(value120) * value119, value118 + Math.sin(value120) * value119);
      value108.stroke();
    }
  }
  value108.restore();
}
function addStormClouds(value121, value122, value123) {
  value121.save();
  const value124 = value121.createLinearGradient(0, value123 * 0.2, 0, value123 * 0.5);
  value124.addColorStop(0, "rgba(40, 40, 60, 0.9)");
  value124.addColorStop(1, "rgba(20, 20, 40, 0.7)");
  value121.fillStyle = value124;
  value121.beginPath();
  value121.moveTo(value122 * 0.1, value123 * 0.3);
  for (let value125 = 0; value125 <= 10; value125++) {
    const value126 = value122 * 0.1 + value125 / 10 * value122 * 0.8;
    const value127 = value123 * 0.3 + Math.sin(value125 * 0.8) * 20 - Math.random() * 10;
    value121.lineTo(value126, value127);
  }
  for (let value128 = 10; value128 >= 0; value128--) {
    const value129 = value122 * 0.1 + value128 / 10 * value122 * 0.8;
    const value130 = value123 * 0.5 + Math.cos(value128 * 0.5) * 15 + Math.random() * 10;
    value121.lineTo(value129, value130);
  }
  value121.closePath();
  value121.fill();
  value121.strokeStyle = "rgba(80, 80, 120, 0.6)";
  value121.lineWidth = 2;
  value121.stroke();
  value121.restore();
}
function addRainEffects(value131, value132, value133) {
  value131.save();
  value131.globalAlpha = 0.6;
  for (let value134 = 0; value134 < 200; value134++) {
    const value135 = Math.random() * value132;
    const value136 = Math.random() * value133;
    const value137 = 10 + Math.random() * 20;
    const value138 = Math.PI * 0.2;
    value131.strokeStyle = "rgba(150, 180, 220, " + (0.3 + Math.random() * 0.4) + ")";
    value131.lineWidth = 1;
    value131.lineCap = "round";
    value131.beginPath();
    value131.moveTo(value135, value136);
    value131.lineTo(value135 + Math.cos(value138) * value137, value136 + Math.sin(value138) * value137);
    value131.stroke();
  }
  value131.restore();
}
function addBackgroundLightningFlashes(value139, value140, value141) {
  value139.save();
  value139.globalAlpha = 0.1;
  value139.globalCompositeOperation = "screen";
  for (let value142 = 0; value142 < 3; value142++) {
    const value143 = Math.random() * value140;
    const value144 = Math.random() * value141 * 0.5;
    const value145 = 100 + Math.random() * 200;
    const value146 = value139.createRadialGradient(value143, value144, 0, value143, value144, value145);
    value146.addColorStop(0, "rgba(100, 150, 255, 0.4)");
    value146.addColorStop(1, "transparent");
    value139.fillStyle = value146;
    value139.beginPath();
    value139.arc(value143, value144, value145, 0, Math.PI * 2);
    value139.fill();
  }
  value139.restore();
}
function addEnergyParticles(value147, value148, value149) {
  value147.save();
  value147.globalCompositeOperation = "screen";
  for (let value150 = 0; value150 < 50; value150++) {
    const value151 = Math.random() * value148;
    const value152 = Math.random() * value149;
    const value153 = 1 + Math.random() * 4;
    const value154 = 0.3 + Math.random() * 0.5;
    value147.fillStyle = "rgba(100, 180, 255, " + value154 + ")";
    value147.beginPath();
    value147.arc(value151, value152, value153, 0, Math.PI * 2);
    value147.fill();
    value147.fillStyle = "rgba(150, 200, 255, " + value154 * 0.3 + ")";
    value147.beginPath();
    value147.arc(value151, value152, value153 * 2, 0, Math.PI * 2);
    value147.fill();
  }
  value147.restore();
}
function drawElectricBorder(value155, value156, value157) {
  value155.save();
  const value158 = value155.createLinearGradient(0, 0, value156, value157);
  value158.addColorStop(0, "#4466cc");
  value158.addColorStop(0.5, "#88aaff");
  value158.addColorStop(1, "#4466cc");
  value155.strokeStyle = value158;
  value155.lineWidth = 8;
  value155.shadowColor = "rgba(100, 150, 255, 0.8)";
  value155.shadowBlur = 25;
  value155.strokeRect(10, 10, value156 - 20, value157 - 20);
  value155.strokeStyle = "rgba(200, 220, 255, 0.6)";
  value155.lineWidth = 2;
  value155.shadowBlur = 15;
  value155.strokeRect(20, 20, value156 - 40, value157 - 40);
  value155.restore();
}
function addLightningSignature(value159, value160, value161) {
  value159.save();
  const value162 = value160 - 110;
  const value163 = value161 - 25;
  value159.font = "italic 14px \"Arial\"";
  value159.fillStyle = "rgba(150, 200, 255, 0.9)";
  value159.textAlign = "right";
  value159.textBaseline = "bottom";
  value159.shadowColor = "rgba(100, 150, 255, 0.6)";
  value159.shadowBlur = 15;
  value159.fillText("by " + getBotName(), value162, value163);
  value159.strokeStyle = "rgba(200, 220, 255, 0.8)";
  value159.lineWidth = 2;
  value159.lineCap = "round";
  value159.beginPath();
  value159.moveTo(value162 + 5, value163 - 10);
  value159.lineTo(value162 - 15, value163 + 5);
  value159.lineTo(value162 - 5, value163);
  value159.lineTo(value162 - 25, value163 + 15);
  value159.stroke();
  value159.restore();
}
