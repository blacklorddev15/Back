const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "icelogo",
  description: "Create frozen ice crystal text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "❄️ *ICE LOGO*\n\n*icelogo*\nicelogo <text>\n\n*Example:*\nicelogo WOLF\nicelogo FROST\nicelogo ICE\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 12) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 12 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateIceLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "❄️ *Ice Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [ICELOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateIceLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#0a1428";
  value16.fillRect(0, 0, value13, value14);
  drawFrozenBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 100, 0, 300);
  value17.addColorStop(0, "#FFFFFF");
  value17.addColorStop(0.2, "#E8F4FF");
  value17.addColorStop(0.4, "#C8E8FF");
  value17.addColorStop(0.6, "#A0D8FF");
  value17.addColorStop(0.8, "#78C8FF");
  value17.addColorStop(1, "#50B8FF");
  value16.font = "bold 84px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createFrozenIceEffect(value16, value12, value13, value14, value17);
  addIceFacets(value16, value12, value13, value14);
  addFrostEffects(value16, value13, value14);
  drawFrozenBorder(value16, value13, value14);
  addSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawFrozenBackground(value18, value19, value20) {
  const value21 = value18.createRadialGradient(value19 / 2, value20 / 2, 0, value19 / 2, value20 / 2, Math.max(value19, value20) / 1.5);
  value21.addColorStop(0, "#1a2a4a");
  value21.addColorStop(0.4, "#0a1a3a");
  value21.addColorStop(0.8, "#050a28");
  value21.addColorStop(1, "#000518");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  value18.strokeStyle = "rgba(200, 230, 255, 0.1)";
  value18.lineWidth = 1;
  for (let value22 = 0; value22 < 50; value22++) {
    const value23 = Math.random() * value19;
    const value24 = Math.random() * value20;
    drawSnowflake(value18, value23, value24, 2 + Math.random() * 4);
  }
  value18.fillStyle = "rgba(180, 220, 255, 0.2)";
  for (let value25 = 0; value25 < 30; value25++) {
    const value26 = Math.random() * value19;
    const value27 = Math.random() * value20;
    const value28 = 1 + Math.random() * 3;
    drawIceCrystal(value18, value26, value27, value28);
  }
}
function createFrozenIceEffect(value29, value30, value31, value32, value33) {
  const value34 = value31 / 2;
  const value35 = value32 / 2;
  const value36 = 8;
  for (let value37 = value36; value37 > 0; value37--) {
    const value38 = value37 * 1.2;
    const value39 = 0.05 + value37 / value36 * 0.2;
    const value40 = 150 - value37 * 15;
    value29.fillStyle = "rgba(0, " + value40 + ", 255, " + value39 + ")";
    value29.fillText(value30.toUpperCase(), value34 + value38, value35 + value38);
  }
  value29.fillStyle = value33;
  value29.fillText(value30.toUpperCase(), value34, value35);
  value29.strokeStyle = "rgba(255, 255, 255, 0.6)";
  value29.lineWidth = 1.2;
  value29.strokeText(value30.toUpperCase(), value34, value35);
}
function addIceFacets(value41, value42, value43, value44) {
  const value45 = value43 / 2;
  const value46 = value44 / 2;
  const value47 = value41.measureText(value42.toUpperCase()).width;
  value41.save();
  value41.globalAlpha = 0.7;
  const value48 = [{
    x: -0.3,
    y: -0.3,
    size: 4
  }, {
    x: -0.15,
    y: -0.4,
    size: 5
  }, {
    x: 0,
    y: -0.35,
    size: 3
  }, {
    x: 0.15,
    y: -0.4,
    size: 4
  }, {
    x: 0.3,
    y: -0.3,
    size: 3
  }, {
    x: -0.25,
    y: 0.2,
    size: 2
  }, {
    x: 0.2,
    y: 0.25,
    size: 2
  }];
  value48.forEach(value49 => {
    const value50 = value45 + value49.x * value47 / 2;
    const value51 = value46 + value49.y * 40;
    value41.fillStyle = "#FFFFFF";
    value41.beginPath();
    value41.arc(value50, value51, value49.size, 0, Math.PI * 2);
    value41.fill();
    value41.shadowColor = "rgba(180, 220, 255, 0.8)";
    value41.shadowBlur = 8;
    value41.fill();
  });
  value41.restore();
}
function addFrostEffects(value52, value53, value54) {
  value52.save();
  value52.globalAlpha = 0.8;
  for (let value55 = 0; value55 < 30; value55++) {
    const value56 = Math.random() * value53;
    const value57 = Math.random() * value54;
    const value58 = 1 + Math.random() * 2;
    value52.fillStyle = "#FFFFFF";
    value52.beginPath();
    value52.arc(value56, value57, value58, 0, Math.PI * 2);
    value52.fill();
  }
  const value59 = value52.createLinearGradient(0, value54 * 0.6, 0, value54);
  value59.addColorStop(0, "rgba(200, 230, 255, 0.3)");
  value59.addColorStop(1, "transparent");
  value52.fillStyle = value59;
  value52.fillRect(0, value54 * 0.6, value53, value54 * 0.4);
  value52.restore();
}
function drawFrozenBorder(value60, value61, value62) {
  const value63 = value60.createLinearGradient(0, 0, value61, value62);
  value63.addColorStop(0, "#A0D8FF");
  value63.addColorStop(0.5, "#78C8FF");
  value63.addColorStop(1, "#A0D8FF");
  value60.strokeStyle = value63;
  value60.lineWidth = 6;
  value60.shadowColor = "rgba(0, 150, 255, 0.4)";
  value60.shadowBlur = 15;
  value60.strokeRect(18, 18, value61 - 36, value62 - 36);
  value60.strokeStyle = "rgba(200, 230, 255, 0.4)";
  value60.lineWidth = 2;
  value60.shadowBlur = 0;
  value60.strokeRect(30, 30, value61 - 60, value62 - 60);
}
function drawSnowflake(value64, value65, value66, value67) {
  value64.save();
  value64.translate(value65, value66);
  for (let value68 = 0; value68 < 6; value68++) {
    value64.rotate(Math.PI / 3);
    value64.beginPath();
    value64.moveTo(0, 0);
    value64.lineTo(0, value67);
    value64.stroke();
    value64.beginPath();
    value64.moveTo(-value67 * 0.3, value67 * 0.3);
    value64.lineTo(value67 * 0.3, value67 * 0.7);
    value64.stroke();
  }
  value64.restore();
}
function drawIceCrystal(value69, value70, value71, value72) {
  value69.save();
  value69.translate(value70, value71);
  value69.beginPath();
  value69.moveTo(0, -value72);
  value69.lineTo(value72 * 0.7, 0);
  value69.lineTo(0, value72);
  value69.lineTo(-value72 * 0.7, 0);
  value69.closePath();
  value69.fill();
  value69.restore();
}
function addSignature(value73, value74, value75) {
  value73.save();
  const value76 = value74 - 120;
  const value77 = value75 - 20;
  value73.font = "italic 12px \"Arial\"";
  value73.fillStyle = "rgba(160, 200, 255, 0.7)";
  value73.textAlign = "right";
  value73.textBaseline = "bottom";
  value73.fillText("by " + getBotName(), value76, value77);
  value73.strokeStyle = "rgba(160, 200, 255, 0.4)";
  value73.lineWidth = 0.5;
  const value78 = value73.measureText("by " + getBotName()).width;
  value73.beginPath();
  value73.moveTo(value76 - value78, value77 + 2);
  value73.lineTo(value76, value77 + 2);
  value73.stroke();
  value73.restore();
}
