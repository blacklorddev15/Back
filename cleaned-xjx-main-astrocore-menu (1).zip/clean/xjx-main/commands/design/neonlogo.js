const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "neonlogo",
  description: "Create vibrant neon glow style text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "💡 *NEON LOGO*\n\n*neonlogo*\nneonlogo <text>\n\n*Example:*\nneonlogo WOLF\nneonlogo NEON\nneonlogo GLOW\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateNeonLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "💡 *Neon Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [NEONLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateNeonLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#0a0a2a";
  value16.fillRect(0, 0, value13, value14);
  drawNeonBackground(value16, value13, value14);
  const value17 = getRandomNeonColor();
  drawNeonGlow(value16, value12, value13, value14, value17);
  drawNeonTube(value16, value12, value13, value14, value17);
  drawNeonReflection(value16, value12, value13, value14, value17);
  addNeonParticles(value16, value13, value14, value17);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawNeonBackground(value18, value19, value20) {
  value18.strokeStyle = "rgba(0, 50, 100, 0.3)";
  value18.lineWidth = 1;
  for (let value21 = 0; value21 < value19; value21 += 40) {
    value18.beginPath();
    value18.moveTo(value21, value20);
    value18.lineTo(value19 / 2, value20 / 2);
    value18.stroke();
  }
  value18.fillStyle = "rgba(20, 20, 60, 0.8)";
  for (let value22 = 0; value22 < 10; value22++) {
    const value23 = Math.random() * 60 + 20;
    const value24 = Math.random() * 100 + 50;
    const value25 = Math.random() * value19;
    value18.fillRect(value25, value20 - value24, value23, value24);
  }
}
function drawNeonGlow(value26, value27, value28, value29, value30) {
  value26.textAlign = "center";
  value26.textBaseline = "middle";
  value26.font = "bold 80px \"Arial\"";
  const value31 = [{
    blur: 50,
    alpha: 0.3,
    offset: 0
  }, {
    blur: 40,
    alpha: 0.4,
    offset: 0
  }, {
    blur: 30,
    alpha: 0.5,
    offset: 0
  }, {
    blur: 20,
    alpha: 0.6,
    offset: 0
  }, {
    blur: 10,
    alpha: 0.7,
    offset: 0
  }];
  for (const value32 of value31) {
    value26.shadowColor = value30;
    value26.shadowBlur = value32.blur;
    value26.fillStyle = "rgba(255, 255, 255, " + value32.alpha + ")";
    value26.fillText(value27.toUpperCase(), value28 / 2, value29 / 2 + value32.offset);
  }
}
function drawNeonTube(value33, value34, value35, value36, value37) {
  value33.shadowColor = "transparent";
  value33.shadowBlur = 0;
  value33.fillStyle = value37;
  value33.font = "bold 80px \"Arial\"";
  value33.fillText(value34.toUpperCase(), value35 / 2, value36 / 2);
  value33.strokeStyle = "#FFFFFF";
  value33.lineWidth = 1;
  value33.globalAlpha = 0.3;
  value33.strokeText(value34.toUpperCase(), value35 / 2, value36 / 2 - 1);
  value33.globalAlpha = 1;
}
function drawNeonReflection(value38, value39, value40, value41, value42) {
  value38.save();
  value38.translate(value40 / 2, value41 / 2);
  value38.scale(1, -0.3);
  value38.translate(-value40 / 2, -value41 / 2);
  const value43 = value38.createLinearGradient(0, value41 / 2, 0, value41);
  value43.addColorStop(0, value42);
  value43.addColorStop(1, "transparent");
  value38.globalAlpha = 0.2;
  value38.fillStyle = value43;
  value38.font = "bold 80px \"Arial\"";
  value38.fillText(value39.toUpperCase(), value40 / 2, value41 / 2);
  value38.restore();
}
function addNeonParticles(value44, value45, value46, value47) {
  value44.globalAlpha = 0.7;
  for (let value48 = 0; value48 < 40; value48++) {
    const value49 = Math.random() * value45;
    const value50 = Math.random() * value46;
    const value51 = Math.random() * 3 + 1;
    const value52 = Math.random() * 0.5 + 0.3;
    value44.fillStyle = value47;
    value44.globalAlpha = value52;
    value44.beginPath();
    value44.arc(value49, value50, value51, 0, Math.PI * 2);
    value44.fill();
  }
  value44.globalAlpha = 0.1;
  value44.fillStyle = "#FFFFFF";
  for (let value53 = 0; value53 < 5; value53++) {
    const value54 = Math.random() * value45;
    const value55 = Math.random() * value46;
    const value56 = Math.random() * 20 + 10;
    value44.beginPath();
    value44.arc(value54, value55, value56, 0, Math.PI * 2);
    value44.fill();
  }
  value44.globalAlpha = 1;
}
function getRandomNeonColor() {
  const value57 = ["#FF00FF", "#00FFFF", "#00FF00", "#FFFF00", "#FF0000", "#0000FF", "#FF00FF", "#00FF00", "#FFA500", "#8A2BE2", "#FF1493", "#00CED1", "#7FFF00", "#DC143C", "#40E0D0"];
  return value57[Math.floor(Math.random() * value57.length)];
}
async function generateSpecificNeonLogo(value58, value59) {
  const value60 = 800;
  const value61 = 400;
  const value62 = createCanvas(value60, value61);
  const value63 = value62.getContext("2d");
  value63.fillStyle = "#0a0a2a";
  value63.fillRect(0, 0, value60, value61);
  const value64 = value59 || getRandomNeonColor();
  value63.textAlign = "center";
  value63.textBaseline = "middle";
  value63.font = "bold 80px \"Arial\"";
  value63.shadowColor = value64;
  value63.shadowBlur = 30;
  value63.fillStyle = value64;
  value63.fillText(value58.toUpperCase(), value60 / 2, value61 / 2);
  value63.shadowBlur = 0;
  value63.fillStyle = "#FFFFFF";
  value63.globalAlpha = 0.8;
  value63.fillText(value58.toUpperCase(), value60 / 2, value61 / 2);
  value63.globalAlpha = 1;
  return value62.toBuffer("image/png");
}
async function generateCyberNeonLogo(value65) {
  const value66 = 800;
  const value67 = 400;
  const value68 = createCanvas(value66, value67);
  const value69 = value68.getContext("2d");
  value69.fillStyle = "#050510";
  value69.fillRect(0, 0, value66, value67);
  const value70 = ["#FF00FF", "#00FFFF", "#00FF00"];
  value69.textAlign = "center";
  value69.textBaseline = "middle";
  value69.font = "bold 80px \"Arial\"";
  for (let value71 = 0; value71 < value70.length; value71++) {
    const value72 = (value71 - 1) * 2;
    value69.shadowColor = value70[value71];
    value69.shadowBlur = 25;
    value69.fillStyle = value70[value71];
    value69.fillText(value65.toUpperCase(), value66 / 2 + value72, value67 / 2 + value72);
  }
  value69.shadowBlur = 0;
  value69.fillStyle = "#FFFFFF";
  value69.fillText(value65.toUpperCase(), value66 / 2, value67 / 2);
  return value68.toBuffer("image/png");
}
