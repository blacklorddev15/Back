const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "dragonlogo",
  description: "Create epic dragon text logos with fantasy and mystical effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🐉 *DRAGON LOGO*\n\n*dragonlogo*\ndragonlogo <text>\n\n*Example:*\ndragonlogo DRAGON\ndragonlogo FIRE\ndragonlogo WYVERN\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateDragonLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🐉 *Dragon Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [DRAGONLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateDragonLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createMysticalBackground(value16, value13, value14);
  const value17 = value13 * 0.7;
  const value18 = value14 * 0.4;
  drawEpicDragon(value16, value17, value18);
  addDragonFire(value16, value17, value18);
  addDragonScales(value16, value17, value18);
  addDragonWings(value16, value17, value18);
  drawDragonText(value16, value12, value13, value14);
  addMagicRunes(value16, value13, value14);
  addMysticalParticles(value16, value13, value14);
  addTreasurePile(value16, value13, value14);
  addFantasyElements(value16, value13, value14);
  drawDragonBorder(value16, value13, value14);
  addDragonSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createMysticalBackground(value19, value20, value21) {
  const value22 = value19.createLinearGradient(0, 0, 0, value21);
  value22.addColorStop(0, "#1a0a2a");
  value22.addColorStop(0.3, "#2d1b4e");
  value22.addColorStop(0.6, "#4a2c7a");
  value22.addColorStop(1, "#1a0a2a");
  value19.fillStyle = value22;
  value19.fillRect(0, 0, value20, value21);
  addMysticalMist(value19, value20, value21);
  addAncientRuins(value19, value20, value21);
}
function addMysticalMist(value23, value24, value25) {
  value23.save();
  value23.globalAlpha = 0.3;
  value23.globalCompositeOperation = "screen";
  const value26 = [{
    x: value24 * 0.2,
    y: value25 * 0.3,
    size: 120,
    color: [100, 50, 200]
  }, {
    x: value24 * 0.7,
    y: value25 * 0.2,
    size: 100,
    color: [200, 50, 100]
  }, {
    x: value24 * 0.4,
    y: value25 * 0.6,
    size: 110,
    color: [50, 150, 200]
  }, {
    x: value24 * 0.8,
    y: value25 * 0.7,
    size: 90,
    color: [200, 150, 50]
  }];
  value26.forEach(value27 => {
    const [value28, value29, value30] = value27.color;
    const value31 = value23.createRadialGradient(value27.x, value27.y, 0, value27.x, value27.y, value27.size);
    value31.addColorStop(0, "rgba(" + value28 + ", " + value29 + ", " + value30 + ", 0.6)");
    value31.addColorStop(1, "transparent");
    value23.fillStyle = value31;
    value23.beginPath();
    value23.arc(value27.x, value27.y, value27.size, 0, Math.PI * 2);
    value23.fill();
  });
  value23.restore();
}
function addAncientRuins(value32, value33, value34) {
  value32.save();
  value32.globalAlpha = 0.2;
  value32.strokeStyle = "rgba(150, 150, 200, 0.4)";
  value32.lineWidth = 2;
  for (let value35 = 0; value35 < 5; value35++) {
    const value36 = value33 * 0.1 + value35 * 80;
    const value37 = value34 * 0.6;
    const value38 = 80 + Math.random() * 40;
    value32.beginPath();
    value32.moveTo(value36, value37);
    value32.lineTo(value36, value37 - value38);
    value32.stroke();
    value32.beginPath();
    value32.arc(value36, value37 - value38, 8, 0, Math.PI * 2);
    value32.stroke();
  }
  value32.beginPath();
  value32.moveTo(value33 * 0.6, value34 * 0.7);
  value32.quadraticCurveTo(value33 * 0.7, value34 * 0.5, value33 * 0.8, value34 * 0.7);
  value32.stroke();
  value32.restore();
}
function drawEpicDragon(value39, value40, value41) {
  value39.save();
  const value42 = value39.createLinearGradient(value40 - 50, value41, value40 + 50, value41);
  value42.addColorStop(0, "#8B0000");
  value42.addColorStop(0.5, "#B22222");
  value42.addColorStop(1, "#DC143C");
  value39.strokeStyle = value42;
  value39.lineWidth = 15;
  value39.lineCap = "round";
  value39.lineJoin = "round";
  value39.beginPath();
  value39.moveTo(value40 - 80, value41 + 20);
  value39.bezierCurveTo(value40 - 40, value41 - 30, value40 + 20, value41 - 20, value40 + 60, value41 + 10);
  value39.stroke();
  value39.beginPath();
  value39.moveTo(value40 + 60, value41 + 10);
  value39.bezierCurveTo(value40 + 80, value41 - 10, value40 + 100, value41 - 5, value40 + 110, value41 + 15);
  value39.stroke();
  drawDragonHead(value39, value40 + 110, value41 + 15);
  drawDragonLegs(value39, value40, value41);
  drawDragonTail(value39, value40 - 80, value41 + 20);
  value39.restore();
}
function drawDragonHead(value43, value44, value45) {
  value43.fillStyle = "#B22222";
  value43.beginPath();
  value43.ellipse(value44, value45, 20, 15, 0, 0, Math.PI * 2);
  value43.fill();
  value43.fillStyle = "#8B0000";
  value43.beginPath();
  value43.ellipse(value44 + 15, value45, 10, 8, 0, 0, Math.PI * 2);
  value43.fill();
  value43.strokeStyle = "#FFD700";
  value43.lineWidth = 3;
  value43.lineCap = "round";
  value43.beginPath();
  value43.moveTo(value44 - 5, value45 - 12);
  value43.lineTo(value44 - 15, value45 - 25);
  value43.stroke();
  value43.beginPath();
  value43.moveTo(value44 + 5, value45 - 12);
  value43.lineTo(value44 + 15, value45 - 25);
  value43.stroke();
  value43.fillStyle = "#FF4500";
  value43.beginPath();
  value43.arc(value44 - 5, value45 - 5, 4, 0, Math.PI * 2);
  value43.fill();
  value43.fillStyle = "#FFFF00";
  value43.beginPath();
  value43.arc(value44 - 5, value45 - 5, 2, 0, Math.PI * 2);
  value43.fill();
  value43.fillStyle = "#8B0000";
  value43.beginPath();
  value43.arc(value44 + 20, value45 - 2, 2, 0, Math.PI * 2);
  value43.fill();
  value43.beginPath();
  value43.arc(value44 + 20, value45 + 2, 2, 0, Math.PI * 2);
  value43.fill();
}
function drawDragonLegs(value46, value47, value48) {
  value46.strokeStyle = "#B22222";
  value46.lineWidth = 8;
  value46.lineCap = "round";
  value46.beginPath();
  value46.moveTo(value47 + 20, value48 + 5);
  value46.lineTo(value47 + 25, value48 + 30);
  value46.stroke();
  value46.beginPath();
  value46.moveTo(value47 + 40, value48 + 8);
  value46.lineTo(value47 + 45, value48 + 35);
  value46.stroke();
  value46.beginPath();
  value46.moveTo(value47 - 40, value48 + 15);
  value46.lineTo(value47 - 35, value48 + 40);
  value46.stroke();
  value46.beginPath();
  value46.moveTo(value47 - 20, value48 + 18);
  value46.lineTo(value47 - 15, value48 + 45);
  value46.stroke();
  value46.strokeStyle = "#FFD700";
  value46.lineWidth = 2;
  const value49 = [{
    x: value47 + 25,
    y: value48 + 30
  }, {
    x: value47 + 45,
    y: value48 + 35
  }, {
    x: value47 - 35,
    y: value48 + 40
  }, {
    x: value47 - 15,
    y: value48 + 45
  }];
  value49.forEach(value50 => {
    for (let value51 = 0; value51 < 3; value51++) {
      const value52 = -0.5 + value51 * 0.5;
      const value53 = 8;
      value46.beginPath();
      value46.moveTo(value50.x, value50.y);
      value46.lineTo(value50.x + Math.cos(value52) * value53, value50.y + Math.sin(value52) * value53);
      value46.stroke();
    }
  });
}
function drawDragonTail(value54, value55, value56) {
  value54.strokeStyle = "#B22222";
  value54.lineWidth = 12;
  value54.lineCap = "round";
  value54.beginPath();
  value54.moveTo(value55, value56);
  value54.bezierCurveTo(value55 - 40, value56 + 20, value55 - 60, value56 - 10, value55 - 80, value56 + 5);
  value54.stroke();
  value54.strokeStyle = "#FFD700";
  value54.lineWidth = 4;
  value54.beginPath();
  value54.moveTo(value55 - 80, value56 + 5);
  value54.lineTo(value55 - 95, value56 - 5);
  value54.stroke();
}
function addDragonWings(value57, value58, value59) {
  value57.save();
  value57.globalAlpha = 0.8;
  const value60 = value57.createLinearGradient(value58 - 10, value59 - 20, value58 - 60, value59 - 50);
  value60.addColorStop(0, "rgba(139, 0, 0, 0.9)");
  value60.addColorStop(1, "rgba(178, 34, 34, 0.6)");
  value57.fillStyle = value60;
  value57.beginPath();
  value57.moveTo(value58 - 10, value59 - 20);
  value57.lineTo(value58 - 40, value59 - 60);
  value57.lineTo(value58 - 60, value59 - 30);
  value57.lineTo(value58 - 30, value59 - 10);
  value57.closePath();
  value57.fill();
  value57.strokeStyle = "rgba(160, 40, 40, 0.8)";
  value57.lineWidth = 2;
  value57.beginPath();
  value57.moveTo(value58 - 10, value59 - 20);
  value57.lineTo(value58 - 35, value59 - 45);
  value57.stroke();
  value57.beginPath();
  value57.moveTo(value58 - 15, value59 - 18);
  value57.lineTo(value58 - 45, value59 - 35);
  value57.stroke();
  value57.fillStyle = value60;
  value57.beginPath();
  value57.moveTo(value58 + 5, value59 - 15);
  value57.lineTo(value58 + 25, value59 - 55);
  value57.lineTo(value58 + 45, value59 - 25);
  value57.lineTo(value58 + 20, value59 - 5);
  value57.closePath();
  value57.fill();
  value57.restore();
}
function addDragonScales(value61, value62, value63) {
  value61.save();
  value61.globalAlpha = 0.7;
  const value64 = [{
    x: value62 - 60,
    y: value63 + 5
  }, {
    x: value62 - 40,
    y: value63 - 5
  }, {
    x: value62 - 20,
    y: value63 + 8
  }, {
    x: value62,
    y: value63 - 2
  }, {
    x: value62 + 20,
    y: value63 + 6
  }, {
    x: value62 + 40,
    y: value63 - 3
  }];
  value64.forEach(value65 => {
    value61.fillStyle = "#FF8C00";
    value61.beginPath();
    value61.ellipse(value65.x, value65.y, 6, 4, 0, 0, Math.PI * 2);
    value61.fill();
    value61.fillStyle = "#FFD700";
    value61.beginPath();
    value61.ellipse(value65.x - 2, value65.y - 1, 2, 1, 0, 0, Math.PI * 2);
    value61.fill();
  });
  value61.restore();
}
function addDragonFire(value66, value67, value68) {
  value66.save();
  value66.globalCompositeOperation = "screen";
  const value69 = value67 + 120;
  const value70 = value68 + 10;
  const value71 = value66.createLinearGradient(value69, value70, value69 - 100, value70);
  value71.addColorStop(0, "#FFFF00");
  value71.addColorStop(0.3, "#FF4500");
  value71.addColorStop(0.7, "#DC143C");
  value71.addColorStop(1, "#8B0000");
  value66.strokeStyle = value71;
  value66.lineWidth = 12;
  value66.lineCap = "round";
  value66.beginPath();
  value66.moveTo(value69, value70);
  value66.bezierCurveTo(value69 - 50, value70 - 20, value69 - 80, value70 + 10, value69 - 120, value70 - 5);
  value66.stroke();
  for (let value72 = 0; value72 < 3; value72++) {
    const value73 = (Math.random() - 0.5) * 30;
    value66.beginPath();
    value66.moveTo(value69, value70);
    value66.bezierCurveTo(value69 - 40, value70 - 15 + value73, value69 - 70, value70 + 5 + value73, value69 - 100, value70 - 10 + value73);
    value66.stroke();
  }
  value66.strokeStyle = "rgba(255, 200, 0, 0.4)";
  value66.lineWidth = 25;
  value66.beginPath();
  value66.moveTo(value69, value70);
  value66.bezierCurveTo(value69 - 50, value70 - 20, value69 - 80, value70 + 10, value69 - 120, value70 - 5);
  value66.stroke();
  addFireSparks(value66, value69 - 60, value70);
  value66.restore();
}
function addFireSparks(value74, value75, value76) {
  value74.save();
  value74.globalCompositeOperation = "screen";
  for (let value77 = 0; value77 < 15; value77++) {
    const value78 = value75 + (Math.random() - 0.5) * 80;
    const value79 = value76 + (Math.random() - 0.5) * 40;
    const value80 = 1 + Math.random() * 4;
    const value81 = 0.3 + Math.random() * 0.7;
    value74.fillStyle = "rgba(255, 255, 200, " + value81 + ")";
    value74.beginPath();
    value74.arc(value78, value79, value80, 0, Math.PI * 2);
    value74.fill();
    const value82 = 5 + Math.random() * 10;
    const value83 = Math.random() * Math.PI * 2;
    value74.strokeStyle = "rgba(255, 200, 100, " + value81 * 0.5 + ")";
    value74.lineWidth = value80 * 0.5;
    value74.lineCap = "round";
    value74.beginPath();
    value74.moveTo(value78, value79);
    value74.lineTo(value78 + Math.cos(value83) * value82, value79 + Math.sin(value83) * value82);
    value74.stroke();
  }
  value74.restore();
}
function drawDragonText(value84, value85, value86, value87) {
  const value88 = value86 * 0.35;
  const value89 = value87 * 0.6;
  value84.save();
  value84.shadowColor = "rgba(0, 0, 0, 0.7)";
  value84.shadowBlur = 15;
  value84.shadowOffsetX = 5;
  value84.shadowOffsetY = 5;
  const value90 = value84.createLinearGradient(value88 - 100, value89 - 50, value88 + 100, value89 + 50);
  value90.addColorStop(0, "#FFD700");
  value90.addColorStop(0.3, "#FF8C00");
  value90.addColorStop(0.7, "#B22222");
  value90.addColorStop(1, "#8B0000");
  value84.font = "bold 68px \"Arial\"";
  value84.textAlign = "center";
  value84.textBaseline = "middle";
  value84.fillStyle = value90;
  value84.fillText(value85.toUpperCase(), value88, value89);
  value84.shadowColor = "transparent";
  value84.shadowBlur = 0;
  value84.shadowOffsetX = 0;
  value84.shadowOffsetY = 0;
  value84.strokeStyle = "rgba(255, 215, 0, 0.8)";
  value84.lineWidth = 3;
  value84.strokeText(value85.toUpperCase(), value88, value89);
  addTextScaleTexture(value84, value85, value88, value89);
  value84.restore();
}
function addTextScaleTexture(value91, value92, value93, value94) {
  value91.save();
  value91.globalCompositeOperation = "overlay";
  value91.globalAlpha = 0.3;
  const value95 = value91.measureText(value92.toUpperCase());
  const value96 = value95.width;
  const value97 = 68;
  for (let value98 = value93 - value96 / 2; value98 < value93 + value96 / 2; value98 += 12) {
    for (let value99 = value94 - value97 / 2; value99 < value94 + value97 / 2; value99 += 10) {
      if (Math.random() > 0.7) {
        value91.fillStyle = "rgba(255, 215, 0, 0.4)";
        value91.beginPath();
        value91.ellipse(value98, value99, 4, 2, 0, 0, Math.PI * 2);
        value91.fill();
      }
    }
  }
  value91.restore();
}
function addMagicRunes(value100, value101, value102) {
  value100.save();
  value100.globalAlpha = 0.6;
  value100.strokeStyle = "rgba(100, 200, 255, 0.8)";
  value100.lineWidth = 2;
  const value103 = [{
    x: value101 * 0.2,
    y: value102 * 0.3
  }, {
    x: value101 * 0.8,
    y: value102 * 0.2
  }, {
    x: value101 * 0.3,
    y: value102 * 0.8
  }, {
    x: value101 * 0.7,
    y: value102 * 0.7
  }];
  value103.forEach(value104 => {
    value100.beginPath();
    value100.arc(value104.x, value104.y, 15, 0, Math.PI * 2);
    value100.stroke();
    value100.beginPath();
    value100.moveTo(value104.x - 8, value104.y - 8);
    value100.lineTo(value104.x + 8, value104.y + 8);
    value100.stroke();
    value100.beginPath();
    value100.moveTo(value104.x + 8, value104.y - 8);
    value100.lineTo(value104.x - 8, value104.y + 8);
    value100.stroke();
    value100.strokeStyle = "rgba(150, 220, 255, 0.4)";
    value100.lineWidth = 8;
    value100.beginPath();
    value100.arc(value104.x, value104.y, 20, 0, Math.PI * 2);
    value100.stroke();
    value100.strokeStyle = "rgba(100, 200, 255, 0.8)";
    value100.lineWidth = 2;
  });
  value100.restore();
}
function addMysticalParticles(value105, value106, value107) {
  value105.save();
  value105.globalCompositeOperation = "screen";
  for (let value108 = 0; value108 < 40; value108++) {
    const value109 = Math.random() * value106;
    const value110 = Math.random() * value107;
    const value111 = 1 + Math.random() * 4;
    const value112 = 200 + Math.random() * 160;
    value105.fillStyle = "hsla(" + value112 + ", 100%, 70%, 0.7)";
    value105.beginPath();
    value105.arc(value109, value110, value111, 0, Math.PI * 2);
    value105.fill();
    value105.fillStyle = "hsla(" + value112 + ", 100%, 70%, 0.3)";
    value105.beginPath();
    value105.arc(value109, value110, value111 * 2, 0, Math.PI * 2);
    value105.fill();
  }
  value105.restore();
}
function addTreasurePile(value113, value114, value115) {
  value113.save();
  value113.globalAlpha = 0.8;
  const value116 = value114 * 0.2;
  const value117 = value115 * 0.8;
  for (let value118 = 0; value118 < 20; value118++) {
    const value119 = value116 + (Math.random() - 0.5) * 60;
    const value120 = value117 + (Math.random() - 0.5) * 30;
    const value121 = 3 + Math.random() * 5;
    value113.fillStyle = "#FFD700";
    value113.beginPath();
    value113.arc(value119, value120, value121, 0, Math.PI * 2);
    value113.fill();
    value113.fillStyle = "#FFFF00";
    value113.beginPath();
    value113.arc(value119 - value121 * 0.3, value120 - value121 * 0.3, value121 * 0.5, 0, Math.PI * 2);
    value113.fill();
  }
  const value122 = ["#FF0000", "#00FF00", "#0000FF", "#FF00FF"];
  for (let value123 = 0; value123 < 5; value123++) {
    const value124 = value116 + (Math.random() - 0.5) * 50;
    const value125 = value117 + (Math.random() - 0.5) * 20;
    const value126 = 4 + Math.random() * 3;
    const value127 = value122[Math.floor(Math.random() * value122.length)];
    value113.fillStyle = value127;
    value113.beginPath();
    value113.moveTo(value124, value125 - value126);
    value113.lineTo(value124 + value126, value125);
    value113.lineTo(value124, value125 + value126);
    value113.lineTo(value124 - value126, value125);
    value113.closePath();
    value113.fill();
    value113.fillStyle = "#FFFFFF";
    value113.beginPath();
    value113.moveTo(value124 - value126 * 0.3, value125 - value126 * 0.3);
    value113.lineTo(value124, value125 - value126 * 0.1);
    value113.lineTo(value124 - value126 * 0.1, value125);
    value113.closePath();
    value113.fill();
  }
  value113.restore();
}
function addFantasyElements(value128, value129, value130) {
  value128.save();
  value128.globalAlpha = 0.4;
  value128.strokeStyle = "rgba(100, 100, 150, 0.6)";
  value128.lineWidth = 3;
  for (let value131 = 0; value131 < 5; value131++) {
    const value132 = value131 * 60;
    const value133 = 30 + Math.random() * 20;
    value128.beginPath();
    value128.moveTo(value132, value130 * 0.7);
    value128.lineTo(value132 + 30, value130 * 0.7 - value133);
    value128.lineTo(value132 + 60, value130 * 0.7);
    value128.stroke();
  }
  value128.restore();
}
function drawDragonBorder(value134, value135, value136) {
  value134.save();
  const value137 = value134.createLinearGradient(0, 0, value135, 0);
  value137.addColorStop(0, "#8B0000");
  value137.addColorStop(0.3, "#B22222");
  value137.addColorStop(0.5, "#FF8C00");
  value137.addColorStop(0.7, "#B22222");
  value137.addColorStop(1, "#8B0000");
  value134.strokeStyle = value137;
  value134.lineWidth = 10;
  value134.shadowColor = "rgba(255, 100, 0, 0.6)";
  value134.shadowBlur = 20;
  value134.strokeRect(10, 10, value135 - 20, value136 - 20);
  value134.strokeStyle = "rgba(255, 215, 0, 0.6)";
  value134.lineWidth = 3;
  value134.shadowBlur = 15;
  value134.strokeRect(20, 20, value135 - 40, value136 - 40);
  addDragonClawMarks(value134, value135, value136);
  value134.restore();
}
function addDragonClawMarks(value138, value139, value140) {
  value138.save();
  value138.strokeStyle = "rgba(255, 215, 0, 0.8)";
  value138.lineWidth = 2;
  value138.lineCap = "round";
  const value141 = [{
    x: 25,
    y: 25
  }, {
    x: value139 - 25,
    y: 25
  }, {
    x: 25,
    y: value140 - 25
  }, {
    x: value139 - 25,
    y: value140 - 25
  }];
  value141.forEach(value142 => {
    for (let value143 = 0; value143 < 3; value143++) {
      const value144 = -0.3 + value143 * 0.3;
      const value145 = 15;
      value138.beginPath();
      value138.moveTo(value142.x, value142.y);
      value138.lineTo(value142.x + Math.cos(value144) * value145, value142.y + Math.sin(value144) * value145);
      value138.stroke();
    }
  });
  value138.restore();
}
function addDragonSignature(value146, value147, value148) {
  value146.save();
  const value149 = value147 - 110;
  const value150 = value148 - 25;
  value146.font = "italic 14px \"Arial\"";
  value146.fillStyle = "rgba(255, 215, 0, 0.9)";
  value146.textAlign = "right";
  value146.textBaseline = "bottom";
  value146.shadowColor = "rgba(255, 100, 0, 0.6)";
  value146.shadowBlur = 10;
  value146.fillText("by " + getBotName(), value149, value150);
  value146.fillStyle = "#FF8C00";
  value146.beginPath();
  value146.ellipse(value149 + 5, value150 - 8, 6, 3, 0, 0, Math.PI * 2);
  value146.fill();
  value146.fillStyle = "#FFD700";
  value146.beginPath();
  value146.ellipse(value149 + 3, value150 - 9, 2, 1, 0, 0, Math.PI * 2);
  value146.fill();
  value146.restore();
}
