const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "titaniumlogo",
  description: "Create premium titanium metallic text logos with anodized effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🔘 *TITANIUM LOGO*\n\n*titaniumlogo*\ntitaniumlogo <text>\n\n*Example:*\ntitaniumlogo WOLF\ntitaniumlogo TITANIUM\ntitaniumlogo ELITE\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateTitaniumLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🔘 *Titanium Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [TITANIUMLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateTitaniumLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#0a0a14";
  value16.fillRect(0, 0, value13, value14);
  drawTitaniumBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 100, 0, 300);
  value17.addColorStop(0, "#E8E8E8");
  value17.addColorStop(0.15, "#D0D0D0");
  value17.addColorStop(0.3, "#B0B0B0");
  value17.addColorStop(0.45, "#909090");
  value17.addColorStop(0.6, "#707070");
  value17.addColorStop(0.75, "#505050");
  value17.addColorStop(0.9, "#383838");
  value17.addColorStop(1, "#202020");
  value16.font = "bold 86px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createTitanium3DEffect(value16, value12, value13, value14, value17);
  addTitaniumHighlights(value16, value12, value13, value14);
  addAnodizedEffects(value16, value12, value13, value14);
  drawTitaniumBorder(value16, value13, value14);
  addBrushedTexture(value16, value13, value14);
  addSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawTitaniumBackground(value18, value19, value20) {
  const value21 = value18.createRadialGradient(value19 / 2, value20 / 2, 0, value19 / 2, value20 / 2, Math.max(value19, value20) / 1.5);
  value21.addColorStop(0, "#1a1a2e");
  value21.addColorStop(0.4, "#0f0f23");
  value21.addColorStop(0.8, "#050514");
  value21.addColorStop(1, "#000005");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  value18.strokeStyle = "rgba(80, 100, 120, 0.1)";
  value18.lineWidth = 1;
  const value22 = 30;
  for (let value23 = -value22; value23 < value19 + value22; value23 += value22 * 1.5) {
    for (let value24 = -value22; value24 < value20 + value22; value24 += value22 * Math.sqrt(3)) {
      drawHexagon(value18, value23 + (value24 % (value22 * Math.sqrt(3)) > value22 * Math.sqrt(3) / 2 ? value22 * 0.75 : 0), value24, value22);
    }
  }
  drawPrecisionCorners(value18, value19, value20);
}
function drawHexagon(value25, value26, value27, value28) {
  value25.beginPath();
  for (let value29 = 0; value29 < 6; value29++) {
    const value30 = value29 * Math.PI / 3;
    const value31 = value26 + value28 * Math.cos(value30);
    const value32 = value27 + value28 * Math.sin(value30);
    if (value29 === 0) {
      value25.moveTo(value31, value32);
    } else {
      value25.lineTo(value31, value32);
    }
  }
  value25.closePath();
  value25.stroke();
}
function createTitanium3DEffect(value33, value34, value35, value36, value37) {
  const value38 = value35 / 2;
  const value39 = value36 / 2;
  const value40 = 10;
  for (let value41 = value40; value41 > 0; value41--) {
    const value42 = value41 * 1.2;
    const value43 = 0.06 + value41 / value40 * 0.2;
    value33.fillStyle = "rgba(0, 0, 0, " + value43 + ")";
    value33.fillText(value34.toUpperCase(), value38 + value42, value39 + value42);
  }
  value33.shadowColor = "rgba(100, 120, 140, 0.3)";
  value33.shadowBlur = 12;
  value33.fillStyle = value37;
  value33.fillText(value34.toUpperCase(), value38, value39);
  value33.shadowColor = "transparent";
  value33.shadowBlur = 0;
  value33.strokeStyle = "rgba(180, 200, 220, 0.4)";
  value33.lineWidth = 1.2;
  value33.strokeText(value34.toUpperCase(), value38, value39);
}
function addTitaniumHighlights(value44, value45, value46, value47) {
  const value48 = value46 / 2;
  const value49 = value47 / 2;
  value44.save();
  const value50 = value44.createLinearGradient(value48 - 250, value49 - 60, value48 + 250, value49 - 15);
  value50.addColorStop(0, "rgba(240, 240, 255, 0)");
  value50.addColorStop(0.3, "rgba(240, 240, 255, 0.8)");
  value50.addColorStop(0.5, "rgba(255, 255, 255, 0.9)");
  value50.addColorStop(0.7, "rgba(240, 240, 255, 0.7)");
  value50.addColorStop(1, "rgba(240, 240, 255, 0)");
  value44.globalCompositeOperation = "screen";
  value44.fillStyle = value50;
  value44.font = "bold 86px \"Arial\"";
  value44.textAlign = "center";
  value44.textBaseline = "middle";
  value44.fillText(value45.toUpperCase(), value48, value49 - 2);
  value44.globalCompositeOperation = "source-over";
  const value51 = value44.measureText(value45.toUpperCase()).width;
  const value52 = [{
    x: -0.35,
    y: -0.35,
    size: 4,
    alpha: 0.9
  }, {
    x: -0.18,
    y: -0.42,
    size: 5,
    alpha: 0.95
  }, {
    x: 0,
    y: -0.38,
    size: 4,
    alpha: 0.9
  }, {
    x: 0.18,
    y: -0.42,
    size: 5,
    alpha: 0.95
  }, {
    x: 0.35,
    y: -0.35,
    size: 4,
    alpha: 0.9
  }];
  value52.forEach(value53 => {
    const value54 = value48 + value53.x * value51 / 2;
    const value55 = value49 + value53.y * 48;
    value44.fillStyle = "rgba(255, 255, 255, " + value53.alpha + ")";
    value44.beginPath();
    value44.arc(value54, value55, value53.size, 0, Math.PI * 2);
    value44.fill();
    value44.shadowColor = "rgba(200, 220, 255, 0.6)";
    value44.shadowBlur = 8;
    value44.fill();
  });
  value44.restore();
}
function addAnodizedEffects(value56, value57, value58, value59) {
  const value60 = value58 / 2;
  const value61 = value59 / 2;
  value56.save();
  value56.globalCompositeOperation = "overlay";
  const value62 = value56.createLinearGradient(value60 - 200, value61 + 20, value60 + 200, value61 - 30);
  value62.addColorStop(0, "rgba(100, 150, 255, 0.2)");
  value62.addColorStop(0.5, "rgba(150, 100, 255, 0.25)");
  value62.addColorStop(1, "rgba(100, 200, 255, 0.2)");
  value56.fillStyle = value62;
  value56.font = "bold 86px \"Arial\"";
  value56.textAlign = "center";
  value56.textBaseline = "middle";
  value56.fillText(value57.toUpperCase(), value60, value61);
  value56.globalCompositeOperation = "screen";
  const value63 = value56.measureText(value57.toUpperCase()).width;
  const value64 = [{
    x: -0.25,
    y: 0.15,
    size: 6,
    color: "rgba(255, 100, 100, 0.3)"
  }, {
    x: -0.1,
    y: 0.25,
    size: 5,
    color: "rgba(255, 200, 100, 0.25)"
  }, {
    x: 0.1,
    y: 0.15,
    size: 7,
    color: "rgba(100, 255, 100, 0.35)"
  }, {
    x: 0.25,
    y: 0.25,
    size: 4,
    color: "rgba(100, 200, 255, 0.3)"
  }];
  value64.forEach(value65 => {
    const value66 = value60 + value65.x * value63 / 2;
    const value67 = value61 + value65.y * 35;
    const value68 = value56.createRadialGradient(value66, value67, 0, value66, value67, value65.size * 2);
    value68.addColorStop(0, value65.color);
    value68.addColorStop(1, "transparent");
    value56.fillStyle = value68;
    value56.beginPath();
    value56.arc(value66, value67, value65.size * 2, 0, Math.PI * 2);
    value56.fill();
  });
  value56.restore();
}
function drawTitaniumBorder(value69, value70, value71) {
  const value72 = value69.createLinearGradient(0, 0, value70, value71);
  value72.addColorStop(0, "#E8E8E8");
  value72.addColorStop(0.25, "#C8C8C8");
  value72.addColorStop(0.5, "#A8A8A8");
  value72.addColorStop(0.75, "#C8C8C8");
  value72.addColorStop(1, "#E8E8E8");
  value69.strokeStyle = value72;
  value69.lineWidth = 7;
  value69.shadowColor = "rgba(100, 120, 140, 0.4)";
  value69.shadowBlur = 18;
  value69.strokeRect(16, 16, value70 - 32, value71 - 32);
  value69.strokeStyle = "rgba(180, 200, 220, 0.5)";
  value69.lineWidth = 2;
  value69.shadowBlur = 0;
  value69.strokeRect(28, 28, value70 - 56, value71 - 56);
  value69.strokeStyle = "rgba(100, 150, 255, 0.3)";
  value69.lineWidth = 1;
  value69.strokeRect(36, 36, value70 - 72, value71 - 72);
  drawAerospaceFasteners(value69, value70, value71);
}
function drawAerospaceFasteners(value73, value74, value75) {
  value73.fillStyle = "#B0B0B0";
  const value76 = [{
    x: 35,
    y: 35
  }, {
    x: value74 - 35,
    y: 35
  }, {
    x: 35,
    y: value75 - 35
  }, {
    x: value74 - 35,
    y: value75 - 35
  }, {
    x: value74 / 2,
    y: 35
  }, {
    x: value74 / 2,
    y: value75 - 35
  }, {
    x: 35,
    y: value75 / 2
  }, {
    x: value74 - 35,
    y: value75 / 2
  }];
  value76.forEach(value77 => {
    value73.save();
    value73.translate(value77.x, value77.y);
    value73.rotate(Math.PI / 6);
    value73.beginPath();
    for (let value78 = 0; value78 < 6; value78++) {
      const value79 = value78 * Math.PI / 3;
      const value80 = Math.cos(value79) * 4;
      const value81 = Math.sin(value79) * 4;
      if (value78 === 0) {
        value73.moveTo(value80, value81);
      } else {
        value73.lineTo(value80, value81);
      }
    }
    value73.closePath();
    value73.fill();
    value73.fillStyle = "rgba(255, 255, 255, 0.6)";
    value73.beginPath();
    value73.arc(0, 0, 1.5, 0, Math.PI * 2);
    value73.fill();
    value73.restore();
    value73.fillStyle = "#B0B0B0";
  });
}
function addBrushedTexture(value82, value83, value84) {
  value82.save();
  value82.globalAlpha = 0.15;
  value82.strokeStyle = "rgba(255, 255, 255, 0.3)";
  value82.lineWidth = 0.8;
  for (let value85 = 0; value85 < value84; value85 += 2) {
    value82.beginPath();
    value82.moveTo(0, value85);
    value82.lineTo(value83, value85);
    value82.stroke();
  }
  for (let value86 = 0; value86 < 30; value86++) {
    const value87 = Math.random() * value83;
    const value88 = Math.random() * value84;
    const value89 = 5 + Math.random() * 15;
    value82.strokeStyle = "rgba(150, 150, 150, 0.4)";
    value82.lineWidth = 0.5;
    value82.beginPath();
    value82.moveTo(value87, value88);
    value82.lineTo(value87 + value89, value88);
    value82.stroke();
  }
  value82.restore();
}
function drawPrecisionCorners(value90, value91, value92) {
  value90.strokeStyle = "rgba(120, 140, 160, 0.4)";
  value90.lineWidth = 2;
  const value93 = 20;
  const value94 = 8;
  value90.beginPath();
  value90.moveTo(25, 25 + value93);
  value90.lineTo(25, 25 + value94);
  value90.moveTo(25, 25);
  value90.lineTo(25 + value94, 25);
  value90.stroke();
  value90.beginPath();
  value90.moveTo(value91 - 25, 25 + value93);
  value90.lineTo(value91 - 25, 25 + value94);
  value90.moveTo(value91 - 25, 25);
  value90.lineTo(value91 - 25 - value94, 25);
  value90.stroke();
  value90.beginPath();
  value90.moveTo(25, value92 - 25 - value93);
  value90.lineTo(25, value92 - 25 - value94);
  value90.moveTo(25, value92 - 25);
  value90.lineTo(25 + value94, value92 - 25);
  value90.stroke();
  value90.beginPath();
  value90.moveTo(value91 - 25, value92 - 25 - value93);
  value90.lineTo(value91 - 25, value92 - 25 - value94);
  value90.moveTo(value91 - 25, value92 - 25);
  value90.lineTo(value91 - 25 - value94, value92 - 25);
  value90.stroke();
}
function addSignature(value95, value96, value97) {
  value95.save();
  const value98 = value96 - 120;
  const value99 = value97 - 20;
  value95.font = "italic 12px \"Arial\"";
  value95.fillStyle = "rgba(160, 180, 200, 0.7)";
  value95.textAlign = "right";
  value95.textBaseline = "bottom";
  value95.fillText("by " + getBotName(), value98, value99);
  value95.strokeStyle = "rgba(160, 180, 200, 0.4)";
  value95.lineWidth = 0.5;
  const value100 = value95.measureText("by " + getBotName()).width;
  value95.beginPath();
  value95.moveTo(value98 - value100, value99 + 2);
  value95.lineTo(value98, value99 + 2);
  value95.stroke();
  value95.restore();
}
async function generateSimpleTitaniumLogo(value101) {
  const value102 = 600;
  const value103 = 300;
  const value104 = createCanvas(value102, value103);
  const value105 = value104.getContext("2d");
  value105.fillStyle = "#0a0a14";
  value105.fillRect(0, 0, value102, value103);
  const value106 = value105.createLinearGradient(0, 50, 0, 250);
  value106.addColorStop(0, "#E8E8E8");
  value106.addColorStop(0.4, "#C8C8C8");
  value106.addColorStop(0.7, "#A8A8A8");
  value106.addColorStop(1, "#888888");
  value105.font = "bold 72px Arial";
  value105.fillStyle = value106;
  value105.textAlign = "center";
  value105.textBaseline = "middle";
  value105.shadowColor = "rgba(100, 120, 140, 0.5)";
  value105.shadowBlur = 15;
  value105.shadowOffsetX = 4;
  value105.shadowOffsetY = 4;
  value105.fillText(value101.toUpperCase(), value102 / 2, value103 / 2);
  value105.strokeStyle = "#C8C8C8";
  value105.lineWidth = 5;
  value105.strokeRect(15, 15, value102 - 30, value103 - 30);
  value105.font = "italic 10px \"Arial\"";
  value105.fillStyle = "rgba(160, 180, 200, 0.7)";
  value105.textAlign = "right";
  value105.textBaseline = "bottom";
  value105.fillText("by " + getBotName(), value102 - 20, value103 - 15);
  return value104.toBuffer("image/png");
}
