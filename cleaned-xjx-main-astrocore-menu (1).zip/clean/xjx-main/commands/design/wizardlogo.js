const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "wizardlogo",
  description: "Create magical wizard text logos with spellcasting and mystical effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🧙‍♂️ *WIZARD LOGO*\n\n*wizardlogo*\nwizardlogo <text>\n\n*Example:*\nwizardlogo WIZARD\nwizardlogo MAGIC\nwizardlogo SPELL\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateWizardLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🧙‍♂️ *Wizard Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [WIZARDLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateWizardLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createWizardBackground(value16, value13, value14);
  const value17 = value13 * 0.75;
  const value18 = value14 * 0.55;
  drawWizardCharacter(value16, value17, value18);
  addMagicStaff(value16, value17, value18);
  addSpellCast(value16, value17, value18);
  addMagicCircles(value16, value17, value18);
  drawArcaneText(value16, value12, value13, value14);
  addMagicParticles(value16, value13, value14);
  addFloatingRunes(value16, value13, value14);
  addMysticalOrbs(value16, value13, value14);
  addSpellTrails(value16, value13, value14);
  drawArcaneBorder(value16, value13, value14);
  addWizardSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createWizardBackground(value19, value20, value21) {
  const value22 = value19.createLinearGradient(0, 0, 0, value21);
  value22.addColorStop(0, "#0a0020");
  value22.addColorStop(0.3, "#1a0040");
  value22.addColorStop(0.6, "#2d1b4e");
  value22.addColorStop(1, "#0a0020");
  value19.fillStyle = value22;
  value19.fillRect(0, 0, value20, value21);
  addStarfield(value19, value20, value21);
  addLibraryElements(value19, value20, value21);
}
function addStarfield(value23, value24, value25) {
  value23.save();
  value23.globalAlpha = 0.8;
  for (let value26 = 0; value26 < 150; value26++) {
    const value27 = Math.random() * value24;
    const value28 = Math.random() * value25;
    const value29 = Math.random() * 2;
    const value30 = 0.5 + Math.random() * 0.5;
    value23.fillStyle = "rgba(255, 255, 255, " + value30 + ")";
    value23.beginPath();
    value23.arc(value27, value28, value29, 0, Math.PI * 2);
    value23.fill();
  }
  for (let value31 = 0; value31 < 50; value31++) {
    const value32 = Math.random() * value24;
    const value33 = Math.random() * value25;
    const value34 = 1 + Math.random() * 3;
    const value35 = 240 + Math.random() * 120;
    value23.fillStyle = "hsla(" + value35 + ", 100%, 70%, 0.8)";
    value23.beginPath();
    value23.arc(value32, value33, value34, 0, Math.PI * 2);
    value23.fill();
    value23.fillStyle = "hsla(" + value35 + ", 100%, 70%, 0.3)";
    value23.beginPath();
    value23.arc(value32, value33, value34 * 2, 0, Math.PI * 2);
    value23.fill();
  }
  value23.restore();
}
function addLibraryElements(value36, value37, value38) {
  value36.save();
  value36.globalAlpha = 0.3;
  for (let value39 = 0; value39 < 8; value39++) {
    const value40 = value37 * 0.1 + value39 * 25;
    const value41 = value38 * 0.8;
    const value42 = 30 + Math.random() * 20;
    const value43 = 15;
    const value44 = "hsl(" + Math.random() * 360 + ", 50%, 40%)";
    value36.fillStyle = value44;
    value36.fillRect(value40, value41 - value42, value43, value42);
    value36.strokeStyle = "rgba(255, 255, 255, 0.5)";
    value36.lineWidth = 1;
    value36.strokeRect(value40, value41 - value42, value43, value42);
    value36.strokeStyle = "rgba(200, 200, 150, 0.6)";
    value36.beginPath();
    value36.moveTo(value40, value41 - value42 + 5);
    value36.lineTo(value40 + value43, value41 - value42 + 5);
    value36.stroke();
  }
  const value45 = value37 * 0.85;
  const value46 = value38 * 0.3;
  value36.fillStyle = "rgba(210, 180, 140, 0.6)";
  value36.fillRect(value45 - 20, value46 - 5, 40, 10);
  value36.fillStyle = "rgba(139, 69, 19, 0.8)";
  value36.beginPath();
  value36.ellipse(value45 - 20, value46, 3, 5, 0, 0, Math.PI * 2);
  value36.fill();
  value36.beginPath();
  value36.ellipse(value45 + 20, value46, 3, 5, 0, 0, Math.PI * 2);
  value36.fill();
  value36.restore();
}
function drawWizardCharacter(value47, value48, value49) {
  value47.save();
  const value50 = value47.createLinearGradient(value48, value49 - 40, value48, value49 + 40);
  value50.addColorStop(0, "#2d1b4e");
  value50.addColorStop(0.5, "#4a2c7a");
  value50.addColorStop(1, "#2d1b4e");
  value47.fillStyle = value50;
  value47.beginPath();
  value47.moveTo(value48 - 25, value49 - 20);
  value47.bezierCurveTo(value48 - 30, value49 + 30, value48 + 30, value49 + 30, value48 + 25, value49 - 20);
  value47.fill();
  value47.fillStyle = "rgba(210, 180, 140, 0.9)";
  value47.beginPath();
  value47.arc(value48, value49 - 30, 15, 0, Math.PI * 2);
  value47.fill();
  value47.fillStyle = "rgba(255, 255, 255, 0.9)";
  value47.beginPath();
  value47.moveTo(value48 - 12, value49 - 25);
  value47.bezierCurveTo(value48 - 15, value49 - 15, value48 + 15, value49 - 15, value48 + 12, value49 - 25);
  value47.bezierCurveTo(value48 + 8, value49 - 10, value48 - 8, value49 - 10, value48 - 12, value49 - 25);
  value47.fill();
  drawWizardHat(value47, value48, value49 - 45);
  value47.fillStyle = "rgba(210, 180, 140, 0.9)";
  value47.beginPath();
  value47.arc(value48 - 30, value49, 8, 0, Math.PI * 2);
  value47.fill();
  value47.beginPath();
  value47.arc(value48 + 30, value49, 8, 0, Math.PI * 2);
  value47.fill();
  value47.restore();
}
function drawWizardHat(value51, value52, value53) {
  value51.fillStyle = "#2d1b4e";
  value51.beginPath();
  value51.ellipse(value52, value53 + 5, 25, 8, 0, 0, Math.PI * 2);
  value51.fill();
  const value54 = value51.createLinearGradient(value52, value53 - 40, value52, value53 + 5);
  value54.addColorStop(0, "#4a2c7a");
  value54.addColorStop(1, "#2d1b4e");
  value51.fillStyle = value54;
  value51.beginPath();
  value51.moveTo(value52 - 20, value53 + 5);
  value51.lineTo(value52, value53 - 40);
  value51.lineTo(value52 + 20, value53 + 5);
  value51.closePath();
  value51.fill();
  value51.fillStyle = "rgba(255, 255, 200, 0.8)";
  for (let value55 = 0; value55 < 3; value55++) {
    const value56 = value52 - 10 + value55 * 10;
    const value57 = value53 - 20 + value55 * 5;
    value51.beginPath();
    value51.arc(value56, value57, 2, 0, Math.PI * 2);
    value51.fill();
  }
}
function addMagicStaff(value58, value59, value60) {
  value58.save();
  const value61 = value58.createLinearGradient(value59 - 50, value60 - 10, value59 - 50, value60 + 30);
  value61.addColorStop(0, "#8B4513");
  value61.addColorStop(1, "#654321");
  value58.strokeStyle = value61;
  value58.lineWidth = 6;
  value58.lineCap = "round";
  value58.beginPath();
  value58.moveTo(value59 - 50, value60 - 10);
  value58.lineTo(value59 - 50, value60 + 30);
  value58.stroke();
  const value62 = value58.createRadialGradient(value59 - 50, value60 - 15, 0, value59 - 50, value60 - 15, 12);
  value62.addColorStop(0, "rgba(100, 200, 255, 0.9)");
  value62.addColorStop(0.7, "rgba(50, 100, 200, 0.6)");
  value62.addColorStop(1, "rgba(0, 50, 150, 0.3)");
  value58.fillStyle = value62;
  value58.beginPath();
  value58.moveTo(value59 - 50, value60 - 25);
  value58.lineTo(value59 - 40, value60 - 15);
  value58.lineTo(value59 - 50, value60 - 5);
  value58.lineTo(value59 - 60, value60 - 15);
  value58.closePath();
  value58.fill();
  value58.fillStyle = "rgba(100, 200, 255, 0.3)";
  value58.beginPath();
  value58.arc(value59 - 50, value60 - 15, 15, 0, Math.PI * 2);
  value58.fill();
  value58.restore();
}
function addSpellCast(value63, value64, value65) {
  value63.save();
  value63.globalCompositeOperation = "screen";
  const value66 = value63.createLinearGradient(value64 - 50, value65 - 15, value64 - 150, value65 - 15);
  value66.addColorStop(0, "rgba(100, 200, 255, 0.9)");
  value66.addColorStop(0.5, "rgba(150, 100, 255, 0.6)");
  value66.addColorStop(1, "rgba(200, 50, 255, 0.3)");
  value63.strokeStyle = value66;
  value63.lineWidth = 8;
  value63.lineCap = "round";
  value63.beginPath();
  value63.moveTo(value64 - 50, value65 - 15);
  value63.lineTo(value64 - 150, value65 - 15);
  value63.stroke();
  value63.strokeStyle = "rgba(150, 200, 255, 0.4)";
  value63.lineWidth = 20;
  value63.beginPath();
  value63.moveTo(value64 - 50, value65 - 15);
  value63.lineTo(value64 - 150, value65 - 15);
  value63.stroke();
  const value67 = value63.createRadialGradient(value64 - 150, value65 - 15, 0, value64 - 150, value65 - 15, 30);
  value67.addColorStop(0, "rgba(255, 255, 255, 0.8)");
  value67.addColorStop(0.5, "rgba(150, 200, 255, 0.5)");
  value67.addColorStop(1, "transparent");
  value63.fillStyle = value67;
  value63.beginPath();
  value63.arc(value64 - 150, value65 - 15, 30, 0, Math.PI * 2);
  value63.fill();
  for (let value68 = 0; value68 < 15; value68++) {
    const value69 = Math.random();
    const value70 = value64 - 50 - value69 * 100;
    const value71 = value65 - 15 + (Math.random() - 0.5) * 20;
    const value72 = 1 + Math.random() * 3;
    const value73 = 200 + Math.random() * 160;
    value63.fillStyle = "hsla(" + value73 + ", 100%, 70%, 0.8)";
    value63.beginPath();
    value63.arc(value70, value71, value72, 0, Math.PI * 2);
    value63.fill();
  }
  value63.restore();
}
function addMagicCircles(value74, value75, value76) {
  value74.save();
  value74.globalAlpha = 0.6;
  const value77 = ["#64C8FF", "#9664FF", "#FF64C8"];
  value77.forEach((value78, value79) => {
    const value80 = 60 + value79 * 20;
    const value81 = 3 - value79;
    value74.strokeStyle = value78;
    value74.lineWidth = value81;
    value74.setLineDash([5, 5]);
    value74.beginPath();
    value74.arc(value75, value76, value80, 0, Math.PI * 2);
    value74.stroke();
    value74.setLineDash([]);
  });
  addCircleRunes(value74, value75, value76);
  value74.restore();
}
function addCircleRunes(value82, value83, value84) {
  value82.save();
  value82.globalAlpha = 0.8;
  const value85 = 8;
  const value86 = 80;
  for (let value87 = 0; value87 < value85; value87++) {
    const value88 = value87 / value85 * Math.PI * 2;
    const value89 = value83 + Math.cos(value88) * value86;
    const value90 = value84 + Math.sin(value88) * value86;
    value82.fillStyle = "rgba(100, 200, 255, 0.9)";
    value82.font = "bold 16px Arial";
    value82.textAlign = "center";
    value82.textBaseline = "middle";
    value82.fillText("*", value89, value90);
    value82.fillStyle = "rgba(100, 200, 255, 0.3)";
    value82.beginPath();
    value82.arc(value89, value90, 10, 0, Math.PI * 2);
    value82.fill();
  }
  value82.restore();
}
function drawArcaneText(value91, value92, value93, value94) {
  const value95 = value93 * 0.35;
  const value96 = value94 * 0.6;
  value91.save();
  value91.shadowColor = "rgba(100, 200, 255, 0.8)";
  value91.shadowBlur = 30;
  const value97 = value91.createLinearGradient(value95 - 100, value96 - 50, value95 + 100, value96 + 50);
  value97.addColorStop(0, "#64C8FF");
  value97.addColorStop(0.3, "#9664FF");
  value97.addColorStop(0.7, "#FF64C8");
  value97.addColorStop(1, "#64C8FF");
  value91.font = "bold 68px \"Arial\"";
  value91.textAlign = "center";
  value91.textBaseline = "middle";
  value91.fillStyle = value97;
  value91.fillText(value92.toUpperCase(), value95, value96);
  value91.shadowColor = "transparent";
  value91.fillStyle = "rgba(255, 255, 255, 0.6)";
  value91.fillText(value92.toUpperCase(), value95, value96);
  value91.strokeStyle = "rgba(200, 230, 255, 0.8)";
  value91.lineWidth = 2;
  value91.strokeText(value92.toUpperCase(), value95, value96);
  addTextRunes(value91, value92, value95, value96);
  value91.restore();
}
function addTextRunes(value98, value99, value100, value101) {
  value98.save();
  value98.globalCompositeOperation = "overlay";
  value98.globalAlpha = 0.3;
  const value102 = value98.measureText(value99.toUpperCase());
  const value103 = value102.width;
  const value104 = 68;
  for (let value105 = 0; value105 < 20; value105++) {
    const value106 = value100 - value103 / 2 + Math.random() * value103;
    const value107 = value101 - value104 / 2 + Math.random() * value104;
    const value108 = 1 + Math.random() * 3;
    const value109 = 200 + Math.random() * 160;
    value98.fillStyle = "hsla(" + value109 + ", 100%, 70%, 0.7)";
    value98.beginPath();
    value98.arc(value106, value107, value108, 0, Math.PI * 2);
    value98.fill();
  }
  value98.restore();
}
function addMagicParticles(value110, value111, value112) {
  value110.save();
  value110.globalCompositeOperation = "screen";
  for (let value113 = 0; value113 < 15; value113++) {
    const value114 = Math.random() * value111;
    const value115 = Math.random() * value112;
    const value116 = 4 + Math.random() * 8;
    const value117 = 200 + Math.random() * 160;
    const value118 = value110.createRadialGradient(value114, value115, 0, value114, value115, value116);
    value118.addColorStop(0, "hsla(" + value117 + ", 100%, 80%, 0.9)");
    value118.addColorStop(1, "hsla(" + value117 + ", 100%, 60%, 0.3)");
    value110.fillStyle = value118;
    value110.beginPath();
    value110.arc(value114, value115, value116, 0, Math.PI * 2);
    value110.fill();
    const value119 = 5 + Math.random() * 15;
    const value120 = Math.random() * Math.PI * 2;
    value110.strokeStyle = "hsla(" + value117 + ", 100%, 70%, 0.5)";
    value110.lineWidth = value116 * 0.5;
    value110.lineCap = "round";
    value110.beginPath();
    value110.moveTo(value114, value115);
    value110.lineTo(value114 + Math.cos(value120) * value119, value115 + Math.sin(value120) * value119);
    value110.stroke();
  }
  for (let value121 = 0; value121 < 40; value121++) {
    const value122 = Math.random() * value111;
    const value123 = Math.random() * value112;
    const value124 = 1 + Math.random() * 2;
    const value125 = 200 + Math.random() * 160;
    value110.fillStyle = "hsla(" + value125 + ", 100%, 80%, 0.9)";
    value110.beginPath();
    value110.arc(value122, value123, value124, 0, Math.PI * 2);
    value110.fill();
  }
  value110.restore();
}
function addFloatingRunes(value126, value127, value128) {
  value126.save();
  value126.globalAlpha = 0.6;
  const value129 = ["*", "+", "○", "□", "△"];
  for (let value130 = 0; value130 < 12; value130++) {
    const value131 = Math.random() * value127;
    const value132 = Math.random() * value128;
    const value133 = 8 + Math.random() * 6;
    const value134 = 200 + Math.random() * 160;
    const value135 = value129[Math.floor(Math.random() * value129.length)];
    value126.fillStyle = "hsla(" + value134 + ", 100%, 70%, 0.8)";
    value126.font = "bold " + value133 + "px Arial";
    value126.textAlign = "center";
    value126.textBaseline = "middle";
    value126.fillText(value135, value131, value132);
    value126.fillStyle = "hsla(" + value134 + ", 100%, 70%, 0.3)";
    value126.beginPath();
    value126.arc(value131, value132, value133, 0, Math.PI * 2);
    value126.fill();
  }
  value126.restore();
}
function addMysticalOrbs(value136, value137, value138) {
  value136.save();
  value136.globalCompositeOperation = "screen";
  value136.globalAlpha = 0.4;
  const value139 = [{
    x: value137 * 0.2,
    y: value138 * 0.3,
    size: 40,
    color: [100, 200, 255]
  }, {
    x: value137 * 0.8,
    y: value138 * 0.4,
    size: 35,
    color: [150, 100, 255]
  }, {
    x: value137 * 0.3,
    y: value138 * 0.7,
    size: 45,
    color: [255, 100, 200]
  }];
  value139.forEach(value140 => {
    const [value141, value142, value143] = value140.color;
    const value144 = value136.createRadialGradient(value140.x, value140.y, 0, value140.x, value140.y, value140.size);
    value144.addColorStop(0, "rgba(" + value141 + ", " + value142 + ", " + value143 + ", 0.7)");
    value144.addColorStop(1, "transparent");
    value136.fillStyle = value144;
    value136.beginPath();
    value136.arc(value140.x, value140.y, value140.size, 0, Math.PI * 2);
    value136.fill();
  });
  value136.restore();
}
function addSpellTrails(value145, value146, value147) {
  value145.save();
  value145.globalCompositeOperation = "screen";
  value145.globalAlpha = 0.2;
  for (let value148 = 0; value148 < 5; value148++) {
    const value149 = Math.random() * value146;
    const value150 = value147 + 20;
    const value151 = value149 + (Math.random() - 0.5) * 100;
    const value152 = Math.random() * value147 * 0.5;
    const value153 = 200 + Math.random() * 160;
    const value154 = value145.createLinearGradient(value149, value150, value151, value152);
    value154.addColorStop(0, "hsla(" + value153 + ", 100%, 70%, 0.6)");
    value154.addColorStop(1, "hsla(" + value153 + ", 100%, 50%, 0.2)");
    value145.strokeStyle = value154;
    value145.lineWidth = 6;
    value145.lineCap = "round";
    value145.beginPath();
    value145.moveTo(value149, value150);
    value145.lineTo(value151, value152);
    value145.stroke();
  }
  value145.restore();
}
function drawArcaneBorder(value155, value156, value157) {
  value155.save();
  const value158 = value155.createLinearGradient(0, 0, value156, 0);
  value158.addColorStop(0, "#64C8FF");
  value158.addColorStop(0.3, "#9664FF");
  value158.addColorStop(0.5, "#FF64C8");
  value158.addColorStop(0.7, "#9664FF");
  value158.addColorStop(1, "#64C8FF");
  value155.strokeStyle = value158;
  value155.lineWidth = 10;
  value155.shadowColor = "rgba(100, 200, 255, 0.6)";
  value155.shadowBlur = 20;
  value155.strokeRect(10, 10, value156 - 20, value157 - 20);
  value155.strokeStyle = "rgba(200, 230, 255, 0.6)";
  value155.lineWidth = 3;
  value155.shadowBlur = 15;
  value155.strokeRect(20, 20, value156 - 40, value157 - 40);
  addRunicCorners(value155, value156, value157);
  value155.restore();
}
function addRunicCorners(value159, value160, value161) {
  value159.save();
  value159.globalAlpha = 0.7;
  const value162 = [{
    x: 30,
    y: 30
  }, {
    x: value160 - 30,
    y: 30
  }, {
    x: 30,
    y: value161 - 30
  }, {
    x: value160 - 30,
    y: value161 - 30
  }];
  value162.forEach(value163 => {
    value159.strokeStyle = "rgba(100, 200, 255, 0.8)";
    value159.lineWidth = 2;
    value159.beginPath();
    value159.arc(value163.x, value163.y, 8, 0, Math.PI * 2);
    value159.stroke();
    value159.beginPath();
    value159.moveTo(value163.x - 5, value163.y);
    value159.lineTo(value163.x + 5, value163.y);
    value159.stroke();
    value159.beginPath();
    value159.moveTo(value163.x, value163.y - 5);
    value159.lineTo(value163.x, value163.y + 5);
    value159.stroke();
  });
  value159.restore();
}
function addWizardSignature(value164, value165, value166) {
  value164.save();
  const value167 = value165 - 110;
  const value168 = value166 - 25;
  value164.font = "italic 14px \"Arial\"";
  value164.fillStyle = "rgba(200, 230, 255, 0.9)";
  value164.textAlign = "right";
  value164.textBaseline = "bottom";
  value164.shadowColor = "rgba(100, 200, 255, 0.6)";
  value164.shadowBlur = 10;
  value164.fillText("by " + getBotName(), value167, value168);
  value164.fillStyle = "rgba(100, 200, 255, 0.8)";
  value164.font = "bold 12px Arial";
  value164.fillText("*", value167 + 5, value168 - 8);
  value164.fillStyle = "rgba(100, 200, 255, 0.3)";
  value164.beginPath();
  value164.arc(value167 + 5, value168 - 8, 6, 0, Math.PI * 2);
  value164.fill();
  value164.restore();
}
