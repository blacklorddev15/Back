const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "bloodlogo",
  category: "design",
  description: "Create terrifying blood text logos with realistic gore and horror effects",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🩸 *BLOOD LOGO*\n\n*bloodlogo*\nbloodlogo <text>\n\n*Example:*\nbloodlogo BLOOD\nbloodlogo GORE\nbloodlogo HORROR\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateAdvancedBloodLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🩸 *Advanced Blood Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [BLOODLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateAdvancedBloodLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createHorrorBackground(value16, value13, value14);
  const value17 = value13 * 0.5;
  const value18 = value14 * 0.5;
  drawAdvancedBloodText(value16, value12, value17, value18);
  addBloodSplatters(value16, value13, value14);
  addBloodSpatterPhysics(value16, value17, value18, value12);
  addGoreDetails(value16, value13, value14);
  addBloodPools(value16, value13, value14);
  addBloodyHandprints(value16, value13, value14);
  addWeaponMarks(value16, value13, value14);
  addBloodMist(value16, value13, value14);
  addBloodParticles(value16, value13, value14);
  addBloodLighting(value16, value13, value14);
  addHorrorShadows(value16, value13, value14);
  drawGoreBorder(value16, value13, value14);
  addBloodSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createHorrorBackground(value19, value20, value21) {
  const value22 = value19.createLinearGradient(0, 0, 0, value21);
  value22.addColorStop(0, "#2a0a0a");
  value22.addColorStop(0.3, "#3a0a0a");
  value22.addColorStop(0.6, "#4a0a0a");
  value22.addColorStop(1, "#2a0a0a");
  value19.fillStyle = value22;
  value19.fillRect(0, 0, value20, value21);
  addWallTexture(value19, value20, value21);
  addBloodStains(value19, value20, value21);
}
function addWallTexture(value23, value24, value25) {
  value23.save();
  value23.globalAlpha = 0.3;
  for (let value26 = 0; value26 < 150; value26++) {
    const value27 = Math.random() * value24;
    const value28 = Math.random() * value25;
    const value29 = 5 + Math.random() * 25;
    const value30 = Math.random() * Math.PI * 2;
    const value31 = 20 + Math.random() * 15;
    value23.strokeStyle = "rgba(" + value31 + ", " + value31 + ", " + value31 + ", 0.4)";
    value23.lineWidth = 1;
    value23.lineCap = "round";
    value23.beginPath();
    value23.moveTo(value27, value28);
    value23.lineTo(value27 + Math.cos(value30) * value29, value28 + Math.sin(value30) * value29);
    value23.stroke();
  }
  for (let value32 = 0; value32 < 80; value32++) {
    const value33 = Math.random() * value24;
    const value34 = Math.random() * value25;
    const value35 = 3 + Math.random() * 12;
    const value36 = 30 + Math.random() * 20;
    value23.fillStyle = "rgba(" + value36 + ", " + value36 * 0.5 + ", " + value36 * 0.3 + ", 0.3)";
    value23.beginPath();
    value23.arc(value33, value34, value35, 0, Math.PI * 2);
    value23.fill();
  }
  value23.restore();
}
function addBloodStains(value37, value38, value39) {
  value37.save();
  value37.globalAlpha = 0.4;
  for (let value40 = 0; value40 < 15; value40++) {
    const value41 = Math.random() * value38;
    const value42 = Math.random() * value39;
    const value43 = 20 + Math.random() * 40;
    const value44 = value37.createRadialGradient(value41, value42, 0, value41, value42, value43);
    value44.addColorStop(0, "rgba(100, 0, 0, 0.8)");
    value44.addColorStop(0.7, "rgba(80, 0, 0, 0.4)");
    value44.addColorStop(1, "transparent");
    value37.fillStyle = value44;
    value37.beginPath();
    value37.arc(value41, value42, value43, 0, Math.PI * 2);
    value37.fill();
    addStainDrips(value37, value41, value42 + value43, value43 * 0.5);
  }
  value37.restore();
}
function addStainDrips(value45, value46, value47, value48) {
  for (let value49 = 0; value49 < value48; value49++) {
    const value50 = value46 + (Math.random() - 0.5) * 30;
    const value51 = 10 + Math.random() * 40;
    const value52 = 1 + Math.random() * 3;
    value45.strokeStyle = "rgba(80, 0, 0, 0.6)";
    value45.lineWidth = value52;
    value45.lineCap = "round";
    value45.beginPath();
    value45.moveTo(value50, value47);
    value45.lineTo(value50, value47 + value51);
    value45.stroke();
    value45.fillStyle = "rgba(100, 0, 0, 0.7)";
    value45.beginPath();
    value45.arc(value50, value47 + value51, value52 * 1.5, 0, Math.PI * 2);
    value45.fill();
  }
}
function drawAdvancedBloodText(value53, value54, value55, value56) {
  value53.save();
  value53.shadowColor = "rgba(150, 0, 0, 0.8)";
  value53.shadowBlur = 40;
  value53.shadowOffsetX = 5;
  value53.shadowOffsetY = 5;
  const value57 = value53.createLinearGradient(value55 - 150, value56 - 60, value55 + 150, value56 + 60);
  value57.addColorStop(0, "#8B0000");
  value57.addColorStop(0.2, "#DC143C");
  value57.addColorStop(0.5, "#8B0000");
  value57.addColorStop(0.8, "#DC143C");
  value57.addColorStop(1, "#8B0000");
  value53.font = "bold 80px \"Arial\"";
  value53.textAlign = "center";
  value53.textBaseline = "middle";
  value53.fillStyle = value57;
  value53.fillText(value54.toUpperCase(), value55, value56);
  value53.shadowColor = "transparent";
  value53.fillStyle = "rgba(220, 20, 60, 0.6)";
  value53.fillText(value54.toUpperCase(), value55 - 2, value56 - 2);
  addBloodClotTexture(value53, value54, value55, value56);
  addAdvancedDrippingBlood(value53, value54, value55, value56);
  addTextSplatter(value53, value54, value55, value56);
  value53.restore();
}
function addBloodClotTexture(value58, value59, value60, value61) {
  value58.save();
  value58.globalCompositeOperation = "overlay";
  value58.globalAlpha = 0.3;
  const value62 = value58.measureText(value59.toUpperCase());
  const value63 = value62.width;
  const value64 = 80;
  for (let value65 = 0; value65 < 25; value65++) {
    const value66 = value60 - value63 / 2 + Math.random() * value63;
    const value67 = value61 - value64 / 2 + Math.random() * value64;
    const value68 = 2 + Math.random() * 8;
    value58.fillStyle = "rgba(60, 0, 0, 0.8)";
    value58.beginPath();
    value58.arc(value66, value67, value68, 0, Math.PI * 2);
    value58.fill();
    value58.fillStyle = "rgba(150, 0, 0, 0.6)";
    value58.beginPath();
    value58.arc(value66 - value68 * 0.3, value67 - value68 * 0.3, value68 * 0.5, 0, Math.PI * 2);
    value58.fill();
  }
  for (let value69 = 0; value69 < 15; value69++) {
    const value70 = value60 - value63 / 2 + Math.random() * value63;
    const value71 = value61 - value64 / 2 + Math.random() * value64;
    const value72 = 5 + Math.random() * 20;
    const value73 = Math.random() * Math.PI * 2;
    value58.strokeStyle = "rgba(80, 0, 0, 0.7)";
    value58.lineWidth = 1 + Math.random() * 2;
    value58.lineCap = "round";
    value58.beginPath();
    value58.moveTo(value70, value71);
    value58.lineTo(value70 + Math.cos(value73) * value72, value71 + Math.sin(value73) * value72);
    value58.stroke();
  }
  value58.restore();
}
function addAdvancedDrippingBlood(value74, value75, value76, value77) {
  value74.save();
  value74.globalAlpha = 0.9;
  const value78 = value74.measureText(value75.toUpperCase());
  const value79 = value78.width;
  const value80 = 80;
  const value81 = [];
  for (let value82 = 0; value82 < value75.length * 3; value82++) {
    value81.push(value76 - value79 / 2 + Math.random() * value79);
  }
  value81.forEach(value83 => {
    const value84 = value77 + value80 / 2;
    const value85 = 1 + Math.floor(Math.random() * 3);
    for (let value86 = 0; value86 < value85; value86++) {
      const value87 = 20 + Math.random() * 60;
      const value88 = 2 + Math.random() * 4;
      const value89 = (Math.random() - 0.5) * 10;
      const value90 = value74.createLinearGradient(value83 + value89, value84, value83 + value89, value84 + value87);
      value90.addColorStop(0, "rgba(150, 0, 0, 0.9)");
      value90.addColorStop(0.7, "rgba(100, 0, 0, 0.7)");
      value90.addColorStop(1, "rgba(80, 0, 0, 0.5)");
      value74.strokeStyle = value90;
      value74.lineWidth = value88;
      value74.lineCap = "round";
      value74.beginPath();
      value74.moveTo(value83 + value89, value84);
      value74.lineTo(value83 + value89, value84 + value87);
      value74.stroke();
      const value91 = value74.createRadialGradient(value83 + value89, value84 + value87, 0, value83 + value89, value84 + value87, value88 * 2);
      value91.addColorStop(0, "rgba(180, 0, 0, 0.9)");
      value91.addColorStop(1, "rgba(120, 0, 0, 0.6)");
      value74.fillStyle = value91;
      value74.beginPath();
      value74.arc(value83 + value89, value84 + value87, value88 * 1.5, 0, Math.PI * 2);
      value74.fill();
      if (Math.random() > 0.7) {
        const value92 = 5 + Math.random() * 15;
        const value93 = value83 + value89 + (Math.random() - 0.5) * 8;
        value74.strokeStyle = "rgba(120, 0, 0, 0.7)";
        value74.lineWidth = value88 * 0.6;
        value74.beginPath();
        value74.moveTo(value83 + value89, value84 + value87 * 0.7);
        value74.lineTo(value93, value84 + value87 * 0.7 + value92);
        value74.stroke();
      }
    }
  });
  value74.restore();
}
function addTextSplatter(value94, value95, value96, value97) {
  value94.save();
  value94.globalAlpha = 0.8;
  const value98 = value94.measureText(value95.toUpperCase());
  const value99 = value98.width;
  const value100 = 80;
  for (let value101 = 0; value101 < 30; value101++) {
    const value102 = Math.random() * Math.PI * 2;
    const value103 = value99 * 0.3 + Math.random() * value99 * 0.4;
    const value104 = value96 + Math.cos(value102) * value103;
    const value105 = value97 + Math.sin(value102) * value103;
    const value106 = 3 + Math.random() * 12;
    drawBloodSplatter(value94, value104, value105, value106);
  }
  value94.restore();
}
function addBloodSplatters(value107, value108, value109) {
  value107.save();
  value107.globalAlpha = 0.7;
  for (let value110 = 0; value110 < 12; value110++) {
    const value111 = Math.random() * value108;
    const value112 = Math.random() * value109;
    const value113 = 15 + Math.random() * 25;
    drawAdvancedBloodSplatter(value107, value111, value112, value113);
  }
  for (let value114 = 0; value114 < 25; value114++) {
    const value115 = Math.random() * value108;
    const value116 = Math.random() * value109;
    const value117 = 8 + Math.random() * 15;
    drawBloodSplatter(value107, value115, value116, value117);
  }
  for (let value118 = 0; value118 < 60; value118++) {
    const value119 = Math.random() * value108;
    const value120 = Math.random() * value109;
    const value121 = 1 + Math.random() * 5;
    value107.fillStyle = "rgba(120, 0, 0, " + (0.5 + Math.random() * 0.4) + ")";
    value107.beginPath();
    value107.arc(value119, value120, value121, 0, Math.PI * 2);
    value107.fill();
  }
  value107.restore();
}
function drawAdvancedBloodSplatter(value122, value123, value124, value125) {
  const value126 = value122.createRadialGradient(value123, value124, 0, value123, value124, value125);
  value126.addColorStop(0, "rgba(180, 0, 0, 0.9)");
  value126.addColorStop(0.7, "rgba(120, 0, 0, 0.6)");
  value126.addColorStop(1, "transparent");
  value122.fillStyle = value126;
  value122.beginPath();
  value122.arc(value123, value124, value125, 0, Math.PI * 2);
  value122.fill();
  const value127 = 8 + Math.floor(Math.random() * 8);
  for (let value128 = 0; value128 < value127; value128++) {
    const value129 = value128 / value127 * Math.PI * 2;
    const value130 = value125 * (0.5 + Math.random() * 0.8);
    const value131 = value125 * (0.1 + Math.random() * 0.2);
    const value132 = value122.createLinearGradient(value123, value124, value123 + Math.cos(value129) * value130, value124 + Math.sin(value129) * value130);
    value132.addColorStop(0, "rgba(150, 0, 0, 0.8)");
    value132.addColorStop(1, "transparent");
    value122.strokeStyle = value132;
    value122.lineWidth = value131;
    value122.lineCap = "round";
    value122.beginPath();
    value122.moveTo(value123, value124);
    value122.lineTo(value123 + Math.cos(value129) * value130, value124 + Math.sin(value129) * value130);
    value122.stroke();
  }
}
function drawBloodSplatter(value133, value134, value135, value136) {
  value133.fillStyle = "rgba(120, 0, 0, " + (0.6 + Math.random() * 0.3) + ")";
  value133.beginPath();
  value133.arc(value134, value135, value136, 0, Math.PI * 2);
  value133.fill();
  for (let value137 = 0; value137 < 3; value137++) {
    const value138 = Math.random() * Math.PI * 2;
    const value139 = value136 * 0.5;
    value133.beginPath();
    value133.arc(value134 + Math.cos(value138) * value139, value135 + Math.sin(value138) * value139, value136 * 0.3, 0, Math.PI * 2);
    value133.fill();
  }
}
function addBloodSpatterPhysics(value140, value141, value142, value143) {
  value140.save();
  value140.globalAlpha = 0.6;
  const value144 = value140.measureText(value143.toUpperCase());
  const value145 = value144.width;
  for (let value146 = 0; value146 < 50; value146++) {
    const value147 = value141 - value145 / 2 + Math.random() * value145;
    const value148 = value142;
    const value149 = 2 + Math.random() * 4;
    const value150 = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI;
    const value151 = 5 + Math.floor(Math.random() * 10);
    drawBloodTrajectory(value140, value147, value148, value150, value149, value151);
  }
  value140.restore();
}
function drawBloodTrajectory(value152, value153, value154, value155, value156, value157) {
  let value158 = value153;
  let value159 = value154;
  const value160 = 0.2;
  let value161 = value156;
  value152.strokeStyle = "rgba(150, 0, 0, " + (0.4 + Math.random() * 0.3) + ")";
  value152.lineWidth = 1 + Math.random() * 2;
  value152.lineCap = "round";
  value152.beginPath();
  value152.moveTo(value158, value159);
  for (let value162 = 0; value162 < value157; value162++) {
    value158 += Math.cos(value155) * value161;
    value159 += Math.sin(value155) * value161;
    value161 *= 0.9;
    value155 += value160 * 0.1;
    value152.lineTo(value158, value159);
    if (Math.random() > 0.8 || value162 === value157 - 1) {
      value152.stroke();
      drawBloodSplatter(value152, value158, value159, 2 + Math.random() * 4);
      value152.beginPath();
      value152.moveTo(value158, value159);
    }
  }
  value152.stroke();
}
function addGoreDetails(value163, value164, value165) {
  value163.save();
  value163.globalAlpha = 0.7;
  for (let value166 = 0; value166 < 8; value166++) {
    const value167 = Math.random() * value164;
    const value168 = Math.random() * value165;
    const value169 = 5 + Math.random() * 15;
    drawFleshChunk(value163, value167, value168, value169);
  }
  for (let value170 = 0; value170 < 5; value170++) {
    const value171 = Math.random() * value164;
    const value172 = Math.random() * value165;
    const value173 = 3 + Math.random() * 8;
    drawBoneFragment(value163, value171, value172, value173);
  }
  value163.restore();
}
function drawFleshChunk(value174, value175, value176, value177) {
  const value178 = "rgba(" + (150 + Math.random() * 50) + ", " + (50 + Math.random() * 30) + ", " + (50 + Math.random() * 30) + ", 0.8)";
  value174.fillStyle = value178;
  value174.beginPath();
  value174.arc(value175, value176, value177, 0, Math.PI * 2);
  value174.fill();
  value174.strokeStyle = "rgba(100, 30, 30, 0.6)";
  value174.lineWidth = 1;
  for (let value179 = 0; value179 < 3; value179++) {
    const value180 = Math.random() * Math.PI * 2;
    const value181 = value177 * 0.8;
    value174.beginPath();
    value174.moveTo(value175, value176);
    value174.lineTo(value175 + Math.cos(value180) * value181, value176 + Math.sin(value180) * value181);
    value174.stroke();
  }
}
function drawBoneFragment(value182, value183, value184, value185) {
  value182.fillStyle = "rgba(240, 240, 220, 0.8)";
  value182.strokeStyle = "rgba(200, 200, 180, 0.9)";
  value182.lineWidth = 1;
  value182.beginPath();
  value182.ellipse(value183, value184, value185, value185 * 0.5, Math.random() * Math.PI, 0, Math.PI * 2);
  value182.fill();
  value182.stroke();
  value182.fillStyle = "rgba(180, 180, 160, 0.6)";
  value182.beginPath();
  value182.ellipse(value183, value184, value185 * 0.6, value185 * 0.3, Math.random() * Math.PI, 0, Math.PI * 2);
  value182.fill();
}
function addBloodPools(value186, value187, value188) {
  value186.save();
  value186.globalAlpha = 0.6;
  for (let value189 = 0; value189 < 6; value189++) {
    const value190 = Math.random() * value187;
    const value191 = value188 * 0.8 + Math.random() * value188 * 0.2;
    const value192 = 20 + Math.random() * 40;
    drawBloodPool(value186, value190, value191, value192);
  }
  value186.restore();
}
function drawBloodPool(value193, value194, value195, value196) {
  const value197 = value193.createRadialGradient(value194, value195, 0, value194, value195, value196);
  value197.addColorStop(0, "rgba(100, 0, 0, 0.8)");
  value197.addColorStop(0.5, "rgba(80, 0, 0, 0.6)");
  value197.addColorStop(1, "rgba(60, 0, 0, 0.3)");
  value193.fillStyle = value197;
  value193.beginPath();
  value193.ellipse(value194, value195, value196, value196 * 0.3, 0, 0, Math.PI * 2);
  value193.fill();
  const value198 = value193.createLinearGradient(value194 - value196, value195, value194 + value196, value195);
  value198.addColorStop(0, "rgba(150, 0, 0, 0.3)");
  value198.addColorStop(0.5, "rgba(180, 0, 0, 0.5)");
  value198.addColorStop(1, "rgba(150, 0, 0, 0.3)");
  value193.fillStyle = value198;
  value193.beginPath();
  value193.ellipse(value194, value195 - value196 * 0.1, value196 * 0.8, value196 * 0.2, 0, 0, Math.PI * 2);
  value193.fill();
}
function addBloodyHandprints(value199, value200, value201) {
  value199.save();
  value199.globalAlpha = 0.5;
  for (let value202 = 0; value202 < 4; value202++) {
    const value203 = Math.random() * value200;
    const value204 = Math.random() * value201;
    const value205 = 30 + Math.random() * 20;
    const value206 = Math.random() * Math.PI * 2;
    drawBloodyHandprint(value199, value203, value204, value205, value206);
  }
  value199.restore();
}
function drawBloodyHandprint(value207, value208, value209, value210, value211) {
  value207.save();
  value207.translate(value208, value209);
  value207.rotate(value211);
  value207.fillStyle = "rgba(120, 0, 0, 0.7)";
  value207.beginPath();
  value207.ellipse(0, 0, value210 * 0.3, value210 * 0.4, 0, 0, Math.PI * 2);
  value207.fill();
  const value212 = [-0.8, -0.4, 0, 0.4, 0.8];
  value212.forEach(value213 => {
    const value214 = Math.cos(value213) * value210 * 0.5;
    const value215 = Math.sin(value213) * value210 * 0.5;
    value207.beginPath();
    value207.ellipse(value214, value215, value210 * 0.1, value210 * 0.25, value213, 0, Math.PI * 2);
    value207.fill();
  });
  value207.restore();
}
function addWeaponMarks(value216, value217, value218) {
  value216.save();
  value216.globalAlpha = 0.4;
  for (let value219 = 0; value219 < 8; value219++) {
    const value220 = Math.random() * value217;
    const value221 = Math.random() * value218;
    const value222 = 20 + Math.random() * 40;
    const value223 = Math.random() * Math.PI * 2;
    value216.strokeStyle = "rgba(80, 0, 0, 0.6)";
    value216.lineWidth = 2;
    value216.lineCap = "round";
    value216.beginPath();
    value216.moveTo(value220, value221);
    value216.lineTo(value220 + Math.cos(value223) * value222, value221 + Math.sin(value223) * value222);
    value216.stroke();
  }
  for (let value224 = 0; value224 < 5; value224++) {
    const value225 = Math.random() * value217;
    const value226 = Math.random() * value218;
    const value227 = 3 + Math.random() * 6;
    value216.fillStyle = "rgba(40, 40, 40, 0.8)";
    value216.beginPath();
    value216.arc(value225, value226, value227, 0, Math.PI * 2);
    value216.fill();
    value216.fillStyle = "rgba(100, 0, 0, 0.5)";
    value216.beginPath();
    value216.arc(value225, value226, value227 * 1.5, 0, Math.PI * 2);
    value216.fill();
  }
  value216.restore();
}
function addBloodMist(value228, value229, value230) {
  value228.save();
  value228.globalAlpha = 0.1;
  value228.globalCompositeOperation = "screen";
  for (let value231 = 0; value231 < 5; value231++) {
    const value232 = Math.random() * value229;
    const value233 = Math.random() * value230;
    const value234 = 50 + Math.random() * 100;
    const value235 = value228.createRadialGradient(value232, value233, 0, value232, value233, value234);
    value235.addColorStop(0, "rgba(100, 0, 0, 0.4)");
    value235.addColorStop(1, "transparent");
    value228.fillStyle = value235;
    value228.beginPath();
    value228.arc(value232, value233, value234, 0, Math.PI * 2);
    value228.fill();
  }
  value228.restore();
}
function addBloodParticles(value236, value237, value238) {
  value236.save();
  value236.globalAlpha = 0.6;
  for (let value239 = 0; value239 < 40; value239++) {
    const value240 = Math.random() * value237;
    const value241 = Math.random() * value238;
    const value242 = 1 + Math.random() * 3;
    const value243 = 0.4 + Math.random() * 0.4;
    value236.fillStyle = "rgba(120, 0, 0, " + value243 + ")";
    value236.beginPath();
    value236.arc(value240, value241, value242, 0, Math.PI * 2);
    value236.fill();
    const value244 = 2 + Math.random() * 6;
    const value245 = Math.random() * Math.PI * 2;
    value236.strokeStyle = "rgba(100, 0, 0, " + value243 * 0.5 + ")";
    value236.lineWidth = value242 * 0.5;
    value236.lineCap = "round";
    value236.beginPath();
    value236.moveTo(value240, value241);
    value236.lineTo(value240 + Math.cos(value245) * value244, value241 + Math.sin(value245) * value244);
    value236.stroke();
  }
  value236.restore();
}
function addBloodLighting(value246, value247, value248) {
  value246.save();
  value246.globalCompositeOperation = "overlay";
  value246.globalAlpha = 0.2;
  for (let value249 = 0; value249 < 3; value249++) {
    const value250 = Math.random() * value247;
    const value251 = Math.random() * value248 * 0.3;
    const value252 = 60 + Math.random() * 80;
    const value253 = value246.createRadialGradient(value250, value251, 0, value250, value251, value252);
    value253.addColorStop(0, "rgba(255, 0, 0, 0.3)");
    value253.addColorStop(1, "transparent");
    value246.fillStyle = value253;
    value246.beginPath();
    value246.arc(value250, value251, value252, 0, Math.PI * 2);
    value246.fill();
  }
  value246.restore();
}
function addHorrorShadows(value254, value255, value256) {
  value254.save();
  value254.globalAlpha = 0.3;
  value254.fillStyle = "rgba(0, 0, 0, 0.5)";
  value254.beginPath();
  value254.moveTo(0, 0);
  value254.lineTo(value255 * 0.3, 0);
  value254.lineTo(0, value256 * 0.3);
  value254.closePath();
  value254.fill();
  value254.beginPath();
  value254.moveTo(value255, 0);
  value254.lineTo(value255 * 0.7, 0);
  value254.lineTo(value255, value256 * 0.3);
  value254.closePath();
  value254.fill();
  value254.beginPath();
  value254.moveTo(0, value256);
  value254.lineTo(value255 * 0.3, value256);
  value254.lineTo(0, value256 * 0.7);
  value254.closePath();
  value254.fill();
  value254.beginPath();
  value254.moveTo(value255, value256);
  value254.lineTo(value255 * 0.7, value256);
  value254.lineTo(value255, value256 * 0.7);
  value254.closePath();
  value254.fill();
  value254.restore();
}
function drawGoreBorder(value257, value258, value259) {
  value257.save();
  const value260 = value257.createLinearGradient(0, 0, value258, 0);
  value260.addColorStop(0, "#8B0000");
  value260.addColorStop(0.3, "#DC143C");
  value260.addColorStop(0.5, "#8B0000");
  value260.addColorStop(0.7, "#DC143C");
  value260.addColorStop(1, "#8B0000");
  value257.strokeStyle = value260;
  value257.lineWidth = 10;
  value257.shadowColor = "rgba(150, 0, 0, 0.6)";
  value257.shadowBlur = 20;
  value257.strokeRect(10, 10, value258 - 20, value259 - 20);
  value257.strokeStyle = "rgba(150, 0, 0, 0.6)";
  value257.lineWidth = 3;
  value257.shadowBlur = 15;
  value257.strokeRect(20, 20, value258 - 40, value259 - 40);
  addBloodCorners(value257, value258, value259);
  value257.restore();
}
function addBloodCorners(value261, value262, value263) {
  value261.save();
  value261.globalAlpha = 0.8;
  const value264 = [{
    x: 30,
    y: 30
  }, {
    x: value262 - 30,
    y: 30
  }, {
    x: 30,
    y: value263 - 30
  }, {
    x: value262 - 30,
    y: value263 - 30
  }];
  value264.forEach(value265 => {
    const value266 = value261.createRadialGradient(value265.x, value265.y, 0, value265.x, value265.y, 8);
    value266.addColorStop(0, "rgba(180, 0, 0, 0.9)");
    value266.addColorStop(1, "rgba(120, 0, 0, 0.6)");
    value261.fillStyle = value266;
    value261.beginPath();
    value261.arc(value265.x, value265.y, 8, 0, Math.PI * 2);
    value261.fill();
    value261.strokeStyle = "rgba(150, 0, 0, 0.8)";
    value261.lineWidth = 3;
    value261.lineCap = "round";
    value261.beginPath();
    value261.moveTo(value265.x, value265.y);
    value261.lineTo(value265.x, value265.y + 15);
    value261.stroke();
  });
  value261.restore();
}
function addBloodSignature(value267, value268, value269) {
  value267.save();
  const value270 = value268 - 110;
  const value271 = value269 - 25;
  value267.font = "italic 14px \"Arial\"";
  value267.fillStyle = "rgba(150, 0, 0, 0.9)";
  value267.textAlign = "right";
  value267.textBaseline = "bottom";
  value267.shadowColor = "rgba(100, 0, 0, 0.6)";
  value267.shadowBlur = 10;
  value267.fillText("by " + getBotName(), value270, value271);
  const value272 = value267.createRadialGradient(value270 + 5, value271 - 8, 0, value270 + 5, value271 - 8, 4);
  value272.addColorStop(0, "rgba(180, 0, 0, 0.9)");
  value272.addColorStop(1, "rgba(120, 0, 0, 0.6)");
  value267.fillStyle = value272;
  value267.beginPath();
  value267.arc(value270 + 5, value271 - 8, 4, 0, Math.PI * 2);
  value267.fill();
  value267.strokeStyle = "rgba(150, 0, 0, 0.8)";
  value267.lineWidth = 2;
  value267.lineCap = "round";
  value267.beginPath();
  value267.moveTo(value270 + 5, value271 - 4);
  value267.lineTo(value270 + 5, value271 - 1);
  value267.stroke();
  value267.restore();
}
