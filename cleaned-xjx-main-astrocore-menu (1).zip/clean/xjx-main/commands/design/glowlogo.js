const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "glowlogo",
  description: "Create intense glowing text logos with vibrant light effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "✨ *GLOW LOGO*\n\n*glowlogo*\nglowlogo <text>\n\n*Example:*\nglowlogo WOLF\nglowlogo GLOW\nglowlogo LIGHT\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 12) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 12 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateGlowLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "✨ *Glow Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [GLOWLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateGlowLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#000000";
  value16.fillRect(0, 0, value13, value14);
  drawCosmicBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 70, 0, 330);
  value17.addColorStop(0, "#FF0080");
  value17.addColorStop(0.2, "#FF00FF");
  value17.addColorStop(0.4, "#8000FF");
  value17.addColorStop(0.6, "#0080FF");
  value17.addColorStop(0.8, "#00FF80");
  value17.addColorStop(1, "#FFFF00");
  value16.font = "bold 88px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createMultiLayerGlow(value16, value12, value13, value14, value17);
  addLightBursts(value16, value13, value14);
  addGlowParticles(value16, value13, value14);
  addRainbowAura(value16, value12, value13, value14);
  drawHolographicBorder(value16, value13, value14);
  addSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawCosmicBackground(value18, value19, value20) {
  const value21 = value18.createRadialGradient(value19 / 2, value20 / 2, 0, value19 / 2, value20 / 2, Math.max(value19, value20) / 1.2);
  value21.addColorStop(0, "#000033");
  value21.addColorStop(0.3, "#000022");
  value21.addColorStop(0.7, "#000011");
  value21.addColorStop(1, "#000000");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  value18.fillStyle = "#FFFFFF";
  for (let value22 = 0; value22 < 150; value22++) {
    const value23 = Math.random() * value19;
    const value24 = Math.random() * value20;
    const value25 = Math.random() * 2;
    const value26 = 0.3 + Math.random() * 0.7;
    value18.globalAlpha = value26;
    value18.beginPath();
    value18.arc(value23, value24, value25, 0, Math.PI * 2);
    value18.fill();
  }
  value18.globalAlpha = 1;
  addNebulaEffects(value18, value19, value20);
}
function addNebulaEffects(value27, value28, value29) {
  const value30 = [{
    x: value28 * 0.2,
    y: value29 * 0.3,
    size: 150,
    color: "rgba(255, 0, 128, 0.1)"
  }, {
    x: value28 * 0.7,
    y: value29 * 0.2,
    size: 120,
    color: "rgba(128, 0, 255, 0.08)"
  }, {
    x: value28 * 0.3,
    y: value29 * 0.7,
    size: 130,
    color: "rgba(0, 128, 255, 0.09)"
  }, {
    x: value28 * 0.8,
    y: value29 * 0.6,
    size: 110,
    color: "rgba(0, 255, 128, 0.07)"
  }];
  value30.forEach(value31 => {
    const value32 = value27.createRadialGradient(value31.x, value31.y, 0, value31.x, value31.y, value31.size);
    value32.addColorStop(0, value31.color);
    value32.addColorStop(1, "transparent");
    value27.fillStyle = value32;
    value27.beginPath();
    value27.arc(value31.x, value31.y, value31.size, 0, Math.PI * 2);
    value27.fill();
  });
}
function createMultiLayerGlow(value33, value34, value35, value36, value37) {
  const value38 = value35 / 2;
  const value39 = value36 / 2;
  const value40 = [{
    blur: 60,
    alpha: 0.3,
    color: "#FF0080",
    offset: 0
  }, {
    blur: 50,
    alpha: 0.4,
    color: "#FF00FF",
    offset: 1
  }, {
    blur: 40,
    alpha: 0.5,
    color: "#8000FF",
    offset: 2
  }, {
    blur: 30,
    alpha: 0.6,
    color: "#0080FF",
    offset: 1
  }, {
    blur: 20,
    alpha: 0.7,
    color: "#00FF80",
    offset: 0
  }, {
    blur: 10,
    alpha: 0.8,
    color: "#FFFF00",
    offset: -1
  }];
  for (const value41 of value40) {
    value33.shadowColor = value41.color;
    value33.shadowBlur = value41.blur;
    value33.fillStyle = "rgba(255, 255, 255, " + value41.alpha + ")";
    value33.fillText(value34.toUpperCase(), value38 + value41.offset, value39 + value41.offset);
  }
  value33.shadowColor = "transparent";
  value33.shadowBlur = 0;
  value33.fillStyle = value37;
  value33.fillText(value34.toUpperCase(), value38, value39);
  value33.save();
  value33.globalCompositeOperation = "screen";
  value33.fillStyle = "rgba(255, 255, 255, 0.6)";
  value33.fillText(value34.toUpperCase(), value38, value39);
  value33.restore();
  value33.strokeStyle = "rgba(255, 255, 255, 0.9)";
  value33.lineWidth = 2;
  value33.strokeText(value34.toUpperCase(), value38, value39);
}
function addLightBursts(value42, value43, value44) {
  const value45 = value43 / 2;
  const value46 = value44 / 2;
  value42.save();
  value42.globalAlpha = 0.4;
  for (let value47 = 0; value47 < 3; value47++) {
    const value48 = 200 + value47 * 100;
    const value49 = 0.3 - value47 * 0.1;
    for (let value50 = 0; value50 < 24; value50++) {
      const value51 = value50 / 24 * Math.PI * 2;
      const value52 = value48;
      const value53 = value42.createLinearGradient(value45, value46, value45 + Math.cos(value51) * value52, value46 + Math.sin(value51) * value52);
      const value54 = value50 * 15 % 360;
      value53.addColorStop(0, "hsla(" + value54 + ", 100%, 70%, " + value49 + ")");
      value53.addColorStop(0.7, "hsla(" + value54 + ", 100%, 50%, " + value49 * 0.5 + ")");
      value53.addColorStop(1, "transparent");
      value42.strokeStyle = value53;
      value42.lineWidth = 8 - value47 * 2;
      value42.beginPath();
      value42.moveTo(value45, value46);
      value42.lineTo(value45 + Math.cos(value51) * value52, value46 + Math.sin(value51) * value52);
      value42.stroke();
    }
  }
  value42.restore();
}
function addGlowParticles(value55, value56, value57) {
  const value58 = value56 / 2;
  const value59 = value57 / 2;
  value55.save();
  value55.globalAlpha = 0.8;
  for (let value60 = 0; value60 < 25; value60++) {
    const value61 = Math.random() * Math.PI * 2;
    const value62 = 80 + Math.random() * 250;
    const value63 = 3 + Math.random() * 8;
    const value64 = Math.random() * 360;
    const value65 = value58 + Math.cos(value61) * value62;
    const value66 = value59 + Math.sin(value61) * value62;
    const value67 = value55.createRadialGradient(value65, value66, 0, value65, value66, value63 * 3);
    value67.addColorStop(0, "hsla(" + value64 + ", 100%, 80%, 0.9)");
    value67.addColorStop(0.7, "hsla(" + value64 + ", 100%, 60%, 0.6)");
    value67.addColorStop(1, "transparent");
    value55.fillStyle = value67;
    value55.beginPath();
    value55.arc(value65, value66, value63 * 3, 0, Math.PI * 2);
    value55.fill();
    value55.fillStyle = "hsla(" + value64 + ", 100%, 90%, 0.8)";
    value55.beginPath();
    value55.arc(value65, value66, value63 * 0.7, 0, Math.PI * 2);
    value55.fill();
  }
  for (let value68 = 0; value68 < 40; value68++) {
    const value69 = Math.random() * value56;
    const value70 = Math.random() * value57;
    const value71 = 1 + Math.random() * 3;
    const value72 = Math.random() * 360;
    const value73 = 0.7 + Math.random() * 0.3;
    value55.fillStyle = "hsla(" + value72 + ", 100%, 80%, " + value73 + ")";
    value55.beginPath();
    for (let value74 = 0; value74 < 5; value74++) {
      const value75 = value74 * Math.PI * 2 / 5;
      const value76 = value71;
      const value77 = value71 * 0.4;
      value55.lineTo(value69 + Math.cos(value75) * value76, value70 + Math.sin(value75) * value76);
      value55.lineTo(value69 + Math.cos(value75 + Math.PI / 5) * value77, value70 + Math.sin(value75 + Math.PI / 5) * value77);
    }
    value55.closePath();
    value55.fill();
    value55.shadowColor = "hsla(" + value72 + ", 100%, 70%, 0.8)";
    value55.shadowBlur = 12;
    value55.fill();
  }
  value55.restore();
}
function addRainbowAura(value78, value79, value80, value81) {
  const value82 = value80 / 2;
  const value83 = value81 / 2;
  value78.save();
  value78.globalCompositeOperation = "screen";
  for (let value84 = 0; value84 < 3; value84++) {
    const value85 = 120 + value84 * 40;
    const value86 = 0.2 - value84 * 0.05;
    for (let value87 = 0; value87 < 36; value87++) {
      const value88 = value87 / 36 * Math.PI * 2;
      const value89 = value87 * 10 % 360;
      const value90 = value82 + Math.cos(value88) * value85;
      const value91 = value83 + Math.sin(value88) * value85;
      const value92 = value78.createRadialGradient(value90, value91, 0, value90, value91, 30);
      value92.addColorStop(0, "hsla(" + value89 + ", 100%, 70%, " + value86 + ")");
      value92.addColorStop(1, "transparent");
      value78.fillStyle = value92;
      value78.beginPath();
      value78.arc(value90, value91, 30, 0, Math.PI * 2);
      value78.fill();
    }
  }
  value78.restore();
}
function drawHolographicBorder(value93, value94, value95) {
  const value96 = value93.createLinearGradient(0, 0, value94, value95);
  value96.addColorStop(0, "#FF0080");
  value96.addColorStop(0.2, "#FF00FF");
  value96.addColorStop(0.4, "#8000FF");
  value96.addColorStop(0.6, "#0080FF");
  value96.addColorStop(0.8, "#00FF80");
  value96.addColorStop(1, "#FFFF00");
  value93.strokeStyle = value96;
  value93.lineWidth = 10;
  value93.shadowColor = "#FFFFFF";
  value93.shadowBlur = 30;
  value93.strokeRect(10, 10, value94 - 20, value95 - 20);
  value93.strokeStyle = "rgba(255, 255, 255, 0.6)";
  value93.lineWidth = 4;
  value93.shadowBlur = 20;
  value93.strokeRect(18, 18, value94 - 36, value95 - 36);
  const value97 = value93.createLinearGradient(value94, 0, 0, value95);
  value97.addColorStop(0, "#FFFF00");
  value97.addColorStop(0.2, "#00FF80");
  value97.addColorStop(0.4, "#0080FF");
  value97.addColorStop(0.6, "#8000FF");
  value97.addColorStop(0.8, "#FF00FF");
  value97.addColorStop(1, "#FF0080");
  value93.strokeStyle = value97;
  value93.lineWidth = 2;
  value93.shadowBlur = 0;
  value93.strokeRect(26, 26, value94 - 52, value95 - 52);
  addCornerGlowAccents(value93, value94, value95);
}
function addCornerGlowAccents(value98, value99, value100) {
  value98.save();
  value98.globalAlpha = 0.7;
  const value101 = [{
    x: 25,
    y: 25
  }, {
    x: value99 - 25,
    y: 25
  }, {
    x: 25,
    y: value100 - 25
  }, {
    x: value99 - 25,
    y: value100 - 25
  }];
  value101.forEach((value102, value103) => {
    const value104 = value103 * 90 % 360;
    const value105 = value98.createRadialGradient(value102.x, value102.y, 0, value102.x, value102.y, 25);
    value105.addColorStop(0, "hsla(" + value104 + ", 100%, 70%, 0.9)");
    value105.addColorStop(1, "transparent");
    value98.fillStyle = value105;
    value98.beginPath();
    value98.arc(value102.x, value102.y, 25, 0, Math.PI * 2);
    value98.fill();
  });
  value98.restore();
}
function addSignature(value106, value107, value108) {
  value106.save();
  const value109 = value107 - 120;
  const value110 = value108 - 20;
  value106.font = "italic 12px \"Arial\"";
  value106.fillStyle = "rgba(255, 255, 255, 0.8)";
  value106.textAlign = "right";
  value106.textBaseline = "bottom";
  value106.shadowColor = "#FF00FF";
  value106.shadowBlur = 8;
  value106.fillText("by " + getBotName(), value109, value110);
  const value111 = value106.createLinearGradient(value109 - value106.measureText("by " + getBotName()).width, value110 + 2, value109, value110 + 2);
  value111.addColorStop(0, "#FF0080");
  value111.addColorStop(0.5, "#0080FF");
  value111.addColorStop(1, "#FFFF00");
  value106.strokeStyle = value111;
  value106.lineWidth = 1;
  value106.beginPath();
  value106.moveTo(value109 - value106.measureText("by " + getBotName()).width, value110 + 2);
  value106.lineTo(value109, value110 + 2);
  value106.stroke();
  value106.shadowColor = "transparent";
  value106.shadowBlur = 0;
  value106.restore();
}
