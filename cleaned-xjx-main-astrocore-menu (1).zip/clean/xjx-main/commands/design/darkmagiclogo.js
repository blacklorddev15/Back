const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "darkmagiclogo",
  description: "Create sinister dark magic text logos with occult and forbidden spell effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🔮 *DARK MAGIC LOGO*\n\n*darkmagiclogo*\ndarkmagiclogo <text>\n\n*Example:*\ndarkmagiclogo SHADOW\ndarkmagiclogo VOID\ndarkmagiclogo CURSED\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateDarkMagicLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🔮 *Dark Magic Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [DARKMAGICLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateDarkMagicLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createForbiddenSanctum(value16, value13, value14);
  const value17 = value13 * 0.75;
  const value18 = value14 * 0.55;
  drawDarkSorcerer(value16, value17, value18);
  addRitualCircle(value16, value17, value18);
  addDarkEnergy(value16, value17, value18);
  addShadowTendrils(value16, value13, value14);
  drawCursedText(value16, value12, value13, value14);
  addOccultSymbols(value16, value13, value14);
  addFloatingRunes(value16, value13, value14);
  addBloodDrops(value16, value13, value14);
  addSoulParticles(value16, value13, value14);
  drawForbiddenBorder(value16, value13, value14);
  addDarkSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createForbiddenSanctum(value19, value20, value21) {
  const value22 = value19.createLinearGradient(0, 0, 0, value21);
  value22.addColorStop(0, "#000000");
  value22.addColorStop(0.3, "#1a001a");
  value22.addColorStop(0.6, "#330033");
  value22.addColorStop(1, "#000000");
  value19.fillStyle = value22;
  value19.fillRect(0, 0, value20, value21);
  addAncientStoneTexture(value19, value20, value21);
  addRitualCandles(value19, value20, value21);
}
function addAncientStoneTexture(value23, value24, value25) {
  value23.save();
  value23.globalAlpha = 0.1;
  for (let value26 = 0; value26 < 200; value26++) {
    const value27 = Math.random() * value24;
    const value28 = Math.random() * value25;
    const value29 = 10 + Math.random() * 30;
    const value30 = Math.random() * Math.PI * 2;
    const value31 = 30 + Math.random() * 20;
    value23.strokeStyle = "rgba(" + value31 + ", " + value31 + ", " + value31 + ", 0.4)";
    value23.lineWidth = 1;
    value23.lineCap = "round";
    value23.beginPath();
    value23.moveTo(value27, value28);
    value23.lineTo(value27 + Math.cos(value30) * value29, value28 + Math.sin(value30) * value29);
    value23.stroke();
  }
  for (let value32 = 0; value32 < 50; value32++) {
    const value33 = Math.random() * value24;
    const value34 = Math.random() * value25;
    const value35 = 3 + Math.random() * 8;
    const value36 = 30 + Math.random() * 20;
    value23.fillStyle = "rgba(" + value36 + ", " + value36 + ", 20, 0.3)";
    value23.beginPath();
    value23.arc(value33, value34, value35, 0, Math.PI * 2);
    value23.fill();
  }
  value23.restore();
}
function addRitualCandles(value37, value38, value39) {
  value37.save();
  value37.globalAlpha = 0.6;
  const value40 = [{
    x: value38 * 0.2,
    y: value39 * 0.7
  }, {
    x: value38 * 0.3,
    y: value39 * 0.8
  }, {
    x: value38 * 0.8,
    y: value39 * 0.7
  }, {
    x: value38 * 0.7,
    y: value39 * 0.8
  }];
  value40.forEach(value41 => {
    value37.fillStyle = "#2c2c2c";
    value37.fillRect(value41.x - 4, value41.y - 30, 8, 30);
    const value42 = value37.createRadialGradient(value41.x, value41.y - 35, 0, value41.x, value41.y - 35, 8);
    value42.addColorStop(0, "rgba(255, 100, 0, 0.9)");
    value42.addColorStop(0.5, "rgba(255, 50, 0, 0.6)");
    value42.addColorStop(1, "transparent");
    value37.fillStyle = value42;
    value37.beginPath();
    value37.arc(value41.x, value41.y - 35, 8, 0, Math.PI * 2);
    value37.fill();
    value37.fillStyle = "rgba(255, 200, 0, 0.4)";
    value37.beginPath();
    value37.arc(value41.x, value41.y - 38, 4, 0, Math.PI * 2);
    value37.fill();
    const value43 = value37.createRadialGradient(value41.x, value41.y - 35, 0, value41.x, value41.y - 35, 20);
    value43.addColorStop(0, "rgba(255, 100, 0, 0.3)");
    value43.addColorStop(1, "transparent");
    value37.fillStyle = value43;
    value37.beginPath();
    value37.arc(value41.x, value41.y - 35, 20, 0, Math.PI * 2);
    value37.fill();
  });
  value37.restore();
}
function drawDarkSorcerer(value44, value45, value46) {
  value44.save();
  const value47 = value44.createLinearGradient(value45, value46 - 60, value45, value46 + 40);
  value47.addColorStop(0, "rgba(20, 0, 40, 0.9)");
  value47.addColorStop(1, "rgba(0, 0, 0, 0.95)");
  value44.fillStyle = value47;
  value44.beginPath();
  value44.moveTo(value45 - 25, value46 - 30);
  value44.bezierCurveTo(value45 - 35, value46 + 40, value45 + 35, value46 + 40, value45 + 25, value46 - 30);
  value44.fill();
  value44.fillStyle = "rgba(0, 0, 0, 0.95)";
  value44.beginPath();
  value44.arc(value45, value46 - 45, 20, 0, Math.PI * 2);
  value44.fill();
  value44.beginPath();
  value44.moveTo(value45 - 20, value46 - 35);
  value44.bezierCurveTo(value45 - 25, value46 - 20, value45 + 25, value46 - 20, value45 + 20, value46 - 35);
  value44.fill();
  const value48 = value44.createRadialGradient(value45 - 8, value46 - 45, 0, value45 - 8, value46 - 45, 6);
  value48.addColorStop(0, "rgba(255, 0, 100, 0.9)");
  value48.addColorStop(1, "transparent");
  value44.fillStyle = value48;
  value44.beginPath();
  value44.arc(value45 - 8, value46 - 45, 6, 0, Math.PI * 2);
  value44.fill();
  value44.beginPath();
  value44.arc(value45 + 8, value46 - 45, 6, 0, Math.PI * 2);
  value44.fill();
  value44.fillStyle = "rgba(0, 0, 0, 0.9)";
  value44.beginPath();
  value44.arc(value45 - 8, value46 - 45, 2, 0, Math.PI * 2);
  value44.fill();
  value44.beginPath();
  value44.arc(value45 + 8, value46 - 45, 2, 0, Math.PI * 2);
  value44.fill();
  value44.fillStyle = "rgba(20, 0, 40, 0.9)";
  value44.beginPath();
  value44.arc(value45 - 35, value46 - 10, 8, 0, Math.PI * 2);
  value44.fill();
  value44.beginPath();
  value44.arc(value45 + 35, value46 - 10, 8, 0, Math.PI * 2);
  value44.fill();
  value44.restore();
}
function addRitualCircle(value49, value50, value51) {
  value49.save();
  value49.globalAlpha = 0.8;
  value49.strokeStyle = "rgba(100, 0, 50, 0.8)";
  value49.lineWidth = 3;
  value49.beginPath();
  value49.arc(value50, value51, 80, 0, Math.PI * 2);
  value49.stroke();
  value49.strokeStyle = "rgba(150, 0, 100, 0.9)";
  value49.lineWidth = 2;
  value49.beginPath();
  value49.arc(value50, value51, 60, 0, Math.PI * 2);
  value49.stroke();
  drawPentagram(value49, value50, value51, 40);
  addCircleSymbols(value49, value50, value51);
  const value52 = value49.createRadialGradient(value50, value51, 50, value50, value51, 90);
  value52.addColorStop(0, "rgba(100, 0, 50, 0.4)");
  value52.addColorStop(1, "transparent");
  value49.fillStyle = value52;
  value49.beginPath();
  value49.arc(value50, value51, 90, 0, Math.PI * 2);
  value49.fill();
  value49.restore();
}
function drawPentagram(value53, value54, value55, value56) {
  value53.save();
  value53.strokeStyle = "rgba(200, 0, 100, 0.9)";
  value53.lineWidth = 2;
  value53.lineJoin = "round";
  const value57 = [];
  for (let value58 = 0; value58 < 5; value58++) {
    const value59 = value58 * 2 * Math.PI / 5 - Math.PI / 2;
    value57.push({
      x: value54 + Math.cos(value59) * value56,
      y: value55 + Math.sin(value59) * value56
    });
  }
  value53.beginPath();
  value53.moveTo(value57[0].x, value57[0].y);
  value53.lineTo(value57[2].x, value57[2].y);
  value53.lineTo(value57[4].x, value57[4].y);
  value53.lineTo(value57[1].x, value57[1].y);
  value53.lineTo(value57[3].x, value57[3].y);
  value53.closePath();
  value53.stroke();
  value53.restore();
}
function addCircleSymbols(value60, value61, value62) {
  value60.save();
  value60.globalAlpha = 0.7;
  const value63 = ["†", "‡", "Ω", "Ψ", "‡", "∞"];
  const value64 = 70;
  value63.forEach((value65, value66) => {
    const value67 = value66 / value63.length * Math.PI * 2;
    const value68 = value61 + Math.cos(value67) * value64;
    const value69 = value62 + Math.sin(value67) * value64;
    value60.fillStyle = "rgba(150, 0, 100, 0.9)";
    value60.font = "bold 14px Arial";
    value60.textAlign = "center";
    value60.textBaseline = "middle";
    value60.fillText(value65, value68, value69);
  });
  value60.restore();
}
function addDarkEnergy(value70, value71, value72) {
  value70.save();
  value70.globalCompositeOperation = "screen";
  for (let value73 = 0; value73 < 3; value73++) {
    const value74 = 100 + value73 * 30;
    const value75 = 0.2 - value73 * 0.05;
    value70.strokeStyle = "rgba(100, 0, 100, " + value75 + ")";
    value70.lineWidth = 8;
    value70.beginPath();
    value70.arc(value71, value72, value74, 0, Math.PI * 2);
    value70.stroke();
  }
  addEnergyTendrils(value70, value71 - 35, value72 - 10);
  addEnergyTendrils(value70, value71 + 35, value72 - 10);
  const value76 = value70.createRadialGradient(value71, value72, 0, value71, value72, 120);
  value76.addColorStop(0, "rgba(100, 0, 50, 0.6)");
  value76.addColorStop(0.5, "rgba(50, 0, 100, 0.3)");
  value76.addColorStop(1, "transparent");
  value70.fillStyle = value76;
  value70.beginPath();
  value70.arc(value71, value72, 120, 0, Math.PI * 2);
  value70.fill();
  value70.restore();
}
function addEnergyTendrils(value77, value78, value79) {
  value77.strokeStyle = "rgba(150, 0, 100, 0.8)";
  value77.lineWidth = 3;
  value77.lineCap = "round";
  for (let value80 = 0; value80 < 5; value80++) {
    const value81 = 30 + Math.random() * 40;
    const value82 = -0.5 + Math.random();
    value77.beginPath();
    value77.moveTo(value78, value79);
    value77.bezierCurveTo(value78 + Math.cos(value82) * value81 * 0.3, value79 + Math.sin(value82) * value81 * 0.3, value78 + Math.cos(value82) * value81 * 0.7, value79 + Math.sin(value82) * value81 * 0.7, value78 + Math.cos(value82) * value81, value79 + Math.sin(value82) * value81);
    value77.stroke();
    value77.strokeStyle = "rgba(200, 0, 150, 0.4)";
    value77.lineWidth = 8;
    value77.beginPath();
    value77.moveTo(value78, value79);
    value77.bezierCurveTo(value78 + Math.cos(value82) * value81 * 0.3, value79 + Math.sin(value82) * value81 * 0.3, value78 + Math.cos(value82) * value81 * 0.7, value79 + Math.sin(value82) * value81 * 0.7, value78 + Math.cos(value82) * value81, value79 + Math.sin(value82) * value81);
    value77.stroke();
    value77.strokeStyle = "rgba(150, 0, 100, 0.8)";
    value77.lineWidth = 3;
  }
}
function addShadowTendrils(value83, value84, value85) {
  value83.save();
  value83.globalAlpha = 0.3;
  for (let value86 = 0; value86 < 8; value86++) {
    const value87 = Math.random() * value84;
    const value88 = value85 + 20;
    const value89 = value87 + (Math.random() - 0.5) * 100;
    const value90 = Math.random() * value85 * 0.8;
    value83.strokeStyle = "rgba(50, 0, 50, 0.6)";
    value83.lineWidth = 4;
    value83.lineCap = "round";
    value83.beginPath();
    value83.moveTo(value87, value88);
    value83.bezierCurveTo(value87 + (Math.random() - 0.5) * 50, value88 - 100, value89 + (Math.random() - 0.5) * 50, value90 + 50, value89, value90);
    value83.stroke();
  }
  value83.restore();
}
function drawCursedText(value91, value92, value93, value94) {
  const value95 = value93 * 0.35;
  const value96 = value94 * 0.6;
  value91.save();
  value91.shadowColor = "rgba(100, 0, 50, 0.8)";
  value91.shadowBlur = 30;
  const value97 = value91.createLinearGradient(value95 - 100, value96 - 50, value95 + 100, value96 + 50);
  value97.addColorStop(0, "#640064");
  value97.addColorStop(0.3, "#960096");
  value97.addColorStop(0.7, "#C80064");
  value97.addColorStop(1, "#640064");
  value91.font = "bold 70px \"Arial\"";
  value91.textAlign = "center";
  value91.textBaseline = "middle";
  value91.fillStyle = value97;
  value91.fillText(value92.toUpperCase(), value95, value96);
  value91.shadowColor = "transparent";
  value91.fillStyle = "rgba(200, 0, 100, 0.7)";
  value91.fillText(value92.toUpperCase(), value95, value96);
  value91.strokeStyle = "rgba(100, 0, 50, 0.9)";
  value91.lineWidth = 2;
  value91.strokeText(value92.toUpperCase(), value95, value96);
  addTextCorruption(value91, value92, value95, value96);
  value91.restore();
}
function addTextCorruption(value98, value99, value100, value101) {
  value98.save();
  value98.globalCompositeOperation = "overlay";
  value98.globalAlpha = 0.4;
  const value102 = value98.measureText(value99.toUpperCase());
  const value103 = value102.width;
  const value104 = 70;
  for (let value105 = 0; value105 < 15; value105++) {
    const value106 = value100 - value103 / 2 + Math.random() * value103;
    const value107 = value101 - value104 / 2 + Math.random() * value104;
    const value108 = 5 + Math.random() * 15;
    const value109 = Math.random() * Math.PI * 2;
    value98.strokeStyle = "rgba(50, 0, 0, 0.8)";
    value98.lineWidth = 1;
    value98.lineCap = "round";
    value98.beginPath();
    value98.moveTo(value106, value107);
    value98.lineTo(value106 + Math.cos(value109) * value108, value107 + Math.sin(value109) * value108);
    value98.stroke();
  }
  for (let value110 = 0; value110 < 8; value110++) {
    const value111 = value100 - value103 / 2 + Math.random() * value103;
    const value112 = value101 + value104 / 2;
    const value113 = 10 + Math.random() * 20;
    value98.strokeStyle = "rgba(150, 0, 0, 0.7)";
    value98.lineWidth = 2;
    value98.lineCap = "round";
    value98.beginPath();
    value98.moveTo(value111, value112);
    value98.lineTo(value111, value112 + value113);
    value98.stroke();
    value98.fillStyle = "rgba(150, 0, 0, 0.7)";
    value98.beginPath();
    value98.arc(value111, value112 + value113, 3, 0, Math.PI * 2);
    value98.fill();
  }
  value98.restore();
}
function addOccultSymbols(value114, value115, value116) {
  value114.save();
  value114.globalAlpha = 0.6;
  const value117 = ["†", "‡", "Ω", "Ψ", "∞", "⌘", "⚡", "☠"];
  for (let value118 = 0; value118 < 12; value118++) {
    const value119 = Math.random() * value115;
    const value120 = Math.random() * value116;
    const value121 = 10 + Math.random() * 8;
    const value122 = value117[Math.floor(Math.random() * value117.length)];
    value114.fillStyle = "rgba(150, 0, 100, 0.8)";
    value114.font = "bold " + value121 + "px Arial";
    value114.textAlign = "center";
    value114.textBaseline = "middle";
    value114.fillText(value122, value119, value120);
    value114.fillStyle = "rgba(100, 0, 50, 0.3)";
    value114.beginPath();
    value114.arc(value119, value120, value121, 0, Math.PI * 2);
    value114.fill();
  }
  value114.restore();
}
function addFloatingRunes(value123, value124, value125) {
  value123.save();
  value123.globalAlpha = 0.5;
  const value126 = ["ᚠ", "ᚢ", "ᚦ", "ᚨ", "ᚱ", "ᚲ", "ᚷ", "ᚹ"];
  for (let value127 = 0; value127 < 15; value127++) {
    const value128 = Math.random() * value124;
    const value129 = Math.random() * value125;
    const value130 = 12 + Math.random() * 10;
    const value131 = value126[Math.floor(Math.random() * value126.length)];
    value123.fillStyle = "rgba(100, 0, 50, 0.9)";
    value123.font = "bold " + value130 + "px Arial";
    value123.textAlign = "center";
    value123.textBaseline = "middle";
    value123.fillText(value131, value128, value129);
    value123.strokeStyle = "rgba(150, 0, 100, 0.4)";
    value123.lineWidth = 2;
    value123.beginPath();
    value123.arc(value128, value129, value130 * 0.8, 0, Math.PI * 2);
    value123.stroke();
  }
  value123.restore();
}
function addBloodDrops(value132, value133, value134) {
  value132.save();
  value132.globalAlpha = 0.7;
  for (let value135 = 0; value135 < 10; value135++) {
    const value136 = Math.random() * value133;
    const value137 = Math.random() * value134;
    const value138 = 2 + Math.random() * 4;
    const value139 = value132.createRadialGradient(value136, value137, 0, value136, value137, value138);
    value139.addColorStop(0, "rgba(150, 0, 0, 0.9)");
    value139.addColorStop(1, "rgba(100, 0, 0, 0.6)");
    value132.fillStyle = value139;
    value132.beginPath();
    value132.arc(value136, value137, value138, 0, Math.PI * 2);
    value132.fill();
    const value140 = 3 + Math.random() * 8;
    value132.strokeStyle = "rgba(150, 0, 0, 0.6)";
    value132.lineWidth = value138 * 0.5;
    value132.lineCap = "round";
    value132.beginPath();
    value132.moveTo(value136, value137);
    value132.lineTo(value136, value137 + value140);
    value132.stroke();
  }
  value132.restore();
}
function addSoulParticles(value141, value142, value143) {
  value141.save();
  value141.globalCompositeOperation = "screen";
  for (let value144 = 0; value144 < 25; value144++) {
    const value145 = Math.random() * value142;
    const value146 = Math.random() * value143;
    const value147 = 1 + Math.random() * 3;
    const value148 = 300 + Math.random() * 60;
    value141.fillStyle = "hsla(" + value148 + ", 100%, 70%, 0.8)";
    value141.beginPath();
    value141.arc(value145, value146, value147, 0, Math.PI * 2);
    value141.fill();
    const value149 = 5 + Math.random() * 10;
    const value150 = Math.random() * Math.PI * 2;
    value141.strokeStyle = "hsla(" + value148 + ", 100%, 70%, 0.5)";
    value141.lineWidth = value147 * 0.5;
    value141.lineCap = "round";
    value141.beginPath();
    value141.moveTo(value145, value146);
    value141.lineTo(value145 + Math.cos(value150) * value149, value146 + Math.sin(value150) * value149);
    value141.stroke();
  }
  value141.restore();
}
function drawForbiddenBorder(value151, value152, value153) {
  value151.save();
  const value154 = value151.createLinearGradient(0, 0, value152, 0);
  value154.addColorStop(0, "#640064");
  value154.addColorStop(0.3, "#960096");
  value154.addColorStop(0.5, "#C80064");
  value154.addColorStop(0.7, "#960096");
  value154.addColorStop(1, "#640064");
  value151.strokeStyle = value154;
  value151.lineWidth = 10;
  value151.shadowColor = "rgba(100, 0, 50, 0.6)";
  value151.shadowBlur = 20;
  value151.strokeRect(10, 10, value152 - 20, value153 - 20);
  value151.strokeStyle = "rgba(150, 0, 100, 0.6)";
  value151.lineWidth = 3;
  value151.shadowBlur = 15;
  value151.strokeRect(20, 20, value152 - 40, value153 - 40);
  addOccultCorners(value151, value152, value153);
  value151.restore();
}
function addOccultCorners(value155, value156, value157) {
  value155.save();
  value155.globalAlpha = 0.8;
  const value158 = [{
    x: 30,
    y: 30
  }, {
    x: value156 - 30,
    y: 30
  }, {
    x: 30,
    y: value157 - 30
  }, {
    x: value156 - 30,
    y: value157 - 30
  }];
  value158.forEach(value159 => {
    value155.strokeStyle = "rgba(150, 0, 100, 0.8)";
    value155.lineWidth = 2;
    value155.beginPath();
    value155.arc(value159.x, value159.y, 8, 0, Math.PI * 2);
    value155.stroke();
    value155.beginPath();
    value155.moveTo(value159.x - 6, value159.y);
    value155.lineTo(value159.x + 6, value159.y);
    value155.stroke();
    value155.beginPath();
    value155.moveTo(value159.x, value159.y - 6);
    value155.lineTo(value159.x, value159.y + 6);
    value155.stroke();
    value155.beginPath();
    value155.moveTo(value159.x - 4, value159.y - 4);
    value155.lineTo(value159.x + 4, value159.y + 4);
    value155.stroke();
    value155.beginPath();
    value155.moveTo(value159.x + 4, value159.y - 4);
    value155.lineTo(value159.x - 4, value159.y + 4);
    value155.stroke();
  });
  value155.restore();
}
function addDarkSignature(value160, value161, value162) {
  value160.save();
  const value163 = value161 - 110;
  const value164 = value162 - 25;
  value160.font = "italic 14px \"Arial\"";
  value160.fillStyle = "rgba(150, 0, 100, 0.9)";
  value160.textAlign = "right";
  value160.textBaseline = "bottom";
  value160.shadowColor = "rgba(100, 0, 50, 0.6)";
  value160.shadowBlur = 10;
  value160.fillText("by " + getBotName(), value163, value164);
  value160.fillStyle = "rgba(150, 0, 100, 0.8)";
  value160.font = "bold 12px Arial";
  value160.fillText("†", value163 + 5, value164 - 8);
  value160.fillStyle = "rgba(100, 0, 50, 0.3)";
  value160.beginPath();
  value160.arc(value163 + 5, value164 - 8, 6, 0, Math.PI * 2);
  value160.fill();
  value160.restore();
}
