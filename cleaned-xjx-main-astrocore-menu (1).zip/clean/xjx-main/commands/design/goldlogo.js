const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "goldlogo",
  description: "Create luxurious gold style text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "💰 *GOLD LOGO*\n\n*goldlogo*\n" + database.getBotSetting("prefix") + "goldlogo <text>\n\n*Example:*\n" + database.getBotSetting("prefix") + "goldlogo WOLF\n" + database.getBotSetting("prefix") + "goldlogo ROYAL\n" + database.getBotSetting("prefix") + "goldlogo LUXURY\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateGoldLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "💰 *Gold Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [GOLDLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateGoldLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#1a1a1a";
  value16.fillRect(0, 0, value13, value14);
  drawLuxuryBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 100, 0, 300);
  value17.addColorStop(0, "#FFD700");
  value17.addColorStop(0.3, "#FFEC8B");
  value17.addColorStop(0.5, "#DAA520");
  value17.addColorStop(0.7, "#B8860B");
  value17.addColorStop(1, "#8B7500");
  value16.font = "bold 84px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  value16.shadowColor = "#000000";
  value16.shadowBlur = 10;
  value16.shadowOffsetX = 3;
  value16.shadowOffsetY = 3;
  value16.fillStyle = value17;
  value16.fillText(value12.toUpperCase(), value13 / 2, value14 / 2);
  value16.shadowColor = "transparent";
  const value18 = value16.createLinearGradient(0, 150, 0, 200);
  value18.addColorStop(0, "rgba(255, 255, 255, 0.8)");
  value18.addColorStop(1, "rgba(255, 255, 255, 0.2)");
  value16.fillStyle = value18;
  value16.globalCompositeOperation = "screen";
  value16.fillText(value12.toUpperCase(), value13 / 2, value14 / 2 - 2);
  value16.globalCompositeOperation = "source-over";
  drawGoldBorder(value16, value13, value14);
  addLuxuryElements(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawLuxuryBackground(value19, value20, value21) {
  const value22 = value19.createRadialGradient(value20 / 2, value21 / 2, 0, value20 / 2, value21 / 2, value20 / 2);
  value22.addColorStop(0, "#2a2a2a");
  value22.addColorStop(1, "#1a1a1a");
  value19.fillStyle = value22;
  value19.fillRect(0, 0, value20, value21);
  value19.strokeStyle = "rgba(255, 215, 0, 0.1)";
  value19.lineWidth = 1;
  for (let value23 = -value20; value23 < value20 * 2; value23 += 20) {
    value19.beginPath();
    value19.moveTo(value23, 0);
    value19.lineTo(value23 + value21, value21);
    value19.stroke();
  }
  drawCornerDecorations(value19, value20, value21);
}
function drawGoldBorder(value24, value25, value26) {
  const value27 = value24.createLinearGradient(0, 0, value25, value26);
  value27.addColorStop(0, "#FFD700");
  value27.addColorStop(0.5, "#DAA520");
  value27.addColorStop(1, "#FFD700");
  value24.strokeStyle = value27;
  value24.lineWidth = 8;
  value24.shadowColor = "#FFD700";
  value24.shadowBlur = 15;
  value24.strokeRect(20, 20, value25 - 40, value26 - 40);
  value24.strokeStyle = "rgba(255, 215, 0, 0.3)";
  value24.lineWidth = 2;
  value24.shadowBlur = 0;
  value24.strokeRect(30, 30, value25 - 60, value26 - 60);
}
function addLuxuryElements(value28, value29, value30) {
  value28.fillStyle = "#FFD700";
  value28.shadowColor = "#FFD700";
  value28.shadowBlur = 10;
  for (let value31 = 0; value31 < 50; value31++) {
    const value32 = Math.random() * value29;
    const value33 = Math.random() * value30;
    const value34 = Math.random() * 3 + 1;
    value28.beginPath();
    value28.arc(value32, value33, value34, 0, Math.PI * 2);
    value28.fill();
  }
  value28.shadowBlur = 0;
}
function drawCornerDecorations(value35, value36, value37) {
  value35.strokeStyle = "rgba(255, 215, 0, 0.3)";
  value35.lineWidth = 2;
  const value38 = 30;
  value35.beginPath();
  value35.moveTo(20, 20 + value38);
  value35.lineTo(20, 20);
  value35.lineTo(20 + value38, 20);
  value35.stroke();
  value35.beginPath();
  value35.moveTo(value36 - 20 - value38, 20);
  value35.lineTo(value36 - 20, 20);
  value35.lineTo(value36 - 20, 20 + value38);
  value35.stroke();
  value35.beginPath();
  value35.moveTo(20, value37 - 20 - value38);
  value35.lineTo(20, value37 - 20);
  value35.lineTo(20 + value38, value37 - 20);
  value35.stroke();
  value35.beginPath();
  value35.moveTo(value36 - 20 - value38, value37 - 20);
  value35.lineTo(value36 - 20, value37 - 20);
  value35.lineTo(value36 - 20, value37 - 20 - value38);
  value35.stroke();
}
async function generateSimpleGoldLogo(value39) {
  const value40 = 600;
  const value41 = 300;
  const value42 = createCanvas(value40, value41);
  const value43 = value42.getContext("2d");
  value43.fillStyle = "#0a0a0a";
  value43.fillRect(0, 0, value40, value41);
  const value44 = value43.createLinearGradient(0, 50, 0, 250);
  value44.addColorStop(0, "#FFD700");
  value44.addColorStop(0.5, "#DAA520");
  value44.addColorStop(1, "#B8860B");
  value43.font = "bold 70px Arial";
  value43.fillStyle = value44;
  value43.textAlign = "center";
  value43.textBaseline = "middle";
  value43.shadowColor = "#000000";
  value43.shadowBlur = 10;
  value43.shadowOffsetX = 3;
  value43.shadowOffsetY = 3;
  value43.fillText(value39.toUpperCase(), value40 / 2, value41 / 2);
  value43.strokeStyle = "#FFD700";
  value43.lineWidth = 4;
  value43.strokeRect(10, 10, value40 - 20, value41 - 20);
  return value42.toBuffer("image/png");
}
