const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "silverlogo",
  description: "Create realistic silver metallic text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "⚪ *SILVER LOGO*\n\n*silverlogo*\nsilverlogo <text>\n\n*Example:*\nsilverlogo WOLF\nsilverlogo SILVER\nsilverlogo PREMIUM\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateSilverLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "⚪ *Silver Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [SILVERLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateSilverLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#1a1a1a";
  value16.fillRect(0, 0, value13, value14);
  drawSilverBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 100, 0, 300);
  value17.addColorStop(0, "#F8F8F8");
  value17.addColorStop(0.15, "#E8E8E8");
  value17.addColorStop(0.3, "#C0C0C0");
  value17.addColorStop(0.5, "#A8A8A8");
  value17.addColorStop(0.7, "#909090");
  value17.addColorStop(0.85, "#787878");
  value17.addColorStop(1, "#606060");
  value16.font = "bold 84px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createSilver3DEffect(value16, value12, value13, value14, value17);
  addMetallicHighlights(value16, value12, value13, value14);
  drawChromeBorder(value16, value13, value14);
  addReflection(value16, value12, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawSilverBackground(value18, value19, value20) {
  const value21 = value18.createRadialGradient(value19 / 2, value20 / 2, 0, value19 / 2, value20 / 2, Math.max(value19, value20) / 2);
  value21.addColorStop(0, "#2a2a2a");
  value21.addColorStop(0.6, "#1a1a1a");
  value21.addColorStop(1, "#0a0a0a");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  value18.strokeStyle = "rgba(255, 255, 255, 0.03)";
  value18.lineWidth = 1;
  for (let value22 = -value20; value22 < value19 + value20; value22 += 4) {
    value18.beginPath();
    value18.moveTo(value22, 0);
    value18.lineTo(value22 + value20, value20);
    value18.stroke();
  }
  drawCornerAccents(value18, value19, value20);
}
function createSilver3DEffect(value23, value24, value25, value26, value27) {
  const value28 = value25 / 2;
  const value29 = value26 / 2;
  const value30 = 8;
  for (let value31 = value30; value31 > 0; value31--) {
    const value32 = value31;
    const value33 = 0.1 + value31 / value30 * 0.3;
    value23.fillStyle = "rgba(0, 0, 0, " + value33 + ")";
    value23.fillText(value24.toUpperCase(), value28 + value32, value29 + value32);
  }
  value23.fillStyle = value27;
  value23.fillText(value24.toUpperCase(), value28, value29);
  value23.strokeStyle = "rgba(255, 255, 255, 0.3)";
  value23.lineWidth = 1;
  value23.strokeText(value24.toUpperCase(), value28, value29);
}
function addMetallicHighlights(value34, value35, value36, value37) {
  const value38 = value36 / 2;
  const value39 = value37 / 2;
  value34.save();
  const value40 = value34.createLinearGradient(value38 - 200, value39 - 50, value38 + 200, value39 - 20);
  value40.addColorStop(0, "rgba(255, 255, 255, 0.8)");
  value40.addColorStop(0.3, "rgba(255, 255, 255, 0.4)");
  value40.addColorStop(0.7, "rgba(255, 255, 255, 0.2)");
  value40.addColorStop(1, "transparent");
  value34.globalCompositeOperation = "screen";
  value34.fillStyle = value40;
  value34.font = "bold 84px \"Arial\"";
  value34.textAlign = "center";
  value34.textBaseline = "middle";
  value34.fillText(value35.toUpperCase(), value38, value39 - 2);
  value34.globalCompositeOperation = "source-over";
  value34.fillStyle = "rgba(255, 255, 255, 0.6)";
  value34.globalAlpha = 0.3;
  const value41 = value34.measureText(value35.toUpperCase()).width;
  for (let value42 = 0; value42 < 5; value42++) {
    const value43 = value38 - value41 / 2 + Math.random() * value41;
    const value44 = value39 - 40 + Math.random() * 20;
    const value45 = Math.random() * 3 + 1;
    value34.beginPath();
    value34.arc(value43, value44, value45, 0, Math.PI * 2);
    value34.fill();
  }
  value34.restore();
}
function drawChromeBorder(value46, value47, value48) {
  const value49 = value46.createLinearGradient(0, 0, value47, value48);
  value49.addColorStop(0, "#E8E8E8");
  value49.addColorStop(0.3, "#C0C0C0");
  value49.addColorStop(0.5, "#A8A8A8");
  value49.addColorStop(0.7, "#C0C0C0");
  value49.addColorStop(1, "#E8E8E8");
  value46.strokeStyle = value49;
  value46.lineWidth = 6;
  value46.shadowColor = "#C0C0C0";
  value46.shadowBlur = 15;
  value46.strokeRect(20, 20, value47 - 40, value48 - 40);
  value46.strokeStyle = "rgba(255, 255, 255, 0.2)";
  value46.lineWidth = 2;
  value46.shadowBlur = 0;
  value46.strokeRect(30, 30, value47 - 60, value48 - 60);
}
function addReflection(value50, value51, value52, value53) {
  const value54 = value52 / 2;
  const value55 = value53 / 2;
  value50.save();
  value50.translate(value54, value55);
  value50.scale(1, -0.3);
  value50.translate(-value54, -value55);
  const value56 = value50.createLinearGradient(0, value55, 0, value53);
  value56.addColorStop(0, "rgba(192, 192, 192, 0.3)");
  value56.addColorStop(0.5, "rgba(192, 192, 192, 0.1)");
  value56.addColorStop(1, "transparent");
  value50.globalAlpha = 0.2;
  value50.fillStyle = value56;
  value50.font = "bold 84px \"Arial\"";
  value50.textAlign = "center";
  value50.textBaseline = "middle";
  value50.fillText(value51.toUpperCase(), value54, value55);
  value50.restore();
}
function drawCornerAccents(value57, value58, value59) {
  value57.strokeStyle = "rgba(192, 192, 192, 0.3)";
  value57.lineWidth = 2;
  const value60 = 25;
  value57.beginPath();
  value57.moveTo(25, 25 + value60);
  value57.lineTo(25, 25);
  value57.lineTo(25 + value60, 25);
  value57.stroke();
  value57.beginPath();
  value57.moveTo(value58 - 25 - value60, 25);
  value57.lineTo(value58 - 25, 25);
  value57.lineTo(value58 - 25, 25 + value60);
  value57.stroke();
  value57.beginPath();
  value57.moveTo(25, value59 - 25 - value60);
  value57.lineTo(25, value59 - 25);
  value57.lineTo(25 + value60, value59 - 25);
  value57.stroke();
  value57.beginPath();
  value57.moveTo(value58 - 25 - value60, value59 - 25);
  value57.lineTo(value58 - 25, value59 - 25);
  value57.lineTo(value58 - 25, value59 - 25 - value60);
  value57.stroke();
}
async function generateSimpleSilverLogo(value61) {
  const value62 = 600;
  const value63 = 300;
  const value64 = createCanvas(value62, value63);
  const value65 = value64.getContext("2d");
  value65.fillStyle = "#1a1a1a";
  value65.fillRect(0, 0, value62, value63);
  const value66 = value65.createLinearGradient(0, 50, 0, 250);
  value66.addColorStop(0, "#FFFFFF");
  value66.addColorStop(0.3, "#E0E0E0");
  value66.addColorStop(0.6, "#C0C0C0");
  value66.addColorStop(1, "#A0A0A0");
  value65.font = "bold 70px Arial";
  value65.fillStyle = value66;
  value65.textAlign = "center";
  value65.textBaseline = "middle";
  value65.shadowColor = "#000000";
  value65.shadowBlur = 10;
  value65.shadowOffsetX = 3;
  value65.shadowOffsetY = 3;
  value65.fillText(value61.toUpperCase(), value62 / 2, value63 / 2);
  value65.strokeStyle = "#C0C0C0";
  value65.lineWidth = 4;
  value65.strokeRect(10, 10, value62 - 20, value63 - 20);
  return value64.toBuffer("image/png");
}
