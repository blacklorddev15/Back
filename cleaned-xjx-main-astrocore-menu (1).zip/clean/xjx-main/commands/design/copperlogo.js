const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "copperlogo",
  category: "design",
  description: "Create warm copper metallic text logos with natural patina",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🟠 *COPPER LOGO*\n\n*copperlogo*\ncopperlogo <text>\n\n*Example:*\ncopperlogo WOLF\ncopperlogo COPPER\ncopperlogo WARM\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateCopperLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🟠 *Copper Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [COPPERLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateCopperLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#2a1a0a";
  value16.fillRect(0, 0, value13, value14);
  drawNaturalBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 100, 0, 300);
  value17.addColorStop(0, "#FFD700");
  value17.addColorStop(0.15, "#E6B800");
  value17.addColorStop(0.3, "#CD7F32");
  value17.addColorStop(0.45, "#B87333");
  value17.addColorStop(0.6, "#A65A29");
  value17.addColorStop(0.75, "#8B4513");
  value17.addColorStop(0.9, "#654321");
  value17.addColorStop(1, "#4E3524");
  value16.font = "bold 84px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createCopper3DEffect(value16, value12, value13, value14, value17);
  addCopperHighlights(value16, value12, value13, value14);
  addCopperPatina(value16, value12, value13, value14);
  drawCopperBorder(value16, value13, value14);
  addHammeredTexture(value16, value13, value14);
  addSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawNaturalBackground(value18, value19, value20) {
  const value21 = value18.createRadialGradient(value19 / 2, value20 / 2, 0, value19 / 2, value20 / 2, Math.max(value19, value20) / 1.5);
  value21.addColorStop(0, "#3a2a1a");
  value21.addColorStop(0.4, "#2a1a0a");
  value21.addColorStop(0.8, "#1a0a00");
  value21.addColorStop(1, "#0a0500");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  value18.strokeStyle = "rgba(120, 80, 40, 0.1)";
  value18.lineWidth = 1;
  for (let value22 = 0; value22 < 150; value22++) {
    const value23 = Math.random() * value19;
    const value24 = Math.random() * value20;
    const value25 = 15 + Math.random() * 35;
    const value26 = Math.random() * Math.PI * 2;
    const value27 = (Math.random() - 0.5) * 0.5;
    value18.beginPath();
    value18.moveTo(value23, value24);
    value18.quadraticCurveTo(value23 + Math.cos(value26) * value25 * 0.5 + value27 * 20, value24 + Math.sin(value26) * value25 * 0.5 + value27 * 20, value23 + Math.cos(value26) * value25, value24 + Math.sin(value26) * value25);
    value18.stroke();
  }
  value18.fillStyle = "rgba(200, 150, 50, 0.2)";
  for (let value28 = 0; value28 < 50; value28++) {
    const value29 = Math.random() * value19;
    const value30 = Math.random() * value20;
    const value31 = 1 + Math.random() * 3;
    value18.beginPath();
    value18.arc(value29, value30, value31, 0, Math.PI * 2);
    value18.fill();
  }
}
function createCopper3DEffect(value32, value33, value34, value35, value36) {
  const value37 = value34 / 2;
  const value38 = value35 / 2;
  const value39 = 8;
  for (let value40 = value39; value40 > 0; value40--) {
    const value41 = value40 * 1.5;
    const value42 = 0.08 + value40 / value39 * 0.25;
    const value43 = 80 - value40 * 8;
    value32.fillStyle = "rgba(" + value43 + ", " + (value43 - 20) + ", " + (value43 - 40) + ", " + value42 + ")";
    value32.fillText(value33.toUpperCase(), value37 + value41, value38 + value41);
  }
  value32.fillStyle = value36;
  value32.fillText(value33.toUpperCase(), value37, value38);
  value32.strokeStyle = "rgba(255, 200, 100, 0.4)";
  value32.lineWidth = 1.5;
  value32.strokeText(value33.toUpperCase(), value37, value38);
}
function addCopperHighlights(value44, value45, value46, value47) {
  const value48 = value46 / 2;
  const value49 = value47 / 2;
  value44.save();
  const value50 = value44.createLinearGradient(value48 - 250, value49 - 50, value48 + 250, value49 - 10);
  value50.addColorStop(0, "rgba(255, 255, 200, 0)");
  value50.addColorStop(0.3, "rgba(255, 255, 150, 0.6)");
  value50.addColorStop(0.5, "rgba(255, 255, 100, 0.7)");
  value50.addColorStop(0.7, "rgba(255, 255, 150, 0.5)");
  value50.addColorStop(1, "rgba(255, 255, 200, 0)");
  value44.globalCompositeOperation = "screen";
  value44.fillStyle = value50;
  value44.font = "bold 84px \"Arial\"";
  value44.textAlign = "center";
  value44.textBaseline = "middle";
  value44.fillText(value45.toUpperCase(), value48, value49 - 2);
  value44.globalCompositeOperation = "source-over";
  const value51 = value44.measureText(value45.toUpperCase()).width;
  const value52 = [{
    x: -0.35,
    y: -0.35,
    size: 5,
    alpha: 0.8,
    color: "rgba(255, 230, 100, 0.9)"
  }, {
    x: -0.15,
    y: -0.4,
    size: 6,
    alpha: 0.9,
    color: "rgba(255, 220, 80, 0.9)"
  }, {
    x: 0.05,
    y: -0.35,
    size: 4,
    alpha: 0.7,
    color: "rgba(255, 240, 120, 0.8)"
  }, {
    x: 0.25,
    y: -0.4,
    size: 5,
    alpha: 0.8,
    color: "rgba(255, 230, 100, 0.9)"
  }, {
    x: 0.4,
    y: -0.3,
    size: 3,
    alpha: 0.6,
    color: "rgba(255, 240, 130, 0.7)"
  }];
  value52.forEach(value53 => {
    const value54 = value48 + value53.x * value51 / 2;
    const value55 = value49 + value53.y * 45;
    value44.fillStyle = value53.color.replace(")", ", " + value53.alpha + ")").replace("a(", "a(");
    value44.beginPath();
    value44.arc(value54, value55, value53.size, 0, Math.PI * 2);
    value44.fill();
  });
  value44.restore();
}
function addCopperPatina(value56, value57, value58, value59) {
  const value60 = value58 / 2;
  const value61 = value59 / 2;
  value56.save();
  const value62 = value56.createLinearGradient(value60 - 200, value61 + 40, value60 + 200, value61 - 30);
  value62.addColorStop(0, "rgba(83, 130, 85, 0.2)");
  value62.addColorStop(0.4, "rgba(67, 111, 77, 0.3)");
  value62.addColorStop(0.7, "rgba(53, 94, 59, 0.2)");
  value62.addColorStop(1, "transparent");
  value56.globalCompositeOperation = "overlay";
  value56.fillStyle = value62;
  value56.font = "bold 84px \"Arial\"";
  value56.textAlign = "center";
  value56.textBaseline = "middle";
  value56.fillText(value57.toUpperCase(), value60, value61);
  value56.globalCompositeOperation = "source-over";
  const value63 = value56.measureText(value57.toUpperCase()).width;
  const value64 = [{
    x: -0.3,
    y: 0.25,
    size: 8,
    alpha: 0.4,
    color: "rgba(64, 130, 109, 0.5)"
  }, {
    x: -0.1,
    y: -0.15,
    size: 6,
    alpha: 0.3,
    color: "rgba(72, 140, 120, 0.4)"
  }, {
    x: 0.15,
    y: 0.35,
    size: 10,
    alpha: 0.5,
    color: "rgba(60, 125, 105, 0.6)"
  }, {
    x: 0.35,
    y: -0.25,
    size: 7,
    alpha: 0.4,
    color: "rgba(68, 135, 115, 0.5)"
  }, {
    x: 0.45,
    y: 0.15,
    size: 5,
    alpha: 0.3,
    color: "rgba(76, 145, 125, 0.4)"
  }];
  value64.forEach(value65 => {
    const value66 = value60 + value65.x * value63 / 2;
    const value67 = value61 + value65.y * 40;
    value56.fillStyle = value65.color.replace(")", ", " + value65.alpha + ")").replace("a(", "a(");
    value56.beginPath();
    value56.arc(value66, value67, value65.size, 0, Math.PI * 2);
    value56.fill();
    value56.fillStyle = value65.color.replace(")", ", " + value65.alpha * 0.7 + ")").replace("a(", "a(");
    value56.beginPath();
    value56.arc(value66 - value65.size * 0.3, value67 - value65.size * 0.3, value65.size * 0.5, 0, Math.PI * 2);
    value56.fill();
  });
  value56.restore();
}
function drawCopperBorder(value68, value69, value70) {
  const value71 = value68.createLinearGradient(0, 0, value69, value70);
  value71.addColorStop(0, "#FFD700");
  value71.addColorStop(0.25, "#E6B800");
  value71.addColorStop(0.5, "#B87333");
  value71.addColorStop(0.75, "#E6B800");
  value71.addColorStop(1, "#FFD700");
  value68.strokeStyle = value71;
  value68.lineWidth = 8;
  value68.shadowColor = "rgba(184, 115, 51, 0.5)";
  value68.shadowBlur = 15;
  value68.strokeRect(18, 18, value69 - 36, value70 - 36);
  value68.strokeStyle = "rgba(255, 200, 100, 0.4)";
  value68.lineWidth = 2;
  value68.shadowBlur = 0;
  value68.strokeRect(30, 30, value69 - 60, value70 - 60);
  drawCopperRivets(value68, value69, value70);
}
function drawCopperRivets(value72, value73, value74) {
  value72.fillStyle = "#B87333";
  const value75 = [{
    x: 35,
    y: 35
  }, {
    x: value73 - 35,
    y: 35
  }, {
    x: 35,
    y: value74 - 35
  }, {
    x: value73 - 35,
    y: value74 - 35
  }, {
    x: value73 / 2,
    y: 35
  }, {
    x: value73 / 2,
    y: value74 - 35
  }];
  value75.forEach(value76 => {
    value72.beginPath();
    value72.arc(value76.x, value76.y, 6, 0, Math.PI * 2);
    value72.fill();
    value72.fillStyle = "rgba(255, 215, 0, 0.6)";
    value72.beginPath();
    value72.arc(value76.x - 2, value76.y - 2, 2, 0, Math.PI * 2);
    value72.fill();
    value72.fillStyle = "#B87333";
  });
}
function addHammeredTexture(value77, value78, value79) {
  value77.save();
  value77.globalAlpha = 0.2;
  for (let value80 = 0; value80 < 80; value80++) {
    const value81 = Math.random() * value78;
    const value82 = Math.random() * value79;
    const value83 = 2 + Math.random() * 5;
    value77.fillStyle = "rgba(" + (180 + Math.random() * 40) + ", " + (120 + Math.random() * 30) + ", " + (50 + Math.random() * 20) + ", 0.8)";
    value77.beginPath();
    value77.arc(value81, value82, value83, 0, Math.PI * 2);
    value77.fill();
    value77.fillStyle = "rgba(255, 230, 150, 0.4)";
    value77.beginPath();
    value77.arc(value81 - value83 * 0.3, value82 - value83 * 0.3, value83 * 0.3, 0, Math.PI * 2);
    value77.fill();
  }
  value77.strokeStyle = "rgba(139, 69, 19, 0.3)";
  value77.lineWidth = 0.8;
  for (let value84 = 0; value84 < 40; value84++) {
    const value85 = Math.random() * value78;
    const value86 = Math.random() * value79;
    const value87 = 8 + Math.random() * 25;
    const value88 = Math.random() * Math.PI;
    value77.beginPath();
    value77.moveTo(value85, value86);
    value77.lineTo(value85 + Math.cos(value88) * value87, value86 + Math.sin(value88) * value87);
    value77.stroke();
  }
  value77.restore();
}
function addSignature(value89, value90, value91) {
  value89.save();
  const value92 = value90 - 120;
  const value93 = value91 - 20;
  value89.font = "italic 12px \"Arial\"";
  value89.fillStyle = "rgba(184, 115, 51, 0.7)";
  value89.textAlign = "right";
  value89.textBaseline = "bottom";
  value89.fillText("by " + getBotName(), value92, value93);
  value89.strokeStyle = "rgba(184, 115, 51, 0.4)";
  value89.lineWidth = 0.5;
  const value94 = value89.measureText("by " + getBotName()).width;
  value89.beginPath();
  value89.moveTo(value92 - value94, value93 + 2);
  value89.lineTo(value92, value93 + 2);
  value89.stroke();
  value89.restore();
}
async function generateSimpleCopperLogo(value95) {
  const value96 = 600;
  const value97 = 300;
  const value98 = createCanvas(value96, value97);
  const value99 = value98.getContext("2d");
  value99.fillStyle = "#2a1a0a";
  value99.fillRect(0, 0, value96, value97);
  const value100 = value99.createLinearGradient(0, 50, 0, 250);
  value100.addColorStop(0, "#FFD700");
  value100.addColorStop(0.4, "#E6B800");
  value100.addColorStop(0.7, "#B87333");
  value100.addColorStop(1, "#8B4513");
  value99.font = "bold 70px Arial";
  value99.fillStyle = value100;
  value99.textAlign = "center";
  value99.textBaseline = "middle";
  value99.shadowColor = "rgba(184, 115, 51, 0.5)";
  value99.shadowBlur = 15;
  value99.shadowOffsetX = 4;
  value99.shadowOffsetY = 4;
  value99.fillText(value95.toUpperCase(), value96 / 2, value97 / 2);
  value99.strokeStyle = "#B87333";
  value99.lineWidth = 5;
  value99.strokeRect(15, 15, value96 - 30, value97 - 30);
  value99.font = "italic 10px \"Arial\"";
  value99.fillStyle = "rgba(184, 115, 51, 0.7)";
  value99.textAlign = "right";
  value99.textBaseline = "bottom";
  value99.fillText("by " + getBotName(), value96 - 20, value97 - 15);
  return value98.toBuffer("image/png");
}
