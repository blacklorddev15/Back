const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "iceglowlogo",
  description: "Create glowing ice text logos with radiant light effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "💠 *ICE GLOW LOGO*\n\n*iceglowlogo*\niceglowlogo <text>\n\n*Example:*\niceglowlogo WOLF\niceglowlogo GLOW\niceglowlogo FROZEN\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 12) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 12 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateIceGlowLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "💠 *Ice Glow Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [ICEGLOWLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateIceGlowLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  value16.fillStyle = "#050a14";
  value16.fillRect(0, 0, value13, value14);
  drawGlowingBackground(value16, value13, value14);
  const value17 = value16.createLinearGradient(0, 80, 0, 320);
  value17.addColorStop(0, "#FFFFFF");
  value17.addColorStop(0.2, "#B8F8FF");
  value17.addColorStop(0.4, "#80F0FF");
  value17.addColorStop(0.6, "#48E8FF");
  value17.addColorStop(0.8, "#20E0FF");
  value17.addColorStop(1, "#00D8FF");
  value16.font = "bold 86px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createIceGlowEffect(value16, value12, value13, value14, value17);
  addLightRays(value16, value13, value14);
  addGlowParticles(value16, value13, value14);
  addCrystalGlow(value16, value12, value13, value14);
  drawRadiantBorder(value16, value13, value14);
  addSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawGlowingBackground(value18, value19, value20) {
  const value21 = value18.createRadialGradient(value19 / 2, value20 / 2, 0, value19 / 2, value20 / 2, Math.max(value19, value20) / 1.2);
  value21.addColorStop(0, "#001a33");
  value21.addColorStop(0.3, "#000a1a");
  value21.addColorStop(0.7, "#000514");
  value21.addColorStop(1, "#000000");
  value18.fillStyle = value21;
  value18.fillRect(0, 0, value19, value20);
  value18.fillStyle = "#FFFFFF";
  for (let value22 = 0; value22 < 100; value22++) {
    const value23 = Math.random() * value19;
    const value24 = Math.random() * value20;
    const value25 = Math.random() * 1.5;
    const value26 = 0.3 + Math.random() * 0.7;
    value18.globalAlpha = value26;
    value18.beginPath();
    value18.arc(value23, value24, value25, 0, Math.PI * 2);
    value18.fill();
  }
  value18.globalAlpha = 1;
  const value27 = value18.createLinearGradient(0, 0, 0, value20);
  value27.addColorStop(0, "rgba(0, 100, 255, 0.1)");
  value27.addColorStop(0.5, "rgba(0, 200, 255, 0.05)");
  value27.addColorStop(1, "rgba(0, 150, 255, 0.08)");
  value18.fillStyle = value27;
  value18.fillRect(0, 0, value19, value20);
  addNebulaClouds(value18, value19, value20);
}
function addNebulaClouds(value28, value29, value30) {
  value28.save();
  value28.globalAlpha = 0.3;
  const value31 = [{
    x: value29 * 0.2,
    y: value30 * 0.3,
    size: 120,
    color: "rgba(0, 100, 255, 0.4)"
  }, {
    x: value29 * 0.7,
    y: value30 * 0.2,
    size: 90,
    color: "rgba(0, 150, 255, 0.3)"
  }, {
    x: value29 * 0.3,
    y: value30 * 0.7,
    size: 110,
    color: "rgba(0, 80, 255, 0.35)"
  }, {
    x: value29 * 0.8,
    y: value30 * 0.6,
    size: 80,
    color: "rgba(0, 120, 255, 0.25)"
  }];
  value31.forEach(value32 => {
    const value33 = value28.createRadialGradient(value32.x, value32.y, 0, value32.x, value32.y, value32.size);
    value33.addColorStop(0, value32.color);
    value33.addColorStop(1, "transparent");
    value28.fillStyle = value33;
    value28.beginPath();
    value28.arc(value32.x, value32.y, value32.size, 0, Math.PI * 2);
    value28.fill();
  });
  value28.restore();
}
function createIceGlowEffect(value34, value35, value36, value37, value38) {
  const value39 = value36 / 2;
  const value40 = value37 / 2;
  const value41 = [{
    blur: 50,
    alpha: 0.3,
    offset: 0,
    color: "#00D8FF"
  }, {
    blur: 40,
    alpha: 0.4,
    offset: 0,
    color: "#20E0FF"
  }, {
    blur: 30,
    alpha: 0.5,
    offset: 0,
    color: "#48E8FF"
  }, {
    blur: 20,
    alpha: 0.6,
    offset: 0,
    color: "#80F0FF"
  }, {
    blur: 10,
    alpha: 0.7,
    offset: 0,
    color: "#B8F8FF"
  }];
  for (const value42 of value41) {
    value34.shadowColor = value42.color;
    value34.shadowBlur = value42.blur;
    value34.fillStyle = "rgba(255, 255, 255, " + value42.alpha + ")";
    value34.fillText(value35.toUpperCase(), value39, value40 + value42.offset);
  }
  value34.shadowColor = "transparent";
  value34.shadowBlur = 0;
  value34.fillStyle = value38;
  value34.fillText(value35.toUpperCase(), value39, value40);
  value34.save();
  value34.globalCompositeOperation = "screen";
  value34.fillStyle = "rgba(180, 240, 255, 0.6)";
  value34.fillText(value35.toUpperCase(), value39, value40);
  value34.restore();
  value34.strokeStyle = "rgba(255, 255, 255, 0.8)";
  value34.lineWidth = 1.5;
  value34.strokeText(value35.toUpperCase(), value39, value40);
}
function addLightRays(value43, value44, value45) {
  const value46 = value44 / 2;
  const value47 = value45 / 2;
  value43.save();
  value43.globalAlpha = 0.4;
  for (let value48 = 0; value48 < 16; value48++) {
    const value49 = value48 / 16 * Math.PI * 2;
    const value50 = 450;
    const value51 = Math.sin(Date.now() * 0.001 + value48) * 0.2 + 0.8;
    const value52 = value43.createLinearGradient(value46, value47, value46 + Math.cos(value49) * value50, value47 + Math.sin(value49) * value50);
    value52.addColorStop(0, "rgba(0, 216, 255, " + value51 * 0.9 + ")");
    value52.addColorStop(0.7, "rgba(0, 150, 255, " + value51 * 0.5 + ")");
    value52.addColorStop(1, "transparent");
    value43.strokeStyle = value52;
    value43.lineWidth = 12;
    value43.beginPath();
    value43.moveTo(value46, value47);
    value43.lineTo(value46 + Math.cos(value49) * value50, value47 + Math.sin(value49) * value50);
    value43.stroke();
  }
  value43.restore();
}
function addGlowParticles(value53, value54, value55) {
  const value56 = value54 / 2;
  const value57 = value55 / 2;
  value53.save();
  value53.globalAlpha = 0.8;
  for (let value58 = 0; value58 < 60; value58++) {
    const value59 = Math.random() * Math.PI * 2;
    const value60 = 50 + Math.random() * 200;
    const value61 = 1 + Math.random() * 4;
    const value62 = Math.sin(Date.now() * 0.002 + value58) * 0.3 + 0.7;
    const value63 = value56 + Math.cos(value59) * value60;
    const value64 = value57 + Math.sin(value59) * value60;
    const value65 = value53.createRadialGradient(value63, value64, 0, value63, value64, value61 * 3);
    value65.addColorStop(0, "rgba(0, 216, 255, " + value62 * 0.9 + ")");
    value65.addColorStop(0.5, "rgba(0, 150, 255, " + value62 * 0.6 + ")");
    value65.addColorStop(1, "transparent");
    value53.fillStyle = value65;
    value53.beginPath();
    value53.arc(value63, value64, value61 * 3, 0, Math.PI * 2);
    value53.fill();
  }
  for (let value66 = 0; value66 < 25; value66++) {
    const value67 = Math.random() * value54;
    const value68 = Math.random() * value55;
    const value69 = 2 + Math.random() * 3;
    const value70 = 0.7 + Math.random() * 0.3;
    value53.fillStyle = "rgba(255, 255, 255, " + value70 + ")";
    value53.beginPath();
    for (let value71 = 0; value71 < 5; value71++) {
      const value72 = value71 * Math.PI * 2 / 5;
      const value73 = value69;
      const value74 = value69 * 0.4;
      value53.lineTo(value67 + Math.cos(value72) * value73, value68 + Math.sin(value72) * value73);
      value53.lineTo(value67 + Math.cos(value72 + Math.PI / 5) * value74, value68 + Math.sin(value72 + Math.PI / 5) * value74);
    }
    value53.closePath();
    value53.fill();
    value53.shadowColor = "rgba(0, 216, 255, 0.8)";
    value53.shadowBlur = 10;
    value53.fill();
  }
  value53.restore();
}
function addCrystalGlow(value75, value76, value77, value78) {
  const value79 = value77 / 2;
  const value80 = value78 / 2;
  const value81 = value75.measureText(value76.toUpperCase()).width;
  value75.save();
  value75.globalAlpha = 0.9;
  const value82 = [{
    x: -0.35,
    y: -0.3,
    size: 6,
    intensity: 0.9
  }, {
    x: -0.2,
    y: -0.4,
    size: 7,
    intensity: 1
  }, {
    x: -0.05,
    y: -0.35,
    size: 5,
    intensity: 0.8
  }, {
    x: 0.1,
    y: -0.4,
    size: 6,
    intensity: 0.9
  }, {
    x: 0.25,
    y: -0.3,
    size: 5,
    intensity: 0.8
  }, {
    x: 0.35,
    y: -0.25,
    size: 4,
    intensity: 0.7
  }, {
    x: -0.3,
    y: 0.2,
    size: 3,
    intensity: 0.6
  }, {
    x: 0.25,
    y: 0.25,
    size: 3,
    intensity: 0.6
  }];
  value82.forEach(value83 => {
    const value84 = value79 + value83.x * value81 / 2;
    const value85 = value80 + value83.y * 45;
    const value86 = value75.createRadialGradient(value84, value85, 0, value84, value85, value83.size * 2);
    value86.addColorStop(0, "rgba(255, 255, 255, " + value83.intensity + ")");
    value86.addColorStop(0.7, "rgba(0, 216, 255, " + value83.intensity * 0.7 + ")");
    value86.addColorStop(1, "transparent");
    value75.fillStyle = value86;
    value75.beginPath();
    value75.arc(value84, value85, value83.size * 2, 0, Math.PI * 2);
    value75.fill();
    value75.fillStyle = "rgba(255, 255, 255, " + value83.intensity + ")";
    value75.beginPath();
    value75.arc(value84, value85, value83.size * 0.5, 0, Math.PI * 2);
    value75.fill();
  });
  value75.restore();
}
function drawRadiantBorder(value87, value88, value89) {
  const value90 = value87.createLinearGradient(0, 0, value88, value89);
  value90.addColorStop(0, "#B8F8FF");
  value90.addColorStop(0.25, "#80F0FF");
  value90.addColorStop(0.5, "#20E0FF");
  value90.addColorStop(0.75, "#80F0FF");
  value90.addColorStop(1, "#B8F8FF");
  value87.strokeStyle = value90;
  value87.lineWidth = 8;
  value87.shadowColor = "rgba(0, 216, 255, 0.8)";
  value87.shadowBlur = 25;
  value87.strokeRect(12, 12, value88 - 24, value89 - 24);
  value87.strokeStyle = "rgba(180, 240, 255, 0.6)";
  value87.lineWidth = 3;
  value87.shadowBlur = 15;
  value87.strokeRect(20, 20, value88 - 40, value89 - 40);
  value87.strokeStyle = "rgba(255, 255, 255, 0.4)";
  value87.lineWidth = 1;
  value87.shadowBlur = 0;
  value87.strokeRect(28, 28, value88 - 56, value89 - 56);
  addCornerGlow(value87, value88, value89);
}
function addCornerGlow(value91, value92, value93) {
  value91.save();
  value91.globalAlpha = 0.6;
  const value94 = [{
    x: 25,
    y: 25
  }, {
    x: value92 - 25,
    y: 25
  }, {
    x: 25,
    y: value93 - 25
  }, {
    x: value92 - 25,
    y: value93 - 25
  }];
  value94.forEach(value95 => {
    const value96 = value91.createRadialGradient(value95.x, value95.y, 0, value95.x, value95.y, 20);
    value96.addColorStop(0, "rgba(0, 216, 255, 0.9)");
    value96.addColorStop(1, "transparent");
    value91.fillStyle = value96;
    value91.beginPath();
    value91.arc(value95.x, value95.y, 20, 0, Math.PI * 2);
    value91.fill();
  });
  value91.restore();
}
function addSignature(value97, value98, value99) {
  value97.save();
  const value100 = value98 - 120;
  const value101 = value99 - 20;
  value97.font = "italic 12px \"Arial\"";
  value97.fillStyle = "rgba(0, 216, 255, 0.8)";
  value97.textAlign = "right";
  value97.textBaseline = "bottom";
  value97.shadowColor = "rgba(0, 150, 255, 0.6)";
  value97.shadowBlur = 5;
  value97.fillText("by " + getBotName(), value100, value101);
  value97.strokeStyle = "rgba(0, 216, 255, 0.5)";
  value97.lineWidth = 0.8;
  const value102 = value97.measureText("by " + getBotName()).width;
  value97.beginPath();
  value97.moveTo(value100 - value102, value101 + 2);
  value97.lineTo(value100, value101 + 2);
  value97.stroke();
  value97.shadowColor = "transparent";
  value97.shadowBlur = 0;
  value97.restore();
}
