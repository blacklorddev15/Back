const database = require("../../database");
module.exports = {
  name: "logomenu",
  aliases: ["logos", "logohelp", "logocmds", "designmenu"],
  category: "design",
  description: "Show available logo design commands",
  usage: ".logomenu",
  async execute(value1, value2) {
    const value3 = value2.key.remoteJid;
    const value4 = database.getBotSetting("prefix") || ".";
    const value5 = database.getBotSetting("botName") || "JuneX-Ultra";
    const value6 = "🌟 Premium metals\n\n• " + value4 + "goldlogo\n• " + value4 + "silverlogo\n• " + value4 + "platinumlogo\n• " + value4 + "chromelogo\n• " + value4 + "diamondlogo\n• " + value4 + "bronzelogo\n• " + value4 + "steellogo\n• " + value4 + "copperlogo\n• " + value4 + "titaniumlogo\n\n🔥 Elemental effects\n\n• " + value4 + "firelogo\n• " + value4 + "icelogo\n• " + value4 + "iceglowlogo\n• " + value4 + "lightninglogo\n• " + value4 + "rainbowlogo\n• " + value4 + "sunlogo\n• " + value4 + "moonlogo\n\n🎭 Mythical and magical\n\n• " + value4 + "dragonlogo\n• " + value4 + "phoenixlogo\n• " + value4 + "wizardlogo\n• " + value4 + "crystallogo\n• " + value4 + "darkmagiclogo\n\n🌌 Dark and gothic\n\n• " + value4 + "shadowlogo\n• " + value4 + "smokelogo\n• " + value4 + "bloodlogo\n\n💫 Glow and neon\n\n• " + value4 + "neonlogo\n• " + value4 + "glowlogo\n• " + value4 + "gradientlogo\n• " + value4 + "matrixlogo\n• " + value4 + "aqualogo\n\nPowered by " + value5 + "\nUse " + value4 + "<command> followed by your text.";
    await value1.sendMessage(value3, {
      text: "🎨 *LOGO DESIGN MENU*\n\n" + value6
    }, {
      quoted: value2
    });
  }
};
