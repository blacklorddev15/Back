const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "chromelogo",
  category: "design",
  description: "Create shiny chrome reflective text logos",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "✨ *CHROME LOGO*\n\n*chromelogo*\nchromelogo <text>\n\n*Example:*\nchromelogo WOLF\nchromelogo CHROME\nchromelogo SHINE\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 15 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateChromeLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "✨ *Chrome Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [CHROMELOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateChromeLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  const value17 = value16.createLinearGradient(0, 0, value13, value14);
  value17.addColorStop(0, "#2a2a2a");
  value17.addColorStop(0.5, "#1a1a1a");
  value17.addColorStop(1, "#0a0a0a");
  value16.fillStyle = value17;
  value16.fillRect(0, 0, value13, value14);
  drawChromeEnvironment(value16, value13, value14);
  const value18 = value16.createLinearGradient(0, 80, 0, 320);
  value18.addColorStop(0, "#FFFFFF");
  value18.addColorStop(0.1, "#F0F0F0");
  value18.addColorStop(0.2, "#D0D0D0");
  value18.addColorStop(0.35, "#A0A0A0");
  value18.addColorStop(0.5, "#707070");
  value18.addColorStop(0.65, "#404040");
  value18.addColorStop(0.8, "#202020");
  value18.addColorStop(0.9, "#000000");
  value18.addColorStop(1, "#303030");
  value16.font = "bold 88px \"Arial\"";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  createChromeReflectionEffect(value16, value12, value13, value14, value18);
  addChromeHighlights(value16, value12, value13, value14);
  drawChromeBorder(value16, value13, value14);
  addLightSources(value16, value13, value14);
  addChromeImperfections(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function drawChromeEnvironment(value19, value20, value21) {
  const value22 = [{
    x: value20 * 0.2,
    y: value21 * 0.3,
    size: 80,
    color: "rgba(255, 255, 255, 0.1)"
  }, {
    x: value20 * 0.8,
    y: value21 * 0.2,
    size: 60,
    color: "rgba(255, 255, 255, 0.08)"
  }, {
    x: value20 * 0.3,
    y: value21 * 0.7,
    size: 70,
    color: "rgba(255, 255, 255, 0.06)"
  }, {
    x: value20 * 0.7,
    y: value21 * 0.6,
    size: 50,
    color: "rgba(255, 255, 255, 0.05)"
  }];
  value22.forEach(value23 => {
    const value24 = value19.createRadialGradient(value23.x, value23.y, 0, value23.x, value23.y, value23.size);
    value24.addColorStop(0, value23.color);
    value24.addColorStop(1, "transparent");
    value19.fillStyle = value24;
    value19.beginPath();
    value19.arc(value23.x, value23.y, value23.size, 0, Math.PI * 2);
    value19.fill();
  });
  value19.strokeStyle = "rgba(100, 100, 100, 0.1)";
  value19.lineWidth = 1;
  for (let value25 = 0; value25 < value21; value25 += 40) {
    value19.beginPath();
    value19.moveTo(0, value25);
    value19.lineTo(value20, value25);
    value19.stroke();
  }
  for (let value26 = 0; value26 < value20; value26 += 40) {
    value19.beginPath();
    value19.moveTo(value26, 0);
    value19.lineTo(value26, value21);
    value19.stroke();
  }
}
function createChromeReflectionEffect(value27, value28, value29, value30, value31) {
  const value32 = value29 / 2;
  const value33 = value30 / 2;
  value27.shadowColor = "rgba(0, 0, 0, 0.6)";
  value27.shadowBlur = 20;
  value27.shadowOffsetX = 8;
  value27.shadowOffsetY = 8;
  value27.fillStyle = "rgba(0, 0, 0, 0.4)";
  value27.fillText(value28.toUpperCase(), value32 + 5, value33 + 5);
  value27.shadowColor = "transparent";
  value27.shadowBlur = 0;
  value27.shadowOffsetX = 0;
  value27.shadowOffsetY = 0;
  value27.fillStyle = value31;
  value27.fillText(value28.toUpperCase(), value32, value33);
  value27.strokeStyle = "rgba(255, 255, 255, 0.3)";
  value27.lineWidth = 1;
  value27.strokeText(value28.toUpperCase(), value32, value33);
}
function addChromeHighlights(value34, value35, value36, value37) {
  const value38 = value36 / 2;
  const value39 = value37 / 2;
  value34.save();
  const value40 = value34.createLinearGradient(value38 - 300, value39 - 80, value38 + 300, value39 - 20);
  value40.addColorStop(0, "rgba(255, 255, 255, 0)");
  value40.addColorStop(0.2, "rgba(255, 255, 255, 0.8)");
  value40.addColorStop(0.4, "rgba(255, 255, 255, 0.9)");
  value40.addColorStop(0.6, "rgba(255, 255, 255, 0.7)");
  value40.addColorStop(0.8, "rgba(255, 255, 255, 0.3)");
  value40.addColorStop(1, "rgba(255, 255, 255, 0)");
  value34.globalCompositeOperation = "screen";
  value34.fillStyle = value40;
  value34.font = "bold 88px \"Arial\"";
  value34.textAlign = "center";
  value34.textBaseline = "middle";
  value34.fillText(value35.toUpperCase(), value38, value39 - 2);
  value34.globalCompositeOperation = "source-over";
  const value41 = value34.measureText(value35.toUpperCase()).width;
  const value42 = [{
    x: -0.35,
    y: -0.4,
    size: 6,
    alpha: 0.9
  }, {
    x: -0.15,
    y: -0.45,
    size: 8,
    alpha: 0.8
  }, {
    x: 0.05,
    y: -0.4,
    size: 7,
    alpha: 0.85
  }, {
    x: 0.25,
    y: -0.45,
    size: 6,
    alpha: 0.8
  }, {
    x: 0.4,
    y: -0.35,
    size: 5,
    alpha: 0.7
  }];
  value42.forEach(value43 => {
    const value44 = value38 + value43.x * value41 / 2;
    const value45 = value39 + value43.y * 45;
    value34.fillStyle = "rgba(255, 255, 255, " + value43.alpha + ")";
    value34.beginPath();
    value34.arc(value44, value45, value43.size, 0, Math.PI * 2);
    value34.fill();
    value34.shadowColor = "rgba(255, 255, 255, 0.6)";
    value34.shadowBlur = 10;
    value34.fill();
  });
  value34.restore();
}
function drawChromeBorder(value46, value47, value48) {
  const value49 = value46.createLinearGradient(0, 0, value47, value48);
  value49.addColorStop(0, "#FFFFFF");
  value49.addColorStop(0.15, "#E0E0E0");
  value49.addColorStop(0.3, "#A0A0A0");
  value49.addColorStop(0.5, "#404040");
  value49.addColorStop(0.7, "#A0A0A0");
  value49.addColorStop(0.85, "#E0E0E0");
  value49.addColorStop(1, "#FFFFFF");
  value46.strokeStyle = value49;
  value46.lineWidth = 8;
  value46.shadowColor = "rgba(255, 255, 255, 0.3)";
  value46.shadowBlur = 15;
  value46.strokeRect(12, 12, value47 - 24, value48 - 24);
  value46.strokeStyle = "rgba(255, 255, 255, 0.5)";
  value46.lineWidth = 2;
  value46.shadowBlur = 0;
  value46.strokeRect(25, 25, value47 - 50, value48 - 50);
  drawChromeCorners(value46, value47, value48);
}
function drawChromeCorners(value50, value51, value52) {
  value50.strokeStyle = "rgba(255, 255, 255, 0.6)";
  value50.lineWidth = 3;
  const value53 = 35;
  value50.beginPath();
  value50.moveTo(20, 20 + value53);
  value50.lineTo(20, 20);
  value50.lineTo(20 + value53, 20);
  value50.stroke();
  value50.beginPath();
  value50.moveTo(value51 - 20 - value53, 20);
  value50.lineTo(value51 - 20, 20);
  value50.lineTo(value51 - 20, 20 + value53);
  value50.stroke();
  value50.beginPath();
  value50.moveTo(20, value52 - 20 - value53);
  value50.lineTo(20, value52 - 20);
  value50.lineTo(20 + value53, value52 - 20);
  value50.stroke();
  value50.beginPath();
  value50.moveTo(value51 - 20 - value53, value52 - 20);
  value50.lineTo(value51 - 20, value52 - 20);
  value50.lineTo(value51 - 20, value52 - 20 - value53);
  value50.stroke();
}
function addLightSources(value54, value55, value56) {
  value54.save();
  value54.globalAlpha = 0.3;
  const value57 = [{
    x: value55 * 0.25,
    y: value56 * 0.25,
    size: 15
  }, {
    x: value55 * 0.75,
    y: value56 * 0.3,
    size: 12
  }, {
    x: value55 * 0.35,
    y: value56 * 0.7,
    size: 10
  }, {
    x: value55 * 0.65,
    y: value56 * 0.65,
    size: 8
  }];
  value57.forEach(value58 => {
    const value59 = value54.createRadialGradient(value58.x, value58.y, 0, value58.x, value58.y, value58.size * 3);
    value59.addColorStop(0, "rgba(255, 255, 255, 0.8)");
    value59.addColorStop(0.5, "rgba(255, 255, 255, 0.3)");
    value59.addColorStop(1, "transparent");
    value54.fillStyle = value59;
    value54.beginPath();
    value54.arc(value58.x, value58.y, value58.size * 3, 0, Math.PI * 2);
    value54.fill();
  });
  value54.restore();
}
function addChromeImperfections(value60, value61, value62) {
  value60.save();
  value60.globalAlpha = 0.1;
  value60.strokeStyle = "rgba(255, 255, 255, 0.3)";
  value60.lineWidth = 0.5;
  for (let value63 = 0; value63 < 20; value63++) {
    const value64 = Math.random() * value61;
    const value65 = Math.random() * value62;
    const value66 = 10 + Math.random() * 30;
    const value67 = Math.random() * Math.PI;
    value60.beginPath();
    value60.moveTo(value64, value65);
    value60.lineTo(value64 + Math.cos(value67) * value66, value65 + Math.sin(value67) * value66);
    value60.stroke();
  }
  value60.fillStyle = "rgba(255, 255, 255, 0.2)";
  for (let value68 = 0; value68 < 30; value68++) {
    const value69 = Math.random() * value61;
    const value70 = Math.random() * value62;
    const value71 = Math.random() * 1.5;
    value60.beginPath();
    value60.arc(value69, value70, value71, 0, Math.PI * 2);
    value60.fill();
  }
  value60.restore();
}
async function generateSimpleChromeLogo(value72) {
  const value73 = 600;
  const value74 = 300;
  const value75 = createCanvas(value73, value74);
  const value76 = value75.getContext("2d");
  value76.fillStyle = "#1a1a1a";
  value76.fillRect(0, 0, value73, value74);
  const value77 = value76.createLinearGradient(0, 40, 0, 260);
  value77.addColorStop(0, "#FFFFFF");
  value77.addColorStop(0.2, "#E0E0E0");
  value77.addColorStop(0.4, "#A0A0A0");
  value77.addColorStop(0.6, "#606060");
  value77.addColorStop(0.8, "#A0A0A0");
  value77.addColorStop(1, "#E0E0E0");
  value76.font = "bold 75px Arial";
  value76.fillStyle = value77;
  value76.textAlign = "center";
  value76.textBaseline = "middle";
  value76.shadowColor = "rgba(255, 255, 255, 0.3)";
  value76.shadowBlur = 10;
  value76.fillText(value72.toUpperCase(), value73 / 2, value74 / 2);
  value76.strokeStyle = value77;
  value76.lineWidth = 4;
  value76.strokeRect(10, 10, value73 - 20, value74 - 20);
  return value75.toBuffer("image/png");
}
