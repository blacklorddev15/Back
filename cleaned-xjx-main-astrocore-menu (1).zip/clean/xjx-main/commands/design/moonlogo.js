const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "moonlogo",
  description: "Create stunning text logos with realistic moon background and cosmic effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🌙 *MOON LOGO*\n\n*moonlogo*\nmoonlogo <text>\n\n*Example:*\nmoonlogo LUNA\nmoonlogo MOON\nmoonlogo NIGHT\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateMoonLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🌙 *Moon Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [MOONLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateMoonLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createDeepSpaceBackground(value16, value13, value14);
  const value17 = 120;
  const value18 = value13 * 0.75;
  const value19 = value14 * 0.3;
  drawRealisticMoon(value16, value18, value19, value17);
  addMoonGlow(value16, value18, value19, value17);
  addLensFlare(value16, value18, value19, value17);
  drawCosmicText(value16, value12, value13, value14);
  addDetailedStars(value16, value13, value14);
  addShootingStars(value16, value13, value14);
  addCosmicDust(value16, value13, value14);
  addNebulaBackground(value16, value13, value14);
  drawCosmicBorder(value16, value13, value14);
  addMoonSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createDeepSpaceBackground(value20, value21, value22) {
  const value23 = value20.createRadialGradient(value21 * 0.3, value22 * 0.3, 0, value21, value22, Math.max(value21, value22) * 0.8);
  value23.addColorStop(0, "#0a0a2a");
  value23.addColorStop(0.4, "#070720");
  value23.addColorStop(0.7, "#050515");
  value23.addColorStop(1, "#000005");
  value20.fillStyle = value23;
  value20.fillRect(0, 0, value21, value22);
  addGalaxyClouds(value20, value21, value22);
}
function drawRealisticMoon(value24, value25, value26, value27) {
  value24.save();
  const value28 = value24.createRadialGradient(value25, value26, 0, value25, value26, value27 * 1.5);
  value28.addColorStop(0, "rgba(200, 200, 210, 0.3)");
  value28.addColorStop(0.7, "rgba(150, 150, 170, 0.1)");
  value28.addColorStop(1, "transparent");
  value24.fillStyle = value28;
  value24.beginPath();
  value24.arc(value25, value26, value27 * 1.5, 0, Math.PI * 2);
  value24.fill();
  const value29 = value24.createRadialGradient(value25 - value27 * 0.3, value26 - value27 * 0.2, 0, value25, value26, value27);
  value29.addColorStop(0, "#e8e8e8");
  value29.addColorStop(0.3, "#d0d0d0");
  value29.addColorStop(0.6, "#b0b0b0");
  value29.addColorStop(1, "#8a8a8a");
  value24.fillStyle = value29;
  value24.beginPath();
  value24.arc(value25, value26, value27, 0, Math.PI * 2);
  value24.fill();
  addMoonCraters(value24, value25, value26, value27);
  addMoonSurfaceDetails(value24, value25, value26, value27);
  drawTerminator(value24, value25, value26, value27);
  value24.restore();
}
function addMoonCraters(value30, value31, value32, value33) {
  const value34 = [{
    x: -0.2,
    y: -0.1,
    size: 0.15,
    depth: 0.3
  }, {
    x: 0.3,
    y: 0.2,
    size: 0.12,
    depth: 0.4
  }, {
    x: -0.4,
    y: 0.3,
    size: 0.18,
    depth: 0.5
  }, {
    x: 0.1,
    y: -0.4,
    size: 0.1,
    depth: 0.2
  }, {
    x: 0.5,
    y: -0.1,
    size: 0.08,
    depth: 0.3
  }, {
    x: -0.3,
    y: 0.5,
    size: 0.14,
    depth: 0.4
  }, {
    x: 0.2,
    y: 0.4,
    size: 0.09,
    depth: 0.25
  }, {
    x: -0.5,
    y: -0.2,
    size: 0.11,
    depth: 0.35
  }];
  value34.forEach(value35 => {
    const value36 = value31 + value35.x * value33;
    const value37 = value32 + value35.y * value33;
    const value38 = value35.size * value33;
    const value39 = value30.createRadialGradient(value36 - value38 * 0.2, value37 - value38 * 0.2, 0, value36, value37, value38);
    value39.addColorStop(0, "rgba(120, 120, 120, " + (0.3 + value35.depth * 0.3) + ")");
    value39.addColorStop(1, "rgba(80, 80, 80, " + (0.1 + value35.depth * 0.2) + ")");
    value30.fillStyle = value39;
    value30.beginPath();
    value30.arc(value36, value37, value38, 0, Math.PI * 2);
    value30.fill();
    value30.strokeStyle = "rgba(200, 200, 200, " + (0.2 + value35.depth * 0.2) + ")";
    value30.lineWidth = 1;
    value30.beginPath();
    value30.arc(value36, value37, value38, 0, Math.PI * 2);
    value30.stroke();
  });
}
function addMoonSurfaceDetails(value40, value41, value42, value43) {
  value40.save();
  for (let value44 = 0; value44 < 50; value44++) {
    const value45 = Math.random() * Math.PI * 2;
    const value46 = Math.random() * value43 * 0.8;
    const value47 = value41 + Math.cos(value45) * value46;
    const value48 = value42 + Math.sin(value45) * value46;
    const value49 = 1 + Math.random() * 3;
    const value50 = 140 + Math.random() * 60;
    const value51 = 0.3 + Math.random() * 0.4;
    value40.fillStyle = "rgba(" + value50 + ", " + value50 + ", " + value50 + ", " + value51 + ")";
    value40.beginPath();
    value40.arc(value47, value48, value49, 0, Math.PI * 2);
    value40.fill();
  }
  const value52 = [{
    startAngle: 0.2,
    endAngle: 0.8,
    height: 0.1
  }, {
    startAngle: 1.2,
    endAngle: 1.8,
    height: 0.08
  }, {
    startAngle: 2.5,
    endAngle: 3.2,
    height: 0.12
  }];
  value52.forEach(value53 => {
    value40.strokeStyle = "rgba(180, 180, 180, 0.6)";
    value40.lineWidth = 2;
    value40.beginPath();
    for (let value54 = value53.startAngle; value54 <= value53.endAngle; value54 += 0.1) {
      const value55 = Math.sin(value54 * 10) * value53.height * value43;
      const value56 = value41 + Math.cos(value54) * (value43 + value55);
      const value57 = value42 + Math.sin(value54) * (value43 + value55);
      if (value54 === value53.startAngle) {
        value40.moveTo(value56, value57);
      } else {
        value40.lineTo(value56, value57);
      }
    }
    value40.stroke();
  });
  value40.restore();
}
function drawTerminator(value58, value59, value60, value61) {
  value58.save();
  const value62 = value58.createLinearGradient(value59 - value61, value60, value59 + value61 * 0.3, value60);
  value62.addColorStop(0, "rgba(60, 60, 80, 0.8)");
  value62.addColorStop(0.5, "rgba(100, 100, 120, 0.3)");
  value62.addColorStop(1, "transparent");
  value58.globalCompositeOperation = "multiply";
  value58.fillStyle = value62;
  value58.beginPath();
  value58.arc(value59, value60, value61, Math.PI * 0.5, Math.PI * 1.5);
  value58.fill();
  value58.restore();
}
function addMoonGlow(value63, value64, value65, value66) {
  value63.save();
  const value67 = value63.createRadialGradient(value64, value65, value66 * 0.8, value64, value65, value66 * 2.5);
  value67.addColorStop(0, "rgba(180, 180, 220, 0.2)");
  value67.addColorStop(0.5, "rgba(140, 140, 200, 0.1)");
  value67.addColorStop(1, "transparent");
  value63.fillStyle = value67;
  value63.globalCompositeOperation = "screen";
  value63.beginPath();
  value63.arc(value64, value65, value66 * 2.5, 0, Math.PI * 2);
  value63.fill();
  value63.restore();
}
function addLensFlare(value68, value69, value70, value71) {
  value68.save();
  value68.globalCompositeOperation = "screen";
  value68.globalAlpha = 0.3;
  const value72 = value68.createRadialGradient(value69 - value71 * 0.5, value70 - value71 * 0.5, 0, value69, value70, value71 * 3);
  value72.addColorStop(0, "rgba(255, 255, 255, 0.8)");
  value72.addColorStop(0.3, "rgba(200, 200, 255, 0.4)");
  value72.addColorStop(1, "transparent");
  value68.fillStyle = value72;
  value68.beginPath();
  value68.arc(value69, value70, value71 * 3, 0, Math.PI * 2);
  value68.fill();
  for (let value73 = 0; value73 < 3; value73++) {
    const value74 = value73 / 3 * Math.PI * 2;
    const value75 = value71 * 1.5;
    const value76 = value69 + Math.cos(value74) * value75;
    const value77 = value70 + Math.sin(value74) * value75;
    const value78 = value71 * (0.3 + Math.random() * 0.3);
    const value79 = value68.createRadialGradient(value76, value77, 0, value76, value77, value78);
    value79.addColorStop(0, "rgba(255, 255, 255, 0.6)");
    value79.addColorStop(1, "transparent");
    value68.fillStyle = value79;
    value68.beginPath();
    value68.arc(value76, value77, value78, 0, Math.PI * 2);
    value68.fill();
  }
  value68.restore();
}
function drawCosmicText(value80, value81, value82, value83) {
  const value84 = value82 * 0.35;
  const value85 = value83 * 0.6;
  value80.save();
  value80.shadowColor = "rgba(180, 180, 220, 0.8)";
  value80.shadowBlur = 30;
  const value86 = value80.createLinearGradient(value84 - 100, value85 - 50, value84 + 100, value85 + 50);
  value86.addColorStop(0, "#ffffff");
  value86.addColorStop(0.3, "#e8e8ff");
  value86.addColorStop(0.7, "#c8c8e0");
  value86.addColorStop(1, "#a8a8c0");
  value80.font = "bold 72px \"Arial\"";
  value80.textAlign = "center";
  value80.textBaseline = "middle";
  value80.fillStyle = value86;
  value80.fillText(value81.toUpperCase(), value84, value85);
  value80.shadowColor = "transparent";
  value80.strokeStyle = "rgba(255, 255, 255, 0.8)";
  value80.lineWidth = 2;
  value80.strokeText(value81.toUpperCase(), value84, value85);
  value80.shadowColor = "rgba(0, 0, 30, 0.5)";
  value80.shadowBlur = 15;
  value80.shadowOffsetX = 3;
  value80.shadowOffsetY = 3;
  value80.fillStyle = "rgba(255, 255, 255, 0.9)";
  value80.fillText(value81.toUpperCase(), value84 - 2, value85 - 2);
  value80.restore();
}
function addDetailedStars(value87, value88, value89) {
  value87.save();
  for (let value90 = 0; value90 < 200; value90++) {
    const value91 = Math.random() * value88;
    const value92 = Math.random() * value89;
    const value93 = Math.random() * 2.5;
    const value94 = 150 + Math.random() * 105;
    const value95 = 0.5 + Math.random() * 0.5;
    value87.fillStyle = "rgba(" + value94 + ", " + value94 + ", 255, " + value95 * 0.3 + ")";
    value87.beginPath();
    value87.arc(value91, value92, value93 * 3, 0, Math.PI * 2);
    value87.fill();
    value87.fillStyle = "rgba(255, 255, 255, " + value95 + ")";
    value87.beginPath();
    value87.arc(value91, value92, value93, 0, Math.PI * 2);
    value87.fill();
    if (Math.random() > 0.7) {
      value87.fillStyle = "rgba(255, 255, 200, " + value95 * 0.7 + ")";
      value87.beginPath();
      value87.arc(value91, value92, value93 * 0.5, 0, Math.PI * 2);
      value87.fill();
    }
  }
  const value96 = [{
    x: value88 * 0.1,
    y: value89 * 0.2,
    size: 3,
    color: [255, 220, 180]
  }, {
    x: value88 * 0.9,
    y: value89 * 0.1,
    size: 4,
    color: [180, 220, 255]
  }, {
    x: value88 * 0.2,
    y: value89 * 0.9,
    size: 2.5,
    color: [220, 255, 180]
  }];
  value96.forEach(value97 => {
    const [value98, value99, value100] = value97.color;
    value87.fillStyle = "rgba(" + value98 + ", " + value99 + ", " + value100 + ", 0.8)";
    value87.beginPath();
    value87.arc(value97.x, value97.y, value97.size, 0, Math.PI * 2);
    value87.fill();
    value87.fillStyle = "rgba(" + value98 + ", " + value99 + ", " + value100 + ", 0.3)";
    value87.beginPath();
    value87.arc(value97.x, value97.y, value97.size * 4, 0, Math.PI * 2);
    value87.fill();
  });
  value87.restore();
}
function addShootingStars(value101, value102, value103) {
  value101.save();
  const value104 = [{
    x: value102 * 0.8,
    y: value103 * 0.1,
    length: 80,
    angle: -0.3
  }, {
    x: value102 * 0.6,
    y: value103 * 0.05,
    length: 60,
    angle: -0.5
  }];
  value104.forEach(value105 => {
    const value106 = value101.createLinearGradient(value105.x, value105.y, value105.x + Math.cos(value105.angle) * value105.length, value105.y + Math.sin(value105.angle) * value105.length);
    value106.addColorStop(0, "rgba(255, 255, 255, 0.9)");
    value106.addColorStop(0.5, "rgba(200, 220, 255, 0.6)");
    value106.addColorStop(1, "transparent");
    value101.strokeStyle = value106;
    value101.lineWidth = 2;
    value101.lineCap = "round";
    value101.beginPath();
    value101.moveTo(value105.x, value105.y);
    value101.lineTo(value105.x + Math.cos(value105.angle) * value105.length, value105.y + Math.sin(value105.angle) * value105.length);
    value101.stroke();
    value101.strokeStyle = "rgba(180, 200, 255, 0.3)";
    value101.lineWidth = 8;
    value101.beginPath();
    value101.moveTo(value105.x, value105.y);
    value101.lineTo(value105.x + Math.cos(value105.angle) * value105.length, value105.y + Math.sin(value105.angle) * value105.length);
    value101.stroke();
  });
  value101.restore();
}
function addCosmicDust(value107, value108, value109) {
  value107.save();
  value107.globalAlpha = 0.1;
  value107.globalCompositeOperation = "screen";
  const value110 = [{
    x: value108 * 0.4,
    y: value109 * 0.7,
    size: 100,
    color: [100, 100, 200]
  }, {
    x: value108 * 0.6,
    y: value109 * 0.8,
    size: 80,
    color: [200, 100, 200]
  }, {
    x: value108 * 0.3,
    y: value109 * 0.3,
    size: 120,
    color: [100, 200, 200]
  }];
  value110.forEach(value111 => {
    const [value112, value113, value114] = value111.color;
    const value115 = value107.createRadialGradient(value111.x, value111.y, 0, value111.x, value111.y, value111.size);
    value115.addColorStop(0, "rgba(" + value112 + ", " + value113 + ", " + value114 + ", 0.3)");
    value115.addColorStop(1, "transparent");
    value107.fillStyle = value115;
    value107.beginPath();
    value107.arc(value111.x, value111.y, value111.size, 0, Math.PI * 2);
    value107.fill();
  });
  value107.restore();
}
function addNebulaBackground(value116, value117, value118) {
  value116.save();
  value116.globalAlpha = 0.15;
  value116.globalCompositeOperation = "screen";
  const value119 = [{
    x: value117 * 0.2,
    y: value118 * 0.4,
    size: 150,
    color: [80, 60, 150]
  }, {
    x: value117 * 0.8,
    y: value118 * 0.6,
    size: 120,
    color: [60, 80, 150]
  }, {
    x: value117 * 0.5,
    y: value118 * 0.2,
    size: 100,
    color: [150, 60, 100]
  }];
  value119.forEach(value120 => {
    const [value121, value122, value123] = value120.color;
    const value124 = value116.createRadialGradient(value120.x, value120.y, 0, value120.x, value120.y, value120.size);
    value124.addColorStop(0, "rgba(" + value121 + ", " + value122 + ", " + value123 + ", 0.4)");
    value124.addColorStop(0.7, "rgba(" + value121 + ", " + value122 + ", " + value123 + ", 0.2)");
    value124.addColorStop(1, "transparent");
    value116.fillStyle = value124;
    value116.beginPath();
    value116.arc(value120.x, value120.y, value120.size, 0, Math.PI * 2);
    value116.fill();
  });
  value116.restore();
}
function addGalaxyClouds(value125, value126, value127) {
  value125.save();
  value125.globalAlpha = 0.05;
  for (let value128 = 0; value128 < 5; value128++) {
    const value129 = Math.random() * value126;
    const value130 = Math.random() * value127;
    const value131 = 50 + Math.random() * 100;
    const value132 = value125.createRadialGradient(value129, value130, 0, value129, value130, value131);
    value132.addColorStop(0, "rgba(100, 100, 150, 0.1)");
    value132.addColorStop(1, "transparent");
    value125.fillStyle = value132;
    value125.beginPath();
    value125.arc(value129, value130, value131, 0, Math.PI * 2);
    value125.fill();
  }
  value125.restore();
}
function drawCosmicBorder(value133, value134, value135) {
  value133.save();
  const value136 = value133.createLinearGradient(0, 0, value134, value135);
  value136.addColorStop(0, "rgba(120, 120, 200, 0.6)");
  value136.addColorStop(0.5, "rgba(180, 180, 220, 0.8)");
  value136.addColorStop(1, "rgba(120, 120, 200, 0.6)");
  value133.strokeStyle = value136;
  value133.lineWidth = 8;
  value133.shadowColor = "rgba(150, 150, 255, 0.5)";
  value133.shadowBlur = 20;
  value133.strokeRect(10, 10, value134 - 20, value135 - 20);
  value133.strokeStyle = "rgba(200, 200, 255, 0.4)";
  value133.lineWidth = 2;
  value133.shadowBlur = 0;
  value133.strokeRect(20, 20, value134 - 40, value135 - 40);
  value133.restore();
}
function addMoonSignature(value137, value138, value139) {
  value137.save();
  const value140 = value138 - 100;
  const value141 = value139 - 25;
  value137.font = "italic 14px \"Arial\"";
  value137.fillStyle = "rgba(200, 200, 255, 0.8)";
  value137.textAlign = "right";
  value137.textBaseline = "bottom";
  value137.shadowColor = "rgba(150, 150, 255, 0.5)";
  value137.shadowBlur = 10;
  value137.fillText("by " + getBotName(), value140, value141);
  value137.strokeStyle = "rgba(180, 180, 220, 0.6)";
  value137.lineWidth = 1;
  value137.beginPath();
  value137.moveTo(value140 - value137.measureText("by " + getBotName()).width, value141 + 2);
  value137.lineTo(value140, value141 + 2);
  value137.stroke();
  value137.restore();
}
