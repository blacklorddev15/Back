const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "rainbowlogo",
  description: "Create vibrant rainbow text logos with colorful spectrum effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🌈 *RAINBOW LOGO*\n\n*rainbowlogo*\nrainbowlogo <text>\n\n*Example:*\nrainbowlogo COLOR\nrainbowlogo RAINBOW\nrainbowlogo SPECTRUM\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateRainbowLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🌈 *Rainbow Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [RAINBOWLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateRainbowLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createRainbowBackground(value16, value13, value14);
  drawRainbowArcs(value16, value13, value14);
  drawRainbowText(value16, value12, value13, value14);
  addColorParticles(value16, value13, value14);
  addSparkles(value16, value13, value14);
  addColorBursts(value16, value13, value14);
  addColorWaves(value16, value13, value14);
  addPrismEffects(value16, value13, value14);
  drawRainbowBorder(value16, value13, value14);
  addRainbowSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createRainbowBackground(value17, value18, value19) {
  const value20 = value17.createLinearGradient(0, 0, value18, value19);
  value20.addColorStop(0, "#ff0080");
  value20.addColorStop(0.2, "#ff00ff");
  value20.addColorStop(0.4, "#8000ff");
  value20.addColorStop(0.6, "#0080ff");
  value20.addColorStop(0.8, "#00ff80");
  value20.addColorStop(1, "#ffff00");
  value17.fillStyle = value20;
  value17.fillRect(0, 0, value18, value19);
  addColorClouds(value17, value18, value19);
}
function addColorClouds(value21, value22, value23) {
  value21.save();
  value21.globalAlpha = 0.3;
  value21.globalCompositeOperation = "screen";
  const value24 = [{
    x: value22 * 0.2,
    y: value23 * 0.3,
    size: 120,
    color: [255, 0, 128]
  }, {
    x: value22 * 0.7,
    y: value23 * 0.2,
    size: 100,
    color: [128, 0, 255]
  }, {
    x: value22 * 0.3,
    y: value23 * 0.7,
    size: 110,
    color: [0, 128, 255]
  }, {
    x: value22 * 0.8,
    y: value23 * 0.6,
    size: 90,
    color: [0, 255, 128]
  }, {
    x: value22 * 0.5,
    y: value23 * 0.4,
    size: 130,
    color: [255, 255, 0]
  }];
  value24.forEach(value25 => {
    const [value26, value27, value28] = value25.color;
    const value29 = value21.createRadialGradient(value25.x, value25.y, 0, value25.x, value25.y, value25.size);
    value29.addColorStop(0, "rgba(" + value26 + ", " + value27 + ", " + value28 + ", 0.6)");
    value29.addColorStop(1, "transparent");
    value21.fillStyle = value29;
    value21.beginPath();
    value21.arc(value25.x, value25.y, value25.size, 0, Math.PI * 2);
    value21.fill();
  });
  value21.restore();
}
function drawRainbowArcs(value30, value31, value32) {
  const value33 = value31 / 2;
  const value34 = value32 * 0.6;
  const value35 = Math.min(value31, value32) * 0.8;
  value30.save();
  value30.globalAlpha = 0.7;
  const value36 = ["#ff0000", "#ff7f00", "#ffff00", "#00ff00", "#0000ff", "#4b0082", "#8b00ff"];
  value36.forEach((value37, value38) => {
    const value39 = value35 - value38 * 25;
    const value40 = Math.PI * 0.1;
    const value41 = Math.PI * 0.9;
    value30.strokeStyle = value37;
    value30.lineWidth = 20;
    value30.lineCap = "round";
    value30.beginPath();
    value30.arc(value33, value34, value39, value40, value41);
    value30.stroke();
  });
  value30.shadowColor = "#ffffff";
  value30.shadowBlur = 30;
  value36.forEach((value42, value43) => {
    const value44 = value35 - value43 * 25;
    const value45 = Math.PI * 0.1;
    const value46 = Math.PI * 0.9;
    value30.strokeStyle = value42;
    value30.lineWidth = 15;
    value30.beginPath();
    value30.arc(value33, value34, value44, value45, value46);
    value30.stroke();
  });
  value30.restore();
}
function drawRainbowText(value47, value48, value49, value50) {
  const value51 = value49 * 0.5;
  const value52 = value50 * 0.5;
  value47.save();
  value47.shadowColor = "rgba(0, 0, 0, 0.5)";
  value47.shadowBlur = 20;
  value47.shadowOffsetX = 5;
  value47.shadowOffsetY = 5;
  const value53 = value47.createLinearGradient(value51 - 150, value52 - 50, value51 + 150, value52 + 50);
  value53.addColorStop(0, "#ff0000");
  value53.addColorStop(0.16, "#ff7f00");
  value53.addColorStop(0.33, "#ffff00");
  value53.addColorStop(0.5, "#00ff00");
  value53.addColorStop(0.66, "#0000ff");
  value53.addColorStop(0.83, "#4b0082");
  value53.addColorStop(1, "#8b00ff");
  value47.font = "bold 72px \"Arial\"";
  value47.textAlign = "center";
  value47.textBaseline = "middle";
  value47.fillStyle = value53;
  value47.fillText(value48.toUpperCase(), value51, value52);
  value47.shadowColor = "transparent";
  value47.shadowBlur = 0;
  value47.shadowOffsetX = 0;
  value47.shadowOffsetY = 0;
  value47.strokeStyle = "rgba(255, 255, 255, 0.8)";
  value47.lineWidth = 3;
  value47.strokeText(value48.toUpperCase(), value51, value52);
  value47.strokeStyle = "rgba(255, 255, 255, 0.4)";
  value47.lineWidth = 1;
  value47.strokeText(value48.toUpperCase(), value51, value52);
  addCharacterColorEffects(value47, value48, value51, value52);
  value47.restore();
}
function addCharacterColorEffects(value54, value55, value56, value57) {
  value54.save();
  value54.globalCompositeOperation = "screen";
  const value58 = value54.measureText(value55.toUpperCase());
  const value59 = value58.width;
  const value60 = value59 / value55.length;
  for (let value61 = 0; value61 < value55.length; value61++) {
    const value62 = value56 - value59 / 2 + (value61 + 0.5) * value60;
    const value63 = value61 * 360 / value55.length % 360;
    const value64 = value54.createRadialGradient(value62, value57, 0, value62, value57, 40);
    value64.addColorStop(0, "hsla(" + value63 + ", 100%, 70%, 0.6)");
    value64.addColorStop(1, "transparent");
    value54.fillStyle = value64;
    value54.beginPath();
    value54.arc(value62, value57, 40, 0, Math.PI * 2);
    value54.fill();
  }
  value54.restore();
}
function addColorParticles(value65, value66, value67) {
  value65.save();
  value65.globalCompositeOperation = "screen";
  for (let value68 = 0; value68 < 25; value68++) {
    const value69 = Math.random() * value66;
    const value70 = Math.random() * value67;
    const value71 = 8 + Math.random() * 20;
    const value72 = Math.random() * 360;
    const value73 = 80 + Math.random() * 20;
    const value74 = value65.createRadialGradient(value69, value70, 0, value69, value70, value71);
    value74.addColorStop(0, "hsla(" + value72 + ", " + value73 + "%, 70%, 0.8)");
    value74.addColorStop(1, "hsla(" + value72 + ", " + value73 + "%, 50%, 0.3)");
    value65.fillStyle = value74;
    value65.beginPath();
    value65.arc(value69, value70, value71, 0, Math.PI * 2);
    value65.fill();
    value65.fillStyle = "hsla(" + value72 + ", 100%, 90%, 0.9)";
    value65.beginPath();
    value65.arc(value69, value70, value71 * 0.3, 0, Math.PI * 2);
    value65.fill();
  }
  for (let value75 = 0; value75 < 50; value75++) {
    const value76 = Math.random() * value66;
    const value77 = Math.random() * value67;
    const value78 = 3 + Math.random() * 10;
    const value79 = Math.random() * 360;
    value65.fillStyle = "hsla(" + value79 + ", 100%, 70%, 0.7)";
    value65.beginPath();
    value65.arc(value76, value77, value78, 0, Math.PI * 2);
    value65.fill();
  }
  for (let value80 = 0; value80 < 100; value80++) {
    const value81 = Math.random() * value66;
    const value82 = Math.random() * value67;
    const value83 = 1 + Math.random() * 4;
    const value84 = Math.random() * 360;
    value65.fillStyle = "hsla(" + value84 + ", 100%, 80%, 0.9)";
    value65.beginPath();
    value65.arc(value81, value82, value83, 0, Math.PI * 2);
    value65.fill();
  }
  value65.restore();
}
function addSparkles(value85, value86, value87) {
  value85.save();
  value85.globalCompositeOperation = "screen";
  for (let value88 = 0; value88 < 40; value88++) {
    const value89 = Math.random() * value86;
    const value90 = Math.random() * value87;
    const value91 = 1 + Math.random() * 3;
    const value92 = Math.random() * 360;
    const value93 = Math.random() * Math.PI * 2;
    value85.save();
    value85.translate(value89, value90);
    value85.rotate(value93);
    value85.fillStyle = "hsla(" + value92 + ", 100%, 80%, 0.9)";
    value85.beginPath();
    for (let value94 = 0; value94 < 5; value94++) {
      const value95 = value94 * Math.PI * 2 / 5;
      const value96 = value91 * 2;
      const value97 = value91;
      value85.lineTo(Math.cos(value95) * value96, Math.sin(value95) * value96);
      value85.lineTo(Math.cos(value95 + Math.PI / 5) * value97, Math.sin(value95 + Math.PI / 5) * value97);
    }
    value85.closePath();
    value85.fill();
    value85.fillStyle = "hsla(" + value92 + ", 100%, 70%, 0.4)";
    value85.beginPath();
    value85.arc(0, 0, value91 * 3, 0, Math.PI * 2);
    value85.fill();
    value85.restore();
  }
  value85.restore();
}
function addColorBursts(value98, value99, value100) {
  value98.save();
  value98.globalCompositeOperation = "screen";
  value98.globalAlpha = 0.4;
  const value101 = [{
    x: value99 * 0.3,
    y: value100 * 0.3
  }, {
    x: value99 * 0.7,
    y: value100 * 0.7
  }, {
    x: value99 * 0.2,
    y: value100 * 0.7
  }, {
    x: value99 * 0.8,
    y: value100 * 0.3
  }];
  value101.forEach((value102, value103) => {
    const value104 = value103 * 90 % 360;
    for (let value105 = 0; value105 < 12; value105++) {
      const value106 = value105 / 12 * Math.PI * 2;
      const value107 = 80 + Math.random() * 70;
      const value108 = (value104 + value105 * 30) % 360;
      const value109 = value98.createLinearGradient(value102.x, value102.y, value102.x + Math.cos(value106) * value107, value102.y + Math.sin(value106) * value107);
      value109.addColorStop(0, "hsla(" + value108 + ", 100%, 70%, 0.8)");
      value109.addColorStop(0.7, "hsla(" + value108 + ", 100%, 50%, 0.4)");
      value109.addColorStop(1, "transparent");
      value98.strokeStyle = value109;
      value98.lineWidth = 6;
      value98.lineCap = "round";
      value98.beginPath();
      value98.moveTo(value102.x, value102.y);
      value98.lineTo(value102.x + Math.cos(value106) * value107, value102.y + Math.sin(value106) * value107);
      value98.stroke();
    }
  });
  value98.restore();
}
function addColorWaves(value110, value111, value112) {
  value110.save();
  value110.globalCompositeOperation = "screen";
  value110.globalAlpha = 0.3;
  for (let value113 = 0; value113 < 4; value113++) {
    const value114 = value112 * 0.2 + value113 * 40;
    const value115 = 15 + value113 * 5;
    const value116 = 0.02 + value113 * 0.01;
    value110.beginPath();
    for (let value117 = 0; value117 <= value111; value117 += 2) {
      const value118 = value114 + Math.sin(value117 * value116 + value113) * value115;
      const value119 = (value117 / value111 * 360 + value113 * 90) % 360;
      if (value117 === 0) {
        value110.moveTo(value117, value118);
      } else {
        value110.strokeStyle = "hsla(" + value119 + ", 100%, 70%, 0.6)";
        value110.lineTo(value117, value118);
        value110.stroke();
        value110.beginPath();
        value110.moveTo(value117, value118);
      }
    }
  }
  value110.restore();
}
function addPrismEffects(value120, value121, value122) {
  value120.save();
  value120.globalCompositeOperation = "screen";
  value120.globalAlpha = 0.2;
  const value123 = value121 * 0.5;
  const value124 = value122 * 0.5;
  const value125 = [{
    angle: -0.3,
    hue: 0,
    length: 200
  }, {
    angle: -0.1,
    hue: 60,
    length: 180
  }, {
    angle: 0.1,
    hue: 120,
    length: 160
  }, {
    angle: 0.3,
    hue: 240,
    length: 140
  }];
  value125.forEach(value126 => {
    const value127 = value120.createLinearGradient(value123, value124, value123 + Math.cos(value126.angle) * value126.length, value124 + Math.sin(value126.angle) * value126.length);
    value127.addColorStop(0, "hsla(" + value126.hue + ", 100%, 70%, 0.6)");
    value127.addColorStop(0.7, "hsla(" + value126.hue + ", 100%, 50%, 0.3)");
    value127.addColorStop(1, "transparent");
    value120.strokeStyle = value127;
    value120.lineWidth = 12;
    value120.lineCap = "round";
    value120.beginPath();
    value120.moveTo(value123, value124);
    value120.lineTo(value123 + Math.cos(value126.angle) * value126.length, value124 + Math.sin(value126.angle) * value126.length);
    value120.stroke();
    value120.strokeStyle = "hsla(" + value126.hue + ", 100%, 70%, 0.3)";
    value120.lineWidth = 25;
    value120.beginPath();
    value120.moveTo(value123, value124);
    value120.lineTo(value123 + Math.cos(value126.angle) * value126.length, value124 + Math.sin(value126.angle) * value126.length);
    value120.stroke();
  });
  const value128 = value120.createRadialGradient(value123, value124, 0, value123, value124, 60);
  value128.addColorStop(0, "rgba(255, 255, 255, 0.8)");
  value128.addColorStop(1, "transparent");
  value120.fillStyle = value128;
  value120.beginPath();
  value120.arc(value123, value124, 60, 0, Math.PI * 2);
  value120.fill();
  value120.restore();
}
function drawRainbowBorder(value129, value130, value131) {
  value129.save();
  const value132 = value129.createLinearGradient(0, 0, value130, 0);
  value132.addColorStop(0, "#ff0000");
  value132.addColorStop(0.16, "#ff7f00");
  value132.addColorStop(0.33, "#ffff00");
  value132.addColorStop(0.5, "#00ff00");
  value132.addColorStop(0.66, "#0000ff");
  value132.addColorStop(0.83, "#4b0082");
  value132.addColorStop(1, "#8b00ff");
  value129.strokeStyle = value132;
  value129.lineWidth = 10;
  value129.shadowColor = "rgba(255, 255, 255, 0.6)";
  value129.shadowBlur = 25;
  value129.strokeRect(10, 10, value130 - 20, value131 - 20);
  const value133 = value129.createLinearGradient(value130, 0, 0, value131);
  value133.addColorStop(0, "#8b00ff");
  value133.addColorStop(0.16, "#4b0082");
  value133.addColorStop(0.33, "#0000ff");
  value133.addColorStop(0.5, "#00ff00");
  value133.addColorStop(0.66, "#ffff00");
  value133.addColorStop(0.83, "#ff7f00");
  value133.addColorStop(1, "#ff0000");
  value129.strokeStyle = value133;
  value129.lineWidth = 3;
  value129.shadowBlur = 15;
  value129.strokeRect(20, 20, value130 - 40, value131 - 40);
  addCornerRainbowAccents(value129, value130, value131);
  value129.restore();
}
function addCornerRainbowAccents(value134, value135, value136) {
  value134.save();
  value134.globalAlpha = 0.7;
  const value137 = [{
    x: 25,
    y: 25
  }, {
    x: value135 - 25,
    y: 25
  }, {
    x: 25,
    y: value136 - 25
  }, {
    x: value135 - 25,
    y: value136 - 25
  }];
  value137.forEach((value138, value139) => {
    const value140 = value139 * 90 % 360;
    for (let value141 = 0; value141 < 3; value141++) {
      const value142 = 15 + value141 * 8;
      const value143 = (value140 + value141 * 120) % 360;
      value134.strokeStyle = "hsla(" + value143 + ", 100%, 70%, 0.8)";
      value134.lineWidth = 3;
      value134.beginPath();
      value134.arc(value138.x, value138.y, value142, 0, Math.PI * 0.5);
      value134.stroke();
    }
  });
  value134.restore();
}
function addRainbowSignature(value144, value145, value146) {
  value144.save();
  const value147 = value145 - 110;
  const value148 = value146 - 25;
  value144.font = "italic 14px \"Arial\"";
  value144.textAlign = "right";
  value144.textBaseline = "bottom";
  const value149 = value144.createLinearGradient(value147 - 100, value148, value147, value148);
  value149.addColorStop(0, "#ff0000");
  value149.addColorStop(0.16, "#ff7f00");
  value149.addColorStop(0.33, "#ffff00");
  value149.addColorStop(0.5, "#00ff00");
  value149.addColorStop(0.66, "#0000ff");
  value149.addColorStop(0.83, "#4b0082");
  value149.addColorStop(1, "#8b00ff");
  value144.fillStyle = value149;
  value144.shadowColor = "rgba(255, 255, 255, 0.5)";
  value144.shadowBlur = 10;
  value144.fillText("by " + getBotName(), value147, value148);
  const value150 = 20;
  const value151 = 4;
  const value152 = value147 - 105;
  const value153 = value148 + 2;
  const value154 = value144.createLinearGradient(value152, value153, value152 + value150, value153);
  value154.addColorStop(0, "#ff0000");
  value154.addColorStop(0.16, "#ff7f00");
  value154.addColorStop(0.33, "#ffff00");
  value154.addColorStop(0.5, "#00ff00");
  value154.addColorStop(0.66, "#0000ff");
  value154.addColorStop(0.83, "#4b0082");
  value154.addColorStop(1, "#8b00ff");
  value144.fillStyle = value154;
  value144.fillRect(value152, value153, value150, value151);
  value144.restore();
}
