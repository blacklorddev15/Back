const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "firelogo",
  description: "Create fire/flame style text logos",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (!value7.length) {
        await value5.sendMessage(value8, {
          text: "🔥 *Fire Logo*\nUsage: " + database.getBotSetting("prefix") + "firelogo <text>\nExample:\n" + database.getBotSetting("prefix") + "firelogo WOLF"
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 15) {
        await value5.sendMessage(value8, {
          text: "❌ Text too long! Maximum 15 characters.\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateFireLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🔥 *Fire Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [FIRELOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ Error creating fire logo: " + error11.message + "\nTry again with shorter text."
      }, {
        quoted: value6
      });
    }
  }
};
async function generateFireLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  const value17 = value16.createLinearGradient(0, 0, 0, value14);
  value17.addColorStop(0, "#0a0a0a");
  value17.addColorStop(0.4, "#8B0000");
  value17.addColorStop(0.7, "#FF4500");
  value17.addColorStop(0.9, "#FF8C00");
  value17.addColorStop(1, "#0a0a0a");
  value16.fillStyle = value17;
  value16.fillRect(0, 0, value13, value14);
  addFireBackgroundNoise(value16, value13, value14);
  value16.font = "bold 80px Arial";
  value16.textAlign = "center";
  value16.textBaseline = "middle";
  const value18 = value16.createLinearGradient(0, value14 / 2 - 50, 0, value14 / 2 + 50);
  value18.addColorStop(0, "#FFFF00");
  value18.addColorStop(0.3, "#FFA500");
  value18.addColorStop(0.7, "#FF4500");
  value18.addColorStop(1, "#8B0000");
  value16.fillStyle = value18;
  value16.shadowColor = "#FF4500";
  value16.shadowBlur = 25;
  value16.fillText(value12.toUpperCase(), value13 / 2, value14 / 2);
  value16.shadowColor = "#FFFF00";
  value16.shadowBlur = 15;
  value16.lineWidth = 2;
  value16.strokeStyle = value18;
  value16.strokeText(value12.toUpperCase(), value13 / 2, value14 / 2);
  addFireParticles(value16, value13, value14);
  value16.strokeStyle = "#FF8C00";
  value16.lineWidth = 5;
  value16.shadowColor = "#FF4500";
  value16.shadowBlur = 20;
  value16.strokeRect(10, 10, value13 - 20, value14 - 20);
  value16.shadowColor = "transparent";
  value16.shadowBlur = 0;
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function addFireBackgroundNoise(value19, value20, value21) {
  value19.globalAlpha = 0.25;
  for (let value22 = 0; value22 < 1200; value22++) {
    const value23 = Math.random() * value20;
    const value24 = Math.random() * value21;
    const value25 = Math.random() * 3 + 1;
    const value26 = Math.random();
    if (value26 > 0.7) {
      value19.fillStyle = "#FFFF00";
    } else if (value26 > 0.4) {
      value19.fillStyle = "#FFA500";
    } else {
      value19.fillStyle = "#FF4500";
    }
    value19.fillRect(value23, value24, value25, value25);
  }
  value19.globalAlpha = 1;
}
function addFireParticles(value27, value28, value29) {
  value27.globalAlpha = 0.7;
  for (let value30 = 0; value30 < 250; value30++) {
    const value31 = Math.random() * Math.PI * 2;
    const value32 = Math.random() * 120 + 50;
    const value33 = value28 / 2 + Math.cos(value31) * value32;
    const value34 = value29 / 2 + Math.sin(value31) * value32;
    const value35 = Math.random() * 4 + 1;
    const value36 = Math.random();
    if (value36 > 0.8) {
      value27.fillStyle = "#FFFF00";
    } else if (value36 > 0.5) {
      value27.fillStyle = "#FFA500";
    } else {
      value27.fillStyle = "#FF4500";
    }
    value27.beginPath();
    value27.arc(value33, value34, value35, 0, Math.PI * 2);
    value27.fill();
  }
  value27.globalAlpha = 1;
}
