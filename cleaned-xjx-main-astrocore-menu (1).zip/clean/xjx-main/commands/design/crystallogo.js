const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "crystallogo",
  category: "design",
  description: "Create stunning crystal text logos with gemstone and refractive effects",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "💎 *CRYSTAL LOGO*\n\n*crystallogo*\ncrystallogo <text>\n\n*Example:*\ncrystallogo CRYSTAL\ncrystallogo GEM\ncrystallogo DIAMOND\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateCrystalLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "💎 *Crystal Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [CRYSTALLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generateCrystalLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createCrystalCave(value16, value13, value14);
  const value17 = value13 * 0.75;
  const value18 = value14 * 0.6;
  drawCrystalCluster(value16, value17, value18);
  addCrystalLightBeams(value16, value17, value18);
  addCrystalRefractions(value16, value13, value14);
  drawCrystalText(value16, value12, value13, value14);
  addFloatingShards(value16, value13, value14);
  addCrystalDust(value16, value13, value14);
  addGemstoneHighlights(value16, value13, value14);
  addRainbowRefractions(value16, value13, value14);
  drawCrystalBorder(value16, value13, value14);
  addCrystalSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createCrystalCave(value19, value20, value21) {
  const value22 = value19.createLinearGradient(0, 0, 0, value21);
  value22.addColorStop(0, "#0a0a2a");
  value22.addColorStop(0.3, "#1a1a4a");
  value22.addColorStop(0.6, "#2d2d6a");
  value22.addColorStop(1, "#0a0a2a");
  value19.fillStyle = value22;
  value19.fillRect(0, 0, value20, value21);
  addBackgroundCrystals(value19, value20, value21);
  addCrystalPatterns(value19, value20, value21);
}
function addBackgroundCrystals(value23, value24, value25) {
  value23.save();
  value23.globalAlpha = 0.3;
  for (let value26 = 0; value26 < 8; value26++) {
    const value27 = Math.random() * value24;
    const value28 = value25 * 0.7 + Math.random() * value25 * 0.3;
    const value29 = 20 + Math.random() * 40;
    const value30 = 200 + Math.random() * 160;
    drawBackgroundCrystal(value23, value27, value28, value29, value30);
  }
  value23.restore();
}
function drawBackgroundCrystal(value31, value32, value33, value34, value35) {
  value31.save();
  value31.translate(value32, value33);
  value31.rotate(Math.random() * Math.PI);
  const value36 = value31.createLinearGradient(-value34, -value34, value34, value34);
  value36.addColorStop(0, "hsla(" + value35 + ", 80%, 50%, 0.4)");
  value36.addColorStop(0.5, "hsla(" + value35 + ", 100%, 70%, 0.6)");
  value36.addColorStop(1, "hsla(" + value35 + ", 80%, 50%, 0.4)");
  value31.fillStyle = value36;
  value31.beginPath();
  value31.moveTo(0, -value34);
  value31.lineTo(value34 * 0.7, 0);
  value31.lineTo(0, value34);
  value31.lineTo(-value34 * 0.7, 0);
  value31.closePath();
  value31.fill();
  value31.strokeStyle = "hsla(" + value35 + ", 100%, 80%, 0.6)";
  value31.lineWidth = 1;
  value31.beginPath();
  value31.moveTo(0, -value34);
  value31.lineTo(0, value34);
  value31.stroke();
  value31.beginPath();
  value31.moveTo(-value34 * 0.7, 0);
  value31.lineTo(value34 * 0.7, 0);
  value31.stroke();
  value31.restore();
}
function addCrystalPatterns(value37, value38, value39) {
  value37.save();
  value37.globalAlpha = 0.1;
  value37.strokeStyle = "rgba(100, 150, 255, 0.4)";
  value37.lineWidth = 1;
  const value40 = 30;
  for (let value41 = 0; value41 < value39; value41 += value40 * 1.5) {
    for (let value42 = 0; value42 < value38; value42 += value40 * 1.732) {
      drawHexagon(value37, value42 + (value41 % (value40 * 3) ? value40 * 0.866 : 0), value41, value40);
    }
  }
  value37.restore();
}
function drawHexagon(value43, value44, value45, value46) {
  value43.beginPath();
  for (let value47 = 0; value47 < 6; value47++) {
    const value48 = value47 * Math.PI / 3;
    const value49 = value44 + Math.cos(value48) * value46;
    const value50 = value45 + Math.sin(value48) * value46;
    if (value47 === 0) {
      value43.moveTo(value49, value50);
    } else {
      value43.lineTo(value49, value50);
    }
  }
  value43.closePath();
  value43.stroke();
}
function drawCrystalCluster(value51, value52, value53) {
  value51.save();
  drawMainCrystal(value51, value52, value53 - 30, 50, 220);
  const value54 = [{
    x: -40,
    y: -10,
    size: 30,
    hue: 200,
    rotation: -0.3
  }, {
    x: 35,
    y: -15,
    size: 25,
    hue: 240,
    rotation: 0.2
  }, {
    x: -25,
    y: 40,
    size: 20,
    hue: 180,
    rotation: -0.1
  }, {
    x: 30,
    y: 35,
    size: 22,
    hue: 260,
    rotation: 0.4
  }, {
    x: 0,
    y: 50,
    size: 18,
    hue: 220,
    rotation: 0
  }];
  value54.forEach(value55 => {
    drawSingleCrystal(value51, value52 + value55.x, value53 + value55.y, value55.size, value55.hue, value55.rotation);
  });
  const value56 = value51.createRadialGradient(value52, value53 + 60, 0, value52, value53 + 60, 40);
  value56.addColorStop(0, "rgba(50, 50, 100, 0.8)");
  value56.addColorStop(1, "rgba(20, 20, 50, 0.4)");
  value51.fillStyle = value56;
  value51.beginPath();
  value51.arc(value52, value53 + 60, 40, 0, Math.PI * 2);
  value51.fill();
  value51.restore();
}
function drawMainCrystal(value57, value58, value59, value60, value61) {
  value57.save();
  value57.translate(value58, value59);
  const value62 = value57.createLinearGradient(-value60, -value60, value60, value60);
  value62.addColorStop(0, "hsla(" + value61 + ", 100%, 40%, 0.9)");
  value62.addColorStop(0.3, "hsla(" + value61 + ", 100%, 70%, 0.95)");
  value62.addColorStop(0.7, "hsla(" + value61 + ", 100%, 60%, 0.9)");
  value62.addColorStop(1, "hsla(" + value61 + ", 100%, 40%, 0.8)");
  value57.fillStyle = value62;
  value57.beginPath();
  value57.moveTo(0, -value60);
  value57.lineTo(value60 * 0.8, -value60 * 0.3);
  value57.lineTo(value60 * 0.8, value60 * 0.5);
  value57.lineTo(0, value60);
  value57.lineTo(-value60 * 0.8, value60 * 0.5);
  value57.lineTo(-value60 * 0.8, -value60 * 0.3);
  value57.closePath();
  value57.fill();
  addCrystalFacets(value57, value60, value61);
  const value63 = value57.createRadialGradient(0, 0, 0, 0, 0, value60 * 0.6);
  value63.addColorStop(0, "hsla(" + value61 + ", 100%, 80%, 0.6)");
  value63.addColorStop(1, "transparent");
  value57.fillStyle = value63;
  value57.beginPath();
  value57.arc(0, 0, value60 * 0.6, 0, Math.PI * 2);
  value57.fill();
  value57.restore();
}
function addCrystalFacets(value64, value65, value66) {
  value64.strokeStyle = "hsla(" + value66 + ", 100%, 90%, 0.8)";
  value64.lineWidth = 2;
  value64.beginPath();
  value64.moveTo(0, -value65);
  value64.lineTo(0, value65);
  value64.stroke();
  value64.beginPath();
  value64.moveTo(-value65 * 0.8, -value65 * 0.3);
  value64.lineTo(value65 * 0.8, value65 * 0.5);
  value64.stroke();
  value64.beginPath();
  value64.moveTo(value65 * 0.8, -value65 * 0.3);
  value64.lineTo(-value65 * 0.8, value65 * 0.5);
  value64.stroke();
  value64.fillStyle = "hsla(" + value66 + ", 100%, 95%, 0.6)";
  value64.beginPath();
  value64.moveTo(0, -value65);
  value64.lineTo(value65 * 0.3, -value65 * 0.6);
  value64.lineTo(-value65 * 0.3, -value65 * 0.6);
  value64.closePath();
  value64.fill();
  value64.beginPath();
  value64.moveTo(value65 * 0.8, -value65 * 0.3);
  value64.lineTo(value65 * 0.5, 0);
  value64.lineTo(value65 * 0.8, value65 * 0.2);
  value64.closePath();
  value64.fill();
  value64.beginPath();
  value64.moveTo(-value65 * 0.8, -value65 * 0.3);
  value64.lineTo(-value65 * 0.5, 0);
  value64.lineTo(-value65 * 0.8, value65 * 0.2);
  value64.closePath();
  value64.fill();
}
function drawSingleCrystal(value67, value68, value69, value70, value71, value72) {
  value67.save();
  value67.translate(value68, value69);
  value67.rotate(value72);
  const value73 = value67.createLinearGradient(-value70, -value70, value70, value70);
  value73.addColorStop(0, "hsla(" + value71 + ", 100%, 50%, 0.8)");
  value73.addColorStop(0.5, "hsla(" + value71 + ", 100%, 70%, 0.9)");
  value73.addColorStop(1, "hsla(" + value71 + ", 100%, 50%, 0.8)");
  value67.fillStyle = value73;
  value67.beginPath();
  value67.moveTo(0, -value70);
  value67.lineTo(value70 * 0.6, 0);
  value67.lineTo(0, value70);
  value67.lineTo(-value70 * 0.6, 0);
  value67.closePath();
  value67.fill();
  value67.strokeStyle = "hsla(" + value71 + ", 100%, 90%, 0.7)";
  value67.lineWidth = 1;
  value67.beginPath();
  value67.moveTo(0, -value70);
  value67.lineTo(0, value70);
  value67.stroke();
  value67.beginPath();
  value67.moveTo(-value70 * 0.6, 0);
  value67.lineTo(value70 * 0.6, 0);
  value67.stroke();
  value67.fillStyle = "hsla(" + value71 + ", 100%, 95%, 0.5)";
  value67.beginPath();
  value67.moveTo(0, -value70);
  value67.lineTo(value70 * 0.2, -value70 * 0.3);
  value67.lineTo(-value70 * 0.2, -value70 * 0.3);
  value67.closePath();
  value67.fill();
  value67.restore();
}
function addCrystalLightBeams(value74, value75, value76) {
  value74.save();
  value74.globalCompositeOperation = "screen";
  value74.globalAlpha = 0.4;
  for (let value77 = 0; value77 < 12; value77++) {
    const value78 = value77 / 12 * Math.PI * 2;
    const value79 = 100 + Math.random() * 80;
    const value80 = 200 + Math.random() * 160;
    const value81 = value74.createLinearGradient(value75, value76, value75 + Math.cos(value78) * value79, value76 + Math.sin(value78) * value79);
    value81.addColorStop(0, "hsla(" + value80 + ", 100%, 70%, 0.8)");
    value81.addColorStop(0.7, "hsla(" + value80 + ", 100%, 50%, 0.4)");
    value81.addColorStop(1, "transparent");
    value74.strokeStyle = value81;
    value74.lineWidth = 6;
    value74.lineCap = "round";
    value74.beginPath();
    value74.moveTo(value75, value76);
    value74.lineTo(value75 + Math.cos(value78) * value79, value76 + Math.sin(value78) * value79);
    value74.stroke();
  }
  const value82 = value74.createRadialGradient(value75, value76, 0, value75, value76, 120);
  value82.addColorStop(0, "rgba(100, 150, 255, 0.6)");
  value82.addColorStop(0.5, "rgba(80, 120, 255, 0.3)");
  value82.addColorStop(1, "transparent");
  value74.fillStyle = value82;
  value74.beginPath();
  value74.arc(value75, value76, 120, 0, Math.PI * 2);
  value74.fill();
  value74.restore();
}
function addCrystalRefractions(value83, value84, value85) {
  value83.save();
  value83.globalCompositeOperation = "overlay";
  value83.globalAlpha = 0.2;
  for (let value86 = 0; value86 < value85; value86 += 30) {
    for (let value87 = 0; value87 < value84; value87 += 30) {
      const value88 = 0.3 + Math.sin(value87 * 0.02 + value86 * 0.01) * 0.3;
      const value89 = 15 + Math.sin(value87 * 0.03) * 10;
      value83.fillStyle = "rgba(255, 255, 255, " + value88 + ")";
      value83.beginPath();
      value83.arc(value87 + Math.sin(value86 * 0.02) * 10, value86, value89, 0, Math.PI * 2);
      value83.fill();
    }
  }
  value83.restore();
}
function drawCrystalText(value90, value91, value92, value93) {
  const value94 = value92 * 0.35;
  const value95 = value93 * 0.6;
  value90.save();
  value90.shadowColor = "rgba(100, 150, 255, 0.8)";
  value90.shadowBlur = 30;
  const value96 = value90.createLinearGradient(value94 - 100, value95 - 50, value94 + 100, value95 + 50);
  value96.addColorStop(0, "#64C8FF");
  value96.addColorStop(0.2, "#9664FF");
  value96.addColorStop(0.5, "#FFFFFF");
  value96.addColorStop(0.8, "#64FFC8");
  value96.addColorStop(1, "#64C8FF");
  value90.font = "bold 70px \"Arial\"";
  value90.textAlign = "center";
  value90.textBaseline = "middle";
  value90.fillStyle = value96;
  value90.fillText(value91.toUpperCase(), value94, value95);
  value90.shadowColor = "transparent";
  value90.fillStyle = "rgba(255, 255, 255, 0.7)";
  value90.fillText(value91.toUpperCase(), value94, value95);
  value90.strokeStyle = "rgba(200, 230, 255, 0.9)";
  value90.lineWidth = 2;
  value90.strokeText(value91.toUpperCase(), value94, value95);
  addTextFacets(value90, value91, value94, value95);
  value90.restore();
}
function addTextFacets(value97, value98, value99, value100) {
  value97.save();
  value97.globalCompositeOperation = "overlay";
  value97.globalAlpha = 0.3;
  const value101 = value97.measureText(value98.toUpperCase());
  const value102 = value101.width;
  const value103 = 70;
  for (let value104 = 0; value104 < value98.length * 3; value104++) {
    const value105 = value104 / (value98.length * 3);
    const value106 = value99 - value102 / 2 + value102 * value105;
    const value107 = value100 - value103 / 2 + Math.random() * value103;
    if (Math.random() > 0.7) {
      const value108 = 3 + Math.random() * 8;
      const value109 = Math.random() * Math.PI * 2;
      value97.fillStyle = "rgba(255, 255, 255, 0.8)";
      value97.beginPath();
      value97.moveTo(value106, value107);
      value97.lineTo(value106 + Math.cos(value109) * value108, value107 + Math.sin(value109) * value108);
      value97.lineTo(value106 + Math.cos(value109 + Math.PI / 3) * value108, value107 + Math.sin(value109 + Math.PI / 3) * value108);
      value97.closePath();
      value97.fill();
    }
  }
  value97.restore();
}
function addFloatingShards(value110, value111, value112) {
  value110.save();
  value110.globalAlpha = 0.8;
  for (let value113 = 0; value113 < 10; value113++) {
    const value114 = Math.random() * value111;
    const value115 = Math.random() * value112;
    const value116 = 5 + Math.random() * 15;
    const value117 = 200 + Math.random() * 160;
    const value118 = Math.random() * Math.PI;
    drawCrystalShard(value110, value114, value115, value116, value117, value118);
  }
  for (let value119 = 0; value119 < 25; value119++) {
    const value120 = Math.random() * value111;
    const value121 = Math.random() * value112;
    const value122 = 2 + Math.random() * 6;
    const value123 = 200 + Math.random() * 160;
    value110.fillStyle = "hsla(" + value123 + ", 100%, 70%, 0.9)";
    value110.beginPath();
    value110.moveTo(value120, value121 - value122);
    value110.lineTo(value120 + value122 * 0.6, value121);
    value110.lineTo(value120, value121 + value122);
    value110.lineTo(value120 - value122 * 0.6, value121);
    value110.closePath();
    value110.fill();
  }
  value110.restore();
}
function drawCrystalShard(value124, value125, value126, value127, value128, value129) {
  value124.save();
  value124.translate(value125, value126);
  value124.rotate(value129);
  const value130 = value124.createLinearGradient(-value127, -value127, value127, value127);
  value130.addColorStop(0, "hsla(" + value128 + ", 100%, 50%, 0.8)");
  value130.addColorStop(0.5, "hsla(" + value128 + ", 100%, 70%, 0.9)");
  value130.addColorStop(1, "hsla(" + value128 + ", 100%, 50%, 0.8)");
  value124.fillStyle = value130;
  value124.beginPath();
  value124.moveTo(0, -value127);
  value124.lineTo(value127 * 0.8, 0);
  value124.lineTo(0, value127);
  value124.lineTo(-value127 * 0.8, 0);
  value124.closePath();
  value124.fill();
  value124.fillStyle = "hsla(" + value128 + ", 100%, 90%, 0.6)";
  value124.beginPath();
  value124.moveTo(0, -value127);
  value124.lineTo(value127 * 0.3, -value127 * 0.2);
  value124.lineTo(-value127 * 0.3, -value127 * 0.2);
  value124.closePath();
  value124.fill();
  value124.restore();
}
function addCrystalDust(value131, value132, value133) {
  value131.save();
  value131.globalCompositeOperation = "screen";
  for (let value134 = 0; value134 < 60; value134++) {
    const value135 = Math.random() * value132;
    const value136 = Math.random() * value133;
    const value137 = 1 + Math.random() * 3;
    const value138 = 200 + Math.random() * 160;
    const value139 = 0.6 + Math.random() * 0.4;
    value131.fillStyle = "hsla(" + value138 + ", 100%, 70%, " + value139 + ")";
    value131.beginPath();
    value131.arc(value135, value136, value137, 0, Math.PI * 2);
    value131.fill();
    value131.fillStyle = "hsla(" + value138 + ", 100%, 70%, " + value139 * 0.3 + ")";
    value131.beginPath();
    value131.arc(value135, value136, value137 * 2, 0, Math.PI * 2);
    value131.fill();
  }
  value131.restore();
}
function addGemstoneHighlights(value140, value141, value142) {
  value140.save();
  value140.globalCompositeOperation = "screen";
  value140.globalAlpha = 0.3;
  for (let value143 = 0; value143 < 20; value143++) {
    const value144 = Math.random() * value141;
    const value145 = Math.random() * value142;
    const value146 = 2 + Math.random() * 4;
    value140.fillStyle = "rgba(255, 255, 255, 0.9)";
    value140.beginPath();
    for (let value147 = 0; value147 < 5; value147++) {
      const value148 = value147 * Math.PI * 2 / 5;
      const value149 = value146 * 2;
      const value150 = value146;
      value140.lineTo(value144 + Math.cos(value148) * value149, value145 + Math.sin(value148) * value149);
      value140.lineTo(value144 + Math.cos(value148 + Math.PI / 5) * value150, value145 + Math.sin(value148 + Math.PI / 5) * value150);
    }
    value140.closePath();
    value140.fill();
  }
  value140.restore();
}
function addRainbowRefractions(value151, value152, value153) {
  value151.save();
  value151.globalCompositeOperation = "screen";
  value151.globalAlpha = 0.1;
  for (let value154 = 0; value154 < 8; value154++) {
    const value155 = Math.random() * value152;
    const value156 = Math.random() * value153;
    const value157 = 30 + Math.random() * 40;
    const value158 = Math.random() * 360;
    const value159 = value151.createRadialGradient(value155, value156, 0, value155, value156, value157);
    value159.addColorStop(0, "hsla(" + value158 + ", 100%, 70%, 0.6)");
    value159.addColorStop(1, "transparent");
    value151.fillStyle = value159;
    value151.beginPath();
    value151.arc(value155, value156, value157, 0, Math.PI * 2);
    value151.fill();
  }
  value151.restore();
}
function drawCrystalBorder(value160, value161, value162) {
  value160.save();
  const value163 = value160.createLinearGradient(0, 0, value161, 0);
  value163.addColorStop(0, "#64C8FF");
  value163.addColorStop(0.3, "#9664FF");
  value163.addColorStop(0.5, "#FFFFFF");
  value163.addColorStop(0.7, "#9664FF");
  value163.addColorStop(1, "#64C8FF");
  value160.strokeStyle = value163;
  value160.lineWidth = 10;
  value160.shadowColor = "rgba(100, 150, 255, 0.6)";
  value160.shadowBlur = 20;
  value160.strokeRect(10, 10, value161 - 20, value162 - 20);
  value160.strokeStyle = "rgba(200, 230, 255, 0.6)";
  value160.lineWidth = 3;
  value160.shadowBlur = 15;
  value160.strokeRect(20, 20, value161 - 40, value162 - 40);
  addCornerGems(value160, value161, value162);
  value160.restore();
}
function addCornerGems(value164, value165, value166) {
  value164.save();
  value164.globalAlpha = 0.8;
  const value167 = [{
    x: 30,
    y: 30,
    hue: 200
  }, {
    x: value165 - 30,
    y: 30,
    hue: 240
  }, {
    x: 30,
    y: value166 - 30,
    hue: 180
  }, {
    x: value165 - 30,
    y: value166 - 30,
    hue: 260
  }];
  value167.forEach(value168 => {
    const value169 = value164.createRadialGradient(value168.x, value168.y, 0, value168.x, value168.y, 8);
    value169.addColorStop(0, "hsla(" + value168.hue + ", 100%, 80%, 0.9)");
    value169.addColorStop(1, "hsla(" + value168.hue + ", 100%, 50%, 0.6)");
    value164.fillStyle = value169;
    value164.beginPath();
    value164.arc(value168.x, value168.y, 8, 0, Math.PI * 2);
    value164.fill();
    value164.fillStyle = "hsla(" + value168.hue + ", 100%, 95%, 0.8)";
    value164.beginPath();
    value164.arc(value168.x - 2, value168.y - 2, 3, 0, Math.PI * 2);
    value164.fill();
  });
  value164.restore();
}
function addCrystalSignature(value170, value171, value172) {
  value170.save();
  const value173 = value171 - 110;
  const value174 = value172 - 25;
  value170.font = "italic 14px \"Arial\"";
  value170.fillStyle = "rgba(200, 230, 255, 0.9)";
  value170.textAlign = "right";
  value170.textBaseline = "bottom";
  value170.shadowColor = "rgba(100, 150, 255, 0.6)";
  value170.shadowBlur = 10;
  value170.fillText("by " + getBotName(), value173, value174);
  value170.fillStyle = "#64C8FF";
  value170.beginPath();
  value170.moveTo(value173 + 5, value174 - 10);
  value170.lineTo(value173 + 10, value174 - 8);
  value170.lineTo(value173 + 5, value174 - 6);
  value170.lineTo(value173, value174 - 8);
  value170.closePath();
  value170.fill();
  value170.fillStyle = "rgba(255, 255, 255, 0.8)";
  value170.beginPath();
  value170.moveTo(value173 + 3, value174 - 9);
  value170.lineTo(value173 + 5, value174 - 8);
  value170.lineTo(value173 + 3, value174 - 7);
  value170.closePath();
  value170.fill();
  value170.restore();
}
