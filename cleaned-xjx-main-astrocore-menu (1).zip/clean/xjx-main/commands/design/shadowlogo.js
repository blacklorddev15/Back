const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "shadowlogo",
  description: "Create logos with dramatic shadow and 3D effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "👻 *SHADOW LOGO*\n\n*shadowlogo*\nshadowlogo <text>\n\n*Example:*\nshadowlogo WOLF\nshadowlogo SHADOW\nshadowlogo DARK\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ").toUpperCase();
      if (value9.length > 12) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 12 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generateShadowLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "👻 *Shadow Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [SHADOWLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message
      }, {
        quoted: value6
      });
    }
  }
};
async function generateShadowLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  const value17 = value16.createLinearGradient(0, 0, value13, value14);
  value17.addColorStop(0, "#1a1a2e");
  value17.addColorStop(0.5, "#16213e");
  value17.addColorStop(1, "#0f3460");
  value16.fillStyle = value17;
  value16.fillRect(0, 0, value13, value14);
  addBackgroundTexture(value16, value13, value14);
  createShadowLayers(value16, value12, value13, value14);
  drawMainText(value16, value12, value13, value14);
  addShadowParticles(value16, value13, value14);
  addLightSource(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function addBackgroundTexture(value18, value19, value20) {
  value18.globalAlpha = 0.03;
  for (let value21 = 0; value21 < 2000; value21++) {
    const value22 = Math.random() * value19;
    const value23 = Math.random() * value20;
    const value24 = Math.random() * 2 + 0.5;
    value18.fillStyle = "#ffffff";
    value18.fillRect(value22, value23, value24, value24);
  }
  value18.globalAlpha = 1;
  const value25 = value18.createRadialGradient(value19 / 2, value20 / 2, 0, value19 / 2, value20 / 2, Math.max(value19, value20) / 2);
  value25.addColorStop(0, "transparent");
  value25.addColorStop(0.7, "transparent");
  value25.addColorStop(1, "rgba(0, 0, 0, 0.5)");
  value18.fillStyle = value25;
  value18.fillRect(0, 0, value19, value20);
}
function createShadowLayers(value26, value27, value28, value29) {
  const value30 = value28 / 2;
  const value31 = value29 / 2;
  const value32 = 15;
  const value33 = 20;
  for (let value34 = value32; value34 > 0; value34--) {
    const value35 = value34 / value32 * value33;
    const value36 = 0.1 + value34 / value32 * 0.3;
    value26.save();
    value26.translate(value30 + value35, value31 + value35);
    const value37 = 1 - value34 / value32;
    value26.fillStyle = "rgba(0, 0, 0, " + value36 * value37 + ")";
    value26.font = "bold 80px Arial";
    value26.textAlign = "center";
    value26.textBaseline = "middle";
    value26.fillText(value27, 0, 0);
    value26.restore();
  }
  value26.shadowColor = "rgba(0, 0, 0, 0.8)";
  value26.shadowBlur = 30;
  value26.shadowOffsetX = 15;
  value26.shadowOffsetY = 15;
  value26.fillStyle = "rgba(0, 0, 0, 0.6)";
  value26.font = "bold 80px Arial";
  value26.textAlign = "center";
  value26.textBaseline = "middle";
  value26.fillText(value27, value30 + 15, value31 + 15);
  value26.shadowColor = "transparent";
  value26.shadowBlur = 0;
  value26.shadowOffsetX = 0;
  value26.shadowOffsetY = 0;
}
function drawMainText(value38, value39, value40, value41) {
  const value42 = value40 / 2;
  const value43 = value41 / 2;
  value38.shadowColor = "rgba(255, 255, 255, 0.3)";
  value38.shadowBlur = 20;
  value38.shadowOffsetX = -2;
  value38.shadowOffsetY = -2;
  value38.fillStyle = "rgba(255, 255, 255, 0.1)";
  value38.font = "bold 80px Arial";
  value38.textAlign = "center";
  value38.textBaseline = "middle";
  value38.fillText(value39, value42 - 2, value43 - 2);
  const value44 = value38.createLinearGradient(value42 - 200, value43 - 50, value42 + 200, value43 + 50);
  value44.addColorStop(0, "#e0e0e0");
  value44.addColorStop(0.2, "#b8b8b8");
  value44.addColorStop(0.5, "#909090");
  value44.addColorStop(0.8, "#686868");
  value44.addColorStop(1, "#404040");
  value38.shadowColor = "transparent";
  value38.fillStyle = value44;
  value38.fillText(value39, value42, value43);
  const value45 = value38.createLinearGradient(value42 - 200, value43 - 50, value42 + 200, value43 - 30);
  value45.addColorStop(0, "rgba(255, 255, 255, 0.8)");
  value45.addColorStop(1, "rgba(255, 255, 255, 0.2)");
  value38.fillStyle = value45;
  value38.globalCompositeOperation = "screen";
  value38.fillText(value39, value42, value43);
  value38.globalCompositeOperation = "source-over";
  value38.strokeStyle = "rgba(0, 0, 0, 0.5)";
  value38.lineWidth = 1;
  value38.strokeText(value39, value42, value43);
}
function addShadowParticles(value46, value47, value48) {
  value46.globalAlpha = 0.6;
  for (let value49 = 0; value49 < 8; value49++) {
    const value50 = Math.random() * value47;
    const value51 = Math.random() * value48;
    const value52 = Math.random() * 100 + 50;
    const value53 = value46.createRadialGradient(value50, value51, 0, value50, value51, value52);
    value53.addColorStop(0, "rgba(0, 0, 0, 0.8)");
    value53.addColorStop(1, "transparent");
    value46.fillStyle = value53;
    value46.beginPath();
    value46.arc(value50, value51, value52, 0, Math.PI * 2);
    value46.fill();
  }
  value46.fillStyle = "rgba(0, 0, 0, 0.4)";
  for (let value54 = 0; value54 < 50; value54++) {
    const value55 = Math.random() * value47;
    const value56 = Math.random() * value48;
    const value57 = Math.random() * 8 + 2;
    value46.beginPath();
    value46.arc(value55, value56, value57, 0, Math.PI * 2);
    value46.fill();
  }
  value46.globalAlpha = 1;
}
function addLightSource(value58, value59, value60) {
  const value61 = value59 * 0.3;
  const value62 = value60 * 0.3;
  const value63 = value58.createRadialGradient(value61, value62, 0, value61, value62, 200);
  value63.addColorStop(0, "rgba(255, 255, 255, 0.1)");
  value63.addColorStop(0.5, "rgba(255, 255, 255, 0.05)");
  value63.addColorStop(1, "transparent");
  value58.fillStyle = value63;
  value58.beginPath();
  value58.arc(value61, value62, 200, 0, Math.PI * 2);
  value58.fill();
  value58.strokeStyle = "rgba(255, 255, 255, 0.1)";
  value58.lineWidth = 1;
  for (let value64 = 0; value64 < 12; value64++) {
    const value65 = value64 / 12 * Math.PI * 2;
    const value66 = 300;
    value58.beginPath();
    value58.moveTo(value61, value62);
    value58.lineTo(value61 + Math.cos(value65) * value66, value62 + Math.sin(value65) * value66);
    value58.stroke();
  }
}
async function generateDeepShadowLogo(value67) {
  const value68 = 800;
  const value69 = 400;
  const value70 = createCanvas(value68, value69);
  const value71 = value70.getContext("2d");
  value71.fillStyle = "#000000";
  value71.fillRect(0, 0, value68, value69);
  const value72 = value68 / 2;
  const value73 = value69 / 2;
  for (let value74 = 0; value74 < 25; value74++) {
    const value75 = value74 * 1.5;
    const value76 = 0.05 + value74 / 25 * 0.2;
    value71.fillStyle = "rgba(0, 0, 0, " + value76 + ")";
    value71.font = "bold 85px Arial";
    value71.textAlign = "center";
    value71.textBaseline = "middle";
    value71.fillText(value67, value72 + value75, value73 + value75);
  }
  value71.shadowColor = "rgba(255, 255, 255, 0.1)";
  value71.shadowBlur = 15;
  value71.fillStyle = "#666666";
  value71.fillText(value67, value72, value73);
  return value70.toBuffer("image/png");
}
async function generateFloatingShadowLogo(value77) {
  const value78 = 800;
  const value79 = 400;
  const value80 = createCanvas(value78, value79);
  const value81 = value80.getContext("2d");
  const value82 = value81.createLinearGradient(0, 0, value78, value79);
  value82.addColorStop(0, "#667eea");
  value82.addColorStop(1, "#764ba2");
  value81.fillStyle = value82;
  value81.fillRect(0, 0, value78, value79);
  const value83 = value78 / 2;
  const value84 = value79 / 2;
  value81.shadowColor = "rgba(0, 0, 0, 0.6)";
  value81.shadowBlur = 40;
  value81.shadowOffsetX = 0;
  value81.shadowOffsetY = 20;
  value81.fillStyle = "#2c3e50";
  value81.font = "bold 80px Arial";
  value81.textAlign = "center";
  value81.textBaseline = "middle";
  value81.fillText(value77, value83, value84);
  value81.shadowColor = "transparent";
  const value85 = value81.createLinearGradient(value83 - 200, value84 - 50, value83 + 200, value84 + 50);
  value85.addColorStop(0, "#ecf0f1");
  value85.addColorStop(1, "#bdc3c7");
  value81.fillStyle = value85;
  value81.fillText(value77, value83, value84 - 10);
  return value80.toBuffer("image/png");
}
