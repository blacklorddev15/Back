const {
  createCanvas
} = require("@napi-rs/canvas");
const database = require("../../database");
function getBotName() {
  return database.getBotSetting("botName") || "JuneX-Ultra";
}
function getFooter() {
  return "> Powered by " + getBotName();
}
function addWatermark(value1, value2, value3, value4 = getBotName()) {
  value1.save();
  value1.shadowColor = "transparent";
  value1.shadowBlur = 0;
  value1.globalAlpha = 0.6;
  value1.font = "bold 16px Arial";
  value1.textAlign = "center";
  value1.textBaseline = "bottom";
  value1.fillStyle = "#FFFFFF";
  value1.strokeStyle = "#000000";
  value1.lineWidth = 2;
  value1.strokeText(value4, value2 / 2, value3 - 10);
  value1.fillText(value4, value2 / 2, value3 - 10);
  value1.restore();
}
module.exports = {
  name: "phoenixlogo",
  description: "Create magnificent phoenix text logos with fire, rebirth and mystical effects",
  category: "design",
  async execute(value5, value6, value7) {
    const value8 = value6.key.remoteJid;
    try {
      if (value7.length === 0) {
        await value5.sendMessage(value8, {
          text: "🔥 *PHOENIX LOGO*\n\n*phoenixlogo*\nphoenixlogo <text>\n\n*Example:*\nphoenixlogo PHOENIX\nphoenixlogo REBIRTH\nphoenixlogo FIREBIRD\n\n" + getFooter(value6.key.participant || value6.key.remoteJid)
        }, {
          quoted: value6
        });
        return;
      }
      const value9 = value7.join(" ");
      if (value9.length > 10) {
        await value5.sendMessage(value8, {
          text: "❌ *ERROR*\n\nText too long!\nMaximum 10 characters\nYour text: \"" + value9 + "\" (" + value9.length + " chars)"
        }, {
          quoted: value6
        });
        return;
      }
      await value5.sendMessage(value8, {
        react: {
          text: "⏳",
          key: value6.key
        }
      });
      const value10 = await generatePhoenixLogo(value9);
      await value5.sendMessage(value8, {
        image: value10,
        caption: "🔥 *Phoenix Logo Generated!*\nText: " + value9 + "\n\n_Created by " + getBotName() + "_"
      }, {
        quoted: value6
      });
      await value5.sendMessage(value8, {
        react: {
          text: "✅",
          key: value6.key
        }
      });
    } catch (error11) {
      console.error("❌ [PHOENIXLOGO] ERROR:", error11);
      await value5.sendMessage(value8, {
        react: {
          text: "❌",
          key: value6.key
        }
      }).catch(() => {});
      await value5.sendMessage(value8, {
        text: "❌ *ERROR*\n\n" + error11.message + "\nPlease try again with shorter text"
      }, {
        quoted: value6
      });
    }
  }
};
async function generatePhoenixLogo(value12) {
  const value13 = 800;
  const value14 = 400;
  const value15 = createCanvas(value13, value14);
  const value16 = value15.getContext("2d");
  createPhoenixSky(value16, value13, value14);
  const value17 = value13 * 0.75;
  const value18 = value14 * 0.5;
  drawMajesticPhoenix(value16, value17, value18);
  addPhoenixFireAura(value16, value17, value18);
  addFlamingWings(value16, value17, value18);
  addFireTail(value16, value17, value18);
  drawRebirthText(value16, value12, value13, value14);
  addAshesParticles(value16, value13, value14);
  addRebirthParticles(value16, value13, value14);
  addFloatingEmbers(value16, value13, value14);
  addFireTrails(value16, value13, value14);
  addMysticalEnergy(value16, value13, value14);
  addNebulaBackground(value16, value13, value14);
  drawPhoenixBorder(value16, value13, value14);
  addPhoenixSignature(value16, value13, value14);
  addWatermark(value16, value13, value14);
  return value15.toBuffer("image/png");
}
function createPhoenixSky(value19, value20, value21) {
  const value22 = value19.createLinearGradient(0, 0, 0, value21);
  value22.addColorStop(0, "#8B0000");
  value22.addColorStop(0.2, "#FF4500");
  value22.addColorStop(0.4, "#FF8C00");
  value22.addColorStop(0.6, "#FFD700");
  value22.addColorStop(0.8, "#FF6347");
  value22.addColorStop(1, "#DC143C");
  value19.fillStyle = value22;
  value19.fillRect(0, 0, value20, value21);
  addFireClouds(value19, value20, value21);
}
function addFireClouds(value23, value24, value25) {
  value23.save();
  value23.globalAlpha = 0.4;
  value23.globalCompositeOperation = "screen";
  const value26 = [{
    x: value24 * 0.2,
    y: value25 * 0.3,
    size: 100,
    color: [255, 100, 0]
  }, {
    x: value24 * 0.7,
    y: value25 * 0.2,
    size: 80,
    color: [255, 150, 0]
  }, {
    x: value24 * 0.3,
    y: value25 * 0.7,
    size: 120,
    color: [255, 200, 0]
  }, {
    x: value24 * 0.8,
    y: value25 * 0.6,
    size: 90,
    color: [255, 100, 50]
  }];
  value26.forEach(value27 => {
    const [value28, value29, value30] = value27.color;
    const value31 = value23.createRadialGradient(value27.x, value27.y, 0, value27.x, value27.y, value27.size);
    value31.addColorStop(0, "rgba(" + value28 + ", " + value29 + ", " + value30 + ", 0.7)");
    value31.addColorStop(1, "transparent");
    value23.fillStyle = value31;
    value23.beginPath();
    value23.arc(value27.x, value27.y, value27.size, 0, Math.PI * 2);
    value23.fill();
  });
  value23.restore();
}
function drawMajesticPhoenix(value32, value33, value34) {
  value32.save();
  const value35 = value32.createRadialGradient(value33, value34, 0, value33, value34, 60);
  value35.addColorStop(0, "rgba(255, 255, 200, 0.9)");
  value35.addColorStop(0.5, "rgba(255, 200, 100, 0.6)");
  value35.addColorStop(1, "rgba(255, 150, 50, 0.3)");
  value32.fillStyle = value35;
  value32.beginPath();
  value32.arc(value33, value34, 60, 0, Math.PI * 2);
  value32.fill();
  const value36 = value32.createRadialGradient(value33 - 10, value34 - 10, 0, value33, value34, 25);
  value36.addColorStop(0, "#FFFF00");
  value36.addColorStop(0.3, "#FFD700");
  value36.addColorStop(0.7, "#FF8C00");
  value36.addColorStop(1, "#FF4500");
  value32.fillStyle = value36;
  value32.beginPath();
  value32.arc(value33, value34, 25, 0, Math.PI * 2);
  value32.fill();
  drawPhoenixHead(value32, value33, value34);
  drawPhoenixLegs(value32, value33, value34);
  value32.restore();
}
function drawPhoenixHead(value37, value38, value39) {
  const value40 = value37.createLinearGradient(value38, value39 - 15, value38 + 35, value39 - 40);
  value40.addColorStop(0, "#FFD700");
  value40.addColorStop(1, "#FF8C00");
  value37.strokeStyle = value40;
  value37.lineWidth = 8;
  value37.lineCap = "round";
  value37.beginPath();
  value37.moveTo(value38, value39 - 15);
  value37.lineTo(value38 + 35, value39 - 40);
  value37.stroke();
  value37.fillStyle = "#FF8C00";
  value37.beginPath();
  value37.arc(value38 + 40, value39 - 45, 12, 0, Math.PI * 2);
  value37.fill();
  const value41 = ["#FFFF00", "#FFD700", "#FF8C00"];
  value41.forEach((value42, value43) => {
    const value44 = -0.5 + value43 * 0.5;
    const value45 = 15 + value43 * 5;
    value37.strokeStyle = value42;
    value37.lineWidth = 4 - value43;
    value37.lineCap = "round";
    value37.beginPath();
    value37.moveTo(value38 + 40, value39 - 45);
    value37.lineTo(value38 + 40 + Math.cos(value44) * value45, value39 - 45 + Math.sin(value44) * value45);
    value37.stroke();
  });
  value37.fillStyle = "#FF4500";
  value37.beginPath();
  value37.arc(value38 + 45, value39 - 47, 3, 0, Math.PI * 2);
  value37.fill();
  value37.fillStyle = "#FFFF00";
  value37.beginPath();
  value37.arc(value38 + 46, value39 - 48, 1, 0, Math.PI * 2);
  value37.fill();
  value37.strokeStyle = "#FF6347";
  value37.lineWidth = 3;
  value37.lineCap = "round";
  value37.beginPath();
  value37.moveTo(value38 + 48, value39 - 43);
  value37.lineTo(value38 + 55, value39 - 45);
  value37.stroke();
}
function drawPhoenixLegs(value46, value47, value48) {
  value46.strokeStyle = "#FF8C00";
  value46.lineWidth = 4;
  value46.lineCap = "round";
  value46.beginPath();
  value46.moveTo(value47 + 5, value48 + 20);
  value46.lineTo(value47 + 10, value48 + 35);
  value46.stroke();
  value46.beginPath();
  value46.moveTo(value47 - 5, value48 + 25);
  value46.lineTo(value47 - 8, value48 + 40);
  value46.stroke();
  value46.strokeStyle = "#FF6347";
  value46.lineWidth = 2;
  const value49 = [{
    x: value47 + 10,
    y: value48 + 35
  }, {
    x: value47 - 8,
    y: value48 + 40
  }];
  value49.forEach(value50 => {
    for (let value51 = 0; value51 < 3; value51++) {
      const value52 = -0.3 + value51 * 0.3;
      const value53 = 8;
      value46.beginPath();
      value46.moveTo(value50.x, value50.y);
      value46.lineTo(value50.x + Math.cos(value52) * value53, value50.y + Math.sin(value52) * value53);
      value46.stroke();
    }
  });
}
function addPhoenixFireAura(value54, value55, value56) {
  value54.save();
  value54.globalCompositeOperation = "screen";
  const value57 = [{
    size: 120,
    alpha: 0.4,
    color: [255, 255, 200]
  }, {
    size: 90,
    alpha: 0.6,
    color: [255, 200, 100]
  }, {
    size: 60,
    alpha: 0.8,
    color: [255, 150, 50]
  }];
  value57.forEach(value58 => {
    const [value59, value60, value61] = value58.color;
    const value62 = value54.createRadialGradient(value55, value56, 0, value55, value56, value58.size);
    value62.addColorStop(0, "rgba(" + value59 + ", " + value60 + ", " + value61 + ", " + value58.alpha + ")");
    value62.addColorStop(1, "transparent");
    value54.fillStyle = value62;
    value54.beginPath();
    value54.arc(value55, value56, value58.size, 0, Math.PI * 2);
    value54.fill();
  });
  for (let value63 = 0; value63 < 3; value63++) {
    const value64 = 150 + value63 * 30;
    const value65 = 0.2 - value63 * 0.05;
    value54.strokeStyle = "rgba(255, 200, 100, " + value65 + ")";
    value54.lineWidth = 8;
    value54.beginPath();
    value54.arc(value55, value56, value64, 0, Math.PI * 2);
    value54.stroke();
  }
  value54.restore();
}
function addFlamingWings(value66, value67, value68) {
  value66.save();
  value66.globalCompositeOperation = "screen";
  value66.globalAlpha = 0.8;
  const value69 = value66.createLinearGradient(value67 - 20, value68 - 10, value67 - 80, value68 - 50);
  value69.addColorStop(0, "#FFFF00");
  value69.addColorStop(0.3, "#FFD700");
  value69.addColorStop(0.7, "#FF8C00");
  value69.addColorStop(1, "#FF4500");
  value66.fillStyle = value69;
  value66.beginPath();
  value66.moveTo(value67 - 20, value68 - 10);
  value66.bezierCurveTo(value67 - 40, value68 - 60, value67 - 70, value68 - 30, value67 - 80, value68 - 10);
  value66.bezierCurveTo(value67 - 70, value68 + 10, value67 - 40, value68 - 5, value67 - 20, value68 - 10);
  value66.closePath();
  value66.fill();
  const value70 = value66.createLinearGradient(value67 + 20, value68 - 10, value67 + 80, value68 - 50);
  value70.addColorStop(0, "#FFFF00");
  value70.addColorStop(0.3, "#FFD700");
  value70.addColorStop(0.7, "#FF8C00");
  value70.addColorStop(1, "#FF4500");
  value66.fillStyle = value70;
  value66.beginPath();
  value66.moveTo(value67 + 20, value68 - 10);
  value66.bezierCurveTo(value67 + 40, value68 - 60, value67 + 70, value68 - 30, value67 + 80, value68 - 10);
  value66.bezierCurveTo(value67 + 70, value68 + 10, value67 + 40, value68 - 5, value67 + 20, value68 - 10);
  value66.closePath();
  value66.fill();
  addWingFlames(value66, value67, value68);
  value66.restore();
}
function addWingFlames(value71, value72, value73) {
  value71.strokeStyle = "rgba(255, 255, 200, 0.8)";
  value71.lineWidth = 3;
  value71.lineCap = "round";
  const value74 = [{
    start: {
      x: value72 - 30,
      y: value73 - 25
    },
    end: {
      x: value72 - 50,
      y: value73 - 45
    }
  }, {
    start: {
      x: value72 - 40,
      y: value73 - 15
    },
    end: {
      x: value72 - 65,
      y: value73 - 25
    }
  }, {
    start: {
      x: value72 - 50,
      y: value73 - 5
    },
    end: {
      x: value72 - 75,
      y: value73 - 10
    }
  }];
  value74.forEach(value75 => {
    value71.beginPath();
    value71.moveTo(value75.start.x, value75.start.y);
    value71.lineTo(value75.end.x, value75.end.y);
    value71.stroke();
  });
  const value76 = [{
    start: {
      x: value72 + 30,
      y: value73 - 25
    },
    end: {
      x: value72 + 50,
      y: value73 - 45
    }
  }, {
    start: {
      x: value72 + 40,
      y: value73 - 15
    },
    end: {
      x: value72 + 65,
      y: value73 - 25
    }
  }, {
    start: {
      x: value72 + 50,
      y: value73 - 5
    },
    end: {
      x: value72 + 75,
      y: value73 - 10
    }
  }];
  value76.forEach(value77 => {
    value71.beginPath();
    value71.moveTo(value77.start.x, value77.start.y);
    value71.lineTo(value77.end.x, value77.end.y);
    value71.stroke();
  });
}
function addFireTail(value78, value79, value80) {
  value78.save();
  value78.globalCompositeOperation = "screen";
  value78.globalAlpha = 0.9;
  const value81 = value78.createLinearGradient(value79 - 20, value80 + 15, value79 - 120, value80 + 5);
  value81.addColorStop(0, "#FFFF00");
  value81.addColorStop(0.2, "#FFD700");
  value81.addColorStop(0.5, "#FF8C00");
  value81.addColorStop(0.8, "#FF4500");
  value81.addColorStop(1, "#DC143C");
  value78.strokeStyle = value81;
  value78.lineWidth = 12;
  value78.lineCap = "round";
  value78.beginPath();
  value78.moveTo(value79 - 20, value80 + 15);
  value78.bezierCurveTo(value79 - 50, value80 + 30, value79 - 80, value80 + 10, value79 - 120, value80 + 5);
  value78.stroke();
  for (let value82 = 0; value82 < 4; value82++) {
    const value83 = (Math.random() - 0.5) * 20;
    const value84 = 6 + Math.random() * 4;
    value78.lineWidth = value84;
    value78.beginPath();
    value78.moveTo(value79 - 20, value80 + 15);
    value78.bezierCurveTo(value79 - 45, value80 + 25 + value83, value79 - 75, value80 + 8 + value83, value79 - 110, value80 + 3 + value83);
    value78.stroke();
  }
  value78.strokeStyle = "rgba(255, 200, 100, 0.4)";
  value78.lineWidth = 25;
  value78.beginPath();
  value78.moveTo(value79 - 20, value80 + 15);
  value78.bezierCurveTo(value79 - 50, value80 + 30, value79 - 80, value80 + 10, value79 - 120, value80 + 5);
  value78.stroke();
  value78.restore();
}
function drawRebirthText(value85, value86, value87, value88) {
  const value89 = value87 * 0.35;
  const value90 = value88 * 0.6;
  value85.save();
  value85.shadowColor = "rgba(255, 100, 0, 0.8)";
  value85.shadowBlur = 40;
  const value91 = value85.createLinearGradient(value89 - 100, value90 - 50, value89 + 100, value90 + 50);
  value91.addColorStop(0, "#FFFF00");
  value91.addColorStop(0.2, "#FFD700");
  value91.addColorStop(0.5, "#FF8C00");
  value91.addColorStop(0.8, "#FF4500");
  value91.addColorStop(1, "#DC143C");
  value85.font = "bold 70px \"Arial\"";
  value85.textAlign = "center";
  value85.textBaseline = "middle";
  value85.fillStyle = value91;
  value85.fillText(value86.toUpperCase(), value89, value90);
  value85.shadowColor = "transparent";
  value85.fillStyle = "rgba(255, 255, 200, 0.7)";
  value85.fillText(value86.toUpperCase(), value89, value90);
  value85.strokeStyle = "rgba(255, 255, 255, 0.8)";
  value85.lineWidth = 2;
  value85.strokeText(value86.toUpperCase(), value89, value90);
  addTextFlames(value85, value86, value89, value90);
  value85.restore();
}
function addTextFlames(value92, value93, value94, value95) {
  value92.save();
  value92.globalCompositeOperation = "screen";
  const value96 = value92.measureText(value93.toUpperCase());
  const value97 = value96.width;
  const value98 = 70;
  for (let value99 = 0; value99 < 20; value99++) {
    const value100 = value94 - value97 / 2 + Math.random() * value97;
    const value101 = value95 + value98 / 2 - Math.random() * 10;
    const value102 = 10 + Math.random() * 20;
    const value103 = 2 + Math.random() * 4;
    const value104 = value92.createLinearGradient(value100, value101, value100, value101 - value102);
    value104.addColorStop(0, "rgba(255, 255, 200, 0.8)");
    value104.addColorStop(0.5, "rgba(255, 200, 100, 0.6)");
    value104.addColorStop(1, "rgba(255, 150, 50, 0.3)");
    value92.strokeStyle = value104;
    value92.lineWidth = value103;
    value92.lineCap = "round";
    value92.beginPath();
    value92.moveTo(value100, value101);
    value92.lineTo(value100, value101 - value102);
    value92.stroke();
  }
  value92.restore();
}
function addAshesParticles(value105, value106, value107) {
  value105.save();
  value105.globalAlpha = 0.6;
  for (let value108 = 0; value108 < 50; value108++) {
    const value109 = Math.random() * value106;
    const value110 = Math.random() * value107;
    const value111 = 1 + Math.random() * 3;
    const value112 = 80 + Math.random() * 40;
    value105.fillStyle = "rgba(" + value112 + ", " + value112 + ", " + value112 + ", 0.7)";
    value105.beginPath();
    value105.arc(value109, value110, value111, 0, Math.PI * 2);
    value105.fill();
    const value113 = 3 + Math.random() * 8;
    const value114 = Math.random() * Math.PI * 2;
    value105.strokeStyle = "rgba(" + value112 + ", " + value112 + ", " + value112 + ", 0.4)";
    value105.lineWidth = value111 * 0.5;
    value105.lineCap = "round";
    value105.beginPath();
    value105.moveTo(value109, value110);
    value105.lineTo(value109 + Math.cos(value114) * value113, value110 + Math.sin(value114) * value113);
    value105.stroke();
  }
  value105.restore();
}
function addRebirthParticles(value115, value116, value117) {
  value115.save();
  value115.globalCompositeOperation = "screen";
  for (let value118 = 0; value118 < 40; value118++) {
    const value119 = Math.random() * value116;
    const value120 = Math.random() * value117;
    const value121 = 1 + Math.random() * 4;
    const value122 = 30 + Math.random() * 30;
    value115.fillStyle = "hsla(" + value122 + ", 100%, 70%, 0.8)";
    value115.beginPath();
    value115.arc(value119, value120, value121, 0, Math.PI * 2);
    value115.fill();
    value115.fillStyle = "hsla(" + value122 + ", 100%, 70%, 0.3)";
    value115.beginPath();
    value115.arc(value119, value120, value121 * 2, 0, Math.PI * 2);
    value115.fill();
  }
  value115.restore();
}
function addFloatingEmbers(value123, value124, value125) {
  value123.save();
  value123.globalCompositeOperation = "screen";
  for (let value126 = 0; value126 < 30; value126++) {
    const value127 = Math.random() * value124;
    const value128 = Math.random() * value125;
    const value129 = 1 + Math.random() * 2;
    const value130 = 0.6 + Math.random() * 0.4;
    value123.fillStyle = "rgba(255, 255, 200, " + value130 + ")";
    value123.beginPath();
    value123.arc(value127, value128, value129, 0, Math.PI * 2);
    value123.fill();
    value123.fillStyle = "rgba(255, 200, 100, " + value130 * 0.3 + ")";
    value123.beginPath();
    value123.arc(value127, value128, value129 * 3, 0, Math.PI * 2);
    value123.fill();
  }
  value123.restore();
}
function addFireTrails(value131, value132, value133) {
  value131.save();
  value131.globalCompositeOperation = "screen";
  value131.globalAlpha = 0.3;
  for (let value134 = 0; value134 < 5; value134++) {
    const value135 = Math.random() * value132;
    const value136 = value133 + 20;
    const value137 = value135 + (Math.random() - 0.5) * 100;
    const value138 = Math.random() * value133 * 0.3;
    const value139 = value131.createLinearGradient(value135, value136, value137, value138);
    value139.addColorStop(0, "rgba(255, 255, 200, 0.6)");
    value139.addColorStop(0.5, "rgba(255, 200, 100, 0.4)");
    value139.addColorStop(1, "rgba(255, 150, 50, 0.2)");
    value131.strokeStyle = value139;
    value131.lineWidth = 8;
    value131.lineCap = "round";
    value131.beginPath();
    value131.moveTo(value135, value136);
    value131.lineTo(value137, value138);
    value131.stroke();
  }
  value131.restore();
}
function addMysticalEnergy(value140, value141, value142) {
  value140.save();
  value140.globalCompositeOperation = "screen";
  value140.globalAlpha = 0.2;
  const value143 = [{
    x: value141 * 0.2,
    y: value142 * 0.3,
    size: 40
  }, {
    x: value141 * 0.8,
    y: value142 * 0.7,
    size: 35
  }, {
    x: value141 * 0.4,
    y: value142 * 0.2,
    size: 45
  }];
  value143.forEach(value144 => {
    const value145 = value140.createRadialGradient(value144.x, value144.y, 0, value144.x, value144.y, value144.size);
    value145.addColorStop(0, "rgba(255, 255, 200, 0.6)");
    value145.addColorStop(1, "transparent");
    value140.fillStyle = value145;
    value140.beginPath();
    value140.arc(value144.x, value144.y, value144.size, 0, Math.PI * 2);
    value140.fill();
  });
  value140.restore();
}
function addNebulaBackground(value146, value147, value148) {
  value146.save();
  value146.globalAlpha = 0.15;
  value146.globalCompositeOperation = "screen";
  const value149 = [{
    x: value147 * 0.3,
    y: value148 * 0.4,
    size: 120,
    color: [255, 100, 0]
  }, {
    x: value147 * 0.7,
    y: value148 * 0.3,
    size: 100,
    color: [255, 150, 50]
  }, {
    x: value147 * 0.5,
    y: value148 * 0.6,
    size: 110,
    color: [255, 200, 100]
  }];
  value149.forEach(value150 => {
    const [value151, value152, value153] = value150.color;
    const value154 = value146.createRadialGradient(value150.x, value150.y, 0, value150.x, value150.y, value150.size);
    value154.addColorStop(0, "rgba(" + value151 + ", " + value152 + ", " + value153 + ", 0.4)");
    value154.addColorStop(1, "transparent");
    value146.fillStyle = value154;
    value146.beginPath();
    value146.arc(value150.x, value150.y, value150.size, 0, Math.PI * 2);
    value146.fill();
  });
  value146.restore();
}
function drawPhoenixBorder(value155, value156, value157) {
  value155.save();
  const value158 = value155.createLinearGradient(0, 0, value156, 0);
  value158.addColorStop(0, "#DC143C");
  value158.addColorStop(0.2, "#FF4500");
  value158.addColorStop(0.5, "#FFD700");
  value158.addColorStop(0.8, "#FF4500");
  value158.addColorStop(1, "#DC143C");
  value155.strokeStyle = value158;
  value155.lineWidth = 10;
  value155.shadowColor = "rgba(255, 100, 0, 0.8)";
  value155.shadowBlur = 25;
  value155.strokeRect(10, 10, value156 - 20, value157 - 20);
  value155.strokeStyle = "rgba(255, 255, 200, 0.6)";
  value155.lineWidth = 3;
  value155.shadowBlur = 15;
  value155.strokeRect(20, 20, value156 - 40, value157 - 40);
  addPhoenixFeatherAccents(value155, value156, value157);
  value155.restore();
}
function addPhoenixFeatherAccents(value159, value160, value161) {
  value159.save();
  value159.globalAlpha = 0.7;
  const value162 = [{
    x: 25,
    y: 25,
    angle: -0.8
  }, {
    x: value160 - 25,
    y: 25,
    angle: -2.4
  }, {
    x: 25,
    y: value161 - 25,
    angle: 0.8
  }, {
    x: value160 - 25,
    y: value161 - 25,
    angle: 2.4
  }];
  value162.forEach(value163 => {
    const value164 = value159.createLinearGradient(value163.x, value163.y, value163.x + Math.cos(value163.angle) * 20, value163.y + Math.sin(value163.angle) * 20);
    value164.addColorStop(0, "#FFD700");
    value164.addColorStop(1, "#FF4500");
    value159.strokeStyle = value164;
    value159.lineWidth = 4;
    value159.lineCap = "round";
    value159.beginPath();
    value159.moveTo(value163.x, value163.y);
    value159.lineTo(value163.x + Math.cos(value163.angle) * 20, value163.y + Math.sin(value163.angle) * 20);
    value159.stroke();
    for (let value165 = 0; value165 < 3; value165++) {
      const value166 = 5 + value165 * 5;
      const value167 = value163.angle + 0.3;
      const value168 = 8 - value165 * 2;
      value159.beginPath();
      value159.moveTo(value163.x + Math.cos(value163.angle) * value166, value163.y + Math.sin(value163.angle) * value166);
      value159.lineTo(value163.x + Math.cos(value163.angle) * value166 + Math.cos(value167) * value168, value163.y + Math.sin(value163.angle) * value166 + Math.sin(value167) * value168);
      value159.stroke();
    }
  });
  value159.restore();
}
function addPhoenixSignature(value169, value170, value171) {
  value169.save();
  const value172 = value170 - 110;
  const value173 = value171 - 25;
  value169.font = "italic 14px \"Arial\"";
  value169.fillStyle = "rgba(255, 255, 200, 0.9)";
  value169.textAlign = "right";
  value169.textBaseline = "bottom";
  value169.shadowColor = "rgba(255, 100, 0, 0.6)";
  value169.shadowBlur = 10;
  value169.fillText("by " + getBotName(), value172, value173);
  const value174 = value169.createLinearGradient(value172 + 5, value173 - 8, value172 + 15, value173 - 8);
  value174.addColorStop(0, "#FFD700");
  value174.addColorStop(1, "#FF4500");
  value169.strokeStyle = value174;
  value169.lineWidth = 2;
  value169.lineCap = "round";
  value169.beginPath();
  value169.moveTo(value172 + 5, value173 - 8);
  value169.lineTo(value172 + 15, value173 - 8);
  value169.stroke();
  value169.beginPath();
  value169.moveTo(value172 + 8, value173 - 8);
  value169.lineTo(value172 + 6, value173 - 12);
  value169.stroke();
  value169.restore();
}
