const fetch = require("node-fetch");
const LANG_NAMES = {
  af: "Afrikaans",
  sq: "Albanian",
  am: "Amharic",
  ar: "Arabic",
  hy: "Armenian",
  az: "Azerbaijani",
  eu: "Basque",
  be: "Belarusian",
  bn: "Bengali",
  bs: "Bosnian",
  bg: "Bulgarian",
  ca: "Catalan",
  ceb: "Cebuano",
  ny: "Chichewa",
  zh: "Chinese",
  co: "Corsican",
  hr: "Croatian",
  cs: "Czech",
  da: "Danish",
  nl: "Dutch",
  en: "English",
  eo: "Esperanto",
  et: "Estonian",
  tl: "Filipino",
  fi: "Finnish",
  fr: "French",
  fy: "Frisian",
  gl: "Galician",
  ka: "Georgian",
  de: "German",
  el: "Greek",
  gu: "Gujarati",
  ht: "Haitian Creole",
  ha: "Hausa",
  haw: "Hawaiian",
  iw: "Hebrew",
  hi: "Hindi",
  hmn: "Hmong",
  hu: "Hungarian",
  is: "Icelandic",
  ig: "Igbo",
  id: "Indonesian",
  ga: "Irish",
  it: "Italian",
  ja: "Japanese",
  jw: "Javanese",
  kn: "Kannada",
  kk: "Kazakh",
  km: "Khmer",
  ko: "Korean",
  ku: "Kurdish",
  ky: "Kyrgyz",
  lo: "Lao",
  la: "Latin",
  lv: "Latvian",
  lt: "Lithuanian",
  lb: "Luxembourgish",
  mk: "Macedonian",
  mg: "Malagasy",
  ms: "Malay",
  ml: "Malayalam",
  mt: "Maltese",
  mi: "Maori",
  mr: "Marathi",
  mn: "Mongolian",
  my: "Myanmar",
  ne: "Nepali",
  no: "Norwegian",
  ps: "Pashto",
  fa: "Persian",
  pl: "Polish",
  pt: "Portuguese",
  pa: "Punjabi",
  ro: "Romanian",
  ru: "Russian",
  sm: "Samoan",
  gd: "Scots Gaelic",
  sr: "Serbian",
  st: "Sesotho",
  sn: "Shona",
  sd: "Sindhi",
  si: "Sinhala",
  sk: "Slovak",
  sl: "Slovenian",
  so: "Somali",
  es: "Spanish",
  su: "Sundanese",
  sw: "Swahili",
  sv: "Swedish",
  tg: "Tajik",
  ta: "Tamil",
  te: "Telugu",
  th: "Thai",
  tr: "Turkish",
  uk: "Ukrainian",
  ur: "Urdu",
  uz: "Uzbek",
  vi: "Vietnamese",
  cy: "Welsh",
  xh: "Xhosa",
  yi: "Yiddish",
  yo: "Yoruba",
  zu: "Zulu"
};
function getLangName(value1) {
  if (!value1 || value1 === "auto") {
    return "Auto-detected";
  }
  return LANG_NAMES[value1.toLowerCase()] || value1.toUpperCase();
}
module.exports = {
  name: "translate2",
  aliases: ["trt2", "tr2"],
  category: "utility",
  description: "Translate text with source→target language note",
  usage: ".translate2 <lang> (reply) | .translate2 <text> <lang>",
  async execute(value2, value3, value4) {
    try {
      const value5 = value3.key.remoteJid;
      await value2.sendPresenceUpdate("composing", value5);
      let value6 = "";
      let value7 = "";
      const value8 = value3.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (value8) {
        value6 = value8.conversation || value8.extendedTextMessage?.text || value8.imageMessage?.caption || value8.videoMessage?.caption || "";
        value7 = value4.join(" ").trim() || "en";
      } else {
        if (value4.length < 1) {
          return await value2.sendMessage(value5, {
            text: "*TRANSLATOR 2*\n\n*Usage:*\n• Reply to a message: _.translate2 <lang>_\n• Direct: _.translate2 <text> <lang>_\n• No lang = defaults to English\n\n*Examples:*\n_.trt2 Bonjour fr_  →  translates to French\n_.trt2 Hello_  →  translates to English\n\n*Common codes:* en es fr de it pt ru ja ko zh ar hi sw"
          }, {
            quoted: value3
          });
        }
        const value9 = value4[value4.length - 1];
        const value10 = /^[a-zA-Z]{2,5}$/.test(value9) && value4.length >= 2;
        if (value10) {
          value7 = value9.toLowerCase();
          value6 = value4.slice(0, -1).join(" ");
        } else {
          value7 = "en";
          value6 = value4.join(" ");
        }
      }
      if (!value6.trim()) {
        return await value2.sendMessage(value5, {
          text: "❌ No text to translate."
        }, {
          quoted: value3
        });
      }
      let value11 = null;
      let value12 = null;
      try {
        const value13 = await fetch("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" + value7 + "&dt=t&ld&q=" + encodeURIComponent(value6));
        if (value13.ok) {
          const value14 = await value13.json();
          if (value14?.[0]?.[0]?.[0]) {
            value11 = value14[0].map(value15 => value15?.[0] || "").join("");
            value12 = value14?.[2] || null;
          }
        }
      } catch {}
      if (!value11) {
        try {
          const value16 = await fetch("https://api.mymemory.translated.net/get?q=" + encodeURIComponent(value6) + "&langpair=auto|" + value7);
          if (value16.ok) {
            const value17 = await value16.json();
            if (value17?.responseData?.translatedText) {
              value11 = value17.responseData.translatedText;
              const value18 = value17?.responseData?.detectedLanguage;
              if (value18) {
                value12 = value18.split("|")[0].toLowerCase();
              }
            }
          }
        } catch {}
      }
      if (!value11) {
        try {
          const value19 = await fetch("https://api.dreaded.site/api/translate?text=" + encodeURIComponent(value6) + "&lang=" + value7);
          if (value19.ok) {
            const value20 = await value19.json();
            if (value20?.translated) {
              value11 = value20.translated;
            }
          }
        } catch {}
      }
      if (!value11) {
        return await value2.sendMessage(value5, {
          text: "❌ Translation failed. Please try again later."
        }, {
          quoted: value3
        });
      }
      const value21 = getLangName(value12);
      const value22 = getLangName(value7);
      const value23 = value11 + "\n\n" + ("_(" + value21 + " → " + value22 + ")_");
      await value2.sendMessage(value5, {
        text: value23
      }, {
        quoted: value3
      });
    } catch (error24) {
      console.error("❌ Error in translate2 command:", error24);
      await value2.sendMessage(value3.key.remoteJid, {
        text: "❌ Failed to translate. Please try again later."
      }, {
        quoted: value3
      });
    }
  }
};
