const axios = require("axios");
const {
  sendButtons
} = require("gifted-btns");
const database = require("../../database");
module.exports = {
  name: "weather",
  aliases: ["w", "clima"],
  category: "utility",
  description: "Get weather for a city",
  usage: ".weather <city>",
  async execute(value1, value2, value3, value4) {
    try {
      if (value3.length === 0) {
        return value4.reply("❌ Please provide a city name!\nExample: .weather London");
      }
      const value5 = value3.join(" ");
      const value6 = "4902c0f2550f58298ad4146a92b65e10";
      await value1.sendMessage(value4.from, {
        react: {
          text: "⏳",
          key: value2.key
        }
      });
      const {
        data: value7
      } = await axios.get("https://api.openweathermap.org/data/2.5/weather?q=" + encodeURIComponent(value5) + "&appid=" + value6 + "&units=metric");
      const value8 = value9 => {
        const value10 = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
        return value10[Math.round(value9 / 45) % 8];
      };
      const value11 = value12 => {
        const value13 = new Date(value12 * 1000);
        return value13.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit"
        });
      };
      const value14 = "┏━━『 🌤️ *WEATHER INFO* 』━━\n\n" + ("🏙️ *City:* " + value7.name + ", " + value7.sys.country + "\n") + ("🌍 *Coordinates:* " + value7.coord.lat + "°N, " + value7.coord.lon + "°E\n\n") + "┃ *Conditions*\n" + ("☁️ *Weather:* " + value7.weather[0].main + "\n") + ("📋 *Description:* " + (value7.weather[0].description.charAt(0).toUpperCase() + value7.weather[0].description.slice(1)) + "\n\n") + "┃ *Temperature*\n" + ("🌡️ *Temp:* " + value7.main.temp + "°C\n") + ("🔥 *Feels Like:* " + value7.main.feels_like + "°C\n") + ("⬆️ *Max:* " + value7.main.temp_max + "°C\n") + ("⬇️ *Min:* " + value7.main.temp_min + "°C\n\n") + "┃ *Atmosphere*\n" + ("💧 *Humidity:* " + value7.main.humidity + "%\n") + ("🌬️ *Wind:* " + value7.wind.speed + " m/s " + value8(value7.wind.deg) + "\n") + ("👁️ *Visibility:* " + (value7.visibility / 1000).toFixed(1) + " km\n") + ("🔵 *Pressure:* " + value7.main.pressure + " hPa\n\n") + "┃ *Sun*\n" + ("🌅 *Sunrise:* " + value11(value7.sys.sunrise) + "\n") + ("🌇 *Sunset:* " + value11(value7.sys.sunset) + "\n\n") + "┗━━━━━━━━━━━━━━━━";
      await value1.sendMessage(value4.from, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
      await sendButtons(value1, value4.from, {
        text: value14,
        footer: "> Powered by " + database.getBotSetting("botName"),
        buttons: [{
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: "🌍 Full Forecast",
            url: "https://openweathermap.org/city/" + value7.id
          })
        }, {
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: "📋 Copy City Name",
            copy_code: value7.name + ", " + value7.sys.country
          })
        }]
      }, {
        quoted: value2
      });
    } catch (error15) {
      console.error("WEATHER ERROR:", error15);
      await value1.sendMessage(value4.from, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      if (error15.response?.status === 404) {
        await value4.reply("❌ City *\"" + value3.join(" ") + "\"* not found!\nCheck the spelling and try again.");
      } else if (error15.response?.status === 401) {
        await value4.reply("❌ Invalid API key!");
      } else {
        await value4.reply("❌ Failed to fetch weather: " + (error15.message || "Unknown error"));
      }
    }
  }
};
