const {
  resolvePhone
} = require("../../utils/jidHelper");
function stripJid(value1) {
  if (!value1 || typeof value1 !== "string") {
    return null;
  }
  return value1.split(":")[0].split("@")[0];
}
async function jidToNumber(value2, value3) {
  if (!value3 || typeof value3 !== "string") {
    return null;
  }
  const value4 = await resolvePhone(value2, value3);
  if (value4) {
    return String(value4).replace(/\D/g, "");
  }
  const value5 = stripJid(value3);
  if (value5) {
    return value5.replace(/\D/g, "");
  } else {
    return null;
  }
}
const COUNTRY_CODES = {
  "355": {
    name: "Albania",
    flag: "🇦🇱"
  },
  "213": {
    name: "Algeria",
    flag: "🇩🇿"
  },
  "376": {
    name: "Andorra",
    flag: "🇦🇩"
  },
  "244": {
    name: "Angola",
    flag: "🇦🇴"
  },
  "374": {
    name: "Armenia",
    flag: "🇦🇲"
  },
  "994": {
    name: "Azerbaijan",
    flag: "🇦🇿"
  },
  "973": {
    name: "Bahrain",
    flag: "🇧🇭"
  },
  "880": {
    name: "Bangladesh",
    flag: "🇧🇩"
  },
  "375": {
    name: "Belarus",
    flag: "🇧🇾"
  },
  "501": {
    name: "Belize",
    flag: "🇧🇿"
  },
  "229": {
    name: "Benin",
    flag: "🇧🇯"
  },
  "975": {
    name: "Bhutan",
    flag: "🇧🇹"
  },
  "591": {
    name: "Bolivia",
    flag: "🇧🇴"
  },
  "387": {
    name: "Bosnia & Herzegovina",
    flag: "🇧🇦"
  },
  "267": {
    name: "Botswana",
    flag: "🇧🇼"
  },
  "673": {
    name: "Brunei",
    flag: "🇧🇳"
  },
  "359": {
    name: "Bulgaria",
    flag: "🇧🇬"
  },
  "226": {
    name: "Burkina Faso",
    flag: "🇧🇫"
  },
  "257": {
    name: "Burundi",
    flag: "🇧🇮"
  },
  "855": {
    name: "Cambodia",
    flag: "🇰🇭"
  },
  "237": {
    name: "Cameroon",
    flag: "🇨🇲"
  },
  "238": {
    name: "Cape Verde",
    flag: "🇨🇻"
  },
  "236": {
    name: "Central African Republic",
    flag: "🇨🇫"
  },
  "235": {
    name: "Chad",
    flag: "🇹🇩"
  },
  "269": {
    name: "Comoros",
    flag: "🇰🇲"
  },
  "242": {
    name: "Congo (Brazzaville)",
    flag: "🇨🇬"
  },
  "243": {
    name: "Congo (Kinshasa)",
    flag: "🇨🇩"
  },
  "682": {
    name: "Cook Islands",
    flag: "🇨🇰"
  },
  "506": {
    name: "Costa Rica",
    flag: "🇨🇷"
  },
  "385": {
    name: "Croatia",
    flag: "🇭🇷"
  },
  "357": {
    name: "Cyprus",
    flag: "🇨🇾"
  },
  "420": {
    name: "Czech Republic",
    flag: "🇨🇿"
  },
  "253": {
    name: "Djibouti",
    flag: "🇩🇯"
  },
  "593": {
    name: "Ecuador",
    flag: "🇪🇨"
  },
  "503": {
    name: "El Salvador",
    flag: "🇸🇻"
  },
  "240": {
    name: "Equatorial Guinea",
    flag: "🇬🇶"
  },
  "291": {
    name: "Eritrea",
    flag: "🇪🇷"
  },
  "372": {
    name: "Estonia",
    flag: "🇪🇪"
  },
  "268": {
    name: "Eswatini",
    flag: "🇸🇿"
  },
  "251": {
    name: "Ethiopia",
    flag: "🇪🇹"
  },
  "679": {
    name: "Fiji",
    flag: "🇫🇯"
  },
  "358": {
    name: "Finland",
    flag: "🇫🇮"
  },
  "594": {
    name: "French Guiana",
    flag: "🇬🇫"
  },
  "689": {
    name: "French Polynesia",
    flag: "🇵🇫"
  },
  "241": {
    name: "Gabon",
    flag: "🇬🇦"
  },
  "220": {
    name: "Gambia",
    flag: "🇬🇲"
  },
  "995": {
    name: "Georgia",
    flag: "🇬🇪"
  },
  "233": {
    name: "Ghana",
    flag: "🇬🇭"
  },
  "350": {
    name: "Gibraltar",
    flag: "🇬🇮"
  },
  "502": {
    name: "Guatemala",
    flag: "🇬🇹"
  },
  "224": {
    name: "Guinea",
    flag: "🇬🇳"
  },
  "245": {
    name: "Guinea-Bissau",
    flag: "🇬🇼"
  },
  "592": {
    name: "Guyana",
    flag: "🇬🇾"
  },
  "509": {
    name: "Haiti",
    flag: "🇭🇹"
  },
  "504": {
    name: "Honduras",
    flag: "🇭🇳"
  },
  "354": {
    name: "Iceland",
    flag: "🇮🇸"
  },
  "353": {
    name: "Ireland",
    flag: "🇮🇪"
  },
  "972": {
    name: "Israel",
    flag: "🇮🇱"
  },
  "962": {
    name: "Jordan",
    flag: "🇯🇴"
  },
  "254": {
    name: "Kenya",
    flag: "🇰🇪"
  },
  "686": {
    name: "Kiribati",
    flag: "🇰🇮"
  },
  "965": {
    name: "Kuwait",
    flag: "🇰🇼"
  },
  "996": {
    name: "Kyrgyzstan",
    flag: "🇰🇬"
  },
  "856": {
    name: "Laos",
    flag: "🇱🇦"
  },
  "371": {
    name: "Latvia",
    flag: "🇱🇻"
  },
  "961": {
    name: "Lebanon",
    flag: "🇱🇧"
  },
  "266": {
    name: "Lesotho",
    flag: "🇱🇸"
  },
  "231": {
    name: "Liberia",
    flag: "🇱🇷"
  },
  "218": {
    name: "Libya",
    flag: "🇱🇾"
  },
  "423": {
    name: "Liechtenstein",
    flag: "🇱🇮"
  },
  "370": {
    name: "Lithuania",
    flag: "🇱🇹"
  },
  "352": {
    name: "Luxembourg",
    flag: "🇱🇺"
  },
  "261": {
    name: "Madagascar",
    flag: "🇲🇬"
  },
  "265": {
    name: "Malawi",
    flag: "🇲🇼"
  },
  "960": {
    name: "Maldives",
    flag: "🇲🇻"
  },
  "223": {
    name: "Mali",
    flag: "🇲🇱"
  },
  "356": {
    name: "Malta",
    flag: "🇲🇹"
  },
  "692": {
    name: "Marshall Islands",
    flag: "🇲🇭"
  },
  "222": {
    name: "Mauritania",
    flag: "🇲🇷"
  },
  "230": {
    name: "Mauritius",
    flag: "🇲🇺"
  },
  "262": {
    name: "Mayotte / Réunion",
    flag: "🇾🇹"
  },
  "373": {
    name: "Moldova",
    flag: "🇲🇩"
  },
  "377": {
    name: "Monaco",
    flag: "🇲🇨"
  },
  "976": {
    name: "Mongolia",
    flag: "🇲🇳"
  },
  "382": {
    name: "Montenegro",
    flag: "🇲🇪"
  },
  "212": {
    name: "Morocco",
    flag: "🇲🇦"
  },
  "258": {
    name: "Mozambique",
    flag: "🇲🇿"
  },
  "264": {
    name: "Namibia",
    flag: "🇳🇦"
  },
  "674": {
    name: "Nauru",
    flag: "🇳🇷"
  },
  "977": {
    name: "Nepal",
    flag: "🇳🇵"
  },
  "687": {
    name: "New Caledonia",
    flag: "🇳🇨"
  },
  "505": {
    name: "Nicaragua",
    flag: "🇳🇮"
  },
  "227": {
    name: "Niger",
    flag: "🇳🇪"
  },
  "234": {
    name: "Nigeria",
    flag: "🇳🇬"
  },
  "683": {
    name: "Niue",
    flag: "🇳🇺"
  },
  "968": {
    name: "Oman",
    flag: "🇴🇲"
  },
  "680": {
    name: "Palau",
    flag: "🇵🇼"
  },
  "970": {
    name: "Palestine",
    flag: "🇵🇸"
  },
  "507": {
    name: "Panama",
    flag: "🇵🇦"
  },
  "675": {
    name: "Papua New Guinea",
    flag: "🇵🇬"
  },
  "595": {
    name: "Paraguay",
    flag: "🇵🇾"
  },
  "974": {
    name: "Qatar",
    flag: "🇶🇦"
  },
  "389": {
    name: "North Macedonia",
    flag: "🇲🇰"
  },
  "250": {
    name: "Rwanda",
    flag: "🇷🇼"
  },
  "685": {
    name: "Samoa",
    flag: "🇼🇸"
  },
  "239": {
    name: "São Tomé & Príncipe",
    flag: "🇸🇹"
  },
  "966": {
    name: "Saudi Arabia",
    flag: "🇸🇦"
  },
  "221": {
    name: "Senegal",
    flag: "🇸🇳"
  },
  "381": {
    name: "Serbia",
    flag: "🇷🇸"
  },
  "248": {
    name: "Seychelles",
    flag: "🇸🇨"
  },
  "232": {
    name: "Sierra Leone",
    flag: "🇸🇱"
  },
  "421": {
    name: "Slovakia",
    flag: "🇸🇰"
  },
  "386": {
    name: "Slovenia",
    flag: "🇸🇮"
  },
  "677": {
    name: "Solomon Islands",
    flag: "🇸🇧"
  },
  "252": {
    name: "Somalia",
    flag: "🇸🇴"
  },
  "211": {
    name: "South Sudan",
    flag: "🇸🇸"
  },
  "249": {
    name: "Sudan",
    flag: "🇸🇩"
  },
  "597": {
    name: "Suriname",
    flag: "🇸🇷"
  },
  "963": {
    name: "Syria",
    flag: "🇸🇾"
  },
  "992": {
    name: "Tajikistan",
    flag: "🇹🇯"
  },
  "255": {
    name: "Tanzania",
    flag: "🇹🇿"
  },
  "670": {
    name: "Timor-Leste",
    flag: "🇹🇱"
  },
  "228": {
    name: "Togo",
    flag: "🇹🇬"
  },
  "676": {
    name: "Tonga",
    flag: "🇹🇴"
  },
  "216": {
    name: "Tunisia",
    flag: "🇹🇳"
  },
  "993": {
    name: "Turkmenistan",
    flag: "🇹🇲"
  },
  "688": {
    name: "Tuvalu",
    flag: "🇹🇻"
  },
  "256": {
    name: "Uganda",
    flag: "🇺🇬"
  },
  "380": {
    name: "Ukraine",
    flag: "🇺🇦"
  },
  "971": {
    name: "United Arab Emirates",
    flag: "🇦🇪"
  },
  "598": {
    name: "Uruguay",
    flag: "🇺🇾"
  },
  "998": {
    name: "Uzbekistan",
    flag: "🇺🇿"
  },
  "678": {
    name: "Vanuatu",
    flag: "🇻🇺"
  },
  "967": {
    name: "Yemen",
    flag: "🇾🇪"
  },
  "260": {
    name: "Zambia",
    flag: "🇿🇲"
  },
  "263": {
    name: "Zimbabwe",
    flag: "🇿🇼"
  },
  "20": {
    name: "Egypt",
    flag: "🇪🇬"
  },
  "27": {
    name: "South Africa",
    flag: "🇿🇦"
  },
  "30": {
    name: "Greece",
    flag: "🇬🇷"
  },
  "31": {
    name: "Netherlands",
    flag: "🇳🇱"
  },
  "32": {
    name: "Belgium",
    flag: "🇧🇪"
  },
  "33": {
    name: "France",
    flag: "🇫🇷"
  },
  "34": {
    name: "Spain",
    flag: "🇪🇸"
  },
  "36": {
    name: "Hungary",
    flag: "🇭🇺"
  },
  "39": {
    name: "Italy",
    flag: "🇮🇹"
  },
  "40": {
    name: "Romania",
    flag: "🇷🇴"
  },
  "41": {
    name: "Switzerland",
    flag: "🇨🇭"
  },
  "43": {
    name: "Austria",
    flag: "🇦🇹"
  },
  "44": {
    name: "United Kingdom",
    flag: "🇬🇧"
  },
  "45": {
    name: "Denmark",
    flag: "🇩🇰"
  },
  "46": {
    name: "Sweden",
    flag: "🇸🇪"
  },
  "47": {
    name: "Norway",
    flag: "🇳🇴"
  },
  "48": {
    name: "Poland",
    flag: "🇵🇱"
  },
  "49": {
    name: "Germany",
    flag: "🇩🇪"
  },
  "51": {
    name: "Peru",
    flag: "🇵🇪"
  },
  "52": {
    name: "Mexico",
    flag: "🇲🇽"
  },
  "53": {
    name: "Cuba",
    flag: "🇨🇺"
  },
  "54": {
    name: "Argentina",
    flag: "🇦🇷"
  },
  "55": {
    name: "Brazil",
    flag: "🇧🇷"
  },
  "56": {
    name: "Chile",
    flag: "🇨🇱"
  },
  "57": {
    name: "Colombia",
    flag: "🇨🇴"
  },
  "58": {
    name: "Venezuela",
    flag: "🇻🇪"
  },
  "60": {
    name: "Malaysia",
    flag: "🇲🇾"
  },
  "61": {
    name: "Australia",
    flag: "🇦🇺"
  },
  "62": {
    name: "Indonesia",
    flag: "🇮🇩"
  },
  "63": {
    name: "Philippines",
    flag: "🇵🇭"
  },
  "64": {
    name: "New Zealand",
    flag: "🇳🇿"
  },
  "65": {
    name: "Singapore",
    flag: "🇸🇬"
  },
  "66": {
    name: "Thailand",
    flag: "🇹🇭"
  },
  "81": {
    name: "Japan",
    flag: "🇯🇵"
  },
  "82": {
    name: "South Korea",
    flag: "🇰🇷"
  },
  "84": {
    name: "Vietnam",
    flag: "🇻🇳"
  },
  "86": {
    name: "China",
    flag: "🇨🇳"
  },
  "90": {
    name: "Turkey",
    flag: "🇹🇷"
  },
  "91": {
    name: "India",
    flag: "🇮🇳"
  },
  "92": {
    name: "Pakistan",
    flag: "🇵🇰"
  },
  "93": {
    name: "Afghanistan",
    flag: "🇦🇫"
  },
  "94": {
    name: "Sri Lanka",
    flag: "🇱🇰"
  },
  "95": {
    name: "Myanmar",
    flag: "🇲🇲"
  },
  "98": {
    name: "Iran",
    flag: "🇮🇷"
  },
  "1": {
    name: "USA / Canada",
    flag: "🇺🇸"
  },
  "7": {
    name: "Russia / Kazakhstan",
    flag: "🇷🇺"
  }
};
function detectCountry(value6) {
  for (const value7 of [3, 2, 1]) {
    const value8 = value6.substring(0, value7);
    if (COUNTRY_CODES[value8]) {
      return {
        dialCode: value8,
        local: value6.substring(value7),
        country: COUNTRY_CODES[value8]
      };
    }
  }
  return null;
}
module.exports = {
  name: "wame",
  aliases: ["walink", "whatslink", "openwa"],
  category: "utility",
  description: "Generate a wa.me link from a quoted message or a number",
  usage: ".wame  (reply to a message)  OR  .wame <number>",
  async execute(value9, value10, value11, value12) {
    try {
      let value13 = null;
      let value14 = null;
      const value15 = value10.message?.extendedTextMessage?.contextInfo;
      const value16 = value15?.quotedMessage;
      if (value16 && value15?.participant) {
        value13 = await jidToNumber(value9, value15.participant);
        if (value13) {
          value14 = "quoted sender";
        }
      }
      if (!value13 && value16) {
        const value17 = value16.conversation || value16.extendedTextMessage?.text || value16.imageMessage?.caption || value16.videoMessage?.caption || value16.documentMessage?.caption || "";
        const value18 = value17.match(/\+?(\d[\d\s\-().]{6,}\d)/);
        if (value18) {
          value13 = value18[1].replace(/\D/g, "");
          value14 = "text in quoted message";
        }
      }
      if (!value13 && value11.length > 0) {
        value13 = value11.join("").replace(/\D/g, "");
        value14 = "provided number";
      }
      if (!value13 || value13.length < 7) {
        return value12.reply("❌ No phone number found.\n\n*Usage:*\n• Reply to any message → `.wame`\n• Direct number → `.wame 254712345678`");
      }
      const value19 = detectCountry(value13);
      const value20 = "https://wa.me/" + value13;
      let value21 = "🔗 *WhatsApp Link*\n\n";
      if (value19) {
        value21 += value19.country.flag + " *Country:* " + value19.country.name + "\n";
        value21 += "📞 *Dial Code:* +" + value19.dialCode + "\n";
        value21 += "🔢 *Local Number:* " + value19.local + "\n";
        value21 += "📱 *Full Number:* +" + value13 + "\n";
      } else {
        value21 += "📱 *Number:* +" + value13 + "\n";
      }
      value21 += "🌐 *Link:* " + value20 + "\n\n";
      value21 += "_Source: " + value14 + "_";
      await value9.sendMessage(value12.from, {
        text: value21
      }, {
        quoted: value10
      });
    } catch (error22) {
      console.error("[wame] error:", error22);
      await value12.reply("❌ Error: " + error22.message);
    }
  }
};
