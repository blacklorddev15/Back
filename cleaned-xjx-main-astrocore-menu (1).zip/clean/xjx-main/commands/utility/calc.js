const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;
function factorial(value1) {
  value1 = Math.floor(value1);
  if (value1 < 0) {
    throw new Error("Factorial of negative number");
  }
  if (value1 > 170) {
    throw new Error("Number too large for factorial");
  }
  let value2 = 1;
  for (let value3 = 2; value3 <= value1; value3++) {
    value2 *= value3;
  }
  return value2;
}
function combinations(value4, value5) {
  if (value5 < 0 || value5 > value4) {
    return 0;
  }
  return factorial(value4) / (factorial(value5) * factorial(value4 - value5));
}
function permutations(value6, value7) {
  if (value7 < 0 || value7 > value6) {
    return 0;
  }
  return factorial(value6) / factorial(value6 - value7);
}
function gcd(value8, value9) {
  value8 = Math.abs(Math.round(value8));
  value9 = Math.abs(Math.round(value9));
  while (value9) {
    [value8, value9] = [value9, value8 % value9];
  }
  return value8;
}
function lcm(value10, value11) {
  return Math.abs(value10 * value11) / gcd(value10, value11);
}
function fmt(value12, value13 = 10) {
  if (!isFinite(value12)) {
    return String(value12);
  }
  const value14 = parseFloat(value12.toFixed(value13));
  return String(value14);
}
const MATH_FNS = {
  PI: Math.PI,
  E: Math.E,
  PHI: 1.618033988749895,
  TAU: Math.PI * 2,
  sin: value15 => Math.sin(value15 * DEG),
  cos: value16 => Math.cos(value16 * DEG),
  tan: value17 => Math.tan(value17 * DEG),
  cot: value18 => 1 / Math.tan(value18 * DEG),
  sec: value19 => 1 / Math.cos(value19 * DEG),
  csc: value20 => 1 / Math.sin(value20 * DEG),
  asin: value21 => Math.asin(value21) * RAD,
  acos: value22 => Math.acos(value22) * RAD,
  atan: value23 => Math.atan(value23) * RAD,
  atan2: (value24, value25) => Math.atan2(value24, value25) * RAD,
  sinr: Math.sin,
  cosr: Math.cos,
  tanr: Math.tan,
  asinr: Math.asin,
  acosr: Math.acos,
  atanr: Math.atan,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
  asinh: Math.asinh,
  acosh: Math.acosh,
  atanh: Math.atanh,
  sqrt: Math.sqrt,
  cbrt: Math.cbrt,
  pow: Math.pow,
  exp: Math.exp,
  log: Math.log10,
  log10: Math.log10,
  log2: Math.log2,
  ln: Math.log,
  logb: (value26, value27) => Math.log(value26) / Math.log(value27),
  abs: Math.abs,
  floor: Math.floor,
  ceil: Math.ceil,
  round: Math.round,
  sign: Math.sign,
  trunc: Math.trunc,
  max: (...value28) => Math.max(...value28),
  min: (...value29) => Math.min(...value29),
  hypot: Math.hypot,
  factorial: factorial,
  C: combinations,
  nCr: combinations,
  P: permutations,
  nPr: permutations,
  gcd: gcd,
  lcm: lcm,
  mean: (...value30) => value30.flat().reduce((value31, value32) => value31 + value32, 0) / value30.flat().length,
  sum: (...value33) => value33.flat().reduce((value34, value35) => value34 + value35, 0),
  product: (...value36) => value36.flat().reduce((value37, value38) => value37 * value38, 1),
  mod: (value39, value40) => (value39 % value40 + value40) % value40,
  deg: value41 => value41 * RAD,
  rad: value42 => value42 * DEG
};
function evalExpr(value43) {
  let value44 = value43.replace(/[×x]/g, "*").replace(/[÷]/g, "/").replace(/[–—]/g, "-").replace(/²/g, "**2").replace(/³/g, "**3").replace(/⁴/g, "**4").replace(/\^/g, "**").replace(/√\(/g, "sqrt(").replace(/√(\d+)/g, "sqrt($1)").replace(/∛\(/g, "cbrt(").replace(/∛(\d+)/g, "cbrt($1)").replace(/π/g, "PI").replace(/\bpi\b/gi, "PI").replace(/\bphi\b/gi, "PHI").replace(/\binf(inity)?\b/gi, "Infinity").replace(/(\w+)!/g, "factorial($1)").replace(/(\d)(PI|E\b|PHI|TAU)/g, "$1*$2").replace(/(\d)\s*\(/g, "$1*(").replace(/\)\s*\(/g, ")*(").replace(/(\d+)\s*C\s*(\d+)/g, "C($1,$2)").replace(/(\d+)\s*P\s*(\d+)/g, "P($1,$2)");
  const value45 = new Function(...Object.keys(MATH_FNS), "\"use strict\"; return (" + value44 + ");");
  return value45(...Object.values(MATH_FNS));
}
function route(value46) {
  const value47 = value46.toLowerCase().trim();
  if (/\d+(\.\d+)?%\s+of\s+\d/.test(value47)) {
    return calcPercentageOf(value47);
  }
  if (/\d\s*[+\-]\s*\d+(\.\d+)?%/.test(value47)) {
    return calcPercentageDelta(value47);
  }
  const value48 = value47.match(/^(mean|median|mode|std|stddev|variance|var|range|sum|product)\s*\(?([\d\s,.\-]+)\)?/);
  if (value48) {
    return calcStats(value48[1], value48[2]);
  }
  const value49 = value47.match(/^(gcd|lcm)\s*[\s(,]\s*([\d\s,]+)/);
  if (value49) {
    return calcGcdLcm(value49[1], value49[2]);
  }
  if (/^(prime|isprime)\s+(\d+)/.test(value47)) {
    const value50 = parseInt(value47.match(/\d+/)[0]);
    return calcPrime(value50);
  }
  if (/^(factor|factors|factorise|factorize)\s+(\d+)/.test(value47)) {
    const value51 = parseInt(value47.match(/\d+/)[0]);
    return calcFactor(value51);
  }
  const value52 = value46.split(/[,\n;]/);
  if (value52.length >= 2 && value52.every(value53 => value53.includes("="))) {
    return solveSystem(value52[0].trim(), value52[1].trim(), value46);
  }
  if (value46.includes("=") && /[a-zA-Z]/.test(value46)) {
    return solveEquation(value46);
  }
  return calcExpression(value46);
}
function calcExpression(value54) {
  let value55;
  try {
    value55 = evalExpr(value54);
  } catch (error56) {
    throw new Error("Cannot evaluate \"" + value54 + "\": " + error56.message);
  }
  if (typeof value55 === "boolean") {
    value55 = value55 ? 1 : 0;
  }
  if (!isFinite(value55) && value55 !== Infinity && value55 !== -Infinity) {
    throw new Error("Result is undefined (division by zero or invalid operation)");
  }
  return "🧮 *Calculator Result*\n\n" + ("📝 *Expression:* `" + value54 + "`\n") + ("✅ *Result:* `" + fmt(value55) + "`");
}
function calcStats(value57, value58) {
  const value59 = value58.split(/[\s,]+/).map(Number).filter(value60 => !isNaN(value60));
  if (!value59.length) {
    throw new Error("No valid numbers provided");
  }
  const value61 = value59.length;
  const value62 = value59.reduce((value63, value64) => value63 + value64, 0) / value61;
  const value65 = [...value59].sort((value66, value67) => value66 - value67);
  const value68 = value61 % 2 ? value65[Math.floor(value61 / 2)] : (value65[value61 / 2 - 1] + value65[value61 / 2]) / 2;
  const value69 = value59.reduce((value70, value71) => value70 + (value71 - value62) ** 2, 0) / value61;
  const value72 = Math.sqrt(value69);
  const value73 = value59.reduce((value74, value75) => value74 + value75, 0);
  const value76 = value65[value61 - 1] - value65[0];
  const value77 = {};
  value59.forEach(value78 => value77[value78] = (value77[value78] || 0) + 1);
  const value79 = Math.max(...Object.values(value77));
  const value80 = Object.keys(value77).filter(value81 => value77[value81] === value79).map(Number);
  const value82 = {
    mean: fmt(value62),
    median: fmt(value68),
    mode: value80.join(", "),
    variance: fmt(value69),
    std: fmt(value72),
    sum: fmt(value73),
    range: fmt(value76),
    min: fmt(value65[0]),
    max: fmt(value65[value61 - 1]),
    count: value61
  };
  const value83 = value84 => {
    switch (value84) {
      case "mean":
        return "✅ *Mean:* `" + value82.mean + "`";
      case "median":
        return "✅ *Median:* `" + value82.median + "`";
      case "mode":
        return "✅ *Mode:* `" + value82.mode + "`";
      case "std":
      case "stddev":
        return "✅ *Std Dev:* `" + value82.std + "`";
      case "variance":
      case "var":
        return "✅ *Variance:* `" + value82.variance + "`";
      case "range":
        return "✅ *Range:* `" + value82.range + "`";
      case "sum":
        return "✅ *Sum:* `" + value82.sum + "`";
      case "product":
        return "✅ *Product:* `" + fmt(value59.reduce((value85, value86) => value85 * value86, 1)) + "`";
    }
    return null;
  };
  const value87 = value83(value57);
  const value88 = "📊 *Data:* `" + value59.join(", ") + "` (n = " + value61 + ")";
  if (value87) {
    return "📊 *Statistics*\n\n" + value88 + "\n" + value87;
  }
  return "📊 *Full Statistics*\n\n" + (value88 + "\n") + "━━━━━━━━━━━━━━━━━━━━━\n" + ("📌 Count    : " + value61 + "\n") + ("📌 Sum      : " + value82.sum + "\n") + ("📌 Mean     : " + value82.mean + "\n") + ("📌 Median   : " + value82.median + "\n") + ("📌 Mode     : " + value82.mode + "\n") + ("📌 Std Dev  : " + value82.std + "\n") + ("📌 Variance : " + value82.variance + "\n") + ("📌 Range    : " + value82.range + "\n") + ("📌 Min      : " + value82.min + "\n") + ("📌 Max      : " + value82.max);
}
function calcGcdLcm(value89, value90) {
  const value91 = value90.split(/[\s,]+/).map(Number).filter(value92 => !isNaN(value92) && value92 > 0);
  if (value91.length < 2) {
    throw new Error("Provide at least 2 numbers");
  }
  if (value89 === "gcd") {
    const value93 = value91.reduce((value94, value95) => gcd(value94, value95));
    return "🔢 *GCD*\n\n📝 Numbers: `" + value91.join(", ") + "`\n✅ GCD = `" + value93 + "`";
  }
  const value96 = value91.reduce((value97, value98) => lcm(value97, value98));
  return "🔢 *LCM*\n\n📝 Numbers: `" + value91.join(", ") + "`\n✅ LCM = `" + value96 + "`";
}
function primeFactors(value99) {
  const value100 = [];
  let value101 = 2;
  while (value101 * value101 <= value99) {
    while (value99 % value101 === 0) {
      value100.push(value101);
      value99 = Math.floor(value99 / value101);
    }
    value101++;
  }
  if (value99 > 1) {
    value100.push(value99);
  }
  return value100;
}
function isPrime(value102) {
  if (value102 < 2) {
    return false;
  }
  if (value102 === 2) {
    return true;
  }
  if (value102 % 2 === 0) {
    return false;
  }
  for (let value103 = 3; value103 <= Math.sqrt(value102); value103 += 2) {
    if (value102 % value103 === 0) {
      return false;
    }
  }
  return true;
}
function calcPrime(value104) {
  value104 = Math.floor(Math.abs(value104));
  const value105 = isPrime(value104);
  return "🔢 *Prime Check*\n\n" + ("📝 Number: `" + value104 + "`\n") + ("✅ *" + value104 + " is " + (value105 ? "" : "NOT ") + "a prime number*") + (value105 ? "" : "\n💡 Smallest factor: `" + primeFactors(value104)[0] + "`");
}
function calcFactor(value106) {
  value106 = Math.floor(Math.abs(value106));
  if (value106 < 2) {
    throw new Error("Enter a number ≥ 2");
  }
  const value107 = primeFactors(value106);
  const value108 = {};
  value107.forEach(value109 => value108[value109] = (value108[value109] || 0) + 1);
  const value110 = Object.entries(value108).map(([value111, value112]) => value112 > 1 ? value111 + "^" + value112 : value111).join(" × ");
  const value113 = [];
  for (let value114 = 1; value114 <= value106; value114++) {
    if (value106 % value114 === 0) {
      value113.push(value114);
    }
  }
  return "🔢 *Prime Factorization*\n\n" + ("📝 Number: `" + value106 + "`\n") + ("✅ *" + value106 + " = " + value110 + "*\n") + ("📌 All factors: `" + value113.join(", ") + "`\n") + ("📌 Factor count: " + value113.length);
}
function calcPercentageOf(value115) {
  const value116 = value115.match(/([\d.]+)%\s+of\s+([\d.]+)/i);
  if (!value116) {
    throw new Error("Format: 15% of 200");
  }
  const value117 = parseFloat(value116[1]);
  const value118 = parseFloat(value116[2]);
  const value119 = value117 / 100 * value118;
  return "💯 *Percentage*\n\n" + ("`" + value117 + "% of " + value118 + "`\n") + ("= `" + value117 + "/100 × " + value118 + "`\n") + ("✅ = `" + fmt(value119) + "`");
}
function calcPercentageDelta(value120) {
  const value121 = value120.match(/([\d.]+)\s*([+\-])\s*([\d.]+)%/);
  if (!value121) {
    throw new Error("Format: 200 + 15%  or  200 - 15%");
  }
  const value122 = parseFloat(value121[1]);
  const value123 = value121[2];
  const value124 = parseFloat(value121[3]);
  const value125 = value124 / 100 * value122;
  const value126 = value123 === "+" ? value122 + value125 : value122 - value125;
  return "💯 *Percentage " + (value123 === "+" ? "Increase" : "Decrease") + "*\n\n" + ("Base: `" + value122 + "`\n") + ((value123 === "+" ? "Increase" : "Decrease") + ": `" + value124 + "% = " + fmt(value125) + "`\n") + ("✅ Result: `" + fmt(value126) + "`");
}
function solveEquation(value127) {
  let value128 = value127.replace(/²/g, "^2").replace(/³/g, "^3").replace(/\s+/g, "").toLowerCase();
  const value129 = /x\^3|x³/.test(value128);
  const value130 = /x\^2|x²/.test(value128);
  if (value128.includes("=")) {
    const [value131, value132] = value128.split("=");
    const value133 = value132 === "" ? NaN : (() => {
      try {
        return evalExpr(value132.replace(/x/g, "0"));
      } catch {
        return NaN;
      }
    })();
    if (isNaN(value133)) {
      throw new Error("Cannot parse right-hand side");
    }
    value128 = value133 === 0 ? value131 : "(" + value131 + ")-(" + value133 + ")";
  }
  if (value129) {
    return solveCubic(value128, value127);
  }
  if (value130) {
    return solveQuadratic(value128, value127);
  }
  return solveLinear(value128, value127);
}
function extractQuadCoeffs(value134) {
  let value135 = value134.replace(/\^2/g, "²").replace(/([0-9])x/g, "$1*x");
  let value136 = 0;
  let value137 = 0;
  let value138 = 0;
  let value139 = false;
  let value140;
  const value141 = /([+-]?\d*\.?\d*)\*?x²/g;
  while ((value140 = value141.exec(value135)) !== null) {
    const value142 = value140[1];
    value136 += value142 === "" || value142 === "+" ? 1 : value142 === "-" ? -1 : parseFloat(value142);
    value139 = true;
  }
  const value143 = /([+-]?\d*\.?\d*)\*?x(?!²)/g;
  while ((value140 = value143.exec(value135)) !== null) {
    const value144 = value140[1];
    value137 += value144 === "" || value144 === "+" ? 1 : value144 === "-" ? -1 : parseFloat(value144);
  }
  let value145 = value135.replace(/[+-]?\d*\.?\d*\*?x²/g, "").replace(/[+-]?\d*\.?\d*\*?x(?!²)/g, "").replace(/[()]/g, "");
  try {
    value138 = value145 ? parseFloat(Function("\"use strict\";return(" + value145 + ")")()) : 0;
  } catch {
    value138 = 0;
  }
  return {
    a: value136,
    b: value137,
    c: value138,
    isQuad: value139
  };
}
function solveLinear(value146, value147) {
  let value148 = 0;
  let value149 = 0;
  let value150;
  const value151 = value146.replace(/([0-9])x/g, "$1*x");
  const value152 = /([+-]?\d*\.?\d*)\*?x/g;
  while ((value150 = value152.exec(value151)) !== null) {
    const value153 = value150[1];
    value148 += value153 === "" || value153 === "+" ? 1 : value153 === "-" ? -1 : parseFloat(value153);
  }
  let value154 = value151.replace(/[+-]?\d*\.?\d*\*?x/g, "").replace(/[()]/g, "");
  try {
    value149 = value154 ? parseFloat(Function("\"use strict\";return(" + value154 + ")")()) : 0;
  } catch {
    value149 = 0;
  }
  if (value148 === 0) {
    throw new Error("No variable found — enter as: 2x + 5 = 0");
  }
  const value155 = -value149 / value148;
  return "🧮 *Linear Equation*\n\n📝 `" + value147 + "`\n━━━━━━━━━━━━━━━━━━━━━\n*Step 1 — Standard form:* `bx + c = 0`\n" + ("b = " + fmt(value148) + ",  c = " + fmt(value149) + "\n\n") + "*Step 2 — Isolate x*\n" + ("`" + fmt(value148) + "x = " + fmt(-value149) + "`\n") + ("`x = " + fmt(-value149) + " ÷ " + fmt(value148) + "`\n\n") + ("✅ *x = " + fmt(value155) + "*");
}
function solveQuadratic(value156, value157) {
  const {
    a: value158,
    b: value159,
    c: value160
  } = extractQuadCoeffs(value156);
  const value161 = value159 * value159 - value158 * 4 * value160;
  const value162 = -value159 / (value158 * 2);
  const value163 = value160 - value159 * value159 / (value158 * 4);
  let value164 = "🧮 *Quadratic Equation*\n\n📝 `" + value157 + "`\n━━━━━━━━━━━━━━━━━━━━━\n*Step 1 — Standard form:* ax² + bx + c = 0\n" + ("a = " + fmt(value158) + ",  b = " + fmt(value159) + ",  c = " + fmt(value160) + "\n\n") + "*Step 2 — Discriminant (Δ = b² − 4ac)*\n" + ("Δ = (" + fmt(value159) + ")² − 4(" + fmt(value158) + ")(" + fmt(value160) + ")\n") + ("Δ = " + fmt(value159 * value159) + " − " + fmt(value158 * 4 * value160) + " = *" + fmt(value161) + "*\n\n") + "*Step 3 — Roots: x = (−b ± √Δ) / 2a*\n\n";
  if (value161 > 0) {
    const value165 = Math.sqrt(value161);
    const value166 = (-value159 + value165) / (value158 * 2);
    const value167 = (-value159 - value165) / (value158 * 2);
    value164 += "Δ > 0 → *Two distinct real roots*\n";
    value164 += "x₁ = (" + fmt(-value159) + " + " + fmt(value165) + ") / " + fmt(value158 * 2) + " = *" + fmt(value166) + "*\n";
    value164 += "x₂ = (" + fmt(-value159) + " − " + fmt(value165) + ") / " + fmt(value158 * 2) + " = *" + fmt(value167) + "*\n\n";
    value164 += "*Step 4 — Factored form*\n";
    value164 += fmt(value158) + "(x − " + fmt(value166) + ")(x − " + fmt(value167) + ") = 0\n\n";
  } else if (value161 === 0) {
    const value168 = -value159 / (value158 * 2);
    value164 += "Δ = 0 → *One repeated real root*\n";
    value164 += "x = −b / 2a = " + fmt(-value159) + " / " + fmt(value158 * 2) + " = *" + fmt(value168) + "*\n\n";
    value164 += "*Step 4 — Factored form*\n";
    value164 += fmt(value158) + "(x − " + fmt(value168) + ")² = 0\n\n";
  } else {
    const value169 = -value159 / (value158 * 2);
    const value170 = Math.sqrt(-value161) / (value158 * 2);
    value164 += "Δ < 0 → *Two complex roots (no real solution)*\n";
    value164 += "x₁ = " + fmt(value169) + " + " + fmt(value170) + "i\n";
    value164 += "x₂ = " + fmt(value169) + " − " + fmt(value170) + "i\n\n";
  }
  value164 += "*Step 5 — Vertex of parabola*\n";
  value164 += "Vertex (h, k) = (" + fmt(value162) + ", " + fmt(value163) + ")\n";
  value164 += "Parabola opens *" + (value158 > 0 ? "upward ↑" : "downward ↓") + "*";
  return value164;
}
function solveCubic(value171, value172) {
  let value173 = 0;
  let value174 = 0;
  let value175 = 0;
  let value176 = 0;
  let value177;
  const value178 = value171.replace(/\^3/g, "³").replace(/\^2/g, "²").replace(/([0-9])x/g, "$1*x");
  const value179 = /([+-]?\d*\.?\d*)\*?x³/g;
  while ((value177 = value179.exec(value178)) !== null) {
    const value180 = value177[1];
    value173 += value180 === "" || value180 === "+" ? 1 : value180 === "-" ? -1 : parseFloat(value180);
  }
  const value181 = /([+-]?\d*\.?\d*)\*?x²/g;
  while ((value177 = value181.exec(value178)) !== null) {
    const value182 = value177[1];
    value174 += value182 === "" || value182 === "+" ? 1 : value182 === "-" ? -1 : parseFloat(value182);
  }
  const value183 = /([+-]?\d*\.?\d*)\*?x(?![²³])/g;
  while ((value177 = value183.exec(value178)) !== null) {
    const value184 = value177[1];
    value175 += value184 === "" || value184 === "+" ? 1 : value184 === "-" ? -1 : parseFloat(value184);
  }
  let value185 = value178.replace(/[+-]?\d*\.?\d*\*?x[³²]?/g, "").replace(/[()]/g, "");
  try {
    value176 = value185 ? parseFloat(Function("\"use strict\";return(" + value185 + ")")()) : 0;
  } catch {
    value176 = 0;
  }
  const value186 = value187 => value173 * value187 ** 3 + value174 * value187 ** 2 + value175 * value187 + value176;
  const value188 = value189 => value173 * 3 * value189 ** 2 + value174 * 2 * value189 + value175;
  const value190 = new Map();
  const value191 = [-1000, -500, -100, -50, -20, -10, -5, -2, -1, -0.5, 0, 0.5, 1, 2, 5, 10, 20, 50, 100, 500, 1000];
  for (const value192 of value191) {
    let value193 = value192;
    for (let value194 = 0; value194 < 2000; value194++) {
      const value195 = value186(value193);
      const value196 = value188(value193);
      if (Math.abs(value196) < 1e-15) {
        break;
      }
      const value197 = value193 - value195 / value196;
      if (!isFinite(value197)) {
        break;
      }
      if (Math.abs(value197 - value193) < 1e-12) {
        value193 = value197;
        break;
      }
      value193 = value197;
    }
    if (isFinite(value193) && Math.abs(value186(value193)) < 0.000001) {
      const value198 = Math.round(value193 * 10000000);
      if (!value190.has(value198)) {
        value190.set(value198, value193);
      }
    }
  }
  const value199 = [...value190.values()].sort((value200, value201) => value200 - value201);
  let value202 = "🧮 *Cubic Equation*\n\n📝 `" + value172 + "`\n━━━━━━━━━━━━━━━━━━━━━\n*Coefficients*\n" + ("a = " + fmt(value173) + ",  b = " + fmt(value174) + ",  c = " + fmt(value175) + ",  d = " + fmt(value176) + "\n\n");
  if (value199.length === 0) {
    value202 += "❌ No real roots found";
  } else {
    value202 += "*Real Root" + (value199.length > 1 ? "s" : "") + "*\n";
    value199.forEach((value203, value204) => {
      value202 += "x" + (value199.length > 1 ? ["₁", "₂", "₃"][value204] : "") + " = *" + fmt(value203) + "*\n";
    });
    value202 += "\n*Verification*\n";
    value199.forEach((value205, value206) => {
      value202 += "f(" + fmt(value205) + ") ≈ " + fmt(value186(value205)) + "\n";
    });
  }
  return value202;
}
function solveSystem(value207, value208, value209) {
  function handler210(value211) {
    value211 = value211.toLowerCase().replace(/\s+/g, "").replace(/²/g, "^2");
    const [value212, value213] = value211.split("=");
    const value214 = parseFloat(value213) || 0;
    let value215 = 0;
    let value216 = 0;
    let value217;
    const value218 = value212.replace(/([0-9])x/g, "$1*x").replace(/([0-9])y/g, "$1*y");
    const value219 = /([+-]?\d*\.?\d*)\*?x/g;
    while ((value217 = value219.exec(value218)) !== null) {
      const value220 = value217[1];
      value215 += value220 === "" || value220 === "+" ? 1 : value220 === "-" ? -1 : parseFloat(value220);
    }
    const value221 = /([+-]?\d*\.?\d*)\*?y/g;
    while ((value217 = value221.exec(value218)) !== null) {
      const value222 = value217[1];
      value216 += value222 === "" || value222 === "+" ? 1 : value222 === "-" ? -1 : parseFloat(value222);
    }
    return {
      a: value215,
      b: value216,
      c: value214
    };
  }
  const value223 = handler210(value207);
  const value224 = handler210(value208);
  const value225 = value223.a * value224.b - value224.a * value223.b;
  if (Math.abs(value225) < 1e-12) {
    return "🧮 *System of Equations*\n\n" + ("📝 `" + value207 + "`\n📝 `" + value208 + "`\n") + "━━━━━━━━━━━━━━━━━━━━━\n❌ No unique solution (equations are parallel or identical)";
  }
  const value226 = (value223.c * value224.b - value224.c * value223.b) / value225;
  const value227 = (value223.a * value224.c - value224.a * value223.c) / value225;
  return "🧮 *System of Linear Equations*\n\n" + ("📝 Eq 1: `" + value207 + "`\n") + ("📝 Eq 2: `" + value208 + "`\n") + "━━━━━━━━━━━━━━━━━━━━━\n*Cramer's Rule*\n" + ("D  = (" + fmt(value223.a) + ")(" + fmt(value224.b) + ") − (" + fmt(value224.a) + ")(" + fmt(value223.b) + ") = *" + fmt(value225) + "*\n") + ("Dx = (" + fmt(value223.c) + ")(" + fmt(value224.b) + ") − (" + fmt(value224.c) + ")(" + fmt(value223.b) + ") = *" + fmt(value223.c * value224.b - value224.c * value223.b) + "*\n") + ("Dy = (" + fmt(value223.a) + ")(" + fmt(value224.c) + ") − (" + fmt(value224.a) + ")(" + fmt(value223.c) + ") = *" + fmt(value223.a * value224.c - value224.a * value223.c) + "*\n\n") + ("✅ *x = " + fmt(value226) + ",  y = " + fmt(value227) + "*");
}
const HELP = "🧮 *Advanced Calculator*\n\n*Arithmetic & Science*\n`.calc 5 + 3 * (2^4)`\n`.calc sqrt(144) + cbrt(27)`\n`.calc 5! + C(8,3)`\n\n*Trigonometry* _(degrees by default)_\n`.calc sin(30)`  `.calc cos(60)`\n`.calc tan(45)`  `.calc asin(0.5)`\n_Radians: use_ `sinr(PI/6)`\n\n*Logarithms*\n`.calc log(1000)`  `ln(E)`  `log2(64)`\n\n*Statistics*\n`.calc mean 10,20,30,40,50`\n`.calc std 4,8,15,16,23,42`\n`.calc median 3,1,4,1,5`\n\n*Equations (with steps)*\n`.calc 3x + 9 = 0`\n`.calc x^2 + 5x + 6 = 0`\n`.calc x^3 - 6x^2 + 11x - 6 = 0`\n\n*System of equations*\n`.calc 2x+y=7, x-y=1`\n\n*Number theory*\n`.calc gcd 12,18`  `.calc lcm 4,6`\n`.calc prime 17`  `.calc factor 360`\n\n*Percentage*\n`.calc 15% of 200`\n`.calc 200 + 15%`";
module.exports = {
  name: "calc",
  aliases: ["calculate", "math", "solve"],
  category: "utility",
  description: "Full mathematics calculator — all types of maths with steps",
  usage: ".calc <expression | equation>",
  async execute(value228, value229, value230, value231) {
    try {
      if (!value230.length) {
        return value231.reply(HELP);
      }
      const value232 = value230.join(" ").trim();
      const value233 = route(value232);
      await value231.reply(value233);
    } catch (error234) {
      console.error("[calc] error:", error234);
      await value231.reply("❌ " + error234.message);
    }
  }
};
