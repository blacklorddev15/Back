const react = (value1, value2, value3) => value1.sendMessage(value2.key.remoteJid, {
  react: {
    text: value3,
    key: value2.key
  }
});
const send = (value4, value5, value6) => value4.sendMessage(value5.key.remoteJid, {
  text: value6
}, {
  quoted: value5
});
function getQuotedKey(value7, value8, value9) {
  const value10 = value8.message?.extendedTextMessage?.contextInfo || value8.message?.imageMessage?.contextInfo || value8.message?.videoMessage?.contextInfo || value8.message?.audioMessage?.contextInfo || value8.message?.documentMessage?.contextInfo || value8.message?.stickerMessage?.contextInfo || null;
  if (!value10?.stanzaId) {
    return null;
  }
  const value11 = value7.user?.id?.split(":")[0] || value7.user?.id?.split("@")[0];
  const value12 = value10.participant || "";
  const value13 = value12 ? value12.split("@")[0] === value11 : value8.key.fromMe;
  return {
    id: value10.stanzaId,
    remoteJid: value9,
    fromMe: value13,
    participant: value10.participant || undefined
  };
}
module.exports = [{
  name: "pin",
  aliases: ["pinchat"],
  category: "utility",
  description: "Pin the current chat",
  usage: ".pin",
  async execute(value14, value15, value16, value17) {
    const value18 = value17.from;
    await react(value14, value15, "📌");
    try {
      await value14.chatModify({
        pin: true
      }, value18);
      await send(value14, value15, "📌 *Chat Pinned*\n\nThis chat has been pinned successfully.\n\n_Use_ *.unpin* _to unpin this chat._");
      await react(value14, value15, "✅");
    } catch (error19) {
      console.error("[pin]", error19.message);
      await react(value14, value15, "❌");
      const value20 = error19.message?.includes("App state key not present") ? "❌ *Cannot pin chat* — your session does not have app state keys.\n\nChat pinning requires a full WhatsApp session (not just a SESSION_ID string). This is a Baileys limitation." : "❌ Failed to pin chat: " + error19.message;
      value17.reply(value20);
    }
  }
}, {
  name: "unpin",
  aliases: ["unpinchat"],
  category: "utility",
  description: "Unpin the current chat",
  usage: ".unpin",
  async execute(value21, value22, value23, value24) {
    const value25 = value24.from;
    await react(value21, value22, "📌");
    try {
      await value21.chatModify({
        pin: false
      }, value25);
      await send(value21, value22, "📌 *Chat Unpinned*\n\nThis chat has been unpinned successfully.\n\n_Use_ *.pin* _to pin this chat again._");
      await react(value21, value22, "✅");
    } catch (error26) {
      console.error("[unpin]", error26.message);
      await react(value21, value22, "❌");
      const value27 = error26.message?.includes("App state key not present") ? "❌ *Cannot unpin chat* — your session does not have app state keys.\n\nChat unpinning requires a full WhatsApp session (not just a SESSION_ID string). This is a Baileys limitation." : "❌ Failed to unpin chat: " + error26.message;
      value24.reply(value27);
    }
  }
}, {
  name: "pinmsg",
  aliases: ["pinmessage"],
  category: "utility",
  description: "Pin a quoted message in a chat or group",
  usage: ".pinmsg [24h|7d|30d] (reply to a message)",
  async execute(value28, value29, value30, value31) {
    const value32 = value31.from;
    const value33 = value30[0];
    const value34 = {
      "24h": 86400,
      "7d": 604800,
      "30d": 2592000
    };
    const value35 = value34[value33] || 604800;
    const value36 = getQuotedKey(value28, value29, value32);
    if (!value36) {
      return value31.reply("❌ *Please reply to a message to pin it.*\n\n*Usage:* .pinmsg\n*Duration options:*\n  .pinmsg 24h  → Pin for 24 hours\n  .pinmsg 7d   → Pin for 7 days _(default)_\n  .pinmsg 30d  → Pin for 30 days");
    }
    await react(value28, value29, "📌");
    try {
      await value28.sendMessage(value32, {
        pin: value36,
        type: 1,
        time: value35
      });
      const value37 = value33 === "24h" ? "24 hours" : value33 === "30d" ? "30 days" : "7 days";
      await send(value28, value29, "📌 *Message Pinned*\n\n" + ("Duration: *" + value37 + "*\n\n") + "_Use_ *.unpinmsg* _(reply to the same message) to unpin._");
      await react(value28, value29, "✅");
    } catch (error38) {
      console.error("[pinmsg]", error38.message);
      await react(value28, value29, "❌");
      value31.reply("❌ Failed to pin message. Make sure the bot is an admin in groups.");
    }
  }
}, {
  name: "unpinmsg",
  aliases: ["unpinmessage"],
  category: "utility",
  description: "Unpin a quoted message in a chat or group",
  usage: ".unpinmsg (reply to the pinned message)",
  async execute(value39, value40, value41, value42) {
    const value43 = value42.from;
    const value44 = getQuotedKey(value39, value40, value43);
    if (!value44) {
      return value42.reply("❌ *Please reply to the pinned message to unpin it.*\n\n*Usage:* .unpinmsg _(reply to the pinned message)_");
    }
    await react(value39, value40, "📌");
    try {
      await value39.sendMessage(value43, {
        pin: value44,
        type: 2,
        time: 0
      });
      await send(value39, value40, "📌 *Message Unpinned*\n\nThe message has been unpinned successfully.\n\n_Use_ *.pinmsg* _(reply to a message) to pin again._");
      await react(value39, value40, "✅");
    } catch (error45) {
      console.error("[unpinmsg]", error45.message);
      await react(value39, value40, "❌");
      value42.reply("❌ Failed to unpin message. Make sure the bot is an admin in groups.");
    }
  }
}, {
  name: "starmsg",
  aliases: ["star", "starmesg", "starmessage"],
  category: "utility",
  description: "Star or unstar a quoted message",
  usage: ".starmsg (reply to a message) | .starmsg unstar (reply to unstar)",
  async execute(value46, value47, value48, value49) {
    const value50 = value49.from;
    const value51 = value48[0]?.toLowerCase() === "unstar";
    const value52 = getQuotedKey(value46, value47, value50);
    if (!value52) {
      return value49.reply("❌ *Please reply to a message to star it.*\n\n*Usage:*\n  .starmsg            → ⭐ Star the quoted message\n  .starmsg unstar     → ✖ Unstar the quoted message");
    }
    await react(value46, value47, value51 ? "✖️" : "⭐");
    try {
      await value46.star(value50, [{
        id: value52.id,
        fromMe: value52.fromMe
      }], !value51);
      if (value51) {
        await send(value46, value47, "✖️ *Message Unstarred*\n\nThe message has been removed from your starred messages.\n\n_Use_ *.starmsg* _(reply to a message) to star it again._");
      } else {
        await send(value46, value47, "⭐ *Message Starred*\n\nThe message has been added to your starred messages.\n\n_Use_ *.starmsg unstar* _(reply to the message) to unstar._");
      }
      await react(value46, value47, "✅");
    } catch (error53) {
      console.error("[starmsg]", error53.message);
      await react(value46, value47, "❌");
      value49.reply("❌ Failed to " + (value51 ? "unstar" : "star") + " message. Please try again.");
    }
  }
}];
