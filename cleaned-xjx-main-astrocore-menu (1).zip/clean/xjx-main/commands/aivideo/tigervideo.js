const axios = require("axios");
const {
  downloadMedia
} = require("./ephotoVideo");
const database = require("../../database");
function extractVideoUrl(value1) {
  if (typeof value1 !== "string") {
    return null;
  }
  const value2 = [/<video[^>]+src=["']([^"']+)["']/i, /<a[^>]+href=["']([^"']+\.(?:mp4|webm|mov)(?:\?[^"']*)?)["']/i, /<iframe[^>]+src=["']([^"']+)["']/i];
  for (const value3 of value2) {
    const value4 = value1.match(value3);
    if (value4?.[1]) {
      if (value4[1].startsWith("http")) {
        return value4[1];
      } else {
        return "https://en.ephoto360.com" + value4[1];
      }
    }
  }
  return null;
}
async function generateTigerVideo(value5) {
  const value6 = "https://en.ephoto360.com/create-digital-tiger-logo-video-effect-723.html";
  try {
    const value7 = await axios.post(value6, new URLSearchParams({
      text: value5,
      submit: "Create"
    }), {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0",
        Referer: value6
      },
      timeout: 30000,
      maxRedirects: 5
    });
    const value8 = extractVideoUrl(value7.data);
    if (value8) {
      return value8;
    }
  } catch (error9) {
    console.error("[TIGERVIDEO] Primary API failed: " + error9.message);
  }
  const value10 = ["https://api.ephoto360.com/create-digital-tiger-logo-video-effect-723?text=" + encodeURIComponent(value5), "https://ephoto-api.vercel.app/api/tiger-video?text=" + encodeURIComponent(value5), "https://api.textpro.me/create-tiger-video?text=" + encodeURIComponent(value5)];
  for (const value11 of value10) {
    try {
      const value12 = await axios.get(value11, {
        timeout: 15000
      });
      const value13 = value12.data?.url || value12.data?.result?.url || extractVideoUrl(value12.data);
      if (value13) {
        return value13;
      }
    } catch {}
  }
  return null;
}
module.exports = {
  name: "tigervideo",
  aliases: ["tigerlogo", "tigertext", "tigervid", "tigeranimation"],
  category: "aivideo",
  description: "Create a digital tiger logo video with your text",
  usage: (database.getBotSetting("prefix") || ".") + "tigervideo <text>",
  async execute(value14, value15, value16, value17 = {}) {
    const value18 = value15.key.remoteJid;
    const value19 = value17.prefix || database.getBotSetting("prefix") || ".";
    await value14.sendMessage(value18, {
      react: {
        text: "⏳",
        key: value15.key
      }
    });
    try {
      const value20 = value16.join(" ").trim();
      if (!value20) {
        return value14.sendMessage(value18, {
          text: "🐯 Digital tiger logo video\n\nUsage: " + value19 + "tigervideo <text>\nMaximum: 30 characters\nExamples:\n" + value19 + "tigervideo " + (database.getBotSetting("botName") || "JUNE-X") + "\n" + value19 + "tigervideo TIGER KING"
        }, {
          quoted: value15
        });
      }
      if (value20.length > 30) {
        return value14.sendMessage(value18, {
          text: "❌ Text is too long! Please use maximum 30 characters."
        }, {
          quoted: value15
        });
      }
      const value21 = await generateTigerVideo(value20);
      if (!value21) {
        return value14.sendMessage(value18, {
          text: "❌ Failed to generate tiger video for \"" + value20 + "\". Please try again later."
        }, {
          quoted: value15
        });
      }
      const value22 = await downloadMedia(value21);
      if (!value22.isVideo) {
        throw new Error("The tiger provider returned a non-video result");
      }
      await value14.sendMessage(value18, {
        video: value22.buffer,
        caption: "🐯 *DIGITAL TIGER VIDEO*\n📝 *Text:* " + value20,
        mimetype: value22.mimetype,
        gifPlayback: false
      }, {
        quoted: value15
      });
      await value14.sendMessage(value18, {
        react: {
          text: "✅",
          key: value15.key
        }
      });
    } catch (error23) {
      console.error("[TIGERVIDEO] Error:", error23);
      await value14.sendMessage(value18, {
        text: "❌ Error generating tiger video:\n" + error23.message
      }, {
        quoted: value15
      });
      await value14.sendMessage(value18, {
        react: {
          text: "❌",
          key: value15.key
        }
      });
    }
  }
};
