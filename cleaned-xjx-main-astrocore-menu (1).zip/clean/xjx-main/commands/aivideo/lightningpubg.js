const {
  generateEphoto,
  downloadMedia,
  sendGeneratedMedia
} = require("./ephotoVideo");
const database = require("../../database");
const EFFECT_URLS = ["https://en.ephoto360.com/lightning-pubg-video-logo-maker-online-615.html", "https://en.ephoto360.com/create-pubg-style-glitch-video-avatar-581.html", "https://en.ephoto360.com/create-gaming-logo-pubg-style-online-free-575.html", "https://en.ephoto360.com/pubg-battlegrounds-logo-maker-online-free-576.html"];
module.exports = {
  name: "lightningpubg",
  aliases: ["pubgvideo", "pubglightning", "pubglogo", "pubgintro", "lightningpubgvideo"],
  category: "aivideo",
  description: "Create a lightning PUBG video logo with your text",
  usage: (database.getBotSetting("prefix") || ".") + "lightningpubg <text>",
  async execute(value1, value2, value3, value4 = {}) {
    const value5 = value2.key.remoteJid;
    const value6 = value4.prefix || database.getBotSetting("prefix") || ".";
    await value1.sendMessage(value5, {
      react: {
        text: "⏳",
        key: value2.key
      }
    });
    try {
      const value7 = value3.join(" ").trim();
      if (!value7) {
        return value1.sendMessage(value5, {
          text: "⚡ Lightning PUBG video\n\nUsage: " + value6 + "lightningpubg <text>\nMaximum: 25 characters\nExample: " + value6 + "lightningpubg " + (database.getBotSetting("botName") || "JUNE-X")
        }, {
          quoted: value2
        });
      }
      if (value7.length > 25) {
        return value1.sendMessage(value5, {
          text: "❌ Text is too long! Please use maximum 25 characters."
        }, {
          quoted: value2
        });
      }
      let value8 = null;
      for (const value9 of EFFECT_URLS) {
        value8 = await generateEphoto(value9, value7);
        if (value8) {
          break;
        }
      }
      if (!value8) {
        return value1.sendMessage(value5, {
          text: "❌ Failed to generate lightning PUBG effect for \"" + value7 + "\". Please try again later."
        }, {
          quoted: value2
        });
      }
      const value10 = await downloadMedia(value8, 45000);
      await sendGeneratedMedia(value1, value2, value10, {
        videoCaption: "⚡ *LIGHTNING PUBG VIDEO LOGO*\n📝 *Text:* " + value7,
        imageCaption: "⚡ *LIGHTNING PUBG EFFECT*\n📝 *Text:* " + value7
      });
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error11) {
      console.error("[LIGHTNINGPUBG] Error:", error11);
      await value1.sendMessage(value5, {
        text: "❌ Error generating lightning PUBG video:\n" + error11.message
      }, {
        quoted: value2
      });
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
    }
  }
};
