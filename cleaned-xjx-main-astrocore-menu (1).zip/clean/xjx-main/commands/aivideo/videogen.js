const axios = require("axios");
const database = require("../../database");
function getVideoFile(value1) {
  return value1?.video_files?.filter(value2 => value2?.link)?.sort((value3, value4) => (value4.width || 0) - (value3.width || 0))[0]?.link;
}
module.exports = {
  name: "videogen",
  aliases: ["vgen"],
  category: "aivideo",
  description: "Fetch a short video from a keyword",
  usage: (database.getBotSetting("prefix") || ".") + "videogen <keyword>",
  async execute(value5, value6, value7, value8 = {}) {
    const value9 = value6.key.remoteJid;
    const value10 = value8.prefix || database.getBotSetting("prefix") || ".";
    const value11 = value7.join(" ").trim();
    await value5.sendMessage(value9, {
      react: {
        text: "⏳",
        key: value6.key
      }
    });
    if (!value11) {
      return value5.sendMessage(value9, {
        text: "🎬 Video generator\n\nUsage: " + value10 + "videogen <keyword>\nExample: " + value10 + "videogen wolf anime"
      }, {
        quoted: value6
      });
    }
    const value12 = process.env.PEXELS_API_KEY?.trim();
    if (!value12) {
      return value5.sendMessage(value9, {
        text: "❌ Video search is not configured. Add `PEXELS_API_KEY` to the June-X environment before using this command."
      }, {
        quoted: value6
      });
    }
    try {
      const value13 = await axios.get("https://api.pexels.com/videos/search", {
        params: {
          query: value11,
          per_page: 3
        },
        headers: {
          Authorization: value12
        },
        timeout: 30000
      });
      const value14 = value13.data?.videos || [];
      if (!value14.length) {
        return value5.sendMessage(value9, {
          text: "❌ No videos found for \"" + value11 + "\"."
        }, {
          quoted: value6
        });
      }
      const value15 = getVideoFile(value14[Math.floor(Math.random() * value14.length)]);
      if (!value15) {
        throw new Error("The video service returned no playable file");
      }
      await value5.sendMessage(value9, {
        video: {
          url: value15
        },
        caption: "🎬 Video result for: \"" + value11 + "\"\n" + (database.getBotSetting("botName") || "JuneX-Ultra") + " Video"
      }, {
        quoted: value6
      });
    } catch (error16) {
      console.error("[VIDEOGEN] Error:", error16);
      await value5.sendMessage(value9, {
        text: "⚠️ Failed to fetch video: " + error16.message
      }, {
        quoted: value6
      });
    }
  }
};
