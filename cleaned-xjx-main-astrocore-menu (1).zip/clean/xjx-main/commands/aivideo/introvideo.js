const {
  generateEphoto,
  downloadMedia,
  sendGeneratedMedia
} = require("./ephotoVideo");
const database = require("../../database");
const EFFECT_URLS = ["https://en.ephoto360.com/free-logo-intro-video-maker-online-558.html", "https://en.ephoto360.com/free-logo-intro-video-maker-online-582.html", "https://en.ephoto360.com/create-digital-glitch-text-effect-online-772.html"];
module.exports = {
  name: "introvideo",
  aliases: ["intro", "logointro", "introanimation", "videointro"],
  category: "aivideo",
  description: "Create a logo intro video with your text",
  usage: (database.getBotSetting("prefix") || ".") + "introvideo <text>",
  async execute(value1, value2, value3, value4 = {}) {
    const value5 = value2.key.remoteJid;
    const value6 = value4.prefix || database.getBotSetting("prefix") || ".";
    await value1.sendMessage(value5, {
      react: {
        text: "⏳",
        key: value2.key
      }
    });
    try {
      const value7 = value3.join(" ").trim();
      if (!value7) {
        return value1.sendMessage(value5, {
          text: "🎬 Logo intro video\n\nUsage: " + value6 + "introvideo <text>\nMaximum: 30 characters\nExample: " + value6 + "introvideo " + (database.getBotSetting("botName") || "JUNE-X")
        }, {
          quoted: value2
        });
      }
      if (value7.length > 30) {
        return value1.sendMessage(value5, {
          text: "❌ Text is too long! Please use maximum 30 characters."
        }, {
          quoted: value2
        });
      }
      let value8 = null;
      for (const value9 of EFFECT_URLS) {
        value8 = await generateEphoto(value9, value7);
        if (value8) {
          break;
        }
      }
      if (!value8) {
        return value1.sendMessage(value5, {
          text: "❌ Failed to generate intro video for \"" + value7 + "\". Please try again later."
        }, {
          quoted: value2
        });
      }
      const value10 = await downloadMedia(value8, 45000);
      await sendGeneratedMedia(value1, value2, value10, {
        videoCaption: "🎬 *LOGO INTRO VIDEO*\n📝 *Text:* " + value7,
        imageCaption: "🎬 *LOGO INTRO EFFECT*\n📝 *Text:* " + value7
      });
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error11) {
      console.error("[INTROVIDEO] Error:", error11);
      await value1.sendMessage(value5, {
        text: "❌ Error generating intro video:\n" + error11.message
      }, {
        quoted: value2
      });
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
    }
  }
};
