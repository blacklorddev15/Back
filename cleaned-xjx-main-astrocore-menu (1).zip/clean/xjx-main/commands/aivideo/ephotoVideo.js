const axios = require("axios");
const mumaker = require("mumaker");
const USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36";
function resultUrlFrom(value1) {
  return value1?.url || value1?.image || value1?.img || value1?.result?.url || value1?.result?.image || null;
}
async function generateEphoto(value2, value3) {
  const value4 = encodeURIComponent(value3);
  const value5 = ["https://api-photooxy.vercel.app/api/ephoto360?url=" + encodeURIComponent(value2) + "&text=" + value4, "https://widipe.com/ephoto360?url=" + encodeURIComponent(value2) + "&text=" + value4];
  for (const value6 of value5) {
    try {
      const value7 = await axios.get(value6, {
        timeout: 15000,
        headers: {
          "User-Agent": USER_AGENT
        }
      });
      const value8 = resultUrlFrom(value7.data);
      if (value8) {
        return value8;
      }
    } catch {}
  }
  try {
    const value9 = await mumaker.ephoto(value2, value3);
    const value10 = resultUrlFrom(value9);
    if (value10) {
      return value10;
    }
  } catch (error11) {
    console.error("[AIVIDEO] Ephoto fallback failed: " + error11.message);
  }
  return null;
}
async function downloadMedia(value12, value13 = 45000) {
  const value14 = await axios.get(value12, {
    responseType: "arraybuffer",
    timeout: value13,
    maxContentLength: 62914560,
    maxBodyLength: 62914560,
    headers: {
      "User-Agent": USER_AGENT,
      Accept: "*/*",
      Referer: "https://en.ephoto360.com/"
    }
  });
  const value15 = Buffer.from(value14.data);
  if (!value15.length) {
    throw new Error("Generated media is empty");
  }
  if (value15.length > 52428800) {
    throw new Error("Generated media is too large (" + (value15.length / 1024 / 1024).toFixed(2) + "MB)");
  }
  const value16 = String(value14.headers["content-type"] || "").toLowerCase();
  const value17 = value16.startsWith("video/") || /\.(mp4|webm|mov)(?:[?#]|$)/i.test(value12);
  return {
    buffer: value15,
    isVideo: value17,
    mimetype: value17 ? value16.startsWith("video/") ? value16 : "video/mp4" : "image/jpeg",
    sizeMB: (value15.length / 1024 / 1024).toFixed(2)
  };
}
async function sendGeneratedMedia(value18, value19, value20, {
  videoCaption: value21,
  imageCaption: value22
}) {
  const value23 = value20.isVideo ? {
    video: value20.buffer,
    caption: value21,
    mimetype: value20.mimetype,
    gifPlayback: false
  } : {
    image: value20.buffer,
    caption: value22
  };
  return value18.sendMessage(value19.key.remoteJid, value23, {
    quoted: value19
  });
}
module.exports = {
  generateEphoto: generateEphoto,
  downloadMedia: downloadMedia,
  sendGeneratedMedia: sendGeneratedMedia
};
