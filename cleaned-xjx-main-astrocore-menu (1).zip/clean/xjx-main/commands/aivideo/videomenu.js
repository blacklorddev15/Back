const database = require("../../database");
module.exports = {
  name: "videomenu",
  aliases: ["vidmenu", "aividmenu", "videoeffects"],
  description: "Show AI video effect commands",
  category: "aivideo",
  usage: (database.getBotSetting("prefix") || ".") + "videomenu",
  async execute(value1, value2, value3, value4 = {}) {
    const value5 = value2.key.remoteJid;
    const value6 = value4.prefix || database.getBotSetting("prefix") || ".";
    const value7 = ["🎬 AI video commands", "", value6 + "tigervideo", value6 + "introvideo", value6 + "lightningpubg", value6 + "lovevideo", value6 + "videogen"].join("\n");
    return value1.sendMessage(value5, {
      text: value7
    }, {
      quoted: value2
    });
  }
};
