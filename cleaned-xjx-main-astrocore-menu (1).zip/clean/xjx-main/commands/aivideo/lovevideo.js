const {
  generateEphoto,
  downloadMedia,
  sendGeneratedMedia
} = require("./ephotoVideo");
const database = require("../../database");
const EFFECT_URLS = ["https://en.ephoto360.com/create-sweet-love-video-cards-online-734.html", "https://en.ephoto360.com/create-romantic-luxury-video-wedding-invitations-online-580.html", "https://en.ephoto360.com/write-text-on-love-hearts-261.html", "https://en.ephoto360.com/love-hearts-name-generator-353.html"];
module.exports = {
  name: "lovevideo",
  aliases: ["lovecard", "sweetlove", "loveanimation", "lovegreeting", "romanticvideo"],
  category: "aivideo",
  description: "Create a sweet love video card with your text",
  usage: (database.getBotSetting("prefix") || ".") + "lovevideo <text>",
  async execute(value1, value2, value3, value4 = {}) {
    const value5 = value2.key.remoteJid;
    const value6 = value4.prefix || database.getBotSetting("prefix") || ".";
    await value1.sendMessage(value5, {
      react: {
        text: "⏳",
        key: value2.key
      }
    });
    try {
      const value7 = value3.join(" ").trim();
      if (!value7) {
        return value1.sendMessage(value5, {
          text: "💖 Love video card\n\nUsage: " + value6 + "lovevideo <text>\nMaximum: 50 characters\nExample: " + value6 + "lovevideo I love " + (database.getBotSetting("botName") || "you")
        }, {
          quoted: value2
        });
      }
      if (value7.length > 50) {
        return value1.sendMessage(value5, {
          text: "❌ Text is too long! Please use maximum 50 characters."
        }, {
          quoted: value2
        });
      }
      let value8 = null;
      for (const value9 of EFFECT_URLS) {
        value8 = await generateEphoto(value9, value7);
        if (value8) {
          break;
        }
      }
      if (!value8) {
        return value1.sendMessage(value5, {
          text: "❌ Failed to generate love video for \"" + value7 + "\". Please try again later."
        }, {
          quoted: value2
        });
      }
      const value10 = await downloadMedia(value8, 45000);
      await sendGeneratedMedia(value1, value2, value10, {
        videoCaption: "💖 *SWEET LOVE VIDEO CARD*\n📝 *Message:* " + value7,
        imageCaption: "💖 *SWEET LOVE CARD*\n📝 *Message:* " + value7
      });
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error11) {
      console.error("[LOVEVIDEO] Error:", error11);
      await value1.sendMessage(value5, {
        text: "❌ Error generating love video:\n" + error11.message
      }, {
        quoted: value2
      });
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
    }
  }
};
