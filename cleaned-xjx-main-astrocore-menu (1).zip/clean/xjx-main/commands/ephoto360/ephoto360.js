const axios = require("axios");
const cheerio = require("cheerio");
const database = require("../../database");
async function ephoto(value1, value2) {
  let value3 = new FormData();
  let value4 = await axios.get(value1, {
    headers: {
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36"
    }
  });
  let value5 = cheerio.load(value4.data);
  let value6 = value5("input[name=token]").val();
  let value7 = value5("input[name=build_server]").val();
  let value8 = value5("input[name=build_server_id]").val();
  value3.append("text[]", value2);
  value3.append("token", value6);
  value3.append("build_server", value7);
  value3.append("build_server_id", value8);
  let value9 = await axios({
    url: value1,
    method: "POST",
    data: value3,
    headers: {
      Accept: "*/*",
      "Accept-Language": "en-US,en;q=0.9",
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
      cookie: value4.headers["set-cookie"]?.join("; "),
      "Content-Type": "multipart/form-data"
    }
  });
  let value10 = cheerio.load(value9.data);
  let value11 = JSON.parse(value10("input[name=form_value_input]").val());
  value11["text[]"] = value11.text;
  delete value11.text;
  let {
    data: value12
  } = await axios.post("https://en.ephoto360.com/effect/create-image", new URLSearchParams(value11), {
    headers: {
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
      cookie: value4.headers["set-cookie"].join("; ")
    }
  });
  return value7 + value12.image;
}
function makeEphotoCmd(value13, value14, value15, value16) {
  return {
    name: value13,
    aliases: value14,
    category: "textmaker",
    description: value16,
    usage: "." + value13 + " <text>",
    async execute(value17, value18, value19, value20) {
      const {
        from: value21,
        reply: value22
      } = value20 || {};
      const value23 = value21 || value18.key.remoteJid;
      const value24 = value19.join(" ");
      const value25 = database.getBotSetting("prefix") || ".";
      if (!value24) {
        const value26 = value22 || (value27 => value17.sendMessage(value23, {
          text: value27
        }, {
          quoted: value18
        }));
        return value26("*Example: " + value25 + value13 + " vin*");
      }
      try {
        const value28 = await ephoto(value15, value24);
        await value17.sendMessage(value23, {
          image: {
            url: value28
          },
          caption: database.getBotSetting("botName")
        }, {
          quoted: value18
        });
      } catch (error29) {
        console.error("Error in " + value13 + " command:", error29);
        const value30 = value22 || (value31 => value17.sendMessage(value23, {
          text: value31
        }, {
          quoted: value18
        }));
        value30("*❌ An error occurred while generating the effect.*");
      }
    }
  };
}
function makeApiCmd(value32, value33, value34, value35, value36) {
  return {
    name: value32,
    aliases: value33,
    category: "textmaker",
    description: value35,
    usage: "." + value32 + " <text>",
    async execute(value37, value38, value39, value40) {
      const {
        from: value41,
        reply: value42
      } = value40 || {};
      const value43 = value41 || value38.key.remoteJid;
      const value44 = value39.join(" ");
      const value45 = database.getBotSetting("prefix") || ".";
      const value46 = value42 || (value47 => value37.sendMessage(value43, {
        text: value47
      }, {
        quoted: value38
      }));
      if (!value44) {
        return value46("*Example: " + value45 + value32 + " vin*");
      }
      try {
        await value46(value36);
        const value48 = value34(encodeURIComponent(value44));
        await value37.sendMessage(value43, {
          image: {
            url: value48
          },
          caption: database.getBotSetting("botName")
        }, {
          quoted: value38
        });
      } catch (error49) {
        console.error("Error in " + value32 + " command:", error49);
        value46("❌ Error generating effect. Please try again later.");
      }
    }
  };
}
module.exports = [makeEphotoCmd("luxurygold", ["goldtext", "goldfx"], "https://en.ephoto360.com/create-a-luxury-gold-text-effect-online-594.html", "Create a luxury gold text effect"), makeEphotoCmd("advancedglow", ["aglow"], "https://en.ephoto360.com/advanced-glow-effects-74.html", "Create an advanced glow text effect"), makeEphotoCmd("blackpinklogo", ["bplogo"], "https://en.ephoto360.com/create-blackpink-logo-online-free-607.html", "Create a Blackpink logo style text"), makeEphotoCmd("blackpinkstyle", ["bpstyle"], "https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html", "Create a Blackpink style text effect"), makeEphotoCmd("cartoonstyle", ["cartoonfx"], "https://en.ephoto360.com/create-a-cartoon-style-graffiti-text-effect-online-668.html", "Create a cartoon style graffiti text effect"), makeEphotoCmd("deadpool", ["deadpoolfx"], "https://en.ephoto360.com/create-light-effects-green-neon-online-429.html", "Create a green neon light text effect"), makeEphotoCmd("effectclouds", ["cloudsfx"], "https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html", "Write text in clouds in the sky"), makeEphotoCmd("flagtext", ["flagfx"], "https://en.ephoto360.com/nigeria-3d-flag-text-effect-online-free-753.html", "Create a 3D flag text effect"), makeEphotoCmd("freecreate", ["freefx"], "https://en.ephoto360.com/free-create-a-3d-hologram-text-effect-441.html", "Create a 3D hologram text effect"), makeEphotoCmd("galaxystyle", ["galaxyfx"], "https://en.ephoto360.com/create-galaxy-style-free-name-logo-438.html", "Create a galaxy style name logo"), makeEphotoCmd("galaxywallpaper", ["galaxywp"], "https://en.ephoto360.com/create-galaxy-wallpaper-mobile-online-528.html", "Create a galaxy wallpaper with your text"), makeEphotoCmd("makingneon", ["makeneon"], "https://en.ephoto360.com/making-neon-light-text-effect-with-galaxy-style-521.html", "Create neon light text with galaxy style"), makeEphotoCmd("matrixfx", ["matrixtext"], "https://en.ephoto360.com/matrix-text-effect-154.html", "Create a matrix style text effect"), makeEphotoCmd("royaltext", ["royalfx"], "https://en.ephoto360.com/royal-text-effect-online-free-471.html", "Create a royal text effect"), makeEphotoCmd("sandfx", ["sandtext"], "https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html", "Write text in sand on a beach"), makeEphotoCmd("summerbeach", ["beachfx"], "https://en.ephoto360.com/write-in-sand-summer-beach-online-free-595.html", "Write text on a summer beach"), makeEphotoCmd("topography", ["topofx"], "https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html", "Create typography text effect on pavement"), makeEphotoCmd("typography", ["typefx"], "https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html", "Create a typography pavement text effect"), makeEphotoCmd("flag3dtext", ["flag3d"], "https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html", "Create a 3D American flag text effect"), makeEphotoCmd("glitchtext", ["textglitch"], "https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html", "Create a digital glitch text effect"), makeEphotoCmd("dragonball", ["dragonballfx"], "https://en.ephoto360.com/create-dragon-ball-style-text-effects-online-809.html", "Create a Dragon Ball style text effect"), makeEphotoCmd("multicoloredneon", ["multicneon"], "https://en.ephoto360.com/create-multicolored-neon-light-signatures-591.html", "Create multicolored neon light signatures"), makeEphotoCmd("neonglitch", ["neonglitchfx"], "https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html", "Create impressive neon glitch text effect"), makeEphotoCmd("papercutstyle", ["papercutfx"], "https://en.ephoto360.com/multicolor-3d-paper-cut-style-text-effect-658.html", "Create a 3D multicolor paper cut style text"), makeEphotoCmd("pixelglitch", ["pixelglitchfx"], "https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html", "Create a pixel glitch text effect"), makeEphotoCmd("glowingtext", ["glowtxt"], "https://en.ephoto360.com/create-glowing-text-effects-online-706.html", "Create glowing text effect"), makeEphotoCmd("gradienttext", ["gradienttxt"], "https://en.ephoto360.com/create-3d-gradient-text-effect-online-600.html", "Create a 3D gradient text effect"), makeEphotoCmd("graffiti", ["graffitifx"], "https://en.ephoto360.com/cute-girl-painting-graffiti-text-effect-667.html", "Create a graffiti text effect"), makeEphotoCmd("incandescent", ["incandescentfx"], "https://en.ephoto360.com/text-effects-incandescent-bulbs-219.html", "Create incandescent bulb text effect"), makeEphotoCmd("lighteffects", ["lightfx"], "https://en.ephoto360.com/create-light-effects-green-neon-online-429.html", "Create light/neon text effects"), makeEphotoCmd("logomaker", ["logomake"], "https://en.ephoto360.com/free-bear-logo-maker-online-673.html", "Create a bear logo with text"), makeApiCmd("royal", ["royal2"], value50 => "https://api.nekolabs.my.id/ephoto/royal-text?text=" + value50, "Create a royal logo (via external API)", "👑 Creating royal logo... Please wait ⏳"), makeApiCmd("textonwetglass", ["wetglass", "wetfx"], value51 => "https://api.nekolabs.web.id/ephoto/text-on-wet-glass?text=" + value51, "Create a wet glass text effect (via external API)", "💧 Creating text on wet glass effect... Please wait ⏳"), makeApiCmd("bear", ["bearlogo"], value52 => "https://api.nekolabs.my.id/ephoto/bear-logo?text=" + value52, "Create a bear logo (via external API)", "🐻 Creating bear logo... Please wait ⏳"), makeApiCmd("papercut", ["3dpaper", "paper3d"], value53 => "https://api.nekolabs.my.id/ephoto/3d-paper-cut-style?text=" + value53, "Create a 3D paper cut style (via external API)", "✂️ Creating 3D paper cut style... Please wait ⏳"), makeApiCmd("hologram", ["3dhologram", "hologram3d"], value54 => "https://api.nekolabs.my.id/ephoto/3d-hologram-text?text=" + value54, "Create a 3D hologram text (via external API)", "✨ Creating 3D hologram text... Please wait ⏳")];
