const axios = require("axios");
const APIs = require("../../utils/api");
const database = require("../../database");
const getFooter = () => "Powered by " + database.getBotSetting("botName");
module.exports = {
  name: "tiktokstalk",
  aliases: ["ttstalk", "tikstalk", "tiktokinfo"],
  description: "Stalk a TikTok user profile",
  category: "Stalker Commands",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = database.getBotSetting("prefix") || ".";
    if (!value3 || !value3[0]) {
      return value1.sendMessage(value5, {
        text: "┏━━『 🔍 TIKTOK STALKER 』━━\n" + ("➥ Command    ➜ " + value6 + "tiktokstalk <username>\n") + "➥ Usage      ➜ Stalk a TikTok profile\n" + ("➥ Example    ➜ " + value6 + "tiktokstalk tiktokuser\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value2
      });
    }
    const value7 = value3[0].replace("@", "").trim();
    await value1.sendMessage(value5, {
      react: {
        text: "🔍",
        key: value2.key
      }
    });
    try {
      const value8 = await APIs.stalkTikTok(value7);
      let value9 = null;
      if (value8.avatar) {
        try {
          const value10 = await axios.get(value8.avatar, {
            responseType: "arraybuffer",
            timeout: 10000
          });
          if (value10.data.length > 500) {
            value9 = Buffer.from(value10.data);
          }
        } catch {}
      }
      const value11 = ["┏━━『 🎵 TIKTOK PROFILE 』━━", "➥ Name       ➜ " + value8.name, "➥ Username   ➜ @" + value8.username, "➥ Bio        ➜ " + value8.bio, "➥ Followers  ➜ " + Number(value8.followers).toLocaleString(), "➥ Following  ➜ " + Number(value8.following).toLocaleString(), "➥ Likes      ➜ " + Number(value8.likes).toLocaleString()];
      if (value8.videos !== null) {
        value11.push("➥ Videos     ➜ " + value8.videos);
      }
      value11.push("➥ Verified   ➜ " + (value8.verified ? "Yes ✔️" : "No"));
      value11.push("➥ Private    ➜ " + (value8.private ? "Yes" : "No"));
      if (value8.profileUrl) {
        value11.push("➥ Profile    ➜ " + value8.profileUrl);
      }
      value11.push("➥ Powered By ➜ " + database.getBotSetting("botName"), "┗━━━━━━━━━━━━━━━━");
      const value12 = value11.join("\n");
      if (value9) {
        await value1.sendMessage(value5, {
          image: value9,
          caption: value12
        }, {
          quoted: value2
        });
      } else {
        await value1.sendMessage(value5, {
          text: value12
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error13) {
      console.error("❌ [TIKTOKSTALK] Error:", error13.message);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        text: "❌ *TikTok Stalk Failed*\n\n⚠️ " + error13.message + "\n\n💡 Check the username and try again."
      }, {
        quoted: value2
      });
    }
  }
};
