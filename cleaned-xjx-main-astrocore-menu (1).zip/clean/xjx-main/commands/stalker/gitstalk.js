const axios = require("axios");
const APIs = require("../../utils/api");
const database = require("../../database");
const DEFAULT_USER = "torvalds";
const getFooter = () => "Powered by " + database.getBotSetting("botName");
module.exports = {
  name: "gitstalk",
  aliases: ["githubstalk", "ghstalk"],
  description: "Stalk a GitHub user profile",
  category: "Stalker Commands",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = database.getBotSetting("prefix") || ".";
    if (!value3 || !value3[0]) {
      return value1.sendMessage(value5, {
        text: "┏━━『 🔍 GITHUB STALKER 』━━\n" + ("➥ Command    ➜ " + value6 + "gitstalk <username>\n") + "➥ Usage      ➜ Stalk a GitHub profile\n" + ("➥ Example    ➜ " + value6 + "gitstalk " + DEFAULT_USER + "\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value2
      });
    }
    const value7 = value3[0].replace("@", "").trim();
    await value1.sendMessage(value5, {
      react: {
        text: "🔍",
        key: value2.key
      }
    });
    try {
      const value8 = await APIs.stalkGitHub(value7);
      const value9 = value8?.result || value8?.data || value8;
      if (!value9 || !value9.login && !value9.username) {
        throw new Error("User not found on GitHub");
      }
      const value10 = JSON.stringify(value8, null, 2);
      const value11 = value10.length > 900 ? value10.slice(0, 900) + "\n... (truncated)" : value10;
      const value12 = "```json\n" + value11 + "\n```";
      let value13 = null;
      const value14 = value9.avatar_url || value9.avatar;
      if (value14) {
        try {
          const value15 = await axios.get(value14, {
            responseType: "arraybuffer",
            timeout: 10000
          });
          if (value15.data.length > 500) {
            value13 = Buffer.from(value15.data);
          }
        } catch {}
      }
      if (value13) {
        await value1.sendMessage(value5, {
          image: value13,
          caption: value12
        }, {
          quoted: value2
        });
      } else {
        await value1.sendMessage(value5, {
          text: value12
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error16) {
      console.error("❌ [GITSTALK] Error:", error16.message);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        text: "❌ *GitHub Stalk Failed*\n\n⚠️ " + error16.message + "\n\n💡 Check the username and try again."
      }, {
        quoted: value2
      });
    }
  }
};
