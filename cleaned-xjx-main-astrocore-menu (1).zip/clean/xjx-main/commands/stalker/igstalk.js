const axios = require("axios");
const APIs = require("../../utils/api");
const database = require("../../database");
const getFooter = () => "Powered by " + database.getBotSetting("botName");
module.exports = {
  name: "igstalk",
  aliases: ["instastalk", "iginfo", "instagramstalk"],
  description: "Stalk an Instagram user profile",
  category: "Stalker Commands",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = database.getBotSetting("prefix") || ".";
    if (!value3 || !value3[0]) {
      return value1.sendMessage(value5, {
        text: "┏━━『 🔍 INSTAGRAM STALKER 』━━\n" + ("➥ Command    ➜ " + value6 + "igstalk <username>\n") + "➥ Usage      ➜ Stalk an Instagram profile\n" + ("➥ Example    ➜ " + value6 + "igstalk giftedtechnexus\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value2
      });
    }
    const value7 = value3[0].replace("@", "").trim();
    await value1.sendMessage(value5, {
      react: {
        text: "🔍",
        key: value2.key
      }
    });
    try {
      const value8 = await APIs.stalkInstagram(value7);
      let value9 = null;
      if (value8.avatar) {
        try {
          const value10 = await axios.get(value8.avatar, {
            responseType: "arraybuffer",
            timeout: 10000
          });
          if (value10.data.length > 500) {
            value9 = Buffer.from(value10.data);
          }
        } catch {}
      }
      const value11 = "┏━━『 📸 INSTAGRAM PROFILE 』━━\n" + ("➥ Full Name  ➜ " + (value8.full_name || "N/A") + "\n") + ("➥ Username   ➜ @" + (value8.username || value7) + "\n") + ("➥ Bio        ➜ " + (value8.description || "N/A") + "\n") + ("➥ Posts      ➜ " + (value8.posts || "0") + "\n") + ("➥ Followers  ➜ " + (value8.followers || "0") + "\n") + ("➥ Following  ➜ " + (value8.following || "0") + "\n") + ("➥ Private    ➜ " + (value8.is_private ? "Yes" : "No") + "\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━";
      if (value9) {
        await value1.sendMessage(value5, {
          image: value9,
          caption: value11
        }, {
          quoted: value2
        });
      } else {
        await value1.sendMessage(value5, {
          text: value11
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error12) {
      console.error("❌ [IGSTALK] Error:", error12.message);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        text: "❌ *Instagram Stalk Failed*\n\n⚠️ " + error12.message + "\n\n💡 Check the username and try again."
      }, {
        quoted: value2
      });
    }
  }
};
