const APIs = require("../../utils/api");
const database = require("../../database");
const getFooter = () => "Powered by " + database.getBotSetting("botName");
module.exports = {
  name: "ipstalk",
  aliases: ["ipinfo2", "iplookup", "iptrack"],
  description: "Look up information about an IP address",
  category: "Stalker Commands",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = database.getBotSetting("prefix") || ".";
    if (!value3 || !value3[0]) {
      return value1.sendMessage(value5, {
        text: "┏━━『 🔍 IP STALKER 』━━\n" + ("➥ Command    ➜ " + value6 + "ipstalk <IP address>\n") + "➥ Usage      ➜ Look up IP address info\n" + ("➥ Example    ➜ " + value6 + "ipstalk 41.90.70.195\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value2
      });
    }
    const value7 = value3[0].trim();
    await value1.sendMessage(value5, {
      react: {
        text: "🔍",
        key: value2.key
      }
    });
    try {
      const value8 = await APIs.stalkIp(value7);
      let value9 = "┏━━『 🌐 IP ADDRESS INFO 』━━\n" + ("➥ IP         ➜ " + value7 + "\n") + ("➥ Country    ➜ " + (value8.country || "N/A") + "\n") + ("➥ Continent  ➜ " + (value8.continent || "N/A") + "\n") + ("➥ Country Code ➜ " + (value8.countryCode || "N/A") + "\n") + ("➥ ASN        ➜ " + (value8.asn || "N/A") + "\n") + ("➥ ISP/AS Name ➜ " + (value8.asName || "N/A") + "\n") + ("➥ AS Domain  ➜ " + (value8.asDomain || "N/A"));
      if (value8.continentCode) {
        value9 += "\n➥ Continent Code ➜ " + value8.continentCode;
      }
      value9 += "\n➥ Powered By ➜ " + database.getBotSetting("botName") + "\n┗━━━━━━━━━━━━━━━━";
      await value1.sendMessage(value5, {
        text: value9
      }, {
        quoted: value2
      });
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error10) {
      console.error("❌ [IPSTALK] Error:", error10.message);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        text: "❌ *IP Stalk Failed*\n\n⚠️ " + error10.message + "\n\n💡 Make sure the IP address is valid."
      }, {
        quoted: value2
      });
    }
  }
};
