const axios = require("axios");
const APIs = require("../../utils/api");
const database = require("../../database");
const getFooter = () => "Powered by " + database.getBotSetting("botName");
module.exports = {
  name: "twitterstalk",
  aliases: ["twstalk", "xstalk", "twitterinfo"],
  description: "Stalk a Twitter/X user profile",
  category: "Stalker Commands",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = database.getBotSetting("prefix") || ".";
    if (!value3 || !value3[0]) {
      return value1.sendMessage(value5, {
        text: "┏━━『 🔍 TWITTER/X STALKER 』━━\n" + ("➥ Command    ➜ " + value6 + "twitterstalk <username>\n") + "➥ Usage      ➜ Stalk a Twitter/X profile\n" + ("➥ Example    ➜ " + value6 + "twitterstalk giftedmauriceke\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value2
      });
    }
    const value7 = value3[0].replace("@", "").trim();
    await value1.sendMessage(value5, {
      react: {
        text: "🔍",
        key: value2.key
      }
    });
    try {
      const value8 = await APIs.stalkTwitter(value7);
      let value9 = null;
      const value10 = value8.avatar || value8.profile_image_url || value8.profile_image_url_https;
      if (value10) {
        try {
          const value11 = await axios.get(value10.replace("_normal", "_400x400"), {
            responseType: "arraybuffer",
            timeout: 10000
          });
          if (value11.data.length > 500) {
            value9 = Buffer.from(value11.data);
          }
        } catch {}
      }
      let value12 = "┏━━『 🐦 TWITTER/X PROFILE 』━━\n" + ("➥ Name       ➜ " + (value8.name || "N/A") + "\n") + ("➥ Username   ➜ @" + (value8.username || value8.screen_name || value7) + "\n") + ("➥ Bio        ➜ " + (value8.bio || value8.description || "N/A") + "\n") + ("➥ Followers  ➜ " + (value8.followers || value8.followers_count || 0).toLocaleString() + "\n") + ("➥ Following  ➜ " + (value8.following || value8.friends_count || 0).toLocaleString() + "\n") + ("➥ Tweets     ➜ " + (value8.tweets || value8.statuses_count || 0).toLocaleString() + "\n") + ("➥ Verified   ➜ " + (value8.verified ? "Yes" : "No"));
      if (value8.location) {
        value12 += "\n➥ Location   ➜ " + value8.location;
      }
      if (value8.website || value8.url) {
        value12 += "\n➥ Website    ➜ " + (value8.website || value8.url);
      }
      value12 += "\n➥ Powered By ➜ " + database.getBotSetting("botName") + "\n┗━━━━━━━━━━━━━━━━";
      if (value9) {
        await value1.sendMessage(value5, {
          image: value9,
          caption: value12
        }, {
          quoted: value2
        });
      } else {
        await value1.sendMessage(value5, {
          text: value12
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error13) {
      console.error("❌ [TWITTERSTALK] Error:", error13.message);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        text: "❌ *Twitter Stalk Failed*\n\n⚠️ " + error13.message + "\n\n💡 Check the username and try again."
      }, {
        quoted: value2
      });
    }
  }
};
