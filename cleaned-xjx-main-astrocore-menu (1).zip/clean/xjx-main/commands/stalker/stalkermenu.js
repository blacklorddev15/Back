const database = require("../../database");
const getBotName = () => database.getBotSetting("botName");
module.exports = {
  name: "stalkercmd",
  aliases: ["smenu", "stalkermenu", "stalkercmds"],
  description: "Shows all Stalker commands",
  category: "Stalker Commands",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = getBotName();
    const value7 = "┏━━『 🕵️ STALKER COMMANDS 』━━\n➥ WhatsApp Channel ➜ wachannel <URL>\n➥ TikTok           ➜ tiktokstalk <username>\n➥ Twitter/X        ➜ twitterstalk <username>\n➥ IP Address       ➜ ipstalk <IP>\n➥ Instagram        ➜ igstalk <username>\n➥ NPM Package      ➜ npmstalk <package>\n➥ GitHub           ➜ gitstalk <username>\n" + ("➥ Powered By       ➜ " + value6 + "\n") + "┗━━━━━━━━━━━━━━━━";
    await value1.sendMessage(value5, {
      text: value7
    }, {
      quoted: value2
    });
  }
};
