const APIs = require("../../utils/api");
const database = require("../../database");
const getFooter = () => "Powered by " + database.getBotSetting("botName");
module.exports = {
  name: "npmstalk",
  aliases: ["npminfo", "npmlookup", "pkgstalk"],
  description: "Look up an NPM package",
  category: "Stalker Commands",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = database.getBotSetting("prefix") || ".";
    if (!value3 || !value3[0]) {
      return value1.sendMessage(value5, {
        text: "┏━━『 🔍 NPM PACKAGE STALKER 』━━\n" + ("➥ Command    ➜ " + value6 + "npmstalk <package name>\n") + "➥ Usage      ➜ Look up an NPM package\n" + ("➥ Example    ➜ " + value6 + "npmstalk express\n") + ("➥ Example    ➜ " + value6 + "npmstalk gifted-btns\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value2
      });
    }
    const value7 = value3.join(" ").trim();
    await value1.sendMessage(value5, {
      react: {
        text: "🔍",
        key: value2.key
      }
    });
    try {
      const value8 = await APIs.stalkNpm(value7);
      const value9 = value8.name || value7;
      const value10 = value8.version || value8["dist-tags"]?.latest || "N/A";
      const value11 = value8.description || "No description";
      const value12 = value8.author?.name || value8.author || "N/A";
      const value13 = value8.license || "N/A";
      const value14 = value8.homepage || "https://npmjs.com/package/" + value9;
      const value15 = value8.downloads || value8.weeklyDownloads || "N/A";
      const value16 = Array.isArray(value8.keywords) ? value8.keywords.slice(0, 5).join(", ") : value8.keywords || "N/A";
      const value17 = value8.created || value8.time?.created ? new Date(value8.created || value8.time.created).toLocaleDateString() : "N/A";
      const value18 = value8.modified || value8.time?.modified ? new Date(value8.modified || value8.time?.modified).toLocaleDateString() : "N/A";
      let value19 = "┏━━『 📦 NPM PACKAGE INFO 』━━\n" + ("➥ Package    ➜ " + value9 + "\n") + ("➥ Version    ➜ " + value10 + "\n") + ("➥ Description ➜ " + value11 + "\n") + ("➥ Author     ➜ " + value12 + "\n") + ("➥ License    ➜ " + value13 + "\n") + ("➥ Keywords   ➜ " + value16);
      if (value15 !== "N/A") {
        value19 += "\n➥ Downloads  ➜ " + value15;
      }
      value19 += "\n➥ Created    ➜ " + value17 + "\n" + ("➥ Updated    ➜ " + value18 + "\n") + ("➥ Homepage   ➜ " + value14 + "\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━";
      await value1.sendMessage(value5, {
        text: value19
      }, {
        quoted: value2
      });
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error20) {
      console.error("❌ [NPMSTALK] Error:", error20.message);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        text: "❌ *NPM Stalk Failed*\n\n⚠️ " + error20.message + "\n\n💡 Check the package name and try again."
      }, {
        quoted: value2
      });
    }
  }
};
