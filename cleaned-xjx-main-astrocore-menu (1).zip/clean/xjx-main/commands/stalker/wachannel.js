const axios = require("axios");
const APIs = require("../../utils/api");
const database = require("../../database");
const getFooter = () => "Powered by " + database.getBotSetting("botName");
module.exports = {
  name: "wachannel",
  aliases: ["channelstalk", "wachannelstalk", "wacs"],
  description: "Stalk a WhatsApp Channel",
  category: "Stalker Commands",
  async execute(value1, value2, value3, value4) {
    const value5 = value2.key.remoteJid;
    const value6 = database.getBotSetting("prefix") || ".";
    if (!value3 || !value3[0]) {
      return value1.sendMessage(value5, {
        text: "┏━━『 🔍 WHATSAPP CHANNEL STALKER 』━━\n" + ("➥ Command    ➜ " + value6 + "wachannel <channel URL>\n") + "➥ Usage      ➜ Stalk a WhatsApp channel\n" + ("➥ Example    ➜ " + value6 + "wachannel https://whatsapp.com/channel/...\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━"
      }, {
        quoted: value2
      });
    }
    const value7 = value3.join(" ").trim();
    await value1.sendMessage(value5, {
      react: {
        text: "🔍",
        key: value2.key
      }
    });
    try {
      const {
        followers: value8,
        img: value9,
        description: value10
      } = await APIs.stalkWachannel(value7);
      let value11 = null;
      if (value9) {
        try {
          const value12 = await axios.get(value9, {
            responseType: "arraybuffer",
            timeout: 10000
          });
          if (value12.data.length > 500) {
            value11 = Buffer.from(value12.data);
          }
        } catch {}
      }
      const value13 = "┏━━『 📢 WHATSAPP CHANNEL INFO 』━━\n" + ("➥ Followers  ➜ " + (value8 || "N/A") + "\n") + ("➥ Description ➜ " + (value10 || "N/A") + "\n") + ("➥ URL        ➜ " + value7 + "\n") + ("➥ Powered By ➜ " + database.getBotSetting("botName") + "\n") + "┗━━━━━━━━━━━━━━━━";
      if (value11) {
        await value1.sendMessage(value5, {
          image: value11,
          caption: value13
        }, {
          quoted: value2
        });
      } else {
        await value1.sendMessage(value5, {
          text: value13
        }, {
          quoted: value2
        });
      }
      await value1.sendMessage(value5, {
        react: {
          text: "✅",
          key: value2.key
        }
      });
    } catch (error14) {
      console.error("❌ [WACHANNEL] Error:", error14.message);
      await value1.sendMessage(value5, {
        react: {
          text: "❌",
          key: value2.key
        }
      });
      await value1.sendMessage(value5, {
        text: "❌ *Channel Stalk Failed*\n\n⚠️ " + error14.message + "\n\n💡 Make sure you provide a valid WhatsApp channel URL."
      }, {
        quoted: value2
      });
    }
  }
};
