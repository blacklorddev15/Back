'use strict';

const {
  EventEmitter
} = require("events");
const axios = require("axios");
const {
  loadCommands
} = require("./commandLoader");
const DEFAULT_TIMEOUT_MS = Math.max(15000, Math.min(180000, Number(process.env.JUNE_DGNS_MEDIA_TIMEOUT_MS) || 90000));
const CHAT_JID = "media-diagnostic@s.whatsapp.net";
const TEST_QUERY = "Rick Astley Never Gonna Give You Up";
const YOUTUBE_URL = "https://www.youtube.com/watch?v=dQw4w9WgXcQ";
const MEDIA_FIXTURES = Object.freeze({
  facebook: () => process.env.JUNE_DGNS_FACEBOOK_URL || "https://www.facebook.com/watch/?v=10153231379946729",
  igs: () => process.env.JUNE_DGNS_INSTAGRAM_URL || "https://www.instagram.com/reel/Cx6p9q5P7qI/",
  igsc: () => process.env.JUNE_DGNS_INSTAGRAM_URL || "https://www.instagram.com/reel/Cx6p9q5P7qI/",
  instagram: () => process.env.JUNE_DGNS_INSTAGRAM_URL || "https://www.instagram.com/reel/Cx6p9q5P7qI/",
  lyrics: () => process.env.JUNE_DGNS_LYRICS_QUERY || TEST_QUERY,
  pinterest: () => process.env.JUNE_DGNS_PINTEREST_URL || "https://in.pinterest.com/pin/1109363320773690068/",
  play: () => process.env.JUNE_DGNS_YOUTUBE_QUERY || TEST_QUERY,
  play2: () => process.env.JUNE_DGNS_YOUTUBE_QUERY || TEST_QUERY,
  shazam: () => process.env.JUNE_DGNS_SHAZAM_QUERY || TEST_QUERY,
  soundcloud: () => process.env.JUNE_DGNS_SOUNDCLOUD_URL || "https://soundcloud.com/alanwalker/faded",
  spotify: () => process.env.JUNE_DGNS_SPOTIFY_QUERY || "Alan Walker Faded",
  spotify2: () => process.env.JUNE_DGNS_SPOTIFY_QUERY || "Alan Walker Faded",
  tiktok2: () => process.env.JUNE_DGNS_TIKTOK_URL || "https://www.tiktok.com/@scout2015/video/6718335390845095173",
  tt: () => process.env.JUNE_DGNS_TIKTOK_URL || "https://www.tiktok.com/@scout2015/video/6718335390845095173",
  twitter: () => process.env.JUNE_DGNS_TWITTER_URL || "https://x.com/SpaceX/status/1884633239926157752",
  ytvideo: () => process.env.JUNE_DGNS_YOUTUBE_URL || YOUTUBE_URL,
  video2: () => process.env.JUNE_DGNS_YOUTUBE_QUERY || TEST_QUERY,
  video3: () => process.env.JUNE_DGNS_YOUTUBE_QUERY || TEST_QUERY,
  ytsearch: () => process.env.JUNE_DGNS_YOUTUBE_QUERY || TEST_QUERY,
  snapchat: () => process.env.JUNE_DGNS_SNAPCHAT_URL || "",
  porn: () => process.env.JUNE_DGNS_PORN_INPUT || "",
  xvideos: () => process.env.JUNE_DGNS_XVIDEOS_INPUT || ""
});
const INTERACTIVE_STEPS = Object.freeze({
  spotify: ["number"],
  spotify2: ["sptrack_", "spfmt_"],
  soundcloud: ["scfmt_"],
  video2: ["video_"],
  twitter: ["tw_"]
});
function uniqueMediaCommands() {
  const value1 = new Map();
  for (const value2 of loadCommands().values()) {
    if (value2?.category === "media" && value2.name && !value1.has(value2.name)) {
      value1.set(value2.name, value2);
    }
  }
  return [...value1.values()].sort((value3, value4) => value3.name.localeCompare(value4.name));
}
function delay(value5) {
  return new Promise(value6 => setTimeout(value6, value5));
}
function withTimeout(value7, value8) {
  let value9;
  return Promise.race([Promise.resolve(value7), new Promise((value10, value11) => {
    value9 = setTimeout(() => {
      const value12 = new Error("Diagnostic exceeded " + Math.ceil(value8 / 1000) + "s timeout");
      value12.code = "DGNS_TIMEOUT";
      value11(value12);
    }, value8);
    value9.unref?.();
  })]).finally(() => clearTimeout(value9));
}
function truncate(value13, value14 = 180) {
  const value15 = String(value13 || "").replace(/\s+/g, " ").trim();
  if (value15.length > value14) {
    return value15.slice(0, value14 - 1) + "…";
  } else {
    return value15;
  }
}
function firstText(value16) {
  return value16?.text || value16?.caption || value16?.conversation || "";
}
function isFailureText(value17) {
  return /(?:^|\s)(?:❌|🚫|error|failed|failure|invalid|unsupported|timed out|timeout|no (?:media|video|results?|download|downloadable)|cannot|could not)/i.test(String(value17 || ""));
}
function collectStrings(value18, value19 = []) {
  if (typeof value18 === "string") {
    value19.push(value18);
  } else if (Array.isArray(value18)) {
    value18.forEach(value20 => collectStrings(value20, value19));
  } else if (value18 && typeof value18 === "object") {
    Object.values(value18).forEach(value21 => collectStrings(value21, value19));
  }
  return value19;
}
function mediaKind(value22) {
  for (const value23 of ["audio", "video", "image", "document", "sticker"]) {
    if (value22?.[value23]) {
      return value23;
    }
  }
  return null;
}
function makeMessage(value24, value25, value26) {
  const value27 = value26?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  return {
    key: {
      id: value24,
      remoteJid: CHAT_JID,
      fromMe: false,
      participant: CHAT_JID
    },
    message: {
      conversation: value25,
      ...(value27 ? {
        extendedTextMessage: {
          text: value25,
          contextInfo: value26.message.extendedTextMessage.contextInfo
        }
      } : {})
    }
  };
}
function makeCaptureSocket() {
  const value28 = new EventEmitter();
  const value29 = [];
  return {
    ev: value28,
    sent: value29,
    user: {
      id: CHAT_JID
    },
    async sendMessage(value30, value31, value32) {
      value29.push({
        jid: value30,
        content: value31 || {},
        options: value32 || {},
        at: Date.now()
      });
      return {
        key: {
          id: "DGNS-OUT-" + value29.length,
          remoteJid: value30,
          fromMe: true
        }
      };
    },
    async updateMediaMessage() {
      return null;
    }
  };
}
function axiosTrace() {
  const value33 = [];
  const value34 = axios.interceptors.response.use(value35 => {
    value33.push({
      ok: true,
      url: value35.config?.url,
      status: value35.status
    });
    return value35;
  });
  const value36 = axios.interceptors.response.use(undefined, value37 => {
    value33.push({
      ok: false,
      url: value37.config?.url,
      status: value37.response?.status || null,
      message: value37.message
    });
    return Promise.reject(value37);
  });
  return {
    events: value33,
    close() {
      axios.interceptors.response.eject(value34);
      axios.interceptors.response.eject(value36);
    }
  };
}
async function waitFor(value38, value39) {
  const value40 = Date.now();
  while (Date.now() - value40 < value39) {
    const value41 = value38();
    if (value41) {
      return value41;
    }
    await delay(80);
  }
  return null;
}
function selectionMessage(value42, value43) {
  return {
    key: {
      id: "DGNS-SELECT-" + Date.now(),
      remoteJid: CHAT_JID,
      fromMe: false,
      participant: CHAT_JID
    },
    message: {
      conversation: value43 === "1" ? "1" : undefined,
      interactiveResponseMessage: value43 === "1" ? undefined : {
        nativeFlowResponseMessage: {
          paramsJson: value43
        }
      }
    }
  };
}
async function runInteractiveSteps(value44, value45, value46) {
  if (value44 === "twitter") {
    let value47 = 0;
    const value48 = await waitFor(() => {
      const value49 = value45.sent.slice(value47).flatMap(value50 => collectStrings(value50.content));
      return value49.find(value51 => /tw_(?:item|vfmt|ifmt)_/.test(value51));
    }, Math.min(15000, Math.max(1000, value46 - Date.now())));
    if (!value48) {
      throw new Error("Selection UI did not provide a Twitter media option");
    }
    value47 = value45.sent.length;
    value45.ev.emit("messages.upsert", {
      messages: [selectionMessage("dgns-twitter-1", value48)]
    });
    if (value48.includes("tw_item_")) {
      const value52 = await waitFor(() => {
        const value53 = value45.sent.slice(value47).flatMap(value54 => collectStrings(value54.content));
        return value53.find(value55 => /tw_(?:vfmt|ifmt)_/.test(value55));
      }, Math.min(15000, Math.max(1000, value46 - Date.now())));
      if (!value52) {
        throw new Error("Twitter item selection did not provide a format option");
      }
      value45.ev.emit("messages.upsert", {
        messages: [selectionMessage("dgns-twitter-2", value52)]
      });
    }
    return;
  }
  const value56 = INTERACTIVE_STEPS[value44] || [];
  let value57 = 0;
  for (const value58 of value56) {
    const value59 = Math.max(1000, value46 - Date.now());
    let value60;
    if (value58 === "number") {
      value60 = "1";
      await delay(120);
    } else {
      value60 = await waitFor(() => {
        const value61 = value45.sent.slice(value57).flatMap(value62 => collectStrings(value62.content));
        return value61.find(value63 => value63.includes(value58));
      }, Math.min(15000, value59));
      if (!value60) {
        throw new Error("Selection UI did not provide " + value58);
      }
    }
    value57 = value45.sent.length;
    value45.ev.emit("messages.upsert", {
      messages: [selectionMessage("dgns-" + value44, value60)]
    });
    await delay(180);
  }
}
function classifyResult(value64, value65, value66, value67) {
  const value68 = value65.sent;
  const value69 = value68.map(value70 => mediaKind(value70.content)).find(Boolean);
  const value71 = value68.map(value72 => firstText(value72.content)).filter(Boolean);
  const value73 = [...value71].reverse().find(isFailureText);
  const value74 = [...value66.events].reverse().find(value75 => !value75.ok);
  if (value67?.code === "DGNS_TIMEOUT") {
    return {
      status: "timeout",
      stage: "Timeout",
      reason: value67.message
    };
  }
  if (value67) {
    const value76 = value67.response?.status || value74?.status;
    return {
      status: "failed",
      stage: value76 ? "API request" : "Command execution",
      reason: value76 ? "HTTP " + value76 + " — " + truncate(value67.message) : truncate(value67.message || value67)
    };
  }
  if (value73) {
    const value77 = value74?.status;
    return {
      status: "failed",
      stage: value77 ? "API request" : value66.events.length ? "API response / parsing" : "Command execution",
      reason: value77 ? "HTTP " + value77 + " — " + truncate(value73) : truncate(value73)
    };
  }
  if (value69) {
    return {
      status: "passed",
      stage: "Delivery prepared",
      reason: value69 + " output captured"
    };
  }
  if (value71.length || value68.some(value78 => collectStrings(value78.content).some(value79 => /(?:sptrack_|scfmt_|tw_|video_)/.test(value79)))) {
    return {
      status: "passed",
      stage: "API response",
      reason: "successful response captured"
    };
  }
  return {
    status: "failed",
    stage: "Command execution",
    reason: "Command completed without a success or error result"
  };
}
function quotedFixtureAvailable(value80, value81) {
  const value82 = value81?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  if (!value82) {
    return false;
  }
  if (value80 === "ptv") {
    return Boolean(value82.videoMessage);
  }
  if (value80 === "trim") {
    return Boolean(value82.audioMessage || value82.videoMessage);
  }
  return false;
}
async function runOne(value83, value84, value85) {
  const value86 = value83.name;
  const value87 = MEDIA_FIXTURES[value86];
  if ((value86 === "ptv" || value86 === "trim") && !quotedFixtureAvailable(value86, value84)) {
    return {
      name: value86,
      status: "skipped",
      stage: "Input",
      reason: "Reply to a WhatsApp video/audio when running .dgns MEDIA-CMD to test this command"
    };
  }
  const value88 = value87 ? value87() : "";
  if (!value88 && value86 !== "ptv" && value86 !== "trim") {
    return {
      name: value86,
      status: "skipped",
      stage: "Input",
      reason: "No deliberate safe diagnostic fixture is configured"
    };
  }
  const value89 = makeCaptureSocket();
  const value90 = axiosTrace();
  const value91 = "DGNS-" + value86 + "-" + Date.now() + "-" + Math.random().toString(16).slice(2);
  const value92 = makeMessage(value91, value88, value84);
  const value93 = {
    from: CHAT_JID,
    sender: CHAT_JID,
    prefix: ".",
    isOwner: true,
    isSudo: true,
    isMod: true,
    isGroup: false,
    quoted: value84?.message?.extendedTextMessage?.contextInfo?.quotedMessage,
    reply: value94 => value89.sendMessage(CHAT_JID, {
      text: value94
    }, {
      quoted: value92
    }),
    react: value95 => value89.sendMessage(CHAT_JID, {
      react: {
        text: value95,
        key: value92.key
      }
    })
  };
  const value96 = Date.now();
  let value97 = null;
  try {
    const value98 = value96 + value85;
    const value99 = value86 === "trim" ? ["0:00", "0:01"] : value88 ? value88.split(/\s+/) : [];
    await withTimeout(value83.execute(value89, value92, value99, value93), value85);
    await runInteractiveSteps(value86, value89, value98);
    if (INTERACTIVE_STEPS[value86]?.length) {
      await waitFor(() => value89.sent.some(value100 => mediaKind(value100.content) || isFailureText(firstText(value100.content))), Math.max(0, value98 - Date.now()));
    }
  } catch (error101) {
    value97 = error101;
  } finally {
    value90.close();
    value89.ev.removeAllListeners();
  }
  return {
    name: value86,
    inputType: /https?:\/\//.test(value88) ? "URL" : value88 ? "query" : "quoted media",
    durationMs: Date.now() - value96,
    ...classifyResult(value86, value89, value90, value97)
  };
}
async function runMediaDiagnostics(value102, value103 = {}) {
  const value104 = Math.max(15000, Math.min(180000, Number(value103.timeoutMs) || DEFAULT_TIMEOUT_MS));
  const value105 = uniqueMediaCommands();
  const value106 = [];
  for (const value107 of value105) {
    value106.push(await runOne(value107, value102, value104));
  }
  return value106;
}
function formatMediaReport(value108) {
  const value109 = value108.reduce((value110, value111) => {
    value110[value111.status] = (value110[value111.status] || 0) + 1;
    return value110;
  }, {
    passed: 0,
    failed: 0,
    timeout: 0,
    skipped: 0
  });
  const value112 = value109.passed + value109.failed + value109.timeout;
  const value113 = value112 ? Math.round(value109.passed / value112 * 100) : 0;
  const value114 = {
    passed: "✅",
    failed: "❌",
    timeout: "⏱️",
    skipped: "⚠️"
  };
  const value115 = ["🧪 *DGNS — MEDIA-CMD*", "━━━━━━━━━━━━━━━━━━━━"];
  value108.forEach((value116, value117) => {
    value115.push(String(value117 + 1).padStart(2, "0") + ". " + value114[value116.status] + " *" + value116.name + "*" + (value116.status === "passed" ? "" : " — " + truncate(value116.reason, 115)));
  });
  value115.push("━━━━━━━━━━━━━━━━━━━━", "📊 *FINAL RESULT*", "Tested: " + value112 + "/" + value108.length + "  •  ✅ " + value109.passed + "  ❌ " + value109.failed + "  ⏱️ " + value109.timeout + "  ⚠️ " + value109.skipped, "Success rate: " + value113 + "%");
  const value118 = value108.filter(value119 => value119.status === "failed" || value119.status === "timeout");
  if (value118.length) {
    value115.push("━━━━━━━━━━━━━━━━━━━━", "❌ *FAILED / TIMEOUT*");
    for (const value120 of value118) {
      value115.push("• *" + value120.name + "* — " + value120.stage + ": " + truncate(value120.reason, 150));
    }
  }
  const value121 = value108.filter(value122 => value122.status === "skipped");
  if (value121.length) {
    value115.push("━━━━━━━━━━━━━━━━━━━━", "⚠️ *SKIPPED*");
    for (const value123 of value121) {
      value115.push("• *" + value123.name + "* — " + truncate(value123.reason, 130));
    }
  }
  return value115.join("\n").slice(0, 6500);
}
module.exports = {
  runMediaDiagnostics: runMediaDiagnostics,
  formatMediaReport: formatMediaReport,
  MEDIA_FIXTURES: MEDIA_FIXTURES
};
