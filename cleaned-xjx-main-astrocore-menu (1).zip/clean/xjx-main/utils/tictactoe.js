class TicTacToe {
  constructor(value1, value2) {
    this.playerX = value1;
    this.playerO = value2;
    this.board = Array(9).fill(null);
    this.currentTurn = value1;
    this.turns = 0;
    this.winner = null;
  }
  turn(value3, value4) {
    if (this.winner) {
      return false;
    }
    if (this.board[value4]) {
      return false;
    }
    this.board[value4] = value3 ? "O" : "X";
    this.turns++;
    this.checkWinner();
    if (!this.winner && this.turns < 9) {
      this.currentTurn = value3 ? this.playerX : this.playerO;
    }
    return true;
  }
  checkWinner() {
    const value5 = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
    for (const value6 of value5) {
      const [value7, value8, value9] = value6;
      if (this.board[value7] && this.board[value7] === this.board[value8] && this.board[value7] === this.board[value9]) {
        this.winner = this.board[value7] === "X" ? this.playerX : this.playerO;
        return;
      }
    }
  }
  render() {
    return this.board.map((value10, value11) => {
      if (value10) {
        return value10;
      }
      return (value11 + 1).toString();
    });
  }
}
module.exports = TicTacToe;
