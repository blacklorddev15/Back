'use strict';

const COUNTRY_ZONES = require("./tzCountryMap.json");
const _isTz = value1 => {
  if (!value1 || typeof value1 !== "string") {
    return false;
  }
  try {
    new Intl.DateTimeFormat("en-US", {
      timeZone: value1
    }).format(new Date());
    return true;
  } catch (error2) {
    return false;
  }
};
let _parsePhoneNumber = null;
function numberToCountry(value3) {
  try {
    const value4 = String(value3 || "").replace(/\D/g, "");
    if (value4.length < 7) {
      return null;
    }
    if (!_parsePhoneNumber) {
      const value5 = require("awesome-phonenumber");
      _parsePhoneNumber = value5.parsePhoneNumber || value5;
    }
    const value6 = _parsePhoneNumber("+" + value4);
    const value7 = value6 && (value6.regionCode || value6.country);
    if (value7 && /^[A-Z]{2}$/.test(value7)) {
      return value7;
    } else {
      return null;
    }
  } catch (error8) {
    return null;
  }
}
function countryToZone(value9) {
  if (!value9) {
    return null;
  }
  const value10 = COUNTRY_ZONES[value9];
  if (Array.isArray(value10) && value10.length) {
    return value10[0];
  } else {
    return null;
  }
}
function zoneForNumber(value11) {
  const value12 = numberToCountry(value11);
  if (!value12) {
    return null;
  }
  const value13 = countryToZone(value12);
  if (value13) {
    return {
      zone: value13,
      country: value12
    };
  } else {
    return null;
  }
}
const asList = value14 => (Array.isArray(value14) ? value14 : [value14]).filter(Boolean);
function resolveTimeZone(value15 = {}) {
  const {
    storedTz: value16,
    envTz: value17,
    ownerNumber: value18,
    botNumber: value19,
    defaultTz: value20
  } = value15;
  if (_isTz(value16) && String(value16).toLowerCase() !== "auto") {
    return {
      tz: value16,
      source: "setting"
    };
  }
  if (_isTz(value17)) {
    return {
      tz: value17,
      source: "env"
    };
  }
  for (const value21 of asList(value18)) {
    const value22 = zoneForNumber(value21);
    if (value22) {
      return {
        tz: value22.zone,
        source: "auto:owner",
        country: value22.country
      };
    }
  }
  for (const value23 of asList(value19)) {
    const value24 = zoneForNumber(value23);
    if (value24) {
      return {
        tz: value24.zone,
        source: "auto:paired",
        country: value24.country
      };
    }
  }
  if (_isTz(value20)) {
    return {
      tz: value20,
      source: "default"
    };
  }
  return {
    tz: "UTC",
    source: "utc"
  };
}
module.exports = {
  resolveTimeZone: resolveTimeZone,
  zoneForNumber: zoneForNumber,
  numberToCountry: numberToCountry,
  countryToZone: countryToZone,
  _isTz: _isTz
};
