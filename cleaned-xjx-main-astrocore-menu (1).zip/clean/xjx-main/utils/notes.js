'use strict';

const fs = require("fs");
const path = require("path");
const NOTES_NS = "user_notes";
const MEDIA_NS = "user_notes_media";
const REMINDERS_NS = "note_reminders";
const REMINDERS_KEY = "pending";
const MAX_NOTES = 100;
const MAX_TEXT = 1000;
const MAX_MEDIA_NOTES = 20;
const MAX_MEDIA_BYTES = 5242880;
const PAGE_SIZE = 15;
const KIND_META = {
  image: {
    icon: "🖼️",
    label: "Image"
  },
  sticker: {
    icon: "🌟",
    label: "Sticker"
  },
  video: {
    icon: "🎬",
    label: "Video"
  },
  voice: {
    icon: "🎤",
    label: "Voice note"
  },
  audio: {
    icon: "🎵",
    label: "Audio"
  },
  document: {
    icon: "📄",
    label: "Document"
  }
};
const state = {
  db: null,
  sock: null,
  timer: null
};
function db() {
  if (state.db) {
    return state.db;
  }
  return require(path.join(global.__CORE__ || process.cwd(), "database"));
}
function mediaDir() {
  if (process.env.JUNE_NOTES_DIR) {
    return path.resolve(process.env.JUNE_NOTES_DIR);
  } else {
    return path.join(process.cwd(), "data", "notes");
  }
}
function getUserId(value1) {
  const value2 = value1 && value1.key && (value1.key.participant || value1.key.remoteJid) || "";
  return String(value2).split(":")[0].split("@")[0];
}
function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}
function loadNotes(value3) {
  const value4 = db().getKV(NOTES_NS, value3, []);
  if (Array.isArray(value4)) {
    return value4.filter(Boolean);
  } else {
    return [];
  }
}
function saveNotes(value5, value6) {
  db().setKV(NOTES_NS, value5, value6);
}
function parseTags(value7) {
  const value8 = String(value7 || "").match(/#[a-zA-Z0-9_-]{1,24}/g) || [];
  return [...new Set(value8.map(value9 => value9.toLowerCase()))];
}
function fmtTimestamp(value10) {
  try {
    return new Date(value10).toLocaleString("en-GB", {
      day: "2-digit",
      month: "short",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch (error11) {
    return "";
  }
}
function parseTimeSpec(value12) {
  const value13 = String(value12 || "").trim().match(/^(\d{1,4})(s|m|h|d)?$/i);
  if (!value13) {
    return null;
  }
  const value14 = Number(value13[1]);
  if (!Number.isFinite(value14) || value14 <= 0) {
    return null;
  }
  const value15 = (value13[2] || "m").toLowerCase();
  const value16 = {
    s: 1000,
    m: 60000,
    h: 3600000,
    d: 86400000
  }[value15];
  return value14 * value16;
}
function describeDueAt(value17) {
  const value18 = value17 - Date.now();
  if (value18 <= 0) {
    return "now";
  }
  const value19 = Math.round(value18 / 60000);
  if (value19 < 60) {
    return value19 + " min";
  }
  const value20 = Math.round(value19 / 60);
  if (value20 < 48) {
    return value20 + " hr";
  }
  return Math.round(value20 / 24) + " days";
}
function mediaFile(value21, value22, value23) {
  return path.join(mediaDir(), String(value21), value22.id + "." + (value23 || "bin"));
}
function saveMediaNote({
  userId: value24,
  buffer: value25,
  kind: value26,
  mime: value27,
  filename: value28,
  caption: value29,
  savedAt = Date.now()
}) {
  if (!KIND_META[value26]) {
    return {
      error: "Unsupported media type: " + value26
    };
  }
  if (!Buffer.isBuffer(value25) || value25.length === 0) {
    return {
      error: "Empty media"
    };
  }
  if (value25.length > MAX_MEDIA_BYTES) {
    return {
      error: "Media too large (" + (value25.length / 1048576).toFixed(1) + "MB) — the limit is " + MAX_MEDIA_BYTES / 1048576 + "MB per media note"
    };
  }
  const value30 = loadNotes(value24);
  if (value30.length >= MAX_NOTES) {
    return {
      error: "You already have " + MAX_NOTES + " notes. Delete some via .mynotes first."
    };
  }
  if (value30.filter(value31 => value31.type && value31.type !== "text").length >= MAX_MEDIA_NOTES) {
    return {
      error: "You already have " + MAX_MEDIA_NOTES + " media notes. Delete some via .mynotes first."
    };
  }
  const value32 = {
    id: newId(),
    type: value26,
    mime: value27 || "application/octet-stream",
    filename: value28 || null,
    caption: String(value29 || "").slice(0, MAX_TEXT) || null,
    size: value25.length,
    tags: parseTags(value29 || ""),
    savedAt: savedAt
  };
  try {
    fs.mkdirSync(path.join(mediaDir(), String(value24)), {
      recursive: true
    });
    fs.writeFileSync(mediaFile(value24, value32, extFor(value32)), value25);
  } catch (error33) {}
  try {
    db().setKV(MEDIA_NS, value24 + ":" + value32.id, {
      kind: value26,
      mime: value32.mime,
      filename: value32.filename,
      b64: value25.toString("base64")
    });
  } catch (error34) {}
  value30.push(value32);
  saveNotes(value24, value30);
  return {
    note: value32,
    index: value30.length
  };
}
function extFor(value35) {
  const value36 = String(value35.mime || "");
  const value37 = {
    "image/jpeg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "video/mp4": "mp4",
    "audio/ogg": "ogg",
    "audio/mpeg": "mp3",
    "audio/mp4": "m4a",
    "application/pdf": "pdf"
  };
  if (value37[value36]) {
    return value37[value36];
  }
  if (value35.filename && /\.[a-zA-Z0-9]{1,8}$/.test(value35.filename)) {
    return value35.filename.split(".").pop();
  }
  return "bin";
}
function getMedia(value38, value39) {
  if (!value39 || value39.type === "text" || !value39.id) {
    return null;
  }
  const value40 = mediaFile(value38, value39, extFor(value39));
  try {
    if (fs.existsSync(value40)) {
      return fs.readFileSync(value40);
    }
  } catch (error41) {}
  try {
    const value42 = db().getKV(MEDIA_NS, value38 + ":" + value39.id, null);
    if (value42 && value42.b64) {
      const value43 = Buffer.from(value42.b64, "base64");
      try {
        fs.mkdirSync(path.join(mediaDir(), String(value38)), {
          recursive: true
        });
        fs.writeFileSync(value40, value43);
      } catch (error44) {}
      return value43;
    }
  } catch (error45) {}
  return null;
}
function deleteMedia(value46, value47) {
  if (!value47 || value47.type === "text" || !value47.id) {
    return;
  }
  try {
    if (fs.existsSync(mediaFile(value46, value47, extFor(value47)))) {
      fs.rmSync(mediaFile(value46, value47, extFor(value47)), {
        force: true
      });
    }
  } catch (error48) {}
  try {
    db().delKV(MEDIA_NS, value46 + ":" + value47.id);
  } catch (error49) {}
}
function deleteAllMedia(value50) {
  for (const value51 of loadNotes(value50)) {
    deleteMedia(value50, value51);
  }
}
function noteIcon(value52) {
  if (value52.type && value52.type !== "text" && KIND_META[value52.type]) {
    return KIND_META[value52.type].icon;
  } else {
    return "📝";
  }
}
function noteText(value53) {
  const value54 = !value53.type || value53.type === "text";
  if (value54) {
    return value53.text;
  } else {
    return value53.caption || "";
  }
}
function matchesQuery(value55, value56) {
  const value57 = String(value56 || "").toLowerCase();
  if (!value57) {
    return false;
  }
  return noteText(value55).toLowerCase().includes(value57) || (value55.filename || "").toLowerCase().includes(value57) || (value55.tags || []).some(value58 => value58.includes(value57));
}
function matchesTag(value59, value60) {
  const value61 = String(value60 || "").toLowerCase();
  return (value59.tags || []).includes(value61);
}
function paginate(value62, value63) {
  const value64 = value62.length;
  const value65 = Math.max(1, Math.ceil(value64 / PAGE_SIZE));
  const value66 = Math.min(Math.max(1, value63 || 1), value65);
  return {
    slice: value62.slice((value66 - 1) * PAGE_SIZE, value66 * PAGE_SIZE),
    page: value66,
    pages: value65,
    total: value64
  };
}
function renderLine(value67, value68) {
  const value69 = value67.savedAt ? fmtTimestamp(value67.savedAt) : "";
  const value70 = value67.tags && value67.tags.length ? " " + value67.tags.join(" ") : "";
  const value71 = value67.type && value67.type !== "text" ? " _(" + KIND_META[value67.type].label + (value67.filename ? ": " + value67.filename : "") + ")_" : "";
  return "➥ *" + value68 + ".* " + noteIcon(value67) + " " + (noteText(value67) || "") + value71 + (value69 ? "  _[" + value69 + "]_" : "") + value70;
}
function buildExportText(value72, value73) {
  const value74 = ["📝 Notes export — " + value73.length + " note(s)", "👤 User " + value72, "📅 " + fmtTimestamp(Date.now()), ""];
  value73.forEach((value75, value76) => {
    const value77 = value75.type && value75.type !== "text" ? "[" + KIND_META[value75.type].label + (value75.filename ? ": " + value75.filename : "") + "] " : "";
    value74.push(value76 + 1 + ". " + value77 + noteText(value75) + (value75.savedAt ? "  (" + fmtTimestamp(value75.savedAt) + ")" : ""));
  });
  return value74.join("\n");
}
function loadReminders() {
  const value78 = db().getKV(REMINDERS_NS, REMINDERS_KEY, []);
  if (Array.isArray(value78)) {
    return value78.filter(Boolean);
  } else {
    return [];
  }
}
function saveReminders(value79) {
  db().setKV(REMINDERS_NS, REMINDERS_KEY, value79);
}
function addReminder({
  userId: value80,
  userJid: value81,
  noteId: value82,
  dueAt: value83,
  noteRef: value84
}) {
  const value85 = loadReminders();
  const value86 = {
    id: newId(),
    userId: value80,
    userJid: value81 || value80 + "@s.whatsapp.net",
    noteId: value82,
    dueAt: value83,
    createdAt: Date.now(),
    text: value84 ? noteText(value84) : "",
    type: value84 ? value84.type : "text"
  };
  value85.push(value86);
  saveReminders(value85);
  ensureTimer();
  return value86;
}
function cancelReminder(value87) {
  const value88 = loadReminders();
  const value89 = value88.filter(value90 => value90.id !== value87);
  saveReminders(value89);
  return value89.length !== value88.length;
}
async function scanReminders() {
  const value91 = Date.now();
  const value92 = loadReminders();
  const value93 = value92.filter(value94 => value94.dueAt <= value91);
  if (!value93.length) {
    return 0;
  }
  saveReminders(value92.filter(value95 => value95.dueAt > value91));
  for (const value96 of value93) {
    try {
      const value97 = loadNotes(value96.userId);
      const value98 = value97.find(value99 => value99.id === value96.noteId);
      const value100 = value98 ? noteText(value98) : value96.text;
      const value101 = value98 && value98.type && value98.type !== "text" ? KIND_META[value98.type].label : null;
      let value102 = "⏰ *Note reminder*\n\n" + noteIcon(value98 || value96) + " " + (value100 || "(empty note)");
      if (value101) {
        value102 += "\n\n_" + value101 + " attached below._";
      }
      if (state.sock) {
        await state.sock.sendMessage(value96.userJid, {
          text: value102
        });
        if (value98 && value98.type && value98.type !== "text") {
          const value103 = getMedia(value96.userId, value98);
          if (value103) {
            await sendMediaByKind(state.sock, value96.userJid, value98, value103);
          }
        }
      }
    } catch (error104) {}
  }
  return value93.length;
}
function sendMediaByKind(value105, value106, value107, value108) {
  const value109 = {
    caption: value107.caption || undefined
  };
  switch (value107.type) {
    case "image":
      return value105.sendMessage(value106, {
        ...value109,
        image: value108,
        mimetype: value107.mime
      });
    case "sticker":
      return value105.sendMessage(value106, {
        sticker: value108,
        mimetype: value107.mime
      });
    case "video":
      return value105.sendMessage(value106, {
        ...value109,
        video: value108,
        mimetype: value107.mime,
        ptv: value107.ptv || undefined
      });
    case "voice":
      return value105.sendMessage(value106, {
        audio: value108,
        ptt: true,
        mimetype: value107.mime || "audio/ogg; codecs=opus"
      });
    case "audio":
      return value105.sendMessage(value106, {
        audio: value108,
        mimetype: value107.mime
      });
    default:
      return value105.sendMessage(value106, {
        document: value108,
        mimetype: value107.mime,
        fileName: value107.filename || "note"
      });
  }
}
function ensureTimer() {
  if (state.timer) {
    return;
  }
  state.timer = setInterval(() => {
    scanReminders().catch(() => {});
  }, 30000);
  if (global._activeIntervals) {
    global._activeIntervals.push(state.timer);
  }
}
function onBotConnected(value110) {
  if (value110) {
    state.sock = value110;
  }
  if (loadReminders().length) {
    ensureTimer();
  }
  return true;
}
module.exports = {
  MAX_NOTES: MAX_NOTES,
  MAX_TEXT: MAX_TEXT,
  MAX_MEDIA_NOTES: MAX_MEDIA_NOTES,
  MAX_MEDIA_BYTES: MAX_MEDIA_BYTES,
  PAGE_SIZE: PAGE_SIZE,
  KIND_META: KIND_META,
  NOTES_NS: NOTES_NS,
  MEDIA_NS: MEDIA_NS,
  getUserId: getUserId,
  newId: newId,
  loadNotes: loadNotes,
  saveNotes: saveNotes,
  saveMediaNote: saveMediaNote,
  getMedia: getMedia,
  deleteMedia: deleteMedia,
  deleteAllMedia: deleteAllMedia,
  sendMediaByKind: sendMediaByKind,
  parseTags: parseTags,
  fmtTimestamp: fmtTimestamp,
  parseTimeSpec: parseTimeSpec,
  describeDueAt: describeDueAt,
  noteIcon: noteIcon,
  noteText: noteText,
  matchesQuery: matchesQuery,
  matchesTag: matchesTag,
  paginate: paginate,
  renderLine: renderLine,
  buildExportText: buildExportText,
  addReminder: addReminder,
  cancelReminder: cancelReminder,
  scanReminders: scanReminders,
  onBotConnected: onBotConnected,
  __test: {
    state: state,
    setDatabase: value111 => {
      state.db = value111;
    },
    reset: () => {
      if (state.timer) {
        clearInterval(state.timer);
      }
      state.timer = null;
      state.sock = null;
      state.db = null;
    }
  }
};
