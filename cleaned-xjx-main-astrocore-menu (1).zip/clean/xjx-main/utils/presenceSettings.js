const db = require("../database");
const KEY_PM = "presencePm";
const KEY_GROUP = "presenceGroup";
const KEY_LEGACY = "presenceMode";
const VALID = new Set(["off", "typing", "recording", "recordtype"]);
const LABELS = {
  off: "off",
  typing: "⌨️ typing",
  recording: "🎙️ recording",
  recordtype: "🎙️⌨️ record+type"
};
const isSet = value1 => value1 !== undefined && value1 !== null && value1 !== "";
const normalize = value2 => VALID.has(value2) ? value2 : "off";
function ensureMigrated() {
  if (isSet(db.getBotSetting(KEY_PM)) || isSet(db.getBotSetting(KEY_GROUP))) {
    return;
  }
  const value3 = db.getBotSetting(KEY_LEGACY);
  if (!isSet(value3)) {
    return;
  }
  const value4 = normalize(value3);
  try {
    db.setBotSetting(KEY_PM, value4);
  } catch (error5) {}
  try {
    db.setBotSetting(KEY_GROUP, value4);
  } catch (error6) {}
}
function getModes() {
  ensureMigrated();
  return {
    pm: normalize(db.getBotSetting(KEY_PM)),
    group: normalize(db.getBotSetting(KEY_GROUP))
  };
}
function getModeFor(value7) {
  const {
    pm: value8,
    group: value9
  } = getModes();
  if (value7 && String(value7).endsWith("@g.us")) {
    return value9;
  } else {
    return value8;
  }
}
function setPmMode(value10) {
  try {
    db.setBotSetting(KEY_PM, normalize(value10));
  } catch (error11) {}
}
function setGroupMode(value12) {
  try {
    db.setBotSetting(KEY_GROUP, normalize(value12));
  } catch (error13) {}
}
function getMode() {
  const {
    pm: value14,
    group: value15
  } = getModes();
  if (value15 !== "off") {
    return value15;
  } else {
    return value14;
  }
}
function setMode(value16) {
  const value17 = normalize(value16);
  setPmMode(value17);
  setGroupMode(value17);
}
function labelOf(value18) {
  return LABELS[value18] || value18 || "off";
}
async function runPresenceCommand({
  name: value19,
  mode: value20,
  args: value21,
  extra: value22,
  emoji: value23,
  label: value24
}) {
  const value25 = (value21 || []).map(value26 => String(value26).toLowerCase());
  const value27 = value25[0];
  const value28 = getModes();
  if (!value27) {
    return value22.reply(value23 + " *" + value24 + "*\n\n" + ("📱 PM       : " + labelOf(value28.pm) + "\n") + ("👥 Group    : " + labelOf(value28.group) + "\n\n") + "Usage:\n" + ("• ." + value19 + " pm     → PM only\n") + ("• ." + value19 + " gc     → Groups only\n") + ("• ." + value19 + " all    → PM + Groups\n") + ("• ." + value19 + " off    → Disable\n") + "_(aliases: dms = pm, group = gc)_");
  }
  let value29;
  let value30;
  let value31;
  if (value27 === "off") {
    value29 = "off";
    value30 = "off";
    value31 = "everywhere";
  } else if (value27 === "all") {
    value29 = value20;
    value30 = value20;
    value31 = "PM + Groups";
  } else if (value27 === "pm" || value27 === "dms") {
    value29 = value20;
    value30 = "off";
    value31 = "PM only";
  } else if (value27 === "group" || value27 === "gc") {
    value30 = value20;
    value29 = "off";
    value31 = "Groups only";
  } else {
    return value22.reply("⚠️ Usage: ." + value19 + " pm|gc|all|off");
  }
  setPmMode(value29);
  setGroupMode(value30);
  if (value27 === "off") {
    return value22.reply(value23 + " *" + value24 + "* disabled " + value31 + ".");
  }
  return value22.reply(value23 + " *" + value24 + "* enabled for *" + value31 + "* (" + labelOf(value20) + ").");
}
module.exports = {
  getModes: getModes,
  getModeFor: getModeFor,
  setPmMode: setPmMode,
  setGroupMode: setGroupMode,
  getMode: getMode,
  setMode: setMode,
  runPresenceCommand: runPresenceCommand,
  labelOf: labelOf
};
