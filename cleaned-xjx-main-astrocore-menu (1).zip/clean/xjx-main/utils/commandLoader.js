const fs = require("fs");
const path = require("path");
const COMMANDS_PATH = path.join(__dirname, "..", "commands");
const SCRIPT_EXT = ".js";
function listCategories() {
  if (!fs.existsSync(COMMANDS_PATH)) {
    return [];
  }
  return fs.readdirSync(COMMANDS_PATH);
}
function clearCommandCache() {
  const value1 = COMMANDS_PATH;
  for (const value2 of Object.keys(require.cache)) {
    if (value2.startsWith(value1) && value2.endsWith(SCRIPT_EXT)) {
      delete require.cache[value2];
    }
  }
}
function loadCommands() {
  const value3 = new Map();
  const value4 = COMMANDS_PATH;
  if (!fs.existsSync(value4)) {
    console.log("Commands directory not found");
    return value3;
  }
  const value5 = fs.readdirSync(value4);
  value5.forEach(value6 => {
    const value7 = path.join(value4, value6);
    let value8;
    try {
      value8 = fs.statSync(value7);
    } catch (error9) {
      return;
    }
    if (value8.isDirectory()) {
      let value10 = [];
      try {
        value10 = fs.readdirSync(value7).filter(value11 => value11.endsWith(SCRIPT_EXT));
      } catch (error12) {
        return;
      }
      value10.forEach(value13 => {
        const value14 = path.join(value7, value13);
        try {
          const value15 = require(value14);
          const value16 = Array.isArray(value15) ? value15 : [value15];
          value16.forEach(value17 => {
            if (value17 && value17.name) {
              value17.category = value6;
              const value18 = value3.get(value17.name);
              if (value18 && value18.name === value17.name) {
                console.warn("[ COMMANDS ] Duplicate name \"" + value17.name + "\": " + (value6 + "/" + value13 + " overrides " + (value18.__source || "earlier command")));
              }
              value17.__source = value6 + "/" + value13;
              value3.set(value17.name, value17);
              if (value17.aliases) {
                value17.aliases.forEach(value19 => {
                  const value20 = value3.get(value19);
                  if (value20 === value17) {
                    return;
                  }
                  if (value20 && value20.name === value19) {
                    console.warn("[ COMMANDS ] Alias \"" + value19 + "\" of " + value6 + "/" + value13 + " " + ("shadows the real command \"" + value19 + "\" (" + value20.__source + ") — alias skipped"));
                    return;
                  }
                  value3.set(value19, value17);
                });
              }
            }
          });
        } catch (error21) {
          console.error("Error loading command " + value13 + ":", error21.message);
        }
      });
    }
  });
  let value22 = 0;
  let value23 = 0;
  for (const [value24, value25] of value3) {
    if (value24 === value25.name) {
      value22++;
    } else {
      value23++;
    }
  }
  Object.defineProperty(value3, "commandCount", {
    value: value22,
    enumerable: false
  });
  Object.defineProperty(value3, "aliasCount", {
    value: value23,
    enumerable: false
  });
  return value3;
}
function reloadCommands() {
  clearCommandCache();
  return loadCommands();
}
function watchCommands(value26, value27 = {}) {
  const value28 = typeof value27.debounceMs === "number" ? value27.debounceMs : 250;
  let value29 = null;
  let value30 = null;
  const value31 = value32 => {
    try {
      const value33 = reloadCommands();
      if (typeof value26 === "function") {
        value26(value33);
      }
      console.log("[ COMMANDS ] Hot-reloaded " + value33.size + " command" + (value33.size === 1 ? "" : "s") + " " + ("(changed: " + value32 + ")"));
    } catch (error34) {
      console.error("[ COMMANDS ] Hot-reload failed:", error34.message);
    }
  };
  const value35 = value36 => {
    if (value29) {
      clearTimeout(value29);
    }
    value29 = setTimeout(() => value31(value36), value28);
  };
  try {
    value30 = fs.watch(COMMANDS_PATH, {
      recursive: true
    }, (value37, value38) => {
      if (!value38) {
        return;
      }
      const value39 = String(value38);
      if (!value39.endsWith(SCRIPT_EXT)) {
        return;
      }
      const value40 = value39.toLowerCase();
      if (value40.includes(".obfuscated.") || value40.includes(".backup")) {
        return;
      }
      value35(value39);
    });
  } catch (error41) {
    console.warn("[ COMMANDS ] Recursive watch unavailable, falling back to per-folder watch:", error41.message);
    const value42 = [];
    for (const value43 of listCategories()) {
      const value44 = path.join(COMMANDS_PATH, value43);
      try {
        const value45 = fs.watch(value44, (value46, value47) => {
          const value48 = String(value47 || "");
          if (value48.endsWith(SCRIPT_EXT)) {
            value35(value43 + "/" + value48);
          }
        });
        value42.push(value45);
      } catch (error49) {}
    }
    return {
      close() {
        if (value29) {
          clearTimeout(value29);
        }
        for (const value50 of value42) {
          try {
            value50.close();
          } catch (error51) {}
        }
      }
    };
  }
  value30.on("error", value52 => {
    console.error("[ COMMANDS ] Watcher error:", value52.message);
  });
  return {
    close() {
      if (value29) {
        clearTimeout(value29);
      }
      if (value30) {
        try {
          value30.close();
        } catch (error53) {}
      }
    }
  };
}
module.exports = {
  loadCommands: loadCommands,
  watchCommands: watchCommands,
  reloadCommands: reloadCommands,
  clearCommandCache: clearCommandCache
};
