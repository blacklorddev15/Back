const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const webp = require("node-webpmux");
const {
  getTempDir,
  deleteTempFile
} = require("./tempManager");
const MAX_FILE_SIZE = 52428800;
async function writeExifImg(value1, value2) {
  const {
    packname: value3
  } = value2;
  const value4 = new webp.Image();
  await value4.load(value1);
  const value5 = {
    "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
    "sticker-pack-name": value3 || "Knight Bot",
    emojis: ["🤖"]
  };
  const value6 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
  const value7 = Buffer.from(JSON.stringify(value5), "utf8");
  const value8 = Buffer.concat([value6, value7]);
  value8.writeUIntLE(value7.length, 14, 4);
  value4.exif = value8;
  return await value4.save(null);
}
async function writeExifVid(value9, value10) {
  const {
    packname: value11
  } = value10;
  const value12 = require("./ffmpegPath");
  const {
    spawn: value13
  } = require("child_process");
  if (value9.length > MAX_FILE_SIZE) {
    throw new Error("File too large: " + (value9.length / 1024 / 1024).toFixed(2) + "MB (max: " + MAX_FILE_SIZE / 1024 / 1024 + "MB)");
  }
  const value14 = getTempDir();
  const value15 = path.join(value14, "input_" + Date.now() + ".mp4");
  const value16 = path.join(value14, "output_" + Date.now() + ".webp");
  const value17 = [value15, value16];
  try {
    fs.writeFileSync(value15, value9);
    await new Promise((value18, value19) => {
      const value20 = value13(value12(), ["-y", "-i", value15, "-vf", "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000", "-c:v", "libwebp", "-preset", "default", "-loop", "0", "-vsync", "0", "-pix_fmt", "yuva420p", "-quality", "75", "-compression_level", "6", value16]);
      const value21 = [];
      value20.stderr.on("data", value22 => value21.push(value22));
      value20.on("error", value19);
      value20.on("close", value23 => {
        if (value23 === 0) {
          return value18();
        }
        value19(new Error(Buffer.concat(value21).toString() || "ffmpeg exited with code " + value23));
      });
    });
    const value24 = fs.readFileSync(value16);
    const value25 = new webp.Image();
    await value25.load(value24);
    const value26 = {
      "sticker-pack-id": crypto.randomBytes(32).toString("hex"),
      "sticker-pack-name": value11 || "Knight Bot",
      emojis: ["🤖"]
    };
    const value27 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
    const value28 = Buffer.from(JSON.stringify(value26), "utf8");
    const value29 = Buffer.concat([value27, value28]);
    value29.writeUIntLE(value28.length, 14, 4);
    value25.exif = value29;
    const value30 = await value25.save(null);
    return value30;
  } catch (error31) {
    throw error31;
  } finally {
    value17.forEach(value32 => deleteTempFile(value32));
  }
}
module.exports = {
  writeExifImg: writeExifImg,
  writeExifVid: writeExifVid
};
