'use strict';

const fs = require("fs");
const path = require("path");
const os = require("os");
const {
  execFileSync
} = require("child_process");
const {
  Readable
} = require("stream");
const FFMPEG_RELEASE_BASE = "https://github.com/iqbal-rashed/ytdlp-nodejs/releases/download/ffmpeg-latest";
const ASSET_BY_PLATFORM = {
  "linux-x64": "linux-x64-ffmpeg",
  "linux-arm64": "linux-arm64-ffmpeg",
  "darwin-x64": "macos-x64-ffmpeg",
  "darwin-arm64": "macos-arm64-ffmpeg",
  "win32-x64": "win-x64-ffmpeg.exe",
  "win32-ia32": "win-ia32-ffmpeg.exe"
};
const CACHE_DIR = path.join(__dirname, "..", "data", "ffmpeg");
const CACHE_BIN = path.join(CACHE_DIR, "ffmpeg");
const LOCK_FILE = path.join(CACHE_DIR, ".downloading");
function platformAsset() {
  return ASSET_BY_PLATFORM[process.platform + "-" + process.arch] || null;
}
function cacheIsValid() {
  try {
    if (!fs.existsSync(CACHE_BIN)) {
      return false;
    }
    execFileSync(CACHE_BIN, ["-version"], {
      timeout: 10000,
      stdio: "pipe"
    });
    return true;
  } catch (error1) {
    return false;
  }
}
function isDownloadInFlight() {
  try {
    const value2 = fs.readFileSync(LOCK_FILE, "utf8");
    const value3 = Number(value2.trim());
    return Number.isFinite(value3) && Date.now() - value3 < 1800000;
  } catch (error4) {
    return false;
  }
}
async function ensureFfmpegRuntime({
  log = console.log,
  warn = console.log
} = {}) {
  try {
    if (cacheIsValid()) {
      log("[ BOOT ] ffmpeg runtime cache ready: " + CACHE_BIN);
      return true;
    }
    const value5 = platformAsset();
    if (!value5) {
      warn("[ BOOT ] ffmpeg runtime: no static build for " + process.platform + "-" + process.arch + "; skipping provision.");
      return false;
    }
    if (isDownloadInFlight()) {
      log("[ BOOT ] ffmpeg runtime: download already in progress; skipping.");
      return false;
    }
    fs.mkdirSync(CACHE_DIR, {
      recursive: true
    });
    try {
      fs.writeFileSync(LOCK_FILE, String(Date.now()), {
        flag: "wx"
      });
    } catch (error6) {
      return false;
    }
    const value7 = FFMPEG_RELEASE_BASE + "/" + value5;
    log("[ BOOT ] ffmpeg runtime: no system ffmpeg — downloading " + value5 + " (~190MB) in background…");
    const value8 = path.join(CACHE_DIR, "ffmpeg.downloading");
    try {
      const value9 = await fetch(value7, {
        signal: AbortSignal.timeout(600000)
      });
      if (!value9.ok || !value9.body) {
        throw new Error("download failed: HTTP " + value9.status);
      }
      const value10 = await new Promise((value11, value12) => {
        const value13 = fs.createWriteStream(value8);
        const value14 = Readable.fromWeb(value9.body);
        let value15 = 0;
        const value16 = Date.now();
        let value17 = 0;
        value14.on("data", value18 => {
          value15 += value18.length;
          const value19 = Date.now();
          if (value19 - value17 > 10000) {
            value17 = value19;
            log("[ BOOT ] ffmpeg runtime: " + (value15 / 1048576).toFixed(0) + "MB downloaded…");
          }
        });
        value14.pipe(value13);
        value13.on("finish", () => value13.close(() => value11(value15)));
        value13.on("error", value12);
        value14.on("error", value12);
      });
      fs.chmodSync(value8, 493);
      execFileSync(value8, ["-version"], {
        timeout: 10000,
        stdio: "pipe"
      });
      fs.renameSync(value8, CACHE_BIN);
      log("[ BOOT ] ffmpeg runtime: ready at " + CACHE_BIN + " (" + (value10 / 1048576).toFixed(0) + "MB) — used from the next boot; conversions meanwhile use the fallback binary.");
      return true;
    } catch (error20) {
      try {
        fs.unlinkSync(value8);
      } catch (error21) {}
      warn("[ BOOT ] ffmpeg runtime: provisioning failed (" + error20.message + ") — falling back to ffmpeg-static/bare ffmpeg.");
      return false;
    } finally {
      try {
        fs.unlinkSync(LOCK_FILE);
      } catch (error22) {}
    }
  } catch (error23) {
    warn("[ BOOT ] ffmpeg runtime: unexpected error (" + error23.message + ") — continuing without it.");
    return false;
  }
}
module.exports = {
  ensureFfmpegRuntime: ensureFfmpegRuntime,
  cacheIsValid: cacheIsValid,
  CACHE_BIN: CACHE_BIN
};
