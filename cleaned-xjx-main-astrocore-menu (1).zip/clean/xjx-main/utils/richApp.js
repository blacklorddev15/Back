'use strict';

const {
  randomUUID
} = require("crypto");
const {
  generateWAMessageFromContent
} = require("@whiskeysockets/baileys");
function buildRichMessage(value1, value2) {
  const value3 = Buffer.from(JSON.stringify({
    __typename: "GenAIUnifiedResponse",
    response_id: randomUUID(),
    sections: [{
      __typename: "GenAIUnifiedResponseSection",
      view_model: {
        __typename: "GenAISingleLayoutViewModel",
        primitive: {
          __typename: "FOAHtmlPrimitiveDemoDONOTUSE",
          trusted_sources: [],
          payload: String(value2).trim()
        }
      }
    }]
  })).toString("base64");
  return generateWAMessageFromContent(value1, {
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          unifiedResponse: {
            data: value3
          },
          contextInfo: {
            isForwarded: true,
            forwardOrigin: 4
          }
        }
      }
    }
  }, {});
}
async function sendRichApp(value4, value5, value6, value7) {
  const value8 = value7 || value5.key.remoteJid;
  let value9 = value8;
  let value10 = buildRichMessage(value9, value6);
  try {
    await value4.relayMessage(value9, value10.message, {
      messageId: value10.key.id
    });
    return true;
  } catch (error11) {
    const value12 = value5.key.remoteJidAlt;
    if (!value12 || value12 === value9) {
      throw error11;
    }
    value9 = value12;
    value10 = buildRichMessage(value9, value6);
    await value4.relayMessage(value9, value10.message, {
      messageId: value10.key.id
    });
    return true;
  }
}
const RICH_FALLBACK = value13 => "╭─❏ 「 " + value13 + " 」\n│ This mini-app could not render on this client.\n╰───────────────";
module.exports = {
  buildRichMessage: buildRichMessage,
  sendRichApp: sendRichApp,
  RICH_FALLBACK: RICH_FALLBACK
};
