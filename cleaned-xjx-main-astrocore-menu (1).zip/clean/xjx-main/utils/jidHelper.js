'use strict';

const {
  jidDecode,
  jidEncode
} = require("@whiskeysockets/baileys");
const database = require("../database");
const lidMappingCache = new Map();
function jidUser(value1) {
  if (!value1) {
    return null;
  }
  const value2 = String(value1);
  try {
    const value3 = jidDecode(value2);
    if (value3?.user) {
      return value3.user.split(":")[0];
    }
  } catch (error4) {}
  return value2.split(":")[0].split("@")[0] || null;
}
function jidServer(value5) {
  try {
    const value6 = jidDecode(String(value5 || ""))?.server;
    if (value6 === "c.us") {
      return "s.whatsapp.net";
    } else {
      return value6 || null;
    }
  } catch (error7) {
    return null;
  }
}
function isLidJid(value8) {
  const value9 = jidServer(value8);
  return value9 === "lid" || value9 === "hosted.lid";
}
function isPnJid(value10) {
  const value11 = jidServer(value10);
  return value11 === "s.whatsapp.net" || value11 === "hosted";
}
function cacheKey(value12, value13) {
  return value12 + ":" + value13;
}
function getLidMappingValue(value14, value15) {
  const value16 = jidUser(value14);
  if (!value16 || !["lidToPn", "pnToLid"].includes(value15)) {
    return null;
  }
  const value17 = cacheKey(value15, value16);
  if (lidMappingCache.has(value17)) {
    return lidMappingCache.get(value17);
  }
  try {
    const value18 = database.getLidMap(value15, value16) || null;
    lidMappingCache.set(value17, value18);
    return value18;
  } catch (error19) {
    return null;
  }
}
function rememberLidMapping(value20, value21) {
  const value22 = jidUser(value20);
  const value23 = jidUser(value21);
  if (!value22 || !value23 || value22 === value23) {
    return false;
  }
  try {
    const value24 = getLidMappingValue(value22, "lidToPn");
    const value25 = getLidMappingValue(value23, "pnToLid");
    if (value24 !== value23) {
      database.saveLidMap("lidToPn", value22, value23);
    }
    if (value25 !== value22) {
      database.saveLidMap("pnToLid", value23, value22);
    }
    lidMappingCache.set(cacheKey("lidToPn", value22), value23);
    lidMappingCache.set(cacheKey("pnToLid", value23), value22);
    return true;
  } catch (error26) {
    return false;
  }
}
function rememberParticipantLidMapping(value27) {
  if (!value27 || typeof value27 === "string") {
    return false;
  }
  const value28 = [value27.lid, value27.id, value27.userJid].filter(Boolean);
  const value29 = value28.find(isLidJid);
  const value30 = value27.phoneNumber || value27.pn || value28.find(isPnJid);
  if (value29 && value30) {
    return rememberLidMapping(value29, value30);
  } else {
    return false;
  }
}
function normalizeJidWithLid(value31) {
  if (!value31) {
    return value31;
  }
  try {
    const value32 = jidDecode(value31);
    if (!value32?.user) {
      return String(value31).split(":")[0].split("@")[0] + "@s.whatsapp.net";
    }
    let value33 = value32.user.split(":")[0];
    let value34 = value32.server === "c.us" ? "s.whatsapp.net" : value32.server;
    if (value34 === "lid" || value34 === "hosted.lid") {
      const value35 = getLidMappingValue(value33, "lidToPn");
      if (value35) {
        value33 = value35;
        value34 = value34 === "hosted.lid" ? "hosted" : "s.whatsapp.net";
      }
    }
    return jidEncode(value33, value34 === "hosted" ? "hosted" : "s.whatsapp.net");
  } catch (error36) {
    return value31;
  }
}
function buildComparableIds(value37) {
  if (!value37) {
    return [];
  }
  try {
    const value38 = jidDecode(value37);
    if (!value38?.user) {
      return [normalizeJidWithLid(value37)].filter(Boolean);
    }
    const value39 = value38.user.split(":")[0];
    const value40 = value38.server === "c.us" ? "s.whatsapp.net" : value38.server;
    const value41 = new Set([jidEncode(value39, value40)]);
    if (value40 === "s.whatsapp.net" || value40 === "hosted") {
      const value42 = getLidMappingValue(value39, "pnToLid");
      if (value42) {
        value41.add(jidEncode(value42, value40 === "hosted" ? "hosted.lid" : "lid"));
      }
    } else if (value40 === "lid" || value40 === "hosted.lid") {
      const value43 = getLidMappingValue(value39, "lidToPn");
      if (value43) {
        value41.add(jidEncode(value43, value40 === "hosted.lid" ? "hosted" : "s.whatsapp.net"));
      }
    }
    return [...value41];
  } catch (error44) {
    return [value37];
  }
}
function findParticipant(value45 = [], value46) {
  const value47 = (Array.isArray(value46) ? value46 : [value46]).filter(Boolean).flatMap(buildComparableIds);
  if (!value47.length) {
    return null;
  }
  return value45.find(value48 => {
    if (!value48) {
      return false;
    }
    const value49 = [value48.id, value48.lid, value48.userJid].filter(Boolean).flatMap(buildComparableIds);
    return value49.some(value50 => value47.includes(value50));
  }) || null;
}
function resolveTargetJidVariants(value51, value52) {
  if (!value51) {
    return [];
  }
  const value53 = new Set([value51]);
  for (const value54 of buildComparableIds(value51)) {
    value53.add(value54);
  }
  if (Array.isArray(value52?.participants)) {
    const value55 = jidUser(value51);
    const value56 = value52.participants.find(value57 => {
      if (!value57 || typeof value57 === "string") {
        return false;
      }
      const value58 = [value57.id, value57.lid, value57.userJid].filter(Boolean);
      return value58.includes(value51) || value58.some(value59 => jidUser(value59) === value55);
    });
    if (value56) {
      rememberParticipantLidMapping(value56);
      for (const value60 of [value56.id, value56.lid, value56.userJid, value56.phoneNumber, value56.pn]) {
        if (!value60) {
          continue;
        }
        value53.add(String(value60).includes("@") ? value60 : value60 + "@s.whatsapp.net");
      }
      for (const value61 of [value56.id, value56.lid, value56.userJid].filter(Boolean).flatMap(buildComparableIds)) {
        value53.add(value61);
      }
    }
  }
  return [...value53].filter(Boolean);
}
async function tryFetchProfilePictureUrl(value62, value63, value64) {
  const value65 = resolveTargetJidVariants(value63, value64);
  let value66;
  for (const value67 of value65) {
    try {
      const value68 = await value62.profilePictureUrl(value67, "image");
      if (value68) {
        return {
          url: value68,
          jid: value67
        };
      }
    } catch (error69) {
      value66 = error69;
    }
  }
  if (value66) {
    throw value66;
  }
  return {
    url: null,
    jid: value63
  };
}
function displayUserTag(value70, value71) {
  if (!value70) {
    return "";
  }
  if (Array.isArray(value71?.participants)) {
    const value72 = jidUser(value70);
    const value73 = value71.participants.find(value74 => {
      if (!value74 || typeof value74 === "string") {
        return false;
      }
      const value75 = [value74.id, value74.lid, value74.userJid].filter(Boolean);
      return value75.includes(value70) || value75.some(value76 => jidUser(value76) === value72);
    });
    if (value73) {
      rememberParticipantLidMapping(value73);
      const value77 = value73.phoneNumber || value73.pn;
      if (value77) {
        return jidUser(value77) || String(value77).split("@")[0];
      }
    }
  }
  return String(value70).split("@")[0];
}
async function resolvePhone(value78, value79) {
  if (!value79) {
    return null;
  }
  try {
    const value80 = jidDecode(value79);
    if (!value80?.user) {
      return null;
    }
    const value81 = value80.user.split(":")[0];
    const value82 = value80.server;
    const value83 = value82 === "lid" || value82 === "hosted.lid";
    if (!value83) {
      return value81;
    }
    try {
      const value84 = value78?.signalRepository?.lidMapping;
      if (value84?.getPNForLID) {
        const value85 = await value84.getPNForLID(value79);
        if (value85) {
          const value86 = jidUser(value85);
          if (value86) {
            rememberLidMapping(value81, value86);
            return value86;
          }
        }
      }
    } catch (error87) {}
    return getLidMappingValue(value81, "lidToPn");
  } catch (error88) {
    return null;
  }
}
async function preloadLidResolution(value89, value90, {
  maxWaitMs = 12000,
  intervalMs = 1500
} = {}) {
  const value91 = Array.isArray(value90) ? value90 : [];
  for (const value92 of value91) {
    rememberParticipantLidMapping(value92);
  }
  const value93 = value91.filter(value94 => {
    const value95 = value94?.id || value94;
    return isLidJid(value95);
  });
  if (!value93.length) {
    return {
      attempted: 0,
      resolved: 0
    };
  }
  await Promise.all(value93.map(async value96 => {
    try {
      await value89.presenceSubscribe(value96.id || value96);
    } catch (error97) {}
  }));
  const value98 = Date.now();
  let value99 = 0;
  while (Date.now() - value98 < maxWaitMs) {
    const value100 = await Promise.all(value93.map(value101 => resolvePhone(value89, value101.id || value101)));
    value99 = value100.filter(Boolean).length;
    if (value99 === value93.length) {
      break;
    }
    await new Promise(value102 => setTimeout(value102, intervalMs));
  }
  return {
    attempted: value93.length,
    resolved: value99
  };
}
async function enrichParticipants(value103, value104, {
  skipAdmins = true
} = {}) {
  const value105 = Array.isArray(value104) ? value104 : [];
  const value106 = value103.user?.id || "";
  const value107 = (await resolvePhone(value103, value106)) || jidUser(value106);
  const value108 = await Promise.all(value105.map(async value109 => {
    rememberParticipantLidMapping(value109);
    let value110 = value109.phoneNumber ? jidUser(value109.phoneNumber) : null;
    if (!value110) {
      value110 = await resolvePhone(value103, value109.id);
    }
    return {
      ...value109,
      phone: value110,
      isUnresolvableLid: !value110
    };
  }));
  return value108.filter(value111 => {
    const value112 = value111.phone || jidUser(value111.id);
    if (value112 === value107) {
      return false;
    }
    if (skipAdmins && value111.admin) {
      return false;
    }
    return true;
  });
}
module.exports = {
  jidUser: jidUser,
  getLidMappingValue: getLidMappingValue,
  rememberLidMapping: rememberLidMapping,
  rememberParticipantLidMapping: rememberParticipantLidMapping,
  findParticipant: findParticipant,
  buildComparableIds: buildComparableIds,
  normalizeJidWithLid: normalizeJidWithLid,
  resolveTargetJidVariants: resolveTargetJidVariants,
  tryFetchProfilePictureUrl: tryFetchProfilePictureUrl,
  displayUserTag: displayUserTag,
  resolvePhone: resolvePhone,
  preloadLidResolution: preloadLidResolution,
  enrichParticipants: enrichParticipants
};
