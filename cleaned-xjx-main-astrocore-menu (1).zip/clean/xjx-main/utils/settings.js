const db = require("../database");
const MANAGED_KEYS = ["prefix", "botName", "timezone", "menuStyle", "fontStyle"];
const DEFAULTS = {
  prefix: ".",
  botName: "JuneX-Ultra",
  timezone: "Africa/Nairobi",
  menuStyle: "5",
  fontStyle: "normal"
};
function get(value1) {
  return db.getBotSetting(value1);
}
function set(value2, value3) {
  db.setBotSetting(value2, value3);
}
function load() {
  const value4 = db.getAllBotSettings();
  const value5 = {};
  for (const value6 of MANAGED_KEYS) {
    if (value6 in value4) {
      value5[value6] = value4[value6];
    }
  }
  return value5;
}
function save(value7) {
  db.updateBotSettings(value7);
}
module.exports = {
  get: get,
  set: set,
  load: load,
  save: save,
  DEFAULTS: DEFAULTS
};
