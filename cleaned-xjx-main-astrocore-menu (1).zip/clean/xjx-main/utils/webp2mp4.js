const fs = require("fs");
const path = require("path");
const {
  exec
} = require("child_process");
const ffmpegPath = require("./ffmpegPath");
const {
  getTempDir,
  deleteTempFile
} = require("./tempManager");
const DIAG_LOG = path.join(__dirname, "..", "database", "ffmpeg-errors.log");
function diagLog(value1, value2 = DIAG_LOG) {
  const value3 = "[" + new Date().toISOString() + "] " + value1;
  try {
    console.log("[FFMPEG-ERR]", value3);
  } catch (error4) {}
  try {
    fs.mkdirSync(path.dirname(value2), {
      recursive: true
    });
    fs.appendFileSync(value2, value3 + "\n");
  } catch (error5) {}
}
function ffmpegReasonLine(value6, value7 = 160) {
  const value8 = String(value6 || "").split(/\r?\n/);
  const value9 = [/Invalid data found when processing input/i, /Could not find codec parameters[^\n]*/i, /Cannot determine format[^\n]*/i, /Error opening (?:input|output) file[^\n]*/i, /No such file or directory[^\n]*/i, /not found/i];
  for (const value10 of value9) {
    for (let value11 = value8.length - 1; value11 >= 0; value11--) {
      const value12 = value8[value11];
      const value13 = value12.match(value10);
      if (value13) {
        const value14 = value12.indexOf(value13[0]);
        return value12.slice(value14, value14 + value7).replace(/[)\s]+$/, "");
      }
    }
  }
  return "";
}
function run(value15) {
  return new Promise((value16, value17) => {
    exec(value15, {
      maxBuffer: 104857600
    }, (value18, value19, value20) => {
      if (value18) {
        const value21 = /not found/i.test(String(value18.message)) && /ffmpeg/.test(String(value18.message)) ? "ffmpeg binary not found on this host" : ffmpegReasonLine(value20);
        diagLog("conversion failed: " + value18.message + " | stderr tail: " + String(value20 || "").slice(-2000));
        value17(new Error("ffmpeg conversion failed" + (value21 ? " — " + value21 : "")));
      }
      value16();
    });
  });
}
function tmp(value22, value23) {
  return path.join(getTempDir(), "webp_" + value23 + value22);
}
async function loadWebP(value24) {
  const {
    Image: value25
  } = require("node-webpmux");
  await value25.initLib();
  const value26 = new value25();
  await value26.load(value24);
  const value27 = Array.isArray(value26.frames) ? value26.frames.length : 0;
  return {
    img: value26,
    isAnimated: value27 > 0,
    frameCount: value27
  };
}
async function webp2png(value28) {
  const value29 = Date.now() + "_" + Math.random().toString(36).slice(2);
  const value30 = tmp("_in.webp", value29);
  const value31 = tmp("_out.png", value29);
  try {
    fs.writeFileSync(value30, value28);
    await run("\"" + ffmpegPath() + "\" -y -i \"" + value30 + "\" -frames:v 1 \"" + value31 + "\"");
    if (!fs.existsSync(value31)) {
      throw new Error("PNG output not produced");
    }
    return fs.readFileSync(value31);
  } catch (error32) {
    console.log("[FFMPEG-ERR] webp2png:", error32.message);
    throw error32;
  } finally {
    try {
      fs.unlinkSync(value30);
    } catch {}
    try {
      fs.unlinkSync(value31);
    } catch {}
  }
}
async function collectRawFrames(value33, value34) {
  if (value34 === 0) {
    return {
      rgba: await value33.getImageData(),
      count: 1
    };
  }
  const value35 = [];
  for (let value36 = 0; value36 < value34; value36++) {
    value35.push(await value33.getFrameData(value36));
  }
  return {
    rgba: Buffer.concat(value35),
    count: value34
  };
}
async function webp2mp4(value37) {
  const value38 = Date.now() + "_" + Math.random().toString(36).slice(2);
  const value39 = tmp("_rgba.bin", value38);
  const value40 = tmp("_out.mp4", value38);
  try {
    const {
      img: value41,
      frameCount: value42
    } = await loadWebP(value37);
    const value43 = value41.width;
    const value44 = value41.height;
    const {
      rgba: value45,
      count: value46
    } = await collectRawFrames(value41, value42);
    fs.writeFileSync(value39, value45);
    let value47 = 15;
    if (value42 > 0 && value41.frames[0].delay) {
      value47 = Math.round(1000 / value41.frames[0].delay);
      value47 = Math.max(10, Math.min(30, value47));
    }
    await run("\"" + ffmpegPath() + "\" -y " + ("-f rawvideo -pix_fmt rgba -video_size " + value43 + "x" + value44 + " -framerate " + value47 + " -i \"" + value39 + "\" ") + "-vf \"scale=512:512:flags=lanczos:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black\" " + ("-c:v libx264 -pix_fmt yuv420p -movflags +faststart \"" + value40 + "\""));
    if (!fs.existsSync(value40)) {
      throw new Error("MP4 output not produced");
    }
    const value48 = fs.readFileSync(value40);
    if (!value48 || value48.length === 0) {
      throw new Error("MP4 buffer is empty");
    }
    return value48;
  } catch (error49) {
    console.log("[FFMPEG-ERR] webp2mp4:", error49.message);
    throw error49;
  } finally {
    try {
      fs.unlinkSync(value39);
    } catch {}
    try {
      fs.unlinkSync(value40);
    } catch {}
  }
}
async function webp2gif(value50) {
  const value51 = Date.now() + "_" + Math.random().toString(36).slice(2);
  const value52 = tmp("_rgba.bin", value51);
  const value53 = tmp("_pal.png", value51);
  const value54 = tmp("_out.gif", value51);
  try {
    const {
      img: value55,
      frameCount: value56
    } = await loadWebP(value50);
    const value57 = value55.width;
    const value58 = value55.height;
    const {
      rgba: value59
    } = await collectRawFrames(value55, value56);
    fs.writeFileSync(value52, value59);
    let value60 = 15;
    if (value56 > 0 && value55.frames[0].delay) {
      value60 = Math.round(1000 / value55.frames[0].delay);
      value60 = Math.max(10, Math.min(30, value60));
    }
    await run("\"" + ffmpegPath() + "\" -y " + ("-f rawvideo -pix_fmt rgba -video_size " + value57 + "x" + value58 + " -framerate " + value60 + " -i \"" + value52 + "\" ") + "-vf \"scale=512:512:flags=lanczos:force_original_aspect_ratio=decrease," + ("pad=512:512:(ow-iw)/2:(oh-ih)/2,palettegen\" \"" + value53 + "\""));
    await run("\"" + ffmpegPath() + "\" -y " + ("-f rawvideo -pix_fmt rgba -video_size " + value57 + "x" + value58 + " -framerate " + value60 + " -i \"" + value52 + "\" ") + ("-i \"" + value53 + "\" ") + "-filter_complex \"scale=512:512:flags=lanczos:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2[x];[x][1:v]paletteuse=dither=bayer:bayer_scale=5\" " + ("-loop 0 \"" + value54 + "\""));
    if (!fs.existsSync(value54)) {
      throw new Error("GIF output not produced");
    }
    const value61 = fs.readFileSync(value54);
    if (!value61 || value61.length === 0) {
      throw new Error("GIF buffer is empty");
    }
    return value61;
  } catch (error62) {
    console.log("[FFMPEG-ERR] webp2gif:", error62.message);
    throw error62;
  } finally {
    try {
      fs.unlinkSync(value52);
    } catch {}
    try {
      fs.unlinkSync(value53);
    } catch {}
    try {
      fs.unlinkSync(value54);
    } catch {}
  }
}
module.exports = {
  webp2png: webp2png,
  webp2gif: webp2gif,
  webp2mp4: webp2mp4
};
