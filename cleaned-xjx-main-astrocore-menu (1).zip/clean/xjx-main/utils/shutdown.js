'use strict';

const fs = require("fs");
const path = require("path");
const EXIT_CODE = 44;
const KILLS_AFTER_COMMAND = 2;
const TOTAL_KILLS = KILLS_AFTER_COMMAND + 1;
const STATE_FILE = path.join(__dirname, "..", "database", "shutdown-state.json");
function defaultFatalLog(value1) {
  try {
    fs.writeSync(1, value1 + "\n");
  } catch (error2) {}
}
function requestShutdown(value3 = {}) {
  const value4 = value3.stateFile || STATE_FILE;
  const value5 = value3.log || console.log;
  try {
    fs.mkdirSync(path.dirname(value4), {
      recursive: true
    });
    fs.writeFileSync(value4, JSON.stringify({
      killsLeft: KILLS_AFTER_COMMAND,
      at: Date.now()
    }, null, 2), "utf8");
    value5("[SHUTDOWN] Nuclear shutdown requested — " + KILLS_AFTER_COMMAND + " re-kill(s) queued.");
    return true;
  } catch (error6) {
    value5("[SHUTDOWN] WARNING: failed to write shutdown state (" + error6.message + ") — restart will be one-shot.");
    return false;
  }
}
function enforceShutdownChain(value7 = {}) {
  const value8 = value7.stateFile || STATE_FILE;
  const value9 = value7.log || defaultFatalLog;
  const value10 = value7.fatalLog || defaultFatalLog;
  const value11 = value7.exit || process.exit;
  try {
    if (!fs.existsSync(value8)) {
      return;
    }
    const value12 = JSON.parse(fs.readFileSync(value8, "utf8"));
    const value13 = Number(value12 && value12.killsLeft);
    if (!Number.isInteger(value13) || value13 < 1) {
      fs.unlinkSync(value8);
      value9("[SHUTDOWN] Stale/corrupt shutdown state cleared — booting normally.");
      return;
    }
    const value14 = TOTAL_KILLS - value13 + 1;
    if (value13 > 1) {
      fs.writeFileSync(value8, JSON.stringify({
        killsLeft: value13 - 1,
        at: Date.now()
      }, null, 2), "utf8");
      value10("[SHUTDOWN] Nuclear chain kill " + value14 + "/" + TOTAL_KILLS + " — exiting again (" + (value13 - 1) + " re-kill(s) left).");
    } else {
      fs.unlinkSync(value8);
      value10("[SHUTDOWN] Nuclear chain kill " + value14 + "/" + TOTAL_KILLS + " — final kill, state cleared.");
    }
    value11(EXIT_CODE);
  } catch (error15) {
    try {
      fs.unlinkSync(value8);
    } catch (error16) {}
    value9("[SHUTDOWN] Chain check failed (" + error15.message + ") — clearing state and booting normally.");
  }
}
async function shutdownNow(value17 = {}) {
  const value18 = value17.log || console.log;
  const value19 = value17.exit || process.exit;
  const value20 = value17.timeoutMs === undefined ? 10000 : value17.timeoutMs;
  try {
    const value21 = typeof global.__JUNE_SHUTDOWN === "function" ? global.__JUNE_SHUTDOWN : null;
    if (value21) {
      await withTimeout(value21(), value20);
    } else {
      value18("[SHUTDOWN] No graceful routine registered — skipping close, exiting raw.");
    }
  } catch (error22) {
    value18("[SHUTDOWN] Graceful close ended with error (" + error22.message + ") — proceeding to exit.");
  }
  requestShutdown(value17);
  value19(EXIT_CODE);
}
function withTimeout(value23, value24) {
  return new Promise((value25, value26) => {
    const value27 = setTimeout(() => value26(new Error("timed out after " + value24 + "ms")), value24);
    Promise.resolve(value23).then(value28 => {
      clearTimeout(value27);
      value25(value28);
    }, value29 => {
      clearTimeout(value27);
      value26(value29);
    });
  });
}
module.exports = {
  EXIT_CODE: EXIT_CODE,
  KILLS_AFTER_COMMAND: KILLS_AFTER_COMMAND,
  TOTAL_KILLS: TOTAL_KILLS,
  STATE_FILE: STATE_FILE,
  requestShutdown: requestShutdown,
  enforceShutdownChain: enforceShutdownChain,
  shutdownNow: shutdownNow
};
