function getQuotedContext(value1) {
  const value2 = [value1.message?.extendedTextMessage?.contextInfo, value1.message?.buttonsResponseMessage?.contextInfo, value1.message?.listResponseMessage?.contextInfo];
  for (const value3 of value2) {
    if (value3?.quotedMessage) {
      return {
        ctx: value3,
        quotedMessage: value3.quotedMessage
      };
    }
  }
  return null;
}
function resolveQuoted(value4) {
  const value5 = getQuotedContext(value4);
  if (!value5) {
    return null;
  }
  const {
    ctx: value6,
    quotedMessage: value7
  } = value5;
  const value8 = {
    key: {
      remoteJid: value6.remoteJid || value4.key.remoteJid,
      fromMe: false,
      id: value6.stanzaId,
      participant: value6.participant
    },
    message: value7
  };
  return {
    ctx: value6,
    quotedMessage: value7,
    fullQuoted: value8
  };
}
module.exports = {
  getQuotedContext: getQuotedContext,
  resolveQuoted: resolveQuoted
};
