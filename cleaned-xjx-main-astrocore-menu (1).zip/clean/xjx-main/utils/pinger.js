'use strict';

const path = require("path");
const SETTINGS_KEY = "pinger.targets";
const DEFAULT_INTERVAL_MS = 240000;
const PING_TIMEOUT_MS = 10000;
const MAX_TARGETS = 10;
const MAX_URL_LENGTH = 200;
const state = {
  sock: null,
  db: null,
  timer: null,
  statuses: new Map()
};
function intervalMs() {
  const value1 = Number(process.env.JUNE_PINGER_INTERVAL_MS);
  if (Number.isSafeInteger(value1) && value1 >= 250) {
    return value1;
  } else {
    return DEFAULT_INTERVAL_MS;
  }
}
function getDb() {
  if (state.db) {
    return state.db;
  }
  return require(path.join(global.__CORE__ || process.cwd(), "database"));
}
const PRIVATE_HOST_PATTERNS = [/^localhost$/i, /^127\./, /^10\./, /^192\.168\./, /^169\.254\./, /^0\./, /^\[?::1\]?$/, /^\[?fe80:/i, /^\[?fc00:/i, /^\[?fd/i];
function isPrivateHost(value2) {
  const value3 = String(value2 || "").replace(/^\[|\]$/g, "");
  if (PRIVATE_HOST_PATTERNS.some(value4 => value4.test(value3))) {
    return true;
  }
  const value5 = value3.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (value5) {
    const [value6, value7] = [Number(value5[1]), Number(value5[2])];
    if (value6 === 172 && value7 >= 16 && value7 <= 31) {
      return true;
    }
  }
  return false;
}
function validateTargetUrl(value8) {
  const value9 = String(value8 || "").trim();
  if (!value9) {
    return {
      ok: false,
      error: "No URL given."
    };
  }
  if (value9.length > MAX_URL_LENGTH) {
    return {
      ok: false,
      error: "URL is too long (max " + MAX_URL_LENGTH + " characters)."
    };
  }
  let value10;
  try {
    value10 = new URL(value9);
  } catch (error11) {
    return {
      ok: false,
      error: "That is not a valid URL (include https:// — e.g. https://example.com)."
    };
  }
  if (value10.protocol !== "http:" && value10.protocol !== "https:") {
    return {
      ok: false,
      error: "Only http:// and https:// URLs are supported."
    };
  }
  if (!value10.hostname) {
    return {
      ok: false,
      error: "The URL has no hostname."
    };
  }
  if (isPrivateHost(value10.hostname)) {
    return {
      ok: false,
      error: "Private, loopback and link-local addresses cannot be pinged."
    };
  }
  value10.hash = "";
  return {
    ok: true,
    url: value10.toString()
  };
}
function listTargets() {
  const value12 = getDb().getBotSetting(SETTINGS_KEY);
  if (Array.isArray(value12)) {
    return value12.filter(value13 => value13 && typeof value13.url === "string");
  } else {
    return [];
  }
}
function saveTargets(value14) {
  getDb().setBotSetting(SETTINGS_KEY, value14);
}
function addTarget(value15, value16 = Date.now()) {
  const value17 = listTargets();
  if (value17.some(value18 => value18.url === value15)) {
    return {
      added: false,
      reason: "already-listed"
    };
  }
  if (value17.length >= MAX_TARGETS) {
    return {
      added: false,
      reason: "limit"
    };
  }
  value17.push({
    url: value15,
    addedAt: value16
  });
  saveTargets(value17);
  ensureTimer();
  return {
    added: true
  };
}
function removeTarget(value19) {
  const value20 = listTargets();
  const value21 = value20.filter(value22 => value22.url !== value19);
  if (value21.length === value20.length) {
    return {
      removed: false
    };
  }
  saveTargets(value21);
  state.statuses.delete(value19);
  if (!value21.length) {
    stopTimer();
  }
  return {
    removed: true
  };
}
function clearTargets() {
  const value23 = listTargets().length > 0;
  saveTargets([]);
  state.statuses.clear();
  stopTimer();
  return {
    cleared: value23
  };
}
async function pingOnce(value24) {
  const value25 = Date.now();
  try {
    const value26 = await fetch(value24, {
      method: "GET",
      redirect: "follow",
      signal: AbortSignal.timeout(PING_TIMEOUT_MS),
      headers: {
        "User-Agent": "JuneX-Ultra-Pinger/3.0 (+keep-alive)"
      }
    });
    try {
      value26.body?.cancel?.();
    } catch (error27) {}
    const value28 = Date.now() - value25;
    return {
      ok: value26.status < 500,
      status: value26.status < 500 ? "up" : "down",
      httpStatus: value26.status,
      latencyMs: value28,
      error: null
    };
  } catch (error29) {
    const value30 = Date.now() - value25;
    const value31 = error29?.name === "TimeoutError" ? "timeout" : error29?.cause?.code || error29?.code || error29?.message || "network error";
    return {
      ok: false,
      status: "down",
      httpStatus: null,
      latencyMs: value30,
      error: String(value31)
    };
  }
}
function ownerJids() {
  try {
    return (getDb().getOwners() || []).map(value32 => String(value32 || "").trim()).filter(Boolean).map(value33 => value33.includes("@") ? value33 : value33.replace(/\D/g, "") + "@s.whatsapp.net").filter(value34 => value34.startsWith("@") === false && value34.includes("@s.whatsapp.net"));
  } catch (error35) {
    return [];
  }
}
async function notifyOwners(value36) {
  if (!state.sock) {
    return;
  }
  for (const value37 of ownerJids()) {
    try {
      await state.sock.sendMessage(value37, {
        text: value36
      });
    } catch (error38) {}
  }
}
async function runCycle() {
  const value39 = listTargets();
  if (!value39.length) {
    stopTimer();
    return;
  }
  const value40 = await Promise.allSettled(value39.map(value41 => pingOnce(value41.url)));
  value40.forEach((value42, value43) => {
    const value44 = value39[value43].url;
    const value45 = value42.status === "fulfilled" ? value42.value : {
      ok: false,
      status: "down",
      httpStatus: null,
      latencyMs: null,
      error: String(value42.reason)
    };
    const value46 = state.statuses.get(value44);
    state.statuses.set(value44, {
      ...value45,
      checkedAt: Date.now()
    });
    if (value46 && value46.status !== value45.status) {
      if (value45.status === "down") {
        notifyOwners("🔴 *Pinger: site down*\n\n" + value44 + "\n\nReason: " + (value45.error || "HTTP " + value45.httpStatus) + "\nChecked: " + new Date().toLocaleString());
      } else {
        notifyOwners("🟢 *Pinger: site recovered*\n\n" + value44 + "\n\nHTTP " + value45.httpStatus + " · " + value45.latencyMs + " ms\nChecked: " + new Date().toLocaleString());
      }
    }
  });
}
function ensureTimer() {
  if (state.timer) {
    return;
  }
  state.timer = setInterval(() => {
    runCycle().catch(() => {});
  }, intervalMs());
  if (global._activeIntervals) {
    global._activeIntervals.push(state.timer);
  }
}
function stopTimer() {
  if (!state.timer) {
    return;
  }
  clearInterval(state.timer);
  state.timer = null;
}
function onBotConnected(value47, value48) {
  if (value47) {
    state.sock = value47;
  }
  if (value48) {
    state.db = value48;
  }
  if (listTargets().length) {
    ensureTimer();
    setTimeout(() => {
      runCycle().catch(() => {});
    }, 3000);
  }
  return true;
}
function getStatusMap() {
  return state.statuses;
}
module.exports = {
  DEFAULT_INTERVAL_MS: DEFAULT_INTERVAL_MS,
  MAX_TARGETS: MAX_TARGETS,
  SETTINGS_KEY: SETTINGS_KEY,
  intervalMs: intervalMs,
  validateTargetUrl: validateTargetUrl,
  listTargets: listTargets,
  addTarget: addTarget,
  removeTarget: removeTarget,
  clearTargets: clearTargets,
  pingOnce: pingOnce,
  onBotConnected: onBotConnected,
  runCycle: runCycle,
  getStatusMap: getStatusMap,
  __test: {
    state: state,
    getDb: () => getDb(),
    setDatabase: value49 => {
      state.db = value49;
    },
    reset: () => {
      stopTimer();
      state.sock = null;
      state.db = null;
      state.statuses.clear();
    }
  }
};
