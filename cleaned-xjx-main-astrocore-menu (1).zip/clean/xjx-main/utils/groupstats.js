'use strict';

const database = require("../database");
const FLUSH_INTERVAL_MS = 5000;
const cache = new Map();
const dirtyDays = new Map();
const preReadyDays = new Map();
const fullyLoadedGroups = new Set();
let databaseReady = false;
let flushInProgress = false;
let lastDatabaseErrorAt = 0;
function todayKey() {
  return new Date().toISOString().slice(0, 10);
}
function hourKey() {
  return new Date().getHours().toString();
}
function toCount(value1) {
  const value2 = Number(value1);
  if (Number.isFinite(value2) && value2 > 0) {
    return Math.floor(value2);
  } else {
    return 0;
  }
}
function normaliseCounterMap(value3) {
  const value4 = {};
  if (!value3 || typeof value3 !== "object" || Array.isArray(value3)) {
    return value4;
  }
  for (const [value5, value6] of Object.entries(value3)) {
    const value7 = toCount(value6);
    if (value7 > 0) {
      value4[String(value5)] = value7;
    }
  }
  return value4;
}
function normaliseStat(value8) {
  const value9 = value8 && typeof value8 === "object" && !Array.isArray(value8) ? value8 : {};
  return {
    total: toCount(value9.total),
    users: normaliseCounterMap(value9.users),
    hours: normaliseCounterMap(value9.hours)
  };
}
function mergeStats(value10, value11) {
  const value12 = normaliseStat(value10);
  const value13 = normaliseStat(value11);
  value12.total += value13.total;
  for (const [value14, value15] of Object.entries(value13.users)) {
    value12.users[value14] = (value12.users[value14] || 0) + value15;
  }
  for (const [value16, value17] of Object.entries(value13.hours)) {
    value12.hours[value16] = (value12.hours[value16] || 0) + value17;
  }
  return value12;
}
function normaliseGroupId(value18) {
  return String(value18 || "");
}
function normaliseDate(value19) {
  return String(value19 || "");
}
function getGroupDays(value20) {
  const value21 = normaliseGroupId(value20);
  let value22 = cache.get(value21);
  if (!value22) {
    value22 = new Map();
    cache.set(value21, value22);
  }
  return value22;
}
function markDay(value23, value24, value25) {
  const value26 = normaliseGroupId(value24);
  const value27 = normaliseDate(value25);
  let value28 = value23.get(value26);
  if (!value28) {
    value28 = new Set();
    value23.set(value26, value28);
  }
  value28.add(value27);
}
function reportDatabaseError(value29) {
  const value30 = Date.now();
  if (value30 - lastDatabaseErrorAt < 60000) {
    return;
  }
  lastDatabaseErrorAt = value30;
  console.error("[groupStats] SQLite error:", value29?.message || value29);
}
function loadDay(value31, value32) {
  const value33 = normaliseGroupId(value31);
  const value34 = normaliseDate(value32);
  const value35 = getGroupDays(value33);
  if (value35.has(value34)) {
    return value35.get(value34);
  }
  if (!databaseReady) {
    return null;
  }
  try {
    const value36 = database.getGroupStat(value33, value34);
    if (value36 === null) {
      return null;
    }
    const value37 = normaliseStat(value36);
    value35.set(value34, value37);
    return value37;
  } catch (error38) {
    reportDatabaseError(error38);
    return null;
  }
}
function ensureDay(value39, value40) {
  const value41 = normaliseGroupId(value39);
  const value42 = normaliseDate(value40);
  const value43 = loadDay(value41, value42);
  if (value43) {
    return value43;
  }
  const value44 = {
    total: 0,
    users: {},
    hours: {}
  };
  getGroupDays(value41).set(value42, value44);
  if (!databaseReady) {
    markDay(preReadyDays, value41, value42);
  }
  return value44;
}
function loadAllGroupDays(value45) {
  const value46 = normaliseGroupId(value45);
  const value47 = getGroupDays(value46);
  if (!databaseReady || fullyLoadedGroups.has(value46)) {
    return value47;
  }
  try {
    for (const value48 of database.getAllGroupStats(value46)) {
      const value49 = normaliseDate(value48.date);
      if (!value47.has(value49)) {
        value47.set(value49, normaliseStat(value48.data));
      }
    }
    fullyLoadedGroups.add(value46);
  } catch (error50) {
    reportDatabaseError(error50);
  }
  return value47;
}
function reconcilePreReadyDays() {
  if (!databaseReady || preReadyDays.size === 0) {
    return;
  }
  for (const [value51, value52] of preReadyDays) {
    const value53 = getGroupDays(value51);
    for (const value54 of value52) {
      const value55 = value53.get(value54);
      if (!value55) {
        continue;
      }
      try {
        const value56 = database.getGroupStat(value51, value54);
        if (value56 !== null) {
          value53.set(value54, mergeStats(value56, value55));
        }
      } catch (error57) {
        reportDatabaseError(error57);
      }
    }
  }
  preReadyDays.clear();
}
function flushGroupStats() {
  if (!databaseReady || flushInProgress || dirtyDays.size === 0) {
    return 0;
  }
  flushInProgress = true;
  let value58 = 0;
  try {
    for (const [value59, value60] of [...dirtyDays.entries()]) {
      const value61 = getGroupDays(value59);
      for (const value62 of [...value60]) {
        const value63 = value61.get(value62);
        if (!value63) {
          value60.delete(value62);
          continue;
        }
        try {
          database.saveGroupStat(value59, value62, value63);
          value60.delete(value62);
          value58 += 1;
        } catch (error64) {
          reportDatabaseError(error64);
        }
      }
      if (value60.size === 0) {
        dirtyDays.delete(value59);
      }
    }
  } finally {
    flushInProgress = false;
  }
  return value58;
}
function addMessage(value65, value66) {
  const value67 = normaliseGroupId(value65);
  const value68 = String(value66 || "");
  if (!value67 || !value68) {
    return;
  }
  const value69 = todayKey();
  const value70 = ensureDay(value67, value69);
  value70.total += 1;
  value70.users[value68] = (value70.users[value68] || 0) + 1;
  const value71 = hourKey();
  value70.hours[value71] = (value70.hours[value71] || 0) + 1;
  markDay(dirtyDays, value67, value69);
}
function getStats(value72) {
  return loadDay(value72, todayKey());
}
function getActiveUsers(value73, value74 = 15) {
  const value75 = {};
  for (const value76 of loadAllGroupDays(value73).values()) {
    for (const [value77, value78] of Object.entries(value76.users || {})) {
      value75[value77] = (value75[value77] || 0) + toCount(value78);
    }
  }
  const value79 = Math.max(0, Math.floor(Number(value74) || 0));
  return Object.entries(value75).map(([value80, value81]) => ({
    jid: value80,
    count: value81
  })).sort((value82, value83) => value83.count - value82.count).slice(0, value79);
}
function getInactiveUsers(value84, value85) {
  const value86 = new Set();
  for (const value87 of loadAllGroupDays(value84).values()) {
    for (const value88 of Object.keys(value87.users || {})) {
      value86.add(value88);
    }
  }
  if (Array.isArray(value85)) {
    return value85.filter(value89 => !value86.has(value89));
  } else {
    return [];
  }
}
setInterval(flushGroupStats, FLUSH_INTERVAL_MS).unref();
global.__JUNE_FLUSH_GROUP_STATS = flushGroupStats;
process.prependListener("exit", flushGroupStats);
database.ready.then(() => {
  databaseReady = true;
  reconcilePreReadyDays();
  flushGroupStats();
}).catch(() => {});
module.exports = {
  addMessage: addMessage,
  getStats: getStats,
  getActiveUsers: getActiveUsers,
  getInactiveUsers: getInactiveUsers,
  flush: flushGroupStats,
  flushGroupStats: flushGroupStats
};
