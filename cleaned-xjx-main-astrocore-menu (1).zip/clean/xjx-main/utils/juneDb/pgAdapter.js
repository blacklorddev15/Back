'use strict';

const fs = require("fs");
const path = require("path");
let Pool = null;
try {
  ({
    Pool
  } = require("pg"));
} catch (error1) {}
const SCHEMA_FILE = path.join(__dirname, "postgres-schema.sql");
const LEGACY_AUTH_RECORD_KEY = "__june_encrypted_auth_backup_v1__";
function normalizeBotId(value2) {
  const value3 = String(value2 || "").trim().split("@")[0].split(":")[0];
  const value4 = value3.replace(/[^a-zA-Z0-9_.-]/g, "-").replace(/-+/g, "-");
  return value4 || "june-x-main";
}
const BOT_ID_PRODUCT = "june-ultra-main";
function buildBotId(value5, value6 = BOT_ID_PRODUCT) {
  const value7 = String(value5 || "").split("@")[0].split(":")[0].replace(/\D/g, "");
  return normalizeBotId(value7 ? value6 + "-" + value7 : value6);
}
let activeBotId = buildBotId(process.env.PN || process.env.JUNE_PN || process.env.JUNE_BOT_ID || process.env.BOT_ID || process.env.OWNER_NUMBER);
let pool = null;
let ready = false;
let initializing = null;
let lastError = null;
let schemaReady = false;
function hasUrl() {
  return Boolean(getUrl());
}
function getUrl() {
  return String(process.env.DATABASE_URL || process.env.POSTGRESQL_URL || process.env.POSTGRES_URL || "").trim();
}
function getBotId() {
  return activeBotId;
}
function setBotId(value8) {
  if (value8) {
    activeBotId = normalizeBotId(value8);
  }
  return activeBotId;
}
function getStatus() {
  return {
    configured: hasUrl(),
    available: ready,
    schemaReady: schemaReady,
    botId: activeBotId,
    lastError: lastError
  };
}
function readSchema() {
  try {
    return fs.readFileSync(SCHEMA_FILE, "utf8");
  } catch (error9) {
    throw new Error("PostgreSQL schema file is unavailable: " + error9.message);
  }
}
function normalizePgConfig(value10) {
  const value11 = String(value10 || "").trim();
  const value12 = {
    rejectUnauthorized: false
  };
  const value13 = (value14, value15) => {
    let value16 = String(value14 || "");
    for (const value17 of value15) {
      value16 = value16.replace(new RegExp("([?&])" + value17 + "=[^&]*", "gi"), "$1");
    }
    return value16.replace(/[?&]+$/g, "").replace(/\?&/g, "?").replace(/&&+/g, "&");
  };
  try {
    const value18 = new URL(value11);
    const value19 = String(value18.searchParams.get("sslmode") || "").toLowerCase();
    const value20 = String(value18.searchParams.get("ssl") || "").toLowerCase();
    value18.searchParams.delete("sslmode");
    value18.searchParams.delete("channel_binding");
    value18.searchParams.delete("uselibpqcompat");
    if (value20 === "true" || value20 === "1" || value20 === "require") {
      value18.searchParams.delete("ssl");
    }
    const value21 = /^(localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\])$/i.test(value18.hostname);
    let value22;
    if (value19 === "disable" || value20 === "false" || value20 === "0") {
      value22 = false;
    } else if (value19 === "verify-full") {
      value22 = {
        rejectUnauthorized: true
      };
    } else if (value19 || value20 === "true" || value20 === "1" || value20 === "require" || !value21) {
      value22 = value12;
    }
    return {
      connectionString: value18.toString(),
      ssl: value22
    };
  } catch {
    const value23 = /sslmode=([^&]+)/i.exec(value11)?.[1]?.toLowerCase() || "";
    if (value23 === "disable") {
      return {
        connectionString: value13(value11, ["sslmode", "channel_binding", "uselibpqcompat"]),
        ssl: false
      };
    }
    return {
      connectionString: value13(value11, ["sslmode", "channel_binding", "uselibpqcompat", "ssl"]),
      ssl: value12
    };
  }
}
async function init() {
  if (ready) {
    return getStatus();
  }
  if (initializing) {
    return initializing;
  }
  initializing = (async () => {
    if (!hasUrl()) {
      return getStatus();
    }
    if (!Pool) {
      lastError = "The pg package is not installed";
      console.warn("[PG] Optional PostgreSQL disabled: " + lastError);
      return getStatus();
    }
    const value24 = getUrl();
    const value25 = normalizePgConfig(value24);
    const value26 = new Pool({
      connectionString: value25.connectionString,
      max: Number(process.env.JUNE_PG_POOL_MAX) || 5,
      idleTimeoutMillis: Number(process.env.JUNE_PG_IDLE_TIMEOUT_MS) || 30000,
      connectionTimeoutMillis: Number(process.env.JUNE_PG_CONNECTION_TIMEOUT_MS) || 5000,
      ssl: value25.ssl
    });
    value26.on("error", value27 => {
      lastError = value27.message;
      const value28 = Date.now();
      if (value28 - value26._lastErrorLog >= 300000) {
        value26._lastErrorLog = value28;
        console.warn("[PG] Pool error: " + value27.message);
      }
    });
    try {
      await value26.query("SELECT 1");
      await value26.query(readSchema());
      pool = value26;
      ready = true;
      schemaReady = true;
      lastError = null;
      console.log("[PG] Connected; remote persistence enabled for bot_id=" + require("../redact").maskBotId(activeBotId));
    } catch (error29) {
      lastError = error29.message;
      console.warn("[PG] Optional PostgreSQL unavailable: " + error29.message);
      if (/SSL|TLS/i.test(error29.message)) {
        console.warn("[PG] The server requires TLS. Paste the provider URL as-is; June enables TLS for remote hosts automatically.");
      } else if (/password|authentication|role .* does not exist/i.test(error29.message)) {
        console.warn("[PG] Check the username and password in DATABASE_URL.");
      } else if (/ENOTFOUND|EAI_AGAIN|ETIMEDOUT|ECONNREFUSED/i.test(error29.message)) {
        console.warn("[PG] Host unreachable — check the hostname, port, and that the database is awake.");
      }
      try {
        await value26.end();
      } catch (error30) {}
    }
    return getStatus();
  })().finally(() => {
    initializing = null;
  });
  return initializing;
}
function query(value31, value32 = []) {
  if (!ready || !pool) {
    return Promise.resolve(null);
  }
  return pool.query(value31, value32).catch(value33 => {
    lastError = value33.message;
    return null;
  });
}
function mirrorBotSetting(value34, value35) {
  return query("INSERT INTO bot_configs (bot_id, key, value)\n     VALUES ($1, $2, $3::jsonb)\n     ON CONFLICT (bot_id, key)\n     DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()", [activeBotId, String(value34), JSON.stringify(value35)]);
}
function mirrorGroupSettings(value36, value37) {
  return query("INSERT INTO group_features (bot_id, group_id, feature, config, enabled)\n     VALUES ($1, $2, $3, $4::jsonb, TRUE)\n     ON CONFLICT (bot_id, group_id, feature)\n     DO UPDATE SET config = EXCLUDED.config, enabled = TRUE, updated_at = NOW()", [activeBotId, String(value36), "group-settings", JSON.stringify(value37 || {})]);
}
function mirrorGroupStat(value38, value39, value40) {
  return query("INSERT INTO group_stats (bot_id, group_id, stat_date, data)\n     VALUES ($1, $2, $3, $4::jsonb)\n     ON CONFLICT (bot_id, group_id, stat_date)\n     DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()", [activeBotId, String(value38), String(value39), JSON.stringify(value40 || {})]);
}
function mirrorUser(value41, value42) {
  return query("INSERT INTO users (bot_id, user_id, data)\n     VALUES ($1, $2, $3::jsonb)\n     ON CONFLICT (bot_id, user_id)\n     DO UPDATE SET data = EXCLUDED.data, updated_at = NOW()", [activeBotId, String(value41), JSON.stringify(value42 || {})]);
}
function mirrorAntideleteMessage(value43, value44, value45, value46 = Date.now()) {
  return query("INSERT INTO antidelete_messages (bot_id, chat_id, message_id, payload, stored_at)\n     VALUES ($1, $2, $3, $4::jsonb, $5)\n     ON CONFLICT (bot_id, chat_id, message_id)\n     DO UPDATE SET payload = EXCLUDED.payload, stored_at = EXCLUDED.stored_at", [activeBotId, String(value43), String(value44), JSON.stringify(value45 || {}), new Date(Number(value46))]);
}
function deleteAntideleteMessage(value47, value48) {
  return query("DELETE FROM antidelete_messages\n     WHERE bot_id = $1 AND chat_id = $2 AND message_id = $3", [activeBotId, String(value47), String(value48)]);
}
function mirrorAntideleteStatus(value49, value50, value51 = Date.now()) {
  return query("INSERT INTO antidelete_statuses (bot_id, status_id, payload, stored_at)\n     VALUES ($1, $2, $3::jsonb, $4)\n     ON CONFLICT (bot_id, status_id)\n     DO UPDATE SET payload = EXCLUDED.payload, stored_at = EXCLUDED.stored_at", [activeBotId, String(value49), JSON.stringify(value50 || {}), new Date(Number(value51))]);
}
function deleteAntideleteStatus(value52) {
  return query("DELETE FROM antidelete_statuses\n     WHERE bot_id = $1 AND status_id = $2", [activeBotId, String(value52)]);
}
function mirrorLidMap(value53, value54, value55, value56 = Date.now()) {
  return query("INSERT INTO lid_map (bot_id, direction, map_user, map_value, updated_at)\n     VALUES ($1, $2, $3, $4, $5)\n     ON CONFLICT (bot_id, direction, map_user)\n     DO UPDATE SET map_value = EXCLUDED.map_value, updated_at = EXCLUDED.updated_at", [activeBotId, String(value53), String(value54), String(value55), new Date(Number(value56))]);
}
function mirrorWarning(value57, value58, value59) {
  return query("INSERT INTO warnings (bot_id, group_id, user_id, count, reasons)\n     VALUES ($1, $2, $3, $4, $5::jsonb)\n     ON CONFLICT (bot_id, group_id, user_id)\n     DO UPDATE SET count = EXCLUDED.count, reasons = EXCLUDED.reasons, updated_at = NOW()", [activeBotId, String(value57), String(value58), Number(value59?.count || 0), JSON.stringify(value59?.entries || [])]);
}
function mirrorModerator(value60, value61 = true) {
  if (value61) {
    return query("INSERT INTO sudoers (bot_id, user_id)\n       VALUES ($1, $2)\n       ON CONFLICT (bot_id, user_id) DO NOTHING", [activeBotId, String(value60)]);
  } else {
    return query("DELETE FROM sudoers WHERE bot_id = $1 AND user_id = $2", [activeBotId, String(value60)]);
  }
}
function mirrorMutedUser(value62, value63, value64 = true) {
  if (value64) {
    return query("INSERT INTO muted_users (bot_id, group_id, user_id)\n       VALUES ($1, $2, $3)\n       ON CONFLICT (bot_id, group_id, user_id) DO NOTHING", [activeBotId, String(value62), String(value63)]);
  } else {
    return query("DELETE FROM muted_users\n       WHERE bot_id = $1 AND group_id = $2 AND user_id = $3", [activeBotId, String(value62), String(value63)]);
  }
}
function mirrorKV(value65, value66, value67) {
  return query("INSERT INTO kv_store (bot_id, namespace, key, value)\n     VALUES ($1, $2, $3, $4::jsonb)\n     ON CONFLICT (bot_id, namespace, key)\n     DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()", [activeBotId, String(value65), String(value66), JSON.stringify(value67)]);
}
function deleteKV(value68, value69) {
  return query("DELETE FROM kv_store WHERE bot_id = $1 AND namespace = $2 AND key = $3", [activeBotId, String(value68), String(value69)]);
}
function mirrorProfile(value70, value71, value72) {
  return query("INSERT INTO chatbot_profiles (bot_id, profile_bot_id, user_id, profile)\n     VALUES ($1, $2, $3, $4::jsonb)\n     ON CONFLICT (bot_id, profile_bot_id, user_id)\n     DO UPDATE SET profile = EXCLUDED.profile, updated_at = NOW()", [activeBotId, String(value70 || "default"), String(value71), JSON.stringify(value72 || {})]);
}
function mirrorAuthState(value73) {
  const value74 = value73 || {};
  return query("INSERT INTO session_auth_state (bot_id, session_creds, session_keys, session_auth_meta)\n     VALUES ($1, $2::jsonb, $3::jsonb, $4::jsonb)\n     ON CONFLICT (bot_id)\n     DO UPDATE SET\n       session_creds = EXCLUDED.session_creds,\n       session_keys = EXCLUDED.session_keys,\n       session_auth_meta = EXCLUDED.session_auth_meta,\n       updated_at = NOW()", [activeBotId, JSON.stringify(Array.isArray(value74.sessionCreds) ? value74.sessionCreds : []), JSON.stringify(Array.isArray(value74.sessionKeys) ? value74.sessionKeys : []), JSON.stringify(Array.isArray(value74.sessionAuthMeta) ? value74.sessionAuthMeta : [])]).then(value75 => {
    if (!value75) {
      return value75;
    }
    return deleteLegacyAuthRecord().then(() => value75);
  });
}
async function fetchAuthState() {
  const value76 = await query("SELECT session_creds, session_keys, session_auth_meta, updated_at\n     FROM session_auth_state\n     WHERE bot_id = $1\n     LIMIT 1", [activeBotId]);
  const value77 = value76?.rows?.[0];
  if (!value77) {
    return null;
  }
  return {
    snapshot: {
      version: 1,
      createdAt: value77.updated_at ? new Date(value77.updated_at).getTime() : 0,
      sessionCreds: value77.session_creds,
      sessionKeys: value77.session_keys,
      sessionAuthMeta: value77.session_auth_meta
    },
    updatedAt: value77.updated_at ? new Date(value77.updated_at).getTime() : 0,
    source: "postgres"
  };
}
function deleteAuthState() {
  return query("DELETE FROM session_auth_state WHERE bot_id = $1", [activeBotId]);
}
function deleteLegacyAuthRecord() {
  return query("DELETE FROM bot_configs WHERE bot_id = $1 AND key = $2", [activeBotId, LEGACY_AUTH_RECORD_KEY]);
}
function restoreIntoSQLite(value78) {
  if (!ready || !pool || !value78) {
    return Promise.resolve({
      restored: 0,
      skipped: "pg_unavailable"
    });
  }
  return (async () => {
    let value79 = 0;
    const value80 = await pool.query("SELECT table_name, payload\n       FROM june_restore_snapshot($1)", [activeBotId]);
    if (!value80?.rows) {
      return {
        restored: 0,
        skipped: "no_remote_rows"
      };
    }
    const value81 = value78.transaction(() => {
      for (const value82 of value80.rows) {
        const value83 = value82.payload || {};
        if (value82.table_name === "bot_configs") {
          if (value83.key === LEGACY_AUTH_RECORD_KEY) {
            continue;
          }
          const value84 = value78.prepare("SELECT 1 FROM bot_settings WHERE key = ?").get(value83.key);
          if (!value84) {
            value78.prepare("INSERT INTO bot_settings (key, value) VALUES (?, ?)").run(value83.key, JSON.stringify(value83.value));
            value79++;
          }
        } else if (value82.table_name === "group_stats") {
          const value85 = value78.prepare("SELECT 1 FROM group_stats WHERE group_id = ? AND date = ?").get(value83.group_id, value83.stat_date);
          if (!value85) {
            value78.prepare("INSERT INTO group_stats (group_id, date, data) VALUES (?, ?, ?)").run(value83.group_id, value83.stat_date, JSON.stringify(value83.data || {}));
            value79++;
          }
        } else if (value82.table_name === "group_features" && value83.feature === "group-settings") {
          const value86 = value78.prepare("SELECT 1 FROM groups WHERE group_id = ?").get(value83.group_id);
          if (!value86) {
            value78.prepare("INSERT INTO groups (group_id, settings) VALUES (?, ?)").run(value83.group_id, JSON.stringify(value83.config || {}));
            value79++;
          }
        } else if (value82.table_name === "warnings") {
          const value87 = value78.prepare("SELECT 1 FROM warnings WHERE group_id = ? AND user_id = ?").get(value83.group_id, value83.user_id);
          if (!value87) {
            value78.prepare("INSERT INTO warnings (group_id, user_id, count, entries) VALUES (?, ?, ?, ?)").run(value83.group_id, value83.user_id, Number(value83.count || 0), JSON.stringify(value83.reasons || []));
            value79++;
          }
        } else if (value82.table_name === "sudoers") {
          const value88 = value78.prepare("SELECT 1 FROM moderators WHERE user_id = ?").get(value83.user_id);
          if (!value88) {
            value78.prepare("INSERT INTO moderators (user_id) VALUES (?)").run(value83.user_id);
            value79++;
          }
        } else if (value82.table_name === "kv_store") {
          if (value83.namespace === "runtime_telemetry" && value83.value?.eventType) {
            const value89 = value83.value;
            const value90 = value78.prepare("SELECT 1 FROM runtime_telemetry WHERE event_type = ? AND event_key = ?").get(value89.eventType, value89.eventKey);
            if (!value90) {
              value78.prepare("\n                INSERT INTO runtime_telemetry\n                  (event_type, event_key, payload, count, first_seen, last_seen)\n                VALUES (?, ?, ?, ?, ?, ?)\n              ").run(value89.eventType, value89.eventKey, JSON.stringify(value89.payload || {}), Number(value89.count || 1), Number(value89.firstSeen || Date.now()), Number(value89.lastSeen || Date.now()));
              value79++;
            }
            continue;
          }
          const value91 = value78.prepare("SELECT 1 FROM kv_store WHERE namespace = ? AND key = ?").get(value83.namespace, value83.key);
          if (!value91) {
            value78.prepare("INSERT INTO kv_store (namespace, key, value) VALUES (?, ?, ?)").run(value83.namespace, value83.key, JSON.stringify(value83.value));
            value79++;
          }
        } else if (value82.table_name === "chatbot_profiles") {
          const value92 = value78.prepare("SELECT 1 FROM chat_profiles WHERE bot_id = ? AND user_id = ?").get(value83.profile_bot_id, value83.user_id);
          if (!value92) {
            value78.prepare("INSERT INTO chat_profiles (bot_id, user_id, profile) VALUES (?, ?, ?)").run(value83.profile_bot_id, value83.user_id, JSON.stringify(value83.profile || {}));
            value79++;
          }
        } else if (value82.table_name === "users") {
          const value93 = value78.prepare("SELECT 1 FROM users WHERE user_id = ?").get(value83.user_id);
          if (!value93) {
            value78.prepare("INSERT INTO users (user_id, data) VALUES (?, ?)").run(value83.user_id, JSON.stringify(value83.data || {}));
            value79++;
          }
        } else if (value82.table_name === "muted_users") {
          const value94 = value78.prepare("SELECT 1 FROM muted_users WHERE group_id = ? AND user_id = ?").get(value83.group_id, value83.user_id);
          if (!value94) {
            value78.prepare("INSERT INTO muted_users (group_id, user_id) VALUES (?, ?)").run(value83.group_id, value83.user_id);
            value79++;
          }
        } else if (value82.table_name === "antidelete_messages") {
          const value95 = value78.prepare("SELECT 1 FROM antidelete_messages WHERE chat_id = ? AND message_id = ?").get(value83.chat_id, value83.message_id);
          if (!value95) {
            value78.prepare("INSERT INTO antidelete_messages (chat_id, message_id, payload, stored_at) VALUES (?, ?, ?, ?)").run(value83.chat_id, value83.message_id, JSON.stringify(value83.payload || {}), Number(value83.stored_at || Date.now()));
            value79++;
          }
        } else if (value82.table_name === "antidelete_statuses") {
          const value96 = value78.prepare("SELECT 1 FROM antidelete_statuses WHERE status_id = ?").get(value83.status_id);
          if (!value96) {
            value78.prepare("INSERT INTO antidelete_statuses (status_id, payload, stored_at) VALUES (?, ?, ?)").run(value83.status_id, JSON.stringify(value83.payload || {}), Number(value83.stored_at || Date.now()));
            value79++;
          }
        } else if (value82.table_name === "lid_map") {
          const value97 = value78.prepare("SELECT 1 FROM lid_map WHERE direction = ? AND user = ?").get(value83.direction, value83.user);
          if (!value97) {
            value78.prepare("INSERT INTO lid_map (direction, user, value, updated_at) VALUES (?, ?, ?, ?)").run(value83.direction, value83.user, value83.value, Number(value83.updated_at || Date.now()));
            value79++;
          }
        }
      }
    });
    value81();
    return {
      restored: value79,
      botId: activeBotId
    };
  })().catch(value98 => {
    lastError = value98.message;
    console.warn("[PG] Restore skipped: " + value98.message);
    return {
      restored: 0,
      error: value98.message
    };
  });
}
async function close() {
  if (!pool) {
    return;
  }
  const value99 = pool;
  pool = null;
  ready = false;
  schemaReady = false;
  try {
    await value99.end();
  } catch (error100) {}
}
const KIND_TABLE = {
  "bot-setting": {
    table: "bot_configs",
    where: "bot_id = $1 AND key != $2",
    extra: [LEGACY_AUTH_RECORD_KEY]
  },
  "group-settings": {
    table: "group_features",
    where: "bot_id = $1 AND feature = 'group-settings'",
    extra: []
  },
  "group-stat": {
    table: "group_stats",
    where: "bot_id = $1",
    extra: []
  },
  user: {
    table: "users",
    where: "bot_id = $1",
    extra: []
  },
  warning: {
    table: "warnings",
    where: "bot_id = $1",
    extra: []
  },
  moderator: {
    table: "sudoers",
    where: "bot_id = $1",
    extra: []
  },
  "muted-user": {
    table: "muted_users",
    where: "bot_id = $1",
    extra: []
  },
  kv: {
    table: "kv_store",
    where: "bot_id = $1",
    extra: []
  },
  "antidelete-message": {
    table: "antidelete_messages",
    where: "bot_id = $1",
    extra: []
  },
  "antidelete-status": {
    table: "antidelete_statuses",
    where: "bot_id = $1",
    extra: []
  },
  "chat-profile": {
    table: "chatbot_profiles",
    where: "bot_id = $1",
    extra: []
  },
  "lid-map": {
    table: "lid_map",
    where: "bot_id = $1",
    extra: []
  }
};
async function clearKind(value101) {
  if (!ready || !pool) {
    return {
      ok: false,
      reason: "unavailable"
    };
  }
  const value102 = KIND_TABLE[value101];
  if (!value102) {
    return {
      ok: false,
      reason: "unknown-kind"
    };
  }
  try {
    const value103 = [activeBotId, ...(value102.extra || [])];
    const value104 = await query("DELETE FROM " + value102.table + " WHERE " + value102.where, value103);
    return {
      ok: true,
      deleted: value104?.rowCount || 0
    };
  } catch (error105) {
    lastError = error105?.message || String(error105);
    return {
      ok: false,
      reason: lastError
    };
  }
}
module.exports = {
  init: init,
  query: query,
  close: close,
  getBotId: getBotId,
  setBotId: setBotId,
  buildBotId: buildBotId,
  getStatus: getStatus,
  mirrorBotSetting: mirrorBotSetting,
  mirrorGroupSettings: mirrorGroupSettings,
  mirrorGroupStat: mirrorGroupStat,
  mirrorUser: mirrorUser,
  mirrorAntideleteMessage: mirrorAntideleteMessage,
  deleteAntideleteMessage: deleteAntideleteMessage,
  mirrorAntideleteStatus: mirrorAntideleteStatus,
  deleteAntideleteStatus: deleteAntideleteStatus,
  mirrorLidMap: mirrorLidMap,
  mirrorWarning: mirrorWarning,
  mirrorModerator: mirrorModerator,
  mirrorMutedUser: mirrorMutedUser,
  mirrorKV: mirrorKV,
  deleteKV: deleteKV,
  mirrorProfile: mirrorProfile,
  mirrorAuthState: mirrorAuthState,
  fetchAuthState: fetchAuthState,
  deleteAuthState: deleteAuthState,
  deleteLegacyAuthRecord: deleteLegacyAuthRecord,
  restoreIntoSQLite: restoreIntoSQLite,
  clearKind: clearKind
};
