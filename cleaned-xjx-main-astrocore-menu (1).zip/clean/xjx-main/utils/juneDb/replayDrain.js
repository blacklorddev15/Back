'use strict';

const INITIAL_DRAIN_MS = Math.max(10000, Number(process.env.JUNE_REPLAY_DRAIN_MS) || 45000);
const MAX_DRAIN_MS = Math.max(INITIAL_DRAIN_MS, Number(process.env.JUNE_REPLAY_DRAIN_MAX_MS) || 180000);
const OLD_MESSAGE_MS = Math.max(5000, Number(process.env.JUNE_REPLAY_AGE_MS) || 30000);
const BURST_THRESHOLD = Math.max(5, Number(process.env.JUNE_REPLAY_BURST_THRESHOLD) || 15);
const BURST_EXTENSION_MS = Math.max(1000, Number(process.env.JUNE_REPLAY_EXTENSION_MS) || 8000);
const QUIET_WINDOWS_REQUIRED = Math.max(1, Number(process.env.JUNE_REPLAY_QUIET_WINDOWS) || 3);
let active = false;
let openedAt = 0;
let drainEndsAt = 0;
let hardCapAt = 0;
let burstWindowAt = 0;
let burstCount = 0;
let quietWindows = 0;
let dropped = 0;
let passed = 0;
function messageTimestampMs(value1) {
  const value2 = value1?.messageTimestamp;
  if (!value2) {
    return 0;
  }
  const value3 = typeof value2 === "object" ? Number(value2.low || 0) : Number(value2);
  if (Number.isFinite(value3) && value3 > 0) {
    return value3 * 1000;
  } else {
    return 0;
  }
}
function markConnectionOpen() {
  const value4 = Date.now();
  active = true;
  openedAt = value4;
  drainEndsAt = value4 + INITIAL_DRAIN_MS;
  hardCapAt = value4 + MAX_DRAIN_MS;
  burstWindowAt = value4;
  burstCount = 0;
  quietWindows = 0;
  dropped = 0;
  passed = 0;
}
function finishDrain() {
  active = false;
}
function isReplayMessage(value5) {
  if (!active) {
    return false;
  }
  const value6 = Date.now();
  if (value6 >= drainEndsAt || value6 >= hardCapAt) {
    finishDrain();
    return false;
  }
  const value7 = messageTimestampMs(value5);
  if (!value7) {
    return false;
  }
  const value8 = value6 - value7;
  if (value8 <= OLD_MESSAGE_MS) {
    passed += 1;
    quietWindows = 0;
    return false;
  }
  if (value6 - burstWindowAt >= 1000) {
    if (burstCount >= BURST_THRESHOLD) {
      drainEndsAt = Math.min(hardCapAt, Math.max(drainEndsAt, value6 + BURST_EXTENSION_MS));
      quietWindows = 0;
    } else {
      quietWindows += 1;
      if (quietWindows >= QUIET_WINDOWS_REQUIRED) {
        finishDrain();
        return true;
      }
    }
    burstWindowAt = value6;
    burstCount = 0;
  }
  burstCount += 1;
  dropped += 1;
  return true;
}
function getStats() {
  const value9 = Date.now();
  const value10 = Math.min(drainEndsAt, hardCapAt);
  return {
    active: active && value9 < value10,
    openedAt: openedAt,
    remainingMs: active ? Math.max(0, value10 - value9) : 0,
    dropped: dropped,
    passed: passed,
    initialDrainMs: INITIAL_DRAIN_MS,
    maxDrainMs: MAX_DRAIN_MS
  };
}
module.exports = {
  markConnectionOpen: markConnectionOpen,
  isReplayMessage: isReplayMessage,
  getStats: getStats
};
