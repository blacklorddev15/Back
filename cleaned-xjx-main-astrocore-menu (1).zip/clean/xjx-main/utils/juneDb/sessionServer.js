'use strict';

const crypto = require("crypto");
const zlib = require("zlib");
let BufferJSON = null;
try {
  ({
    BufferJSON
  } = require("@whiskeysockets/baileys/lib/Utils/generics"));
} catch (error1) {}
const DEFAULT_SESSION_SERVER_URL = "https://burning-lorena-eminentbo-ede53cc1.koyeb.app";
const DEFAULT_TIMEOUT_MS = 20000;
const HANDLE_PATTERN = /^JUNE-X~[A-Za-z0-9]{4,20}$/i;
const HANDLE_BODY_STRIP = /^june-x~/i;
const AUTH_KEY_TYPES = ["app-state-sync-version", "app-state-sync-key", "sender-key-memory", "sender-key", "identity-key", "device-list", "lid-mapping", "pre-key", "session", "tctoken"];
class SessionServerError extends Error {
  constructor(value2, {
    status = 0,
    code = "request_failed"
  } = {}) {
    super(value2);
    this.name = "SessionServerError";
    this.status = status;
    this.code = code;
    this.retryable = status === 0 || status === 408 || status === 429 || status >= 500;
    this.terminal = ["session_revoked", "session_state_missing"].includes(code);
  }
}
function isJuneHandle(value3) {
  return HANDLE_PATTERN.test(String(value3 || "").trim());
}
const handleBody = value4 => String(value4 || "").trim().replace(HANDLE_BODY_STRIP, "").toLowerCase();
function describeHandleProblem(value5) {
  const value6 = String(value5 || "").trim();
  if (!value6) {
    return "empty";
  }
  if (!/^june-x~/i.test(value6)) {
    return "missing JUNE-X~ prefix (expected JUNE-X~ + 4-20 letters/digits)";
  }
  const value7 = value6.slice(7);
  if (value7.length < 4 || value7.length > 20) {
    return "bad length (" + value7.length + " after ~, expected 4-20)";
  }
  if (!/^[A-Za-z0-9]+$/.test(value7)) {
    return "bad charset (only letters/digits allowed after JUNE-X~)";
  }
  return "valid (no problem detected)";
}
function getServerUrl() {
  const value8 = String(process.env.JUNE_SESSION_SERVER_URL || "").trim().replace(/\/+$/, "");
  return value8 || DEFAULT_SESSION_SERVER_URL;
}
function getConfiguredToken() {
  const value9 = String(process.env.SESSION_ID || "").trim();
  if (isJuneHandle(value9)) {
    return value9;
  } else {
    return "";
  }
}
function isTokenModeActive() {
  if (state.offlineMode) {
    return false;
  }
  return isJuneHandle(getConfiguredToken());
}
function markOfflineMode() {
  state.offlineMode = true;
}
function sha256Hex(value10) {
  return crypto.createHash("sha256").update(String(value10)).digest("hex");
}
function handleBotIdSuffix(value11) {
  const value12 = String(value11 || "").trim();
  if (!isJuneHandle(value12)) {
    return null;
  }
  return sha256Hex(handleBody(value12)).slice(0, 12);
}
const state = {
  leaseToken: null,
  leaseExpiresAt: 0,
  sessionId: null,
  sessionMeta: null,
  everAuthenticated: false,
  lastDb: null,
  authPromise: null,
  revoked: false,
  offlineMode: false
};
async function authenticate({
  db = null
} = {}) {
  if (state.revoked) {
    throw new SessionServerError("Session was revoked", {
      code: "session_revoked"
    });
  }
  if (state.authPromise) {
    return state.authPromise;
  }
  if (db) {
    state.lastDb = db;
  }
  const value13 = getConfiguredToken();
  const value14 = getServerUrl();
  if (!isJuneHandle(value13)) {
    throw new SessionServerError("No valid JUNE-X~ Session ID configured in SESSION_ID");
  }
  if (!value14) {
    throw new SessionServerError("Session Server URL is not configured");
  }
  state.authPromise = Promise.resolve().then(() => {
    state.leaseToken = value13;
    state.leaseExpiresAt = Date.now() + 1200000;
    state.sessionId = null;
    state.sessionMeta = null;
    state.everAuthenticated = true;
    return {
      session: null,
      lease: {
        token: value13,
        expiresAt: state.leaseExpiresAt
      }
    };
  }).finally(() => {
    state.authPromise = null;
  });
  return state.authPromise;
}
function isAuthenticated() {
  return Boolean(state.leaseToken && Date.now() < state.leaseExpiresAt);
}
function validateSnapshot(value15) {
  if (!value15 || typeof value15 !== "object") {
    return null;
  }
  const value16 = Array.isArray(value15.sessionCreds) ? value15.sessionCreds : null;
  const value17 = Array.isArray(value15.sessionKeys) ? value15.sessionKeys : null;
  const value18 = Array.isArray(value15.sessionAuthMeta) ? value15.sessionAuthMeta : null;
  if (!value16 || !value17 || !value18) {
    return null;
  }
  if (!value16.some(value19 => value19?.key === "creds" && typeof value19.value === "string")) {
    return null;
  }
  if (value18.find(value20 => value20?.key === "status")?.value !== "verified") {
    return null;
  }
  if (!value16.every(value21 => typeof value21?.key === "string" && typeof value21?.value === "string")) {
    return null;
  }
  if (!value17.every(value22 => typeof value22?.type === "string" && typeof value22?.id === "string" && typeof value22?.value === "string")) {
    return null;
  }
  if (!value18.every(value23 => typeof value23?.key === "string" && typeof value23?.value === "string")) {
    return null;
  }
  return {
    creds: value16,
    keys: value17,
    meta: value18
  };
}
function restoreSnapshotIntoSQLite(value24, value25) {
  const value26 = Date.now();
  const value27 = value24.prepare("\n    INSERT INTO session_creds (key, value, updated_at) VALUES (?, ?, ?)\n    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at\n  ");
  const value28 = value24.prepare("\n    INSERT INTO session_keys (type, id, value, updated_at) VALUES (?, ?, ?, ?)\n    ON CONFLICT(type, id) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at\n  ");
  const value29 = value24.prepare("\n    INSERT INTO session_auth_meta (key, value) VALUES (?, ?)\n    ON CONFLICT(key) DO UPDATE SET value = excluded.value\n  ");
  const value30 = value24.transaction(() => {
    value24.prepare("DELETE FROM session_creds").run();
    value24.prepare("DELETE FROM session_keys").run();
    value24.prepare("DELETE FROM session_auth_meta").run();
    for (const value31 of value25.creds) {
      value27.run(value31.key, value31.value, Number(value31.updated_at || value26));
    }
    for (const value32 of value25.keys) {
      value28.run(value32.type, value32.id, value32.value, Number(value32.updated_at || value26));
    }
    for (const value33 of value25.meta) {
      value29.run(value33.key, value33.value);
    }
  });
  value30();
  return {
    credentialRows: value25.creds.length,
    keyRows: value25.keys.length,
    metaRows: value25.meta.length
  };
}
function parseAuthKeyFilename(value34) {
  if (!value34.endsWith(".json") || value34 === "creds.json") {
    return null;
  }
  const value35 = value34.slice(0, -".json".length);
  const value36 = AUTH_KEY_TYPES.find(value37 => value35.startsWith(value37 + "-"));
  if (!value36) {
    return null;
  }
  const value38 = value35.slice(value36.length + 1).replace(/__/g, "/").replace(/-/g, ":");
  if (value38) {
    return {
      type: value36,
      id: value38
    };
  } else {
    return null;
  }
}
function filesToSnapshot(value39) {
  const value40 = Date.now();
  const value41 = value42 => {
    try {
      const value43 = JSON.parse(JSON.stringify(value42), BufferJSON.reviver);
      return JSON.parse(JSON.stringify(value43, BufferJSON.replacer));
    } catch (error44) {
      return value42;
    }
  };
  const value45 = value39 ? value41(value39["creds.json"]) : null;
  if (!value45 || typeof value45 !== "object") {
    return null;
  }
  const value46 = [{
    key: "creds",
    value: JSON.stringify(value45),
    updated_at: value40
  }];
  const value47 = [];
  for (const [value48, value49] of Object.entries(value39 || {})) {
    if (value48 === "creds.json") {
      continue;
    }
    const value50 = parseAuthKeyFilename(value48);
    if (!value50 || !value49 || typeof value49 !== "object") {
      continue;
    }
    value47.push({
      type: value50.type,
      id: value50.id,
      value: JSON.stringify(value41(value49)),
      updated_at: value40
    });
  }
  const value51 = [{
    key: "status",
    value: "verified"
  }, {
    key: "source",
    value: "june-session-server"
  }];
  return {
    creds: value46,
    keys: value47,
    meta: value51
  };
}
async function fetchAndRestoreSnapshot(value52) {
  const value53 = getConfiguredToken();
  if (!isJuneHandle(value53)) {
    throw new SessionServerError("No valid JUNE-X~ Session ID configured in SESSION_ID");
  }
  const value54 = getServerUrl();
  let value55;
  try {
    value55 = await fetch(value54 + "/session/" + encodeURIComponent(value53), {
      headers: {
        Accept: "text/plain"
      },
      signal: AbortSignal.timeout(DEFAULT_TIMEOUT_MS)
    });
  } catch (error56) {
    throw new SessionServerError("Session Server unreachable: " + error56.message);
  }
  const value57 = (await value55.text()).trim();
  if (!value55.ok) {
    throw new SessionServerError("This Session ID is unknown or was revoked", {
      code: "session_revoked",
      status: value55.status
    });
  }
  let value58 = value57;
  const value59 = value58.indexOf("~");
  if (value59 >= 0) {
    value58 = value58.slice(value59 + 1);
  }
  let value60;
  try {
    value60 = JSON.parse(zlib.gunzipSync(Buffer.from(value58, "base64")).toString("utf8"));
  } catch (error61) {
    throw new SessionServerError("Session Server returned an invalid session blob", {
      code: "session_state_missing"
    });
  }
  const value62 = filesToSnapshot({
    "creds.json": value60
  });
  if (!value62) {
    throw new SessionServerError("Session Server returned an invalid session blob", {
      code: "session_state_missing"
    });
  }
  state.offlineMode = true;
  state.leaseToken = null;
  state.leaseExpiresAt = 0;
  const value63 = restoreSnapshotIntoSQLite(value52, value62);
  return {
    ...value63,
    version: null,
    sessionId: null
  };
}
async function revokeSession(value64 = "whatsapp-logout") {
  if (state.revoked) {
    return {
      revoked: false,
      skipped: "already-revoked"
    };
  }
  state.revoked = true;
  state.leaseToken = null;
  state.leaseExpiresAt = 0;
  return {
    revoked: true,
    localOnly: true,
    reason: value64
  };
}
function getStatus() {
  return {
    tokenMode: isTokenModeActive(),
    serverConfigured: Boolean(getServerUrl()),
    authenticated: isAuthenticated(),
    sessionId: state.sessionId,
    sessionMeta: state.sessionMeta
  };
}
module.exports = {
  HANDLE_PATTERN: HANDLE_PATTERN,
  DEFAULT_SESSION_SERVER_URL: DEFAULT_SESSION_SERVER_URL,
  isJuneHandle: isJuneHandle,
  describeHandleProblem: describeHandleProblem,
  getServerUrl: getServerUrl,
  getConfiguredToken: getConfiguredToken,
  isTokenModeActive: isTokenModeActive,
  markOfflineMode: markOfflineMode,
  sha256Hex: sha256Hex,
  handleBotIdSuffix: handleBotIdSuffix,
  authenticate: authenticate,
  isAuthenticated: isAuthenticated,
  filesToSnapshot: filesToSnapshot,
  restoreSnapshotIntoSQLite: restoreSnapshotIntoSQLite,
  validateSnapshot: validateSnapshot,
  fetchAndRestoreSnapshot: fetchAndRestoreSnapshot,
  SessionServerError: SessionServerError,
  revokeSession: revokeSession,
  getStatus: getStatus
};
