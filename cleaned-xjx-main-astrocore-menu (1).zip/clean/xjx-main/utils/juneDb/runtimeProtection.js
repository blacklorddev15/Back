'use strict';

const fs = require("fs");
const path = require("path");
const os = require("os");
function atomicWriteFile(value1, value2, value3 = "utf8") {
  const value4 = path.resolve(value1);
  const value5 = path.dirname(value4);
  fs.mkdirSync(value5, {
    recursive: true
  });
  const value6 = value4 + ".tmp-" + process.pid + "-" + Date.now();
  try {
    fs.writeFileSync(value6, value2, value3);
    fs.renameSync(value6, value4);
  } finally {
    try {
      fs.rmSync(value6, {
        force: true
      });
    } catch (error7) {}
  }
}
function boundedMap(value8, value9) {
  if (!(value8 instanceof Map) || value8.size <= value9) {
    return;
  }
  while (value8.size > value9) {
    value8.delete(value8.keys().next().value);
  }
}
function pruneMap(value10, value11, value12 = Date.now()) {
  if (!(value10 instanceof Map)) {
    return;
  }
  for (const [value13, value14] of value10) {
    const value15 = value14?.timestamp ?? value14?.ts ?? value14?.updatedAt ?? 0;
    if (value15 && value12 - value15 > value11) {
      value10.delete(value13);
    }
  }
}
function directorySize(value16) {
  let value17 = 0;
  try {
    for (const value18 of fs.readdirSync(value16, {
      withFileTypes: true
    })) {
      const value19 = path.join(value16, value18.name);
      try {
        value17 += value18.isDirectory() ? directorySize(value19) : fs.statSync(value19).size;
      } catch (error20) {}
    }
  } catch (error21) {}
  return value17;
}
function diskFreeBytes(value22 = process.cwd()) {
  try {
    if (typeof fs.statfsSync === "function") {
      const value23 = fs.statfsSync(value22);
      return Number(value23.bavail) * Number(value23.bsize);
    }
  } catch (error24) {}
  return null;
}
function createDiskManager(value25 = {}) {
  const value26 = path.resolve(value25.root || process.cwd());
  const value27 = Number(value25.minimumFreeBytes) || (Number(process.env.JUNE_MIN_FREE_MB) || 100) * 1024 * 1024;
  const value28 = Number(value25.intervalMs) || Number(process.env.JUNE_DISK_CHECK_MS) || 300000;
  const value29 = typeof value25.cleanup === "function" ? value25.cleanup : () => {};
  const value30 = Number(value25.cleanupCooldownMs) || Number(process.env.JUNE_DISK_CLEANUP_COOLDOWN_MS) || 900000;
  let value31 = null;
  let value32 = {
    freeBytes: null,
    low: false,
    checkedAt: null,
    cleanupAt: null
  };
  let value33 = false;
  const value34 = (value35 = false) => {
    const value36 = Date.now();
    const value37 = diskFreeBytes(value26);
    const value38 = value37 !== null && value37 < value27;
    const value39 = value38 && !value32.low;
    const value40 = value38 && (value35 || value39 || !value32.cleanupAt || value36 - value32.cleanupAt >= value30);
    value32 = {
      ...value32,
      freeBytes: value37,
      low: value38,
      checkedAt: value36
    };
    if (value40) {
      try {
        const value41 = value29({
          aggressive: true,
          freeBytes: value37,
          minimumFreeBytes: value27
        });
        Promise.resolve(value41).catch(() => {});
        value32.cleanupAt = value36;
      } catch (error42) {}
    }
    return value32;
  };
  return {
    start() {
      if (value33) {
        return;
      }
      value33 = true;
      value34();
      value31 = setInterval(() => value34(), value28);
      value31.unref?.();
    },
    stop() {
      if (value31) {
        clearInterval(value31);
      }
      value31 = null;
      value33 = false;
    },
    check: value34,
    emergencyCleanup() {
      return value34(true);
    },
    getStatus() {
      return {
        ...value32,
        minimumFreeBytes: value27,
        cleanupCooldownMs: value30,
        root: value26
      };
    },
    getReport() {
      return {
        ...this.getStatus(),
        rootBytes: directorySize(value26),
        tmpBytes: directorySize(os.tmpdir())
      };
    }
  };
}
function createTelemetryStore(value43 = {}) {
  const value44 = Number(value43.maxEntries) || 500;
  const value45 = [];
  const value46 = (value47, value48 = {}) => {
    value45.push({
      type: value47,
      data: value48,
      timestamp: Date.now()
    });
    if (value45.length > value44) {
      value45.splice(0, value45.length - value44);
    }
  };
  return {
    record: value46,
    list(value49 = 50) {
      return value45.slice(-Math.max(0, Number(value49) || 0));
    },
    stats() {
      const value50 = {};
      for (const value51 of value45) {
        value50[value51.type] = (value50[value51.type] || 0) + 1;
      }
      return {
        total: value45.length,
        counts: value50,
        last: value45.at(-1) || null
      };
    }
  };
}
module.exports = {
  atomicWriteFile: atomicWriteFile,
  boundedMap: boundedMap,
  pruneMap: pruneMap,
  directorySize: directorySize,
  diskFreeBytes: diskFreeBytes,
  createDiskManager: createDiskManager,
  createTelemetryStore: createTelemetryStore
};
