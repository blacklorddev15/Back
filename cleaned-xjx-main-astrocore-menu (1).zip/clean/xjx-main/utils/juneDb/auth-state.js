'use strict';

const fs = require("fs");
const path = require("path");
const AUTH_META = {
  status: "status",
  sourceKeyFiles: "source_key_files",
  databaseKeyRows: "database_key_rows",
  sourceJsonFiles: "source_json_files",
  quarantinedPath: "quarantined_path",
  migratedAt: "migrated_at",
  pendingFileMigration: "pending_file_migration",
  sessionIdFingerprint: "session_id_fingerprint",
  sessionIdRevokedFingerprint: "session_id_revoked_fingerprint",
  authSource: "auth_source",
  authConnectionVerified: "auth_connection_verified"
};
const KEY_TYPES = ["app-state-sync-version", "app-state-sync-key", "sender-key-memory", "sender-key", "identity-key", "device-list", "lid-mapping", "pre-key", "session", "tctoken"];
const CORE_KEY_TYPES = new Set(["pre-key", "session", "identity-key", "sender-key", "sender-key-memory", "app-state-sync-key"]);
let baileysDepsPromise = null;
async function getBaileysDeps() {
  if (!baileysDepsPromise) {
    baileysDepsPromise = import("@whiskeysockets/baileys").then(value1 => ({
      proto: value1.proto,
      BufferJSON: value1.BufferJSON,
      initAuthCreds: value1.initAuthCreds
    }));
  }
  return baileysDepsPromise;
}
function ensureAuthSchema(value2) {
  value2.exec("\n    CREATE TABLE IF NOT EXISTS session_creds (\n      key        TEXT PRIMARY KEY,\n      value      TEXT NOT NULL,\n      updated_at INTEGER NOT NULL\n    );\n    CREATE TABLE IF NOT EXISTS session_keys (\n      type       TEXT NOT NULL,\n      id         TEXT NOT NULL,\n      value      TEXT NOT NULL,\n      updated_at INTEGER NOT NULL,\n      PRIMARY KEY (type, id)\n    );\n    CREATE INDEX IF NOT EXISTS idx_session_keys_type ON session_keys(type);\n    CREATE TABLE IF NOT EXISTS session_auth_meta (\n      key   TEXT PRIMARY KEY,\n      value TEXT NOT NULL\n    );\n  ");
}
function setMeta(value3, value4, value5) {
  if (value5 === null || value5 === undefined) {
    value3.prepare("DELETE FROM session_auth_meta WHERE key = ?").run(value4);
    return;
  }
  value3.prepare("\n    INSERT INTO session_auth_meta (key, value) VALUES (?, ?)\n    ON CONFLICT(key) DO UPDATE SET value = excluded.value\n  ").run(value4, String(value5));
}
function getMeta(value6, value7) {
  const value8 = value6.prepare("SELECT value FROM session_auth_meta WHERE key = ?").get(value7)?.value;
  if (value8 === undefined || value8 === "" || value8 === "null") {
    return null;
  } else {
    return value8;
  }
}
function getSessionIdFingerprint(value9) {
  ensureAuthSchema(value9);
  return getMeta(value9, AUTH_META.sessionIdFingerprint);
}
function setSessionIdFingerprint(value10, value11) {
  ensureAuthSchema(value10);
  setMeta(value10, AUTH_META.sessionIdFingerprint, value11 || null);
}
function getSessionIdRevokedFingerprint(value12) {
  ensureAuthSchema(value12);
  return getMeta(value12, AUTH_META.sessionIdRevokedFingerprint);
}
function setSessionIdRevokedFingerprint(value13, value14) {
  ensureAuthSchema(value13);
  setMeta(value13, AUTH_META.sessionIdRevokedFingerprint, value14 || null);
}
function getAuthSource(value15) {
  ensureAuthSchema(value15);
  return getMeta(value15, AUTH_META.authSource);
}
function setAuthSource(value16, value17) {
  ensureAuthSchema(value16);
  setMeta(value16, AUTH_META.authSource, value17 || null);
}
function isAuthConnectionVerified(value18) {
  ensureAuthSchema(value18);
  return getMeta(value18, AUTH_META.authConnectionVerified) === "1";
}
function setAuthConnectionVerified(value19, value20) {
  ensureAuthSchema(value19);
  setMeta(value19, AUTH_META.authConnectionVerified, value20 ? "1" : "0");
}
function isLocallyVerifiedAuth(value21) {
  ensureAuthSchema(value21);
  const value22 = getMeta(value21, AUTH_META.authConnectionVerified);
  if (value22 === "1") {
    return true;
  }
  if (value22 === "0") {
    return false;
  }
  return getMeta(value21, AUTH_META.authSource) === null;
}
function getSQLiteAuthStats(value23) {
  ensureAuthSchema(value23);
  const value24 = value23.prepare("SELECT type, COUNT(*) AS count FROM session_keys GROUP BY type ORDER BY type").all();
  return {
    verified: getMeta(value23, AUTH_META.status) === "verified",
    hasCreds: !!value23.prepare("SELECT 1 FROM session_creds WHERE key = 'creds'").get(),
    totalKeys: value23.prepare("SELECT COUNT(*) AS count FROM session_keys").get().count,
    sourceKeyFiles: Number(getMeta(value23, AUTH_META.sourceKeyFiles) || 0),
    databaseKeyRows: Number(getMeta(value23, AUTH_META.databaseKeyRows) || 0),
    sourceJsonFiles: Number(getMeta(value23, AUTH_META.sourceJsonFiles) || 0),
    quarantinedPath: getMeta(value23, AUTH_META.quarantinedPath),
    migratedAt: getMeta(value23, AUTH_META.migratedAt),
    pendingFileMigration: getMeta(value23, AUTH_META.pendingFileMigration) === "1",
    invalidReason: getMeta(value23, "invalid_reason"),
    byType: value24
  };
}
function hasVerifiedSQLiteAuth(value25) {
  const value26 = getSQLiteAuthStats(value25);
  return value26.verified && value26.hasCreds;
}
function invalidateSQLiteAuth(value27, value28 = "file-auth-priority") {
  ensureAuthSchema(value27);
  setMeta(value27, AUTH_META.status, "invalid");
  setMeta(value27, "invalid_reason", value28);
  setMeta(value27, AUTH_META.pendingFileMigration, "0");
}
function isObjectValue(value29) {
  return value29 !== null && typeof value29 === "object";
}
function removeInvalidLidMapping(value30, value31, value32, value33) {
  if (value31 !== "lid-mapping") {
    return false;
  }
  try {
    value30.prepare("DELETE FROM session_keys WHERE type = ? AND id = ?").run(value31, value32);
    setMeta(value30, "last_lid_mapping_repair_count", 1);
    setMeta(value30, "last_lid_mapping_repair_at", Date.now());
    if (typeof value33 === "function") {
      value33("auth-lid-mapping-repair");
    }
  } catch (error34) {}
  return true;
}
function parseKeyFilename(value35) {
  if (!value35.endsWith(".json") || value35 === "creds.json") {
    return null;
  }
  const value36 = value35.slice(0, -".json".length);
  const value37 = KEY_TYPES.find(value38 => value36.startsWith(value38 + "-"));
  if (!value37) {
    return null;
  }
  const value39 = value36.slice(value37.length + 1);
  if (!value39) {
    return null;
  }
  return {
    type: value37,
    id: value39.replace(/__/g, "/").replace(/-/g, ":")
  };
}
function copyToQuarantine(value40) {
  const value41 = value40 + ".quarantine-" + Date.now();
  fs.renameSync(value40, value41);
  return value41;
}
function defaultQuarantineRetentionDays() {
  const value42 = process.env.JUNE_SESSION_QUARANTINE_RETENTION_DAYS;
  if (value42 === undefined || String(value42).trim() === "") {
    return 1;
  }
  const value43 = Number(value42);
  if (Number.isFinite(value43)) {
    return value43;
  } else {
    return 1;
  }
}
function defaultQuarantineMaxCount() {
  const value44 = process.env.JUNE_SESSION_QUARANTINE_MAX_COUNT;
  if (value44 === undefined || String(value44).trim() === "") {
    return 3;
  }
  const value45 = Number(value44);
  if (Number.isFinite(value45)) {
    return Math.max(0, Math.floor(value45));
  } else {
    return 3;
  }
}
function cleanupSessionQuarantines(value46, value47 = defaultQuarantineRetentionDays(), value48 = defaultQuarantineMaxCount()) {
  const value49 = Number(value47);
  const value50 = Number(value48);
  const value51 = Number.isFinite(value49) && value49 > 0;
  const value52 = Number.isFinite(value50) && value50 > 0;
  if (!value51 && !value52) {
    return {
      enabled: false,
      retentionDays: value49,
      maxCount: value50,
      removed: [],
      skipped: "disabled"
    };
  }
  const value53 = path.dirname(value46);
  if (!fs.existsSync(value53)) {
    return {
      enabled: true,
      retentionDays: value49,
      maxCount: value50,
      removed: [],
      retained: 0
    };
  }
  const value54 = path.basename(value46);
  const value55 = value51 ? Date.now() - value49 * 24 * 60 * 60 * 1000 : null;
  const value56 = [];
  for (const value57 of fs.readdirSync(value53)) {
    if (!value57.startsWith(value54 + ".quarantine-") && !value57.startsWith(value54 + ".incomplete-")) {
      continue;
    }
    const value58 = path.join(value53, value57);
    try {
      const value59 = fs.statSync(value58);
      if (!value59.isDirectory()) {
        continue;
      }
      const value60 = Number(value57.match(/-(\d+)$/)?.[1] || 0);
      value56.push({
        path: value58,
        mtimeMs: value59.mtimeMs,
        stamp: value60
      });
    } catch (error61) {}
  }
  value56.sort((value62, value63) => value63.mtimeMs - value62.mtimeMs || value63.stamp - value62.stamp);
  const value64 = [];
  let value65 = 0;
  let value66 = 0;
  for (let value67 = 0; value67 < value56.length; value67 += 1) {
    const value68 = value56[value67];
    const value69 = value51 && value68.mtimeMs < value55;
    const value70 = value52 && value67 >= value50;
    if (!value69 && !value70) {
      continue;
    }
    try {
      fs.rmSync(value68.path, {
        recursive: true,
        force: true
      });
      value64.push(value68.path);
      if (value69) {
        value65 += 1;
      } else if (value70) {
        value66 += 1;
      }
    } catch (error71) {}
  }
  return {
    enabled: true,
    retentionDays: value49,
    maxCount: value50,
    removed: value64,
    retained: Math.max(0, value56.length - value64.length),
    removedByRetention: value65,
    removedByLimit: value66
  };
}
function getSessionQuarantineStats(value72) {
  const value73 = path.dirname(value72);
  const value74 = path.basename(value72);
  if (!fs.existsSync(value73)) {
    return {
      count: 0,
      newestAt: null,
      paths: []
    };
  }
  const value75 = [];
  for (const value76 of fs.readdirSync(value73)) {
    if (!value76.startsWith(value74 + ".quarantine-") && !value76.startsWith(value74 + ".incomplete-")) {
      continue;
    }
    const value77 = path.join(value73, value76);
    try {
      const value78 = fs.statSync(value77);
      if (value78.isDirectory()) {
        value75.push({
          path: value77,
          mtimeMs: value78.mtimeMs
        });
      }
    } catch (error79) {}
  }
  value75.sort((value80, value81) => value81.mtimeMs - value80.mtimeMs);
  return {
    count: value75.length,
    newestAt: value75[0]?.mtimeMs || null,
    paths: value75.map(value82 => value82.path)
  };
}
async function readStableJson(value83, value84, value85 = 3) {
  let value86 = null;
  for (let value87 = 0; value87 < value85; value87 += 1) {
    try {
      const value88 = fs.statSync(value83);
      const value89 = fs.readFileSync(value83, "utf8");
      const value90 = fs.statSync(value83);
      if (value88.size !== value90.size || value88.mtimeMs !== value90.mtimeMs) {
        value86 = new Error("file changed while it was being read");
      } else {
        return JSON.parse(value89, value84.reviver);
      }
    } catch (error91) {
      value86 = error91;
    }
    if (value87 < value85 - 1) {
      await new Promise(value92 => setTimeout(value92, 100));
    }
  }
  throw value86 || new Error("could not read JSON file");
}
async function migrateFilesToSQLite(value93, value94, value95 = {}) {
  const {
    BufferJSON: value96
  } = await getBaileysDeps();
  ensureAuthSchema(value93);
  if (!fs.existsSync(value94) || !fs.statSync(value94).isDirectory()) {
    throw new Error("AUTH_MIGRATION_NO_SESSION_DIR: " + value94);
  }
  const value97 = path.join(value94, "creds.json");
  if (!fs.existsSync(value97)) {
    throw new Error("AUTH_MIGRATION_NO_CREDS: creds.json is missing");
  }
  let value98;
  try {
    value98 = JSON.parse(fs.readFileSync(value97, "utf8"), value96.reviver);
    if (!value98 || typeof value98 !== "object") {
      throw new Error("credentials are not an object");
    }
  } catch (error99) {
    throw new Error("AUTH_MIGRATION_INVALID_CREDS: " + error99.message);
  }
  const value100 = fs.readdirSync(value94);
  const value101 = value100.map(parseKeyFilename).filter(Boolean);
  if (value101.length === 0) {
    throw new Error("AUTH_MIGRATION_NO_KEY_FILES: only creds.json is available");
  }
  const value102 = value100.filter(value103 => value103.endsWith(".json") && value103 !== "creds.json" && !parseKeyFilename(value103));
  if (value102.length > 0) {
    throw new Error("AUTH_MIGRATION_UNKNOWN_FILES: " + value102.join(", "));
  }
  const value104 = [];
  const value105 = [];
  for (const value106 of value101) {
    const value107 = value106.type + "-" + value106.id.replace(/\//g, "__").replace(/:/g, "-") + ".json";
    const value108 = value100.find(value109 => {
      const value110 = parseKeyFilename(value109);
      return value110 && value110.type === value106.type && value110.id === value106.id;
    });
    if (!value108) {
      throw new Error("AUTH_MIGRATION_SOURCE_NOT_FOUND: " + value107);
    }
    try {
      const value111 = await readStableJson(path.join(value94, value108), value96);
      value104.push({
        type: value106.type,
        id: value106.id,
        value: JSON.stringify(value111, value96.replacer)
      });
    } catch (error112) {
      if (value106.type === "lid-mapping") {
        value105.push(value108);
        continue;
      }
      throw new Error("AUTH_MIGRATION_INVALID_KEY " + value108 + ": " + error112.message);
    }
  }
  if (value104.length === 0) {
    throw new Error(value105.length > 0 ? "AUTH_MIGRATION_NO_VALID_KEY_FILES: skipped " + value105.join(", ") : "AUTH_MIGRATION_NO_KEY_FILES: no usable key files were found");
  }
  const value113 = Date.now();
  const value114 = value95.replace === true;
  const value115 = value93.prepare("\n    INSERT INTO session_creds (key, value, updated_at) VALUES ('creds', ?, ?)\n    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at\n  ");
  const value116 = value93.prepare("\n    INSERT INTO session_keys (type, id, value, updated_at) VALUES (?, ?, ?, ?)\n    ON CONFLICT(type, id) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at\n  ");
  const value117 = value93.transaction(() => {
    if (value114) {
      value93.prepare("DELETE FROM session_creds").run();
      value93.prepare("DELETE FROM session_keys").run();
    }
    value115.run(JSON.stringify(value98, value96.replacer), value113);
    for (const value118 of value104) {
      value116.run(value118.type, value118.id, value118.value, value113);
    }
    setMeta(value93, AUTH_META.status, "verifying");
    setMeta(value93, AUTH_META.sourceKeyFiles, value104.length);
    setMeta(value93, AUTH_META.databaseKeyRows, value104.length);
    setMeta(value93, AUTH_META.sourceJsonFiles, value100.filter(value119 => value119.endsWith(".json")).length);
    setMeta(value93, "unknown_json_files", value102.length);
  });
  value117();
  const value120 = getSQLiteAuthStats(value93);
  if (!value120.hasCreds || value120.totalKeys !== value104.length || value120.sourceKeyFiles !== value104.length) {
    setMeta(value93, AUTH_META.status, "invalid");
    throw new Error("AUTH_MIGRATION_COUNT_MISMATCH: source=" + value104.length + ", database=" + value120.totalKeys);
  }
  const value121 = value93.prepare("SELECT value FROM session_creds WHERE key = 'creds'").get();
  JSON.parse(value121.value, value96.reviver);
  for (const value122 of value93.prepare("SELECT value FROM session_keys").all()) {
    JSON.parse(value122.value, value96.reviver);
  }
  let value123 = null;
  if (value95.quarantine !== false) {
    try {
      value123 = copyToQuarantine(value94);
    } catch (error124) {
      setMeta(value93, AUTH_META.status, "invalid");
      throw new Error("AUTH_MIGRATION_QUARANTINE_FAILED: " + error124.message);
    }
  }
  setMeta(value93, AUTH_META.status, "verified");
  setMeta(value93, AUTH_META.quarantinedPath, value123);
  setMeta(value93, AUTH_META.migratedAt, value113);
  setMeta(value93, AUTH_META.pendingFileMigration, value95.quarantine === false ? "1" : "0");
  setMeta(value93, "invalid_reason", null);
  if (typeof value95.onMutation === "function") {
    value95.onMutation("auth-migration");
  }
  return {
    ok: true,
    stats: getSQLiteAuthStats(value93),
    quarantinedPath: value123,
    skippedOptionalFiles: value105
  };
}
async function validateSQLiteAuth(value125, value126 = {}) {
  const {
    proto: value127,
    BufferJSON: value128
  } = await getBaileysDeps();
  ensureAuthSchema(value125);
  const value129 = getSQLiteAuthStats(value125);
  const value130 = value129.verified;
  const value131 = [];
  const value132 = (value133, value134) => {
    const value135 = value133 + ": " + value134;
    if (value130 && value126.markInvalid !== false) {
      invalidateSQLiteAuth(value125, value135);
    }
    return {
      ok: false,
      wasVerified: value130,
      code: value133,
      reason: value135,
      stats: getSQLiteAuthStats(value125)
    };
  };
  if (!value130) {
    return {
      ok: false,
      wasVerified: false,
      code: "AUTH_NOT_VERIFIED",
      reason: "SQLite auth is not marked verified.",
      stats: value129
    };
  }
  const value136 = value125.prepare("SELECT value FROM session_creds WHERE key = 'creds'").get();
  if (!value136) {
    return value132("AUTH_CREDS_MISSING", "session_creds does not contain creds.");
  }
  try {
    const value137 = JSON.parse(value136.value, value128.reviver);
    if (!value137 || typeof value137 !== "object") {
      return value132("AUTH_CREDS_INVALID", "stored credentials are not an object.");
    }
  } catch (error138) {
    return value132("AUTH_CREDS_INVALID", error138.message);
  }
  const value139 = value125.prepare("SELECT type, id, value FROM session_keys ORDER BY type, id").all();
  if (value129.sourceKeyFiles > 0 && value139.length === 0) {
    return value132("AUTH_KEYS_MISSING", "migration recorded " + value129.sourceKeyFiles + " source key files but SQLite has none.");
  }
  const value140 = new Set();
  for (const value141 of value139) {
    if (!KEY_TYPES.includes(value141.type)) {
      return value132("AUTH_KEY_TYPE_UNKNOWN", "unsupported key type \"" + value141.type + "\".");
    }
    if (!value141.id) {
      if (value141.type === "lid-mapping") {
        value131.push(value141);
        continue;
      }
      return value132("AUTH_KEY_ID_MISSING", "key type \"" + value141.type + "\" has an empty ID.");
    }
    try {
      const value142 = JSON.parse(value141.value, value128.reviver);
      if (value142 === null || typeof value142 !== "object") {
        if (value141.type === "lid-mapping") {
          value131.push(value141);
          continue;
        }
        return value132("AUTH_KEY_INVALID", value141.type + "/" + value141.id + " is not an object.");
      }
      if (value141.type === "app-state-sync-key") {
        value127.Message.AppStateSyncKeyData.create(value142);
      }
    } catch (error143) {
      if (value141.type === "lid-mapping") {
        value131.push(value141);
        continue;
      }
      return value132("AUTH_KEY_INVALID", value141.type + "/" + value141.id + ": " + error143.message);
    }
    value140.add(value141.type);
  }
  if (value131.length > 0) {
    const value144 = value125.prepare("DELETE FROM session_keys WHERE type = ? AND id = ?");
    const value145 = value125.transaction(() => {
      for (const value146 of value131) {
        value144.run(value146.type, value146.id || "");
      }
      setMeta(value125, "last_lid_mapping_repair_count", value131.length);
      setMeta(value125, "last_lid_mapping_repair_at", Date.now());
    });
    value145();
    if (typeof value126.onMutation === "function") {
      value126.onMutation("auth-lid-mapping-repair");
    }
  }
  if (value129.sourceKeyFiles > 0 && ![...CORE_KEY_TYPES].some(value147 => value140.has(value147))) {
    return value132("AUTH_KEY_TYPES_INCOMPLETE", "no core Signal key type is present; found " + ([...value140].join(", ") || "none") + ".");
  }
  return {
    ok: true,
    wasVerified: true,
    code: "AUTH_VALID",
    reason: "SQLite credentials and key rows validated.",
    stats: getSQLiteAuthStats(value125),
    repairedLidMappings: value131.length
  };
}
async function finalizePendingFileMigration(value148, value149, value150 = {}) {
  ensureAuthSchema(value148);
  if (getMeta(value148, AUTH_META.pendingFileMigration) !== "1") {
    return {
      ok: false,
      skipped: true,
      reason: "no-pending-file-migration"
    };
  }
  return migrateFilesToSQLite(value148, value149, {
    replace: true,
    quarantine: true,
    onMutation: value150.onMutation
  });
}
async function useSQLiteAuthState(value151, value152, value153 = {}) {
  const {
    proto: value154,
    BufferJSON: value155,
    initAuthCreds: value156
  } = await getBaileysDeps();
  ensureAuthSchema(value151);
  if (!hasVerifiedSQLiteAuth(value151)) {
    const value157 = path.join(value152, "creds.json");
    const value158 = getMeta(value151, AUTH_META.status);
    const value159 = getMeta(value151, "invalid_reason");
    const value160 = value153.allowFresh === true && !fs.existsSync(value157) && (value158 !== "invalid" || value153.allowFreshAfterInvalid === true);
    if (value160) {
      const value161 = value156();
      const value162 = Date.now();
      value151.prepare("\n        INSERT INTO session_creds (key, value, updated_at) VALUES ('creds', ?, ?)\n        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at\n      ").run(JSON.stringify(value161, value155.replacer), value162);
      setMeta(value151, AUTH_META.status, "verified");
      setMeta(value151, AUTH_META.sourceKeyFiles, 0);
      setMeta(value151, AUTH_META.databaseKeyRows, 0);
      setMeta(value151, AUTH_META.sourceJsonFiles, 0);
      setMeta(value151, AUTH_META.migratedAt, value162);
      if (typeof value153.onMutation === "function") {
        value153.onMutation("auth-fresh-init");
      }
    } else {
      await migrateFilesToSQLite(value151, value152, {
        replace: true,
        onMutation: value153.onMutation
      });
    }
  }
  if (!hasVerifiedSQLiteAuth(value151)) {
    throw new Error("AUTH_STATE_NOT_VERIFIED");
  }
  function handler163() {
    const value164 = value151.prepare("SELECT value FROM session_creds WHERE key = 'creds'").get();
    if (value164) {
      return JSON.parse(value164.value, value155.reviver);
    } else {
      return value156();
    }
  }
  function handler165(value166, value167) {
    const value168 = value151.prepare("SELECT value FROM session_keys WHERE type = ? AND id = ?").get(value166, value167);
    if (!value168) {
      return null;
    }
    try {
      const value169 = JSON.parse(value168.value, value155.reviver);
      if (!isObjectValue(value169) && removeInvalidLidMapping(value151, value166, value167, value153.onMutation)) {
        return null;
      }
      return value169;
    } catch (error170) {
      if (removeInvalidLidMapping(value151, value166, value167, value153.onMutation)) {
        return null;
      }
      throw error170;
    }
  }
  function handler171(value172) {
    value151.prepare("\n      INSERT INTO session_creds (key, value, updated_at) VALUES ('creds', ?, ?)\n      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at\n    ").run(JSON.stringify(value172, value155.replacer), Date.now());
    if (typeof value153.onMutation === "function") {
      value153.onMutation("auth-creds");
    }
  }
  const value173 = handler163();
  return {
    source: "sqlite",
    stats: getSQLiteAuthStats(value151),
    state: {
      creds: value173,
      keys: {
        get: async (value174, value175) => {
          const value176 = {};
          for (const value177 of value175) {
            let value178 = handler165(value174, value177);
            if (value174 === "app-state-sync-key" && value178) {
              value178 = value154.Message.AppStateSyncKeyData.create(value178);
            }
            value176[value177] = value178;
          }
          return value176;
        },
        set: async value179 => {
          const value180 = value151.prepare("\n            INSERT INTO session_keys (type, id, value, updated_at) VALUES (?, ?, ?, ?)\n            ON CONFLICT(type, id) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at\n          ");
          const value181 = value151.prepare("DELETE FROM session_keys WHERE type = ? AND id = ?");
          const value182 = value151.transaction(() => {
            for (const [value183, value184] of Object.entries(value179)) {
              for (const [value185, value186] of Object.entries(value184)) {
                if (!value186) {
                  value181.run(value183, value185);
                  continue;
                }
                if (value183 === "lid-mapping" && !isObjectValue(value186)) {
                  value181.run(value183, value185);
                  continue;
                }
                const value187 = JSON.stringify(value186, value155.replacer);
                if (value187 === undefined) {
                  if (value183 === "lid-mapping") {
                    value181.run(value183, value185);
                  } else {
                    throw new Error("AUTH_KEY_SERIALIZE_FAILED: " + value183 + "/" + value185);
                  }
                  continue;
                }
                value180.run(value183, value185, value187, Date.now());
              }
            }
          });
          value182();
          if (typeof value153.onMutation === "function") {
            value153.onMutation("auth-keys");
          }
        }
      }
    },
    saveCreds: () => handler171(value173)
  };
}
function clearSQLiteAuth(value188, value189 = "cleared") {
  ensureAuthSchema(value188);
  const value190 = value188.transaction(() => {
    value188.prepare("DELETE FROM session_creds").run();
    value188.prepare("DELETE FROM session_keys").run();
    setMeta(value188, AUTH_META.status, "invalid");
    setMeta(value188, "invalid_reason", value189);
    setMeta(value188, AUTH_META.sourceKeyFiles, 0);
    setMeta(value188, AUTH_META.databaseKeyRows, 0);
    setMeta(value188, AUTH_META.sourceJsonFiles, 0);
    setMeta(value188, AUTH_META.quarantinedPath, "");
    setMeta(value188, AUTH_META.migratedAt, "");
    setMeta(value188, AUTH_META.pendingFileMigration, "0");
    setMeta(value188, "invalid_reason", value189);
    setMeta(value188, AUTH_META.authConnectionVerified, "0");
    setMeta(value188, AUTH_META.authSource, null);
  });
  value190();
}
module.exports = {
  AUTH_META: AUTH_META,
  ensureAuthSchema: ensureAuthSchema,
  getSQLiteAuthStats: getSQLiteAuthStats,
  hasVerifiedSQLiteAuth: hasVerifiedSQLiteAuth,
  validateSQLiteAuth: validateSQLiteAuth,
  invalidateSQLiteAuth: invalidateSQLiteAuth,
  migrateFilesToSQLite: migrateFilesToSQLite,
  finalizePendingFileMigration: finalizePendingFileMigration,
  cleanupSessionQuarantines: cleanupSessionQuarantines,
  getSessionQuarantineStats: getSessionQuarantineStats,
  getSessionIdFingerprint: getSessionIdFingerprint,
  setSessionIdFingerprint: setSessionIdFingerprint,
  getSessionIdRevokedFingerprint: getSessionIdRevokedFingerprint,
  setSessionIdRevokedFingerprint: setSessionIdRevokedFingerprint,
  getAuthSource: getAuthSource,
  setAuthSource: setAuthSource,
  isAuthConnectionVerified: isAuthConnectionVerified,
  setAuthConnectionVerified: setAuthConnectionVerified,
  isLocallyVerifiedAuth: isLocallyVerifiedAuth,
  clearSQLiteAuth: clearSQLiteAuth,
  useSQLiteAuthState: useSQLiteAuthState
};
