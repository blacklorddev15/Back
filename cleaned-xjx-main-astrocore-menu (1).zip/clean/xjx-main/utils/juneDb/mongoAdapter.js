'use strict';

let MongoClient = null;
let client = null;
let mongoDb = null;
let ready = false;
let initializing = null;
let lastError = null;
const COLLECTION = "june_mirror_records";
function normalizeBotId(value1) {
  const value2 = String(value1 || "").trim().split("@")[0].split(":")[0];
  const value3 = value2.replace(/[^a-zA-Z0-9_.-]/g, "-").replace(/-+/g, "-");
  return value3 || "june-x-main";
}
const BOT_ID_PRODUCT = "june-ultra-main";
function buildBotId(value4, value5 = BOT_ID_PRODUCT) {
  const value6 = String(value4 || "").split("@")[0].split(":")[0].replace(/\D/g, "");
  return normalizeBotId(value6 ? value5 + "-" + value6 : value5);
}
let activeBotId = buildBotId(process.env.PN || process.env.JUNE_PN || process.env.JUNE_BOT_ID || process.env.BOT_ID || process.env.OWNER_NUMBER);
function getUri() {
  return String(process.env.MONGODB_URI || process.env.MONGODB_URL || process.env.MONGO_URL || "").trim();
}
function hasUri() {
  return Boolean(getUri());
}
function getDatabaseName() {
  const value7 = String(process.env.JUNE_MONGO_DB || process.env.MONGO_DB || "june_x").trim();
  return value7 || "june_x";
}
function getBotId() {
  return activeBotId;
}
function setBotId(value8) {
  if (value8) {
    activeBotId = normalizeBotId(value8);
  }
  return activeBotId;
}
function getStatus() {
  return {
    configured: hasUri(),
    available: ready,
    collection: COLLECTION,
    database: getDatabaseName(),
    botId: activeBotId,
    lastError: lastError
  };
}
function collection() {
  return mongoDb?.collection(COLLECTION) || null;
}
function recordId(value9, value10 = []) {
  return [value9, activeBotId, ...value10.map(value11 => String(value11))].map(value12 => encodeURIComponent(value12)).join("|");
}
function runRemoteOperation(value13) {
  if (!ready || !collection()) {
    return Promise.resolve(null);
  }
  return Promise.resolve().then(value13).catch(value14 => {
    lastError = value14?.message || String(value14);
    return null;
  });
}
function upsertRecord(value15, value16, value17) {
  const value18 = recordId(value15, value16);
  return runRemoteOperation(() => collection().updateOne({
    _id: value18
  }, {
    $set: {
      kind: value15,
      botId: activeBotId,
      data: value17 || {},
      updatedAt: new Date()
    },
    $setOnInsert: {
      createdAt: new Date()
    }
  }, {
    upsert: true
  }));
}
function deleteRecord(value19, value20) {
  return runRemoteOperation(() => collection().deleteOne({
    _id: recordId(value19, value20)
  }));
}
async function ensureIndexes() {
  const value21 = collection();
  if (!value21) {
    return;
  }
  await Promise.all([value21.createIndex({
    botId: 1,
    kind: 1,
    updatedAt: -1
  }), value21.createIndex({
    kind: 1,
    updatedAt: -1
  })]);
}
async function init() {
  if (ready) {
    return getStatus();
  }
  if (initializing) {
    return initializing;
  }
  initializing = (async () => {
    if (!hasUri()) {
      return getStatus();
    }
    try {
      ({
        MongoClient: MongoClient
      } = require("mongodb"));
      if (!MongoClient) {
        throw new Error("MongoClient constructor was not found");
      }
    } catch (error22) {
      lastError = "The mongodb package is not installed";
      console.warn("[MONGO] Optional MongoDB disabled: " + lastError);
      return getStatus();
    }
    let value23 = null;
    try {
      value23 = new MongoClient(getUri(), {
        maxPoolSize: Number(process.env.JUNE_MONGO_POOL_MAX) || 5,
        serverSelectionTimeoutMS: Number(process.env.JUNE_MONGO_CONNECT_TIMEOUT_MS) || 8000,
        connectTimeoutMS: Number(process.env.JUNE_MONGO_CONNECT_TIMEOUT_MS) || 8000,
        retryWrites: true
      });
      await value23.connect();
      client = value23;
      mongoDb = client.db(getDatabaseName());
      await ensureIndexes();
      ready = true;
      lastError = null;
      console.log("[MONGO] Connected; remote persistence enabled for bot_id=" + require("../redact").maskBotId(activeBotId));
    } catch (error24) {
      lastError = error24?.message || String(error24);
      console.warn("[MONGO] Optional MongoDB unavailable: " + lastError);
      try {
        await value23?.close();
      } catch (error25) {}
      client = null;
      mongoDb = null;
      ready = false;
    }
    return getStatus();
  })().finally(() => {
    initializing = null;
  });
  return initializing;
}
function mirrorBotSetting(value26, value27) {
  return upsertRecord("bot-setting", [value26], {
    key: String(value26),
    value: value27
  });
}
function mirrorGroupSettings(value28, value29) {
  return upsertRecord("group-settings", [value28], {
    groupId: String(value28),
    settings: value29 || {}
  });
}
function mirrorGroupStat(value30, value31, value32) {
  return upsertRecord("group-stat", [value30, value31], {
    groupId: String(value30),
    date: String(value31),
    data: value32 || {}
  });
}
function mirrorUser(value33, value34) {
  return upsertRecord("user", [value33], {
    userId: String(value33),
    data: value34 || {}
  });
}
function mirrorWarning(value35, value36, value37) {
  return upsertRecord("warning", [value35, value36], {
    groupId: String(value35),
    userId: String(value36),
    count: Number(value37?.count || 0),
    entries: value37?.entries || []
  });
}
function mirrorModerator(value38, value39 = true) {
  if (!value39) {
    return deleteRecord("moderator", [value38]);
  }
  return upsertRecord("moderator", [value38], {
    userId: String(value38)
  });
}
function mirrorMutedUser(value40, value41, value42 = true) {
  if (!value42) {
    return deleteRecord("muted-user", [value40, value41]);
  }
  return upsertRecord("muted-user", [value40, value41], {
    groupId: String(value40),
    userId: String(value41)
  });
}
function mirrorKV(value43, value44, value45) {
  return upsertRecord("kv", [value43, value44], {
    namespace: String(value43),
    key: String(value44),
    value: value45
  });
}
function deleteKV(value46, value47) {
  return deleteRecord("kv", [value46, value47]);
}
function mirrorAntideleteMessage(value48, value49, value50, value51 = Date.now()) {
  return upsertRecord("antidelete-message", [value48, value49], {
    chatId: String(value48),
    messageId: String(value49),
    payload: value50 || {},
    storedAt: Number(value51)
  });
}
function deleteAntideleteMessage(value52, value53) {
  return deleteRecord("antidelete-message", [value52, value53]);
}
function mirrorAntideleteStatus(value54, value55, value56 = Date.now()) {
  return upsertRecord("antidelete-status", [value54], {
    statusId: String(value54),
    payload: value55 || {},
    storedAt: Number(value56)
  });
}
function deleteAntideleteStatus(value57) {
  return deleteRecord("antidelete-status", [value57]);
}
function mirrorLidMap(value58, value59, value60, value61 = Date.now()) {
  return upsertRecord("lid-map", [value58, value59], {
    direction: String(value58),
    user: String(value59),
    value: String(value60),
    updatedAt: Number(value61)
  });
}
function mirrorProfile(value62, value63, value64) {
  return upsertRecord("chat-profile", [value62, value63], {
    profileBotId: String(value62 || "default"),
    userId: String(value63),
    profile: value64 || {}
  });
}
function mirrorAuthState(value65) {
  return upsertRecord("auth-state", [], value65 || {}).then(value66 => {
    if (!value66) {
      return value66;
    }
    return deleteLegacyAuthRecord().then(() => value66);
  });
}
function fetchAuthState() {
  if (!ready || !collection()) {
    return Promise.resolve(null);
  }
  return runRemoteOperation(async () => {
    const value67 = await collection().findOne({
      _id: recordId("auth-state", [])
    });
    if (!value67?.data) {
      return null;
    }
    return {
      snapshot: value67.data,
      updatedAt: value67.updatedAt ? new Date(value67.updatedAt).getTime() : 0,
      source: "mongo"
    };
  });
}
function deleteAuthState() {
  return deleteRecord("auth-state", []);
}
function deleteLegacyAuthRecord() {
  return deleteRecord("auth-backup", []);
}
function insertIfMissing(value68, value69, value70, value71, value72) {
  if (value68.prepare(value69).get(...value70)) {
    return false;
  }
  value68.prepare(value71).run(...value72);
  return true;
}
async function restoreIntoSQLite(value73) {
  if (!ready || !mongoDb || !value73) {
    return {
      restored: 0,
      skipped: "mongo_unavailable"
    };
  }
  try {
    const value74 = await collection().find({
      botId: activeBotId
    }).sort({
      updatedAt: 1
    }).toArray();
    let value75 = 0;
    const value76 = value73.transaction(() => {
      for (const value77 of value74) {
        const value78 = value77?.data || {};
        try {
          let value79 = false;
          switch (value77.kind) {
            case "bot-setting":
              value79 = insertIfMissing(value73, "SELECT 1 FROM bot_settings WHERE key = ?", [value78.key], "INSERT INTO bot_settings (key, value) VALUES (?, ?)", [value78.key, JSON.stringify(value78.value)]);
              break;
            case "group-settings":
              value79 = insertIfMissing(value73, "SELECT 1 FROM groups WHERE group_id = ?", [value78.groupId], "INSERT INTO groups (group_id, settings) VALUES (?, ?)", [value78.groupId, JSON.stringify(value78.settings || {})]);
              break;
            case "group-stat":
              value79 = insertIfMissing(value73, "SELECT 1 FROM group_stats WHERE group_id = ? AND date = ?", [value78.groupId, value78.date], "INSERT INTO group_stats (group_id, date, data) VALUES (?, ?, ?)", [value78.groupId, value78.date, JSON.stringify(value78.data || {})]);
              break;
            case "user":
              value79 = insertIfMissing(value73, "SELECT 1 FROM users WHERE user_id = ?", [value78.userId], "INSERT INTO users (user_id, data) VALUES (?, ?)", [value78.userId, JSON.stringify(value78.data || {})]);
              break;
            case "warning":
              value79 = insertIfMissing(value73, "SELECT 1 FROM warnings WHERE group_id = ? AND user_id = ?", [value78.groupId, value78.userId], "INSERT INTO warnings (group_id, user_id, count, entries) VALUES (?, ?, ?, ?)", [value78.groupId, value78.userId, Number(value78.count || 0), JSON.stringify(value78.entries || [])]);
              break;
            case "moderator":
              value79 = insertIfMissing(value73, "SELECT 1 FROM moderators WHERE user_id = ?", [value78.userId], "INSERT INTO moderators (user_id) VALUES (?)", [value78.userId]);
              break;
            case "muted-user":
              value79 = insertIfMissing(value73, "SELECT 1 FROM muted_users WHERE group_id = ? AND user_id = ?", [value78.groupId, value78.userId], "INSERT INTO muted_users (group_id, user_id) VALUES (?, ?)", [value78.groupId, value78.userId]);
              break;
            case "kv":
              if (value78.namespace === "runtime_telemetry" && value78.value?.eventType) {
                const value80 = value78.value;
                value79 = insertIfMissing(value73, "SELECT 1 FROM runtime_telemetry WHERE event_type = ? AND event_key = ?", [value80.eventType, value80.eventKey], "INSERT INTO runtime_telemetry\n                    (event_type, event_key, payload, count, first_seen, last_seen)\n                   VALUES (?, ?, ?, ?, ?, ?)", [value80.eventType, value80.eventKey, JSON.stringify(value80.payload || {}), Number(value80.count || 1), Number(value80.firstSeen || Date.now()), Number(value80.lastSeen || Date.now())]);
              } else {
                value79 = insertIfMissing(value73, "SELECT 1 FROM kv_store WHERE namespace = ? AND key = ?", [value78.namespace, value78.key], "INSERT INTO kv_store (namespace, key, value) VALUES (?, ?, ?)", [value78.namespace, value78.key, JSON.stringify(value78.value)]);
              }
              break;
            case "antidelete-message":
              value79 = insertIfMissing(value73, "SELECT 1 FROM antidelete_messages WHERE chat_id = ? AND message_id = ?", [value78.chatId, value78.messageId], "INSERT INTO antidelete_messages (chat_id, message_id, payload, stored_at) VALUES (?, ?, ?, ?)", [value78.chatId, value78.messageId, JSON.stringify(value78.payload || {}), Number(value78.storedAt || Date.now())]);
              break;
            case "antidelete-status":
              value79 = insertIfMissing(value73, "SELECT 1 FROM antidelete_statuses WHERE status_id = ?", [value78.statusId], "INSERT INTO antidelete_statuses (status_id, payload, stored_at) VALUES (?, ?, ?)", [value78.statusId, JSON.stringify(value78.payload || {}), Number(value78.storedAt || Date.now())]);
              break;
            case "lid-map":
              value79 = insertIfMissing(value73, "SELECT 1 FROM lid_map WHERE direction = ? AND user = ?", [value78.direction, value78.user], "INSERT INTO lid_map (direction, user, value, updated_at) VALUES (?, ?, ?, ?)", [value78.direction, value78.user, value78.value, Number(value78.updatedAt || Date.now())]);
              break;
            case "chat-profile":
              value79 = insertIfMissing(value73, "SELECT 1 FROM chat_profiles WHERE bot_id = ? AND user_id = ?", [value78.profileBotId, value78.userId], "INSERT INTO chat_profiles (bot_id, user_id, profile) VALUES (?, ?, ?)", [value78.profileBotId, value78.userId, JSON.stringify(value78.profile || {})]);
              break;
            default:
              break;
          }
          if (value79) {
            value75 += 1;
          }
        } catch (error81) {}
      }
    });
    value76();
    return {
      restored: value75,
      botId: activeBotId
    };
  } catch (error82) {
    lastError = error82?.message || String(error82);
    console.warn("[MONGO] Restore skipped: " + lastError);
    return {
      restored: 0,
      error: lastError
    };
  }
}
async function close() {
  const value83 = client;
  client = null;
  mongoDb = null;
  ready = false;
  if (!value83) {
    return;
  }
  try {
    await value83.close();
  } catch (error84) {}
}
function regexEscape(value85) {
  return String(value85).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
async function clearKind(value86) {
  if (!ready || !collection()) {
    return {
      ok: false,
      reason: "unavailable"
    };
  }
  try {
    const value87 = "^" + regexEscape(encodeURIComponent(value86)) + "\\|" + regexEscape(encodeURIComponent(activeBotId || "")) + "\\|";
    const value88 = await collection().deleteMany({
      _id: {
        $regex: value87
      }
    });
    return {
      ok: true,
      deleted: value88?.deletedCount || 0
    };
  } catch (error89) {
    lastError = error89?.message || String(error89);
    return {
      ok: false,
      reason: lastError
    };
  }
}
module.exports = {
  init: init,
  close: close,
  getBotId: getBotId,
  setBotId: setBotId,
  buildBotId: buildBotId,
  getStatus: getStatus,
  mirrorBotSetting: mirrorBotSetting,
  mirrorGroupSettings: mirrorGroupSettings,
  mirrorGroupStat: mirrorGroupStat,
  mirrorUser: mirrorUser,
  mirrorWarning: mirrorWarning,
  mirrorModerator: mirrorModerator,
  mirrorMutedUser: mirrorMutedUser,
  mirrorKV: mirrorKV,
  deleteKV: deleteKV,
  mirrorAntideleteMessage: mirrorAntideleteMessage,
  deleteAntideleteMessage: deleteAntideleteMessage,
  mirrorAntideleteStatus: mirrorAntideleteStatus,
  deleteAntideleteStatus: deleteAntideleteStatus,
  mirrorLidMap: mirrorLidMap,
  mirrorProfile: mirrorProfile,
  mirrorAuthState: mirrorAuthState,
  fetchAuthState: fetchAuthState,
  deleteAuthState: deleteAuthState,
  deleteLegacyAuthRecord: deleteLegacyAuthRecord,
  restoreIntoSQLite: restoreIntoSQLite,
  clearKind: clearKind
};
