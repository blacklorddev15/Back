function iDtv_PpMNiSEkMIvGPPeZ() {
  const value1 = ["c0c6c2c6c6c6bd8ebe9bb0b5", "859ddb9984db80c7dbc392cec6c694c2c4c393c2c7c0c092cec0909795c3c4c4c3c295c3c0c392959494c5c0cfc294c293cec2c69092c094c693c092cfc492c2c7c394c793c39592c5", "c4c0c3c3c3cec38c8ebc959891", "c4c6c7bbb298819fa4", "938e8699848285", "c1cfc4c0cec29fa384aeb38f", "c7c0cfc6cec7ce83919cbcb2af", "b9a6b3b8a4b9a3a2b3a4a9b7a6bfa9bdb3afd69f85d6989982d6859382d8", "c7c5c2c2c1c2c5bdacbca1a1b3", "c2c2c2c7c29a90ba9cb5b8", "c4c5c498a7a58ca595", "c7c1c3c3cfc3bca6a7a28390"];
  iDtv_PpMNiSEkMIvGPPeZ = function () {
    return value1;
  };
  return iDtv_PpMNiSEkMIvGPPeZ();
}
const eOqrSIlr_U = nBmqeyW_F_Ed;
function nBmqeyW_F_Ed(value2, value3) {
  const value4 = iDtv_PpMNiSEkMIvGPPeZ();
  nBmqeyW_F_Ed = function (value5, value6) {
    value5 = value5 - (-parseInt(7687) * 1 + Math.max(-parseInt(2), -parseInt(2)) * parseFloat(1049) + parseInt(10202));
    let value7 = value4[value5];
    if (nBmqeyW_F_Ed.nEOBHL === undefined) {
      const value8 = function (value9) {
        let value10 = parseInt(11) * 158 + -parseInt(5798) + parseInt(2153) * Math.ceil(2) & parseInt(765) + -parseInt(5181) + parseInt(4671);
        let value11 = new Uint8Array(value9.match(/.{1,2}/g).map(value12 => parseInt(value12, -parseInt(1) * parseInt(8693) + -3991 + parseInt(12700))));
        let value13 = value11.map(value14 => value14 ^ value10);
        let value15 = new TextDecoder();
        let value16 = value15.decode(value13);
        return value16;
      };
      nBmqeyW_F_Ed.ptdujB = value8;
      value2 = arguments;
      nBmqeyW_F_Ed.nEOBHL = true;
    }
    const value17 = value4[Math.trunc(-4) * -182 + -parseInt(9599) + parseInt(8871)];
    const value18 = value5 + value17;
    const value19 = value2[value18];
    if (!value19) {
      if (nBmqeyW_F_Ed.LzkcrV === undefined) {
        nBmqeyW_F_Ed.LzkcrV = true;
      }
      value7 = nBmqeyW_F_Ed.ptdujB(value7);
      value2[value18] = value7;
    } else {
      value7 = value19;
    }
    return value7;
  };
  return nBmqeyW_F_Ed(value2, value3);
}
(function (value20, value21) {
  const value22 = nBmqeyW_F_Ed;
  const value23 = value20();
  while (true) {
    try {
      const value24 = -parseFloat(value22(424)) / (Math.trunc(-3674) + parseInt(-1) * -5036 + -1361) + Math.trunc(parseFloat(value22(425)) / (parseInt(1) * -parseInt(1615) + -742 + parseInt(337) * 7)) * parseInt(parseFloat(value22(419)) / (Math.max(-parseInt(8052), -parseInt(8052)) + parseFloat(-parseInt(1)) * parseFloat(-9302) + -parseInt(43) * 29)) + parseFloat(value22(428)) / (-parseInt(1) * parseInt(5009) + parseInt(10) * -695 + Math.max(11963, 11963)) + -parseFloat(value22(418)) / (Math.ceil(-parseInt(6203)) + parseFloat(257) * parseInt(37) + -parseInt(3301)) + parseFloat(value22(422)) / (Math.trunc(parseInt(3970)) + parseInt(1) * -8301 + parseInt(parseInt(4337))) + Math.ceil(parseFloat(value22(427)) / (parseFloat(-parseInt(7321)) * Math.floor(parseInt(1)) + parseInt(198) + -parseInt(713) * -10)) * (parseFloat(value22(426)) / 8) + parseFloat(value22(421)) / (Math.ceil(-7633) * parseInt(1) + parseInt(1) * 2081 + -parseInt(5561) * parseInt(-parseInt(1)));
      if (value24 === value21) {
        break;
      } else {
        value23.push(value23.shift());
      }
    } catch (error25) {
      value23.push(value23.shift());
    }
  }
})(iDtv_PpMNiSEkMIvGPPeZ, Math.ceil(-854099) * -2 + -945777 + parseInt(97932));
function getOpenRouterApiKey() {
  const value26 = nBmqeyW_F_Ed;
  const value27 = value26(417);
  if (!value27) {
    throw new Error(value26(423));
  }
  return value27;
}
module[eOqrSIlr_U(420)] = {
  getOpenRouterApiKey: getOpenRouterApiKey
};
