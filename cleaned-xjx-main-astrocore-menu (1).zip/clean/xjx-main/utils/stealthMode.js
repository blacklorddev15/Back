const db = require("../database");
const KEY = "stealthMode";
const isEnabled = () => {
  try {
    return !!db.getBotSetting(KEY);
  } catch (error1) {
    return false;
  }
};
const setEnabled = value2 => {
  try {
    db.setBotSetting(KEY, !!value2);
    return true;
  } catch (error3) {
    return false;
  }
};
function applyToSocket(value4) {
  const value5 = {
    qHqmq: function (value6) {
      return value6();
    },
    iPLNz: function (value7, value8) {
      return value7 !== value8;
    },
    XEvxG: "unavailable",
    LniQo: function (value9, value10, ...value11) {
      return value9(value10, ...value11);
    },
    uUdGs: function (value12, ...value13) {
      return value12(...value13);
    },
    RioDp: "function"
  };
  if (!value4 || value4.__stealthPatched) {
    return value4;
  }
  value4.__stealthPatched = true;
  const value14 = typeof value4.sendPresenceUpdate === value5.RioDp ? value4.sendPresenceUpdate.bind(value4) : null;
  const value15 = typeof value4.readMessages === value5.RioDp ? value4.readMessages.bind(value4) : null;
  if (value14) {
    value4.sendPresenceUpdate = async (value16, ...value17) => {
      if (value5.qHqmq(isEnabled) && value5.iPLNz(value16, value5.XEvxG)) {
        return;
      }
      return value5.LniQo(value14, value16, ...value17);
    };
  }
  if (value15) {
    value4.readMessages = async (...value18) => {
      if (value5.qHqmq(isEnabled)) {
        return;
      }
      return value5.uUdGs(value15, ...value18);
    };
  }
  return value4;
}
module.exports = {
  KEY: KEY,
  isEnabled: isEnabled,
  setEnabled: setEnabled,
  applyToSocket: applyToSocket
};
