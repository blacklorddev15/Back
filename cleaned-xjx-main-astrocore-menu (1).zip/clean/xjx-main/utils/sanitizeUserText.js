'use strict';

const POSIX_PATH_RE = /(?<![\w./:%-])(?:\/[^\s"'`,;)\]}>]+){2,}/g;
const WIN_PATH_RE = /(?<![\w.])(?:[A-Za-z]:[\\/][^\s"'`,;)\]}>]+)/g;
const REPLACEMENT = "[path]";
function sanitizeUserText(value1) {
  if (typeof value1 !== "string") {
    return value1;
  }
  try {
    return value1.replace(WIN_PATH_RE, REPLACEMENT).replace(POSIX_PATH_RE, REPLACEMENT);
  } catch (error2) {
    return value1;
  }
}
function wrapSockSanitized(value3) {
  if (!value3 || typeof value3.sendMessage !== "function" || value3.__juneTextSanitized) {
    return value3;
  }
  const value4 = value3.sendMessage.bind(value3);
  value3.sendMessage = (value5, value6, value7) => {
    if (value6 && typeof value6 === "object") {
      for (const value8 of ["text", "caption"]) {
        if (typeof value6[value8] === "string") {
          value6[value8] = sanitizeUserText(value6[value8]);
        }
      }
    }
    return value4(value5, value6, value7);
  };
  value3.__juneTextSanitized = true;
  return value3;
}
module.exports = {
  sanitizeUserText: sanitizeUserText,
  wrapSockSanitized: wrapSockSanitized
};
