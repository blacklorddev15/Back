const db = require("../database");
const KEY = "disabledCommands";
const PROTECTED = ["disable", "enable"];
const readList = () => {
  try {
    const value1 = db.getBotSetting(KEY);
    if (Array.isArray(value1)) {
      return value1.map(value2 => String(value2).toLowerCase());
    } else {
      return [];
    }
  } catch (error3) {
    return [];
  }
};
const writeList = value4 => {
  try {
    db.setBotSetting(KEY, [...new Set(value4.map(value5 => String(value5).toLowerCase()))]);
    return true;
  } catch (error6) {
    return false;
  }
};
const getAll = () => readList().sort();
const isDisabled = value7 => {
  const value8 = String(value7 || "").toLowerCase();
  return !!value8 && readList().includes(value8);
};
const isProtected = value9 => PROTECTED.includes(String(value9 || "").toLowerCase());
const disable = value10 => {
  const value11 = String(value10 || "").toLowerCase();
  if (!value11 || isProtected(value11)) {
    return false;
  }
  const value12 = readList();
  if (value12.includes(value11)) {
    return true;
  }
  return writeList([...value12, value11]);
};
const enable = value13 => {
  const value14 = String(value13 || "").toLowerCase();
  if (!value14) {
    return false;
  }
  const value15 = readList();
  if (!value15.includes(value14)) {
    return true;
  }
  return writeList(value15.filter(value16 => value16 !== value14));
};
const enableAll = () => {
  const value17 = readList();
  writeList([]);
  return value17.length;
};
module.exports = {
  KEY: KEY,
  PROTECTED: PROTECTED,
  getAll: getAll,
  isDisabled: isDisabled,
  isProtected: isProtected,
  disable: disable,
  enable: enable,
  enableAll: enableAll
};
