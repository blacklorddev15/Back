const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const ffmpeg = require("fluent-ffmpeg");
const ffmpegPath = require("./ffmpegPath");
const webpmux = require("node-webpmux");
const {
  fileTypeFromBuffer
} = require("file-type");
const database = require("../database");
ffmpeg.setFfmpegPath(ffmpegPath());
const tmpFile = value1 => path.join(os.tmpdir(), "stk_" + Date.now() + "_" + crypto.randomBytes(4).toString("hex") + "." + value1);
const cleanup = (...value2) => {
  for (const value3 of value2) {
    try {
      fs.unlinkSync(value3);
    } catch {}
  }
};
const VIDEO_MIMES = ["video/mp4", "video/webm", "video/quicktime", "video/3gpp", "image/gif"];
const detectExt = async value4 => {
  const value5 = await fileTypeFromBuffer(value4);
  return {
    ext: value5?.ext || "bin",
    mime: value5?.mime || "",
    isAnimated: value5 ? VIDEO_MIMES.includes(value5.mime) : false
  };
};
const buildExif = ({
  pack: value6,
  author: value7,
  categories = []
}) => {
  const value8 = {
    "sticker-pack-id": "com.junex." + Date.now(),
    "sticker-pack-name": value6,
    "sticker-pack-publisher": value7,
    emojis: categories
  };
  const value9 = Buffer.from(JSON.stringify(value8), "utf8");
  const value10 = Buffer.from([73, 73, 42, 0, 8, 0, 0, 0, 1, 0, 65, 87, 7, 0, 0, 0, 0, 0, 22, 0, 0, 0]);
  value10.writeUIntLE(value9.length, 14, 4);
  return Buffer.concat([value10, value9]);
};
const applyExif = async (value11, value12) => {
  const value13 = new webpmux.Image();
  await value13.load(value11);
  value13.exif = buildExif(value12);
  return value13.save(null);
};
const toWebp = (value14, value15, value16, value17 = "full") => new Promise((value18, value19) => {
  const value20 = tmpFile(value15);
  const value21 = tmpFile("webp");
  fs.writeFileSync(value20, value14);
  let value22;
  let value23 = null;
  if (value17 === "circle") {
    value22 = ["[0:v]scale=512:512:force_original_aspect_ratio=increase,crop=512:512,fps=15,format=rgba[base]", "[base]geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='if(lte(pow(X-256,2)+pow(Y-256,2),pow(256,2)),alpha(X,Y),0)'[circ]"].join(";");
    value23 = "[circ]";
  } else if (value17 === "cropped") {
    value22 = "[0:v]scale=512:512:force_original_aspect_ratio=increase,crop=512:512,fps=15,format=rgba[out]";
    value23 = "[out]";
  } else {
    value22 = "[0:v]scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,fps=15,format=rgba[out]";
    value23 = "[out]";
  }
  const value24 = ffmpeg(value20).complexFilter(value22, value23).outputOptions(["-vcodec", "libwebp", "-loop", "0", "-preset", "picture", "-an", "-vsync", "0", value16 ? "-t" : "-frames:v", value16 ? "6" : "1"]).toFormat("webp").save(value21).on("end", () => {
    try {
      const value25 = fs.readFileSync(value21);
      value18(value25);
    } catch (error26) {
      value19(error26);
    } finally {
      cleanup(value20, value21);
    }
  }).on("error", value27 => {
    cleanup(value20, value21);
    value19(value27);
  });
});
const buildSticker = async (value28, value29, value30 = {}) => {
  const {
    ext: value31,
    isAnimated: value32
  } = await detectExt(value28);
  const value33 = await toWebp(value28, value31, value32, value29);
  return applyExif(value33, {
    pack: value30.pack || database.getBotSetting("packname"),
    author: value30.author || database.getBotSetting("author"),
    categories: value30.categories || ["🤖"]
  });
};
const createStickerBuffer = async (value34, value35 = {}) => {
  try {
    return await buildSticker(value34, "full", value35);
  } catch (error36) {
    throw new Error("Sticker creation failed: " + error36.message);
  }
};
const createCroppedSticker = async (value37, value38 = {}) => {
  try {
    return await buildSticker(value37, "cropped", value38);
  } catch (error39) {
    throw new Error("Cropped sticker creation failed: " + error39.message);
  }
};
const createCircleSticker = async (value40, value41 = {}) => {
  try {
    return await buildSticker(value40, "circle", value41);
  } catch (error42) {
    throw new Error("Circle sticker creation failed: " + error42.message);
  }
};
const stickerToImage = async value43 => {
  const value44 = require("webp-converter");
  value44.grant_permission();
  const value45 = tmpFile("webp");
  const value46 = tmpFile("png");
  try {
    fs.writeFileSync(value45, value43);
    await value44.dwebp(value45, value46, "-o");
    if (!fs.existsSync(value46)) {
      throw new Error("dwebp produced no output");
    }
    return fs.readFileSync(value46);
  } catch (error47) {
    throw new Error("Sticker to image conversion failed: " + error47.message);
  } finally {
    cleanup(value45, value46);
  }
};
module.exports = {
  createStickerBuffer: createStickerBuffer,
  createCroppedSticker: createCroppedSticker,
  createCircleSticker: createCircleSticker,
  stickerToImage: stickerToImage
};
