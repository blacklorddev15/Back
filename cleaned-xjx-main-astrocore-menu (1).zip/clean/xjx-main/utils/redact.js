'use strict';

const maskDigits = value1 => {
  const value2 = String(value1 ?? "").replace(/\D/g, "");
  if (value2.length < 5) {
    return "•••";
  }
  const value3 = value2.slice(0, 5);
  const value4 = value2.length > 7 ? value2.slice(-2) : "";
  const value5 = "•".repeat(Math.max(value2.length - value3.length - value4.length, 3));
  return value3 + value5 + value4;
};
const maskNumber = value6 => {
  const value7 = String(value6 ?? "");
  if (!value7) {
    return "(none)";
  }
  if (!/\d/.test(value7)) {
    return "•••";
  }
  return value7.replace(/\d{5,}/, value8 => maskDigits(value8));
};
const maskBotId = value9 => {
  const value10 = String(value9 ?? "");
  if (!value10) {
    return "(none)";
  }
  if (value10.length <= 10) {
    return value10.slice(0, 2) + "…";
  }
  return value10.slice(0, 6) + "…" + value10.slice(-4);
};
module.exports = {
  maskNumber: maskNumber,
  maskBotId: maskBotId
};
