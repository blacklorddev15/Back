const axios = require("axios");
const {
  downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");
const downloadMedia = async value1 => {
  try {
    const value2 = Object.keys(value1)[0];
    const value3 = await downloadContentFromMessage(value1[value2], value2.replace("Message", ""));
    let value4 = Buffer.from([]);
    for await (const value5 of value3) {
      value4 = Buffer.concat([value4, value5]);
    }
    return value4;
  } catch (error6) {
    throw new Error("Media download failed: " + error6.message);
  }
};
const formatDuration = value7 => {
  const value8 = Math.floor(value7 / 1000 % 60);
  const value9 = Math.floor(value7 / 60000 % 60);
  const value10 = Math.floor(value7 / 3600000 % 24);
  const value11 = [];
  if (value10 > 0) {
    value11.push(value10 + "h");
  }
  if (value9 > 0) {
    value11.push(value9 + "m");
  }
  if (value8 > 0) {
    value11.push(value8 + "s");
  }
  return value11.join(" ") || "0s";
};
const formatSize = value12 => {
  if (value12 === 0) {
    return "0 Bytes";
  }
  const value13 = 1024;
  const value14 = ["Bytes", "KB", "MB", "GB"];
  const value15 = Math.floor(Math.log(value12) / Math.log(value13));
  return Math.round(value12 / Math.pow(value13, value15) * 100) / 100 + " " + value14[value15];
};
const sleep = value16 => new Promise(value17 => setTimeout(value17, value16));
const parseMentions = value18 => {
  const value19 = [];
  const value20 = /@(\d+)/g;
  let value21;
  while ((value21 = value20.exec(value18)) !== null) {
    value19.push(value21[1] + "@s.whatsapp.net");
  }
  return value19;
};
const getQuoted = value22 => {
  if (value22.message.extendedTextMessage) {
    return value22.message.extendedTextMessage.contextInfo?.quotedMessage;
  }
  return null;
};
const uploadFile = async (value23, value24 = "file") => {
  const value25 = require("form-data");
  const value26 = process.env.IMGBB_API_KEY;
  if (value26) {
    try {
      const value27 = new value25();
      value27.append("image", value23.toString("base64"));
      const value28 = await axios.post("https://api.imgbb.com/1/upload?key=" + value26, value27, {
        headers: value27.getHeaders(),
        timeout: 30000
      });
      const value29 = value28.data?.data?.url;
      if (value29) {
        return value29;
      }
    } catch (error30) {}
  }
  try {
    const value31 = new value25();
    value31.append("reqtype", "fileupload");
    value31.append("fileToUpload", value23, {
      filename: value24
    });
    const value32 = await axios.post("https://catbox.moe/user/api.php", value31, {
      headers: value31.getHeaders(),
      timeout: 60000
    });
    const value33 = (value32.data || "").trim();
    if (value33.startsWith("http")) {
      return value33;
    }
  } catch (error34) {}
  try {
    const value35 = new value25();
    value35.append("file", value23, {
      filename: value24
    });
    const value36 = await axios.post("https://file.io", value35, {
      headers: value35.getHeaders(),
      timeout: 30000
    });
    if (value36.data?.success) {
      return value36.data.link;
    }
  } catch (error37) {}
  throw new Error("All upload services failed");
};
const extractUrl = value38 => {
  const value39 = /(https?:\/\/[^\s]+)/gi;
  const value40 = value38.match(value39);
  if (value40) {
    return value40[0];
  } else {
    return null;
  }
};
const random = value41 => {
  return value41[Math.floor(Math.random() * value41.length)];
};
const isUrl = value42 => {
  const value43 = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
  return value43.test(value42);
};
const runtime = value44 => {
  value44 = Number(value44);
  const value45 = Math.floor(value44 / 86400);
  const value46 = Math.floor(value44 % 86400 / 3600);
  const value47 = Math.floor(value44 % 3600 / 60);
  const value48 = Math.floor(value44 % 60);
  const value49 = [];
  if (value45 > 0) {
    value49.push(value45 + "d");
  }
  if (value46 > 0) {
    value49.push(value46 + "h");
  }
  if (value47 > 0) {
    value49.push(value47 + "m");
  }
  if (value48 > 0) {
    value49.push(value48 + "s");
  }
  return value49.join(" ");
};
const BK9_URL = "https://api.bk9.dev/ai/gemini";
const COD3_COPILOT_URL = "https://api.cod3uchiha.com/ai/copilot";
const COD3_GPT5_URL = "https://api.cod3uchiha.com/ai/gpt5";
const AI_MODELS = {
  gpt: {
    name: "GPT-compatible fallback",
    icon: "🤖",
    category: "text"
  },
  "nvidia-chat": {
    name: "NVIDIA Chat",
    icon: "🟢",
    category: "text",
    provider: "nvidia"
  }
};
const MODEL_PRIORITY = ["gpt", "nvidia-chat"];
function getAIQuerySources(value50) {
  return [{
    url: BK9_URL,
    params: {
      q: value50
    }
  }, {
    url: COD3_COPILOT_URL,
    params: {
      text: value50
    }
  }, {
    url: COD3_GPT5_URL,
    params: {
      text: value50
    }
  }];
}
function extractXJuneResponse(value51) {
  if (!value51) {
    return null;
  }
  if (typeof value51 === "string") {
    const value52 = value51.trim();
    if (/^<!doctype|^<html/i.test(value52) || value52.length < 3) {
      return null;
    } else {
      return value52;
    }
  }
  for (const value53 of ["BK9", "result", "response", "text", "message", "answer", "content", "output", "reply"]) {
    if (typeof value51[value53] === "string" && value51[value53].trim()) {
      return value51[value53].trim();
    }
  }
  if (value51.data && typeof value51.data === "object") {
    return extractXJuneResponse(value51.data);
  }
  if (typeof value51.data === "string") {
    return value51.data.trim();
  }
  return null;
}
function extractImageUrl(value54) {
  if (typeof value54 === "string" && /^https?:\/\//i.test(value54)) {
    return value54;
  }
  if (!value54 || typeof value54 !== "object") {
    return null;
  }
  for (const value55 of ["url", "image", "image_url", "result", "output"]) {
    const value56 = value54[value55];
    if (typeof value56 === "string" && /^https?:\/\//i.test(value56)) {
      return value56;
    }
    if (Array.isArray(value56) && typeof value56[0] === "string") {
      return value56[0];
    }
    if (Array.isArray(value56) && value56[0]?.url) {
      return value56[0].url;
    }
  }
  return null;
}
function getModelList() {
  return Object.entries(AI_MODELS).map(([value57, value58]) => ({
    key: value57,
    name: value58.name,
    icon: value58.icon,
    category: value58.category,
    vision: !!value58.vision,
    provider: value58.provider || "api"
  }));
}
module.exports = {
  downloadMedia: downloadMedia,
  formatDuration: formatDuration,
  formatSize: formatSize,
  sleep: sleep,
  parseMentions: parseMentions,
  getQuoted: getQuoted,
  uploadFile: uploadFile,
  extractUrl: extractUrl,
  random: random,
  isUrl: isUrl,
  runtime: runtime,
  BK9_URL: BK9_URL,
  COD3_COPILOT_URL: COD3_COPILOT_URL,
  COD3_GPT5_URL: COD3_GPT5_URL,
  AI_MODELS: AI_MODELS,
  MODEL_PRIORITY: MODEL_PRIORITY,
  getAIQuerySources: getAIQuerySources,
  extractXJuneResponse: extractXJuneResponse,
  extractImageUrl: extractImageUrl,
  getModelList: getModelList
};
