const db = require("../database");
const VALID_MODES = db.VALID_BOT_MODES;
function getMode() {
  return db.getBotMode();
}
function setMode(value1) {
  return db.setBotMode(value1);
}
function getModeLabel() {
  const value2 = {
    public: "🌐 Public",
    private: "🔒 Private",
    group: "👥 Group Only",
    pm: "💬 PM Only",
    silent: "🔒 Private",
    groups: "👥 Group Only",
    dms: "💬 PM Only"
  };
  return value2[getMode()] || "🌐 Public";
}
module.exports = {
  getMode: getMode,
  setMode: setMode,
  getModeLabel: getModeLabel,
  VALID_MODES: VALID_MODES
};
