const fs = require("fs");
const path = require("path");
const {
  getTempDir
} = require("./tempManager");
const CLEANUP_INTERVAL_MS = 600000;
const TEMP_FILE_AGE_MS = 1800000;
const ROOT_JUNK_AGE_MS = 3600000;
const SESSION_DIR_NAME = "session";
const ROOT_JUNK_NAME_PATTERN = /^(?:tmp|temp|download|converted|upload|media|sticker)[._-]/i;
const ROOT_JUNK_EXTENSIONS = new Set([".gif", ".png", ".mp3", ".mp4", ".opus", ".jpg", ".jpeg", ".webp", ".webm", ".zip"]);
const BOT_ROOT = path.join(__dirname, "..");
let scheduledInterval = null;
let sweepRunning = false;
function sweepDir({
  dir: value1,
  ageMs: value2,
  namePattern = null,
  extensions = null,
  now = Date.now()
}) {
  if (!value1 || !fs.existsSync(value1)) {
    return {
      deleted: 0,
      bytesFreed: 0
    };
  }
  const value3 = now - value2;
  let value4 = 0;
  let value5 = 0;
  const value6 = fs.readdirSync(value1, {
    withFileTypes: true
  });
  for (const value7 of value6) {
    if (!value7.isFile()) {
      continue;
    }
    if (value7.name === SESSION_DIR_NAME) {
      continue;
    }
    if (namePattern && !namePattern.test(value7.name)) {
      continue;
    }
    if (extensions && !extensions.has(path.extname(value7.name).toLowerCase())) {
      continue;
    }
    const value8 = path.join(value1, value7.name);
    try {
      const value9 = fs.statSync(value8);
      if (value9.mtimeMs >= value3) {
        continue;
      }
      fs.unlinkSync(value8);
      value4 += 1;
      value5 += value9.size;
    } catch (error10) {
      if (!/ENOENT|EBUSY|EPERM/.test(error10.code || error10.message)) {
        console.warn("[Cleanup] could not process " + value8 + ": " + error10.message);
      }
    }
  }
  return {
    deleted: value4,
    bytesFreed: value5
  };
}
function sweepRootJunk({
  rootDir = BOT_ROOT,
  now = Date.now()
} = {}) {
  return sweepDir({
    dir: rootDir,
    ageMs: ROOT_JUNK_AGE_MS,
    namePattern: ROOT_JUNK_NAME_PATTERN,
    extensions: ROOT_JUNK_EXTENSIONS,
    now: now
  });
}
function sweepTempDir({
  tempDir = getTempDir(),
  now = Date.now()
} = {}) {
  return sweepDir({
    dir: tempDir,
    ageMs: TEMP_FILE_AGE_MS,
    now: now
  });
}
async function runFileSweep(value11, {
  rootDir: value12,
  tempDir: value13
} = {}) {
  if (sweepRunning) {
    return {
      rootDeleted: 0,
      tempDeleted: 0,
      bytesFreed: 0,
      skipped: true
    };
  }
  sweepRunning = true;
  try {
    const value14 = sweepRootJunk({
      rootDir: value12
    });
    const value15 = sweepTempDir({
      tempDir: value13
    });
    const value16 = value14.deleted + value15.deleted;
    const value17 = value14.bytesFreed + value15.bytesFreed;
    if (value16 > 0) {
      const value18 = (value17 / 1048576).toFixed(2);
      console.log("🧹 Cleanup: removed " + value16 + " expired temporary file(s), freed " + value18 + " MB (root: " + value14.deleted + ", temp/: " + value15.deleted + ")");
      if (value11 && value11.user && value11.user.id) {
        value11.sendMessage(value11.user.id.split(":")[0] + "@s.whatsapp.net", {
          text: "🧹 Removed " + value16 + " expired temporary file(s)."
        }).catch(() => {});
      }
    }
    return {
      rootDeleted: value14.deleted,
      tempDeleted: value15.deleted,
      bytesFreed: value17
    };
  } finally {
    sweepRunning = false;
  }
}
function startScheduledCleanups(value19, {
  initialSweep = true
} = {}) {
  if (scheduledInterval) {
    return scheduledInterval;
  }
  if (initialSweep) {
    Promise.resolve(runFileSweep(value19)).catch(value20 => {
      console.error("[Cleanup] startup sweep failed:", value20.message);
    });
  }
  scheduledInterval = setInterval(() => {
    Promise.resolve(runFileSweep(value19)).catch(() => {});
  }, CLEANUP_INTERVAL_MS);
  if (Array.isArray(global._activeIntervals)) {
    global._activeIntervals.push(scheduledInterval);
  }
  return scheduledInterval;
}
function stopScheduledCleanups() {
  if (!scheduledInterval) {
    return;
  }
  clearInterval(scheduledInterval);
  if (Array.isArray(global._activeIntervals)) {
    const value21 = global._activeIntervals.indexOf(scheduledInterval);
    if (value21 !== -1) {
      global._activeIntervals.splice(value21, 1);
    }
  }
  scheduledInterval = null;
}
module.exports = {
  runFileSweep: runFileSweep,
  startScheduledCleanups: startScheduledCleanups,
  stopScheduledCleanups: stopScheduledCleanups,
  sweepRootJunk: sweepRootJunk,
  sweepTempDir: sweepTempDir,
  CLEANUP_INTERVAL_MS: CLEANUP_INTERVAL_MS,
  TEMP_FILE_AGE_MS: TEMP_FILE_AGE_MS,
  ROOT_JUNK_AGE_MS: ROOT_JUNK_AGE_MS
};
