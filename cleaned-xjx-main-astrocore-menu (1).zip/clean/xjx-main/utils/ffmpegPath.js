const {
  execSync
} = require("child_process");
const fs = require("fs");
const path = require("path");
const CANDIDATES = [(() => {
  try {
    return execSync("which ffmpeg", {
      encoding: "utf8"
    }).trim();
  } catch {
    return null;
  }
})(), "/usr/bin/ffmpeg", "/usr/local/bin/ffmpeg", path.join(__dirname, "..", "data", "ffmpeg", "ffmpeg"), (() => {
  try {
    const value1 = require("ffmpeg-static");
    if (value1 && fs.existsSync(value1)) {
      return value1;
    } else {
      return null;
    }
  } catch {
    return null;
  }
})()];
let cached = null;
function resolveFfmpegPath() {
  if (cached) {
    if (cached === "ffmpeg") {
      cached = null;
    } else if (fs.existsSync(cached)) {
      return cached;
    } else {
      cached = null;
    }
  }
  cached = CANDIDATES.find(value2 => value2 && value2 !== "ffmpeg" && fs.existsSync(value2)) || "ffmpeg";
  return cached;
}
module.exports = resolveFfmpegPath;
module.exports.__resetCache = () => {
  cached = null;
};
