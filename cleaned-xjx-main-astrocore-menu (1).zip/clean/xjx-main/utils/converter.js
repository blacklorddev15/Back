const fs = require("fs");
const path = require("path");
const {
  spawn
} = require("child_process");
const ffmpegBin = require("./ffmpegPath");
function ffmpeg(value1, value2 = [], value3 = "", value4 = "") {
  return new Promise(async (value5, value6) => {
    try {
      const value7 = path.join(__dirname, "../temp");
      if (!fs.existsSync(value7)) {
        fs.mkdirSync(value7, {
          recursive: true
        });
      }
      let value8 = path.join(value7, Date.now() + "." + value3);
      let value9 = value8 + "." + value4;
      await fs.promises.writeFile(value8, value1);
      spawn(ffmpegBin(), ["-y", "-i", value8, ...value2, value9]).on("error", value6).on("close", async value10 => {
        try {
          await fs.promises.unlink(value8);
          if (value10 !== 0) {
            return value6(value10);
          }
          value5(await fs.promises.readFile(value9));
          await fs.promises.unlink(value9);
        } catch (error11) {
          value6(error11);
        }
      });
    } catch (error12) {
      value6(error12);
    }
  });
}
function toAudio(value13, value14) {
  return ffmpeg(value13, ["-vn", "-ac", "2", "-b:a", "128k", "-ar", "44100", "-f", "mp3"], value14, "mp3");
}
function toPTT(value15, value16) {
  return ffmpeg(value15, ["-vn", "-c:a", "libopus", "-b:a", "128k", "-vbr", "on", "-compression_level", "10"], value16, "opus");
}
function toVideo(value17, value18) {
  return ffmpeg(value17, ["-c:v", "libx264", "-c:a", "aac", "-ab", "128k", "-ar", "44100", "-crf", "32", "-preset", "slow"], value18, "mp4");
}
module.exports = {
  toAudio: toAudio,
  toPTT: toPTT,
  toVideo: toVideo,
  ffmpeg: ffmpeg
};
