function createMessageStore({
  maxPerChat = 20,
  maxChats = 300
} = {}) {
  const value1 = new Map();
  function handler2(value3, value4) {
    if (!value3 || !value4 || !value4.key || !value4.key.id) {
      return;
    }
    let value5 = value1.get(value3);
    if (!value5) {
      value5 = new Map();
      value1.set(value3, value5);
    } else {
      value1.delete(value3);
      value1.set(value3, value5);
    }
    value5.set(value4.key.id, value4);
    while (value5.size > maxPerChat) {
      value5.delete(value5.keys().next().value);
    }
    while (value1.size > maxChats) {
      value1.delete(value1.keys().next().value);
    }
  }
  function handler6(value7) {
    const value8 = Math.max(0, Math.floor(value7));
    while (value1.size > value8) {
      value1.delete(value1.keys().next().value);
    }
    return value1.size;
  }
  return {
    messages: value1,
    maxPerChat: maxPerChat,
    maxChats: maxChats,
    storeMessage: handler2,
    evictOldestChats: handler6,
    bind(value9) {
      value9.on("messages.upsert", ({
        messages: value10
      }) => {
        for (const value11 of value10 || []) {
          handler2(value11.key?.remoteJid, value11);
        }
      });
    },
    async loadMessage(value12, value13) {
      return value1.get(value12)?.get(value13) || null;
    }
  };
}
module.exports = {
  createMessageStore: createMessageStore
};
