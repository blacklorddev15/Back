const fs = require("fs");
const path = require("path");
const PROJECT_ROOT = process.cwd();
const TEMP_DIR = path.join(PROJECT_ROOT, "temp");
function initializeTempSystem() {
  const value1 = path.resolve(TEMP_DIR);
  process.env.TMPDIR = value1;
  process.env.TMP = value1;
  process.env.TEMP = value1;
  if (process.platform === "win32") {
    process.env.TEMP = value1;
    process.env.TMP = value1;
  }
  if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, {
      recursive: true
    });
  }
  return TEMP_DIR;
}
function getTempDir() {
  if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, {
      recursive: true
    });
  }
  return TEMP_DIR;
}
function createTempFilePath(value2 = "temp", value3 = "tmp") {
  const value4 = getTempDir();
  const value5 = Date.now();
  const value6 = Math.random().toString(36).slice(2);
  const value7 = value2 + "_" + value5 + "_" + value6 + "." + value3;
  return path.join(value4, value7);
}
function deleteTempFile(value8) {
  try {
    if (value8 && fs.existsSync(value8)) {
      const value9 = path.resolve(value8);
      const value10 = path.resolve(TEMP_DIR);
      if (value9.startsWith(value10)) {
        fs.unlinkSync(value8);
        return true;
      } else {
        console.warn("Attempted to delete file outside temp directory: " + value8);
        return false;
      }
    }
    return false;
  } catch (error11) {
    console.error("Error deleting temp file " + value8 + ":", error11.message);
    return false;
  }
}
function deleteTempFiles(value12) {
  if (!Array.isArray(value12)) {
    return;
  }
  value12.forEach(value13 => {
    deleteTempFile(value13);
  });
}
module.exports = {
  initializeTempSystem: initializeTempSystem,
  getTempDir: getTempDir,
  createTempFilePath: createTempFilePath,
  deleteTempFile: deleteTempFile,
  deleteTempFiles: deleteTempFiles,
  TEMP_DIR: TEMP_DIR
};
