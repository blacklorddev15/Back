const axios = require("axios");
const api = axios.create({
  timeout: 30000,
  headers: {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
  }
});
const DOWNLOAD_HEADERS = {
  timeout: 60000,
  headers: {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Accept: "application/json, text/plain, */*"
  }
};
const NVIDIA_BASE_URL = "https://integrate.api.nvidia.com/v1/chat/completions";
const NVIDIA_DEFAULT_MODEL = "nvidia/nemotron-nano-12b-v2-vl";
function getNvidiaApiKey() {
  const value1 = "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";
  if (!value1) {
    throw new Error("NVIDIA_API_KEY is not set. Get a free key at https://build.nvidia.com and add it to your environment secrets.");
  }
  return value1;
}
async function callNvidia({
  messages: value2,
  model: value3,
  maxTokens: value4,
  temperature: value5,
  timeoutMs: value6
}) {
  const {
    data: value7
  } = await axios.post(NVIDIA_BASE_URL, {
    model: value3 || NVIDIA_DEFAULT_MODEL,
    messages: value2,
    max_tokens: value4 ?? 2048,
    temperature: value5 ?? 0.7,
    top_p: 0.95,
    stream: false
  }, {
    headers: {
      Authorization: "Bearer " + getNvidiaApiKey(),
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    timeout: value6 ?? 90000
  });
  const value8 = value7?.choices?.[0]?.message?.content;
  if (!value8) {
    throw new Error("Empty response from NVIDIA API");
  }
  if (typeof value8 === "string") {
    return value8;
  } else {
    return value8.map(value9 => typeof value9 === "string" ? value9 : value9.text || "").join("");
  }
}
const tryRequest = async (value10, value11 = 3) => {
  let value12;
  for (let value13 = 1; value13 <= value11; value13++) {
    try {
      return await value10();
    } catch (error14) {
      value12 = error14;
      if (value13 < value11) {
        await new Promise(value15 => setTimeout(value15, value13 * 1000));
      }
    }
  }
  throw value12;
};
const APIs = {
  generateImage: async value16 => {
    try {
      const value17 = await api.get("https://api.siputzx.my.id/api/ai/stablediffusion", {
        params: {
          prompt: value16
        }
      });
      return value17.data;
    } catch {
      throw new Error("Failed to generate image");
    }
  },
  chatAI: async value18 => {
    try {
      const value19 = await api.get("https://api.shizo.top/ai/gpt?apikey=shizo&query=" + encodeURIComponent(value18));
      if (value19.data?.msg) {
        return {
          msg: value19.data.msg
        };
      }
      return value19.data;
    } catch {
      throw new Error("Failed to get AI response");
    }
  },
  nvidiaChat: async (value20, value21 = {}) => {
    const {
      model: value22,
      system: value23,
      maxTokens: value24,
      temperature: value25,
      timeoutMs: value26
    } = value21;
    const value27 = [];
    if (value23) {
      value27.push({
        role: "system",
        content: value23
      });
    }
    value27.push({
      role: "user",
      content: value20
    });
    return callNvidia({
      messages: value27,
      model: value22,
      maxTokens: value24,
      temperature: value25,
      timeoutMs: value26
    });
  },
  nvidiaVision: async (value28, value29, value30 = {}) => {
    const {
      model: value31,
      maxTokens: value32,
      temperature: value33,
      timeoutMs: value34
    } = value30;
    let value35;
    if (Buffer.isBuffer(value29)) {
      const value36 = value29.toString("base64");
      value35 = "data:image/jpeg;base64," + value36;
    } else if (typeof value29 === "string") {
      value35 = value29;
    } else {
      throw new Error("nvidiaVision(): image must be a Buffer or URL string");
    }
    const value37 = [{
      role: "user",
      content: [{
        type: "text",
        text: value28 || "Describe this image in detail."
      }, {
        type: "image_url",
        image_url: {
          url: value35
        }
      }]
    }];
    return callNvidia({
      messages: value37,
      model: value31,
      maxTokens: value32,
      temperature: value33,
      timeoutMs: value34
    });
  },
  nvidiaImage: async (value38, value39 = {}) => {
    const {
      width = 1024,
      height = 1024,
      timeoutMs = 120000,
      model: value40
    } = value39;
    try {
      const value41 = await axios.post("https://ai.api.nvidia.com/v1/genai/black-forest-labs/flux.1-dev", {
        prompt: value38,
        width: width,
        height: height
      }, {
        headers: {
          Authorization: "Bearer " + getNvidiaApiKey(),
          "Content-Type": "application/json",
          Accept: "application/json"
        },
        timeout: timeoutMs
      });
      const value42 = value41.data?.artifacts || value41.data?.images || value41.data?.data;
      const value43 = Array.isArray(value42) ? value42[0] : value42;
      const value44 = value43?.base64 || value43?.b64 || value41.data?.b64;
      if (value44 && typeof value44 === "string") {
        return Buffer.from(value44, "base64");
      }
      const value45 = value41.data?.data?.[0]?.b64_json;
      if (value45) {
        return Buffer.from(value45, "base64");
      }
      const value46 = value43?.url || value43?.image_url || value41.data?.url;
      if (value46 && typeof value46 === "string") {
        const value47 = await axios.get(value46, {
          responseType: "arraybuffer",
          timeout: timeoutMs
        });
        if (value47.data && value47.data.length) {
          return Buffer.from(value47.data);
        }
      }
      return null;
    } catch (error48) {
      console.error("[NVIDIA FLUX]", error48.message);
      return null;
    }
  },
  pollinationsImage: async (value49, value50 = {}) => {
    const {
      width = 1024,
      height = 1024,
      timeoutMs = 60000
    } = value50;
    try {
      const value51 = "https://image.pollinations.ai/prompt/" + encodeURIComponent(value49) + "?width=" + width + "&height=" + height + "&nologo=true";
      const value52 = await axios.get(value51, {
        responseType: "arraybuffer",
        timeout: timeoutMs
      });
      if (value52.data && value52.data.length) {
        return Buffer.from(value52.data);
      }
      return null;
    } catch (error53) {
      console.error("[Pollinations]", error53.message);
      return null;
    }
  },
  translate: async (value54, value55 = "en") => {
    try {
      const value56 = await api.get("https://api.siputzx.my.id/api/tools/translate", {
        params: {
          text: value54,
          to: value55
        }
      });
      const value57 = value56.data?.data?.translatedText || value56.data?.translatedText || value56.data?.result || value56.data?.translation;
      if (!value57) {
        throw new Error("No translation returned");
      }
      return {
        translation: value57
      };
    } catch {
      throw new Error("Translation failed");
    }
  },
  wikiSearch: async value58 => {
    try {
      const value59 = await api.get("https://en.wikipedia.org/api/rest_v1/page/summary/" + encodeURIComponent(value58));
      return value59.data;
    } catch {
      throw new Error("Wikipedia search failed");
    }
  },
  shortenUrl: async value60 => {
    try {
      const value61 = await api.get("https://tinyurl.com/api-create.php", {
        params: {
          url: value60
        }
      });
      return value61.data;
    } catch {
      throw new Error("Failed to shorten URL");
    }
  },
  screenshotWebsite: async value62 => {
    try {
      const value63 = await axios.get("https://eliteprotech-apis.zone.id/ssweb?url=" + encodeURIComponent(value62), {
        timeout: 30000,
        responseType: "arraybuffer",
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
      });
      if (value63.headers["content-type"]?.includes("image")) {
        return Buffer.from(value63.data);
      }
      try {
        const value64 = JSON.parse(Buffer.from(value63.data).toString());
        return value64.url || value64.data?.url || value64.image;
      } catch {
        return Buffer.from(value63.data);
      }
    } catch {
      throw new Error("Failed to take screenshot");
    }
  },
  textToSpeech: async value65 => {
    try {
      const value66 = await axios.get("https://www.laurine.site/api/tts/tts-nova?text=" + encodeURIComponent(value65), {
        timeout: 30000,
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
      });
      const value67 = value66.data;
      if (!value67) {
        throw new Error("Empty response");
      }
      if (typeof value67 === "string" && value67.startsWith("http")) {
        return value67;
      }
      const value68 = value67.data || value67;
      if (value68.URL) {
        return value68.URL;
      }
      if (value68.url) {
        return value68.url;
      }
      if (value68.MP3) {
        return "https://ttsmp3.com/created_mp3_ai/" + value68.MP3;
      }
      if (value68.mp3) {
        return "https://ttsmp3.com/created_mp3_ai/" + value68.mp3;
      }
      throw new Error("Invalid API response structure");
    } catch (error69) {
      throw new Error("Failed to generate speech: " + error69.message);
    }
  },
  getMeme: async () => {
    try {
      const value70 = await api.get("https://meme-api.com/gimme");
      return value70.data;
    } catch {
      throw new Error("Failed to fetch meme");
    }
  },
  getQuote: async () => {
    try {
      const value71 = await api.get("https://zenquotes.io/api/random");
      const value72 = Array.isArray(value71.data) ? value71.data[0] : value71.data;
      return {
        content: value72.q,
        author: value72.a
      };
    } catch {
      throw new Error("Failed to fetch quote");
    }
  },
  getJoke: async () => {
    try {
      const value73 = await api.get("https://official-joke-api.appspot.com/random_joke");
      return value73.data;
    } catch {
      throw new Error("Failed to fetch joke");
    }
  },
  getWeather: async value74 => {
    try {
      const value75 = await api.get("https://api.siputzx.my.id/api/tools/weather", {
        params: {
          city: value74
        }
      });
      return value75.data;
    } catch {
      throw new Error("Failed to fetch weather");
    }
  },
  getIzumiDownloadByUrl: async value76 => {
    const value77 = await tryRequest(() => axios.get("https://apissupreme.vercel.app/media/ytmp3?apikey=supreme&url=" + encodeURIComponent(value76), DOWNLOAD_HEADERS));
    if (value77?.data?.status && value77?.data?.downloadUrl) {
      return {
        download: value77.data.downloadUrl,
        title: value77.data.title,
        thumbnail: value77.data.thumbnail,
        duration: value77.data.duration,
        source: value77.data.source
      };
    }
    throw new Error("no download URL returned");
  },
  getIzumiDownloadByQuery: async value78 => {
    const value79 = await tryRequest(() => axios.get("https://yt-dl.officialhectormanuel.workers.dev/?url=" + encodeURIComponent(value78), DOWNLOAD_HEADERS));
    if (value79?.data?.audio) {
      return {
        download: value79.data.audio,
        title: value79.data.title,
        thumbnail: value79.data.thumbnail
      };
    }
    throw new Error("Izumi query: no download URL returned");
  },
  getEliteProTechDownloadByUrl: async value80 => {
    const value81 = await tryRequest(() => axios.get("https://yt-dl.officialhectormanuel.workers.dev/?url=" + encodeURIComponent(value80), DOWNLOAD_HEADERS));
    if (value81?.data?.audio) {
      return {
        download: value81.data.audio,
        title: value81.data.title
      };
    }
    throw new Error("casper audio: no download URL returned");
  },
  getEliteProTechVideoByUrl: async value82 => {
    const value83 = await tryRequest(() => axios.get("https://apiskeith2-production-3679.up.railway.app/download/video?url=" + encodeURIComponent(value82) + "&format=mp4", DOWNLOAD_HEADERS));
    if (value83?.data?.status && value83?.data?.result) {
      return {
        download: value83.data.result,
        title: value83.data.title
      };
    }
    throw new Error("video: no download URL returned");
  },
  igDownload: async value84 => {
    try {
      const value85 = await api.get("https://api.siputzx.my.id/api/d/igdl", {
        params: {
          url: value84
        }
      });
      return value85.data;
    } catch {
      throw new Error("Failed to download Instagram content");
    }
  },
  getTikTokDownload: async value86 => {
    try {
      const value87 = await axios.get("https://api.siputzx.my.id/api/d/tiktok?url=" + encodeURIComponent(value86), {
        timeout: 15000,
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
      });
      if (value87.data?.status && value87.data?.data) {
        const value88 = value87.data.data;
        const value89 = value88.urls?.[0] || value88.video_url || value88.url || value88.download_url || null;
        const value90 = value88.metadata?.title || "TikTok Video";
        return {
          videoUrl: value89,
          title: value90
        };
      }
      throw new Error("Invalid API response");
    } catch {
      throw new Error("TikTok download failed");
    }
  },
  stalkGitHub: async value91 => {
    const value92 = await api.get("https://apis.xwolf.space/api/stalk/github", {
      params: {
        username: value91
      },
      timeout: 20000
    });
    const value93 = value92.data;
    const value94 = value93?.result || value93?.data || value93;
    if (!value94 || !value94.login && !value94.username) {
      throw new Error("User not found on GitHub");
    }
    return value93;
  },
  stalkInstagram: async value95 => {
    const value96 = await api.get(globalThis._apiOverrides?.igstalk || "https://api.giftedtech.co.ke/api/stalk/igstalk", {
      params: {
        apikey: "gifted",
        username: value95
      },
      timeout: 20000
    });
    if (!value96.data?.success || !value96.data?.result) {
      throw new Error("User not found");
    }
    return value96.data.result;
  },
  stalkIp: async value97 => {
    const value98 = await api.get(globalThis._apiOverrides?.ipstalk || "https://api.giftedtech.co.ke/api/stalk/ipstalk", {
      params: {
        apikey: "gifted",
        address: value97
      },
      timeout: 20000
    });
    if (!value98.data?.success || !value98.data?.result) {
      throw new Error("Could not retrieve IP information");
    }
    return value98.data.result;
  },
  stalkNpm: async value99 => {
    const value100 = await api.get(globalThis._apiOverrides?.npmstalk || "https://api.giftedtech.co.ke/api/stalk/npmstalk", {
      params: {
        apikey: "gifted",
        packagename: value99
      },
      timeout: 25000
    });
    if (!value100.data?.success || !value100.data?.result) {
      throw new Error("Package not found on NPM");
    }
    return value100.data.result;
  },
  stalkTikTok: async value101 => {
    try {
      const value102 = await api.get("https://apis.xwolf.space/api/stalk/tiktok", {
        params: {
          username: value101
        },
        timeout: 15000
      });
      const value103 = value102.data;
      if (value103?.success && value103?.username) {
        return {
          name: value103.nickname || value103.username,
          username: value103.username,
          bio: value103.bio || "N/A",
          avatar: value103.avatar || null,
          followers: value103.followers ?? 0,
          following: value103.following ?? 0,
          likes: value103.likes ?? 0,
          videos: value103.videos ?? null,
          verified: value103.verified ?? false,
          private: value103.privateAccount ?? false,
          profileUrl: value103.profileUrl || null,
          source: "xwolf"
        };
      }
    } catch {}
    const value104 = await api.get("https://api.giftedtech.co.ke/api/stalk/tiktokstalk", {
      params: {
        apikey: "gifted",
        username: value101
      },
      timeout: 20000
    });
    if (!value104.data?.success || !value104.data?.result) {
      throw new Error("User not found");
    }
    const value105 = value104.data.result;
    return {
      name: value105.name || value105.username,
      username: value105.username || value101,
      bio: value105.bio || "N/A",
      avatar: value105.avatar || null,
      followers: value105.followers ?? 0,
      following: value105.following ?? 0,
      likes: value105.likes ?? 0,
      videos: null,
      verified: value105.verified ?? false,
      private: value105.private ?? false,
      profileUrl: value105.website?.link || null,
      source: "gifted"
    };
  },
  stalkTwitter: async value106 => {
    const value107 = await api.get(globalThis._apiOverrides?.twitterstalk || "https://api.giftedtech.co.ke/api/stalk/twitterstalk", {
      params: {
        apikey: "gifted",
        username: value106
      },
      timeout: 25000
    });
    if (!value107.data?.success || !value107.data?.result) {
      throw new Error("User not found or Twitter API unavailable");
    }
    return value107.data.result;
  },
  stalkWachannel: async value108 => {
    const value109 = await api.get("https://api.giftedtech.co.ke/api/stalk/wachannel", {
      params: {
        apikey: "gifted",
        url: value108
      },
      timeout: 20000
    });
    if (!value109.data?.success || !value109.data?.result) {
      throw new Error("Channel not found or invalid URL");
    }
    return value109.data.result;
  }
};
APIs.NVIDIA_DEFAULT_MODEL = NVIDIA_DEFAULT_MODEL;
APIs.NVIDIA_BASE_URL = NVIDIA_BASE_URL;
APIs.getNvidiaApiKey = getNvidiaApiKey;
module.exports = APIs;
