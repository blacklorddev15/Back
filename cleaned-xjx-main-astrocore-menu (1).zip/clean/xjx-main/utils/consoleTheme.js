'use strict';

const chalk = require("chalk");
const db = require("../database");
const KEY = "consoleTheme";
const VALID = ["auto", "dark", "light"];
const DAY_START_HOUR = 6;
const NIGHT_START_HOUR = 18;
function _validTz(value1) {
  if (!value1 || typeof value1 !== "string") {
    return false;
  }
  try {
    new Intl.DateTimeFormat("en-US", {
      timeZone: value1
    }).format(new Date());
    return true;
  } catch (error2) {
    return false;
  }
}
function getTimeZone() {
  if (typeof db.getTimeZone === "function") {
    try {
      return db.getTimeZone();
    } catch (error3) {}
  }
  try {
    const value4 = db.getBotSetting("timezone");
    if (_validTz(value4)) {
      return value4;
    }
  } catch (error5) {}
  if (_validTz(process.env.TIMEZONE)) {
    return process.env.TIMEZONE;
  }
  return "UTC";
}
function getTimeZoneSource() {
  if (typeof db.getTimeZoneSource === "function") {
    try {
      return db.getTimeZoneSource();
    } catch (error6) {}
  }
  try {
    if (_validTz(db.getBotSetting("timezone"))) {
      return "bot";
    }
  } catch (error7) {}
  if (_validTz(process.env.TIMEZONE)) {
    return "env";
  }
  return "default";
}
function nowParts() {
  const value8 = getTimeZone();
  const value9 = new Date();
  const value10 = value9.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
    timeZone: value8
  });
  const value11 = Number(value9.toLocaleString("en-US", {
    hour: "2-digit",
    hour12: false,
    timeZone: value8
  }));
  return {
    time: value10,
    hour: Number.isFinite(value11) ? value11 : 0
  };
}
function getMode() {
  return "dark";
}
function setMode(value12) {
  return false;
}
function currentTheme() {
  const value13 = getMode();
  if (value13 === "dark" || value13 === "light") {
    return value13;
  }
  const {
    hour: value14
  } = nowParts();
  if (value14 >= DAY_START_HOUR && value14 < NIGHT_START_HOUR) {
    return "light";
  } else {
    return "dark";
  }
}
let _lastTheme = null;
function ensureTheme() {
  const value15 = currentTheme();
  if (_lastTheme === null) {
    _lastTheme = value15;
    return value15;
  }
  if (value15 === _lastTheme) {
    return value15;
  }
  const {
    time: value16,
    hour: value17
  } = nowParts();
  const value18 = String(value17).padStart(2, "0") + ":00";
  if (value15 === "light") {
    console.log(chalk.gray.bold("[" + value16 + "]") + " ☀️ " + chalk.green.bold("Console switched to white theme (June Lite style) — " + value18));
  } else {
    console.log(chalk.blue.bold("[ JUNEX ULTRA ]") + " " + chalk.yellow("🌙 Console switched to dark theme (June Ultra style) — " + value18));
  }
  _lastTheme = value15;
  return value15;
}
setInterval(() => {
  try {
    ensureTheme();
  } catch (error19) {}
}, 30000).unref();
function darkLog(value20, value21, value22) {
  const value23 = chalk.blue.bold("[ JUNEX ULTRA ]");
  const value24 = value22 ? console.error : console.log;
  const value25 = chalk[value21] ? chalk[value21](value20) : value20;
  if (String(value20).includes("\n") || String(value20).includes("════")) {
    value24(value23, value25);
  } else {
    value24(value23 + " " + value25);
  }
}
const LIGHT_ICON_BY_COLOR = {
  red: "❌",
  yellow: "⚠️",
  green: "✅",
  cyan: "🔌",
  magenta: "🗄️"
};
const LIGHT_PAINT_BY_COLOR = {
  red: value26 => chalk.red(value26),
  yellow: value27 => chalk.yellow(value27),
  green: value28 => chalk.green(value28),
  cyan: value29 => chalk.cyan(value29),
  magenta: value30 => chalk.magenta(value30),
  blue: value31 => chalk.blue(value31),
  gray: value32 => chalk.gray(value32),
  white: value33 => chalk.white(value33)
};
function lightLog(value34, value35, value36) {
  const {
    time: value37
  } = nowParts();
  const value38 = value36 ? "red" : LIGHT_PAINT_BY_COLOR[value35] ? value35 : "white";
  const value39 = value36 ? "❌" : LIGHT_ICON_BY_COLOR[value38] || "💡";
  const value40 = chalk.gray.bold("[" + value37 + "]");
  const value41 = LIGHT_PAINT_BY_COLOR[value38](String(value34));
  if (String(value34).includes("\n")) {
    console.log(value40, value39, value41);
  } else {
    console.log(value40 + " " + value39 + " " + value41);
  }
}
function log(value42, value43 = "white", value44 = false) {
  const value45 = ensureTheme();
  if (value45 === "light") {
    lightLog(value42, value43, value44);
  } else {
    darkLog(value42, value43, value44);
  }
}
function cmdLine(value46, value47, value48) {
  if (ensureTheme() === "dark") {
    console.log(chalk.magenta.bold("[ CMD ]"), chalk.cyan("✦ " + value46), chalk.yellow("← " + value47), value48 === "OWNER" ? chalk.green("[OWNER]") : value48 === "SUDO" ? chalk.blue("[SUDO]") : chalk.white("[USER]"));
    return;
  }
  const {
    time: value49
  } = nowParts();
  console.log(chalk.gray.bold("[" + value49 + "]") + " " + chalk.cyan.bold("⌨️ CMD") + " " + chalk.green.bold("✦ " + value46) + " " + chalk.yellow("← " + value47) + " " + (value48 === "OWNER" ? chalk.green("[OWNER]") : value48 === "SUDO" ? chalk.blue("[SUDO]") : chalk.gray("[USER]")));
}
const BOX_INNER = 50;
const BOX_BAR = "─".repeat(BOX_INNER);
const BOX_CYAN = "#00D9FF";
const MAX_MSG_LINES = 40;
function edge(value50) {
  return chalk.hex(BOX_CYAN).bold(value50);
}
function wrapLines(value51, value52) {
  const value53 = String(value51 ?? "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const value54 = [];
  for (const value55 of value53.split("\n")) {
    if (value55 === "") {
      value54.push("");
      continue;
    }
    let value56 = "";
    const value57 = value55.split(/(\s+)/);
    for (const value58 of value57) {
      if (value58.length > value52) {
        if (value56.trim()) {
          value54.push(value56.trimEnd());
          value56 = "";
        }
        for (let value59 = 0; value59 < value58.length; value59 += value52) {
          const value60 = value58.slice(value59, value59 + value52);
          if (value59 + value52 < value58.length) {
            value54.push(value60);
          } else {
            value56 = value60;
          }
        }
        continue;
      }
      if (value56.length + value58.length > value52) {
        value54.push(value56.trimEnd());
        value56 = value58.trimStart();
      } else {
        value56 += value58;
      }
    }
    value54.push(value56.trimEnd());
  }
  if (value54.length) {
    return value54;
  } else {
    return [""];
  }
}
function printLabeled(value61, value62, value63, value64) {
  const value65 = String(value62 ?? "");
  const value66 = " ".repeat(Math.max(value61.length + 1, 8));
  const value67 = Math.max(16, BOX_INNER - (value61.length + 2));
  const value68 = wrapLines(value65, value67);
  const value69 = value68.length > 1 ? value68.slice(1).join("\n") : "";
  const value70 = value69 ? wrapLines(value69, BOX_INNER - value66.length) : [];
  console.log(edge("│") + " " + value63(value61) + " " + value64(value68[0] || ""));
  for (const value71 of value70) {
    console.log(edge("│") + " " + value66 + value64(value71));
  }
}
function extractPhoneNumber(value72) {
  if (!value72) {
    return null;
  }
  return String(value72).replace("@s.whatsapp.net", "").replace("@lid", "").replace("@g.us", "").split(":")[0];
}
const TYPE_LABELS = {
  conversation: "TEXT",
  extendedTextMessage: "TEXT",
  imageMessage: "IMAGE",
  videoMessage: "VIDEO",
  audioMessage: "AUDIO",
  documentMessage: "DOCUMENT",
  stickerMessage: "STICKER",
  contactMessage: "CONTACT",
  locationMessage: "LOCATION"
};
function printMessage(value73, value74, value75, value76 = {}) {
  try {
    if (ensureTheme() !== "light") {
      return;
    }
    if (!value73?.key || !value74) {
      return;
    }
    const value77 = Object.keys(value74)[0];
    if (["senderKeyDistributionMessage", "protocolMessage", "reactionMessage"].includes(value77)) {
      return;
    }
    const value78 = value73.key.remoteJid;
    const value79 = value73.key.participant || value73.key.remoteJid;
    const value80 = String(value78).endsWith("@g.us");
    const value81 = !!value73.key.fromMe;
    let value82 = "";
    let value83 = "";
    if (value81) {
      value82 = value75?.user?.name || "Owner";
      value83 = extractPhoneNumber(value75?.user?.id || value75?.user?.jid) || "me";
    } else {
      value82 = (value73.pushName || "").trim();
      value83 = extractPhoneNumber(value79) || String(value79 || "").split("@")[0];
    }
    const value84 = value82 && value82 !== value83 ? value82 + " (" + value83 + ")" : value83;
    let value85 = "";
    let value86 = 0;
    if (value77 === "conversation") {
      value85 = value74.conversation || "";
    } else if (value77 === "extendedTextMessage") {
      value85 = value74.extendedTextMessage?.text || "";
    } else if (value77 === "imageMessage") {
      value85 = value74.imageMessage?.caption || "[Image]";
      value86 = value74.imageMessage?.fileLength || 0;
    } else if (value77 === "videoMessage") {
      value85 = value74.videoMessage?.caption || "[Video]";
      value86 = value74.videoMessage?.fileLength || 0;
    } else if (value77 === "audioMessage") {
      const value87 = value74.audioMessage?.seconds || 0;
      value85 = "[Audio " + Math.floor(value87 / 60) + ":" + String(value87 % 60).padStart(2, "0") + "]";
      value86 = value74.audioMessage?.fileLength || 0;
    } else if (value77 === "documentMessage") {
      value85 = "[📄 " + (value74.documentMessage?.fileName || "Document") + "]";
      value86 = value74.documentMessage?.fileLength || 0;
    } else if (value77 === "stickerMessage") {
      value85 = "[Sticker]";
      value86 = value74.stickerMessage?.fileLength || 0;
    } else if (value77 === "contactMessage") {
      value85 = "[👤 " + (value74.contactMessage?.displayName || "Contact") + "]";
    } else if (value77 === "locationMessage") {
      value85 = "[📍 Location]";
    } else {
      value85 = "[" + String(value77 || "msg").replace("Message", "") + "]";
    }
    let value88 = "";
    if (value86 > 0) {
      const value89 = Number(value86) || 0;
      if (value89 > 0) {
        const value90 = ["B", "KB", "MB", "GB"];
        const value91 = Math.min(3, Math.floor(Math.log(value89) / Math.log(1024)));
        value88 = " (" + (value89 / Math.pow(1024, value91)).toFixed(1) + " " + value90[value91] + ")";
      }
    }
    const value92 = value73.messageTimestamp ? new Date((value73.messageTimestamp.low || Number(value73.messageTimestamp) || 0) * 1000) : new Date();
    const value93 = value92 && !Number.isNaN(value92.getTime()) ? value92 : new Date();
    const value94 = value93.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
      timeZone: getTimeZone()
    });
    const value95 = /^\s*[.!#\/]/.test(String(value85));
    const value96 = TYPE_LABELS[value77] || String(value77 || "msg").replace("Message", "").toUpperCase();
    const value97 = String(value85).includes("JUNE") || String(value85).includes("Pinging...") || String(value85).includes("*🤖") || value81 && String(value85).includes("*");
    const value98 = value95 ? value99 => chalk.greenBright.bold(value99) : value97 ? value100 => chalk.cyan.bold(value100) : value81 ? value101 => chalk.blueBright.bold(value101) : value102 => chalk.white.bold(value102);
    console.log(edge("╭" + BOX_BAR));
    console.log(edge("│") + " " + chalk.cyan.bold("🤖 Bot") + " " + chalk.white.bgCyan.bold(" " + value94 + " ") + " " + chalk.magenta.bold(value96) + chalk.gray.bold(value88));
    printLabeled(value81 ? "📤 ME" : "📨 FROM", value84, value103 => value81 ? chalk.green.bold(value103) : chalk.yellow.bold(value103), value104 => chalk.white.bold(value104));
    if (value80) {
      const value105 = value76.groupName || "Group";
      printLabeled("👥 GROUP", value105, value106 => chalk.blue.bold(value106), value107 => chalk.white.bold(value107));
    } else {
      printLabeled("💬 PRIVATE", "Private Chat", value108 => chalk.magenta.bold(value108), value109 => chalk.white.bold(value109));
    }
    if (value85) {
      console.log(edge("├" + BOX_BAR));
      let value110 = wrapLines(value85, BOX_INNER);
      if (value110.length > MAX_MSG_LINES) {
        const value111 = value110.length;
        value110 = value110.slice(0, MAX_MSG_LINES);
        value110.push("... (" + (value111 - MAX_MSG_LINES) + " more lines)");
      }
      value110.forEach((value112, value113) => {
        if (value113 === 0) {
          console.log(edge("│") + " " + chalk.hex("#FFD700").bold("💭 MSG") + " " + value98(value112));
        } else {
          console.log(edge("│") + " " + value98(value112));
        }
      });
    }
    console.log(edge("╰" + BOX_BAR));
    console.log("");
  } catch (error114) {
    try {
      console.log(chalk.red.bold("❌ Error logging message:"), error114.message);
    } catch (error115) {}
  }
}
function bootBanner(value116 = {}) {
  try {
    ensureTheme();
    const {
      time: value117
    } = nowParts();
    const value118 = db.getBotSetting("botName") || "JUNE-X ULTRA";
    const value119 = () => chalk.gray.bold("[" + nowParts().time + "]");
    const value120 = (value121, value122, value123) => console.log(value119(), value121, value122(value123));
    console.log("");
    value120("💡", chalk.blue, "[ " + value118 + " ]");
    if (value116.version) {
      value120("💡", chalk.white, "Version   : v" + String(value116.version).replace(/^v/, ""));
    }
    if (value116.owner) {
      value120("💡", chalk.white, "Owner     : " + value116.owner);
    }
    if (value116.prefix !== undefined) {
      value120("💡", chalk.white, "Prefix    : [ " + value116.prefix + " ]");
    }
    if (value116.mode) {
      value120("💡", chalk.white, "Mode      : " + String(value116.mode).toUpperCase());
    }
    if (value116.commandCount !== undefined) {
      value120("💡", chalk.white, "Commands  : " + value116.commandCount + " loaded" + (value116.aliasCount ? " (+" + value116.aliasCount + " aliases)" : ""));
    }
    value120("🗄️", chalk.magenta, "Database  : " + (value116.sqliteLabel || "ready") + " (" + (value116.sqliteDriver || "sqlite") + ")");
    if (value116.sessionLabel) {
      value120("🔌", chalk.cyan, "Session   : " + value116.sessionLabel + " (" + (value116.authSource || "sqlite") + ")");
    }
    if (value116.platform) {
      value120("💡", chalk.white, "Platform  : " + value116.platform + " • Node " + (value116.nodeVersion || process.version));
    }
    if (value116.startupTime) {
      value120("✅", chalk.green, "Boot complete in " + value116.startupTime);
    }
    value120("💡", chalk.blue, "Timezone  : " + getTimeZone() + " (theme switch " + String(DAY_START_HOUR).padStart(2, "0") + ":00 ☀️ / " + String(NIGHT_START_HOUR).padStart(2, "0") + ":00 🌙)");
    console.log("");
  } catch (error124) {}
}
module.exports = {
  KEY: KEY,
  VALID: VALID,
  getTimeZone: getTimeZone,
  getTimeZoneSource: getTimeZoneSource,
  nowParts: nowParts,
  getMode: getMode,
  setMode: setMode,
  currentTheme: currentTheme,
  ensureTheme: ensureTheme,
  log: log,
  cmdLine: cmdLine,
  printMessage: printMessage,
  bootBanner: bootBanner
};
