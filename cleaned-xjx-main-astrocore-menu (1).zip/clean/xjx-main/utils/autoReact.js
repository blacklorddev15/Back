const db = require("../database");
const DEFAULTS = Object.freeze({
  enabled: false,
  mode: "bot",
  target: "both",
  fixedEmoji: "🌪️",
  randomMode: false
});
const MODES = new Set(["bot", "all"]);
const TARGETS = new Set(["dms", "groups", "both"]);
function bool(value1, value2) {
  if (typeof value1 === "boolean") {
    return value1;
  } else {
    return value2;
  }
}
function load() {
  const value3 = db.getBotSetting("autoReactMode");
  const value4 = db.getBotSetting("autoReactSource") || value3 || DEFAULTS.mode;
  return {
    enabled: bool(db.getBotSetting("autoReact"), DEFAULTS.enabled),
    mode: MODES.has(value4) ? value4 : DEFAULTS.mode,
    target: TARGETS.has(db.getBotSetting("autoReactTarget")) ? db.getBotSetting("autoReactTarget") : DEFAULTS.target,
    fixedEmoji: typeof db.getBotSetting("autoReactFixedEmoji") === "string" && db.getBotSetting("autoReactFixedEmoji").trim() ? db.getBotSetting("autoReactFixedEmoji").trim() : DEFAULTS.fixedEmoji,
    randomMode: bool(db.getBotSetting("autoReactRandomMode"), DEFAULTS.randomMode)
  };
}
function save(value5 = {}) {
  const value6 = load();
  const value7 = {
    enabled: Object.prototype.hasOwnProperty.call(value5, "enabled") ? value5.enabled === true : value6.enabled,
    mode: Object.prototype.hasOwnProperty.call(value5, "mode") && MODES.has(value5.mode) ? value5.mode : value6.mode,
    target: Object.prototype.hasOwnProperty.call(value5, "target") && TARGETS.has(value5.target) ? value5.target : value6.target,
    fixedEmoji: Object.prototype.hasOwnProperty.call(value5, "fixedEmoji") && typeof value5.fixedEmoji === "string" && value5.fixedEmoji.trim() ? value5.fixedEmoji.trim() : value6.fixedEmoji,
    randomMode: Object.prototype.hasOwnProperty.call(value5, "randomMode") ? value5.randomMode === true : value6.randomMode
  };
  db.updateBotSettings({
    autoReact: value7.enabled,
    autoReactMode: value7.mode,
    autoReactSource: value7.mode,
    autoReactTarget: value7.target,
    autoReactFixedEmoji: value7.fixedEmoji,
    autoReactRandomMode: value7.randomMode
  });
  try {
    db.setBotSetting("autoReact", value7.enabled);
    db.setBotSetting("autoReactMode", value7.mode);
  } catch (error8) {}
  try {
    global.invalidateSettingsCache?.();
  } catch (error9) {}
  return value7;
}
function canTargetChat(value10, value11) {
  return value10 === "both" || value10 === "groups" && value11 || value10 === "dms" && !value11;
}
module.exports = {
  DEFAULTS: DEFAULTS,
  load: load,
  save: save,
  canTargetChat: canTargetChat
};
