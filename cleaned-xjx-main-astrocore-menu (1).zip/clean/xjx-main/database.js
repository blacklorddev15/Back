'use strict';

const path = require("path");
const fs = require("fs");
const {
  spawnSync
} = require("child_process");
const crypto = require("crypto");
const pgAdapter = require("./utils/juneDb/pgAdapter");
const mongoAdapter = require("./utils/juneDb/mongoAdapter");
const DB_DIR = path.resolve(process.env.JUNE_DB_DIR || path.join(__dirname, "database"));
const DB_FILE = path.resolve(process.env.JUNE_DB_FILE || path.join(DB_DIR, "june-ultra.db"));
const DB_BACKUP_FILE = path.resolve(process.env.JUNE_DB_BACKUP_FILE || path.join(DB_DIR, "june-ultra.db.backup"));
const DB_BACKUP_DEBOUNCE_MS = Number(process.env.JUNE_DB_BACKUP_DEBOUNCE_MS) || 15000;
const DB_BACKUP_INTERVAL_MS = Number(process.env.JUNE_DB_BACKUP_INTERVAL_MS) || 900000;
const DB_SCHEMA_VERSION = "6";
const NATIVE_PROBE_CACHE_FILE = path.join(DB_DIR, ".native-sqlite-probe.json");
function positiveNumberEnv(value1, value2, {
  minimum = 0
} = {}) {
  const value3 = Number(process.env[value1]);
  if (Number.isFinite(value3) && value3 >= minimum) {
    return value3;
  } else {
    return value2;
  }
}
const DB_MAINTENANCE_INTERVAL_MS = positiveNumberEnv("JUNE_DB_MAINTENANCE_INTERVAL_MS", 3600000, {
  minimum: 60000
});
const ANTIDELETE_RETENTION_MS = positiveNumberEnv("JUNE_ANTIDELETE_RETENTION_HOURS", 48, {
  minimum: 0
}) * 60 * 60 * 1000;
const ANTIDELETE_STATUS_RETENTION_MS = positiveNumberEnv("JUNE_ANTIDELETE_STATUS_RETENTION_HOURS", 24, {
  minimum: 0
}) * 60 * 60 * 1000;
const ANTIDELETE_MAX_ROWS = Math.floor(positiveNumberEnv("JUNE_ANTIDELETE_MAX_ROWS", 500, {
  minimum: 0
}));
const ANTIDELETE_STATUS_MAX_ROWS = Math.floor(positiveNumberEnv("JUNE_ANTIDELETE_STATUS_MAX_ROWS", 500, {
  minimum: 0
}));
const AUTO_DOWNLOAD_STATUS_HISTORY_MAX_ROWS = Math.floor(positiveNumberEnv("JUNE_AUTODOWNLOAD_STATUS_HISTORY_MAX_ROWS", 500, {
  minimum: 50
}));
const REMOTE_SYNC_INTERVAL_MS = positiveNumberEnv("JUNE_REMOTE_SYNC_INTERVAL_MS", 30000, {
  minimum: 5000
});
const REMOTE_SYNC_MAX_ROWS = Math.floor(positiveNumberEnv("JUNE_REMOTE_SYNC_MAX_ROWS", 2000, {
  minimum: 100
}));
const AUTH_MIRROR_DEBOUNCE_MS = Math.floor(positiveNumberEnv("JUNE_AUTH_MIRROR_DEBOUNCE_MS", 2000, {
  minimum: 500
}));
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, {
    recursive: true
  });
}
const requestedSQLiteDriver = String(process.env.JUNE_SQLITE_DRIVER || "auto").trim().toLowerCase();
const forceSqlJs = /^(1|true|yes|on)$/i.test(String(process.env.JUNE_FORCE_SQLJS || "")) || ["wasm", "sqljs", "sql.js"].includes(requestedSQLiteDriver);
let dbDriver = "unknown";
let Database = null;
function nativeProbeSignature() {
  let value4 = "unresolved";
  try {
    const value5 = require.resolve("better-sqlite3");
    const value6 = fs.statSync(value5);
    value4 = value5 + ":" + value6.size + ":" + value6.mtimeMs;
  } catch (error7) {}
  return JSON.stringify({
    node: process.version,
    abi: process.versions.modules || "unknown",
    platform: process.platform,
    arch: process.arch,
    moduleStamp: value4
  });
}
function readFailedNativeProbe(value8) {
  try {
    const value9 = JSON.parse(fs.readFileSync(NATIVE_PROBE_CACHE_FILE, "utf8"));
    if (value9?.signature === value8 && value9?.ok === false && value9?.reason) {
      return {
        ok: false,
        reason: "cached-" + value9.reason
      };
    }
  } catch (error10) {}
  return null;
}
function cacheFailedNativeProbe(value11, value12) {
  try {
    const value13 = NATIVE_PROBE_CACHE_FILE + ".tmp-" + process.pid;
    fs.writeFileSync(value13, JSON.stringify({
      signature: value11,
      ok: false,
      reason: value12.reason || "probe-failed",
      checkedAt: Date.now()
    }));
    fs.renameSync(value13, NATIVE_PROBE_CACHE_FILE);
  } catch (error14) {}
}
function clearFailedNativeProbeCache() {
  try {
    fs.rmSync(NATIVE_PROBE_CACHE_FILE, {
      force: true
    });
  } catch (error15) {}
}
function probeNativeBetterSqlite() {
  const value16 = ["'use strict';", "const Database = require('better-sqlite3');", "const db = new Database(':memory:');", "db.prepare('SELECT 1 AS ok').get();", "db.close();"].join("");
  try {
    const value17 = spawnSync(process.execPath, ["-e", value16], {
      cwd: __dirname,
      encoding: "utf8",
      stdio: "pipe",
      timeout: 7000,
      windowsHide: true
    });
    if (value17.error) {
      return {
        ok: false,
        reason: value17.error.code || "spawn-error"
      };
    }
    if (value17.status === 0 && !value17.signal) {
      return {
        ok: true,
        reason: "passed"
      };
    }
    return {
      ok: false,
      reason: value17.signal ? "signal-" + value17.signal : "exit-" + (value17.status ?? "unknown")
    };
  } catch (error18) {
    return {
      ok: false,
      reason: "probe-exception"
    };
  }
}
if (forceSqlJs) {
  dbDriver = "sql.js-fallback";
  console.warn("[DB] sql.js selected by configuration");
} else {
  const signature = nativeProbeSignature();
  const nativeProbe = requestedSQLiteDriver === "native" ? probeNativeBetterSqlite() : readFailedNativeProbe(signature) || probeNativeBetterSqlite();
  if (nativeProbe.ok) {
    clearFailedNativeProbeCache();
    try {
      Database = require("better-sqlite3");
      dbDriver = "better-sqlite3";
    } catch (error19) {
      dbDriver = "sql.js-fallback";
      console.warn("[DB] Native SQLite loaded in probe but failed in parent; using sql.js fallback");
    }
  } else {
    if (!String(nativeProbe.reason).startsWith("cached-")) {
      cacheFailedNativeProbe(signature, nativeProbe);
    }
    dbDriver = "sql.js-fallback";
    console.warn("[DB] Native SQLite probe failed (" + nativeProbe.reason + "); using sql.js fallback");
  }
}
function cleanStaleBackupArtifacts() {
  try {
    const value20 = path.basename(DB_BACKUP_FILE) + ".tmp-";
    for (const value21 of fs.readdirSync(DB_DIR)) {
      if (value21.startsWith(value20)) {
        fs.rmSync(path.join(DB_DIR, value21), {
          force: true
        });
      }
    }
  } catch (error22) {}
}
cleanStaleBackupArtifacts();
let db;
let stmts = {};
const botSettingsCache = new Map();
const clearBotSettingsCache = () => {
  botSettingsCache.clear();
};
let backupTimer = null;
let backupInterval = null;
let backupPromise = null;
let dirtyRevision = 0;
let backedUpRevision = -1;
let lastIntegrityCheck = null;
let lastBackup = null;
let lastMaintenance = null;
let maintenanceTimer = null;
let maintenanceRunning = false;
let remoteSyncTimer = null;
let remoteSyncRunning = false;
let lastRemoteSync = null;
let authMirrorTimer = null;
let authMirrorRunning = null;
let lastAuthMirror = null;
let shuttingDown = false;
const REMOTE_IDENTITY_ARGUMENTS = {
  mirrorBotSetting: [0],
  mirrorGroupSettings: [0],
  mirrorGroupStat: [0, 1],
  mirrorUser: [0],
  mirrorWarning: [0, 1],
  mirrorModerator: [0],
  mirrorMutedUser: [0, 1],
  mirrorKV: [0, 1],
  deleteKV: [0, 1],
  mirrorAntideleteMessage: [0, 1],
  deleteAntideleteMessage: [0, 1],
  mirrorAntideleteStatus: [0],
  deleteAntideleteStatus: [0],
  mirrorLidMap: [0, 1],
  mirrorProfile: [0, 1],
  mirrorAuthState: [],
  deleteAuthState: [],
  deleteLegacyAuthRecord: []
};
function getRemoteAdapter(value23) {
  if (value23 === "postgres") {
    return pgAdapter;
  } else if (value23 === "mongo") {
    return mongoAdapter;
  } else {
    return null;
  }
}
function remoteDedupeKey(value24, value25, value26) {
  const value27 = REMOTE_IDENTITY_ARGUMENTS[value25];
  const value28 = value27 ? value27.map(value29 => value26[value29]) : value26;
  const value30 = JSON.stringify({
    adapter: value24,
    method: value25,
    identity: value28
  });
  return crypto.createHash("sha256").update(value30).digest("hex");
}
function trimRemoteSyncQueue() {
  if (!db) {
    return 0;
  }
  try {
    const value31 = db.prepare("SELECT COUNT(*) AS count FROM remote_sync_queue").get().count;
    const value32 = Math.max(0, value31 - REMOTE_SYNC_MAX_ROWS);
    if (!value32) {
      return 0;
    }
    const value33 = db.prepare("\n      DELETE FROM remote_sync_queue WHERE id IN (\n        SELECT id FROM remote_sync_queue ORDER BY updated_at ASC LIMIT ?\n      )\n    ").run(value32);
    return value33.changes || 0;
  } catch (error34) {
    return 0;
  }
}
function enqueueRemoteSync(value35, value36, value37, value38 = "adapter-unavailable") {
  if (!db) {
    return;
  }
  try {
    const value39 = Date.now();
    const value40 = JSON.stringify(value37);
    const value41 = remoteDedupeKey(value35, value36, value37);
    db.prepare("\n      INSERT INTO remote_sync_queue\n        (adapter, method, payload, dedupe_key, attempts, next_attempt_at, last_error, created_at, updated_at)\n      VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?)\n      ON CONFLICT(dedupe_key) DO UPDATE SET\n        payload = excluded.payload,\n        attempts = 0,\n        next_attempt_at = excluded.next_attempt_at,\n        last_error = excluded.last_error,\n        updated_at = excluded.updated_at\n    ").run(value35, value36, value40, value41, value39, String(value38).slice(0, 500), value39, value39);
    trimRemoteSyncQueue();
    requestBackup("remote-sync-queued");
  } catch (error42) {}
}
function invokeRemote(value43, value44, value45, value46) {
  const value47 = value44?.getStatus?.() || {};
  if (!value47.configured) {
    return;
  }
  if (!value47.available || typeof value44?.[value45] !== "function") {
    enqueueRemoteSync(value43, value45, value46, "adapter-unavailable");
    return;
  }
  Promise.resolve(value44[value45](...value46)).then(value48 => {
    if (value48 === null || value48 === false) {
      enqueueRemoteSync(value43, value45, value46, "remote-operation-failed");
    }
  }).catch(value49 => {
    enqueueRemoteSync(value43, value45, value46, value49?.message || "remote-operation-error");
  });
}
function mirrorRemote(value50, ...value51) {
  invokeRemote("postgres", pgAdapter, value50, value51);
  invokeRemote("mongo", mongoAdapter, value50, value51);
}
function deleteRemoteKV(value52, value53) {
  mirrorRemote("deleteKV", value52, value53);
}
function remoteRetryDelay(value54) {
  return Math.min(300000, 2 ** Math.min(6, value54) * 5000);
}
async function processRemoteSyncQueue(value55 = "scheduled") {
  if (!db || remoteSyncRunning || shuttingDown) {
    return lastRemoteSync;
  }
  remoteSyncRunning = true;
  const value56 = {
    reason: value55,
    processed: 0,
    succeeded: 0,
    deferred: 0,
    failed: 0,
    timestamp: Date.now()
  };
  try {
    const value57 = db.prepare("\n      SELECT id, adapter, method, payload, attempts\n      FROM remote_sync_queue\n      WHERE next_attempt_at <= ?\n      ORDER BY id ASC\n      LIMIT 50\n    ").all(Date.now());
    const value58 = db.prepare("DELETE FROM remote_sync_queue WHERE id = ?");
    const value59 = db.prepare("\n      UPDATE remote_sync_queue\n      SET attempts = ?, next_attempt_at = ?, last_error = ?, updated_at = ?\n      WHERE id = ?\n    ");
    for (const value60 of value57) {
      value56.processed += 1;
      const value61 = getRemoteAdapter(value60.adapter);
      const value62 = value61?.getStatus?.() || {};
      let value63;
      try {
        value63 = JSON.parse(value60.payload);
      } catch (error64) {
        value63 = null;
      }
      if (!Array.isArray(value63)) {
        value58.run(value60.id);
        value56.failed += 1;
        continue;
      }
      if (!value62.available || typeof value61?.[value60.method] !== "function") {
        const value65 = Number(value60.attempts || 0) + 1;
        value59.run(value65, Date.now() + remoteRetryDelay(value65), "adapter-unavailable", Date.now(), value60.id);
        value56.deferred += 1;
        continue;
      }
      try {
        const value66 = await value61[value60.method](...value63);
        if (value66 === null || value66 === false) {
          throw new Error("remote-operation-failed");
        }
        value58.run(value60.id);
        value56.succeeded += 1;
      } catch (error67) {
        const value68 = Number(value60.attempts || 0) + 1;
        value59.run(value68, Date.now() + remoteRetryDelay(value68), String(error67?.message || error67 || "remote-operation-failed").slice(0, 500), Date.now(), value60.id);
        value56.deferred += 1;
      }
    }
    if (value56.succeeded > 0 || value56.failed > 0) {
      requestBackup("remote-sync-processed");
    }
    lastRemoteSync = value56;
    return value56;
  } finally {
    remoteSyncRunning = false;
  }
}
function getRemoteSyncQueueStats() {
  if (!db) {
    return {
      pending: 0,
      due: 0,
      oldestAt: null,
      lastRun: lastRemoteSync
    };
  }
  try {
    const value69 = Date.now();
    const value70 = db.prepare("\n      SELECT COUNT(*) AS pending,\n        SUM(CASE WHEN next_attempt_at <= ? THEN 1 ELSE 0 END) AS due,\n        MIN(created_at) AS oldest_at\n      FROM remote_sync_queue\n    ").get(value69);
    return {
      pending: Number(value70?.pending || 0),
      due: Number(value70?.due || 0),
      oldestAt: value70?.oldest_at || null,
      lastRun: lastRemoteSync
    };
  } catch (error71) {
    return {
      pending: 0,
      due: 0,
      oldestAt: null,
      lastRun: lastRemoteSync
    };
  }
}
function buildRemoteAuthSnapshot() {
  if (!db) {
    return null;
  }
  try {
    const value72 = db.prepare("SELECT key, value, updated_at FROM session_creds ORDER BY key ASC").all();
    const value73 = db.prepare("SELECT type, id, value, updated_at FROM session_keys ORDER BY type ASC, id ASC").all();
    const value74 = db.prepare("SELECT key, value FROM session_auth_meta ORDER BY key ASC").all();
    const value75 = value74.find(value76 => value76.key === "status")?.value;
    if (!value72.some(value77 => value77.key === "creds") || !value73.length || value75 !== "verified") {
      return null;
    }
    return {
      version: 1,
      createdAt: Date.now(),
      sessionCreds: value72,
      sessionKeys: value73,
      sessionAuthMeta: value74
    };
  } catch (error78) {
    return null;
  }
}
function validateRemoteAuthSnapshot(value79) {
  if (!value79 || value79.version !== 1) {
    return null;
  }
  const value80 = Array.isArray(value79.sessionCreds) ? value79.sessionCreds : null;
  const value81 = Array.isArray(value79.sessionKeys) ? value79.sessionKeys : null;
  const value82 = Array.isArray(value79.sessionAuthMeta) ? value79.sessionAuthMeta : null;
  if (!value80 || !value81 || !value82 || !value80.some(value83 => value83?.key === "creds") || !value81.length) {
    return null;
  }
  if (value82.find(value84 => value84?.key === "status")?.value !== "verified") {
    return null;
  }
  if (!value80.every(value85 => typeof value85?.key === "string" && typeof value85?.value === "string")) {
    return null;
  }
  if (!value81.every(value86 => typeof value86?.type === "string" && typeof value86?.id === "string" && typeof value86?.value === "string")) {
    return null;
  }
  if (!value82.every(value87 => typeof value87?.key === "string" && typeof value87?.value === "string")) {
    return null;
  }
  return {
    creds: value80,
    keys: value81,
    meta: value82
  };
}
function hasConfiguredRemoteAuthMirror() {
  return [pgAdapter, mongoAdapter].some(value88 => Boolean(value88?.getStatus?.().configured));
}
function getRemoteAuthMirrorStatus() {
  return {
    enabled: hasConfiguredRemoteAuthMirror(),
    mode: "plain-remote",
    lastMirror: lastAuthMirror,
    queued: Boolean(authMirrorTimer)
  };
}
async function mirrorRemoteAuthState(value89 = "scheduled") {
  if (authMirrorRunning) {
    return authMirrorRunning;
  }
  if (!hasConfiguredRemoteAuthMirror()) {
    lastAuthMirror = {
      ok: false,
      skipped: "remote-not-configured",
      reason: value89,
      timestamp: Date.now()
    };
    return lastAuthMirror;
  }
  authMirrorRunning = (async () => {
    try {
      const value90 = buildRemoteAuthSnapshot();
      if (!value90) {
        lastAuthMirror = {
          ok: false,
          skipped: "local-auth-not-verified",
          reason: value89,
          timestamp: Date.now()
        };
        return lastAuthMirror;
      }
      mirrorRemote("mirrorAuthState", value90);
      lastAuthMirror = {
        ok: true,
        reason: value89,
        timestamp: Date.now(),
        credentialRows: value90.sessionCreds.length,
        keyRows: value90.sessionKeys.length,
        metaRows: value90.sessionAuthMeta.length
      };
      return lastAuthMirror;
    } catch (error91) {
      lastAuthMirror = {
        ok: false,
        reason: value89,
        error: error91.code || "mirror-failed",
        timestamp: Date.now()
      };
      return lastAuthMirror;
    } finally {
      authMirrorRunning = null;
    }
  })();
  return authMirrorRunning;
}
function scheduleRemoteAuthMirror(value92 = "auth-update") {
  if (!hasConfiguredRemoteAuthMirror() || shuttingDown) {
    return false;
  }
  if (authMirrorTimer) {
    clearTimeout(authMirrorTimer);
  }
  authMirrorTimer = setTimeout(() => {
    authMirrorTimer = null;
    mirrorRemoteAuthState(value92);
  }, AUTH_MIRROR_DEBOUNCE_MS);
  authMirrorTimer.unref?.();
  return true;
}
async function flushRemoteAuthMirror(value93 = "shutdown") {
  if (authMirrorTimer) {
    clearTimeout(authMirrorTimer);
    authMirrorTimer = null;
  }
  return mirrorRemoteAuthState(value93);
}
async function restoreRemoteAuthState() {
  if (!db) {
    return {
      restored: false,
      skipped: "database-unavailable"
    };
  }
  try {
    const value94 = db.prepare("SELECT value FROM session_auth_meta WHERE key = ?").get("status");
    const value95 = value94?.value === "verified" && !!db.prepare("SELECT 1 FROM session_creds WHERE key = 'creds'").get();
    if (value95) {
      return {
        restored: false,
        skipped: "local-auth-verified"
      };
    }
    const value96 = (await Promise.all([typeof pgAdapter.fetchAuthState === "function" ? pgAdapter.fetchAuthState() : null, typeof mongoAdapter.fetchAuthState === "function" ? mongoAdapter.fetchAuthState() : null])).filter(value97 => value97?.snapshot);
    if (!value96.length) {
      return {
        restored: false,
        skipped: "no-remote-auth-state"
      };
    }
    value96.sort((value98, value99) => Number(value99.updatedAt || value99.snapshot?.createdAt || 0) - Number(value98.updatedAt || value98.snapshot?.createdAt || 0));
    const value100 = value96[0];
    const value101 = validateRemoteAuthSnapshot(value100.snapshot);
    if (!value101) {
      return {
        restored: false,
        skipped: "invalid-remote-auth-state"
      };
    }
    const value102 = db.prepare("\n      INSERT INTO session_creds (key, value, updated_at) VALUES (?, ?, ?)\n      ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at\n    ");
    const value103 = db.prepare("\n      INSERT INTO session_keys (type, id, value, updated_at) VALUES (?, ?, ?, ?)\n      ON CONFLICT(type, id) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at\n    ");
    const value104 = db.prepare("\n      INSERT INTO session_auth_meta (key, value) VALUES (?, ?)\n      ON CONFLICT(key) DO UPDATE SET value = excluded.value\n    ");
    const value105 = db.transaction(() => {
      db.prepare("DELETE FROM session_creds").run();
      db.prepare("DELETE FROM session_keys").run();
      db.prepare("DELETE FROM session_auth_meta").run();
      for (const value106 of value101.creds) {
        value102.run(value106.key, value106.value, Number(value106.updated_at || Date.now()));
      }
      for (const value107 of value101.keys) {
        value103.run(value107.type, value107.id, value107.value, Number(value107.updated_at || Date.now()));
      }
      for (const value108 of value101.meta) {
        value104.run(value108.key, value108.value);
      }
    });
    value105();
    requestBackup("remote-auth-mirror-restore");
    return {
      restored: true,
      source: value100.source || "remote",
      credentialRows: value101.creds.length,
      keyRows: value101.keys.length,
      metaRows: value101.meta.length
    };
  } catch (error109) {
    return {
      restored: false,
      error: error109.code || "remote-auth-restore-failed"
    };
  }
}
function clearRemoteAuthState() {
  mirrorRemote("deleteAuthState");
  mirrorRemote("deleteLegacyAuthRecord");
  lastAuthMirror = {
    ok: true,
    cleared: true,
    timestamp: Date.now()
  };
  return true;
}
function startRemoteSyncQueue() {
  if (remoteSyncTimer) {
    clearInterval(remoteSyncTimer);
  }
  remoteSyncTimer = setInterval(() => {
    processRemoteSyncQueue("interval");
  }, REMOTE_SYNC_INTERVAL_MS);
  remoteSyncTimer.unref?.();
  const value110 = setTimeout(() => void processRemoteSyncQueue("startup"), 5000);
  value110.unref?.();
}
function integrityCheck(value111) {
  try {
    if (dbDriver === "better-sqlite3") {
      const value112 = value111.pragma("integrity_check", {
        simple: true
      });
      return {
        ok: value112 === "ok",
        result: value112
      };
    } else {
      return {
        ok: true,
        result: "ok (sql.js)"
      };
    }
  } catch (error113) {
    return {
      ok: false,
      result: error113.message
    };
  }
}
function validateBackup(value114 = DB_BACKUP_FILE) {
  if (!fs.existsSync(value114)) {
    return false;
  }
  try {
    return fs.statSync(value114).size > 0;
  } catch (error115) {
    return false;
  }
}
function removeBackupSidecars(value116) {
  for (const value117 of [value116 + "-wal", value116 + "-shm"]) {
    try {
      fs.rmSync(value117, {
        force: true
      });
    } catch (error118) {}
  }
}
function restoreFromLocalBackup() {
  if (!validateBackup()) {
    return false;
  }
  removeBackupSidecars(DB_BACKUP_FILE);
  const value119 = ".corrupt-" + Date.now() + "-" + process.pid;
  const value120 = [];
  try {
    for (const value121 of [DB_FILE, DB_FILE + "-wal", DB_FILE + "-shm"]) {
      if (!fs.existsSync(value121)) {
        continue;
      }
      const value122 = "" + value121 + value119;
      fs.renameSync(value121, value122);
      value120.push([value121, value122]);
    }
    fs.copyFileSync(DB_BACKUP_FILE, DB_FILE);
    clearBotSettingsCache();
    console.warn("[DB] ✅ Restored from backup");
    return true;
  } catch (error123) {
    console.error("[DB] ❌ Restore failed: " + error123.message);
    try {
      fs.rmSync(DB_FILE, {
        force: true
      });
    } catch (error124) {}
    for (const [value125, value126] of value120.reverse()) {
      try {
        if (fs.existsSync(value126)) {
          fs.renameSync(value126, value125);
        }
      } catch (error127) {}
    }
    return false;
  }
}
function configureDatabase(value128) {
  if (dbDriver === "better-sqlite3") {
    try {
      value128.pragma("journal_mode = WAL");
      value128.pragma("synchronous  = NORMAL");
      value128.pragma("cache_size   = -16000");
      value128.pragma("foreign_keys = ON");
    } catch (error129) {}
  }
}
class SqlJsDatabase {
  constructor(value130, value131) {
    this.sqlDb = value130;
    this.filePath = value131;
    this._transactionDepth = 0;
  }
  prepare(value132) {
    return new SqlJsStatement(this.sqlDb, value132, this);
  }
  exec(value133) {
    try {
      this.sqlDb.exec(value133);
      this._save();
    } catch (error134) {
      console.error("[DB] sql.js query failed:", error134.message);
      throw error134;
    }
  }
  pragma(value135, value136 = {}) {
    if (value136.simple) {
      return "ok";
    }
    return [];
  }
  transaction(value137) {
    if (typeof value137 !== "function") {
      throw new TypeError("[DB] transaction callback must be a function");
    }
    return (...value138) => {
      if (this._transactionDepth > 0) {
        return value137(...value138);
      }
      this.sqlDb.exec("BEGIN");
      this._transactionDepth = 1;
      try {
        const value139 = value137(...value138);
        this.sqlDb.exec("COMMIT");
        this._transactionDepth = 0;
        this._save();
        return value139;
      } catch (error140) {
        this._transactionDepth = 0;
        try {
          this.sqlDb.exec("ROLLBACK");
        } catch (error141) {}
        throw error140;
      }
    };
  }
  backup(value142) {
    return new Promise((value143, value144) => {
      try {
        const value145 = this.sqlDb.export();
        const value146 = Buffer.from(value145);
        fs.writeFileSync(value142, value146);
        value143();
      } catch (error147) {
        value144(error147);
      }
    });
  }
  close() {
    try {
      this._save();
      this.sqlDb.close?.();
    } catch (error148) {}
  }
  _save() {
    if (this._transactionDepth > 0) {
      return;
    }
    const value149 = this.sqlDb.export();
    const value150 = Buffer.from(value149);
    const value151 = this.filePath + ".tmp-" + process.pid;
    fs.writeFileSync(value151, value150);
    fs.renameSync(value151, this.filePath);
  }
}
class SqlJsStatement {
  constructor(value152, value153, value154) {
    this.sqlDb = value152;
    this.sql = value153;
    this.wrapper = value154;
  }
  run(...value155) {
    try {
      const value156 = this.sqlDb.prepare(this.sql);
      value156.bind(value155);
      value156.step();
      value156.free();
      this.wrapper._save();
      return {
        changes: this.sqlDb.getRowsModified?.() || 1
      };
    } catch (error157) {
      console.error("[DB-sql.js] run error:", error157.message);
      throw error157;
    }
  }
  get(...value158) {
    try {
      const value159 = this.sqlDb.prepare(this.sql);
      value159.bind(value158);
      const value160 = value159.step() ? value159.getAsObject() : null;
      value159.free();
      return value160;
    } catch (error161) {
      console.error("[DB-sql.js] get error:", error161.message);
      return null;
    }
  }
  all(...value162) {
    try {
      const value163 = this.sqlDb.prepare(this.sql);
      value163.bind(value162);
      const value164 = [];
      while (value163.step()) {
        value164.push(value163.getAsObject());
      }
      value163.free();
      return value164;
    } catch (error165) {
      console.error("[DB-sql.js] all error:", error165.message);
      return [];
    }
  }
}
async function openDatabase() {
  if ((!fs.existsSync(DB_FILE) || fs.statSync(DB_FILE).size === 0) && validateBackup()) {
    restoreFromLocalBackup();
  }
  let value166;
  if (dbDriver === "better-sqlite3") {
    try {
      value166 = new Database(DB_FILE);
    } catch (error167) {
      console.warn("[DB] Native SQLite unavailable on this VPS");
      console.warn("[DB] Falling back to sql.js WASM");
      dbDriver = "sql.js-fallback";
      return openDatabase();
    }
    const value168 = integrityCheck(value166);
    if (!value168.ok) {
      try {
        value166.close();
      } catch (error169) {}
      if (!restoreFromLocalBackup()) {
        throw new Error("Integrity check failed: " + value168.result);
      }
      value166 = new Database(DB_FILE);
      const value170 = integrityCheck(value166);
      if (!value170.ok) {
        try {
          value166.close();
        } catch (error171) {}
        throw new Error("Backup also failed integrity check");
      }
    }
    configureDatabase(value166);
    lastIntegrityCheck = {
      ok: true,
      result: "ok",
      checkedAt: Date.now()
    };
    console.log("[DB] SQLite ready — better-sqlite3 native, integrity check passed");
    return value166;
  } else if (dbDriver === "sql.js-fallback") {
    console.log("[DB] Loading sql.js WASM...");
    try {
      const value172 = require("sql.js");
      const value173 = typeof value172 === "function" ? value172 : value172.default;
      if (typeof value173 !== "function") {
        throw new Error("sql.js initialization function was not found");
      }
      const value174 = await value173({
        locateFile: value175 => path.join(path.dirname(require.resolve("sql.js")), value175)
      });
      let value176 = null;
      if (fs.existsSync(DB_FILE)) {
        value176 = fs.readFileSync(DB_FILE);
      }
      const value177 = new value174.Database(value176);
      value166 = new SqlJsDatabase(value177, DB_FILE);
      configureDatabase(value166);
      lastIntegrityCheck = {
        ok: true,
        result: "ok",
        checkedAt: Date.now()
      };
      console.log("[DB] Using sql.js WASM fallback");
      return value166;
    } catch (error178) {
      console.error("[DB] sql.js fallback failed: " + error178.message);
      throw new Error("sql.js fallback could not start: " + error178.message);
    }
  }
  throw new Error("No database driver available");
}
const SCHEMA_SQL = "\n  CREATE TABLE IF NOT EXISTS database_meta (\n    key   TEXT PRIMARY KEY,\n    value TEXT NOT NULL\n  );\n\n  INSERT INTO database_meta (key, value) VALUES ('schema_version', '" + DB_SCHEMA_VERSION + "')\n    ON CONFLICT(key) DO UPDATE SET value = excluded.value;\n\n  CREATE TABLE IF NOT EXISTS groups (\n    group_id TEXT PRIMARY KEY,\n    settings TEXT NOT NULL DEFAULT '{}'\n  );\n\n  CREATE TABLE IF NOT EXISTS users (\n    user_id TEXT PRIMARY KEY,\n    data    TEXT NOT NULL DEFAULT '{}'\n  );\n\n  CREATE TABLE IF NOT EXISTS warnings (\n    group_id TEXT NOT NULL,\n    user_id  TEXT NOT NULL,\n    count    INTEGER NOT NULL DEFAULT 0,\n    entries  TEXT    NOT NULL DEFAULT '[]',\n    PRIMARY KEY (group_id, user_id)\n  );\n\n  CREATE TABLE IF NOT EXISTS moderators (\n    user_id TEXT PRIMARY KEY\n  );\n\n  CREATE TABLE IF NOT EXISTS muted_users (\n    group_id TEXT NOT NULL,\n    user_id  TEXT NOT NULL,\n    PRIMARY KEY (group_id, user_id)\n  );\n\n  CREATE TABLE IF NOT EXISTS bot_settings (\n    key   TEXT PRIMARY KEY,\n    value TEXT NOT NULL\n  );\n\n  CREATE TABLE IF NOT EXISTS session (\n    id       INTEGER PRIMARY KEY DEFAULT 1,\n    creds    TEXT,\n    saved_at INTEGER\n  );\n\n  CREATE TABLE IF NOT EXISTS session_creds (\n    key        TEXT PRIMARY KEY,\n    value      TEXT NOT NULL,\n    updated_at INTEGER NOT NULL\n  );\n\n  CREATE TABLE IF NOT EXISTS session_keys (\n    type       TEXT NOT NULL,\n    id         TEXT NOT NULL,\n    value      TEXT NOT NULL,\n    updated_at INTEGER NOT NULL,\n    PRIMARY KEY (type, id)\n  );\n\n  CREATE INDEX IF NOT EXISTS idx_session_keys_type ON session_keys(type);\n\n  CREATE TABLE IF NOT EXISTS session_auth_meta (\n    key   TEXT PRIMARY KEY,\n    value TEXT NOT NULL\n  );\n\n  CREATE TABLE IF NOT EXISTS group_stats (\n    group_id TEXT NOT NULL,\n    date     TEXT NOT NULL,\n    data     TEXT NOT NULL DEFAULT '{}',\n    PRIMARY KEY (group_id, date)\n  );\n\n  CREATE TABLE IF NOT EXISTS status_downloads (\n    status_id       TEXT PRIMARY KEY,\n    sender_id       TEXT NOT NULL DEFAULT '',\n    media_type      TEXT NOT NULL DEFAULT 'unknown',\n    downloaded_at   INTEGER NOT NULL,\n    destination_jid TEXT NOT NULL DEFAULT ''\n  );\n  CREATE INDEX IF NOT EXISTS idx_status_downloads_downloaded_at\n    ON status_downloads(downloaded_at DESC);\n\n  CREATE TABLE IF NOT EXISTS chat_profiles (\n    bot_id  TEXT NOT NULL,\n    user_id TEXT NOT NULL,\n    profile TEXT NOT NULL DEFAULT '{}',\n    PRIMARY KEY (bot_id, user_id)\n  );\n\n  CREATE TABLE IF NOT EXISTS kv_store (\n    namespace TEXT NOT NULL,\n    key       TEXT NOT NULL,\n    value     TEXT NOT NULL,\n    PRIMARY KEY (namespace, key)\n  );\n\n  CREATE TABLE IF NOT EXISTS antidelete_messages (\n    chat_id   TEXT NOT NULL,\n    message_id TEXT NOT NULL,\n    payload   TEXT NOT NULL DEFAULT '{}',\n    stored_at INTEGER NOT NULL,\n    PRIMARY KEY (chat_id, message_id)\n  );\n\n  CREATE TABLE IF NOT EXISTS antidelete_statuses (\n    status_id TEXT PRIMARY KEY,\n    payload   TEXT NOT NULL DEFAULT '{}',\n    stored_at INTEGER NOT NULL\n  );\n  CREATE INDEX IF NOT EXISTS idx_antidelete_messages_stored_at ON antidelete_messages(stored_at);\n  CREATE INDEX IF NOT EXISTS idx_antidelete_statuses_stored_at ON antidelete_statuses(stored_at);\n\n  CREATE TABLE IF NOT EXISTS remote_sync_queue (\n    id              INTEGER PRIMARY KEY AUTOINCREMENT,\n    adapter         TEXT NOT NULL,\n    method          TEXT NOT NULL,\n    payload         TEXT NOT NULL,\n    dedupe_key      TEXT NOT NULL UNIQUE,\n    attempts        INTEGER NOT NULL DEFAULT 0,\n    next_attempt_at INTEGER NOT NULL,\n    last_error      TEXT,\n    created_at      INTEGER NOT NULL,\n    updated_at      INTEGER NOT NULL\n  );\n  CREATE INDEX IF NOT EXISTS idx_remote_sync_queue_due ON remote_sync_queue(next_attempt_at);\n\n  CREATE TABLE IF NOT EXISTS lid_map (\n    direction TEXT NOT NULL,\n    user      TEXT NOT NULL,\n    value     TEXT NOT NULL,\n    updated_at INTEGER NOT NULL,\n    PRIMARY KEY (direction, user)\n  );\n\n  CREATE TABLE IF NOT EXISTS runtime_telemetry (\n    event_type TEXT NOT NULL,\n    event_key  TEXT NOT NULL,\n    payload    TEXT NOT NULL DEFAULT '{}',\n    count      INTEGER NOT NULL DEFAULT 1,\n    first_seen INTEGER NOT NULL,\n    last_seen  INTEGER NOT NULL,\n    PRIMARY KEY (event_type, event_key)\n  );\n";
function createPreparedStatements() {
  return {
    getGroupSettings: db.prepare("SELECT settings FROM groups WHERE group_id = ?"),
    upsertGroupSettings: db.prepare("INSERT INTO groups (group_id, settings) VALUES (?, ?) ON CONFLICT(group_id) DO UPDATE SET settings = excluded.settings"),
    getUser: db.prepare("SELECT data FROM users WHERE user_id = ?"),
    upsertUser: db.prepare("INSERT INTO users (user_id, data) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data"),
    getWarnings: db.prepare("SELECT count, entries FROM warnings WHERE group_id = ? AND user_id = ?"),
    getWarningsForGroup: db.prepare("SELECT user_id, count, entries FROM warnings WHERE group_id = ?"),
    upsertWarning: db.prepare("INSERT INTO warnings (group_id, user_id, count, entries) VALUES (?, ?, ?, ?) ON CONFLICT(group_id, user_id) DO UPDATE SET count = excluded.count, entries = excluded.entries"),
    deleteWarning: db.prepare("DELETE FROM warnings WHERE group_id = ? AND user_id = ?"),
    clearWarnings: db.prepare("DELETE FROM warnings WHERE group_id = ?"),
    getModerators: db.prepare("SELECT user_id FROM moderators"),
    addModerator: db.prepare("INSERT OR IGNORE INTO moderators (user_id) VALUES (?)"),
    removeModerator: db.prepare("DELETE FROM moderators WHERE user_id = ?"),
    isModerator: db.prepare("SELECT 1 FROM moderators WHERE user_id = ? LIMIT 1"),
    muteUser: db.prepare("INSERT OR IGNORE INTO muted_users (group_id, user_id) VALUES (?, ?)"),
    unmuteUser: db.prepare("DELETE FROM muted_users WHERE group_id = ? AND user_id = ?"),
    isUserMuted: db.prepare("SELECT 1 FROM muted_users WHERE group_id = ? AND user_id = ? LIMIT 1"),
    getMutedUsers: db.prepare("SELECT user_id FROM muted_users WHERE group_id = ?"),
    getBotSetting: db.prepare("SELECT value FROM bot_settings WHERE key = ?"),
    setBotSetting: db.prepare("INSERT INTO bot_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value"),
    getAllBotSettings: db.prepare("SELECT key, value FROM bot_settings"),
    getSession: db.prepare("SELECT creds FROM session WHERE id = 1"),
    upsertSession: db.prepare("INSERT INTO session (id, creds, saved_at) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET creds = excluded.creds, saved_at = excluded.saved_at"),
    clearSession: db.prepare("DELETE FROM session WHERE id = 1"),
    getKV: db.prepare("SELECT value FROM kv_store WHERE namespace = ? AND key = ?"),
    setKV: db.prepare("INSERT INTO kv_store (namespace, key, value) VALUES (?, ?, ?) ON CONFLICT(namespace, key) DO UPDATE SET value = excluded.value"),
    delKV: db.prepare("DELETE FROM kv_store WHERE namespace = ? AND key = ?"),
    allKV: db.prepare("SELECT key, value FROM kv_store WHERE namespace = ?"),
    insertGroupStat: db.prepare("INSERT INTO group_stats (group_id, date, data) VALUES (?, ?, ?) ON CONFLICT(group_id, date) DO UPDATE SET data = excluded.data"),
    getGroupStat: db.prepare("SELECT data FROM group_stats WHERE group_id = ? AND date = ?"),
    getAllGroupStats: db.prepare("SELECT date, data FROM group_stats WHERE group_id = ?"),
    getStatusDownload: db.prepare("SELECT status_id FROM status_downloads WHERE status_id = ? LIMIT 1"),
    insertStatusDownload: db.prepare("\n      INSERT OR IGNORE INTO status_downloads\n        (status_id, sender_id, media_type, downloaded_at, destination_jid)\n      VALUES (?, ?, ?, ?, ?)\n    "),
    getStatusDownloadLogs: db.prepare("\n      SELECT status_id, sender_id, media_type, downloaded_at, destination_jid\n      FROM status_downloads\n      ORDER BY downloaded_at DESC\n      LIMIT ?\n    "),
    countStatusDownloads: db.prepare("SELECT COUNT(*) AS count FROM status_downloads"),
    deleteOldestStatusDownloads: db.prepare("\n      DELETE FROM status_downloads\n      WHERE status_id IN (\n        SELECT status_id FROM status_downloads\n        ORDER BY downloaded_at ASC, status_id ASC\n        LIMIT ?\n      )\n    "),
    clearStatusDownloadHistory: db.prepare("DELETE FROM status_downloads"),
    saveAntideleteMessage: db.prepare("INSERT INTO antidelete_messages (chat_id, message_id, payload, stored_at) VALUES (?, ?, ?, ?) ON CONFLICT(chat_id, message_id) DO UPDATE SET payload = excluded.payload, stored_at = excluded.stored_at"),
    getAntideleteMessage: db.prepare("SELECT chat_id, message_id, payload, stored_at FROM antidelete_messages WHERE chat_id = ? AND message_id = ? LIMIT 1"),
    getAntideleteMessages: db.prepare("SELECT chat_id, message_id, payload, stored_at FROM antidelete_messages ORDER BY stored_at ASC"),
    deleteAntideleteMessage: db.prepare("DELETE FROM antidelete_messages WHERE chat_id = ? AND message_id = ?"),
    saveAntideleteStatus: db.prepare("INSERT INTO antidelete_statuses (status_id, payload, stored_at) VALUES (?, ?, ?) ON CONFLICT(status_id) DO UPDATE SET payload = excluded.payload, stored_at = excluded.stored_at"),
    getAntideleteStatuses: db.prepare("SELECT status_id, payload, stored_at FROM antidelete_statuses ORDER BY stored_at ASC"),
    deleteAntideleteStatus: db.prepare("DELETE FROM antidelete_statuses WHERE status_id = ?"),
    saveLidMap: db.prepare("INSERT INTO lid_map (direction, user, value, updated_at) VALUES (?, ?, ?, ?) ON CONFLICT(direction, user) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at"),
    getLidMap: db.prepare("SELECT value FROM lid_map WHERE direction = ? AND user = ?"),
    getLidMaps: db.prepare("SELECT direction, user, value, updated_at FROM lid_map"),
    getRuntimeTelemetry: db.prepare("SELECT event_type, event_key, payload, count, first_seen, last_seen FROM runtime_telemetry ORDER BY last_seen DESC LIMIT ?"),
    getRuntimeTelemetryEntry: db.prepare("SELECT event_type, event_key, payload, count, first_seen, last_seen FROM runtime_telemetry WHERE event_type = ? AND event_key = ?"),
    upsertRuntimeTelemetry: db.prepare("\n      INSERT INTO runtime_telemetry\n        (event_type, event_key, payload, count, first_seen, last_seen)\n      VALUES (?, ?, ?, 1, ?, ?)\n      ON CONFLICT(event_type, event_key) DO UPDATE SET\n        payload = excluded.payload,\n        count = runtime_telemetry.count + 1,\n        last_seen = excluded.last_seen\n    "),
    getProfile: db.prepare("SELECT profile FROM chat_profiles WHERE bot_id = ? AND user_id = ?"),
    saveProfile: db.prepare("INSERT INTO chat_profiles (bot_id, user_id, profile) VALUES (?, ?, ?) ON CONFLICT(bot_id, user_id) DO UPDATE SET profile = excluded.profile")
  };
}
async function initializeDatabase() {
  db = await openDatabase();
  db.exec(SCHEMA_SQL);
  stmts = createPreparedStatements();
  backupInterval = setInterval(() => {
    if (!shuttingDown && dirtyRevision > backedUpRevision) {
      createAtomicBackup("interval");
    }
  }, DB_BACKUP_INTERVAL_MS);
  backupInterval.unref?.();
  startDatabaseMaintenance();
  startRemoteSyncQueue();
  return db;
}
const ready = initializeDatabase().catch(value179 => {
  console.error("[DB] Startup failed: " + value179.message);
  throw value179;
});
function requestBackup(value180 = "write") {
  dirtyRevision++;
  if (backupTimer || shuttingDown) {
    return;
  }
  backupTimer = setTimeout(() => {
    backupTimer = null;
    if (dirtyRevision > backedUpRevision) {
      createAtomicBackup("write");
    }
  }, DB_BACKUP_DEBOUNCE_MS);
  backupTimer.unref?.();
}
async function createAtomicBackup(value181 = "scheduled") {
  if (backupPromise) {
    return backupPromise;
  }
  const value182 = dirtyRevision;
  const value183 = DB_BACKUP_FILE + ".tmp-" + process.pid + "-" + Date.now();
  backupPromise = (async () => {
    try {
      await db.backup(value183);
      const value184 = fs.statSync(value183);
      if (value184.size === 0) {
        fs.rmSync(value183, {
          force: true
        });
        throw new Error("Backup empty");
      }
      removeBackupSidecars(DB_BACKUP_FILE);
      fs.renameSync(value183, DB_BACKUP_FILE);
      backedUpRevision = value182;
      lastBackup = {
        ok: true,
        size: value184.size,
        reason: value181,
        timestamp: Date.now()
      };
    } catch (error185) {
      console.warn("[DB] ⚠️  Backup failed:", error185.message);
      try {
        fs.rmSync(value183, {
          force: true
        });
      } catch (error186) {}
      lastBackup = {
        ok: false,
        error: error185.message,
        timestamp: Date.now()
      };
    } finally {
      backupPromise = null;
    }
  })();
  return backupPromise;
}
async function flushBackup() {
  clearTimeout(backupTimer);
  clearInterval(backupInterval);
  clearInterval(maintenanceTimer);
  clearInterval(remoteSyncTimer);
  if (dirtyRevision > backedUpRevision) {
    await createAtomicBackup("shutdown");
  }
}
function listAntideleteRowsForCleanup(value187, value188, value189, value190) {
  const value191 = [];
  if (value189 !== null) {
    const value192 = db.prepare("SELECT " + value188.join(", ") + " FROM " + value187 + " WHERE stored_at < ? ORDER BY stored_at ASC").all(value189);
    value191.push(...value192);
  }
  if (value190 > 0) {
    const value193 = db.prepare("SELECT COUNT(*) AS count FROM " + value187).get().count;
    const value194 = Math.max(0, value193 - value190);
    if (value194 > 0) {
      const value195 = db.prepare("SELECT " + value188.join(", ") + " FROM " + value187 + " ORDER BY stored_at ASC LIMIT ?").all(value194);
      value191.push(...value195);
    }
  }
  const value196 = new Set();
  return value191.filter(value197 => {
    const value198 = value188.map(value199 => value197[value199]).join("|");
    if (value196.has(value198)) {
      return false;
    }
    value196.add(value198);
    return true;
  });
}
function pruneAntideleteData() {
  if (!db) {
    return {
      messages: 0,
      statuses: 0
    };
  }
  const value200 = Date.now();
  const value201 = ANTIDELETE_RETENTION_MS > 0 ? value200 - ANTIDELETE_RETENTION_MS : null;
  const value202 = ANTIDELETE_STATUS_RETENTION_MS > 0 ? value200 - ANTIDELETE_STATUS_RETENTION_MS : null;
  const value203 = listAntideleteRowsForCleanup("antidelete_messages", ["chat_id", "message_id"], value201, ANTIDELETE_MAX_ROWS);
  const value204 = listAntideleteRowsForCleanup("antidelete_statuses", ["status_id"], value202, ANTIDELETE_STATUS_MAX_ROWS);
  const value205 = db.prepare("DELETE FROM antidelete_messages WHERE chat_id = ? AND message_id = ?");
  const value206 = db.prepare("DELETE FROM antidelete_statuses WHERE status_id = ?");
  const value207 = db.transaction(() => {
    for (const value208 of value203) {
      value205.run(value208.chat_id, value208.message_id);
    }
    for (const value209 of value204) {
      value206.run(value209.status_id);
    }
  });
  value207();
  for (const value210 of value203) {
    mirrorRemote("deleteAntideleteMessage", value210.chat_id, value210.message_id);
  }
  for (const value211 of value204) {
    mirrorRemote("deleteAntideleteStatus", value211.status_id);
  }
  return {
    messages: value203.length,
    statuses: value204.length
  };
}
async function runDatabaseMaintenance(value212 = "scheduled") {
  if (!db || maintenanceRunning || shuttingDown) {
    return lastMaintenance;
  }
  maintenanceRunning = true;
  try {
    const value213 = pruneAntideleteData();
    const value214 = await processRemoteSyncQueue("maintenance");
    let value215 = false;
    if (dbDriver === "better-sqlite3") {
      try {
        db.pragma("wal_checkpoint(PASSIVE)");
        value215 = true;
      } catch (error216) {}
    }
    const value217 = value213.messages + value213.statuses;
    if (value217 > 0) {
      requestBackup("database-maintenance");
    }
    lastMaintenance = {
      ok: true,
      reason: value212,
      timestamp: Date.now(),
      removedMessages: value213.messages,
      removedStatuses: value213.statuses,
      checkpointed: value215,
      remoteSync: value214
    };
    if (value217 > 0) {
      console.log("[DB] Maintenance removed " + value217 + " expired/excess antidelete record(s).");
    }
    return lastMaintenance;
  } catch (error218) {
    lastMaintenance = {
      ok: false,
      reason: value212,
      error: error218.message,
      timestamp: Date.now()
    };
    console.warn("[DB] Maintenance failed: " + error218.message);
    return lastMaintenance;
  } finally {
    maintenanceRunning = false;
  }
}
function startDatabaseMaintenance() {
  if (maintenanceTimer) {
    clearInterval(maintenanceTimer);
  }
  maintenanceTimer = setInterval(() => {
    runDatabaseMaintenance("interval");
  }, DB_MAINTENANCE_INTERVAL_MS);
  maintenanceTimer.unref?.();
  const value219 = setTimeout(() => void runDatabaseMaintenance("startup"), 60000);
  value219.unref?.();
}
function vacuumDatabase() {
  if (!db || dbDriver !== "better-sqlite3") {
    return {
      ok: false,
      skipped: true,
      reason: "native-sqlite-not-active"
    };
  }
  try {
    db.exec("VACUUM");
    return {
      ok: true,
      timestamp: Date.now()
    };
  } catch (error220) {
    return {
      ok: false,
      error: error220.message
    };
  }
}
function parse(value221, value222 = null) {
  if (!value221) {
    return value222;
  }
  try {
    return JSON.parse(value221);
  } catch (error223) {
    return value222;
  }
}
function serial(value224) {
  return JSON.stringify(value224);
}
const MESSAGES = {
  wait: "⏳ Please wait...",
  success: "✅ Success!",
  error: "❌ Error occurred!",
  ownerOnly: "👑 This command is only for bot owner!",
  adminOnly: "🛡️ This command is only for group admins!",
  groupOnly: "👥 This command can only be used in groups!",
  privateOnly: "💬 This command can only be used in private chat!",
  botAdminNeeded: "🚫 Bot needs to be admin to execute this command!",
  invalidCommand: "❓ Invalid command! Type .menu for help"
};
const DEFAULT_GROUP_SETTINGS = {
  antilink: false,
  antilinkAction: "delete",
  antitag: false,
  antitagAction: "delete",
  antiviewonce: false,
  antibot: false,
  anticall: false,
  anticallAction: "decline",
  anticallMessage: null,
  anticallNotify: true,
  antigroupmention: false,
  antigroupmentionAction: "delete",
  antigroupstatus: false,
  antigroupstatusAction: "delete",
  welcome: false,
  stickerActions: {},
  antitagadmins: false,
  antitagadminsAction: "warn",
  antiall: false,
  antiforward: false,
  antiforwardLimit: 3,
  welcomeMessage: " 𝚆𝙴𝙻𝙲𝙾𝙼𝙴: @user 👋\n Member count: #memberCount\n 𝚃𝙸𝙼𝙴: time⏰\n\n\n*@user* Welcome to *@group*! 🎉\n*Group 𝙳𝙴𝚂𝙲𝚁𝙸𝙿𝚃𝙸𝙾𝙽*\ngroupDesc\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ botName*",
  welcomeNoPP: false,
  goodbye: false,
  goodbyeMessage: "Goodbye @user 👋 We will never miss you!",
  antiSpam: false,
  antiSpamLimit: 5,
  antiSpamWindow: 5,
  antiSpamAction: "delete",
  nsfw: false,
  detect: false,
  chatbot: false,
  autosticker: false,
  antiimage: false,
  antiimageAction: "delete",
  antisticker: false,
  antistickerAction: "delete",
  antiaudio: false,
  antiaudioAction: "delete",
  antibadword: false,
  antibadwordAction: "warn",
  badwords: [],
  anticontact: false,
  anticontactAction: "delete",
  antigif: false,
  antigifAction: "delete"
};
const ANTICALL_PRESETS = [{
  id: 1,
  emoji: "📵",
  message: "Sorry, I don't accept WhatsApp calls. Please send a message."
}, {
  id: 2,
  emoji: "💬",
  message: "I'm currently unavailable. Kindly text me instead."
}, {
  id: 3,
  emoji: "🚫",
  message: "Calls are disabled. Please chat with me here."
}, {
  id: 4,
  emoji: "🤖",
  message: "This account doesn't accept calls. Send a message to continue."
}, {
  id: 5,
  emoji: "🌙",
  message: "Do Not Disturb. I'll reply when available."
}];
const SOCIAL = {
  github: "https://github.com/Vinpink2/June-Ultra",
  instagram: "https://instagram.com/activator_negative",
  youtube: "http://youtube.com/@suprem_e_lord"
};
const API_KEYS = {
  openai: "",
  deepai: "",
  remove_bg: ""
};
const TELEGRAM_TOKEN = "8316875590:AAGXXYbt2OIn_hORS0s9RlW5n3e5W5-0YPQ";
const JUNE_BOT_ID = "june-ultra-main";
const UPDATE_ZIP_URL = "https://github.com/supreme-Lord2/xjx/archive/refs/heads/main.zip";
const VERSION = require("./package.json").version;
const SESSION_NAME = "";
const BOT_SETTINGS_DEFAULTS = {
  owners: [],
  ownerSource: null,
  botName: "June-X Ultra",
  prefix: ".",
  autoRead: true,
  autoReact: false,
  mode: "public",
  loginMethod: null,
  antideleteMode: "off",
  antieditMode: "off",
  antideleteStatus: false,
  menuStyle: "5",
  menuShowMemory: true,
  menuShowUptime: true,
  menuShowPluginCount: true,
  menuShowProgressBar: true,
  menuImageCustom: false,
  menuImageData: null,
  alwaysOnline: false,
  fontStyle: "normal",
  readReceipts: "off",
  autoReadMode: "off",
  antibug: false,
  antibugAction: "delete",
  autoStatusView: false,
  autoStatusReact: false,
  autoStatusEmoji: "💙",
  autoStatusEmojiPool: [],
  autoStatusRandomEmoji: false,
  autoDownloadStatus: {},
  autoReactSource: "bot",
  autoReactTarget: "both",
  autoReactFixedEmoji: "💙",
  autoReactRandomMode: false,
  anticall: false,
  anticallAction: "decline",
  anticallMessage: null,
  anticallNotify: true,
  ownerName: [],
  timezone: "Africa/Nairobi",
  maxWarnings: 3,
  packname: "June-X Ultra",
  author: "June-X Ultra",
  stickerAuthor: "June-X Ultra",
  selfMode: false,
  autoBio: false,
  autoSticker: false,
  autoTyping: false,
  autoRecording: false,
  autoRecordType: false,
  autoReactMode: "bot",
  newsletterJid: ""
};
const getStoredGroupSettings = value225 => {
  const value226 = stmts.getGroupSettings.get(value225);
  if (value226) {
    return parse(value226.settings, {});
  } else {
    return {};
  }
};
const getGroupSettings = value227 => ({
  ...getDefaultGroupSettings(),
  ...getStoredGroupSettings(value227)
});
const updateGroupSettings = (value228, value229 = {}) => {
  const value230 = getStoredGroupSettings(value228);
  const value231 = value229 && typeof value229 === "object" && !Array.isArray(value229) ? value229 : {};
  const value232 = {
    ...value230,
    ...value231
  };
  stmts.upsertGroupSettings.run(value228, serial(value232));
  requestBackup("group-settings");
  mirrorRemote("mirrorGroupSettings", value228, value232);
  return value232;
};
const getUser = value233 => {
  const value234 = stmts.getUser.get(value233);
  if (value234) {
    return parse(value234.data, {});
  } else {
    return {};
  }
};
const updateUser = (value235, value236) => {
  stmts.upsertUser.run(value235, serial(value236));
  requestBackup("user-update");
  mirrorRemote("mirrorUser", value235, value236);
};
const getWarnings = (value237, value238) => {
  const value239 = stmts.getWarnings.get(value237, value238);
  if (!value239) {
    return {
      count: 0,
      entries: []
    };
  }
  return {
    count: value239.count,
    entries: parse(value239.entries, [])
  };
};
const addWarning = (value240, value241, value242 = "") => {
  const value243 = getWarnings(value240, value241);
  const value244 = [...(value243.entries || []), {
    reason: value242,
    timestamp: Date.now()
  }];
  stmts.upsertWarning.run(value240, value241, value243.count + 1, serial(value244));
  requestBackup("warning-add");
  mirrorRemote("mirrorWarning", value240, value241, {
    count: value243.count + 1,
    entries: value244
  });
  return value243.count + 1;
};
const removeWarning = (value245, value246) => {
  const value247 = getWarnings(value245, value246);
  if (value247.count <= 0) {
    return 0;
  }
  stmts.upsertWarning.run(value245, value246, value247.count - 1, serial(value247.entries));
  requestBackup("warning-remove");
  mirrorRemote("mirrorWarning", value245, value246, {
    count: value247.count - 1,
    entries: value247.entries
  });
  return value247.count - 1;
};
const clearWarnings = (value248, value249) => {
  if (value249) {
    stmts.deleteWarning.run(value248, value249);
    mirrorRemote("mirrorWarning", value248, value249, {
      count: 0,
      entries: []
    });
  } else {
    const value250 = stmts.getWarningsForGroup.all(value248);
    stmts.clearWarnings.run(value248);
    for (const value251 of value250) {
      mirrorRemote("mirrorWarning", value248, value251.user_id, {
        count: 0,
        entries: []
      });
    }
  }
  requestBackup("warning-clear");
  return true;
};
const getModerators = () => stmts.getModerators.all().map(value252 => value252.user_id);
const addModerator = value253 => {
  stmts.addModerator.run(value253);
  requestBackup("moderator-add");
  mirrorRemote("mirrorModerator", value253, true);
  return true;
};
const removeModerator = value254 => {
  stmts.removeModerator.run(value254);
  requestBackup("moderator-remove");
  mirrorRemote("mirrorModerator", value254, false);
  return true;
};
const isModerator = value255 => !!stmts.isModerator.get(value255);
const muteUser = (value256, value257) => {
  stmts.muteUser.run(value256, value257);
  requestBackup("mute-user");
  mirrorRemote("mirrorMutedUser", value256, value257, true);
  return true;
};
const unmuteUser = (value258, value259) => {
  stmts.unmuteUser.run(value258, value259);
  requestBackup("unmute-user");
  mirrorRemote("mirrorMutedUser", value258, value259, false);
  return true;
};
const isUserMuted = (value260, value261) => !!stmts.isUserMuted.get(value260, value261);
const getMutedUsers = value262 => stmts.getMutedUsers.all(value262).map(value263 => value263.user_id);
const cloneIfMutable = value264 => value264 !== null && typeof value264 === "object" ? JSON.parse(JSON.stringify(value264)) : value264;
const getBotSetting = value265 => {
  if (botSettingsCache.has(value265)) {
    return cloneIfMutable(botSettingsCache.get(value265));
  }
  if (!db || !stmts.getBotSetting) {
    return cloneIfMutable(BOT_SETTINGS_DEFAULTS[value265]);
  }
  const value266 = stmts.getBotSetting.get(value265);
  const value267 = value266 ? parse(value266.value) : BOT_SETTINGS_DEFAULTS[value265];
  botSettingsCache.set(value265, value267);
  return cloneIfMutable(value267);
};
const setBotSetting = (value268, value269) => {
  stmts.setBotSetting.run(value268, serial(value269));
  botSettingsCache.set(value268, value269);
  requestBackup("bot-setting");
  mirrorRemote("mirrorBotSetting", value268, value269);
  return true;
};
const getStoredBotSettings = () => {
  const value270 = {};
  for (const value271 of stmts.getAllBotSettings.all()) {
    value270[value271.key] = parse(value271.value);
  }
  return value270;
};
const getAllBotSettings = () => ({
  ...BOT_SETTINGS_DEFAULTS,
  ...getStoredBotSettings()
});
const updateBotSettings = value272 => {
  for (const [value273, value274] of Object.entries(value272)) {
    setBotSetting(value273, value274);
  }
  return true;
};
const _isValidTimeZone = value275 => {
  if (!value275 || typeof value275 !== "string") {
    return false;
  }
  try {
    new Intl.DateTimeFormat("en-US", {
      timeZone: value275
    }).format(new Date());
    return true;
  } catch (error276) {
    return false;
  }
};
const {
  resolveTimeZone
} = require("./utils/tzResolver");
const _rawStoredTz = () => {
  try {
    if (db && stmts.getBotSetting) {
      const value277 = stmts.getBotSetting.get("timezone");
      if (value277 && value277.value) {
        return parse(value277.value);
      }
    }
  } catch (error278) {}
  return undefined;
};
const _tzPayload = () => ({
  storedTz: _rawStoredTz(),
  envTz: process.env.TIMEZONE,
  ownerNumber: Array.isArray(getOwners()) && getOwners()[0] || "",
  botNumber: [(() => {
    try {
      const value279 = global && global.currentSock && global.currentSock.user;
      if (value279 && value279.id) {
        return String(value279.id).split("@")[0].split(":")[0];
      } else {
        return null;
      }
    } catch (error280) {
      return null;
    }
  })(), (() => {
    try {
      if (global && global.phoneNumber) {
        return String(global.phoneNumber).replace(/\D/g, "");
      } else {
        return null;
      }
    } catch (error281) {
      return null;
    }
  })()].filter(Boolean),
  defaultTz: BOT_SETTINGS_DEFAULTS.timezone
});
const getTimeZone = () => resolveTimeZone(_tzPayload()).tz;
const getTimeZoneSource = () => resolveTimeZone(_tzPayload()).source;
let runtimeOwnerName = null;
const setRuntimeOwnerName = value282 => {
  const value283 = typeof value282 === "string" ? value282.trim() : "";
  runtimeOwnerName = value283 || null;
  return runtimeOwnerName;
};
const getOwnerNames = () => {
  const value284 = getBotSetting("ownerName");
  const value285 = (Array.isArray(value284) ? value284 : [value284]).filter(value286 => value286 !== null && value286 !== undefined && String(value286).trim() !== "");
  if (value285.length) {
    return value285;
  }
  if (runtimeOwnerName) {
    return [runtimeOwnerName];
  }
  const value287 = getOwners();
  if (value287.length) {
    return value287;
  } else {
    return ["Bot Owner"];
  }
};
const getOwnerSource = () => getBotSetting("ownerSource");
const setOwnerNames = value288 => {
  setBotSetting("ownerName", Array.isArray(value288) ? value288 : [value288]);
  return true;
};
const ANTICALL_KEYS = ["anticall", "anticallAction", "anticallMessage", "anticallNotify"];
const getDefaultGroupSettings = () => {
  const value289 = JSON.parse(JSON.stringify(DEFAULT_GROUP_SETTINGS));
  for (const value290 of ANTICALL_KEYS) {
    value289[value290] = getBotSetting(value290);
  }
  return value289;
};
const normaliseOwner = value291 => String(value291 || "").split("@")[0].split(":")[0].replace(/\D/g, "");
const getOwners = () => {
  const value292 = getBotSetting("owners");
  if (!Array.isArray(value292)) {
    return [];
  }
  return value292.map(normaliseOwner).filter(Boolean);
};
const setOwners = (value293, value294 = "command") => {
  const value295 = (Array.isArray(value293) ? value293 : [value293]).map(normaliseOwner).filter(Boolean);
  setBotSetting("owners", [...new Set(value295)]);
  setBotSetting("ownerSource", value294 === "auto" ? "auto" : "command");
  return true;
};
const VALID_BOT_MODES = ["public", "private", "group", "pm"];
const BOT_MODE_ALIASES = Object.freeze({
  public: "public",
  private: "private",
  group: "group",
  pm: "pm",
  silent: "private",
  restricted: "private",
  groups: "group",
  grp: "group",
  dms: "pm",
  dm: "pm",
  inbox: "pm",
  priv: "private",
  pub: "public"
});
const normalizeBotMode = value296 => {
  const value297 = String(value296 || "").trim().toLowerCase();
  return BOT_MODE_ALIASES[value297] || null;
};
const getBotMode = () => normalizeBotMode(getBotSetting("mode")) || "public";
const setBotMode = value298 => {
  const value299 = normalizeBotMode(value298);
  if (!value299) {
    throw new Error("Invalid mode: " + value298);
  }
  setBotSetting("mode", value299);
  return value299;
};
const LOGIN_METHOD_VALUES = Object.freeze(["session", "number"]);
const getStoredLoginMethod = () => {
  const value300 = String(getBotSetting("loginMethod") || "").trim().toLowerCase();
  if (LOGIN_METHOD_VALUES.includes(value300)) {
    return value300;
  } else {
    return null;
  }
};
const setStoredLoginMethod = value301 => {
  const value302 = String(value301 || "").trim().toLowerCase();
  if (!LOGIN_METHOD_VALUES.includes(value302)) {
    throw new Error("Invalid login method: " + value301);
  }
  setBotSetting("loginMethod", value302);
  return value302;
};
const clearStoredLoginMethod = () => {
  setBotSetting("loginMethod", null);
  return true;
};
const MENU_STYLE_VALUES = Object.freeze(["1", "2", "3", "4", "5", "6"]);
const MENU_SETTINGS_DEFAULTS = Object.freeze({
  menuStyle: "5",
  showMemory: true,
  showUptime: true,
  showPluginCount: true,
  showProgressBar: true
});
function normaliseMenuStyle(value303) {
  const value304 = String(value303 || "").trim();
  if (MENU_STYLE_VALUES.includes(value304)) {
    return value304;
  } else {
    return MENU_SETTINGS_DEFAULTS.menuStyle;
  }
}
function menuBoolean(value305, value306) {
  if (typeof value305 === "boolean") {
    return value305;
  } else {
    return value306;
  }
}
const getMenuSettings = () => ({
  menuStyle: normaliseMenuStyle(getBotSetting("menuStyle")),
  showMemory: menuBoolean(getBotSetting("menuShowMemory"), MENU_SETTINGS_DEFAULTS.showMemory),
  showUptime: menuBoolean(getBotSetting("menuShowUptime"), MENU_SETTINGS_DEFAULTS.showUptime),
  showPluginCount: menuBoolean(getBotSetting("menuShowPluginCount"), MENU_SETTINGS_DEFAULTS.showPluginCount),
  showProgressBar: menuBoolean(getBotSetting("menuShowProgressBar"), MENU_SETTINGS_DEFAULTS.showProgressBar)
});
const updateMenuSettings = (value307 = {}) => {
  const value308 = getMenuSettings();
  const value309 = value310 => Object.prototype.hasOwnProperty.call(value307, value310);
  const value311 = {
    menuStyle: value309("menuStyle") ? normaliseMenuStyle(value307.menuStyle) : value308.menuStyle,
    showMemory: value309("showMemory") ? menuBoolean(value307.showMemory, value308.showMemory) : value308.showMemory,
    showUptime: value309("showUptime") ? menuBoolean(value307.showUptime, value308.showUptime) : value308.showUptime,
    showPluginCount: value309("showPluginCount") ? menuBoolean(value307.showPluginCount, value308.showPluginCount) : value308.showPluginCount,
    showProgressBar: value309("showProgressBar") ? menuBoolean(value307.showProgressBar, value308.showProgressBar) : value308.showProgressBar
  };
  updateBotSettings({
    menuStyle: value311.menuStyle,
    menuShowMemory: value311.showMemory,
    menuShowUptime: value311.showUptime,
    menuShowPluginCount: value311.showPluginCount,
    menuShowProgressBar: value311.showProgressBar
  });
  return value311;
};
const getMenuImageSettings = () => {
  const value312 = getBotSetting("menuImageData");
  const value313 = getBotSetting("menuImageCustom") === true;
  const value314 = typeof value312 === "string" && value312.trim().length > 0;
  return {
    custom: value313 && value314,
    imageData: value313 && value314 ? value312 : null
  };
};
const setMenuImageData = value315 => {
  const value316 = typeof value315 === "string" && value315.trim().length > 0 ? value315 : null;
  updateBotSettings({
    menuImageCustom: Boolean(value316),
    menuImageData: value316
  });
  return Boolean(value316);
};
const clearMenuImageData = () => {
  updateBotSettings({
    menuImageCustom: false,
    menuImageData: null
  });
  return true;
};
const AUTO_DOWNLOAD_STATUS_TYPES = Object.freeze(["image", "video", "audio", "document", "sticker", "text"]);
const AUTO_DOWNLOAD_STATUS_DEFAULTS = Object.freeze({
  enabled: false,
  mode: "private",
  publicJid: "",
  ownerJid: "",
  downloadTypes: AUTO_DOWNLOAD_STATUS_TYPES,
  excludedContacts: [],
  skipOwnerStatus: true,
  totalDownloaded: 0
});
function autoDownloadStatusBoolean(value317, value318) {
  if (typeof value317 === "boolean") {
    return value317;
  } else {
    return value318;
  }
}
function normaliseAutoDownloadStatusMode(value319) {
  const value320 = String(value319 || "").trim().toLowerCase();
  if (["private", "public"].includes(value320)) {
    return value320;
  } else {
    return AUTO_DOWNLOAD_STATUS_DEFAULTS.mode;
  }
}
function normaliseAutoDownloadStatusTypes(value321) {
  if (!Array.isArray(value321)) {
    return [...AUTO_DOWNLOAD_STATUS_TYPES];
  }
  return [...new Set(value321.map(value322 => String(value322 || "").trim().toLowerCase()).filter(value323 => AUTO_DOWNLOAD_STATUS_TYPES.includes(value323)))];
}
function normaliseExcludedContacts(value324) {
  if (!Array.isArray(value324)) {
    return [];
  }
  return [...new Set(value324.map(value325 => String(value325 || "").replace(/\D/g, "")).filter(Boolean))];
}
function normaliseDownloadCount(value326) {
  const value327 = Number(value326);
  if (Number.isFinite(value327) && value327 > 0) {
    return Math.floor(value327);
  } else {
    return 0;
  }
}
function normaliseAutoDownloadStatusSettings(value328) {
  const value329 = value328 && typeof value328 === "object" && !Array.isArray(value328) ? value328 : {};
  return {
    enabled: autoDownloadStatusBoolean(value329.enabled, AUTO_DOWNLOAD_STATUS_DEFAULTS.enabled),
    mode: normaliseAutoDownloadStatusMode(value329.mode),
    publicJid: typeof value329.publicJid === "string" ? value329.publicJid.trim() : "",
    ownerJid: typeof value329.ownerJid === "string" ? value329.ownerJid.trim() : "",
    downloadTypes: Array.isArray(value329.downloadTypes) ? normaliseAutoDownloadStatusTypes(value329.downloadTypes) : [...AUTO_DOWNLOAD_STATUS_TYPES],
    excludedContacts: normaliseExcludedContacts(value329.excludedContacts),
    skipOwnerStatus: autoDownloadStatusBoolean(value329.skipOwnerStatus, AUTO_DOWNLOAD_STATUS_DEFAULTS.skipOwnerStatus),
    totalDownloaded: normaliseDownloadCount(value329.totalDownloaded)
  };
}
const getAutoDownloadStatusSettings = () => normaliseAutoDownloadStatusSettings(getBotSetting("autoDownloadStatus"));
const setAutoDownloadStatusSettings = (value330 = {}) => {
  const value331 = getAutoDownloadStatusSettings();
  const value332 = value330 && typeof value330 === "object" && !Array.isArray(value330) ? value330 : {};
  const value333 = normaliseAutoDownloadStatusSettings({
    ...value331,
    ...value332
  });
  setBotSetting("autoDownloadStatus", value333);
  return value333;
};
const hasStatusBeenDownloaded = value334 => {
  if (!value334) {
    return false;
  }
  return !!stmts.getStatusDownload.get(String(value334));
};
function trimStatusDownloadHistory() {
  const value335 = stmts.countStatusDownloads.get();
  const value336 = Math.max(0, Number(value335?.count || 0) - AUTO_DOWNLOAD_STATUS_HISTORY_MAX_ROWS);
  if (!value336) {
    return 0;
  }
  return stmts.deleteOldestStatusDownloads.run(value336).changes || 0;
}
const markStatusDownloaded = (value337, value338 = {}) => {
  if (!value337) {
    return false;
  }
  const value339 = stmts.insertStatusDownload.run(String(value337), String(value338.senderId || ""), String(value338.mediaType || "unknown"), Number(value338.downloadedAt || Date.now()), String(value338.destinationJid || ""));
  if (!value339.changes) {
    return false;
  }
  trimStatusDownloadHistory();
  requestBackup("status-download");
  return true;
};
const getStatusDownloadLogs = (value340 = 100) => {
  const value341 = Math.max(1, Math.min(500, Math.floor(Number(value340) || 100)));
  return stmts.getStatusDownloadLogs.all(value341).map(value342 => ({
    statusId: value342.status_id,
    senderId: value342.sender_id,
    mediaType: value342.media_type,
    downloadedAt: value342.downloaded_at,
    destinationJid: value342.destination_jid
  }));
};
const clearStatusDownloadHistory = () => {
  const value343 = stmts.clearStatusDownloadHistory.run();
  requestBackup("status-download-history-clear");
  return value343.changes || 0;
};
const incrementStatusDownloadCount = () => {
  const value344 = getAutoDownloadStatusSettings();
  const value345 = value344.totalDownloaded + 1;
  setAutoDownloadStatusSettings({
    totalDownloaded: value345
  });
  return value345;
};
const ANTIDELETE_MODES = Object.freeze(["off", "chat", "private"]);
const ANTIEDIT_MODES = Object.freeze(["off", "chat", "pm"]);
const ANTITAGADMINS_ACTIONS = Object.freeze(["kick", "warn", "delete"]);
function normaliseChoice(value346, value347, value348) {
  const value349 = String(value346 || "").trim().toLowerCase();
  if (value347.includes(value349)) {
    return value349;
  } else {
    return value348;
  }
}
const getAntideleteMode = () => normaliseChoice(getBotSetting("antideleteMode"), ANTIDELETE_MODES, "off");
const setAntideleteMode = value350 => {
  const value351 = normaliseChoice(value350, ANTIDELETE_MODES, null);
  if (!value351) {
    throw new Error("Invalid Anti-Delete mode");
  }
  setBotSetting("antideleteMode", value351);
  return value351;
};
const getAntieditMode = () => normaliseChoice(getBotSetting("antieditMode"), ANTIEDIT_MODES, "off");
const setAntieditMode = value352 => {
  const value353 = normaliseChoice(value352, ANTIEDIT_MODES, null);
  if (!value353) {
    throw new Error("Invalid Anti-Edit mode");
  }
  setBotSetting("antieditMode", value353);
  return value353;
};
const isAntideleteStatusEnabled = () => getBotSetting("antideleteStatus") === true;
const setAntideleteStatusEnabled = value354 => {
  const value355 = value354 === true;
  setBotSetting("antideleteStatus", value355);
  return value355;
};
const getAntiTagAdminsSettings = value356 => {
  const value357 = getGroupSettings(value356);
  return {
    enabled: value357.antitagadmins === true,
    action: normaliseChoice(value357.antitagadminsAction, ANTITAGADMINS_ACTIONS, "warn")
  };
};
const setAntiTagAdminsSettings = (value358, value359 = {}) => {
  const value360 = getAntiTagAdminsSettings(value358);
  const value361 = {
    enabled: Object.prototype.hasOwnProperty.call(value359, "enabled") ? value359.enabled === true : value360.enabled,
    action: Object.prototype.hasOwnProperty.call(value359, "action") ? normaliseChoice(value359.action, ANTITAGADMINS_ACTIONS, "warn") : value360.action
  };
  updateGroupSettings(value358, {
    antitagadmins: value361.enabled,
    antitagadminsAction: value361.action
  });
  return value361;
};
const isAntiAllEnabled = value362 => getGroupSettings(value362).antiall === true;
const setAntiAllEnabled = (value363, value364) => {
  const value365 = value364 === true;
  updateGroupSettings(value363, {
    antiall: value365
  });
  return value365;
};
const getAntiforwardSettings = value366 => {
  const value367 = getGroupSettings(value366);
  return {
    enabled: value367.antiforward || false,
    warnLimit: value367.antiforwardLimit || 3
  };
};
const updateAntiforwardSettings = (value368, value369, value370) => {
  updateGroupSettings(value368, {
    antiforward: !!value369,
    antiforwardLimit: Number(value370) || 3
  });
  requestBackup("antiforward-settings");
};
const addAntiforwardWarning = (value371, value372) => addWarning(value371, value372, "antiforward");
const getAntiforwardWarningCount = (value373, value374) => getWarnings(value373, value374).count;
const clearAntiforwardWarning = (value375, value376) => removeWarning(value375, value376);
const clearAllAntiforwardWarnings = value377 => clearWarnings(value377);
const saveSession = value378 => {
  try {
    if (!fs.existsSync(value378)) {
      return false;
    }
    const value379 = fs.readFileSync(value378).toString("base64");
    stmts.upsertSession.run(value379, Date.now());
    requestBackup("session");
    return true;
  } catch (error380) {
    console.error("[SESSION-DB]:", error380.message);
    return false;
  }
};
const getSession = () => {
  try {
    const value381 = stmts.getSession.get();
    if (value381) {
      return value381.creds;
    } else {
      return null;
    }
  } catch (error382) {
    console.error("[SESSION-DB]:", error382.message);
    return null;
  }
};
const clearSession = () => {
  stmts.clearSession.run();
  requestBackup("session-clear");
  return true;
};
function loadSettings() {
  return {
    enabled: getBotSetting("autoStatusView") || false,
    react: getBotSetting("autoStatusReact") || false,
    emoji: getBotSetting("autoStatusEmoji") || "💙",
    emojiPool: getBotSetting("autoStatusEmojiPool") || [],
    randomEmoji: getBotSetting("autoStatusRandomEmoji") || false
  };
}
function saveSettings(value383) {
  updateBotSettings({
    autoStatusView: !!value383.enabled,
    autoStatusReact: !!value383.react,
    autoStatusEmoji: value383.emoji || "",
    autoStatusEmojiPool: value383.emojiPool || [],
    autoStatusRandomEmoji: !!value383.randomEmoji
  });
}
function cleanEmoji(value384) {
  return value384.replace(/[\u{FE00}-\u{FE0F}\u{E0100}-\u{E01EF}\u200D\u200B\uFEFF]/gu, "").trim();
}
function pickEmoji(value385) {
  if (value385.randomEmoji && value385.emojiPool.length) {
    return value385.emojiPool[Math.floor(Math.random() * value385.emojiPool.length)];
  } else {
    return value385.emoji;
  }
}
const getKV = (value386, value387, value388 = null) => {
  const value389 = stmts.getKV.get(value386, value387);
  if (!value389) {
    return value388;
  }
  return parse(value389.value, value388);
};
const setKV = (value390, value391, value392) => {
  stmts.setKV.run(value390, value391, serial(value392));
  requestBackup("kv");
  mirrorRemote("mirrorKV", value390, value391, value392);
  return true;
};
const delKV = (value393, value394) => {
  stmts.delKV.run(value393, value394);
  requestBackup("kv-delete");
  deleteRemoteKV(value393, value394);
  return true;
};
const getAllKV = value395 => {
  const value396 = stmts.allKV.all(value395);
  const value397 = {};
  for (const {
    key: value398,
    value: value399
  } of value396) {
    value397[value398] = parse(value399);
  }
  return value397;
};
const SESSION_ERROR_STATE_NAMESPACE = "runtime";
const SESSION_ERROR_STATE_KEY = "sessionErrorCount";
const SESSION_ERROR_STATE_DEFAULT = Object.freeze({
  count: 0,
  last_error_timestamp: 0
});
function normaliseSessionErrorState(value400) {
  const value401 = value400 && typeof value400 === "object" && !Array.isArray(value400) ? value400 : {};
  const value402 = Number(value401.count);
  const value403 = Number(value401.last_error_timestamp);
  return {
    count: Number.isFinite(value402) && value402 > 0 ? Math.floor(value402) : 0,
    last_error_timestamp: Number.isFinite(value403) && value403 > 0 ? Math.floor(value403) : 0
  };
}
const getSessionErrorState = () => normaliseSessionErrorState(getKV(SESSION_ERROR_STATE_NAMESPACE, SESSION_ERROR_STATE_KEY, SESSION_ERROR_STATE_DEFAULT));
const setSessionErrorState = value404 => {
  const value405 = normaliseSessionErrorState(value404);
  setKV(SESSION_ERROR_STATE_NAMESPACE, SESSION_ERROR_STATE_KEY, value405);
  return value405;
};
const clearSessionErrorState = () => {
  delKV(SESSION_ERROR_STATE_NAMESPACE, SESSION_ERROR_STATE_KEY);
  return true;
};
const getGroupStat = (value406, value407) => {
  const value408 = stmts.getGroupStat.get(String(value406), String(value407));
  if (value408) {
    return parse(value408.data, {});
  } else {
    return null;
  }
};
const saveGroupStat = (value409, value410, value411) => {
  stmts.insertGroupStat.run(String(value409), String(value410), serial(value411 || {}));
  requestBackup("group-stat");
  mirrorRemote("mirrorGroupStat", value409, value410, value411);
  return true;
};
const getAllGroupStats = value412 => stmts.getAllGroupStats.all(String(value412)).map(value413 => ({
  date: value413.date,
  data: parse(value413.data, {})
}));
const saveAntideleteMessage = (value414, value415, value416, value417 = Date.now()) => {
  stmts.saveAntideleteMessage.run(String(value414), String(value415), serial(value416 || {}), Number(value417));
  requestBackup("antidelete-message");
  mirrorRemote("mirrorAntideleteMessage", value414, value415, value416, value417);
  return true;
};
const getAntideleteMessage = (value418, value419) => {
  const value420 = stmts.getAntideleteMessage.get(String(value418), String(value419));
  if (value420) {
    return {
      chatId: value420.chat_id,
      messageId: value420.message_id,
      payload: parse(value420.payload, {}),
      storedAt: value420.stored_at
    };
  } else {
    return null;
  }
};
const getAntideleteMessages = () => stmts.getAntideleteMessages.all().map(value421 => ({
  chatId: value421.chat_id,
  messageId: value421.message_id,
  payload: parse(value421.payload, {}),
  storedAt: value421.stored_at
}));
const deleteAntideleteMessage = (value422, value423) => {
  stmts.deleteAntideleteMessage.run(String(value422), String(value423));
  requestBackup("antidelete-message-delete");
  mirrorRemote("deleteAntideleteMessage", value422, value423);
  return true;
};
const saveAntideleteStatus = (value424, value425, value426 = Date.now()) => {
  stmts.saveAntideleteStatus.run(String(value424), serial(value425 || {}), Number(value426));
  requestBackup("antidelete-status");
  mirrorRemote("mirrorAntideleteStatus", value424, value425, value426);
  return true;
};
const getAntideleteStatuses = () => stmts.getAntideleteStatuses.all().map(value427 => ({
  statusId: value427.status_id,
  payload: parse(value427.payload, {}),
  storedAt: value427.stored_at
}));
const deleteAntideleteStatus = value428 => {
  stmts.deleteAntideleteStatus.run(String(value428));
  mirrorRemote("deleteAntideleteStatus", value428);
  return true;
};
const saveLidMap = (value429, value430, value431, value432 = Date.now()) => {
  stmts.saveLidMap.run(String(value429), String(value430), String(value431), Number(value432));
  mirrorRemote("mirrorLidMap", value429, value430, value431, value432);
  return true;
};
const getLidMaps = () => stmts.getLidMaps.all();
const getLidMap = (value433, value434) => {
  const value435 = stmts.getLidMap.get(String(value433), String(value434));
  return value435?.value || null;
};
const recordRuntimeTelemetry = (value436, value437, value438 = {}, value439 = Date.now()) => {
  const value440 = String(value436 || "unknown").slice(0, 80);
  const value441 = String(value437 || "unknown").slice(0, 240);
  const value442 = Number(value439) || Date.now();
  const value443 = serial(value438 || {});
  stmts.upsertRuntimeTelemetry.run(value440, value441, value443, value442, value442);
  const value444 = stmts.getRuntimeTelemetryEntry.get(value440, value441);
  mirrorRemote("mirrorKV", "runtime_telemetry", value440 + ":" + value441, {
    eventType: value440,
    eventKey: value441,
    payload: value438 || {},
    count: value444?.count || 1,
    firstSeen: value444?.first_seen || value442,
    lastSeen: value444?.last_seen || value442
  });
  requestBackup("runtime-telemetry");
  return true;
};
const getRuntimeTelemetry = (value445 = 100) => stmts.getRuntimeTelemetry.all(Math.max(1, Math.min(1000, Number(value445) || 100))).map(value446 => ({
  eventType: value446.event_type,
  eventKey: value446.event_key,
  payload: parse(value446.payload, {}),
  count: value446.count,
  firstSeen: value446.first_seen,
  lastSeen: value446.last_seen
}));
const CHAT_MEMORY_MAX = 25;
const CHAT_MEMORY_FACTS = [[/my name is ([A-Za-z][\w-]*)/i, "name"], [/(?:i'm|i am) ([A-Za-z][\w-]*)(?:\s|$|,)/i, "name"], [/call me ([A-Za-z][\w-]*)/i, "name"], [/(?:i'm|i am) (\d{1,3})(?: years? old)?/i, "age"], [/i work (?:as |at )([\w\s-]{3,40})/i, "job"], [/i(?:'m| am) from ([A-Za-z\s]{3,30})/i, "location"], [/i live in ([A-Za-z\s]{3,30})/i, "location"], [/i (?:love|really like|like|enjoy) ([\w\s-]{3,40})/i, "interest"], [/i (?:hate|dislike|can't stand) ([\w\s-]{3,40})/i, "dislike"]];
const CHAT_MEMORY_SKIP = new Set(["a", "an", "the", "not", "so", "here", "just", "good", "bad", "fine", "going", "trying", "using", "happy", "sad", "tired", "busy"]);
function loadProfile(value447, value448) {
  const value449 = String(value447 || "default").replace(/[^\w-]/g, "_");
  const value450 = String(value448).replace(/[^\w]/g, "_");
  const value451 = stmts.getProfile.get(value449, value450);
  if (value451) {
    return parse(value451.profile);
  }
  const value452 = new Date().toISOString();
  return {
    userId: value448,
    name: null,
    age: null,
    location: null,
    job: null,
    interests: [],
    dislikes: [],
    memories: [],
    messageCount: 0,
    firstSeen: value452,
    lastSeen: value452
  };
}
function saveProfile(value453, value454, value455) {
  const value456 = String(value453 || "default").replace(/[^\w-]/g, "_");
  const value457 = String(value454).replace(/[^\w]/g, "_");
  value455.lastSeen = new Date().toISOString();
  value455.messageCount = (value455.messageCount || 0) + 1;
  stmts.saveProfile.run(value456, value457, serial(value455));
  requestBackup("chat-profile");
  mirrorRemote("mirrorProfile", value456, value457, value455);
}
function learnFromMessage(value458, value459) {
  const value460 = {
    ...value459,
    memories: [...(value459.memories || [])],
    interests: [...(value459.interests || [])],
    dislikes: [...(value459.dislikes || [])]
  };
  for (const [value461, value462] of CHAT_MEMORY_FACTS) {
    const value463 = String(value458).match(value461);
    if (!value463) {
      continue;
    }
    const value464 = value463[1].trim();
    if (!value464 || value464.length > 60 || value462 === "name" && CHAT_MEMORY_SKIP.has(value464.toLowerCase())) {
      continue;
    }
    const value465 = value464.charAt(0).toUpperCase() + value464.slice(1);
    if (["name", "age", "location", "job"].includes(value462) && !value460[value462]) {
      value460[value462] = value462 === "age" ? value465 + " years old" : value465;
    }
    if (value462 === "interest" && !value460.interests.includes(value465)) {
      value460.interests = [...value460.interests, value465].slice(-10);
    }
    if (value462 === "dislike" && !value460.dislikes.includes(value465)) {
      value460.dislikes = [...value460.dislikes, value465].slice(-10);
    }
    const value466 = "User's " + value462 + ": " + value465;
    if (!value460.memories.some(value467 => value467.toLowerCase() === value466.toLowerCase())) {
      value460.memories.unshift(value466);
    }
  }
  value460.memories = value460.memories.slice(0, CHAT_MEMORY_MAX);
  return value460;
}
function buildProfileContext(value468) {
  if (!value468) {
    return "";
  }
  const value469 = [];
  for (const value470 of ["name", "age", "location", "job"]) {
    if (value468[value470]) {
      value469.push("- " + value470 + ": " + value468[value470]);
    }
  }
  if (value468.interests?.length) {
    value469.push("- interests: " + value468.interests.slice(0, 5).join(", "));
  }
  if (value468.dislikes?.length) {
    value469.push("- dislikes: " + value468.dislikes.slice(0, 5).join(", "));
  }
  if (value468.messageCount > 1) {
    value469.push("- This is a returning user.");
  }
  if (value469.length) {
    return "\nWhat you know about the user:\n" + value469.join("\n") + "\n";
  } else {
    return "";
  }
}
function getPersonalizedGreeting(value471) {
  if (value471?.name) {
    return "Hey " + value471.name + "!";
  } else {
    return null;
  }
}
let shutdownPromise = null;
async function shutdownDatabase() {
  if (shutdownPromise) {
    return shutdownPromise;
  }
  shuttingDown = true;
  shutdownPromise = (async () => {
    try {
      console.log("[DB] 🔄 Shutting down...");
      await ready;
      await flushRemoteAuthMirror("shutdown");
      await flushBackup();
    } finally {
      try {
        db?.close();
      } catch (error472) {}
      try {
        await pgAdapter.close();
      } catch (error473) {}
      try {
        await mongoAdapter.close();
      } catch (error474) {}
      console.log("[DB] ✅ Closed");
    }
  })();
  return shutdownPromise;
}
const handleDatabaseSignal = () => {
  const value475 = global.__JUNE_SHUTDOWN;
  const value476 = typeof value475 === "function" ? value475() : shutdownDatabase();
  Promise.resolve(value476).finally(() => process.exit(0));
};
process.once("SIGINT", handleDatabaseSignal);
process.once("SIGTERM", handleDatabaseSignal);
process.on("exit", () => {
  try {
    db.close();
  } catch (error477) {}
});
function runIntegrityCheck() {
  const value478 = integrityCheck(db);
  lastIntegrityCheck = {
    ...value478,
    checkedAt: Date.now()
  };
  return value478;
}
function getDatabaseHealth() {
  let value479 = false;
  let value480 = 0;
  let value481 = false;
  try {
    value479 = fs.existsSync(DB_BACKUP_FILE);
    if (value479) {
      value480 = fs.statSync(DB_BACKUP_FILE).size || 0;
      value481 = validateBackup(DB_BACKUP_FILE);
    }
  } catch (error482) {
    value479 = false;
    value480 = 0;
    value481 = false;
  }
  const value483 = dirtyRevision > backedUpRevision;
  try {
    const value484 = fs.statSync(DB_FILE);
    const value485 = lastIntegrityCheck || {
      ok: true,
      result: "not-yet-run",
      checkedAt: null
    };
    return {
      ok: value485.ok !== false,
      driver: dbDriver,
      schemaVersion: DB_SCHEMA_VERSION,
      file: DB_FILE,
      size: value484.size,
      lastIntegrity: value485,
      lastBackup: lastBackup,
      maintenance: lastMaintenance,
      remoteSync: getRemoteSyncQueueStats(),
      authMirror: getRemoteAuthMirrorStatus(),
      postgres: pgAdapter.getStatus(),
      mongo: mongoAdapter.getStatus(),
      databaseSizeBytes: value484.size,
      backupSizeBytes: value480,
      backupExists: value479,
      backupValid: value481,
      dirty: value483,
      lastIntegrityCheck: value485
    };
  } catch (error486) {
    const value487 = lastIntegrityCheck || {
      ok: false,
      result: error486.message,
      checkedAt: null
    };
    return {
      ok: false,
      driver: dbDriver,
      schemaVersion: DB_SCHEMA_VERSION,
      file: DB_FILE,
      error: error486.message,
      size: 0,
      lastIntegrity: value487,
      lastBackup: lastBackup,
      maintenance: lastMaintenance,
      remoteSync: getRemoteSyncQueueStats(),
      authMirror: getRemoteAuthMirrorStatus(),
      postgres: pgAdapter.getStatus(),
      mongo: mongoAdapter.getStatus(),
      databaseSizeBytes: 0,
      backupSizeBytes: value480,
      backupExists: value479,
      backupValid: value481,
      dirty: value483,
      lastIntegrityCheck: value487
    };
  }
}
function markDatabaseDirty(value488 = "manual-mark") {
  const value489 = String(value488 || "manual-mark").slice(0, 80);
  requestBackup(value489);
  if (/^(auth|session)/i.test(value489)) {
    scheduleRemoteAuthMirror(value489);
  }
}
function backfillRemote() {
  if (!db) {
    return {
      pushed: 0,
      skipped: "database-unavailable"
    };
  }
  const value490 = {
    botSettings: 0,
    groups: 0,
    moderators: 0
  };
  try {
    for (const [value491, value492] of Object.entries(getStoredBotSettings())) {
      mirrorRemote("mirrorBotSetting", value491, value492);
      value490.botSettings++;
    }
  } catch (error493) {}
  try {
    for (const value494 of db.prepare("SELECT group_id, settings FROM groups").all()) {
      mirrorRemote("mirrorGroupSettings", value494.group_id, parse(value494.settings, {}));
      value490.groups++;
    }
  } catch (error495) {}
  try {
    for (const value496 of stmts.getModerators.all()) {
      mirrorRemote("mirrorModerator", value496.user_id, true);
      value490.moderators++;
    }
  } catch (error497) {}
  const value498 = value490.botSettings + value490.groups + value490.moderators;
  return {
    pushed: value498,
    ...value490
  };
}
async function restoreFromPostgres() {
  const value499 = await pgAdapter.restoreIntoSQLite(db);
  clearBotSettingsCache();
  if (value499?.restored > 0) {
    requestBackup("postgres-restore");
  }
  return value499;
}
async function restoreFromMongo() {
  const value500 = await mongoAdapter.restoreIntoSQLite(db);
  clearBotSettingsCache();
  if (value500?.restored > 0) {
    requestBackup("mongo-restore");
  }
  return value500;
}
async function clearRemoteData(value501 = false) {
  const value502 = ["bot-setting", "group-settings", "group-stat", "user", "warning", "moderator", "muted-user", "kv", "antidelete-message", "antidelete-status", "chat-profile", "lid-map"];
  const value503 = [];
  let value504 = false;
  for (const value505 of value502) {
    try {
      const value506 = await mongoAdapter.clearKind(value505);
      if (value506 && value506.ok) {
        value504 = true;
      }
      value503.push("mongo:" + value505 + "=" + (value506 ? value506.deleted : "n/a"));
    } catch (error507) {
      value503.push("mongo:" + value505 + "=err");
    }
    try {
      const value508 = await pgAdapter.clearKind(value505);
      if (value508 && value508.ok) {
        value504 = true;
      }
      value503.push("pg:" + value505 + "=" + (value508 ? value508.deleted : "n/a"));
    } catch (error509) {
      value503.push("pg:" + value505 + "=err");
    }
  }
  if (value501) {
    try {
      await clearRemoteAuthState();
      value504 = true;
    } catch (error510) {}
  }
  return {
    remoteCleared: value504,
    details: value503
  };
}
async function resetDatabase(value511 = {}) {
  const value512 = !!value511.includeSession;
  const value513 = !!value511.includeOwner;
  const value514 = value513 ? null : {
    owners: getBotSetting("owners"),
    ownerSource: getBotSetting("ownerSource"),
    ownerName: getStoredBotSettings().ownerName
  };
  const value515 = ["warnings", "moderators", "muted_users", "kv_store", "antidelete_messages", "antidelete_statuses", "status_downloads", "group_stats", "groups", "users", "chat_profiles", "lid_map", "runtime_telemetry", "bot_settings", "remote_sync_queue"];
  if (value512) {
    value515.push("session", "session_creds", "session_keys", "session_auth_meta");
  }
  const value516 = [];
  if (db) {
    const value517 = db.transaction(() => {
      for (const value518 of value515) {
        try {
          db.prepare("DELETE FROM " + value518).run();
          value516.push(value518);
        } catch (error519) {}
      }
    });
    value517();
  }
  clearBotSettingsCache();
  if (value514) {
    if (Array.isArray(value514.owners) && value514.owners.length) {
      setBotSetting("owners", value514.owners);
      setBotSetting("ownerSource", value514.ownerSource || "auto");
    }
    if (value514.ownerName !== undefined) {
      setBotSetting("ownerName", value514.ownerName);
    }
  }
  const value520 = await clearRemoteData(value512);
  try {
    requestBackup("reset-database");
  } catch (error521) {}
  try {
    vacuumDatabase();
  } catch (error522) {}
  return {
    localCleared: value516,
    includeSession: value512,
    includeOwner: value513,
    ownerPreserved: !!value514,
    remote: value520
  };
}
module.exports = {
  ready: ready,
  getGroupSettings: getGroupSettings,
  updateGroupSettings: updateGroupSettings,
  getUser: getUser,
  updateUser: updateUser,
  getWarnings: getWarnings,
  addWarning: addWarning,
  removeWarning: removeWarning,
  clearWarnings: clearWarnings,
  getModerators: getModerators,
  addModerator: addModerator,
  removeModerator: removeModerator,
  isModerator: isModerator,
  muteUser: muteUser,
  unmuteUser: unmuteUser,
  isUserMuted: isUserMuted,
  getMutedUsers: getMutedUsers,
  getBotSetting: getBotSetting,
  setBotSetting: setBotSetting,
  getTimeZone: getTimeZone,
  getTimeZoneSource: getTimeZoneSource,
  getStoredBotSettings: getStoredBotSettings,
  getAllBotSettings: getAllBotSettings,
  updateBotSettings: updateBotSettings,
  BOT_SETTINGS_DEFAULTS: BOT_SETTINGS_DEFAULTS,
  clearBotSettingsCache: clearBotSettingsCache,
  getOwners: getOwners,
  setOwners: setOwners,
  getOwnerNames: getOwnerNames,
  setOwnerNames: setOwnerNames,
  getOwnerSource: getOwnerSource,
  setRuntimeOwnerName: setRuntimeOwnerName,
  SESSION_NAME: SESSION_NAME,
  getStoredGroupSettings: getStoredGroupSettings,
  MESSAGES: MESSAGES,
  DEFAULT_GROUP_SETTINGS: DEFAULT_GROUP_SETTINGS,
  getDefaultGroupSettings: getDefaultGroupSettings,
  ANTICALL_PRESETS: ANTICALL_PRESETS,
  SOCIAL: SOCIAL,
  API_KEYS: API_KEYS,
  TELEGRAM_TOKEN: TELEGRAM_TOKEN,
  JUNE_BOT_ID: JUNE_BOT_ID,
  UPDATE_ZIP_URL: UPDATE_ZIP_URL,
  VERSION: VERSION,
  getBotMode: getBotMode,
  setBotMode: setBotMode,
  VALID_BOT_MODES: VALID_BOT_MODES,
  getStoredLoginMethod: getStoredLoginMethod,
  setStoredLoginMethod: setStoredLoginMethod,
  clearStoredLoginMethod: clearStoredLoginMethod,
  LOGIN_METHOD_VALUES: LOGIN_METHOD_VALUES,
  getMenuSettings: getMenuSettings,
  updateMenuSettings: updateMenuSettings,
  MENU_STYLE_VALUES: MENU_STYLE_VALUES,
  MENU_SETTINGS_DEFAULTS: MENU_SETTINGS_DEFAULTS,
  getMenuImageSettings: getMenuImageSettings,
  setMenuImageData: setMenuImageData,
  clearMenuImageData: clearMenuImageData,
  getAutoDownloadStatusSettings: getAutoDownloadStatusSettings,
  setAutoDownloadStatusSettings: setAutoDownloadStatusSettings,
  AUTO_DOWNLOAD_STATUS_TYPES: AUTO_DOWNLOAD_STATUS_TYPES,
  AUTO_DOWNLOAD_STATUS_DEFAULTS: AUTO_DOWNLOAD_STATUS_DEFAULTS,
  markStatusDownloaded: markStatusDownloaded,
  hasStatusBeenDownloaded: hasStatusBeenDownloaded,
  getStatusDownloadLogs: getStatusDownloadLogs,
  clearStatusDownloadHistory: clearStatusDownloadHistory,
  incrementStatusDownloadCount: incrementStatusDownloadCount,
  getAntideleteMode: getAntideleteMode,
  setAntideleteMode: setAntideleteMode,
  ANTIDELETE_MODES: ANTIDELETE_MODES,
  getAntieditMode: getAntieditMode,
  setAntieditMode: setAntieditMode,
  ANTIEDIT_MODES: ANTIEDIT_MODES,
  isAntideleteStatusEnabled: isAntideleteStatusEnabled,
  setAntideleteStatusEnabled: setAntideleteStatusEnabled,
  getAntiTagAdminsSettings: getAntiTagAdminsSettings,
  setAntiTagAdminsSettings: setAntiTagAdminsSettings,
  ANTITAGADMINS_ACTIONS: ANTITAGADMINS_ACTIONS,
  isAntiAllEnabled: isAntiAllEnabled,
  setAntiAllEnabled: setAntiAllEnabled,
  getAntiforwardSettings: getAntiforwardSettings,
  updateAntiforwardSettings: updateAntiforwardSettings,
  addAntiforwardWarning: addAntiforwardWarning,
  getAntiforwardWarningCount: getAntiforwardWarningCount,
  clearAntiforwardWarning: clearAntiforwardWarning,
  clearAllAntiforwardWarnings: clearAllAntiforwardWarnings,
  saveSession: saveSession,
  getSession: getSession,
  clearSession: clearSession,
  loadSettings: loadSettings,
  saveSettings: saveSettings,
  cleanEmoji: cleanEmoji,
  pickEmoji: pickEmoji,
  getKV: getKV,
  setKV: setKV,
  delKV: delKV,
  getAllKV: getAllKV,
  getSessionErrorState: getSessionErrorState,
  setSessionErrorState: setSessionErrorState,
  clearSessionErrorState: clearSessionErrorState,
  getGroupStat: getGroupStat,
  saveGroupStat: saveGroupStat,
  getAllGroupStats: getAllGroupStats,
  saveAntideleteMessage: saveAntideleteMessage,
  getAntideleteMessage: getAntideleteMessage,
  getAntideleteMessages: getAntideleteMessages,
  deleteAntideleteMessage: deleteAntideleteMessage,
  saveAntideleteStatus: saveAntideleteStatus,
  getAntideleteStatuses: getAntideleteStatuses,
  deleteAntideleteStatus: deleteAntideleteStatus,
  saveLidMap: saveLidMap,
  getLidMap: getLidMap,
  getLidMaps: getLidMaps,
  recordRuntimeTelemetry: recordRuntimeTelemetry,
  getRuntimeTelemetry: getRuntimeTelemetry,
  loadProfile: loadProfile,
  saveProfile: saveProfile,
  learnFromMessage: learnFromMessage,
  buildProfileContext: buildProfileContext,
  getPersonalizedGreeting: getPersonalizedGreeting,
  runIntegrityCheck: runIntegrityCheck,
  getDatabaseHealth: getDatabaseHealth,
  createBackup: () => createAtomicBackup("manual"),
  flushBackup: flushBackup,
  shutdownDatabase: shutdownDatabase,
  markDatabaseDirty: markDatabaseDirty,
  runDatabaseMaintenance: runDatabaseMaintenance,
  vacuumDatabase: vacuumDatabase,
  pruneAntideleteData: pruneAntideleteData,
  processRemoteSyncQueue: processRemoteSyncQueue,
  getRemoteSyncQueueStats: getRemoteSyncQueueStats,
  getRemoteAuthMirrorStatus: getRemoteAuthMirrorStatus,
  scheduleRemoteAuthMirror: scheduleRemoteAuthMirror,
  flushRemoteAuthMirror: flushRemoteAuthMirror,
  mirrorRemoteAuthState: mirrorRemoteAuthState,
  restoreRemoteAuthState: restoreRemoteAuthState,
  clearRemoteAuthState: clearRemoteAuthState,
  restoreFromPostgres: restoreFromPostgres,
  restoreFromMongo: restoreFromMongo,
  backfillRemote: backfillRemote,
  resetDatabase: resetDatabase,
  getPostgresStatus: pgAdapter.getStatus,
  getMongoStatus: mongoAdapter.getStatus,
  getBotId: pgAdapter.getBotId
};
Object.defineProperty(module.exports, "_db", {
  enumerable: true,
  get() {
    return db;
  }
});
