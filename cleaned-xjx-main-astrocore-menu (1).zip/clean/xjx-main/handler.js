const database = require("./database");
const {
  loadCommands,
  watchCommands
} = require("./utils/commandLoader");
const commandToggle = require("./utils/commandToggle");
const {
  addMessage,
  getActiveUsers,
  getInactiveUsers
} = require("./utils/groupstats");
const {
  jidDecode,
  jidEncode
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const groupMetadataCache = new Map();
const CACHE_TTL = 300000;
const botAdminCache = new Map();
const BOT_ADMIN_TTL = 120000;
let _arSettingsCache = null;
let _arSettingsExpiry = 0;
const SETTINGS_CACHE_TTL = 8000;
function getCachedArSettings() {
  if (_arSettingsCache && Date.now() < _arSettingsExpiry) {
    return _arSettingsCache;
  }
  try {
    _arSettingsCache = require("./utils/autoReact").load();
  } catch {
    _arSettingsCache = {
      enabled: false,
      mode: "bot"
    };
  }
  _arSettingsExpiry = Date.now() + SETTINGS_CACHE_TTL;
  return _arSettingsCache;
}
global.invalidateSettingsCache = () => {
  _arSettingsCache = null;
  botAdminCache.clear();
};
const voCache = new Map();
const VO_CACHE_TTL = 600000;
const getSelfJid = value1 => value1.user.id.split(":")[0] + "@s.whatsapp.net";
function cacheViewOnceMsg(value2) {
  try {
    const value3 = value2.key?.id;
    if (!value3) {
      return;
    }
    const value4 = value2.message || {};
    const value5 = !!value4.viewOnceMessageV2Extension || !!value4.viewOnceMessageV2 || !!value4.viewOnceMessage || !!value4.ephemeralMessage?.message?.viewOnceMessageV2 || !!value4.imageMessage?.viewOnce || !!value4.videoMessage?.viewOnce || !!value4.audioMessage?.viewOnce;
    if (!value5) {
      return;
    }
    voCache.set(value3, {
      msg: value2,
      expires: Date.now() + VO_CACHE_TTL
    });
    if (voCache.size % 20 === 0) {
      const value6 = Date.now();
      for (const [value7, value8] of voCache) {
        if (value8.expires < value6) {
          voCache.delete(value7);
        }
      }
    }
  } catch (error9) {}
}
async function revealVoToDM(value10, value11, value12) {
  const {
    downloadContentFromMessage: value13
  } = require("@whiskeysockets/baileys");
  const {
    createTempFilePath: value14,
    deleteTempFile: value15
  } = require("./utils/tempManager");
  const value16 = ["viewOnceMessageV2Extension", "viewOnceMessageV2", "viewOnceMessage"];
  const value17 = {
    imageMessage: "image",
    videoMessage: "video",
    audioMessage: "audio"
  };
  let value18 = value11.message || {};
  if (value18.ephemeralMessage?.message) {
    value18 = value18.ephemeralMessage.message;
  }
  let value19 = null;
  let value20 = null;
  let value21 = null;
  for (const value22 of value16) {
    const value23 = value18[value22]?.message;
    if (value23) {
      value20 = Object.keys(value23).find(value24 => value17[value24]);
      if (value20) {
        value19 = value23;
        value21 = value17[value20];
        break;
      }
    }
  }
  if (!value19) {
    for (const [value25, value26] of Object.entries(value17)) {
      if (value18[value25]?.viewOnce) {
        value19 = {
          [value25]: {
            ...value18[value25],
            viewOnce: false
          }
        };
        value20 = value25;
        value21 = value26;
        break;
      }
    }
  }
  if (!value19 || !value20) {
    return false;
  }
  let value27 = null;
  try {
    value27 = value14("vvo", value20 === "imageMessage" ? "jpg" : "mp4");
    const value28 = require("fs").createWriteStream(value27);
    const value29 = await value13(value19[value20], value21);
    await new Promise((value30, value31) => {
      value29.pipe(value28);
      value28.on("finish", value30);
      value28.on("error", value31);
      value29.on("error", value31);
    });
    const value32 = value19[value20]?.caption || "";
    if (value20 === "imageMessage") {
      await value10.sendMessage(value12, {
        image: {
          url: value27
        },
        caption: value32 || "🖼️ *ViewOnce Image*"
      });
    } else if (value20 === "videoMessage") {
      await value10.sendMessage(value12, {
        video: {
          url: value27
        },
        caption: value32 || "🎬 *ViewOnce Video*",
        mimetype: "video/mp4"
      });
    } else {
      await value10.sendMessage(value12, {
        audio: {
          url: value27
        },
        mimetype: value19[value20]?.mimetype || "audio/mp4",
        ptt: false
      });
    }
    return true;
  } finally {
    if (value27) {
      value15(value27);
    }
  }
}
const commands = loadCommands();
watchCommands(value33 => {
  commands.clear();
  for (const [value34, value35] of value33) {
    commands.set(value34, value35);
  }
  if (typeof global.invalidateSettingsCache === "function") {
    global.invalidateSettingsCache();
  }
});
const getMessageContent = value36 => {
  if (!value36 || !value36.message) {
    return null;
  }
  let value37 = value36.message;
  if (value37.ephemeralMessage) {
    value37 = value37.ephemeralMessage.message;
  }
  if (value37.viewOnceMessageV2Extension) {
    value37 = value37.viewOnceMessageV2Extension.message;
  }
  if (value37.viewOnceMessageV2) {
    value37 = value37.viewOnceMessageV2.message;
  }
  if (value37.viewOnceMessage) {
    value37 = value37.viewOnceMessage.message;
  }
  if (value37.documentWithCaptionMessage) {
    value37 = value37.documentWithCaptionMessage.message;
  }
  return value37;
};
const getCachedGroupMetadata = async (value38, value39) => {
  try {
    if (!value39 || !value39.endsWith("@g.us")) {
      return null;
    }
    const value40 = groupMetadataCache.get(value39);
    if (value40 && Date.now() - value40.timestamp < CACHE_TTL) {
      return value40.data;
    }
    const value41 = await value38.groupMetadata(value39);
    groupMetadataCache.set(value39, {
      data: value41,
      timestamp: Date.now()
    });
    return value41;
  } catch (error42) {
    if (error42.message && (error42.message.includes("forbidden") || error42.message.includes("403") || error42.statusCode === 403 || error42.output?.statusCode === 403 || error42.data === 403)) {
      groupMetadataCache.set(value39, {
        data: null,
        timestamp: Date.now()
      });
      return null;
    }
    if (error42.message && error42.message.includes("rate-overlimit")) {
      const value43 = groupMetadataCache.get(value39);
      if (value43) {
        return value43.data;
      }
      return null;
    }
    const value44 = groupMetadataCache.get(value39);
    if (value44) {
      return value44.data;
    }
    return null;
  }
};
const getLiveGroupMetadata = async (value45, value46) => {
  try {
    const value47 = await value45.groupMetadata(value46);
    groupMetadataCache.set(value46, {
      data: value47,
      timestamp: Date.now()
    });
    return value47;
  } catch (error48) {
    const value49 = groupMetadataCache.get(value46);
    if (value49) {
      return value49.data;
    }
    return null;
  }
};
const getGroupMetadata = getCachedGroupMetadata;
const isOwner = value50 => {
  if (!value50) {
    return false;
  }
  const value51 = database.getOwners();
  if (!value51.length) {
    return false;
  }
  const value52 = value50.split("@")[0].split(":")[0];
  if (value51.some(value53 => String(value53).replace(/\D/g, "") === value52)) {
    return true;
  }
  try {
    const value54 = normalizeJidWithLid(value50);
    const value55 = normalizeJid(value54);
    if (value55 && value51.some(value56 => {
      const value57 = normalizeJidWithLid(String(value56).includes("@") ? String(value56) : value56 + "@s.whatsapp.net");
      const value58 = normalizeJid(value57);
      return value58 === value55;
    })) {
      return true;
    }
  } catch (error59) {}
  return false;
};
const isSudo = value60 => {
  if (!value60) {
    return false;
  }
  const value61 = value60.split("@")[0].split(":")[0];
  return database.isModerator(value61);
};
const isMod = isSudo;
const lidMappingCache = new Map();
setInterval(() => {
  const value62 = Date.now();
  for (const [value63, value64] of groupMetadataCache) {
    if (value62 - value64.timestamp > 600000) {
      groupMetadataCache.delete(value63);
    }
  }
  lidMappingCache.clear();
}, 600000);
const normalizeJid = value65 => {
  if (!value65) {
    return null;
  }
  if (typeof value65 !== "string") {
    return null;
  }
  if (value65.includes(":")) {
    return value65.split(":")[0];
  }
  if (value65.includes("@")) {
    return value65.split("@")[0];
  }
  return value65;
};
const getLidMappingValue = (value66, value67) => {
  if (!value66) {
    return null;
  }
  const value68 = String(value66).split(":")[0].split("@")[0];
  const value69 = value67 + ":" + value68;
  if (lidMappingCache.has(value69)) {
    return lidMappingCache.get(value69);
  }
  try {
    const value70 = database.getLidMap(value67, value68) || null;
    lidMappingCache.set(value69, value70);
    return value70;
  } catch (error71) {
    return null;
  }
};
function isLidJid(value72) {
  try {
    const value73 = jidDecode(String(value72 || ""))?.server;
    return value73 === "lid" || value73 === "hosted.lid";
  } catch (error74) {
    return false;
  }
}
function rememberLidPair(value75, value76) {
  const value77 = String(value75 || "").split(":")[0].split("@")[0];
  const value78 = String(value76 || "").split(":")[0].split("@")[0];
  if (!value77 || !value78 || value77 === value78) {
    return;
  }
  try {
    if (getLidMappingValue(value77, "lidToPn") !== value78) {
      database.saveLidMap("lidToPn", value77, value78);
      lidMappingCache.set("lidToPn:" + value77, value78);
    }
    if (getLidMappingValue(value78, "pnToLid") !== value77) {
      database.saveLidMap("pnToLid", value78, value77);
      lidMappingCache.set("pnToLid:" + value78, value77);
    }
  } catch (error79) {}
}
function rememberParticipantLidMap(value80) {
  if (!value80 || typeof value80 === "string") {
    return;
  }
  const value81 = [value80.lid, value80.id, value80.userJid].filter(Boolean);
  const value82 = value81.find(isLidJid);
  const value83 = value80.phoneNumber || value80.pn || value81.find(value84 => !isLidJid(value84));
  if (value82 && value83) {
    rememberLidPair(value82, value83);
  }
}
const normalizeJidWithLid = value85 => {
  if (!value85) {
    return value85;
  }
  try {
    const value86 = jidDecode(value85);
    if (!value86?.user) {
      return value85.split(":")[0].split("@")[0] + "@s.whatsapp.net";
    }
    let value87 = value86.user;
    let value88 = value86.server === "c.us" ? "s.whatsapp.net" : value86.server;
    const value89 = () => {
      const value90 = getLidMappingValue(value87, "lidToPn");
      if (value90) {
        value87 = value90;
        value88 = value88 === "hosted.lid" ? "hosted" : "s.whatsapp.net";
        return true;
      }
      return false;
    };
    if (value88 === "lid" || value88 === "hosted.lid") {
      value89();
    } else if (value88 === "s.whatsapp.net" || value88 === "hosted") {
      value89();
    }
    if (value88 === "hosted") {
      return jidEncode(value87, "hosted");
    }
    return jidEncode(value87, "s.whatsapp.net");
  } catch (error91) {
    return value85;
  }
};
const buildComparableIds = value92 => {
  if (!value92) {
    return [];
  }
  try {
    const value93 = jidDecode(value92);
    if (!value93?.user) {
      return [normalizeJidWithLid(value92)].filter(Boolean);
    }
    const value94 = new Set();
    const value95 = value93.server === "c.us" ? "s.whatsapp.net" : value93.server;
    value94.add(jidEncode(value93.user, value95));
    const value96 = value95 === "s.whatsapp.net" || value95 === "hosted";
    const value97 = value95 === "lid" || value95 === "hosted.lid";
    if (value96) {
      const value98 = getLidMappingValue(value93.user, "pnToLid");
      if (value98) {
        const value99 = value95 === "hosted" ? "hosted.lid" : "lid";
        value94.add(jidEncode(value98, value99));
      }
    } else if (value97) {
      const value100 = getLidMappingValue(value93.user, "lidToPn");
      if (value100) {
        const value101 = value95 === "hosted.lid" ? "hosted" : "s.whatsapp.net";
        value94.add(jidEncode(value100, value101));
      }
    }
    return Array.from(value94);
  } catch (error102) {
    return [value92];
  }
};
const findParticipant = (value103 = [], value104) => {
  const value105 = (Array.isArray(value104) ? value104 : [value104]).filter(Boolean).flatMap(value106 => buildComparableIds(value106));
  if (!value105.length) {
    return null;
  }
  return value103.find(value107 => {
    if (!value107) {
      return false;
    }
    rememberParticipantLidMap(value107);
    const value108 = [value107.id, value107.lid, value107.userJid].filter(Boolean).flatMap(value109 => buildComparableIds(value109));
    return value108.some(value110 => value105.includes(value110));
  }) || null;
};
const isAdmin = async (value111, value112, value113, value114 = null) => {
  if (!value112) {
    return false;
  }
  if (!value113 || !value113.endsWith("@g.us")) {
    return false;
  }
  let value115 = value114;
  if (!value115 || !value115.participants) {
    if (value113) {
      value115 = await getLiveGroupMetadata(value111, value113);
    } else {
      return false;
    }
  }
  if (!value115 || !value115.participants) {
    return false;
  }
  const value116 = findParticipant(value115.participants, value112);
  if (!value116) {
    return false;
  }
  return value116.admin === "admin" || value116.admin === "superadmin";
};
const isBotAdmin = async (value117, value118, value119 = null) => {
  if (!value117.user || !value118) {
    return false;
  }
  if (!value118.endsWith("@g.us")) {
    return false;
  }
  const value120 = botAdminCache.get(value118);
  if (value120 && Date.now() - value120.ts < BOT_ADMIN_TTL) {
    return value120.isAdmin;
  }
  try {
    const value121 = value117.user.id;
    const value122 = value117.user.lid;
    if (!value121) {
      return false;
    }
    const value123 = [value121];
    if (value122) {
      value123.push(value122);
    }
    const value124 = await getLiveGroupMetadata(value117, value118);
    if (!value124 || !value124.participants) {
      return false;
    }
    const value125 = findParticipant(value124.participants, value123);
    const value126 = !!value125 && (value125.admin === "admin" || value125.admin === "superadmin");
    botAdminCache.set(value118, {
      isAdmin: value126,
      ts: Date.now()
    });
    return value126;
  } catch {
    return false;
  }
};
const isUrl = value127 => {
  const value128 = /(https?:\/\/[^\s]+)/gi;
  return value128.test(value127);
};
const hasGroupLink = value129 => {
  const value130 = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;
  return value130.test(value129);
};
function extractButtonId(value131, value132) {
  const value133 = value131 || value132?.message || {};
  const value134 = [value133.buttonsResponseMessage?.selectedButtonId, value133.templateButtonReplyMessage?.selectedId, value133.listResponseMessage?.singleSelectReply?.selectedRowId, value133.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson, value133.interactiveResponseMessage?.body?.text, value132?.message?.buttonsResponseMessage?.selectedButtonId, value132?.message?.templateButtonReplyMessage?.selectedId, value132?.message?.listResponseMessage?.singleSelectReply?.selectedRowId, value132?.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson].filter(Boolean);
  for (const value135 of value134) {
    if (typeof value135 !== "string") {
      continue;
    }
    const value136 = value135.trim();
    if (!value136) {
      continue;
    }
    if (value136.startsWith("{")) {
      try {
        const value137 = JSON.parse(value136);
        const value138 = value137.id || value137.selectedId || value137.cmd || value137.command || value137.name;
        if (value138) {
          return String(value138);
        }
      } catch (error139) {}
      continue;
    }
    return value136;
  }
  return null;
}
const isSystemJid = value140 => {
  if (!value140) {
    return true;
  }
  return value140.includes("@broadcast") || value140.includes("status.broadcast") || value140.includes("@newsletter") || value140.includes("@newsletter.");
};
const handleMessage = async (value141, value142) => {
  try {
    if (!value142.message) {
      return;
    }
    try {
      const value143 = commands.get("antidelete");
      if (value143?.storeMessage) {
        value143.storeMessage(value142);
      }
    } catch (error144) {}
    try {
      const value145 = commands.get("antiedit");
      if (value145?.storeMessage) {
        value145.storeMessage(value142);
      }
    } catch (error146) {}
    try {
      cacheViewOnceMsg(value142);
    } catch (error147) {}
    if (value142.message?.reactionMessage) {
      try {
        const value148 = value142.message.reactionMessage;
        const value149 = value142.key.fromMe ? getSelfJid(value141) : value142.key.participant || value142.key.remoteJid;
        const value150 = value142.key.remoteJid;
        if (value148.text && (value142.key.fromMe || isOwner(value149) || isSudo(value149))) {
          const value151 = value148.key?.id;
          const value152 = value151 ? voCache.get(value151) : null;
          if (value152 && value152.expires > Date.now()) {
            const value153 = getSelfJid(value141);
            const value154 = await revealVoToDM(value141, value152.msg, value153);
            if (value154) {
              await value141.sendMessage(value150, {
                react: {
                  text: "✅",
                  key: value142.key
                }
              });
            }
          }
        }
      } catch (error155) {
        console.error("[VO React]", error155.message);
      }
      return;
    }
    const value156 = value142.key.remoteJid;
    const value157 = !value156.endsWith("@g.us") && value156.endsWith("@lid") && value142.key.remoteJidAlt ? value142.key.remoteJidAlt : value156;
    if (value156 === "status@broadcast") {
      try {
        const value158 = commands.get("autodownloadstatus");
        if (value158?.handleAutoDownloadStatus) {
          await value158.handleAutoDownloadStatus(value141, value142.key, value142.message);
        }
      } catch (error159) {
        console.error("[AutoDL-Status hook]", error159.message);
      }
      return;
    }
    if (isSystemJid(value156)) {
      return;
    }
    const value160 = getMessageContent(value142);
    let value161 = [];
    if (value160) {
      const value162 = Object.keys(value160);
      const value163 = ["protocolMessage", "senderKeyDistributionMessage", "messageContextInfo"];
      value161 = value162.filter(value164 => !value163.includes(value164));
    }
    const value165 = value161[0];
    const value166 = value142.key.fromMe ? getSelfJid(value141) : value142.key.participant || value142.key.remoteJid;
    const value167 = value157.endsWith("@g.us");
    const value168 = !value167 && isLidJid(value166) && value142.key.remoteJidAlt ? value142.key.remoteJidAlt : value166;
    if (!value167 && isLidJid(value166) && value142.key.remoteJidAlt) {
      rememberLidPair(value166, value142.key.remoteJidAlt);
    }
    const value169 = value167;
    if (!value142.key.fromMe) {
      try {
        const {
          getModeFor: value170
        } = require("./utils/presenceSettings");
        const value171 = value170(value157);
        if (value171 === "recordtype") {
          value141.sendPresenceUpdate("recording", value157).catch(() => {});
          setTimeout(() => {
            value141.sendPresenceUpdate("composing", value157).catch(() => {});
          }, 1500);
        } else if (value171 === "recording") {
          value141.sendPresenceUpdate("recording", value157).catch(() => {});
        } else if (value171 === "typing") {
          value141.sendPresenceUpdate("composing", value157).catch(() => {});
        }
      } catch (error172) {}
    }
    const value173 = value169 ? await getGroupMetadata(value141, value157) : null;
    if (value169 && !value142.key.fromMe && value168) {
      try {
        if (database.isUserMuted(value157, value168)) {
          await value141.sendMessage(value157, {
            delete: value142.key
          });
          return;
        }
      } catch (error174) {}
    }
    if (value169 && !value142.key.fromMe && database.isAntiAllEnabled(value157)) {
      const value175 = await isAdmin(value141, value168, value157, value173);
      if (!value175 && !isOwner(value168)) {
        if (await isBotAdmin(value141, value157, value173)) {
          await value141.sendMessage(value157, {
            delete: value142.key
          });
          return;
        }
      }
    }
    if (value169) {
      const value176 = commands.get("antispam");
      const value177 = commands.get("antiviewonce");
      const value178 = commands.get("antibot");
      const value179 = commands.get("antiforward");
      const value180 = commands.get("antitagadmins");
      await Promise.allSettled([handleAntigroupmention(value141, value142, value173), handleAntigroupstatus(value141, value142, value173), handleAntiMedia(value141, value142, value173), handleAntilink(value141, value142, value173, value157, value168), value176?.handleAntispam ? value176.handleAntispam(value141, value142, value173) : Promise.resolve(), value177?.handleAntiviewonce ? value177.handleAntiviewonce(value141, value142) : Promise.resolve(), value178?.handleMessage ? value178.handleMessage(value141, value142, value173) : Promise.resolve(), value179?.handleAntiforward ? value179.handleAntiforward(value141, value142, value173) : Promise.resolve(), value180?.handleMessage ? value180.handleMessage(value141, value142, value173, value168, value157, isOwner(value168)) : Promise.resolve(), handleAntibadword(value141, value142, value173), handleAntibug(value141, value142, value173, value169, value168, value157)]);
    } else {
      try {
        await handleAntibug(value141, value142, null, false, value168, value157);
      } catch (error181) {}
    }
    if (value169) {
      addMessage(value157, value168);
    }
    if (!value160 || value161.length === 0) {
      return;
    }
    const value182 = extractButtonId(value160, value142);
    if (value182) {
      const value183 = async () => ({
        from: value157,
        sender: value168,
        isGroup: value169,
        groupMetadata: value173,
        isOwner: isOwner(value168),
        isAdmin: await isAdmin(value141, value168, value157, value173),
        isBotAdmin: await isBotAdmin(value141, value157, value173),
        isMod: isMod(value168),
        isSudo: isMod(value168),
        prefix: database.getBotSetting("prefix") || ".",
        command: "",
        reply: value184 => value141.sendMessage(value157, {
          text: value184
        }, {
          quoted: value142
        }),
        react: value185 => value141.sendMessage(value157, {
          react: {
            text: value185,
            key: value142.key
          }
        })
      });
      if (value182 === "btn_menu") {
        const value186 = await value183();
        const value187 = commands.get("menu");
        if (value187) {
          await value187.execute(value141, value142, [], value186);
        }
        return;
      } else if (value182 === "menu_repo") {
        const value188 = database.SOCIAL?.github || "https://github.com/Vinpink2/June-Ultra";
        await value141.sendMessage(value157, {
          text: "💻 *Bot Repository*\n" + value188
        }, {
          quoted: value142
        });
        return;
      } else if (value182 === "menu_yt") {
        const value189 = database.SOCIAL?.youtube || "http://youtube.com/@suprem_e_lord";
        await value141.sendMessage(value157, {
          text: "📺 *YouTube Channel*\n" + value189
        }, {
          quoted: value142
        });
        return;
      } else if (value182 === "btn_ping") {
        const value190 = await value183();
        const value191 = commands.get("ping");
        if (value191) {
          await value191.execute(value141, value142, [], value190);
        }
        return;
      } else if (value182 === "btn_help") {
        const value192 = await value183();
        const value193 = commands.get("list");
        if (value193) {
          await value193.execute(value141, value142, [], value192);
        }
        return;
      }
      const value194 = database.getBotSetting("prefix") || ".";
      let value195 = String(value182).replace(/_(\d{8,})$/, "");
      if (value195 && value195.startsWith(value194)) {
        const value196 = value195.slice(value194.length).trim().split(/\s+/);
        const value197 = (value196[0] || "").toLowerCase();
        const value198 = value196.slice(1);
        const value199 = commands.get(value197);
        if (value199) {
          const value200 = await value183();
          value200.command = value197;
          value200.prefix = value194;
          value200.isOwner = value142.key.fromMe || value200.isOwner;
          value200.isSudo = value200.isOwner || value200.isSudo;
          value200.isMod = value200.isSudo;
          if (!value200.isOwner && !value200.isSudo && commandToggle.isDisabled(value199.name)) {
            await value141.sendMessage(value157, {
              text: "🚫 The command *" + value199.name + "* is currently disabled."
            }, {
              quoted: value142
            });
            return;
          }
          if (value199.ownerOnly && !value200.isOwner && !value200.isSudo) {
            await value141.sendMessage(value157, {
              text: database.MESSAGES.ownerOnly
            }, {
              quoted: value142
            });
            return;
          }
          if (value199.adminOnly && !value200.isAdmin && !value200.isOwner) {
            await value141.sendMessage(value157, {
              text: database.MESSAGES.adminOnly
            }, {
              quoted: value142
            });
            return;
          }
          await value199.execute(value141, value142, value198, value200);
        }
        return;
      }
    }
    let value201 = "";
    if (value160.conversation) {
      value201 = value160.conversation;
    } else if (value160.extendedTextMessage) {
      value201 = value160.extendedTextMessage.text || "";
    } else if (value160.imageMessage) {
      value201 = value160.imageMessage.caption || "";
    } else if (value160.videoMessage) {
      value201 = value160.videoMessage.caption || "";
    }
    value201 = (value201 || "").trim();
    if (value169) {
      const value202 = database.getGroupSettings(value157);
      if (value202.antitag && !value142.key.fromMe) {
        const value203 = value160.extendedTextMessage?.contextInfo;
        const value204 = value203?.mentionedJid || [];
        const value205 = value201 || value160.imageMessage?.caption || value160.videoMessage?.caption || "";
        const value206 = value205.match(/@[\d+\s\-()~.]+/g) || [];
        const value207 = value205.match(/@\d{10,}/g) || [];
        const value208 = new Set();
        value207.forEach(value209 => {
          const value210 = value209.match(/@(\d+)/);
          if (value210) {
            value208.add(value210[1]);
          }
        });
        const value211 = value204.length;
        const value212 = value208.size;
        const value213 = Math.max(value211, value212);
        if (value213 >= 3) {
          try {
            const value214 = value173.participants || [];
            const value215 = Math.max(3, Math.ceil(value214.length * 0.5));
            const value216 = value212 >= 10 || value212 >= 5 && value212 >= value215;
            if (value213 >= value215 || value216) {
              const value217 = await isAdmin(value141, value168, value157, value173);
              const value218 = isOwner(value168);
              if (!value217 && !value218) {
                const value219 = (value202.antitagAction || "delete").toLowerCase();
                if (value219 === "delete") {
                  try {
                    await value141.sendMessage(value157, {
                      delete: value142.key
                    });
                    await value141.sendMessage(value157, {
                      text: "⚠️ *Tagall Detected!*",
                      mentions: [value168]
                    }, {
                      quoted: value142
                    });
                  } catch (error220) {
                    console.error("Failed to delete tagall message:", error220);
                  }
                } else if (value219 === "kick") {
                  try {
                    await value141.sendMessage(value157, {
                      delete: value142.key
                    });
                  } catch (error221) {
                    console.error("Failed to delete tagall message:", error221);
                  }
                  const value222 = await isBotAdmin(value141, value157, value173);
                  if (value222) {
                    try {
                      await value141.groupParticipantsUpdate(value157, [value168], "remove");
                    } catch (error223) {
                      console.error("Failed to kick for antitag:", error223);
                    }
                    const value224 = ["@" + value168.split("@")[0]];
                    await value141.sendMessage(value157, {
                      text: "🚫 *Antitag Detected!*\n\n" + value224.join(", ") + " has been kicked for tagging all members.",
                      mentions: [value168]
                    }, {
                      quoted: value142
                    });
                  }
                }
                return;
              }
            }
          } catch (error225) {
            console.error("Error during anti-tag enforcement:", error225);
          }
        }
      }
    }
    if (value169) {
      const value226 = database.getGroupSettings(value157);
      if (value226.autosticker) {
        const value227 = value160?.imageMessage || value160?.videoMessage;
        if (value227) {
          if (!value201.startsWith(database.getBotSetting("prefix"))) {
            try {
              const value228 = commands.get("sticker");
              if (value228) {
                await value228.execute(value141, value142, [], {
                  from: value157,
                  sender: value168,
                  isGroup: value169,
                  groupMetadata: value173,
                  isOwner: isOwner(value168),
                  isAdmin: await isAdmin(value141, value168, value157, value173),
                  isBotAdmin: await isBotAdmin(value141, value157, value173),
                  isMod: isMod(value168),
                  reply: value229 => value141.sendMessage(value157, {
                    text: value229
                  }, {
                    quoted: value142
                  }),
                  react: value230 => value141.sendMessage(value157, {
                    react: {
                      text: value230,
                      key: value142.key
                    }
                  })
                });
                return;
              }
            } catch (error231) {
              console.error("[AutoSticker Error]:", error231);
            }
          }
        }
      }
    }
    try {
      const value232 = require("./commands/fun/bomb");
      if (value232.gameState && value232.gameState.has(value168)) {
        const value233 = commands.get("bomb");
        if (value233 && value233.execute) {
          await value233.execute(value141, value142, [], {
            from: value157,
            sender: value168,
            isGroup: value169,
            groupMetadata: value173,
            isOwner: isOwner(value168),
            isAdmin: await isAdmin(value141, value168, value157, value173),
            isBotAdmin: await isBotAdmin(value141, value157, value173),
            isMod: isMod(value168),
            reply: value234 => value141.sendMessage(value157, {
              text: value234
            }, {
              quoted: value142
            }),
            react: value235 => value141.sendMessage(value157, {
              react: {
                text: value235,
                key: value142.key
              }
            })
          });
          return;
        }
      }
    } catch (error236) {}
    try {
      const value237 = require("./commands/fun/tictactoe");
      if (value237.handleTicTacToeMove) {
        const value238 = Object.values(value237.games || {}).some(value239 => value239.id.startsWith("tictactoe") && [value239.game.playerX, value239.game.playerO].includes(value168) && value239.state === "PLAYING");
        if (value238) {
          const value240 = await value237.handleTicTacToeMove(value141, value142, {
            from: value157,
            sender: value168,
            isGroup: value169,
            groupMetadata: value173,
            isOwner: isOwner(value168),
            isAdmin: await isAdmin(value141, value168, value157, value173),
            isBotAdmin: await isBotAdmin(value141, value157, value173),
            isMod: isMod(value168),
            reply: value241 => value141.sendMessage(value157, {
              text: value241
            }, {
              quoted: value142
            }),
            react: value242 => value141.sendMessage(value157, {
              react: {
                text: value242,
                key: value142.key
              }
            })
          });
          if (value240) {
            return;
          }
        }
      }
    } catch (error243) {}
    try {
      const value244 = require("./commands/fun/ttt2");
      if (value244.handleTtt2Move) {
        const value245 = Object.values(value244.games || {}).some(value246 => value246.id.startsWith("ttt2") && [value246.game.playerX, value246.game.playerO].includes(value168) && value246.state === "PLAYING");
        if (value245) {
          const value247 = await value244.handleTtt2Move(value141, value142, {
            from: value157,
            sender: value168,
            isGroup: value169,
            groupMetadata: value173,
            isOwner: isOwner(value168),
            isAdmin: await isAdmin(value141, value168, value157, value173),
            isBotAdmin: await isBotAdmin(value141, value168, value157, value173),
            isMod: isMod(value168),
            reply: value248 => value141.sendMessage(value157, {
              text: value248
            }, {
              quoted: value142
            }),
            react: value249 => value141.sendMessage(value157, {
              react: {
                text: value249,
                key: value142.key
              }
            })
          });
          if (value247) {
            return;
          }
        }
      }
    } catch (error250) {}
    if (/^\d+$/.test(value201.trim())) {
      const value251 = value142.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const value252 = value251?.conversation || value251?.extendedTextMessage?.text || "";
      if (value252.includes("Fancy Text Styles") || value252.includes("Fancy Styles for:")) {
        const value253 = commands.get("fancy");
        if (value253) {
          return value253.execute(value141, value142, [value201.trim()], {
            from: value157,
            sender: value168,
            reply: value254 => value141.sendMessage(value157, {
              text: value254
            }, {
              quoted: value142
            }),
            react: value255 => value141.sendMessage(value157, {
              react: {
                text: value255,
                key: value142.key
              }
            })
          });
        }
      }
    }
    if (/^\d+$/.test(value201.trim())) {
      const value256 = value142.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const value257 = value256?.conversation || value256?.extendedTextMessage?.text || "";
      if (value257.includes("📋") && value257.includes("Group List")) {
        const value258 = commands.get("mygroups");
        if (value258) {
          return value258.execute(value141, value142, [value201.trim()], {
            from: value157,
            sender: value168,
            command: "mygroups",
            prefix: database.getBotSetting("prefix"),
            reply: value259 => value141.sendMessage(value157, {
              text: value259
            }, {
              quoted: value142
            }),
            react: value260 => value141.sendMessage(value157, {
              react: {
                text: value260,
                key: value142.key
              }
            })
          });
        }
      }
    }
    {
      const value261 = !!value142.message?.stickerMessage;
      const value262 = value142.message?.extendedTextMessage?.text || value142.message?.conversation || "";
      const value263 = value262.trim();
      const value264 = value263.length > 0 && value263.length <= 16 && /^\p{Emoji}/u.test(value263) && !/^[a-zA-Z0-9./#]/.test(value263);
      if ((value261 || value264) && (value142.key.fromMe || isOwner(value168) || isSudo(value168))) {
        const value265 = value142.message?.stickerMessage?.contextInfo || value142.message?.extendedTextMessage?.contextInfo || value142.message?.imageMessage?.contextInfo || value142.message?.videoMessage?.contextInfo;
        const value266 = value265?.quotedMessage;
        if (value266) {
          const value267 = !!value266.viewOnceMessageV2Extension || !!value266.viewOnceMessageV2 || !!value266.viewOnceMessage || !!value266?.imageMessage?.viewOnce || !!value266?.videoMessage?.viewOnce || !!value266?.audioMessage?.viewOnce;
          if (value267) {
            try {
              const value268 = commands.get("vv");
              if (value268?.execute) {
                await value268.execute(value141, value142, [], {
                  from: value157,
                  sender: value168,
                  isOwner: true,
                  command: "vv",
                  reply: value269 => value141.sendMessage(value157, {
                    text: value269
                  }, {
                    quoted: value142
                  }),
                  react: value270 => value141.sendMessage(value157, {
                    react: {
                      text: value270,
                      key: value142.key
                    }
                  })
                });
              }
            } catch (error271) {}
            return;
          }
          if (value265?.remoteJid === "status@broadcast") {
            try {
              const value272 = commands.get("save");
              if (value272?.execute) {
                await value272.execute(value141, value142, [], {
                  from: value157,
                  sender: value168,
                  isOwner: value142.key.fromMe || isOwner(value168) || isSudo(value168),
                  command: "save",
                  forwardToSelf: true,
                  triggerLabel: value261 ? "🎭 *Trigger:* Sticker" : "💌 *Emoji:* " + value263,
                  reply: value273 => value141.sendMessage(value157, {
                    text: value273
                  }, {
                    quoted: value142
                  }),
                  react: value274 => value141.sendMessage(value157, {
                    react: {
                      text: value274,
                      key: value142.key
                    }
                  })
                });
              }
            } catch (error275) {}
            return;
          }
        }
      }
    }
    try {
      require("./utils/consoleTheme").printMessage(value142, value160, value141, {
        groupName: value173?.subject || null
      });
    } catch (error276) {}
    const value277 = database.getBotSetting("prefix") ?? ".";
    const value278 = value277 === "" || value201.startsWith(value277);
    let value279 = [];
    let value280 = null;
    let value281 = "";
    if (value278) {
      const value282 = value277 === "" ? value201 : value201.slice(value277.length);
      value279 = value282.trim().split(/\s+/);
      value281 = (value279.shift() || "").toLowerCase();
      value280 = commands.get(value281);
    }
    try {
      const value283 = getCachedArSettings();
      const value284 = value283.mode === "all" || value283.mode === "bot" && Boolean(value280);
      const {
        canTargetChat: value285
      } = require("./utils/autoReact");
      if (value283.enabled && !value142.key.fromMe && value284 && value285(value283.target, value169)) {
        const {
          reactions: value286
        } = require("./utils/emojis");
        const value287 = value283.randomMode && Array.isArray(value286) && value286.length ? value286[Math.floor(Math.random() * value286.length)] : value283.fixedEmoji;
        if (value287) {
          await value141.sendMessage(value157, {
            react: {
              text: value287,
              key: value142.key
            }
          });
        }
      }
    } catch (error288) {
      console.error("[AutoReact Error]", error288.message);
    }
    if (!value280) {
      const value289 = !!value142.message?.imageMessage || !!value142.message?.stickerMessage || !!value142.message?.ephemeralMessage?.message?.imageMessage || !!value142.message?.ephemeralMessage?.message?.stickerMessage || !!value142.message?.viewOnceMessageV2?.message?.imageMessage || !!value142.message?.viewOnceMessage?.message?.imageMessage;
      if ((value201.trim() || value289) && !value142.key.fromMe) {
        try {
          const value290 = commands.get("chatbot");
          if (value290?.handleAutoReply) {
            await value290.handleAutoReply(value141, value142, {
              from: value157,
              isGroup: value169,
              commands: commands
            });
          }
        } catch (error291) {}
      }
      return;
    }
    let value292 = value168;
    try {
      const {
        jidDecode: value293
      } = require("@whiskeysockets/baileys");
      const {
        getLidMappingValue: value294
      } = require("./utils/jidHelper");
      const value295 = value168 ? value293(value168) : null;
      const value296 = value295?.server;
      const value297 = value296 === "lid" || value296 === "hosted.lid";
      if (value297 && value295?.user) {
        if (value169 && value173?.participants) {
          const value298 = value173.participants.find(value299 => {
            if (!value299) {
              return false;
            }
            const value300 = typeof value299 === "string" ? value299 : value299.id || value299.jid || "";
            const value301 = typeof value299 === "string" ? "" : value299.lid || "";
            return value300 === value168 || value301 === value168;
          });
          if (value298 && typeof value298 === "object") {
            rememberParticipantLidMap(value298);
            const value302 = value298.phoneNumber || value298.pn;
            if (value302) {
              value292 = value302.includes("@") ? value302 : value302 + "@s.whatsapp.net";
            }
          }
          if (value292 === value168) {
            const value303 = value294(value295.user, "lidToPn");
            if (value303) {
              value292 = value303 + "@s.whatsapp.net";
            }
          }
        } else if (!value169) {
          try {
            const {
              resolvePhone: value304
            } = require("./utils/jidHelper");
            const value305 = await value304(value141, value168);
            if (value305) {
              value292 = value305 + "@s.whatsapp.net";
            }
          } catch (error306) {
            const value307 = value294(value295.user, "lidToPn");
            if (value307) {
              value292 = value307 + "@s.whatsapp.net";
            }
          }
        }
      }
    } catch (error308) {}
    const value309 = value142.key.fromMe || isOwner(value292);
    const value310 = value309 || isSudo(value292);
    if (database.getBotSetting("selfMode") && !value142.key.fromMe) {
      return;
    }
    {
      const {
        getMode: value311
      } = require("./utils/botMode");
      const value312 = value311();
      if ((value312 === "private" || value312 === "silent") && !value310) {
        return;
      }
      if ((value312 === "group" || value312 === "groups") && !value169 && !value310) {
        return;
      }
      if ((value312 === "pm" || value312 === "dms") && value169 && !value310) {
        return;
      }
    }
    if (value280.ownerOnly && !value309 && !value310) {
      return value141.sendMessage(value157, {
        text: database.MESSAGES.ownerOnly
      }, {
        quoted: value142
      });
    }
    if (value280.modOnly && !value310) {
      return value141.sendMessage(value157, {
        text: "🔒 This command is only for moderators!"
      }, {
        quoted: value142
      });
    }
    if (value280.groupOnly && !value169) {
      return value141.sendMessage(value157, {
        text: database.MESSAGES.groupOnly
      }, {
        quoted: value142
      });
    }
    if (value280.privateOnly && value169) {
      return value141.sendMessage(value157, {
        text: database.MESSAGES.privateOnly
      }, {
        quoted: value142
      });
    }
    if (value280.adminOnly && !(await isAdmin(value141, value168, value157, value173)) && !value309) {
      return value141.sendMessage(value157, {
        text: database.MESSAGES.adminOnly
      }, {
        quoted: value142
      });
    }
    if (value280.botAdminNeeded) {
      const value313 = await isBotAdmin(value141, value157, value173);
      if (!value313) {
        return value141.sendMessage(value157, {
          text: database.MESSAGES.botAdminNeeded
        }, {
          quoted: value142
        });
      }
    }
    if (!value309 && !value310 && commandToggle.isDisabled(value280.name)) {
      return value141.sendMessage(value157, {
        text: "🚫 The command *" + value280.name + "* is currently disabled."
      }, {
        quoted: value142
      });
    }
    try {
      const {
        getModeFor: value314
      } = require("./utils/presenceSettings");
      const value315 = value314(value157);
      if (value315 === "recordtype") {
        await value141.sendPresenceUpdate("recording", value157);
        await new Promise(value316 => setTimeout(value316, 1500));
        await value141.sendPresenceUpdate("composing", value157);
        await new Promise(value317 => setTimeout(value317, 800));
      } else if (value315 === "recording") {
        await value141.sendPresenceUpdate("recording", value157);
        await new Promise(value318 => setTimeout(value318, 1000));
      } else if (value315 === "typing") {
        await value141.sendPresenceUpdate("composing", value157);
        await new Promise(value319 => setTimeout(value319, 800));
      }
    } catch (error320) {
      console.error("[PRESENCE] error:", error320.message);
    }
    const value321 = value168.split("@")[0].split(":")[0];
    require("./utils/consoleTheme").cmdLine(value281, value321, value309 ? "OWNER" : value310 ? "SUDO" : "USER");
    const {
      applyFont: value322
    } = require("./utils/fontConverter");
    await value280.execute(value141, value142, value279, {
      from: value157,
      sender: value168,
      isGroup: value169,
      groupMetadata: value173,
      groupName: value173?.subject || null,
      isOwner: value309,
      isAdmin: await isAdmin(value141, value168, value157, value173),
      isBotAdmin: await isBotAdmin(value141, value157, value173),
      isMod: value310,
      isSudo: value310,
      prefix: database.getBotSetting("prefix"),
      command: value281,
      reply: value323 => value141.sendMessage(value157, {
        text: value322(value323)
      }, {
        quoted: value142
      }),
      react: value324 => value141.sendMessage(value157, {
        react: {
          text: value324,
          key: value142.key
        }
      }),
      getCommandCount: () => commands.commandCount ?? commands.size,
      getAliasCount: () => commands.aliasCount ?? 0,
      getActiveUsers: (value325, value326) => getActiveUsers(value325, value326),
      getInactiveUsers: (value327, value328) => getInactiveUsers(value327, value328)
    });
  } catch (error329) {
    console.error("Error in message handler:", error329);
    if (error329.message && error329.message.includes("rate-overlimit")) {
      return;
    }
    try {
      await value141.sendMessage(value142.key.remoteJid, {
        text: database.MESSAGES.error + "\n\n" + error329.message
      }, {
        quoted: value142
      });
    } catch (error330) {
      if (!error330.message || !error330.message.includes("rate-overlimit")) {
        console.error("Error sending error message:", error330);
      }
    }
  }
};
const handleGroupUpdate = async (value331, value332) => {
  try {
    const {
      id: value333,
      participants: value334,
      action: value335,
      author: value336
    } = value332;
    if (!value333 || !value333.endsWith("@g.us")) {
      return;
    }
    if (value335 === "demote" || value335 === "promote") {
      try {
        const value337 = commands.get("antidemote");
        const value338 = commands.get("antipromote");
        let value339 = value336 || null;
        if (value339) {
          try {
            value339 = normalizeJidWithLid(value339) || value339;
          } catch (error340) {}
        }
        for (const value341 of value334) {
          let value342 = typeof value341 === "string" ? value341 : value341?.phoneNumber || value341?.pn || value341?.id || value341?.jid || null;
          if (!value342) {
            continue;
          }
          if (value335 === "demote" && value337?.handleDemote) {
            await value337.handleDemote(value331, value333, value339, value342);
          }
          if (value335 === "promote" && value338?.handlePromote) {
            await value338.handlePromote(value331, value333, value339, value342);
          }
        }
      } catch (error343) {
        console.error("[handleGroupUpdate] antidemote/antipromote error:", error343.message);
      }
    }
    const value344 = database.getGroupSettings(value333);
    if (!value344.welcome && !value344.goodbye) {
      return;
    }
    const value345 = await getGroupMetadata(value331, value333);
    if (!value345) {
      return;
    }
    const value346 = value347 => {
      if (typeof value347 === "string") {
        return value347;
      }
      if (value347 && value347.id) {
        return value347.id;
      }
      if (value347 && typeof value347 === "object") {
        return value347.jid || value347.participant || null;
      }
      return null;
    };
    for (const value348 of value334) {
      const value349 = value346(value348);
      if (!value349) {
        console.warn("Could not extract participant JID:", value348);
        continue;
      }
      const value350 = value349.split("@")[0];
      if (value335 === "add") {
        try {
          const value351 = commands.get("antibot");
          if (value351?.handleGroupJoin) {
            await value351.handleGroupJoin(value331, value333, value349);
          }
        } catch (error352) {}
        try {
          const value353 = commands.get("antiforeign");
          if (value353?.handleGroupJoin) {
            await value353.handleGroupJoin(value331, value333, value349);
          }
        } catch (error354) {}
      }
      const value355 = (value356, value357) => {
        return (value356 || "").replace(/@user/g, "@" + value357.number).replace(/@group/g, value357.groupName).replace(/groupDesc/g, value357.groupDesc).replace(/time/g, value357.timeString).replace(/#memberCount/g, String(value357.memberCount)).replace(/botName/g, database.getBotSetting("botName"));
      };
      const value358 = async (value359, value360) => {
        try {
          const value361 = await value331.profilePictureUrl(value359, "image");
          const value362 = await axios.get(value361, {
            responseType: "arraybuffer",
            timeout: 8000
          });
          return Buffer.from(value362.data);
        } catch (error363) {}
        try {
          const value364 = await value331.profilePictureUrl(value360, "image");
          const value365 = await axios.get(value364, {
            responseType: "arraybuffer",
            timeout: 8000
          });
          return Buffer.from(value365.data);
        } catch (error366) {}
        return null;
      };
      if (value335 === "add" && value344.welcome) {
        try {
          const value367 = value345.subject || "the group";
          const value368 = value345.desc || "No description";
          const value369 = new Date();
          const value370 = value369.toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
            hour12: true
          });
          const value371 = value345.participants.length;
          const value372 = value355(value344.welcomeMessage, {
            number: value350,
            groupName: value367,
            groupDesc: value368,
            timeString: value370,
            memberCount: value371
          });
          const value373 = value344.welcomeNoPP === true;
          if (value373) {
            await value331.sendMessage(value333, {
              text: value372,
              mentions: [value349]
            });
          } else {
            const value374 = await value358(value349, value333);
            if (value374) {
              await value331.sendMessage(value333, {
                image: value374,
                caption: value372,
                mentions: [value349]
              });
            } else {
              await value331.sendMessage(value333, {
                text: value372,
                mentions: [value349]
              });
            }
          }
        } catch (error375) {
          console.error("Welcome error:", error375);
          try {
            const value376 = (value344.welcomeMessage || "Welcome @user to @group! 👋").replace(/@user/g, "@" + value350).replace(/@group/g, value345.subject || "the group");
            await value331.sendMessage(value333, {
              text: value376,
              mentions: [value349]
            });
          } catch (error377) {}
        }
      } else if (value335 === "remove" && value344.goodbye) {
        try {
          const value378 = value345.subject || "the group";
          const value379 = value345.desc || "No description";
          const value380 = new Date();
          const value381 = value380.toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
            hour12: true
          });
          const value382 = value345.participants.length;
          const value383 = value355(value344.goodbyeMessage, {
            number: value350,
            groupName: value378,
            groupDesc: value379,
            timeString: value381,
            memberCount: value382
          });
          const value384 = value344.welcomeNoPP === true;
          if (value384) {
            await value331.sendMessage(value333, {
              text: value383,
              mentions: [value349]
            });
          } else {
            const value385 = await value358(value349, value333);
            if (value385) {
              await value331.sendMessage(value333, {
                image: value385,
                caption: value383,
                mentions: [value349]
              });
            } else {
              await value331.sendMessage(value333, {
                text: value383,
                mentions: [value349]
              });
            }
          }
        } catch (error386) {
          console.error("Goodbye error:", error386);
          try {
            const value387 = (value344.goodbyeMessage || "Goodbye @user 👋").replace(/@user/g, "@" + value350).replace(/@group/g, value345.subject || "the group");
            await value331.sendMessage(value333, {
              text: value387,
              mentions: [value349]
            });
          } catch (error388) {}
        }
      }
    }
  } catch (error389) {
    if (error389.message && (error389.message.includes("forbidden") || error389.message.includes("403") || error389.statusCode === 403 || error389.output?.statusCode === 403 || error389.data === 403)) {
      return;
    }
    if (!error389.message || !error389.message.includes("forbidden")) {
      console.error("Error handling group update:", error389);
    }
  }
};
const collectAntilinkText = value390 => {
  const value391 = [];
  const value392 = value393 => {
    if (value393 == null) {
      return;
    }
    if (typeof value393 === "string") {
      if (value393.trim()) {
        value391.push(value393);
      }
      return;
    }
    if (typeof value393 === "number" || typeof value393 === "boolean") {
      value391.push(String(value393));
    }
  };
  const value394 = (value395, value396 = 0) => {
    if (!value395 || value396 > 6) {
      return;
    }
    if (typeof value395 === "string") {
      value392(value395);
      return;
    }
    if (Array.isArray(value395)) {
      for (const value397 of value395) {
        value394(value397, value396 + 1);
      }
      return;
    }
    if (typeof value395 !== "object") {
      return;
    }
    value392(value395.conversation);
    value392(value395.text);
    value392(value395.caption);
    value392(value395.matchedText);
    value392(value395.canonicalUrl);
    value392(value395.description);
    value392(value395.title);
    value392(value395.sourceUrl);
    value392(value395.mediaUrl);
    value392(value395.originalUrl);
    value392(value395.thumbnailUrl);
    value392(value395.body?.text);
    value392(value395.header?.title);
    value392(value395.header?.subtitle);
    value392(value395.footer?.text);
    value392(value395.hydratedContentText);
    value392(value395.contentText);
    value392(value395.selectedDisplayText);
    const value398 = [value395.ephemeralMessage?.message, value395.viewOnceMessage?.message, value395.viewOnceMessageV2?.message, value395.viewOnceMessageV2Extension?.message, value395.documentWithCaptionMessage?.message, value395.editedMessage?.message, value395.extendedTextMessage, value395.imageMessage, value395.videoMessage, value395.documentMessage, value395.buttonsMessage, value395.templateMessage, value395.templateMessage?.hydratedTemplate, value395.templateMessage?.hydratedFourRowTemplate, value395.listMessage, value395.interactiveMessage, value395.interactiveMessage?.body, value395.interactiveMessage?.header, value395.interactiveMessage?.nativeFlowMessage, value395.highlyStructuredMessage, value395.contextInfo, value395.contextInfo?.externalAdReply, value395.contextInfo?.externalAdReplyInfo, value395.extendedTextMessage?.contextInfo, value395.extendedTextMessage?.contextInfo?.externalAdReply, value395.imageMessage?.contextInfo?.externalAdReply, value395.videoMessage?.contextInfo?.externalAdReply];
    for (const value399 of value398) {
      value394(value399, value396 + 1);
    }
    if (Array.isArray(value395.nativeFlowMessage?.buttons)) {
      for (const value400 of value395.nativeFlowMessage.buttons) {
        value392(value400?.buttonParamsJson);
        value392(value400?.name);
      }
    }
  };
  value394(value390?.message);
  return value391.join("\n").replace(/[\u200B-\u200D\uFEFF\u2060]/g, "");
};
const ANTILINK_PATTERN = /(?:https?:\/\/|www\.)[^\s<>"'）】]+|(?:chat\.whatsapp\.com|wa\.me|t\.me|vm\.tiktok\.com|vt\.tiktok\.com|tiktok\.com|instagram\.com|instagr\.am|youtu\.be|youtube\.com|facebook\.com|fb\.watch|fb\.com|x\.com|twitter\.com|spotify\.com|soundcloud\.com|t\.co)\/[^\s<>"']+/i;
const messageHasLink = value401 => ANTILINK_PATTERN.test(collectAntilinkText(value401));
const resolveGroupJid = (value402, value403) => {
  if (value403 && String(value403).endsWith("@g.us")) {
    return value403;
  }
  if (value402?.key?.remoteJid?.endsWith("@g.us")) {
    return value402.key.remoteJid;
  }
  if (value402?.key?.remoteJidAlt?.endsWith("@g.us")) {
    return value402.key.remoteJidAlt;
  }
  return value403 || value402?.key?.remoteJid;
};
const resolveParticipantPn = (value404, value405) => {
  const value406 = [value404?.key?.participantAlt, value405, value404?.key?.participant, value404?.key?.remoteJidAlt].filter(Boolean);
  for (const value407 of value406) {
    if (isLidJid(value407)) {
      const value408 = getLidMappingValue(value407, "lidToPn");
      if (value408) {
        rememberLidPair(value407, value408);
        return String(value408).split("@")[0].split(":")[0] + "@s.whatsapp.net";
      }
      continue;
    }
    if (String(value407).endsWith("@s.whatsapp.net") || String(value407).endsWith("@hosted")) {
      return value407;
    }
  }
  return value405 || value404?.key?.participant || value404?.key?.remoteJid;
};
const mentionUser = value409 => String(value409 || "").split("@")[0].split(":")[0];
const ANTILINK_DEBUG_FILE = path.join(__dirname, "antilink-debug.json");
const safeJson = value410 => {
  try {
    return JSON.parse(JSON.stringify(value410, (value411, value412) => {
      if (Buffer.isBuffer(value412)) {
        return "[Buffer " + value412.length + "]";
      }
      if (value412 && typeof value412 === "object" && value412.type === "Buffer" && Array.isArray(value412.data)) {
        return "[Buffer " + value412.data.length + "]";
      }
      if (typeof value412 === "string" && value412.length > 500) {
        return value412.slice(0, 500) + "…";
      }
      return value412;
    }));
  } catch (error413) {
    return {
      error: error413.message
    };
  }
};
const writeAntilinkDebug = value414 => {
  try {
    fs.writeFileSync(ANTILINK_DEBUG_FILE, JSON.stringify(value414, null, 2));
  } catch (error415) {
    console.error("[ANTILINK DEBUG] could not write file:", error415.message);
  }
};
const handleAntilink = async (value416, value417, value418, value419, value420) => {
  try {
    if (!value417?.message || value417.key?.fromMe) {
      return;
    }
    const value421 = resolveGroupJid(value417, value419);
    const value422 = value420 || value417.key.participant || value417.key.remoteJid;
    const value423 = resolveParticipantPn(value417, value422);
    if (!value421 || !String(value421).endsWith("@g.us")) {
      return;
    }
    const value424 = database.getGroupSettings(value421);
    const value425 = collectAntilinkText(value417);
    const value426 = ANTILINK_PATTERN.test(value425);
    const value427 = getMessageContent(value417) || {};
    const value428 = {
      time: new Date().toISOString(),
      decision: "pending",
      from: value421,
      fromHint: value419 || null,
      sender: value422,
      mentionJid: value423,
      senderHint: value420 || null,
      key: {
        remoteJid: value417.key?.remoteJid || null,
        remoteJidAlt: value417.key?.remoteJidAlt || null,
        participant: value417.key?.participant || null,
        participantAlt: value417.key?.participantAlt || null,
        fromMe: !!value417.key?.fromMe,
        id: value417.key?.id || null,
        addressingMode: value417.key?.addressingMode || null
      },
      rawMessageKeys: Object.keys(value417.message || {}),
      unwrappedKeys: Object.keys(value427),
      oldBody: value427.conversation || value427.extendedTextMessage?.text || value427.imageMessage?.caption || value427.videoMessage?.caption || "",
      collectedText: value425,
      hasLink: value426,
      antilinkEnabled: !!value424.antilink,
      antilinkAction: value424.antilinkAction || "delete",
      settingsKeys: Object.keys(value424 || {}),
      message: safeJson(value417.message)
    };
    if (!value424.antilink) {
      value428.decision = "skip: antilink-off";
      writeAntilinkDebug(value428);
      return;
    }
    if (!value426) {
      value428.decision = "skip: no-link-detected";
      writeAntilinkDebug(value428);
      console.log("[ANTILINK DEBUG] no link detected");
      console.log("[ANTILINK DEBUG] keys:", value428.rawMessageKeys.join(", ") || "(none)");
      console.log("[ANTILINK DEBUG] oldBody:", JSON.stringify(value428.oldBody));
      console.log("[ANTILINK DEBUG] collectedText:", JSON.stringify(value425));
      return;
    }
    const value429 = (await isAdmin(value416, value422, value421, value418)) || (await isAdmin(value416, value423, value421, value418));
    const value430 = isOwner(value422) || isOwner(value423);
    value428.senderIsAdmin = value429;
    value428.senderIsOwner = value430;
    if (value429) {
      value428.decision = "skip: sender-admin";
      writeAntilinkDebug(value428);
      console.log("[ANTILINK DEBUG]", value428.decision, "sender=", value422, "mentionJid=", value423);
      return;
    }
    const value431 = await isBotAdmin(value416, value421, value418);
    value428.botIsAdmin = value431;
    if (!value431) {
      value428.decision = "skip: bot-not-admin";
      writeAntilinkDebug(value428);
      console.log("[ANTILINK DEBUG] bot is not admin in", value421);
      return;
    }
    value428.decision = "delete";
    writeAntilinkDebug(value428);
    console.log("[ANTILINK DEBUG] deleting link from", value423, "text=", JSON.stringify(value425.slice(0, 180)));
    const value432 = String(value424.antilinkAction || "delete").toLowerCase();
    const value433 = mentionUser(value423);
    const value434 = value423 || value422;
    const value435 = {
      remoteJid: value421,
      fromMe: value417.key.fromMe || false,
      id: value417.key.id,
      participant: value417.key.participant || value422
    };
    if (value432 === "warn") {
      const value436 = Number(database.addWarning(value421, value422, "Sent a link")) || 0;
      const value437 = database.getBotSetting("maxWarnings") || 3;
      try {
        await value416.sendMessage(value421, {
          delete: value435
        });
      } catch (error438) {}
      if (value436 >= value437) {
        try {
          await value416.groupParticipantsUpdate(value421, [value422], "remove");
          await value416.sendMessage(value421, {
            text: "🔗 @" + value433 + " has been removed.\n⚠️ Reached " + value437 + "/" + value437 + " warnings for sending links.",
            mentions: [value434]
          });
          database.clearWarnings(value421, value422);
        } catch (error439) {
          console.error("Failed to kick after max warns (antilink):", error439);
        }
      } else {
        await value416.sendMessage(value421, {
          text: "🔗 @" + value433 + " warned ⚠️\n\n📌 Reason: Sending links is not allowed\n⚠️ Warnings: " + value436 + "/" + value437 + "\n\n_" + (value437 - value436) + " more warning(s) before removal._",
          mentions: [value434]
        });
      }
    } else if (value432 === "kick") {
      try {
        await value416.sendMessage(value421, {
          delete: value435
        });
        await value416.groupParticipantsUpdate(value421, [value422], "remove");
        await value416.sendMessage(value421, {
          text: "🔗 @" + value433 + " has been removed for sending a link.",
          mentions: [value434]
        });
      } catch (error440) {
        console.error("Failed to kick for antilink:", error440);
      }
    } else {
      try {
        await value416.sendMessage(value421, {
          delete: value435
        });
        await value416.sendMessage(value421, {
          text: "🔗 @" + value433 + "'s message was deleted.\n📌 Reason: Links are not allowed in this group.",
          mentions: [value434]
        });
      } catch (error441) {
        console.error("Failed to delete for antilink:", error441);
      }
    }
  } catch (error442) {
    console.error("Error in antilink handler:", error442);
  }
};
const handleAntibadword = async (value443, value444, value445) => {
  try {
    const value446 = value444.key.remoteJid;
    const value447 = value444.key.participant || value444.key.remoteJid;
    const value448 = database.getGroupSettings(value446);
    if (!value448.antibadword) {
      return;
    }
    const value449 = database.getBadWords(value446);
    if (!value449.length) {
      return;
    }
    const value450 = (value444.message?.conversation || value444.message?.extendedTextMessage?.text || value444.message?.imageMessage?.caption || value444.message?.videoMessage?.caption || "").toLowerCase();
    if (!value450) {
      return;
    }
    const value451 = value449.find(value452 => {
      const value453 = value452.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      return new RegExp("\\b" + value453 + "\\b", "i").test(value450);
    });
    if (!value451) {
      return;
    }
    const value454 = await isAdmin(value443, value447, value446, value445);
    const value455 = isOwner(value447);
    if (value454 || value455) {
      return;
    }
    const value456 = await isBotAdmin(value443, value446, value445);
    if (!value456) {
      return;
    }
    const value457 = (value448.antibadwordAction || "warn").toLowerCase();
    if (value457 === "kick") {
      try {
        await value443.sendMessage(value446, {
          delete: value444.key
        });
        await value443.groupParticipantsUpdate(value446, [value447], "remove");
        await value443.sendMessage(value446, {
          text: "🤬 @" + value447.split("@")[0] + " was *kicked* for using a bad word: _" + value451 + "_",
          mentions: [value447]
        });
      } catch (error458) {
        console.error("AntiBadWord kick error:", error458);
      }
    } else if (value457 === "delete") {
      try {
        await value443.sendMessage(value446, {
          delete: value444.key
        });
        await value443.sendMessage(value446, {
          text: "🤬 @" + value447.split("@")[0] + ", watch your language! Bad word detected: _" + value451 + "_",
          mentions: [value447]
        });
      } catch (error459) {
        console.error("AntiBadWord delete error:", error459);
      }
    } else {
      try {
        await value443.sendMessage(value446, {
          delete: value444.key
        });
        const value460 = database.addWarning(value446, value447, "Bad word: " + value451);
        let value461 = "⚠️ @" + value447.split("@")[0] + ", you have been *warned* for using a bad word: _" + value451 + "_\n";
        value461 += "Warnings: *" + value460.count + "/" + database.getBotSetting("maxWarnings") + "*\n";
        if (value460.count >= database.getBotSetting("maxWarnings")) {
          value461 += "\n❌ Maximum warnings reached. You have been *removed* from the group!";
          await value443.sendMessage(value446, {
            text: value461,
            mentions: [value447]
          });
          await value443.groupParticipantsUpdate(value446, [value447], "remove");
          database.clearWarnings(value446, value447);
        } else {
          value461 += "\n_Further violations may result in a kick._";
          await value443.sendMessage(value446, {
            text: value461,
            mentions: [value447]
          });
        }
      } catch (error462) {
        console.error("AntiBadWord warn error:", error462);
      }
    }
  } catch (error463) {
    console.error("Error in antibadword handler:", error463);
  }
};
const handleAntigroupmention = async (value464, value465, value466) => {
  try {
    const value467 = value465.key.remoteJid;
    const value468 = database.getGroupSettings(value467);
    if (!value468.antigroupmention) {
      return;
    }
    let value469 = value465.message?.groupStatusMentionMessage?.participant || value465.key.participant || value465.key.remoteJid;
    if (value469 && value469.includes(":")) {
      value469 = value469.split(":")[0] + "@s.whatsapp.net";
    }
    try {
      const value470 = value465.message?.extendedTextMessage?.contextInfo || value465.message?.imageMessage?.contextInfo || value465.message?.contextInfo || null;
      database.recordRuntimeTelemetry("anti-group-mention", value467, {
        sender: value469,
        keyParticipant: value465.key.participant || null,
        messageTypes: Object.keys(value465.message || {}),
        hasGroupStatusMention: !!value465.message?.groupStatusMentionMessage,
        groupStatusParticipant: value465.message?.groupStatusMentionMessage?.participant || null,
        context: value470 ? {
          mentionedJid: value470.mentionedJid || [],
          statusMentionedJidList: value470.statusMentionedJidList || [],
          hasForwardedNewsletterInfo: !!value470.forwardedNewsletterMessageInfo,
          externalSourceType: value470.externalAdReplyInfo?.sourceType || null
        } : null
      });
    } catch (error471) {}
    let value472 = false;
    if (value465.message) {
      if (value465.message.groupStatusMentionMessage) {
        value472 = true;
      }
      if (value465.message.protocolMessage?.type === 25) {
        value472 = true;
      }
      const value473 = value474 => {
        if (!value474) {
          return false;
        }
        if (value474.forwardedNewsletterMessageInfo) {
          return true;
        }
        if (value474.externalAdReplyInfo?.sourceType === "status") {
          return true;
        }
        if (Array.isArray(value474.statusMentionedJidList) && value474.statusMentionedJidList.length > 0) {
          return true;
        }
        if (Array.isArray(value474.mentionedJid) && value474.mentionedJid.some(value475 => value475 === value467)) {
          return true;
        }
        return false;
      };
      const value476 = [value465.message.extendedTextMessage?.contextInfo, value465.message.imageMessage?.contextInfo, value465.message.videoMessage?.contextInfo, value465.message.stickerMessage?.contextInfo, value465.message.audioMessage?.contextInfo, value465.message.documentMessage?.contextInfo, value465.message.contextInfo];
      for (const value477 of value476) {
        if (value473(value477)) {
          value472 = true;
          break;
        }
      }
      const value478 = value465.message.conversation || value465.message.extendedTextMessage?.text || value465.message.imageMessage?.caption || value465.message.videoMessage?.caption || "";
      if (/you mentioned this group|mentioned this group/i.test(value478)) {
        value472 = true;
      }
    }
    if (!value472) {
      return;
    }
    const value479 = value469.endsWith("@g.us") ? false : await isAdmin(value464, value469, value467, value466);
    const value480 = isOwner(value469);
    if (value479 || value480) {
      return;
    }
    const value481 = await isBotAdmin(value464, value467, value466);
    if (!value481) {
      console.log("[AGM] Bot is not admin — cannot take action in", value467);
      return;
    }
    const value482 = (value468.antigroupmentionAction || "delete").toLowerCase();
    const value483 = value469.split("@")[0];
    if (value482 === "warn") {
      const value484 = database.addWarning(value467, value469, "Status mention in group");
      const value485 = database.getBotSetting("maxWarnings") || 3;
      try {
        await value464.sendMessage(value467, {
          delete: value465.key
        });
      } catch (error486) {}
      if (value484.count >= value485) {
        try {
          await value464.groupParticipantsUpdate(value467, [value469], "remove");
          await value464.sendMessage(value467, {
            text: "🛡️ @" + value483 + " has been removed.\n⚠️ Reached " + value485 + "/" + value485 + " warnings for sharing a status that mentions this group.",
            mentions: [value469]
          });
          database.clearWarnings(value467, value469);
        } catch (error487) {
          console.error("[AGM] Kick after max warns failed:", error487.message);
        }
      } else {
        await value464.sendMessage(value467, {
          text: "🛡️ @" + value483 + " warned ⚠️\n\n📌 Reason: Shared a status that mentions this group\n⚠️ Warnings: " + value484.count + "/" + value485 + "\n\n_" + (value485 - value484.count) + " more warning(s) before removal._",
          mentions: [value469]
        });
      }
    } else if (value482 === "kick") {
      try {
        await value464.sendMessage(value467, {
          delete: value465.key
        });
        await value464.groupParticipantsUpdate(value467, [value469], "remove");
        await value464.sendMessage(value467, {
          text: "🛡️ @" + value483 + " has been removed for sharing a status that mentions this group.",
          mentions: [value469]
        });
      } catch (error488) {
        console.error("[AGM] Kick failed:", error488.message);
      }
    } else {
      try {
        await value464.sendMessage(value467, {
          delete: value465.key
        });
        await value464.sendMessage(value467, {
          text: "🛡️ @" + value483 + "'s message was deleted.\n📌 Sharing a status that mentions this group is not allowed here.",
          mentions: [value469]
        });
      } catch (error489) {
        console.error("[AGM] Delete failed:", error489.message);
      }
    }
  } catch (error490) {
    console.error("[AGM] Handler error:", error490.message);
  }
};
const handleAntigroupstatus = async (value491, value492, value493) => {
  try {
    const value494 = value492.key.remoteJid;
    const value495 = value492.key.participant || value492.key.remoteJid;
    const value496 = database.getGroupSettings(value494);
    if (!value496.antigroupstatus) {
      return;
    }
    let value497 = false;
    if (value492.message) {
      value497 = value497 || !!value492.message.groupStatusMentionMessage;
      value497 = value497 || value492.message.protocolMessage && value492.message.protocolMessage.type === 25;
      const value498 = value499 => {
        if (!value499) {
          return false;
        }
        if (value499.forwardedNewsletterMessageInfo) {
          return true;
        }
        if (value499.externalAdReplyInfo?.sourceType === "status") {
          return true;
        }
        return false;
      };
      if (value492.message.extendedTextMessage?.contextInfo) {
        value497 = value497 || value498(value492.message.extendedTextMessage.contextInfo);
      }
      if (value492.message.imageMessage?.contextInfo) {
        value497 = value497 || value498(value492.message.imageMessage.contextInfo);
      }
      if (value492.message.videoMessage?.contextInfo) {
        value497 = value497 || value498(value492.message.videoMessage.contextInfo);
      }
      if (value492.message.contextInfo) {
        value497 = value497 || value498(value492.message.contextInfo);
      }
    }
    if (!value497) {
      return;
    }
    const value500 = await isAdmin(value491, value495, value494, value493);
    const value501 = isOwner(value495);
    if (value500 || value501) {
      return;
    }
    const value502 = await isBotAdmin(value491, value494, value493);
    if (!value502) {
      return;
    }
    const value503 = (value496.antigroupstatusAction || "delete").toLowerCase();
    const value504 = value495.split("@")[0];
    if (value503 === "warn") {
      const value505 = database.addWarning(value494, value495, "Status mention in group");
      const value506 = database.getBotSetting("maxWarnings") || 3;
      try {
        await value491.sendMessage(value494, {
          delete: value492.key
        });
      } catch (error507) {}
      if (value505.count >= value506) {
        try {
          await value491.groupParticipantsUpdate(value494, [value495], "remove");
          await value491.sendMessage(value494, {
            text: "🛡️ @" + value504 + " has been removed.\n⚠️ Reached " + value506 + "/" + value506 + " warnings for posting status mentions.",
            mentions: [value495]
          });
          database.clearWarnings(value494, value495);
        } catch (error508) {
          console.error("Failed to kick for antigroupstatus warn:", error508);
        }
      } else {
        await value491.sendMessage(value494, {
          text: "🛡️ @" + value504 + " warned ⚠️\n\n📌 Reason: Status mention in group\n⚠️ Warnings: " + value505.count + "/" + value506 + "\n\n_" + (value506 - value505.count) + " more warning(s) before removal._",
          mentions: [value495]
        });
      }
    } else if (value503 === "kick") {
      try {
        await value491.sendMessage(value494, {
          delete: value492.key
        });
        await value491.groupParticipantsUpdate(value494, [value495], "remove");
        await value491.sendMessage(value494, {
          text: "🛡️ @" + value504 + " has been removed for posting a status mention.",
          mentions: [value495]
        });
      } catch (error509) {
        console.error("Failed to kick for antigroupstatus:", error509);
      }
    } else {
      try {
        await value491.sendMessage(value494, {
          delete: value492.key
        });
        await value491.sendMessage(value494, {
          text: "🛡️ Status mention by @" + value504 + " deleted.\n_Status mentions are not allowed in this group._",
          mentions: [value495]
        });
      } catch (error510) {
        console.error("Failed to delete for antigroupstatus:", error510);
      }
    }
  } catch (error511) {
    console.error("Error in antigroupstatus handler:", error511);
  }
};
const initializeAntiCall = value512 => {
  value512.ev.on("messages.update", async value513 => {
    try {
      const {
        WAMessageStubType: value514
      } = require("@whiskeysockets/baileys");
      const value515 = value513.filter(value516 => value516.update?.messageStubType === value514.REVOKE);
      if (value515.length) {
        const value517 = commands.get("antidelete");
        if (value517?.handleDelete) {
          await value517.handleDelete(value512, value515);
        }
        const value518 = commands.get("antideletestatus");
        if (value518?.handleStatusDelete) {
          await value518.handleStatusDelete(value512, value515);
        }
      }
      const value519 = value513.filter(value520 => value520.update?.message?.editedMessage || value520.update?.message?.protocolMessage?.editedMessage);
      if (value519.length) {
        const value521 = commands.get("antiedit");
        if (value521?.handleAntiEdit) {
          await value521.handleAntiEdit(value512, value519);
        }
      }
    } catch (error522) {}
  });
  value512.ev.on("call", async value523 => {
    try {
      const value524 = database.getDefaultGroupSettings();
      if (!value524.anticall) {
        return;
      }
      const value525 = value524.anticallAction || "block";
      const value526 = Array.isArray(value523) ? value523 : [value523];
      const value527 = database.ANTICALL_PRESETS?.[0]?.message || "Sorry, I don't accept WhatsApp calls. Please send a message.";
      const value528 = value524.anticallMessage || value527;
      for (const value529 of value526) {
        if (!value529?.id || !value529?.from) {
          continue;
        }
        if (value529.status === "offer") {
          await value512.rejectCall(value529.id, value529.from);
          if (value524.anticallNotify !== false) {
            await value512.sendMessage(value529.from, {
              text: value528
            });
          }
          if (value525 === "block") {
            await value512.updateBlockStatus(value529.from, "block");
          }
        }
      }
    } catch (error530) {
      console.error("[ANTICALL ERROR]", error530);
    }
  });
};
const handleAntiMedia = async (value531, value532, value533) => {
  try {
    const value534 = value532.key.remoteJid;
    const value535 = value532.key.participant || value532.key.remoteJid;
    const value536 = database.getGroupSettings(value534);
    function handler537(value538) {
      if (!value538) {
        return null;
      }
      const value539 = Object.keys(value538)[0];
      if (!value539) {
        return null;
      }
      const value540 = ["ephemeralMessage", "viewOnceMessage", "viewOnceMessageV2", "viewOnceMessageV2Extension", "documentWithCaptionMessage"];
      if (value540.includes(value539)) {
        const value541 = value538[value539]?.message;
        if (value541) {
          return Object.keys(value541)[0];
        } else {
          return value539;
        }
      }
      return value539;
    }
    const value542 = handler537(value532.message);
    const value543 = (() => {
      const value544 = value532.message?.videoMessage || value532.message?.ephemeralMessage?.message?.videoMessage || value532.message?.viewOnceMessageV2?.message?.videoMessage;
      return !!value544?.gifPlayback;
    })();
    const value545 = [{
      enabled: value536.antiimage,
      action: value536.antiimageAction || "delete",
      label: "Anti Image 🖼️",
      types: ["imageMessage"]
    }, {
      enabled: value536.antisticker,
      action: value536.antistickerAction || "delete",
      label: "Anti Sticker 🎭",
      types: ["stickerMessage"]
    }, {
      enabled: value536.antiaudio,
      action: value536.antiaudioAction || "delete",
      label: "Anti Audio 🔇",
      types: ["audioMessage", "pttMessage"]
    }, {
      enabled: value536.anticontact,
      action: value536.anticontactAction || "delete",
      label: "Anti Contact 📇",
      types: ["contactMessage", "contactsArrayMessage"]
    }, {
      enabled: value536.antigif && value543,
      action: value536.antigifAction || "delete",
      label: "Anti GIF 🎞️",
      types: ["videoMessage"]
    }];
    for (const value546 of value545) {
      if (!value546.enabled) {
        continue;
      }
      if (!value546.types.includes(value542)) {
        continue;
      }
      const value547 = await isAdmin(value531, value535, value534, value533);
      const value548 = isOwner(value535);
      if (value547 || value548) {
        return;
      }
      const value549 = await isBotAdmin(value531, value534, value533);
      if (!value549) {
        return;
      }
      const value550 = {
        remoteJid: value534,
        fromMe: value532.key.fromMe || false,
        id: value532.key.id,
        participant: value532.key.participant || undefined
      };
      try {
        await value531.sendMessage(value534, {
          delete: value550
        });
      } catch (error551) {}
      const value552 = value535.split("@")[0].split(":")[0];
      const value553 = "━━━━━━━━━━━━━━━━━━━━";
      let value554 = [];
      try {
        const value555 = value533 || (await value531.groupMetadata(value534));
        value554 = (value555?.participants || []).map(value556 => value556.id);
      } catch (error557) {}
      if (value546.action === "kick") {
        try {
          await value531.groupParticipantsUpdate(value534, [value535], "remove");
          await value531.sendMessage(value534, {
            text: value546.label + "\n" + value553 + "\n" + ("🚫 @" + value552 + " has been *removed* from this group.\n") + ("📌 Reason: Sending " + value546.label.replace(/Anti | 🖼️| 🎭| 🔇/g, "").trim().toLowerCase() + " is not allowed here.\n") + ("" + value553),
            mentions: value554
          });
        } catch (error558) {}
      } else if (value546.action === "warn") {
        const value559 = database.addWarning(value534, value535, value546.label);
        const value560 = database.getBotSetting("maxWarnings") || 3;
        if (value559.count >= value560) {
          try {
            await value531.groupParticipantsUpdate(value534, [value535], "remove");
            database.clearWarnings(value534, value535);
            await value531.sendMessage(value534, {
              text: value546.label + "\n" + value553 + "\n" + ("🚫 @" + value552 + " has been *removed* from this group.\n") + ("📌 Reason: Reached maximum warnings (" + value560 + "/" + value560 + ") for sending " + value546.label.replace(/Anti | 🖼️| 🎭| 🔇/g, "").trim().toLowerCase() + ".\n") + ("" + value553),
              mentions: value554
            });
          } catch (error561) {}
        } else {
          const value562 = "⚠️".repeat(value559.count) + "⬜".repeat(value560 - value559.count);
          await value531.sendMessage(value534, {
            text: value546.label + "\n" + value553 + "\n" + ("⚠️ *WARNING* issued to @" + value552 + "\n\n") + ("📌 Reason: Sending " + value546.label.replace(/Anti | 🖼️| 🎭| 🔇/g, "").trim().toLowerCase() + " is not allowed in this group.\n\n") + (value562 + "\n") + ("Warnings: *" + value559.count + "/" + value560 + "*\n\n") + ("_" + (value560 - value559.count) + " more warning(s) will result in removal._\n") + ("" + value553),
            mentions: value554
          });
        }
      } else {
        await value531.sendMessage(value534, {
          text: value546.label + "\n" + value553 + "\n" + ("🗑️ @" + value552 + "'s message was deleted.\n") + ("📌 Sending " + value546.label.replace(/Anti | 🖼️| 🎭| 🔇/g, "").trim().toLowerCase() + " is not allowed here.\n") + ("" + value553),
          mentions: value554
        });
      }
      return;
    }
  } catch (error563) {
    console.error("Error in antiMedia handler:", error563);
  }
};
const CRASH_PATTERNS = [/\u0000/, /\u202E{2,}/, /[\u200B-\u200D\uFEFF]{10,}/, /[\u0300-\u036f]{8,}/, /(.)\1{500,}/, /[\u{E0000}-\u{E007F}]/u];
const isCrashMessage = value564 => {
  if (!value564 || typeof value564 !== "string") {
    return false;
  }
  for (const value565 of CRASH_PATTERNS) {
    try {
      if (value565.test(value564)) {
        return true;
      }
    } catch (error566) {}
  }
  return false;
};
const handleAntibug = async (value567, value568, value569, value570, value571, value572) => {
  try {
    if (!database.getBotSetting("antibug")) {
      return;
    }
    if (value568.key.fromMe) {
      return;
    }
    const value573 = value568.message?.conversation || value568.message?.extendedTextMessage?.text || value568.message?.imageMessage?.caption || value568.message?.videoMessage?.caption || value568.message?.documentMessage?.caption || "";
    if (!isCrashMessage(value573)) {
      return;
    }
    const value574 = (value571 || value572).split("@")[0].split(":")[0];
    const value575 = database.getBotSetting("antibugAction") || "delete";
    if (value570) {
      const value576 = await isAdmin(value567, value571, value572, value569);
      const value577 = isOwner(value571);
      if (value576 || value577) {
        return;
      }
      const value578 = await isBotAdmin(value567, value572, value569);
      if (!value578) {
        try {
          await value567.groupLeave(value572);
        } catch (error579) {}
        try {
          const value580 = getSelfJid(value567);
          await value567.sendMessage(value580, {
            text: "🛡️ *AntiBug Alert*\n" + ("Left group *" + (value569?.subject || value572) + "*\n") + ("Reason: crash message detected from *" + value574 + "* but bot is not admin.")
          });
        } catch (error581) {}
        return;
      }
      try {
        await value567.sendMessage(value572, {
          delete: value568.key
        });
      } catch (error582) {}
      if (value575 === "kick") {
        try {
          await value567.groupParticipantsUpdate(value572, [value571], "remove");
          await value567.sendMessage(value572, {
            text: "🛡️ *AntiBug* — @" + value574 + " was *removed* for sending a crash message.",
            mentions: [value571]
          });
        } catch (error583) {}
      } else if (value575 === "warn") {
        const value584 = database.addWarning(value572, value571, "Crash message (AntiBug)");
        const value585 = database.getBotSetting("maxWarnings") || 3;
        if (value584.count >= value585) {
          try {
            await value567.groupParticipantsUpdate(value572, [value571], "remove");
            database.clearWarnings(value572, value571);
            await value567.sendMessage(value572, {
              text: "🛡️ *AntiBug* — @" + value574 + " was *removed*.\n" + ("Reached max warnings (" + value585 + "/" + value585 + ") for crash messages."),
              mentions: [value571]
            });
          } catch (error586) {}
        } else {
          await value567.sendMessage(value572, {
            text: "🛡️ *AntiBug* ⚠️ Warning to @" + value574 + "\n" + ("Crash message deleted. Warnings: *" + value584.count + "/" + value585 + "*"),
            mentions: [value571]
          });
        }
      } else {
        try {
          await value567.sendMessage(value572, {
            text: "🛡️ *AntiBug* — Crash message from @" + value574 + " deleted.",
            mentions: [value571]
          });
        } catch (error587) {}
      }
    } else {
      try {
        await value567.updateBlockStatus(value571, "block");
      } catch (error588) {}
      try {
        const value589 = getSelfJid(value567);
        await value567.sendMessage(value589, {
          text: "🛡️ *AntiBug Alert — DM*\n" + ("Blocked *" + value574 + "* for sending a crash/bug message in private chat.")
        });
      } catch (error590) {}
    }
  } catch (error591) {
    console.error("[ANTIBUG]", error591.message);
  }
};
module.exports = {
  handleMessage: handleMessage,
  handleGroupUpdate: handleGroupUpdate,
  handleAntilink: handleAntilink,
  handleAntibadword: handleAntibadword,
  handleAntigroupmention: handleAntigroupmention,
  handleAntigroupstatus: handleAntigroupstatus,
  handleAntiMedia: handleAntiMedia,
  handleAntibug: handleAntibug,
  initializeAntiCall: initializeAntiCall,
  isOwner: isOwner,
  isAdmin: isAdmin,
  isBotAdmin: isBotAdmin,
  isMod: isMod,
  isSudo: isSudo,
  getGroupMetadata: getGroupMetadata,
  findParticipant: findParticipant,
  getCommandCount: () => commands.commandCount ?? commands.size,
  getAliasCount: () => commands.aliasCount ?? 0
};
