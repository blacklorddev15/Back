process.env.PUPPETEER_SKIP_DOWNLOAD = "true";
process.env.PUPPETEER_SKIP_CHROMIUM_DOWNLOAD = "true";
const fs = require("fs");
const os = require("os");
const path = require("path");
const assert = require("assert");
const cleanup = require("../utils/cleanup");
const HOUR = 3600000;
function makeDir(value1) {
  return fs.mkdtempSync(path.join(os.tmpdir(), "june-cleanup-" + value1 + "-"));
}
function touch(value2, value3, value4 = 0) {
  const value5 = path.join(value2, value3);
  fs.writeFileSync(value5, "junk");
  if (value4 > 0) {
    const value6 = new Date(Date.now() - value4);
    fs.utimesSync(value5, value6, value6);
  }
  return value5;
}
function exists(value7, value8) {
  return fs.existsSync(path.join(value7, value8));
}
let failures = 0;
function check(value9, value10) {
  try {
    value10();
    console.log("  ✅ " + value9);
  } catch (error11) {
    failures += 1;
    console.error("  ❌ " + value9 + ": " + error11.message);
  }
}
(async () => {
  console.log("root junk sweep");
  const value12 = makeDir("root");
  touch(value12, "media_old.mp4", HOUR * 2);
  touch(value12, "download_old.png", HOUR * 2);
  touch(value12, "sticker_fresh.gif");
  touch(value12, "tmp_x.tmp", HOUR * 2);
  touch(value12, "index.js", HOUR * 2);
  touch(value12, "notes.txt", HOUR * 2);
  fs.mkdirSync(path.join(value12, "session"));
  const value13 = path.join(value12, "session", "creds.json");
  fs.writeFileSync(value13, "{}");
  const value14 = cleanup.sweepRootJunk({
    rootDir: value12
  });
  check("old media_old.mp4 removed", () => assert.ok(!exists(value12, "media_old.mp4")));
  check("old download_old.png removed", () => assert.ok(!exists(value12, "download_old.png")));
  check("fresh sticker_fresh.gif survives", () => assert.ok(exists(value12, "sticker_fresh.gif")));
  check("old tmp_x.tmp survives (non-media ext)", () => assert.ok(exists(value12, "tmp_x.tmp")));
  check("old index.js survives (foreign name)", () => assert.ok(exists(value12, "index.js")));
  check("old notes.txt survives (foreign name)", () => assert.ok(exists(value12, "notes.txt")));
  check("session directory untouched", () => assert.ok(fs.existsSync(value13)));
  check("reports 2 deletions", () => assert.strictEqual(value14.deleted, 2));
  console.log("temp/ sweep");
  const value15 = makeDir("temp");
  touch(value15, "ptv_in_123.mp4", HOUR * 1);
  touch(value15, "converted_old.ogg", 2400000);
  touch(value15, "ptv_out_fresh.mp4");
  fs.mkdirSync(path.join(value15, "subdir"));
  const value16 = cleanup.sweepTempDir({
    tempDir: value15
  });
  check("old ptv_in_123.mp4 removed", () => assert.ok(!exists(value15, "ptv_in_123.mp4")));
  check("old converted_old.ogg removed", () => assert.ok(!exists(value15, "converted_old.ogg")));
  check("fresh ptv_out_fresh.mp4 survives", () => assert.ok(exists(value15, "ptv_out_fresh.mp4")));
  check("subdirectory untouched", () => assert.ok(fs.existsSync(path.join(value15, "subdir"))));
  check("reports 2 deletions", () => assert.strictEqual(value16.deleted, 2));
  console.log("runFileSweep (with sock)");
  const value17 = makeDir("root2");
  const value18 = makeDir("temp2");
  touch(value17, "media_sweep1.mp4", HOUR * 2);
  touch(value18, "upload_sweep2.mp3", HOUR * 1);
  touch(value18, "fresh_keep.jpg");
  const value19 = [];
  const value20 = {
    user: {
      id: "2349127747465:1@s.whatsapp.net",
      name: "June Test"
    },
    sendMessage: async (value21, value22) => {
      value19.push({
        jid: value21,
        content: value22
      });
      return {};
    }
  };
  const value23 = await cleanup.runFileSweep(value20, {
    rootDir: value17,
    tempDir: value18
  });
  check("root file deleted", () => assert.ok(!exists(value17, "media_sweep1.mp4")));
  check("temp file deleted", () => assert.ok(!exists(value18, "upload_sweep2.mp3")));
  check("fresh temp file survives", () => assert.ok(exists(value18, "fresh_keep.jpg")));
  check("counts: rootDeleted=1 tempDeleted=1", () => {
    assert.strictEqual(value23.rootDeleted, 1);
    assert.strictEqual(value23.tempDeleted, 1);
  });
  check("owner DM sent exactly once", () => assert.strictEqual(value19.length, 1));
  check("DM goes to bare owner jid", () => assert.strictEqual(value19[0].jid, "2349127747465@s.whatsapp.net"));
  check("DM reports total of 2", () => assert.ok(value19[0].content.text.includes("Removed 2")));
  console.log("runFileSweep (null sock)");
  const value24 = makeDir("root3");
  const value25 = makeDir("temp3");
  touch(value24, "media_enospc.mp4", HOUR * 3);
  const value26 = await cleanup.runFileSweep(null, {
    rootDir: value24,
    tempDir: value25
  });
  check("file deleted without a socket", () => assert.ok(!exists(value24, "media_enospc.mp4")));
  check("counts: rootDeleted=1", () => assert.strictEqual(value26.rootDeleted, 1));
  console.log("scheduler");
  const value27 = (global._activeIntervals || []).length;
  global._activeIntervals = global._activeIntervals || [];
  const value28 = cleanup.startScheduledCleanups(null, {
    initialSweep: false
  });
  const value29 = cleanup.startScheduledCleanups(null, {
    initialSweep: false
  });
  check("second start is a no-op (same handle)", () => assert.strictEqual(value28, value29));
  check("interval registered in _activeIntervals", () => assert.strictEqual((global._activeIntervals || []).length, value27 + 1));
  cleanup.stopScheduledCleanups();
  cleanup.stopScheduledCleanups();
  check("stop removes the interval", () => assert.strictEqual((global._activeIntervals || []).length, value27));
  for (const value30 of [value12, value15, value17, value18, value24, value25]) {
    try {
      fs.rmSync(value30, {
        recursive: true,
        force: true
      });
    } catch (error31) {}
  }
  if (failures > 0) {
    console.error("\n❌ cleanup hub: " + failures + " check(s) FAILED");
    process.exit(1);
  }
  console.log("\n✅ cleanup hub: all checks passed");
  process.exit(0);
})().catch(value32 => {
  console.error("cleanup hub test crashed:", value32);
  process.exit(1);
});
