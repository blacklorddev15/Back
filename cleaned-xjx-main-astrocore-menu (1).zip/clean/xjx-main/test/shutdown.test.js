const fs = require("fs");
const os = require("os");
const path = require("path");
const assert = require("assert");
const shutdown = require("../utils/shutdown");
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "shutdown-test-"));
const stateFile = path.join(tmp, "database", "shutdown-state.json");
function makeOpts(value1) {
  return {
    stateFile: stateFile,
    codes: value1,
    log: () => {},
    fatalLog: () => {},
    exit: value2 => value1.push(value2)
  };
}
function writeState(value3) {
  fs.mkdirSync(path.dirname(stateFile), {
    recursive: true
  });
  fs.writeFileSync(stateFile, JSON.stringify({
    killsLeft: value3,
    at: Date.now()
  }), "utf8");
}
{
  const ok = shutdown.requestShutdown({
    stateFile: stateFile,
    log: () => {}
  });
  assert.strictEqual(ok, true, "requestShutdown should succeed");
  const st = JSON.parse(fs.readFileSync(stateFile, "utf8"));
  assert.strictEqual(st.killsLeft, 2, "killsLeft should start at 2");
  assert.ok(typeof st.at === "number" && st.at > 0, "state should carry a timestamp");
}
{
  fs.unlinkSync(stateFile);
  const codes = [];
  shutdown.enforceShutdownChain(makeOpts(codes));
  assert.deepStrictEqual(codes, [], "no state file must not exit");
  assert.strictEqual(fs.existsSync(stateFile), false, "no state file must not be created");
}
{
  writeState(2);
  const codes = [];
  shutdown.enforceShutdownChain(makeOpts(codes));
  assert.deepStrictEqual(codes, [44], "kill 2/3 must exit with code 44");
  const st = JSON.parse(fs.readFileSync(stateFile, "utf8"));
  assert.strictEqual(st.killsLeft, 1, "state must decrement to 1");
}
{
  writeState(1);
  const codes = [];
  shutdown.enforceShutdownChain(makeOpts(codes));
  assert.deepStrictEqual(codes, [44], "kill 3/3 must exit with code 44");
  assert.strictEqual(fs.existsSync(stateFile), false, "final kill must delete the state file");
}
{
  const codes = [];
  shutdown.enforceShutdownChain(makeOpts(codes));
  assert.deepStrictEqual(codes, [], "boot after the chain must be a normal boot");
}
{
  const codes = [];
  shutdown.requestShutdown({
    stateFile: stateFile,
    log: () => {}
  });
  codes.push(shutdown.EXIT_CODE);
  let boots = 0;
  while (boots < 5) {
    const before = codes.length;
    shutdown.enforceShutdownChain(makeOpts(codes));
    boots++;
    if (codes.length === before) {
      break;
    }
  }
  assert.strictEqual(codes.length, 3, "chain must produce exactly 3 kills total, got " + codes.length);
  assert.ok(codes.every(value4 => value4 === 44), "every kill must use exit code 44");
  assert.strictEqual(boots, 3, "the 3rd boot must stay alive");
  assert.strictEqual(fs.existsSync(stateFile), false, "state must be gone when the bot is alive");
}
{
  writeState(2);
  fs.writeFileSync(stateFile, "{ not json !!!", "utf8");
  const codes = [];
  shutdown.enforceShutdownChain(makeOpts(codes));
  assert.deepStrictEqual(codes, [], "corrupt state must fail open (boot normally)");
  assert.strictEqual(fs.existsSync(stateFile), false, "corrupt state file must be deleted");
}
{
  writeState(0);
  let codes = [];
  shutdown.enforceShutdownChain(makeOpts(codes));
  assert.deepStrictEqual(codes, [], "killsLeft 0 must fail open");
  assert.strictEqual(fs.existsSync(stateFile), false, "spent state file must be deleted");
  writeState("banana");
  codes = [];
  shutdown.enforceShutdownChain(makeOpts(codes));
  assert.deepStrictEqual(codes, [], "non-numeric killsLeft must fail open");
}
{
  fs.mkdirSync(stateFile, {
    recursive: true
  });
  const codes = [];
  shutdown.enforceShutdownChain(makeOpts(codes));
  assert.deepStrictEqual(codes, [], "dir-as-state must fail open without throwing");
  fs.rmdirSync(stateFile);
}
{
  assert.ok(shutdown.STATE_FILE.endsWith(path.join("database", "shutdown-state.json")), "default state file must live in database/");
  assert.ok(!shutdown.STATE_FILE.startsWith(os.tmpdir()), "default state file must be inside the bot folder");
}
{
  fs.writeFileSync(path.join(tmp, "shutdown-state.json"), "x", "utf8");
  const bad = path.join(tmp, "shutdown-state.json", "nested", "x.json");
  const ok = shutdown.requestShutdown({
    stateFile: bad,
    log: () => {}
  });
  assert.strictEqual(ok, false, "non-writable state path must return false");
  fs.unlinkSync(path.join(tmp, "shutdown-state.json"));
}
const savedRoutine = global.__JUNE_SHUTDOWN;
(async () => {
  {
    let value5 = false;
    global.__JUNE_SHUTDOWN = async () => {
      value5 = true;
    };
    const value6 = [];
    await shutdown.shutdownNow({
      stateFile: stateFile,
      codes: value6,
      log: () => {},
      exit: value7 => value6.push(value7)
    });
    assert.strictEqual(value5, true, "graceful routine must run");
    assert.deepStrictEqual(value6, [44], "must exit 44 after the graceful close");
    const value8 = JSON.parse(fs.readFileSync(stateFile, "utf8"));
    assert.strictEqual(value8.killsLeft, 2, "chain state must be armed after graceful close");
  }
  {
    fs.unlinkSync(stateFile);
    global.__JUNE_SHUTDOWN = undefined;
    const value9 = [];
    await shutdown.shutdownNow({
      stateFile: stateFile,
      codes: value9,
      log: () => {},
      exit: value10 => value9.push(value10)
    });
    assert.deepStrictEqual(value9, [44], "must exit even without a routine");
    assert.strictEqual(fs.existsSync(stateFile), true, "chain state must still be armed");
  }
  {
    fs.unlinkSync(stateFile);
    global.__JUNE_SHUTDOWN = async () => {
      throw new Error("db close exploded");
    };
    const value11 = [];
    await shutdown.shutdownNow({
      stateFile: stateFile,
      codes: value11,
      log: () => {},
      exit: value12 => value11.push(value12)
    });
    assert.deepStrictEqual(value11, [44], "must exit even if the routine throws");
    assert.strictEqual(fs.existsSync(stateFile), true, "chain state must still be armed");
  }
  {
    fs.unlinkSync(stateFile);
    global.__JUNE_SHUTDOWN = () => new Promise(() => {});
    const value13 = [];
    const value14 = Date.now();
    await shutdown.shutdownNow({
      stateFile: stateFile,
      codes: value13,
      log: () => {},
      exit: value15 => value13.push(value15),
      timeoutMs: 30
    });
    const value16 = Date.now() - value14;
    assert.ok(value16 < 2000, "timeout guard must fire quickly (took " + value16 + "ms)");
    assert.deepStrictEqual(value13, [44], "must exit even if the routine hangs");
    assert.strictEqual(fs.existsSync(stateFile), true, "chain state must still be armed");
  }
  global.__JUNE_SHUTDOWN = savedRoutine;
  fs.rmSync(tmp, {
    recursive: true,
    force: true
  });
  console.log("SHUTDOWN TEST: all assertions passed");
})().catch(value17 => {
  try {
    global.__JUNE_SHUTDOWN = savedRoutine;
    fs.rmSync(tmp, {
      recursive: true,
      force: true
    });
  } catch (error18) {}
  console.error("SHUTDOWN TEST FAILED:", value17);
  process.exit(1);
});
