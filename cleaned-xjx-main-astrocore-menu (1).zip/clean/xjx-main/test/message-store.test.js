process.env.PUPPETEER_SKIP_DOWNLOAD = "true";
process.env.PUPPETEER_SKIP_CHROMIUM_DOWNLOAD = "true";
const {
  EventEmitter
} = require("events");
const assert = require("assert");
const {
  createMessageStore
} = require("../utils/messageStore");
function mkMsg(value1, value2, value3 = null) {
  return {
    key: {
      id: value1,
      remoteJid: value2,
      participant: value3
    },
    message: {
      conversation: "m" + value1
    },
    messageTimestamp: Number(value1) || 0
  };
}
let failures = 0;
async function check(value4, value5) {
  try {
    await value5();
    console.log("  ✅ " + value4);
  } catch (error6) {
    failures += 1;
    console.error("  ❌ " + value4 + ": " + error6.message);
  }
}
(async () => {
  console.log("per-chat cap");
  {
    const value7 = createMessageStore({
      maxPerChat: 20,
      maxChats: 300
    });
    for (let value8 = 1; value8 <= 25; value8++) {
      value7.storeMessage("g1@g.us", mkMsg("m" + value8, "g1@g.us"));
    }
    await check("chat holds exactly 20 messages", () => assert.strictEqual(value7.messages.get("g1@g.us").size, 20));
    await check("oldest 5 evicted (m1 gone)", () => assert.strictEqual(value7.messages.get("g1@g.us").has("m1"), false));
    await check("newest kept (m25 present)", () => assert.strictEqual(value7.messages.get("g1@g.us").has("m25"), true));
  }
  console.log("total chat cap");
  {
    const value9 = createMessageStore({
      maxPerChat: 20,
      maxChats: 10
    });
    for (let value10 = 1; value10 <= 12; value10++) {
      value9.storeMessage("c" + value10 + "@s.whatsapp.net", mkMsg("x" + value10, "c" + value10 + "@s.whatsapp.net"));
    }
    await check("only 10 chats kept", () => assert.strictEqual(value9.messages.size, 10));
    await check("oldest chats evicted (c1, c2 gone)", () => {
      assert.strictEqual(value9.messages.has("c1@s.whatsapp.net"), false);
      assert.strictEqual(value9.messages.has("c2@s.whatsapp.net"), false);
    });
    await check("newest chat kept (c12)", () => assert.strictEqual(value9.messages.has("c12@s.whatsapp.net"), true));
  }
  console.log("LRU ordering");
  {
    const value11 = createMessageStore({
      maxPerChat: 5,
      maxChats: 3
    });
    value11.storeMessage("a", mkMsg("a1", "a"));
    value11.storeMessage("b", mkMsg("b1", "b"));
    value11.storeMessage("c", mkMsg("c1", "c"));
    value11.storeMessage("a", mkMsg("a2", "a"));
    value11.storeMessage("d", mkMsg("d1", "d"));
    await check("idle chat b evicted", () => assert.strictEqual(value11.messages.has("b"), false));
    await check("touched chat a survives", () => assert.strictEqual(value11.messages.has("a"), true));
    await check("c and d kept", () => {
      assert.strictEqual(value11.messages.has("c"), true);
      assert.strictEqual(value11.messages.has("d"), true);
    });
  }
  console.log("loadMessage");
  {
    const value12 = createMessageStore();
    value12.storeMessage("g@g.us", mkMsg("id1", "g@g.us"));
    await check("known message resolves", async () => {
      const value13 = await value12.loadMessage("g@g.us", "id1");
      assert.ok(value13 && value13.key.id === "id1");
    });
    await check("unknown message → null", async () => {
      const value14 = await value12.loadMessage("g@g.us", "nope");
      assert.strictEqual(value14, null);
    });
  }
  console.log("bind()");
  {
    const value15 = createMessageStore({
      maxPerChat: 20,
      maxChats: 300
    });
    const value16 = new EventEmitter();
    value15.bind(value16);
    value16.emit("messages.upsert", {
      messages: [mkMsg("u1", "gr@g.us", "1@s.whatsapp.net"), mkMsg("u2", "gr@g.us", "2@s.whatsapp.net")]
    });
    await check("upsert batch stored", () => assert.strictEqual(value15.messages.get("gr@g.us").size, 2));
  }
  console.log("evictOldestChats");
  {
    const value17 = createMessageStore({
      maxPerChat: 20,
      maxChats: 100
    });
    for (let value18 = 1; value18 <= 10; value18++) {
      value17.storeMessage("e" + value18, mkMsg("k" + value18, "e" + value18));
    }
    const value19 = value17.evictOldestChats(4);
    await check("evicts down to target", () => assert.strictEqual(value19, 4));
    await check("oldest dropped (e1, e6 gone; e7, e10 kept)", () => {
      assert.strictEqual(value17.messages.has("e1"), false);
      assert.strictEqual(value17.messages.has("e6"), false);
      assert.strictEqual(value17.messages.has("e7"), true);
      assert.strictEqual(value17.messages.has("e10"), true);
    });
    await check("target below 0 is safe", () => assert.strictEqual(value17.evictOldestChats(-5), 0));
  }
  console.log("bad input");
  {
    const value20 = createMessageStore();
    value20.storeMessage(null, mkMsg("x", "a"));
    value20.storeMessage("a", null);
    value20.storeMessage("a", {
      key: {}
    });
    value20.storeMessage("a", {});
    await check("nothing stored, no crash", () => assert.strictEqual(value20.messages.size, 0));
  }
  if (failures > 0) {
    console.error("\n❌ message store: " + failures + " check(s) FAILED");
    process.exit(1);
  }
  console.log("\n✅ message store: all checks passed");
  process.exit(0);
})().catch(value21 => {
  console.error("message store test crashed:", value21);
  process.exit(1);
});
