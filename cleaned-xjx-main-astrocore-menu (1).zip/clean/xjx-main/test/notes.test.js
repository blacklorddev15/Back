'use strict';

const fs = require("fs");
const path = require("path");
const os = require("os");
const assert = require("node:assert/strict");
process.env.JUNE_NOTES_DIR = fs.mkdtempSync(path.join(os.tmpdir(), "notes-test-"));
const notes = require("../utils/notes");
let passed = 0;
let failed = 0;
function check(value1, value2, value3 = "") {
  if (value2) {
    passed++;
    console.log("  ✔ " + value1);
  } else {
    failed++;
    console.error("  ✖ " + value1 + (value3 ? " — " + value3 : ""));
  }
}
const kv = new Map();
const fakeDb = {
  getKV: (value4, value5, value6 = null) => kv.has(value4 + "::" + value5) ? kv.get(value4 + "::" + value5) : value6,
  setKV: (value7, value8, value9) => {
    kv.set(value7 + "::" + value8, value9);
    return true;
  },
  delKV: (value10, value11) => {
    kv.delete(value10 + "::" + value11);
    return true;
  }
};
notes.__test.reset();
notes.__test.setDatabase(fakeDb);
const USER = "254712345678";
console.log("\n[1] text notes");
kv.set(notes.NOTES_NS + "::" + USER, [{
  id: "old1",
  text: "legacy note",
  savedAt: 1690000000000
}]);
check("legacy note loads", notes.loadNotes(USER).length === 1 && notes.loadNotes(USER)[0].text === "legacy note");
const tags = notes.parseTags("buy milk #shopping #Family #shopping");
check("tags parsed + deduped + lowercased", JSON.stringify(tags) === JSON.stringify(["#shopping", "#family"]), JSON.stringify(tags));
check("no tags → empty", notes.parseTags("plain text").length === 0);
notes.saveNotes(USER, [...notes.loadNotes(USER), {
  id: "n2",
  type: "text",
  text: "team standup #work",
  tags: notes.parseTags("team standup #work"),
  savedAt: Date.now()
}, {
  id: "n3",
  type: "text",
  text: "buy milk #shopping",
  tags: notes.parseTags("buy milk #shopping"),
  savedAt: Date.now()
}]);
check("notes saved", notes.loadNotes(USER).length === 3);
console.log("\n[2] search · tags · edit · pagination · export");
const all = notes.loadNotes(USER);
check("find matches case-insensitively", all.filter(value12 => notes.matchesQuery(value12, "MILK")).length === 1);
check("find matches tag text", all.filter(value13 => notes.matchesQuery(value13, "#work")).length === 1);
check("tag filter works", all.filter(value14 => notes.matchesTag(value14, "#shopping")).length === 1);
check("tag filter is exact", all.filter(value15 => notes.matchesTag(value15, "#shoppinglist")).length === 0);
const edited = [...all];
edited[1].text = "team standup moved to 10am #work #meeting";
edited[1].tags = notes.parseTags(edited[1].text);
notes.saveNotes(USER, edited);
check("edit rewrites text + tags", notes.loadNotes(USER)[1].tags.includes("#meeting"));
const many = Array.from({
  length: 32
}, (value16, value17) => ({
  id: "p" + value17,
  type: "text",
  text: "note " + value17,
  savedAt: Date.now()
}));
const p1 = notes.paginate(many, 1);
const p2 = notes.paginate(many, 2);
const p3 = notes.paginate(many, 3);
const pOver = notes.paginate(many, 99);
check("pagination 15/15/2", p1.slice.length === 15 && p2.slice.length === 15 && p3.slice.length === 2 && p3.pages === 3);
check("page overflow clamps to last page", pOver.page === 3);
const exportText = notes.buildExportText(USER, notes.loadNotes(USER));
check("export includes entries + header", exportText.includes("Notes export") && exportText.includes("legacy note") && exportText.includes("standup") && exportText.includes("buy milk"));
console.log("\n[3] media notes");
const imageBuf = Buffer.from("fakejpegbytes" + "x".repeat(1000));
const saved = notes.saveMediaNote({
  userId: USER,
  buffer: imageBuf,
  kind: "image",
  mime: "image/jpeg",
  caption: "lunch ideas #food"
});
check("media note saved", !!saved.note && saved.note.type === "image" && saved.note.tags.includes("#food"), JSON.stringify(saved));
check("local cache file written", fs.existsSync(path.join(process.env.JUNE_NOTES_DIR, USER, saved.note.id + ".jpg")));
check("mirrored KV copy written", !!fakeDb.getKV(notes.MEDIA_NS, USER + ":" + saved.note.id));
check("metadata in notes array", notes.loadNotes(USER).some(value18 => value18.id === saved.note.id && value18.type === "image"));
check("getMedia returns bytes (local)", notes.getMedia(USER, saved.note).equals(imageBuf));
fs.rmSync(path.join(process.env.JUNE_NOTES_DIR, USER, saved.note.id + ".jpg"));
const recovered = notes.getMedia(USER, saved.note);
check("EPHEMERAL RECOVERY: bytes restored from mirrored KV", recovered && recovered.equals(imageBuf));
check("recovery re-caches the file", fs.existsSync(path.join(process.env.JUNE_NOTES_DIR, USER, saved.note.id + ".jpg")));
notes.deleteMedia(USER, saved.note);
check("delete removes file + KV copy", !fs.existsSync(path.join(process.env.JUNE_NOTES_DIR, USER, saved.note.id + ".jpg")) && !fakeDb.getKV(notes.MEDIA_NS, USER + ":" + saved.note.id));
console.log("\n[4] caps");
const fresh = "9990001111";
check("oversized media rejected", !!notes.saveMediaNote({
  userId: fresh,
  buffer: Buffer.alloc(6291456),
  kind: "video",
  mime: "video/mp4"
}).error);
check("empty media rejected", !!notes.saveMediaNote({
  userId: fresh,
  buffer: Buffer.alloc(0),
  kind: "image"
}).error);
check("unknown kind rejected", !!notes.saveMediaNote({
  userId: fresh,
  buffer: imageBuf,
  kind: "hologram"
}).error);
const capped = "9990002222";
for (let i = 0; i < notes.MAX_MEDIA_NOTES; i++) {
  notes.saveMediaNote({
    userId: capped,
    buffer: imageBuf,
    kind: "image",
    mime: "image/jpeg"
  });
}
check("media cap enforced at 20", !!notes.saveMediaNote({
  userId: capped,
  buffer: imageBuf,
  kind: "image"
}).error);
const hundred = "9990003333";
for (let i = 0; i < notes.MAX_NOTES; i++) {
  notes.saveNotes(hundred, [...notes.loadNotes(hundred), {
    id: "t" + i,
    type: "text",
    text: "x",
    savedAt: Date.now()
  }]);
}
check("total notes cap enforced at 100", notes.loadNotes(hundred).length === notes.MAX_NOTES);
console.log("\n[5] time parsing");
check("30m → 30 min", notes.parseTimeSpec("30m") === 1800000);
check("2h → 2 hours", notes.parseTimeSpec("2h") === 7200000);
check("1d → 1 day", notes.parseTimeSpec("1d") === 86400000);
check("45 → 45 minutes", notes.parseTimeSpec("45") === 2700000);
check("15s → 15 seconds", notes.parseTimeSpec("15s") === 15000);
check("garbage → null", notes.parseTimeSpec("soon") === null && notes.parseTimeSpec("") === null && notes.parseTimeSpec("-5m") === null);
(async () => {
  console.log("\n[6] reminders");
  const value19 = [];
  const value20 = {
    sendMessage: async (value21, value22) => {
      value19.push({
        jid: value21,
        payload: value22
      });
    }
  };
  notes.__test.state.sock = value20;
  notes.saveNotes(USER, [...notes.loadNotes(USER).filter(value23 => value23.id !== "old1"), {
    id: "rem1",
    type: "text",
    text: "call the accountant #money",
    tags: [],
    savedAt: Date.now()
  }]);
  const value24 = notes.addReminder({
    userId: USER,
    userJid: USER + "@s.whatsapp.net",
    noteId: "rem1",
    dueAt: Date.now() + 50,
    noteRef: notes.loadNotes(USER).find(value25 => value25.id === "rem1")
  });
  check("reminder persisted", notes.loadReminders ? true : fakeDb.getKV("note_reminders", "pending").length === 1);
  check("reminder stored in KV", fakeDb.getKV("note_reminders", "pending").some(value26 => value26.id === value24.id));
  await new Promise(value27 => setTimeout(value27, 120));
  const value28 = await notes.scanReminders();
  check("due reminder fired exactly once", value28 === 1 && value19.length === 1, "fired=" + value28 + " sent=" + value19.length);
  check("DM went to the user JID", value19[0]?.jid === USER + "@s.whatsapp.net");
  check("DM contains the note text", String(value19[0]?.payload?.text).includes("call the accountant"));
  check("fired reminder removed from KV", !fakeDb.getKV("note_reminders", "pending").some(value29 => value29.id === value24.id));
  const value30 = await notes.scanReminders();
  check("no double firing", value30 === 0 && value19.length === 1);
  const value31 = notes.addReminder({
    userId: USER,
    userJid: USER + "@s.whatsapp.net",
    noteId: "rem1",
    dueAt: Date.now() + 50,
    noteRef: notes.loadNotes(USER).find(value32 => value32.id === "rem1")
  });
  const value33 = {
    sendMessage: async (value34, value35) => {
      value19.push({
        jid: value34,
        payload: value35
      });
    }
  };
  notes.onBotConnected(value33);
  await new Promise(value36 => setTimeout(value36, 120));
  const value37 = await notes.scanReminders();
  check("reminder survives restart (new socket fires it)", value37 === 1 && value19.length === 2);
  notes.__test.reset();
  console.log("\n" + (failed ? failed + " FAILED" : "ALL GREEN") + " — " + passed + " passed");
  process.exit(failed ? 1 : 0);
})();
