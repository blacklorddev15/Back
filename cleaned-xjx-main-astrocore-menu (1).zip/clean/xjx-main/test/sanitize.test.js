const assert = require("assert");
const {
  sanitizeUserText,
  wrapSockSanitized
} = require("../utils/sanitizeUserText");
const LEAK = "Command failed: \"ffmpeg\" -y -i \"/app/node_modules/ytdl-:-core3/core0/core1/core2/core3/core4/core5/core6/core7/core8/core9/core10/core11/core12/core13/core14/core15/core16/core17/core18/core19/core20/core21/core22/core23/core24/core25/core26/core27/core28/core29/core30/core31/core32/core33/core34/core35/core36/core37/core38/core39/core40/core41/core42/core43/core44/core45/core46/core47/core48/core49/lib_signals/xjx-main/temp/webp_1790235064193_cyct8q63xnc_in.webp\" -frames:v 1 \"/app/node_modules/ytdl-:-core3/core49/lib_signals/xjx-main/temp/webp_1790235064193_cyct8q63xnc_out.png\"";
const cleaned = sanitizeUserText(LEAK);
for (const needle of ["/app", "node_modules", "ytdl-:-core3", "core0", "core49", "lib_signals", "xjx-main", "temp/", "webp_1790", "in.webp", "out.png"]) {
  assert(!cleaned.includes(needle), "leak survives: " + needle + " → " + cleaned);
}
assert(cleaned.includes("[path]"), "replacement token expected");
assert(cleaned.includes("Command failed"), "non-path context must survive");
assert(cleaned.includes("-frames:v 1"), "command flags may remain (not sensitive)");
assert.strictEqual(sanitizeUserText("Download from https://youtube.com/watch?v=dQw4w9WgXcQ or http://a.io/x/y now"), "Download from https://youtube.com/watch?v=dQw4w9WgXcQ or http://a.io/x/y now");
const win = sanitizeUserText("found at C:\\Users\\bob\\videos\\clip.mp4 ok");
assert(!win.includes("C:\\") && !win.includes("bob"), win);
assert(win.includes("[path]"), win);
assert.strictEqual(sanitizeUserText("❌ Failed to convert sticker. Please try again."), "❌ Failed to convert sticker. Please try again.");
assert.strictEqual(sanitizeUserText("usage: .sticker (reply to an image)"), "usage: .sticker (reply to an image)");
assert.strictEqual(sanitizeUserText("in /tmp dir"), "in /tmp dir");
assert.strictEqual(sanitizeUserText("temp/webp_x.webp is relative"), "temp/webp_x.webp is relative");
assert.strictEqual(sanitizeUserText(42), 42);
assert.strictEqual(sanitizeUserText(null), null);
assert.strictEqual(sanitizeUserText(undefined), undefined);
(async () => {
  const value1 = [];
  const value2 = {
    sendMessage: (value3, value4, value5) => {
      value1.push({
        jid: value3,
        content: value4,
        opts: value5
      });
      return Promise.resolve({
        key: {}
      });
    }
  };
  wrapSockSanitized(value2);
  await value2.sendMessage("u@s.whatsapp.net", {
    text: "Error: /app/deep/nested/path/x failed"
  });
  assert.strictEqual(value1.at(-1).content.text, "Error: [path] failed");
  await value2.sendMessage("u@s.whatsapp.net", {
    image: {},
    caption: "see /usr/local/bin/ffmpeg here"
  });
  assert.strictEqual(value1.at(-1).content.caption, "see [path] here");
  assert.deepStrictEqual(value1.at(-1).content.image, {}, "non-text content untouched");
  await value2.sendMessage("u@s.whatsapp.net", {
    text: "link: https://a.io/x/y is fine"
  });
  assert.strictEqual(value1.at(-1).content.text, "link: https://a.io/x/y is fine");
  wrapSockSanitized(value2);
  await value2.sendMessage("u@s.whatsapp.net", {
    text: "double /a/b wrap"
  });
  assert.strictEqual(value1.at(-1).content.text, "double [path] wrap");
  await assert.doesNotReject(() => value2.sendMessage("u@s.whatsapp.net", null, {}));
  console.log("SANITIZE TEST: all assertions passed");
})().catch(value6 => {
  console.error("SANITIZE TEST FAILED:", value6);
  process.exit(1);
});
