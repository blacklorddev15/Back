process.env.PUPPETEER_SKIP_DOWNLOAD = "true";
process.env.PUPPETEER_SKIP_CHROMIUM_DOWNLOAD = "true";
const SENT = [];
const state = {
  gatePassed: false
};
(async () => {
  const value1 = require("/home/user/wdp/handler.js");
  const value2 = require("/home/user/wdp/database.js");
  await value2.ready;
  const value3 = {
    user: {
      id: "2349127747465:1@s.whatsapp.net",
      name: "June Test"
    },
    sendMessage: async (value4, value5, value6) => {
      SENT.push({
        jid: value4,
        content: value5
      });
      return {};
    },
    sendPresenceUpdate: async () => {},
    readMessages: async () => {},
    groupMetadata: async () => ({
      id: "234801@g.us",
      subject: "G",
      participants: []
    })
  };
  global.currentSock = value3;
  value2.setOwners(["2349127747465"], "test");
  const value7 = {
    key: {
      remoteJid: "234802@s.whatsapp.net",
      fromMe: false,
      participant: "234802@s.whatsapp.net",
      id: "TESTMSG1"
    },
    pushName: "Stranger",
    messageTimestamp: Math.floor(Date.now() / 1000),
    message: {
      conversation: ".ping"
    }
  };
  await value1.handleMessage(value3, value7);
  const value8 = require("/home/user/wdp/utils/commandToggle.js");
  value8.disable("ping");
  SENT.length = 0;
  await value1.handleMessage(value3, value7);
  const value9 = SENT.map(value10 => JSON.stringify(value10.content)).join(" | ");
  console.log("disabled-mode reply:", value9.slice(0, 120));
  if (!value9.includes("currently disabled")) {
    console.error("❌ disable feature did not block the non-owner");
    process.exit(1);
  }
  SENT.length = 0;
  const value11 = {
    ...value7,
    key: {
      ...value7.key,
      fromMe: true,
      remoteJid: "2349127747465@s.whatsapp.net"
    }
  };
  await value1.handleMessage(value3, value11);
  const value12 = SENT.map(value13 => JSON.stringify(value13.content)).join(" | ");
  console.log("owner reply while disabled:", value12.slice(0, 120));
  if (value9.includes("currently disabled") && value12.includes("pong")) {
    console.log("✅ disable feature verified: non-owner blocked, owner bypasses");
  }
  value8.enable("ping");
  const value14 = SENT.map(value15 => JSON.stringify(value15.content)).join(" | ");
  console.log("messages sent back:", SENT.length);
  console.log(value14.slice(0, 300));
  if (/commandToggle is not defined/i.test(value14)) {
    console.error("\n❌ STILL BROKEN: commandToggle ReferenceError reached the user");
    process.exit(1);
  }
  if (SENT.length === 0) {
    console.error("\n❌ no reply produced — inspect manually");
    process.exit(1);
  }
  console.log("\n✅ GATE PASSED: non-owner command executed WITHOUT ReferenceError");
  process.exit(0);
})().catch(value16 => {
  if (/commandToggle is not defined/i.test(String(value16))) {
    console.error("\n❌ STILL BROKEN:", value16.message);
  } else {
    console.error("\nHarness error (non-gate):", value16.message);
    console.error("NOTE: any non-commandToggle error here is a harness-env limitation, not the gate bug.");
    process.exit(2);
  }
  process.exit(1);
});
