import { useState } from "react";
import { Pressable, StyleSheet, Switch, Text, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const menu = [
  { id: "account", icon: "person-outline" as const, title: "Account", subtitle: "Security notifications, change number" },
  { id: "privacy", icon: "lock-outline" as const, title: "Privacy", subtitle: "Blocked contacts, disappearing messages" },
  { id: "chats", icon: "chat-bubble-outline" as const, title: "Chats", subtitle: "Theme, wallpapers, chat history" },
  { id: "notifications", icon: "notifications-none" as const, title: "Notifications", subtitle: "Messages, groups, calls" },
];

export default function SettingsScreen() {
  const colors = useColors();
  const [readReceipts, setReadReceipts] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const notify = (message: string) => { setToast(message); setTimeout(() => setToast(null), 2200); };

  return (
    <ScreenContainer className="bg-background" edges={["top", "left", "right"]}>
      <StatusBar style="dark" />
      <View style={styles.header}><Text style={[styles.heading, { color: colors.foreground }]}>Settings</Text><Pressable onPress={() => notify("Settings search opened")} style={({ pressed }) => [styles.searchButton, pressed && styles.pressed]}><MaterialIcons name="search" size={23} color={colors.foreground}/></Pressable></View>
      <Pressable onPress={() => notify("Profile editor opened")} style={({ pressed }) => [styles.profileCard, pressed && styles.pressed]}><View style={[styles.profileAvatar, { backgroundColor: colors.primary }]}><Text style={styles.profileInitials}>AL</Text></View><View style={styles.profileCopy}><Text style={[styles.profileName, { color: colors.foreground }]}>Alex Morgan</Text><Text style={[styles.profileHandle, { color: colors.muted }]}>@alexm · available</Text></View><MaterialIcons name="qr-code-2" size={25} color={colors.primary}/></Pressable>
      <View style={styles.menuList}>{menu.map((item) => <Pressable key={item.id} onPress={() => notify(`${item.title} opened`)} style={({ pressed }) => [styles.menuRow, pressed && styles.pressed]}><View style={[styles.menuIcon, { backgroundColor: "rgba(245, 158, 11, 0.13)" }]}><MaterialIcons name={item.icon} size={21} color={colors.primary}/></View><View style={[styles.menuCopy, { borderBottomColor: colors.border }]}><Text style={[styles.menuTitle, { color: colors.foreground }]}>{item.title}</Text><Text style={[styles.menuSubtitle, { color: colors.muted }]} numberOfLines={1}>{item.subtitle}</Text></View><MaterialIcons name="chevron-right" size={21} color={colors.muted}/></Pressable>)}</View>
      <Text style={[styles.preferenceLabel, { color: colors.muted }]}>PREFERENCES</Text>
      <View style={[styles.preferenceCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.preferenceRow}><View style={[styles.preferenceIcon, { backgroundColor: "rgba(16,185,129,0.13)" }]}><MaterialIcons name="done-all" size={20} color={colors.success}/></View><View style={styles.preferenceCopy}><Text style={[styles.menuTitle, { color: colors.foreground }]}>Read receipts</Text><Text style={[styles.menuSubtitle, { color: colors.muted }]}>Let contacts know when you’ve read messages</Text></View><Switch value={readReceipts} onValueChange={(value) => { setReadReceipts(value); notify(value ? "Read receipts on" : "Read receipts off"); }} trackColor={{ false: colors.border, true: "#A7E8CD" }} thumbColor={readReceipts ? colors.success : "#FFFFFF"}/></View></View>
      <Text style={[styles.version, { color: colors.muted }]}>Pulse v1.0 · made for meaningful conversations</Text>
      {toast ? <View style={[styles.toast, { backgroundColor: colors.foreground }]}><Text style={styles.toastText}>{toast}</Text></View> : null}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingTop: 22, paddingBottom: 20 },
  heading: { fontSize: 32, lineHeight: 38, fontWeight: "800", letterSpacing: -1 },
  searchButton: { width: 37, height: 37, borderRadius: 19, alignItems: "center", justifyContent: "center" },
  pressed: { opacity: 0.58 },
  profileCard: { flexDirection: "row", alignItems: "center", marginHorizontal: 20, paddingBottom: 22, borderBottomWidth: 0 },
  profileAvatar: { width: 64, height: 64, borderRadius: 32, alignItems: "center", justifyContent: "center" },
  profileInitials: { color: "#FFFFFF", fontSize: 20, fontWeight: "800" },
  profileCopy: { flex: 1, marginLeft: 14 },
  profileName: { fontSize: 18, fontWeight: "800" },
  profileHandle: { fontSize: 13, marginTop: 5 },
  menuList: { marginTop: 10 },
  menuRow: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, minHeight: 73 },
  menuIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  menuCopy: { flex: 1, marginLeft: 13, paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  menuTitle: { fontSize: 14, fontWeight: "750" as any },
  menuSubtitle: { fontSize: 11, marginTop: 4 },
  preferenceLabel: { fontSize: 11, fontWeight: "800", letterSpacing: 1.2, marginHorizontal: 20, marginTop: 21, marginBottom: 10 },
  preferenceCard: { marginHorizontal: 20, borderRadius: 18, borderWidth: 1 },
  preferenceRow: { flexDirection: "row", alignItems: "center", padding: 14 },
  preferenceIcon: { width: 41, height: 41, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  preferenceCopy: { flex: 1, marginLeft: 12, paddingRight: 8 },
  version: { textAlign: "center", fontSize: 11, marginTop: 22 },
  toast: { position: "absolute", bottom: 24, left: 24, right: 24, paddingVertical: 13, borderRadius: 14, alignItems: "center" },
  toastText: { color: "#FFFFFF", fontSize: 13, fontWeight: "700" },
});
