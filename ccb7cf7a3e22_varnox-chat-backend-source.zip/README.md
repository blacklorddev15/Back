# Chat backend

Backend API for a WhatsApp-style messaging app: Postgres (Neon-compatible) +
Fastify + WebSocket. 31 TypeScript files (~8,000 lines), 6 SQL migrations
(90 tables, 211 indexes, 159 foreign keys).

**Status: Phase 1 is built and verified.** Registration, email OTP, sessions,
two-step PIN, profiles, contacts, blocking, 1:1 and group chat, messages with
the full edit/delete/react/star/pin/forward surface, attachments, read receipts,
search, notifications, and an admin/moderation API all work end to end.

**Not built:** voice/video calls, status/stories, channels, communities,
broadcast lists, business tools and payments. Their database schemas exist and
are migrated — the APIs are not written. See [Feature coverage](#feature-coverage).

---

## Verified state

Everything below was run against a real PostgreSQL 16 instance in this
workspace, not asserted from reading the code:

| Check | Result |
|---|---|
| `npm run migrate` | 6/6 applied cleanly, `0 pending` on re-run |
| Schema built | 90 tables, 2 views, 211 indexes, 159 FKs, 621 CHECK constraints |
| `npm run typecheck` | **0 errors** (strict mode) |
| `npm run build` | compiles to `dist/` |
| `tests/smoke.sh` | **71 assertions, 0 failures** |
| `npm run seed:admin` | creates a superadmin, exits 0 |

The smoke test boots the real server and exercises the flows that matter:
register → email OTP (including rejection of a wrong and a replayed code) →
login by email and phone → refresh rotation and reuse lockout → two-step PIN →
profile/privacy → contacts → direct chat → send/reply/idempotent resend → read
receipts → reactions → edit permission checks → star/pin → search → upload →
block/unblock with the send guard → report → account deletion.

Two real bugs were found and fixed *by* that test rather than by inspection:

1. **Direct chats could not pin anything.** `who_can_pin` defaults to `admins`,
   but a direct chat has no admins — so both participants were permanently
   locked out of pinning. Group-only policies are now no-ops on direct chats.
2. **`seed-admin` crashed** inserting its audit row: the same placeholder was
   used for a `uuid` column and a `text` column, which Postgres cannot type.

---

## Quick start

```bash
cp .env.example .env          # fill in DATABASE_URL + JWT_SECRET
npm install
npm run migrate               # schema
npm run seed:admin            # optional: create the first superadmin
npm run dev                   # http://localhost:8080
```

Then verify your own install end to end:

```bash
bash tests/smoke.sh
```

---

## Neon specifics (read this before deploying)

Neon is not "just Postgres" in three ways that shaped this codebase.

### 1. Two connection strings, and they are not interchangeable

```
DATABASE_URL        -> pooled   (host contains "-pooler")  → the API
DATABASE_URL_DIRECT -> direct   (no "-pooler")             → migrations only
```

Neon pools with PgBouncer in **transaction mode**, so a connection returns to
the pool after every transaction. The API uses the pooled endpoint; the
migration runner uses the direct one, because PgBouncer cannot reliably run DDL
that depends on session state. Neon's own docs recommend exactly this split.

### 2. Things that silently break behind the pooler

Because there is no persistent session, these are all unavailable — and they
fail in confusing ways rather than loudly:

| Unavailable | How this codebase avoids it |
|---|---|
| `LISTEN` / `NOTIFY` | Realtime fan-out is in-process (`src/realtime/hub.ts`) |
| Session advisory locks | `pg_advisory_xact_lock` — transaction-scoped |
| `SET` / `RESET` (incl. `search_path`) | No session variables anywhere |
| SQL-level `PREPARE` | node-postgres uses protocol-level statements |
| `WITH HOLD` cursors | Not used |

**The realtime consequence, stated plainly:** the WebSocket hub is
single-process. Two API instances behind a load balancer will not see each
other's events. To scale horizontally, add Redis pub/sub behind
`publishToUsers` — nothing else needs to change.

### 3. Every connection is TCP + TLS over the internet

`pool.on('error')` is handled, because a Neon compute that scales to zero will
kill idle connections, and an unhandled pool error would crash the process.

**Cost note:** free-tier compute suspends after ~5 minutes idle. The maintenance
loop runs every 5 minutes — deliberately not more often, since polling a
scale-to-zero database is a good way to keep it awake and burn CU-hours for
nothing.

---

## Architecture

```
src/
  config.ts              zod-validated env; refuses to boot in production with placeholder secrets
  index.ts               server, plugins, central error handler, graceful shutdown
  db/
    pool.ts              pooled + direct pools; withTransaction; advisory-lock helper
    migrate.ts           migration runner with checksums and drift detection
  lib/
    crypto.ts            scrypt passwords, HMAC+destination OTP hashing, AES-256-GCM at rest
    jwt.ts               HS256 access tokens (hard-coded algorithm)
    errors.ts            AppError + stable error codes
    mailer.ts            console | SMTP transports
    rate-limit.ts        in-memory windows + durable counters
    s3.ts                minimal SigV4 signer for one PUT
    validation.ts        shared zod schemas
  middleware/auth.ts     requireAuth, requireAdmin(role), account-status gate
  realtime/hub.ts        connection registry, presence, typing, fan-out
  services/              all business rules (auth, otp, users, contacts, chats, messages, media, notifications, audit)
  routes/                 thin HTTP layer only
migrations/              001 core · 002 social · 003 chats+messages · 004 communities/channels/status · 005 calls/business · 006 notifications/moderation
```

### Decisions worth knowing

**Enumerations are `text` + CHECK, never native `ENUM`.** Native enums cannot be
extended or reordered without an exclusive lock and a table rewrite. Across a
feature list this size, that becomes a deployment hazard.

**Messages carry a global `bigserial seq` alongside their uuid.** UUIDv4 has no
order, so paginating by timestamp breaks on ties — which are common. The seq
gives stable cursor pagination.

**Read state is a watermark, not a row per recipient.** Storing one receipt per
(message, recipient) would need 500,000 rows to answer "what is the tick state"
for a 500-member group with 1,000 messages. Instead each membership carries
`last_read_seq`. `message_receipts` still exists for the cases that need
per-user facts: direct chats and "who has read this".

**Passwords use scrypt from `node:crypto`, not bcrypt/argon2.** Both good
choices, both native modules requiring a compiler on every deploy target.
scrypt is memory-hard and built in.

**JWT is hand-rolled HS256.** This service only issues and verifies its own
tokens with one algorithm, which eliminates the algorithm-confusion class of
attacks — the algorithm is hard-coded and the header is never consulted for
algorithm selection. If you ever need asymmetric keys, use a vetted library
rather than extending this.

**Two-step verification uses a distinct token stage.** A password-correct-but-
PIN-missing login receives a `stage: 'two_step'` token that `requireAuth`
rejects. Without that, enabling the PIN would be theatre — the client could
ignore the challenge and use the token it was handed.

**Refresh tokens rotate, and reuse revokes every session.** Replaying a rotated
refresh token is treated as theft. The smoke test asserts this.

**Deletion is scheduled, not immediate.** Soft-delete plus a 30-day window, so
accidental or coerced deletion is recoverable and moderation keeps its trail.

---

## API surface

`Authorization: Bearer <accessToken>` on everything except the auth entry points.

**Auth** — `POST /auth/register` · `/auth/verify-email` · `/auth/resend-verification`
· `/auth/login` · `/auth/two-step/verify` · `/auth/refresh` · `/auth/logout`
· `/auth/logout/all` · `/auth/password/forgot` · `/auth/password/reset`
· `/auth/password/change` · `/auth/email/change/{request,confirm}`
· `/auth/phone/change` · `/auth/two-step/{enable,disable}` · `GET/POST /auth/devices`
· `/auth/security-log` · `/auth/account/delete{,/cancel}` · `/auth/session`
· `POST /auth/passkey/*` → **501, deliberately** (see below)

**Me** — `GET /me` · `PATCH /me/{profile,privacy,notifications,appearance}`
· `GET /me/privacy-checkup` · `POST/DELETE /me/push-token` · `POST /me/data-export`
· `GET /users/search`

**Social** — `GET/POST /contacts` · `PATCH/DELETE /contacts/:id` · `POST /contacts/sync`
· `GET/POST /contacts/labels` · `DELETE /contacts/labels/:id` · `GET/POST /blocks`
· `DELETE /blocks/:userId` · `POST /reports`

**Chats** — `GET /chats?filter=all|unread|groups|direct|archived|favorites`
· `POST /chats/{direct,group}` · `GET/PATCH /chats/:id` · `POST/DELETE /chats/:id/members`
· `POST /chats/:id/members/:userId/role` · `POST/DELETE /chats/:id/invites`
· `POST /chats/join/:code` · `POST /chats/join-requests/:id`
· `PATCH /chats/:id/settings` · `POST /chats/:id/{mute,lock,unlock,clear,read,unread,typing}`
· `GET /chats/:id/export`

**Messages** — `GET/POST /chats/:id/messages` · `GET/PATCH/DELETE /chats/:id/messages/:msgId`
(`?scope=everyone|me`) · `POST/DELETE .../reactions` · `POST .../star` · `POST .../pin`
· `GET /chats/:id/pinned` · `GET .../readers` · `POST /chats/:id/messages/{delivered,read}`
· `POST /messages/forward` · `GET /messages/starred` · `GET /messages/search`

**Media** — `POST /media/upload` (multipart, ≤50 MB)

**Realtime** — `GET /ws?token=…` · `GET /realtime/status` · `GET /ws/stats`

**Notifications** — `GET /notifications` · `GET /notifications/unread-count` · `POST /notifications/read`

**Admin** — `GET /admin/{stats,users,users/:id,reports,abuse-signals,audit-logs,tickets}`
· `POST /admin/users/:id/{suspend,unsuspend,verify,reset}` · `DELETE /admin/users/:id`
· `POST /admin/reports/:id` · `POST /admin/messages/:id/remove` · `POST /admin/tickets/:id/reply`
· `POST /admin/announcements` · `POST/DELETE /admin/roles` (superadmin only)

---

## Feature coverage

Against your checklist. "Schema" means the tables are migrated but no API reads
or writes them yet.

| # | Area | State |
|---|---|---|
| 1 | Registration & accounts | **Built** — email+phone registration, 6-digit email OTP with expiry/resend cooldown/attempt cap/hourly limits, login by email/phone/username, recovery, email & phone change, uniqueness checks, logout everywhere, new-device email alerts, two-step PIN + backup codes, profiles, username, devices. *Passkeys return 501 by design.* |
| 2 | Private chat | **Built** — send/reply/forward/edit/delete-for-me/delete-for-everyone, star, pin, read/unread, reactions, mentions, sent/delivered/read, idempotent resend, typing, online/last-seen, disappearing messages, view-once flags, search, per-chat wallpaper/theme, mute, archive, chat lock + code, clear, export, block, report |
| 3 | Media & files | **Partial** — upload + send photos/videos/docs/audio/voice/GIF/stickers with metadata; gallery query via search filters. *Missing: in-app camera, crop/rotate/draw/annotate, video trimming, recording pause/resume, playback speed, transcription, link-preview fetching, thumbnails, transcoding* |
| 4 | Voice & video calls | **Schema only** — `calls`, `call_participants`, `call_events`, `call_links`. No signalling. Calls need WebRTC + TURN, which is a separate build |
| 5 | Group chats | **Mostly built** — create, name/photo/description, add/remove, admin roles with owner protection, invite links + QR payload, join approval, restrict send/edit/add/pin, announcements, mentions, labels, ban, leave, system messages. *Missing: polls API, events API, group calls* |
| 6 | Communities | **Schema only** — 7 tables migrated, no API |
| 7 | Status / stories | **Schema only** — 6 tables migrated, no API |
| 8 | Privacy & security | **Mostly built** — visibility controls, read receipts, block/report, privacy checkup, device management + remote logout, login alerts, deletion with recovery window, export requests. *Missing: E2EE (see below), passkeys, encrypted backups, spam/scam detectors (tables exist, no engine)* |
| 9 | Contacts & discovery | **Built** — sync-and-match, search by email/phone/username, add/remove, labels, favourites, blocked list, discoverability controls. *Missing: QR generation (payload only)* |
| 10 | Notifications | **Built** — per-message/group notifications, mute, privacy levels, Expo push with per-device delivery tracking and dead-token pruning, in-app realtime, unread counts, email security alerts. *Missing: call notifications (no call API)* |
| 11 | Search & organisation | **Mostly built** — all-chat and per-chat search, type/sender/date filters, pinned, archived, favourites, unread filter, starred, sort by activity. *Missing: chat folders, separate photo/video/doc search endpoints (a type filter covers this)* |
| 12 | Devices & platforms | **Partial** — device list, remote logout, push, multiple sessions. *Missing: QR device-linking flow, web/desktop/tablet clients* |
| 13 | Broadcast messaging | **Schema only** — 3 tables, no API |
| 14 | Payments & shopping | **Schema only** — carts, orders, payments, catalog |
| 15 | Business tools | **Schema only** — business profile, catalog, collections, replies, templates, links |
| 16 | Accessibility | Client concern — nothing server-side |
| 17 | Administration | **Mostly built** — roles with hierarchy, user search/view/suspend/delete/verify/reset, report review, content removal, audit log, abuse-signal view, support tickets, announcements, platform stats + 30-day growth |

### Two honest caveats

**End-to-end encryption is not implemented, and it is not a bolt-on.** The
Signal Protocol needs per-device key management, ratcheting, multi-device
session handling and encrypted backups — realistically as much work as
everything above. It also conflicts with features you asked for: server-side
search, transcription, and spam/scam detection all require readable plaintext.
Choosing E2EE means moving those to on-device models. Decide deliberately.

**"Delete for everyone", "view once" and "screenshot protection" are
client-enforced.** On a rooted device they can be bypassed. The server does its
part — view-once media is consumed on read, and deleted attachments are purged —
but these should never be marketed as guarantees.

---

## Before you go live

1. **Change `JWT_SECRET`.** Boot refuses to start in production with a
   placeholder, but generate a real one: `openssl rand -base64 48`.
2. **Configure SMTP with a verified domain.** Dev uses the console transport.
   Without SPF/DKIM/DMARC on your sending domain, OTP emails land in spam and it
   will look like a bug in the OTP logic.
3. **Add a breach-list check to password validation.** Length rules are in
   place; checking against Have I Been Pwned's k-anonymity API is the highest
   value next step and costs one HTTP call.
4. **Move media to object storage.** `MEDIA_DRIVER=local` needs a mounted volume
   and a reverse proxy to serve it. Files never belong in Postgres.
5. **Point `MEDIA_PUBLIC_BASE_URL` at a private bucket with signed URLs** if any
   of your content should not be publicly readable — uploads are currently
   served by opaque key only.
6. **Replace the in-memory rate limiter with Redis** once you run more than one
   instance, or each instance grants the full allowance independently.
7. **Move the maintenance loop out of process** when you scale, so N instances
   do not all run the same purge.
8. **Add a database backup schedule.** Neon provides point-in-time restore
   within the history window; verify you know your window before you need it.

---

## Roadmap

| Phase | Scope |
|---|---|
| **1 (done)** | Auth, profiles, contacts, 1:1 + group chat, messages, media, notifications, admin |
| **2** | WebRTC calls (needs TURN), status/stories, polls + events APIs |
| **3** | Channels, communities, broadcast lists |
| **4** | Business tools, catalogs, orders, payments |

Each phase starts with its API against the schemas already migrated, so no
further data-model work is required to begin any of them.
