#!/usr/bin/env bash
# End-to-end smoke test.
#
# Boots the real server against the real database and walks the flows that
# matter: register -> email OTP -> verify -> login -> chat -> message ->
# receipts -> search -> notifications -> admin. Every step asserts, so a
# regression fails loudly instead of printing a cheerful "ok".
#
#   ./tests/smoke.sh
#
# Requires a reachable Postgres and a migrated schema (npm run migrate).
set -uo pipefail

BASE="${BASE:-http://127.0.0.1:8080}"
LOG="${LOG:-/tmp/smoke-server.log}"
PASS=0
FAIL=0

say()  { printf '\n\033[1m%s\033[0m\n' "$*"; }
ok()   { printf '  \033[32mPASS\033[0m %s\n' "$*"; PASS=$((PASS+1)); }
bad()  { printf '  \033[31mFAIL\033[0m %s\n' "$*"; FAIL=$((FAIL+1)); }

# assert <description> <actual> <expected>
assert_eq() {
  if [ "$2" = "$3" ]; then ok "$1 ($2)"; else bad "$1 — expected '$3', got '$2'"; fi
}

# assert_nonempty <description> <value>
assert_nonempty() {
  if [ -n "$2" ] && [ "$2" != "null" ]; then ok "$1"; else bad "$1 — empty"; fi
}

# --- helpers ---------------------------------------------------------------
jqv() { node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{try{const o=JSON.parse(s);const p=process.argv[1].split(".");let v=o;for(const k of p){v=v?.[k];}process.stdout.write(v===undefined||v===null?"":String(v));}catch(e){process.stdout.write("")}})' "$1"; }

# Pulls the newest OTP for a purpose out of the server log (console transport).
otp_for() {
  grep -oE "Your verification code is: [0-9]{6}" "$LOG" | tail -1 | grep -oE '[0-9]{6}'
}

api() { # api <method> <path> <token|-> [json]
  local method="$1" path="$2" token="$3" body="${4:-}"
  if [ "$token" = "-" ]; then
    if [ -n "$body" ]; then
      curl -sS -X "$method" "$BASE$path" -H 'Content-Type: application/json' -d "$body" -w '\n%{http_code}'
    else
      curl -sS -X "$method" "$BASE$path" -w '\n%{http_code}'
    fi
  else
    if [ -n "$body" ]; then
      curl -sS -X "$method" "$BASE$path" -H "Authorization: Bearer $token" -H 'Content-Type: application/json' -d "$body" -w '\n%{http_code}'
    else
      curl -sS -X "$method" "$BASE$path" -H "Authorization: Bearer $token" -w '\n%{http_code}'
    fi
  fi
}

body_of() { printf '%s' "$1" | sed '$d'; }   # drop the trailing status line
code_of() { printf '%s' "$1" | tail -1; }

# --- boot ------------------------------------------------------------------
say "Starting server"
: > "$LOG"
node --import tsx src/index.ts >"$LOG" 2>&1 &
SERVER_PID=$!
trap 'kill $SERVER_PID 2>/dev/null' EXIT

for i in $(seq 1 40); do
  if curl -sf "$BASE/health" >/dev/null 2>&1; then break; fi
  sleep 0.5
done
if ! curl -sf "$BASE/health" >/dev/null 2>&1; then
  bad "server did not become healthy — see $LOG"
  tail -30 "$LOG"
  exit 1
fi
ok "server is healthy (pid $SERVER_PID)"

say "Health & readiness"
R=$(api GET /health/ready -)
assert_eq "readiness reports ready" "$(body_of "$R" | jqv status)" "ready"
assert_eq "database reachable" "$(body_of "$R" | jqv database.ok)" "true"

SUFFIX=$(date +%s)
EMAIL_A="alice.$SUFFIX@example.com"
EMAIL_B="bob.$SUFFIX@example.com"
PHONE_A="+6591${SUFFIX: -6}"
PHONE_B="+6592${SUFFIX: -6}"
PASSWORD="Correct-Horse-Battery-9"

say "Registration (email + phone, code delivered to email)"
R=$(api POST /auth/register - "{\"fullName\":\"Alice Example\",\"email\":\"$EMAIL_A\",\"phone\":\"$PHONE_A\",\"password\":\"$PASSWORD\"}")
assert_eq "register returns 201" "$(code_of "$R")" "201"
assert_nonempty "userId returned" "$(body_of "$R" | jqv userId)"
assert_eq "account starts pending" "$(body_of "$(api POST /auth/login - "{\"identifier\":\"$EMAIL_A\",\"password\":\"$PASSWORD\"}")" | jqv error)" "email_not_verified"

# An account that exists but was never verified must be RETRYABLE, not "taken".
# Otherwise a single transient mail failure strands the user forever: the first
# request wrote the row, and every retry would hit email_taken.
R=$(api POST /auth/register - "{\"fullName\":\"Alice Again\",\"email\":\"$EMAIL_A\",\"phone\":\"$PHONE_A\",\"password\":\"$PASSWORD\"}")
assert_eq "unverified duplicate retries instead of erroring" "$(code_of "$R")" "201"

say "Email OTP verification"
CODE=$(otp_for)
assert_nonempty "OTP appeared in the mail transport log" "$CODE"

R=$(api POST /auth/verify-email - "{\"email\":\"$EMAIL_A\",\"code\":\"000000\",\"device\":{\"platform\":\"android\",\"deviceName\":\"Pixel 8\"}}")
assert_eq "wrong OTP rejected" "$(body_of "$R" | jqv error)" "otp_invalid"

R=$(api POST /auth/verify-email - "{\"email\":\"$EMAIL_A\",\"code\":\"$CODE\",\"device\":{\"platform\":\"android\",\"deviceName\":\"Pixel 8\"}}")
assert_eq "correct OTP accepted" "$(code_of "$R")" "200"
TOKEN_A=$(body_of "$R" | jqv tokens.accessToken)
REFRESH_A=$(body_of "$R" | jqv tokens.refreshToken)
USER_A=$(body_of "$R" | jqv user.id)
assert_nonempty "access token issued" "$TOKEN_A"
assert_eq "email marked verified" "$(body_of "$R" | jqv user.emailVerified)" "true"

R=$(api POST /auth/verify-email - "{\"email\":\"$EMAIL_A\",\"code\":\"$CODE\"}")
assert_eq "OTP cannot be replayed" "$(body_of "$R" | jqv error)" "otp_invalid"

# Now that the account is active, a duplicate registration must be refused.
R=$(api POST /auth/register - "{\"fullName\":\"Impostor\",\"email\":\"$EMAIL_A\",\"phone\":\"+65918888888\",\"password\":\"$PASSWORD\"}")
assert_eq "verified duplicate email rejected" "$(code_of "$R")" "409"
assert_eq "  with email_taken code" "$(body_of "$R" | jqv error)" "email_taken"

say "Login, sessions and two-step verification"
R=$(api POST /auth/login - "{\"identifier\":\"$EMAIL_A\",\"password\":\"wrong-password\"}")
assert_eq "wrong password rejected" "$(code_of "$R")" "401"
assert_eq "  generic error (no user enumeration)" "$(body_of "$R" | jqv error)" "invalid_credentials"

R=$(api POST /auth/login - "{\"identifier\":\"$PHONE_A\",\"password\":\"$PASSWORD\",\"device\":{\"platform\":\"ios\",\"deviceName\":\"iPhone 15\"}}")
assert_eq "login by phone number works" "$(code_of "$R")" "200"

R=$(api POST /auth/login - "{\"identifier\":\"$EMAIL_A\",\"password\":\"$PASSWORD\"}")
TOKEN_A=$(body_of "$R" | jqv tokens.accessToken)
REFRESH_A=$(body_of "$R" | jqv tokens.refreshToken)

R=$(api POST /auth/refresh - "{\"refreshToken\":\"$REFRESH_A\"}")
assert_eq "refresh rotates a session" "$(code_of "$R")" "200"
REFRESH_A2=$(body_of "$R" | jqv tokens.refreshToken)
TOKEN_A=$(body_of "$R" | jqv tokens.accessToken)

R=$(api POST /auth/refresh - "{\"refreshToken\":\"$REFRESH_A\"}")
assert_eq "reused refresh token rejected" "$(code_of "$R")" "401"

# Reusing a rotated refresh token is treated as theft, and the correct response
# is to revoke EVERY session for that user — which necessarily includes the
# token we just issued. So sign in again rather than expecting the old one to
# still work.
R=$(api POST /auth/login - "{\"identifier\":\"$EMAIL_A\",\"password\":\"$PASSWORD\"}")
assert_eq "sign-in works again after reuse lockout" "$(code_of "$R")" "200"
TOKEN_A=$(body_of "$R" | jqv tokens.accessToken)

R=$(api POST /auth/two-step/enable "$TOKEN_A" "{\"password\":\"$PASSWORD\",\"pin\":\"123456\"}")
assert_eq "two-step enabled" "$(code_of "$R")" "200"
BACKUP=$(body_of "$R" | jqv backupCodes)
assert_nonempty "backup codes issued" "$BACKUP"

R=$(api POST /auth/login - "{\"identifier\":\"$EMAIL_A\",\"password\":\"$PASSWORD\"}")
assert_eq "login now requires two-step" "$(body_of "$R" | jqv twoStepRequired)" "true"
CHALLENGE=$(body_of "$R" | jqv challengeToken)

R=$(api GET /me "$CHALLENGE")
assert_eq "challenge token cannot access the API" "$(code_of "$R")" "403"

R=$(api POST /auth/two-step/verify - "{\"challengeToken\":\"$CHALLENGE\",\"pin\":\"000000\",\"device\":{\"platform\":\"android\"}}")
assert_eq "wrong PIN rejected" "$(code_of "$R")" "401"

R=$(api POST /auth/two-step/verify - "{\"challengeToken\":\"$CHALLENGE\",\"pin\":\"123456\",\"device\":{\"platform\":\"android\",\"deviceName\":\"Smoke Test\"}}")
assert_eq "correct PIN completes sign-in" "$(code_of "$R")" "200"
TOKEN_A=$(body_of "$R" | jqv tokens.accessToken)

R=$(api POST /auth/two-step/disable "$TOKEN_A" "{\"password\":\"$PASSWORD\"}")
assert_eq "two-step disabled again" "$(code_of "$R")" "200"
R=$(api POST /auth/login - "{\"identifier\":\"$EMAIL_A\",\"password\":\"$PASSWORD\"}")
TOKEN_A=$(body_of "$R" | jqv tokens.accessToken)

say "Profile, privacy and discovery"
R=$(api PATCH /me/profile "$TOKEN_A" '{"displayName":"Alice","about":"Building things","countryCode":"SG"}')
assert_eq "profile updated" "$(code_of "$R")" "200"

R=$(api PATCH /me/privacy "$TOKEN_A" '{"lastSeenVisibility":"nobody","readReceiptsEnabled":false}')
assert_eq "privacy updated" "$(code_of "$R")" "200"
assert_eq "  last_seen now nobody" "$(body_of "$R" | jqv privacy.last_seen_visibility)" "nobody"

R=$(api GET /me/privacy-checkup "$TOKEN_A")
assert_nonempty "privacy checkup returns findings" "$(body_of "$R" | jqv findings.0.key)"

# Second account for the chat tests.
api POST /auth/register - "{\"fullName\":\"Bob Example\",\"email\":\"$EMAIL_B\",\"phone\":\"$PHONE_B\",\"password\":\"$PASSWORD\"}" >/dev/null
CODE_B=$(otp_for)
R=$(api POST /auth/verify-email - "{\"email\":\"$EMAIL_B\",\"code\":\"$CODE_B\",\"device\":{\"platform\":\"web\",\"deviceName\":\"Firefox\"}}")
TOKEN_B=$(body_of "$R" | jqv tokens.accessToken)
USER_B=$(body_of "$R" | jqv user.id)
assert_nonempty "second account registered and verified" "$TOKEN_B"

# Usernames are globally unique, so a fixed one would collide on the second run.
USERNAME_B="bob_$SUFFIX"
R=$(api POST /auth/username "$TOKEN_B" "{\"username\":\"$USERNAME_B\"}")
assert_eq "username claimed" "$(code_of "$R")" "200"

R=$(api GET "/users/search?q=$USERNAME_B" "$TOKEN_A")
assert_eq "user search finds Bob by username" "$(body_of "$R" | jqv results.0.username)" "$USERNAME_B"

R=$(api POST /contacts "$TOKEN_A" "{\"contactUserId\":\"$USER_B\",\"displayName\":\"Bob\"}")
assert_eq "contact added" "$(code_of "$R")" "201"

say "Direct chat and messages"
R=$(api POST /chats/direct "$TOKEN_A" "{\"userId\":\"$USER_B\"}")
assert_eq "direct chat created" "$(code_of "$R")" "201"
CHAT=$(body_of "$R" | jqv chatId)
assert_nonempty "chatId returned" "$CHAT"

R=$(api POST /chats/direct "$TOKEN_A" "{\"userId\":\"$USER_B\"}")
assert_eq "same chat returned (one per pair)" "$(body_of "$R" | jqv chatId)" "$CHAT"
assert_eq "  and not created twice" "$(body_of "$R" | jqv created)" "false"

R=$(api POST "/chats/$CHAT/messages" "$TOKEN_A" '{"body":"Hello Bob, this is a smoke test","clientId":"smoke-1"}')
assert_eq "message sent" "$(code_of "$R")" "201"
MSG=$(body_of "$R" | jqv message.id)
assert_nonempty "message id returned" "$MSG"
# The send response must be the hydrated camelCase shape, identical to what the
# list endpoint returns. A raw row would arrive with snake_case keys and an
# undefined senderId, and the client would render it as the other person's.
assert_eq "send response is camelCase (senderId)" "$(body_of "$R" | jqv message.senderId)" "$USER_A"
assert_nonempty "send response carries createdAt" "$(body_of "$R" | jqv message.createdAt)"
assert_eq "send response has no snake_case leak" "$(body_of "$R" | jqv message.chat_id)" ""

R=$(api POST "/chats/$CHAT/messages" "$TOKEN_A" '{"body":"Hello Bob, this is a smoke test","clientId":"smoke-1"}')
assert_eq "duplicate clientId is idempotent" "$(body_of "$R" | jqv message.id)" "$MSG"

R=$(api POST "/chats/$CHAT/messages" "$TOKEN_A" '{"body":"Reply from Alice","replyToId":"'"$MSG"'"}')
assert_eq "reply accepted" "$(code_of "$R")" "201"

R=$(api GET "/chats/$CHAT/messages?limit=10" "$TOKEN_B")
assert_eq "Bob can read the conversation" "$(code_of "$R")" "200"
LAST_SEQ=$(body_of "$R" | jqv messages.0.seq)
assert_nonempty "messages returned to Bob" "$LAST_SEQ"

R=$(api GET "/chats/$CHAT" "$TOKEN_B")
assert_eq "Bob can fetch chat details" "$(code_of "$R")" "200"
assert_eq "  member count is 2" "$(body_of "$R" | jqv chat.member_count)" "2"

say "Acknowledgement, editing and reactions"
R=$(api POST "/chats/$CHAT/messages/read" "$TOKEN_B" "{\"upToSeq\":$LAST_SEQ}")
assert_eq "Bob marks messages read" "$(code_of "$R")" "200"
assert_eq "  watermark advanced" "$(body_of "$R" | jqv lastReadSeq)" "$LAST_SEQ"

R=$(api POST "/chats/$CHAT/messages/$MSG/reactions" "$TOKEN_B" '{"emoji":"👍"}')
assert_eq "reaction added" "$(code_of "$R")" "201"

R=$(api PATCH "/chats/$CHAT/messages/$MSG" "$TOKEN_B" '{"body":"Bob should not be able to edit this"}')
assert_eq "non-author cannot edit" "$(code_of "$R")" "403"

R=$(api PATCH "/chats/$CHAT/messages/$MSG" "$TOKEN_A" '{"body":"Hello Bob, this is an edited smoke test"}')
assert_eq "author can edit" "$(code_of "$R")" "200"
assert_nonempty "  editedAt set" "$(body_of "$R" | jqv message.editedAt)"

R=$(api POST "/chats/$CHAT/messages/$MSG/star" "$TOKEN_A" '{"starred":true}')
assert_eq "message starred" "$(code_of "$R")" "200"
R=$(api GET /messages/starred "$TOKEN_A")
assert_eq "starred list contains it" "$(body_of "$R" | jqv messages.0.id)" "$MSG"

R=$(api POST "/chats/$CHAT/messages/$MSG/pin" "$TOKEN_A" '{"pinned":true}')
assert_eq "message pinned" "$(code_of "$R")" "200"

say "Search and unread counts"
R=$(api GET "/messages/search?q=smoke" "$TOKEN_A")
assert_eq "full-text search finds the message" "$(code_of "$R")" "200"
assert_eq "  correct message returned" "$(body_of "$R" | jqv messages.0.id)" "$MSG"

R=$(api GET "/chats?filter=unread" "$TOKEN_A")
assert_eq "chat list query works" "$(code_of "$R")" "200"
R=$(api GET /notifications/unread-count "$TOKEN_B")
assert_eq "notification counter works" "$(code_of "$R")" "200"

say "Attachments"
TMP=$(mktemp /tmp/smoke-XXXXXX.png)
printf '\x89PNG\r\n\x1a\n fake png bytes for the smoke test' > "$TMP"
UP=$(curl -sS -X POST "$BASE/media/upload" -H "Authorization: Bearer $TOKEN_A" -F "file=@$TMP;type=image/png")
assert_nonempty "image upload stored" "$(printf '%s' "$UP" | jqv attachment.storageKey)"
assert_eq "  sha256 computed" "$(printf '%s' "$UP" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{const o=JSON.parse(s);process.stdout.write(String(o.attachment.sha256.length))})')" "64"
SK=$(printf '%s' "$UP" | jqv attachment.storageKey)
R=$(api POST "/chats/$CHAT/messages" "$TOKEN_A" "{\"type\":\"image\",\"attachments\":[{\"kind\":\"image\",\"mimeType\":\"image/png\",\"fileName\":\"smoke.png\",\"byteSize\":44,\"storageDriver\":\"local\",\"storageKey\":\"$SK\"}]}")
assert_eq "image message sent" "$(code_of "$R")" "201"

say "Attachment delivery and access control"
AID=$(body_of "$R" | jqv message.attachments.0.id)
IMG_MSG=$(body_of "$R" | jqv message.id)
assert_nonempty "attachment id returned with the message" "$AID"

# A third account that is NOT in the chat, to prove the membership check.
api POST /auth/register - "{\"fullName\":\"Carol Example\",\"email\":\"carol.$SUFFIX@example.com\",\"phone\":\"+6593${SUFFIX: -6}\",\"password\":\"$PASSWORD\"}" >/dev/null
R=$(api POST /auth/verify-email - "{\"email\":\"carol.$SUFFIX@example.com\",\"code\":\"$(otp_for)\",\"device\":{\"platform\":\"android\"}}")
TOKEN_C=$(body_of "$R" | jqv tokens.accessToken)
assert_nonempty "third (non-member) account ready" "$TOKEN_C"

DL=/tmp/smoke-attachment.bin
HTTP=$(timeout 20 curl -sS -o "$DL" -w '%{http_code}' "$BASE/attachments/$AID?token=$TOKEN_A")
assert_eq "member downloads the attachment" "$HTTP" "200"
assert_eq "delivered bytes are byte-identical" "$(sha256sum "$DL" | cut -d' ' -f1)" "$(sha256sum "$TMP" | cut -d' ' -f1)"
assert_eq "correct content type" "$(timeout 20 curl -sS -D - -o /dev/null "$BASE/attachments/$AID?token=$TOKEN_A" | grep -i '^content-type' | tr -d '\r' | awk '{print $2}')" "image/png"

HTTP=$(timeout 20 curl -sS -o /dev/null -w '%{http_code}' "$BASE/attachments/$AID")
assert_eq "no token is rejected" "$HTTP" "401"

HTTP=$(timeout 20 curl -sS -o /dev/null -w '%{http_code}' "$BASE/attachments/$AID?token=not-a-real-token")
assert_eq "bogus token is rejected" "$HTTP" "401"

HTTP=$(timeout 20 curl -sS -o /dev/null -w '%{http_code}' "$BASE/attachments/$AID?token=$TOKEN_C")
assert_eq "non-member cannot read it (404, not 403)" "$HTTP" "404"

HTTP=$(timeout 20 curl -sS -o /dev/null -w '%{http_code}' "$BASE/attachments/00000000-0000-4000-8000-000000000000?token=$TOKEN_A")
assert_eq "unknown attachment id is 404" "$HTTP" "404"

# Delete for everyone must revoke the file, not just hide the bubble.
R=$(api DELETE "/chats/$CHAT/messages/$IMG_MSG?scope=everyone" "$TOKEN_A")
assert_eq "author deletes the image for everyone" "$(code_of "$R")" "200"
HTTP=$(timeout 20 curl -sS -o /dev/null -w '%{http_code}' "$BASE/attachments/$AID?token=$TOKEN_A")
assert_eq "deleted message's attachment is gone" "$HTTP" "404"

say "Blocking and reporting"
R=$(api POST /blocks "$TOKEN_B" "{\"userId\":\"$USER_A\",\"reason\":\"smoke test\"}")
assert_eq "Bob blocks Alice" "$(code_of "$R")" "201"
R=$(api POST "/chats/$CHAT/messages" "$TOKEN_A" '{"body":"This should be blocked"}')
assert_eq "blocked sender is refused" "$(code_of "$R")" "403"
assert_eq "  with blocked code" "$(body_of "$R" | jqv error)" "blocked_by_recipient"
R=$(api DELETE "/blocks/$USER_A" "$TOKEN_B")
assert_eq "unblock works" "$(code_of "$R")" "200"
R=$(api POST "/chats/$CHAT/messages" "$TOKEN_A" '{"body":"Delivered after unblock"}')
assert_eq "messages resume after unblock" "$(code_of "$R")" "201"

R=$(api POST /reports "$TOKEN_A" "{\"targetType\":\"user\",\"targetId\":\"$USER_B\",\"reason\":\"spam\",\"details\":\"smoke test\"}")
assert_eq "report accepted" "$(code_of "$R")" "201"

say "Account deletion and recovery"
R=$(api POST /auth/account/delete "$TOKEN_B" '{}')
assert_eq "deletion scheduled" "$(code_of "$R")" "200"
R=$(api POST /auth/login - "{\"identifier\":\"$EMAIL_B\",\"password\":\"$PASSWORD\"}")
assert_eq "deactivated account cannot sign in" "$(code_of "$R")" "403"

say "Summary"
printf '\n  passed: %s   failed: %s\n' "$PASS" "$FAIL"
[ "$FAIL" -eq 0 ] || { printf '\n--- server log tail ---\n'; tail -40 "$LOG"; }
exit $([ "$FAIL" -eq 0 ] && echo 0 || echo 1)
