import cors from '@fastify/cors';
import multipart from '@fastify/multipart';
import websocket from '@fastify/websocket';
import Fastify, { type FastifyInstance } from 'fastify';
import { createWriteStream, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { PassThrough } from 'node:stream';
import { ZodError } from 'zod';
import { config } from './config.js';
import { closePool, databaseTarget, initialiseDatabase, query } from './db/pool.js';
import { AppError, ErrorCodes } from './lib/errors.js';
import { prunePersistentCounters } from './lib/rate-limit.js';
import { hubStats, shutdownHub } from './realtime/hub.js';
import { registerRoutes } from './routes/index.js';
import { purgeExpired } from './services/messages.service.js';
import { pruneExpiredOtps } from './services/otp.service.js';

/**
 * Application entrypoint.
 *
 * Startup order matters: configuration is validated on import (config.ts calls
 * process.exit on a bad environment), then plugins, then routes, and only then
 * does the server accept traffic. Background jobs start last so a failure in
 * them cannot prevent the API from serving.
 */

/**
 * Logger configuration.
 *
 * Redaction is non-negotiable: the auth endpoints receive passwords, OTP codes,
 * PINs and refresh tokens in request bodies, and a log file is much easier to
 * read than a database.
 *
 * When LOG_FILE is set the output is teed to both stdout and the file. On
 * Pterodactyl only stdout exists and it is not exposed, so the file is the only
 * way to see an error after the fact.
 */
function buildLoggerOptions(): Record<string, unknown> {
  const base = {
    level: config.LOG_LEVEL,
    redact: {
      paths: [
        'req.headers.authorization',
        'req.headers.cookie',
        'req.body.password',
        'req.body.newPassword',
        'req.body.currentPassword',
        'req.body.code',
        'req.body.pin',
        'req.body.refreshToken',
        'req.body.challengeToken',
        'req.query.token',
        'password',
        'pin',
        'code',
        'authorization',
        'apiKey',
      ],
      censor: '[redacted]',
    },
  };

  if (!config.LOG_FILE) return base;

  const filePath = resolve(config.LOG_FILE);
  try {
    mkdirSync(dirname(filePath), { recursive: true });
    const tee = new PassThrough();
    tee.pipe(createWriteStream(filePath, { flags: 'a' }));
    tee.pipe(process.stdout);
    // eslint-disable-next-line no-console
    console.log(`[logger] also writing to ${filePath}`);
    return { ...base, stream: tee };
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error(`[logger] could not open ${filePath}: ${(err as Error).message} — logging to stdout only`);
    return base;
  }
}

export async function buildServer(): Promise<FastifyInstance> {
  const app = Fastify({
    logger: buildLoggerOptions(),
    // Behind a reverse proxy (Caddy, nginx, a PaaS router) this is required for
    // request.ip to be the real client. Only enable it when you actually have a
    // proxy in front — trusting X-Forwarded-For blindly lets any client spoof
    // its own address and defeat IP-based rate limiting.
    trustProxy: true,
    bodyLimit: 1_048_576, // 1 MB of JSON; files go through multipart, not JSON
    disableRequestLogging: config.isProduction,
  });

  await app.register(cors, {
    origin: config.corsOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  });

  await app.register(multipart, {
    limits: {
      fileSize: config.MEDIA_MAX_UPLOAD_BYTES,
      files: 1,
      fields: 20,
    },
  });

  await app.register(websocket, {
    options: {
      maxPayload: 1_048_576,
      // Chat clients sit idle for long stretches; a shorter timeout would
      // disconnect them unnecessarily. The hub heartbeat detects dead sockets.
      clientTracking: false,
    },
  });

  // ---------------------------------------------------------------------------
  // Database selection — before any route can serve a request.
  //
  // Candidates are probed for reachability AND schema freshness; the first that
  // passes wins, and the choice is fixed for the life of the process. If none
  // pass this throws, so a misconfigured or under-migrated database fails at
  // boot with a readable reason instead of 500-ing on every request.
  // ---------------------------------------------------------------------------
  const selection = await initialiseDatabase();
  app.log.info(
    {
      database: selection.target.label,
      pooledEndpoint: selection.target.pooler,
      migrationsApplied: selection.target.appliedMigrations,
    },
    'database selected',
  );

  const rejected = selection.tried.filter((t) => !t.ok);
  if (rejected.length > 0) {
    // Worth a warning rather than info: it means the primary was unusable and
    // the app fell back, which is a data-consistency decision, not just a blip.
    app.log.warn(
      { rejected },
      `fell back past ${rejected.length} unusable database candidate(s) — confirm this is the intended dataset`,
    );
  }

  // ---------------------------------------------------------------------------
  // Health & readiness
  // ---------------------------------------------------------------------------
  app.get('/health', async () => ({ status: 'ok', uptimeSeconds: Math.round(process.uptime()) }));

  app.get('/health/ready', async (_request, reply) => {
    try {
      // Round-trips to the database, so this fails when Neon is paused or the
      // pooler is unreachable — which is exactly what readiness should detect.
      const started = Date.now();
      await query('SELECT 1 AS ok');
      const target = databaseTarget();
      return {
        status: 'ready',
        database: {
          ok: true,
          latencyMs: Date.now() - started,
          // Which database is actually in use, so you can tell at a glance
          // whether a failover happened — masked to host/db, never credentials.
          target: target?.label ?? null,
          pooled: target?.pooler ?? config.DB_IS_POOLED,
          migrationsApplied: target?.appliedMigrations ?? null,
        },
        realtime: hubStats(),
      };
    } catch (err) {
      app.log.error({ err }, 'readiness check failed');
      return reply.code(503).send({
        status: 'unavailable',
        database: { ok: false, error: (err as Error).message },
      });
    }
  });

  await registerRoutes(app);

  // ---------------------------------------------------------------------------
  // Central error handling
  // ---------------------------------------------------------------------------
  app.setErrorHandler((error, request, reply) => {
    // Fastify types the handler's error as unknown unless the instance is
    // parameterised. Narrow it once here rather than casting at every use.
    const err = error as Error & { statusCode?: number; code?: string };

    // Our own errors carry their status and a stable machine-readable code.
    if (error instanceof AppError) {
      if (error.statusCode >= 500) {
        request.log.error({ err: error }, 'application error');
      }
      return reply.code(error.statusCode).send({
        error: error.code,
        message: error.message,
        ...(error.details !== undefined ? { details: error.details } : {}),
      });
    }

    // Validation failures from zod get a field-level breakdown, which is far
    // more useful to a client than "Bad Request".
    if (error instanceof ZodError) {
      return reply.code(400).send({
        error: ErrorCodes.VALIDATION_FAILED,
        message: 'The request body or query is invalid',
        details: error.issues.map((issue) => ({
          path: issue.path.join('.'),
          message: issue.message,
        })),
      });
    }

    // Fastify's own client errors (bad JSON, payload too large, etc.)
    if (typeof err.statusCode === 'number' && err.statusCode < 500) {
      return reply.code(err.statusCode).send({
        error: err.code ?? 'bad_request',
        message: err.message,
      });
    }

    // A unique-violation that slipped past a pre-check is a conflict, not a
    // server fault. Surfacing it as 409 keeps the client's retry logic sane.
    const pgCode = err.code;
    if (pgCode === '23505') {
      return reply.code(409).send({ error: ErrorCodes.CONFLICT, message: 'That record already exists' });
    }
    if (pgCode === '23503') {
      return reply.code(400).send({ error: ErrorCodes.VALIDATION_FAILED, message: 'Referenced record does not exist' });
    }

    request.log.error({ err: error }, 'unhandled error');
    return reply.code(500).send({
      error: ErrorCodes.INTERNAL,
      message: 'Something went wrong on our end',
    });
  });

  app.setNotFoundHandler((request, reply) => {
    reply.code(404).send({
      error: 'not_found',
      message: `No route for ${request.method} ${request.url}`,
    });
  });

  return app;
}

// ---------------------------------------------------------------------------
// Background maintenance
// ---------------------------------------------------------------------------

/**
 * Expired messages, statuses, OTPs and rate-limit rows all accumulate. This
 * runs in-process on a timer, which is adequate for a single instance.
 *
 * If you scale to multiple API instances, move this to a scheduled job (a
 * separate process, or pg_cron on a plan that offers it) so N instances do not
 * each run the same sweep.
 */
function startMaintenanceLoop(app: FastifyInstance): NodeJS.Timeout {
  const run = async () => {
    try {
      const [purged, otps] = await Promise.all([purgeExpired(), pruneExpiredOtps()]);
      await prunePersistentCounters();
      if (purged.messages > 0 || purged.statuses > 0) {
        app.log.info({ purged }, 'purged expired content');
      }
      void otps;
    } catch (err) {
      app.log.error({ err }, 'maintenance sweep failed');
    }
  };

  // Every 5 minutes. Deliberately not more often: this is cleanup, and a tight
  // loop against a scale-to-zero database is a good way to keep it awake (and
  // burning CU-hours) for no reason.
  const timer = setInterval(run, 5 * 60 * 1000);
  timer.unref();
  return timer;
}

async function main(): Promise<void> {
  const app = await buildServer();
  const maintenance = startMaintenanceLoop(app);

  const shutdown = async (signal: string): Promise<void> => {
    app.log.info({ signal }, 'shutting down');
    clearInterval(maintenance);

    // Close sockets first so clients see a clean 1001 rather than a dropped
    // connection, which they would otherwise treat as a network failure and
    // retry immediately.
    shutdownHub();

    try {
      await app.close();
      await closePool();
    } catch (err) {
      app.log.error({ err }, 'error during shutdown');
    }
    process.exit(0);
  };

  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));

  await app.listen({ port: config.PORT, host: config.HOST });

  app.log.info(
    {
      env: config.NODE_ENV,
      port: config.PORT,
      mediaDriver: config.MEDIA_DRIVER,
      mailTransport: config.MAIL_TRANSPORT,
      pushEnabled: config.PUSH_ENABLED,
      pooledDatabase: config.DB_IS_POOLED,
    },
    'chat backend listening',
  );

  if (config.MEDIA_DRIVER === 'local') {
    app.log.warn(
      `Media is stored on local disk at ${config.MEDIA_LOCAL_DIR}. Serve that directory from your reverse proxy ` +
        `(Caddy/nginx) at ${config.MEDIA_PUBLIC_BASE_URL}, or switch MEDIA_DRIVER=s3 — the API itself does not serve files.`,
    );
  }
}

// Only listen when run directly, so tests can import buildServer without
// binding a port.
const isDirectRun = process.argv[1] !== undefined && import.meta.url.endsWith(process.argv[1].split('/').pop() ?? '');

if (isDirectRun || process.env.START_SERVER === '1') {
  main().catch((err: unknown) => {
    // eslint-disable-next-line no-console
    console.error('Fatal startup error:', err);
    process.exit(1);
  });
}
