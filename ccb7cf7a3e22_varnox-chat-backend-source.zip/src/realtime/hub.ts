import type { WebSocket } from 'ws';
import { query } from '../db/pool.js';

/**
 * In-process realtime hub.
 *
 * WHY NOT POSTGRES LISTEN/NOTIFY: the obvious design for chat fan-out is a
 * Postgres trigger plus LISTEN/NOTIFY, which works beautifully on a normal
 * connection. Neon's pooled endpoint runs PgBouncer in *transaction* mode,
 * where LISTEN is not supported at all — the subscription is dropped as soon
 * as the transaction ends. So fan-out happens here instead.
 *
 * THE TRADE-OFF, stated plainly: this design is single-process. Run two API
 * instances behind a load balancer and a user connected to instance A will not
 * receive a message published on instance B. When you need horizontal scaling,
 * add Redis pub/sub (or a Postgres LISTEN connection held on the DIRECT
 * endpoint, which does support it) behind the same `publishToUsers` interface —
 * nothing else in the codebase needs to change.
 *
 * Online/typing state is deliberately in-memory and therefore also
 * per-process and lost on restart. The durable fallback is `users.last_seen_at`,
 * which is written on disconnect; unread counts come from read watermarks in
 * the database and are always correct.
 */

export type ClientEvent =
  | { type: 'ready'; userId: string; serverTime: string }
  | { type: 'ping'; t: number }
  | { type: 'pong'; t: number }
  | { type: 'message.new'; chatId: string; message: unknown }
  | { type: 'message.updated'; chatId: string; message: unknown }
  | { type: 'message.deleted'; chatId: string; messageId: string; scope: 'everyone' | 'me' }
  | { type: 'message.reaction'; chatId: string; messageId: string; userId: string; emoji: string; removed: boolean }
  | { type: 'receipt.update'; chatId: string; userId: string; deliveredUpTo?: number; readUpTo?: number }
  | { type: 'typing.start'; chatId: string; userId: string }
  | { type: 'typing.stop'; chatId: string; userId: string }
  | { type: 'presence.update'; userId: string; online: boolean; lastSeenAt: string | null }
  | { type: 'chat.updated'; chatId: string; chat: unknown }
  | { type: 'chat.removed'; chatId: string }
  | { type: 'call.incoming'; callId: string; from: string; chatId: string | null; kind: 'voice' | 'video' }
  | { type: 'call.ended'; callId: string; reason: string }
  | { type: 'notification.new'; notification: unknown }
  | { type: 'error'; code: string; message: string };

interface Connection {
  socket: WebSocket;
  userId: string;
  deviceId: string | null;
  socketId: string;
  connectedAt: number;
  lastPongAt: number;
  alive: boolean;
}

const byUser = new Map<string, Set<Connection>>();
const sockets = new Map<string, Connection>();

// How long a socket may miss pongs before we assume the client vanished.
// Without this, a half-open TCP connection keeps a user "online" forever.
const PONG_TIMEOUT_MS = 90_000;
const SWEEP_INTERVAL_MS = 30_000;

let sweepTimer: NodeJS.Timeout | null = null;

export function addConnection(params: {
  socket: WebSocket;
  userId: string;
  deviceId: string | null;
  socketId: string;
}): Connection {
  const conn: Connection = {
    socket: params.socket,
    userId: params.userId,
    deviceId: params.deviceId,
    socketId: params.socketId,
    connectedAt: Date.now(),
    lastPongAt: Date.now(),
    alive: true,
  };

  let set = byUser.get(params.userId);
  if (!set) {
    set = new Set();
    byUser.set(params.userId, set);
  }

  const wasOffline = set.size === 0;
  set.add(conn);
  sockets.set(params.socketId, conn);

  if (wasOffline) {
    // Tell everyone who shares a conversation that this user came online.
    void broadcastPresence(params.userId, true);
  }

  startSweeper();
  return conn;
}

export function removeConnection(socketId: string): void {
  const conn = sockets.get(socketId);
  if (!conn) return;
  sockets.delete(socketId);

  const set = byUser.get(conn.userId);
  if (set) {
    set.delete(conn);
    if (set.size === 0) {
      byUser.delete(conn.userId);
      void markLastSeen(conn.userId);
      void broadcastPresence(conn.userId, false);
    }
  }
}

export function touchConnection(socketId: string): void {
  const conn = sockets.get(socketId);
  if (conn) conn.lastPongAt = Date.now();
}

export function isOnline(userId: string): boolean {
  const set = byUser.get(userId);
  return Boolean(set && set.size > 0);
}

export function onlineUserIds(): string[] {
  return [...byUser.keys()];
}

export function connectionCount(userId: string): number {
  return byUser.get(userId)?.size ?? 0;
}

/** Send to every device a user has open. Returns the number of sockets reached. */
export function publishToUser(userId: string, event: ClientEvent): number {
  const set = byUser.get(userId);
  if (!set || set.size === 0) return 0;

  const payload = JSON.stringify(event);
  let sent = 0;
  for (const conn of set) {
    // readyState 1 === OPEN
    if (conn.socket.readyState === 1) {
      try {
        conn.socket.send(payload);
        sent += 1;
      } catch {
        removeConnection(conn.socketId);
      }
    }
  }
  return sent;
}

export function publishToUsers(userIds: readonly string[], event: ClientEvent): number {
  let sent = 0;
  const seen = new Set<string>();
  for (const userId of userIds) {
    if (seen.has(userId)) continue;
    seen.add(userId);
    sent += publishToUser(userId, event);
  }
  return sent;
}

/**
 * Fan out an event to a conversation's current members.
 * Membership is re-read here rather than trusted from the caller, because a
 * user added mid-request would otherwise miss the message that added them.
 */
export async function publishToChat(
  chatId: string,
  event: ClientEvent,
  opts: { excludeUserId?: string } = {},
): Promise<number> {
  const res = await query<{ user_id: string }>(
    `SELECT user_id FROM chat_members
      WHERE chat_id = $1 AND left_at IS NULL AND status = 'active'`,
    [chatId],
  );

  const recipients = res.rows.map((r) => r.user_id).filter((id) => id !== opts.excludeUserId);
  if (opts.excludeUserId) recipients.push(opts.excludeUserId); // sender's other devices must also sync

  return publishToUsers(recipients, event);
}

// ---------------------------------------------------------------------------
// Presence
// ---------------------------------------------------------------------------

async function markLastSeen(userId: string): Promise<void> {
  try {
    await query(`UPDATE users SET last_seen_at = now() WHERE id = $1`, [userId]);
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('[hub] failed to update last_seen_at', (err as Error).message);
  }
}

/**
 * Presence is only visible to people who share a conversation with the user —
 * broadcasting to the whole user base would leak the activity graph.
 */
async function broadcastPresence(userId: string, online: boolean): Promise<void> {
  try {
    const res = await query<{ user_id: string }>(
      `SELECT DISTINCT other.user_id
         FROM chat_members me
         JOIN chat_members other ON other.chat_id = me.chat_id AND other.user_id <> me.user_id
        WHERE me.user_id = $1 AND me.left_at IS NULL AND other.left_at IS NULL`,
      [userId],
    );

    const lastSeen = await query<{ last_seen_at: Date | null }>(
      `SELECT last_seen_at FROM users WHERE id = $1`,
      [userId],
    );

    publishToUsers(
      res.rows.map((r) => r.user_id),
      {
        type: 'presence.update',
        userId,
        online,
        lastSeenAt: lastSeen.rows[0]?.last_seen_at?.toISOString() ?? null,
      },
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('[hub] failed to broadcast presence', (err as Error).message);
  }
}

// ---------------------------------------------------------------------------
// Typing indicators — deliberately never persisted. They are worthless a
// second later and would otherwise be the highest-volume table in the schema.
// ---------------------------------------------------------------------------

const typingTimers = new Map<string, NodeJS.Timeout>();

export async function setTyping(chatId: string, userId: string, typing: boolean): Promise<void> {
  const key = `${chatId}:${userId}`;
  const existing = typingTimers.get(key);
  if (existing) clearTimeout(existing);

  await publishToChat(chatId, typing ? { type: 'typing.start', chatId, userId } : { type: 'typing.stop', chatId, userId }, {
    excludeUserId: userId,
  });

  if (typing) {
    // Auto-expire, so a client that disconnects mid-typing does not leave the
    // indicator stuck on for everyone else.
    typingTimers.set(
      key,
      setTimeout(() => {
        typingTimers.delete(key);
        void publishToChat(chatId, { type: 'typing.stop', chatId, userId }, { excludeUserId: userId });
      }, 8_000),
    );
  } else {
    typingTimers.delete(key);
  }
}

// ---------------------------------------------------------------------------
// Liveness sweep
// ---------------------------------------------------------------------------

function startSweeper(): void {
  if (sweepTimer) return;
  sweepTimer = setInterval(() => {
    const now = Date.now();
    for (const conn of [...sockets.values()]) {
      if (now - conn.lastPongAt > PONG_TIMEOUT_MS) {
        try {
          conn.socket.terminate();
        } catch {
          // already gone
        }
        removeConnection(conn.socketId);
        continue;
      }
      if (conn.socket.readyState === 1) {
        try {
          conn.socket.send(JSON.stringify({ type: 'ping', t: now }));
        } catch {
          removeConnection(conn.socketId);
        }
      }
    }
  }, SWEEP_INTERVAL_MS);
  // Do not hold the event loop open just for the heartbeat.
  sweepTimer.unref?.();
}

export function shutdownHub(): void {
  if (sweepTimer) {
    clearInterval(sweepTimer);
    sweepTimer = null;
  }
  for (const conn of sockets.values()) {
    try {
      conn.socket.close(1001, 'server shutting down');
    } catch {
      // ignore
    }
  }
  sockets.clear();
  byUser.clear();
}

export function hubStats() {
  return {
    connectedUsers: byUser.size,
    openSockets: sockets.size,
  };
}
