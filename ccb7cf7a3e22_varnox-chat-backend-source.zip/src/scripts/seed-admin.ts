/**
 * Creates (or promotes) the first superadmin.
 *
 *   SUPERADMIN_EMAIL=you@example.com SUPERADMIN_PASSWORD='...' npm run seed:admin
 *
 * This is the only way to bootstrap administrator access — the API deliberately
 * has no "become an admin" endpoint, because that endpoint would be the single
 * highest-value target in the entire system.
 */
import { config } from '../config.js';
import { closePool, initialiseDatabase, query, queryOne, withTransaction } from '../db/pool.js';
import { hashPassword } from '../lib/crypto.js';

async function main(): Promise<void> {
  // The pool only opens once a candidate database has been chosen and verified.
  const selection = await initialiseDatabase();
  console.log(`Connected to ${selection.target.label} (${selection.target.appliedMigrations} migrations applied)`);

  const email = (process.env.SUPERADMIN_EMAIL ?? config.SUPERADMIN_EMAIL ?? '').trim().toLowerCase();
  const password = process.env.SUPERADMIN_PASSWORD ?? config.SUPERADMIN_PASSWORD ?? '';

  if (!email || !password) {
    console.error(
      'Set SUPERADMIN_EMAIL and SUPERADMIN_PASSWORD (in the environment or .env) before running this script.',
    );
    process.exit(1);
  }
  if (password.length < 12) {
    console.error('Use a password of at least 12 characters for a superadmin account.');
    process.exit(1);
  }

  const existing = await queryOne<{ id: string }>(
    `SELECT id FROM users WHERE lower(email) = $1 AND deleted_at IS NULL`,
    [email],
  );

  const userId = await withTransaction(async (tx) => {
    let id = existing?.id;

    if (!id) {
      const inserted = await tx.query<{ id: string }>(
        `INSERT INTO users (email, password_hash, full_name, status, email_verified_at, is_verified)
         VALUES ($1, $2, 'Superadmin', 'active', now(), true)
         RETURNING id`,
        [email, await hashPassword(password)],
      );
      id = inserted.rows[0]!.id;

      await tx.query(`INSERT INTO user_profiles (user_id, display_name) VALUES ($1, 'Superadmin')`, [id]);
      await tx.query(`INSERT INTO user_privacy_settings (user_id) VALUES ($1)`, [id]);
      await tx.query(`INSERT INTO user_notification_settings (user_id) VALUES ($1)`, [id]);
      await tx.query(`INSERT INTO user_appearance_settings (user_id) VALUES ($1)`, [id]);
      console.log(`Created user ${email} (${id})`);
    } else {
      console.log(`Found existing user ${email} (${id})`);
      // Ensure a password reset is not silently required on first login.
      await tx.query(`UPDATE users SET email_verified_at = COALESCE(email_verified_at, now()) WHERE id = $1`, [id]);
    }

    await tx.query(
      `INSERT INTO admin_roles (user_id, role, notes)
       VALUES ($1, 'superadmin', 'seeded by seed-admin script')
       ON CONFLICT (user_id) DO UPDATE SET role = 'superadmin', revoked_at = NULL, granted_at = now()`,
      [id],
    );

    return id;
  });

  // actor_id is a uuid column and target_id is text, so they need separate
  // placeholders — Postgres cannot deduce one type for a parameter used in both.
  await query(
    `INSERT INTO audit_logs (actor_id, actor_role, action, target_type, target_id, metadata)
     VALUES ($1::uuid, 'superadmin', 'admin.role.seed', 'user', $2, $3)`,
    [userId, userId, JSON.stringify({ email, via: 'seed-admin script' })],
  );

  console.log(`\n${email} is now a superadmin. Sign in and use the /admin/* endpoints.`);
  await closePool();
}

main().catch(async (err: unknown) => {
  console.error('seed-admin failed:', err instanceof Error ? err.message : err);
  await closePool().catch(() => {});
  process.exit(1);
});
