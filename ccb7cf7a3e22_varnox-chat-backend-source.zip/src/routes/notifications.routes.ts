import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { uuidSchema } from '../lib/validation.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { getUnreadCount, listNotifications, markNotificationsRead } from '../services/notifications.service.js';

export async function registerNotificationRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: requireAuth };

  app.get('/notifications', auth, async (request) => {
    const query = z
      .object({
        unreadOnly: z.coerce.boolean().optional(),
        limit: z.coerce.number().int().min(1).max(200).default(50),
      })
      .parse(request.query);

    const userId = authOf(request).userId;
    const [items, unreadCount] = await Promise.all([
      listNotifications(userId, query),
      getUnreadCount(userId),
    ]);
    return { notifications: items, unreadCount };
  });

  app.get('/notifications/unread-count', auth, async (request) => {
    return { unreadCount: await getUnreadCount(authOf(request).userId) };
  });

  app.post('/notifications/read', auth, async (request) => {
    const body = z.object({ ids: z.array(uuidSchema).max(500).optional() }).parse(request.body ?? {});
    // Omitting `ids` marks everything read — the "clear all" affordance.
    const updated = await markNotificationsRead(authOf(request).userId, body.ids);
    return { updated };
  });
}
