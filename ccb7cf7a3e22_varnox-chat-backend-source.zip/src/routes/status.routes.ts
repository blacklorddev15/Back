import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { config } from '../config.js';
import { queryOne } from '../db/pool.js';
import { ErrorCodes, badRequest, forbidden, notFound } from '../lib/errors.js';
import { authenticateForMedia } from '../lib/mediaAuth.js';
import { uuidSchema } from '../lib/validation.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import {
  createStatus,
  deleteStatus,
  getStatusForViewer,
  getStatusVisibility,
  listMyStatuses,
  listStatusFeed,
  listStatusReactions,
  listStatusViewers,
  markStatusViewed,
  reactToStatus,
  setStatusVisibility,
} from '../services/status.service.js';

/** Status — posts that expire after 24 hours. */
export async function registerStatusRoutes(app: FastifyInstance): Promise<void> {
  const attachmentSchema = z.object({
    kind: z.enum(['image', 'video', 'voice', 'gif']),
    mimeType: z.string().max(120),
    storageKey: z.string().max(512),
    publicUrl: z.string().url().max(2048).optional(),
    thumbnailUrl: z.string().url().max(2048).optional(),
    byteSize: z.number().int().nonnegative().optional(),
    durationMs: z.number().int().nonnegative().optional(),
    width: z.number().int().positive().optional(),
    height: z.number().int().positive().optional(),
  });

  /**
   * Everything the Updates tab needs in one call: your own live statuses, and
   * everyone else's grouped by author. One request rather than two keeps the
   * screen from flickering between the two halves.
   */
  app.get('/status', { preHandler: requireAuth }, async (request) => {
    const userId = authOf(request).userId;
    const [mine, feed, visibility] = await Promise.all([
      listMyStatuses(userId),
      listStatusFeed(userId),
      getStatusVisibility(userId),
    ]);
    return { mine, feed, visibility };
  });

  app.get('/status/visibility', { preHandler: requireAuth }, async (request) => ({
    visibility: await getStatusVisibility(authOf(request).userId),
  }));

  /**
   * Who may see your statuses. A profile-level setting rather than a per-post
   * one, so it lives outside /status — the same way WhatsApp presents it.
   */
  app.put('/status/visibility', { preHandler: requireAuth }, async (request) => {
    const body = z
      .object({ visibility: z.enum(['everyone', 'contacts', 'contacts_except', 'nobody']) })
      .parse(request.body);
    return { visibility: await setStatusVisibility(authOf(request).userId, body.visibility) };
  });

  app.post('/status', { preHandler: requireAuth }, async (request, reply) => {
    const body = z
      .object({
        type: z.enum(['text', 'image', 'video', 'gif', 'voice']),
        body: z.string().max(700).optional(),
        caption: z.string().max(1024).optional(),
        backgroundColor: z
          .string()
          .regex(/^#[0-9a-fA-F]{6}$/, 'Use a six-digit hex colour')
          .optional(),
        attachments: z.array(attachmentSchema).max(10).optional(),
      })
      .parse(request.body);

    const status = await createStatus({ userId: authOf(request).userId, ...body });
    return reply.code(201).send({ status });
  });

  /**
   * A single status. Declared before /status/:statusId/view so the literal
   * segments below are unambiguous, and because Fastify matches static
   * segments ahead of parameters anyway.
   */
  app.get('/status/:statusId', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ statusId: uuidSchema }).parse(request.params);
    const status = await getStatusForViewer(authOf(request).userId, params.statusId);
    const reactions = await listStatusReactions(params.statusId);
    return { status, reactions };
  });

  app.post('/status/:statusId/view', { preHandler: requireAuth }, async (request, reply) => {
    const params = z.object({ statusId: uuidSchema }).parse(request.params);
    await markStatusViewed(authOf(request).userId, params.statusId);
    return reply.code(204).send();
  });

  /** Only the author may see this; the service enforces it. */
  app.get('/status/:statusId/viewers', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ statusId: uuidSchema }).parse(request.params);
    return { viewers: await listStatusViewers(authOf(request).userId, params.statusId) };
  });

  app.post('/status/:statusId/reactions', { preHandler: requireAuth }, async (request, reply) => {
    const params = z.object({ statusId: uuidSchema }).parse(request.params);
    const body = z.object({ emoji: z.string().min(1).max(16) }).parse(request.body);
    await reactToStatus(authOf(request).userId, params.statusId, body.emoji);
    return reply.code(204).send();
  });

  app.delete('/status/:statusId', { preHandler: requireAuth }, async (request, reply) => {
    const params = z.object({ statusId: uuidSchema }).parse(request.params);
    await deleteStatus(authOf(request).userId, params.statusId);
    return reply.code(204).send();
  });

  /**
   * The bytes behind a status attachment.
   *
   * WHY THIS EXISTS: an uploaded file gets a `publicUrl` built from
   * MEDIA_PUBLIC_BASE_URL, and nothing serves that path — so a photo status
   * would upload happily and then never render. This is the half that renders
   * it, and it is why the composer can offer a photo at all.
   *
   * AUTHORISATION: you may read the bytes if you are the author, or if the
   * status is visible to you. The predicate is the same one the feed uses, so
   * narrowing your audience hides the media too, rather than leaving the file
   * readable by anyone who kept the URL.
   *
   * Reachable by id only: `/media/<storageKey>` would let anyone holding a key
   * read any file, and keys travel through logs and screenshots.
   */
  app.get('/status/media/:attachmentId', async (request: FastifyRequest, reply: FastifyReply) => {
    const params = z.object({ attachmentId: uuidSchema }).parse(request.params);
    const userId = await authenticateForMedia(request);

    const row = await queryOne<{
      id: string;
      kind: string;
      mime_type: string;
      storage_key: string;
    }>(
      `SELECT a.id, a.kind, a.mime_type, a.storage_key
         FROM status_attachments a
         JOIN statuses s ON s.id = a.status_id
         LEFT JOIN user_privacy_settings author_privacy ON author_privacy.user_id = s.user_id
        WHERE a.id = $2
          AND s.deleted_at IS NULL
          AND s.expires_at > now()
          AND (
                s.user_id = $1
                OR (
                     NOT EXISTS (SELECT 1 FROM user_blocks b
                                  WHERE (b.blocker_id = s.user_id AND b.blocked_id = $1)
                                     OR (b.blocker_id = $1 AND b.blocked_id = s.user_id))
                 AND (NOT EXISTS (SELECT 1 FROM status_audience x WHERE x.status_id = s.id AND x.mode = 'include')
                      OR EXISTS (SELECT 1 FROM status_audience x WHERE x.status_id = s.id AND x.user_id = $1 AND x.mode = 'include'))
                 AND NOT EXISTS (SELECT 1 FROM status_audience x WHERE x.status_id = s.id AND x.user_id = $1 AND x.mode = 'exclude')
                 AND CASE COALESCE(author_privacy.status_visibility, 'contacts')
                       WHEN 'everyone' THEN true
                       WHEN 'nobody'   THEN false
                       ELSE EXISTS (SELECT 1 FROM contacts c WHERE c.owner_id = s.user_id AND c.contact_user_id = $1)
                     END
                   )
              )`,
      [userId, params.attachmentId],
    );

    // Same 404 whether the file is absent or simply not yours, so the response
    // cannot be used to probe for other people's media.
    if (!row) throw notFound(ErrorCodes.MESSAGE_NOT_FOUND, 'Attachment not found');

    if (config.MEDIA_DRIVER !== 'local') {
      if (!config.S3_ENDPOINT || !config.S3_BUCKET) {
        throw badRequest(ErrorCodes.INTERNAL, 'Object storage is not configured');
      }
      return reply.redirect(`${config.S3_ENDPOINT.replace(/\/$/, '')}/${config.S3_BUCKET}/${row.storage_key}`, 302);
    }

    const root = resolve(config.MEDIA_LOCAL_DIR);
    const fullPath = resolve(root, row.storage_key);
    if (!fullPath.startsWith(root)) {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Invalid storage path');
    }

    let size: number;
    try {
      size = (await stat(fullPath)).size;
    } catch {
      throw notFound('not_found', 'The stored file is missing');
    }

    reply.header('Content-Type', row.mime_type);
    reply.header('Content-Length', String(size));
    reply.header('Cache-Control', 'private, max-age=3600');
    reply.header('Content-Disposition', 'inline');
    return reply.send(createReadStream(fullPath));
  });
}
