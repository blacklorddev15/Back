import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { ErrorCodes, badRequest } from '../lib/errors.js';
import { messageBodySchema, paginationSchema, uuidSchema } from '../lib/validation.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import {
  addMembers, clearChat, createGroup, createInvite, exportChat, getChatDetails,
  getChatMemberIds, getOrCreateDirectChat, joinViaInvite, listChats, lockChat,
  markChatRead, markChatUnread, muteChat, removeMember, requireMembership,
  reviewJoinRequest, revokeInvite, setMemberRole, unlockChat, updateChat, updateMemberState,
} from '../services/chats.service.js';
import {
  addReaction, deleteMessageForEveryone, deleteMessageForMe, editMessage, forwardMessages,
  getMessageById, listMessages, listPinned, listReaders, listStarred, markDelivered, markRead,
  removeReaction, searchMessages, sendMessage, setPin, setStar,
} from '../services/messages.service.js';
import { inferKind, isAllowedMimeType, storeBuffer } from '../services/media.service.js';
import { setTyping } from '../realtime/hub.js';

/**
 * Conversations, messages and attachments.
 *
 * Membership is verified in the service layer inside the same transaction as
 * every write; the route handlers only parse input and shape output.
 */
export async function registerChatRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: requireAuth };

  // -------------------------------------------------------------------------
  // Chat list & creation
  // -------------------------------------------------------------------------
  app.get('/chats', auth, async (request) => {
    const query = z
      .object({
        filter: z.enum(['all', 'unread', 'groups', 'direct', 'archived', 'favorites']).default('all'),
        limit: z.coerce.number().int().min(1).max(200).default(50),
      })
      .parse(request.query);

    return { chats: await listChats(authOf(request).userId, query.filter, query.limit) };
  });

  app.post('/chats/direct', auth, async (request, reply) => {
    const body = z.object({ userId: uuidSchema }).parse(request.body);
    const result = await getOrCreateDirectChat(authOf(request).userId, body.userId);
    return reply.code(result.created ? 201 : 200).send(result);
  });

  app.post('/chats/group', auth, async (request, reply) => {
    const body = z
      .object({
        title: z.string().trim().min(1).max(100),
        description: z.string().max(500).optional(),
        memberIds: z.array(uuidSchema).max(500).optional(),
        photoUrl: z.string().url().max(2048).optional(),
      })
      .parse(request.body);

    const result = await createGroup({ creatorId: authOf(request).userId, ...body });
    return reply.code(201).send(result);
  });

  app.get('/chats/:chatId', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    return getChatDetails(params.chatId, authOf(request).userId);
  });

  app.patch('/chats/:chatId', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z
      .object({
        title: z.string().trim().min(1).max(100).optional(),
        description: z.string().max(500).optional(),
        photoUrl: z.string().url().max(2048).optional(),
        disappearingSeconds: z.number().int().min(0).max(7_776_000).optional(),
        whoCanSend: z.enum(['everyone', 'admins']).optional(),
        whoCanEditInfo: z.enum(['everyone', 'admins']).optional(),
        whoCanAddMembers: z.enum(['everyone', 'admins']).optional(),
        whoCanPin: z.enum(['everyone', 'admins']).optional(),
      })
      .parse(request.body);

    await updateChat(authOf(request).userId, params.chatId, body);
    return { message: 'Conversation updated.' };
  });

  // -------------------------------------------------------------------------
  // Membership
  // -------------------------------------------------------------------------
  app.post('/chats/:chatId/members', auth, async (request, reply) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z.object({ userIds: z.array(uuidSchema).min(1).max(100) }).parse(request.body);

    const result = await addMembers(authOf(request).userId, params.chatId, body.userIds);
    return reply.code(201).send(result);
  });

  app.delete('/chats/:chatId/members/:userId', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema, userId: uuidSchema }).parse(request.params);
    const query = z.object({ ban: z.coerce.boolean().optional(), reason: z.string().max(200).optional() }).parse(request.query);

    await removeMember({
      actorId: authOf(request).userId,
      chatId: params.chatId,
      userId: params.userId,
      ban: query.ban,
      reason: query.reason,
    });
    return { message: 'Member removed.' };
  });

  app.post('/chats/:chatId/members/:userId/role', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema, userId: uuidSchema }).parse(request.params);
    const body = z.object({ role: z.enum(['admin', 'member']) }).parse(request.body);

    await setMemberRole({ actorId: authOf(request).userId, chatId: params.chatId, userId: params.userId, role: body.role });
    return { message: `Role updated to ${body.role}.` };
  });

  // -------------------------------------------------------------------------
  // Invites & join requests
  // -------------------------------------------------------------------------
  app.post('/chats/:chatId/invites', auth, async (request, reply) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z
      .object({
        expiresInHours: z.number().int().min(1).max(24 * 365).optional(),
        maxUses: z.number().int().min(1).max(100_000).optional(),
        requireApproval: z.boolean().optional(),
      })
      .parse(request.body);

    const invite = await createInvite({ actorId: authOf(request).userId, chatId: params.chatId, ...body });
    return reply.code(201).send({
      ...invite,
      // Both forms, because QR-code invitations need a scannable payload and
      // deep links need a URL.
      url: `https://chat.example/invite/${invite.code}`,
      qrPayload: `chatinvite:${invite.code}`,
    });
  });

  app.delete('/chats/invites/:inviteId', auth, async (request) => {
    const params = z.object({ inviteId: uuidSchema }).parse(request.params);
    await revokeInvite(authOf(request).userId, params.inviteId);
    return { message: 'Invite link revoked.' };
  });

  app.post('/chats/join/:code', auth, async (request) => {
    const params = z.object({ code: z.string().min(4).max(32) }).parse(request.params);
    const result = await joinViaInvite(authOf(request).userId, params.code);
    return result.joined
      ? { joined: true, chatId: result.chatId, message: 'You have joined the conversation.' }
      : { joined: false, requestId: result.requestId, message: 'Your request to join is pending approval.' };
  });

  app.post('/chats/join-requests/:requestId', auth, async (request) => {
    const params = z.object({ requestId: uuidSchema }).parse(request.params);
    const body = z.object({ approve: z.boolean() }).parse(request.body);
    await reviewJoinRequest({ actorId: authOf(request).userId, requestId: params.requestId, approve: body.approve });
    return { message: body.approve ? 'Member approved.' : 'Request declined.' };
  });

  // -------------------------------------------------------------------------
  // Per-user chat state
  // -------------------------------------------------------------------------
  app.patch('/chats/:chatId/settings', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z
      .object({
        mutedUntil: z.string().datetime().nullable().optional(),
        isArchived: z.boolean().optional(),
        pinned: z.boolean().optional(),
        isFavorite: z.boolean().optional(),
        wallpaper: z.string().max(500).nullable().optional(),
        theme: z.string().max(40).nullable().optional(),
        notificationSound: z.string().max(60).nullable().optional(),
        nickname: z.string().max(120).nullable().optional(),
      })
      .parse(request.body);

    await updateMemberState(authOf(request).userId, params.chatId, body);
    return { message: 'Chat settings updated.' };
  });

  app.post('/chats/:chatId/mute', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    // null duration means "until I turn it back on"
    const body = z.object({ durationSeconds: z.number().int().min(60).nullable().default(null) }).parse(request.body);
    const until = await muteChat(authOf(request).userId, params.chatId, body.durationSeconds);
    return { mutedUntil: until };
  });

  app.post('/chats/:chatId/lock', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z.object({ secret: z.string().min(4).max(64).optional() }).parse(request.body);
    await lockChat(authOf(request).userId, params.chatId, body.secret);
    return { message: 'Chat locked.' };
  });

  app.post('/chats/:chatId/unlock', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z.object({ secret: z.string().min(4).max(64).optional() }).parse(request.body);
    await unlockChat(authOf(request).userId, params.chatId, body.secret);
    return { message: 'Chat unlocked.' };
  });

  app.post('/chats/:chatId/clear', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    await clearChat(authOf(request).userId, params.chatId);
    return { message: 'Chat cleared on this device.' };
  });

  app.post('/chats/:chatId/read', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z.object({ upToSeq: z.number().int().nonnegative().optional() }).parse(request.body ?? {});
    const watermark = await markChatRead(authOf(request).userId, params.chatId, body.upToSeq);
    return { lastReadSeq: watermark };
  });

  app.post('/chats/:chatId/unread', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    await markChatUnread(authOf(request).userId, params.chatId);
    return { message: 'Marked as unread.' };
  });

  app.get('/chats/:chatId/export', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    return exportChat(authOf(request).userId, params.chatId);
  });

  // -------------------------------------------------------------------------
  // Messages
  // -------------------------------------------------------------------------
  app.get('/chats/:chatId/messages', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const query = paginationSchema.parse(request.query);

    return listMessages({
      userId: authOf(request).userId,
      chatId: params.chatId,
      limit: query.limit,
      before: query.before,
      after: query.after,
    });
  });

  app.post('/chats/:chatId/messages', auth, async (request, reply) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z
      .object({
        type: z
          .enum(['text', 'image', 'video', 'audio', 'voice', 'document', 'sticker', 'gif', 'location', 'contact'])
          .default('text'),
        body: messageBodySchema.optional(),
        metadata: z.record(z.unknown()).optional(),
        replyToId: uuidSchema.optional(),
        isViewOnce: z.boolean().optional(),
        /** Client-generated, used to make a retried send idempotent. */
        clientId: z.string().max(64).optional(),
        attachments: z
          .array(
            z.object({
              kind: z.enum(['image', 'video', 'audio', 'voice', 'document', 'sticker', 'gif']),
              mimeType: z.string().max(120),
              fileName: z.string().max(255).optional(),
              byteSize: z.number().int().nonnegative(),
              storageDriver: z.string().max(20),
              storageKey: z.string().max(512),
              publicUrl: z.string().url().max(2048).optional(),
              thumbnailUrl: z.string().url().max(2048).optional(),
              width: z.number().int().positive().optional(),
              height: z.number().int().positive().optional(),
              durationMs: z.number().int().nonnegative().optional(),
              waveform: z.unknown().optional(),
              sha256: z.string().max(64).optional(),
              isCompressed: z.boolean().optional(),
              originalByteSize: z.number().int().nonnegative().optional(),
            }),
          )
          .max(20)
          .optional(),
      })
      .parse(request.body);

    const message = await sendMessage({ senderId: authOf(request).userId, chatId: params.chatId, ...body });
    return reply.code(201).send({ message });
  });

  app.get('/chats/:chatId/messages/:messageId', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema, messageId: uuidSchema }).parse(request.params);
    return { message: await getMessageById(params.chatId, params.messageId, authOf(request).userId) };
  });

  app.patch('/chats/:chatId/messages/:messageId', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema, messageId: uuidSchema }).parse(request.params);
    const body = z.object({ body: messageBodySchema }).parse(request.body);

    const message = await editMessage({
      userId: authOf(request).userId,
      chatId: params.chatId,
      messageId: params.messageId,
      body: body.body,
    });
    return { message };
  });

  app.delete('/chats/:chatId/messages/:messageId', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema, messageId: uuidSchema }).parse(request.params);
    // scope=everyone is a retraction; scope=me only hides it locally. They have
    // very different consequences, so the client must say which it means.
    const query = z.object({ scope: z.enum(['everyone', 'me']).default('me') }).parse(request.query);

    if (query.scope === 'everyone') {
      await deleteMessageForEveryone({ userId: authOf(request).userId, chatId: params.chatId, messageId: params.messageId });
      return { message: 'Message deleted for everyone.' };
    }
    await deleteMessageForMe({ userId: authOf(request).userId, chatId: params.chatId, messageId: params.messageId });
    return { message: 'Message deleted for you.' };
  });

  app.post('/chats/:chatId/messages/:messageId/reactions', auth, async (request, reply) => {
    const params = z.object({ chatId: uuidSchema, messageId: uuidSchema }).parse(request.params);
    const body = z.object({ emoji: z.string().min(1).max(16) }).parse(request.body);

    await addReaction({
      userId: authOf(request).userId,
      chatId: params.chatId,
      messageId: params.messageId,
      emoji: body.emoji,
    });
    return reply.code(201).send({ message: 'Reaction added.' });
  });

  app.delete('/chats/:chatId/messages/:messageId/reactions', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema, messageId: uuidSchema }).parse(request.params);
    const query = z.object({ emoji: z.string().min(1).max(16) }).parse(request.query);

    await removeReaction({
      userId: authOf(request).userId,
      chatId: params.chatId,
      messageId: params.messageId,
      emoji: query.emoji,
    });
    return { message: 'Reaction removed.' };
  });

  app.post('/chats/:chatId/messages/:messageId/star', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema, messageId: uuidSchema }).parse(request.params);
    const body = z.object({ starred: z.boolean().default(true) }).parse(request.body ?? {});
    await setStar(authOf(request).userId, params.messageId, body.starred);
    return { message: body.starred ? 'Message starred.' : 'Star removed.' };
  });

  app.post('/chats/:chatId/messages/:messageId/pin', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema, messageId: uuidSchema }).parse(request.params);
    const body = z.object({ pinned: z.boolean().default(true) }).parse(request.body ?? {});

    await setPin({
      userId: authOf(request).userId,
      chatId: params.chatId,
      messageId: params.messageId,
      pinned: body.pinned,
    });
    return { message: body.pinned ? 'Message pinned.' : 'Message unpinned.' };
  });

  app.get('/chats/:chatId/pinned', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    return { messages: await listPinned(params.chatId, authOf(request).userId) };
  });

  app.get('/chats/:chatId/messages/:messageId/readers', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema, messageId: uuidSchema }).parse(request.params);
    return { readers: await listReaders(params.chatId, params.messageId, authOf(request).userId) };
  });

  app.post('/chats/:chatId/messages/delivered', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z.object({ upToSeq: z.number().int().nonnegative().optional() }).parse(request.body ?? {});
    await markDelivered(authOf(request).userId, params.chatId, body.upToSeq);
    return { message: 'Delivery recorded.' };
  });

  app.post('/chats/:chatId/messages/read', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z.object({ upToSeq: z.number().int().nonnegative().optional() }).parse(request.body ?? {});
    const watermark = await markRead({ userId: authOf(request).userId, chatId: params.chatId, upToSeq: body.upToSeq });
    return { lastReadSeq: watermark };
  });

  app.post('/chats/:chatId/typing', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    const body = z.object({ typing: z.boolean().default(true) }).parse(request.body ?? {});

    await requireMembership(params.chatId, authOf(request).userId);
    await setTyping(params.chatId, authOf(request).userId, body.typing);
    return { typing: body.typing };
  });

  app.post('/messages/forward', auth, async (request) => {
    const body = z
      .object({ messageIds: z.array(uuidSchema).min(1).max(20), targetChatIds: z.array(uuidSchema).min(1).max(20) })
      .parse(request.body);

    return forwardMessages({ userId: authOf(request).userId, ...body });
  });

  app.get('/messages/starred', auth, async (request) => {
    const query = z.object({ limit: z.coerce.number().int().min(1).max(200).default(100) }).parse(request.query);
    return { messages: await listStarred(authOf(request).userId, query.limit) };
  });

  app.get('/messages/search', auth, async (request) => {
    const query = z
      .object({
        q: z.string().trim().min(2, 'Type at least 2 characters'),
        chatId: uuidSchema.optional(),
        type: z
          .enum(['text', 'image', 'video', 'audio', 'voice', 'document', 'sticker', 'gif', 'location', 'contact', 'poll', 'system'])
          .optional(),
        fromUserId: uuidSchema.optional(),
        after: z.string().datetime().optional(),
        before: z.string().datetime().optional(),
        limit: z.coerce.number().int().min(1).max(100).default(50),
      })
      .parse(request.query);

    // The wire uses `q` for brevity; the service names it `query`.
    return {
      messages: await searchMessages({
        userId: authOf(request).userId,
        query: query.q,
        chatId: query.chatId,
        type: query.type,
        fromUserId: query.fromUserId,
        after: query.after,
        before: query.before,
        limit: query.limit,
      }),
    };
  });

  app.get('/chats/:chatId/members/ids', auth, async (request) => {
    const params = z.object({ chatId: uuidSchema }).parse(request.params);
    await requireMembership(params.chatId, authOf(request).userId);
    return { memberIds: await getChatMemberIds(params.chatId) };
  });

  // -------------------------------------------------------------------------
  // Attachment upload
  // -------------------------------------------------------------------------
  /**
   * Upload one file and get back a storage descriptor to reference when sending
   * the message. Two-step on purpose: the client can show upload progress and
   * retry the file without re-sending the whole message.
   */
  app.post('/media/upload', auth, async (request, reply) => {
    // TEMPORARY DIAGNOSTIC — remove once the "cannot reach the server" upload
    // report is closed. Logs what actually arrives, so a client-side failure can
    // be told apart from a request that never left the phone.
    request.log.warn(
      {
        dbg: 'UPLOADDBG',
        contentType: request.headers['content-type'] ?? null,
        contentLength: request.headers['content-length'] ?? null,
        ua: request.headers['user-agent'] ?? null,
      },
      'UPLOADDBG request arrived',
    );

    const file = await request.file({ limits: { fileSize: 52_428_800, files: 1 } });
    if (!file) throw badRequest(ErrorCodes.VALIDATION_FAILED, 'No file was uploaded');

    if (!isAllowedMimeType(file.mimetype)) {
      // Drain the stream first, or the connection stalls waiting for a body the
      // server will never read.
      await file.toBuffer().catch(() => {});
      throw badRequest(ErrorCodes.UNSUPPORTED_MEDIA, `Files of type ${file.mimetype} are not supported`);
    }

    const buffer = await file.toBuffer();
    const stored = await storeBuffer({
      buffer,
      mimeType: file.mimetype,
      fileName: file.filename,
      userId: authOf(request).userId,
    });

    return reply.code(201).send({
      attachment: {
        kind: inferKind(file.mimetype),
        mimeType: file.mimetype,
        fileName: file.filename,
        byteSize: stored.byteSize,
        storageDriver: stored.storageDriver,
        storageKey: stored.storageKey,
        publicUrl: stored.publicUrl,
        sha256: stored.sha256,
      },
    });
  });
}
