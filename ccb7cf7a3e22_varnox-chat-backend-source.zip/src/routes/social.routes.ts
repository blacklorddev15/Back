import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { emailSchema, phoneSchema, uuidSchema } from '../lib/validation.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import {
  addContact, blockUser, createLabel, createReport, deleteLabel, listBlocked, listContacts,
  listLabels, removeContact, unblockUser, updateContact,
} from '../services/contacts.service.js';
import { matchKnownContacts } from '../services/users.service.js';

/**
 * Contacts, labels, blocking and reporting.
 *
 * A design note on contact sync: the endpoint accepts phone numbers and returns
 * only the ones already registered. It never returns names for unregistered
 * numbers, and the caller's numbers are not stored — matching happens in the
 * query and is discarded. Storing a user's whole address book would create a
 * secondary copy of data that is not ours to keep.
 */
export async function registerSocialRoutes(app: FastifyInstance): Promise<void> {
  const auth = { preHandler: requireAuth };

  // -------------------------------------------------------------------------
  // Contacts
  // -------------------------------------------------------------------------
  app.get('/contacts', auth, async (request) => {
    const query = z
      .object({
        favoritesOnly: z.coerce.boolean().optional(),
        labelId: uuidSchema.optional(),
      })
      .parse(request.query);

    return { contacts: await listContacts(authOf(request).userId, query) };
  });

  app.post('/contacts', auth, async (request, reply) => {
    const body = z
      .object({
        contactUserId: uuidSchema.optional(),
        phone: phoneSchema.optional(),
        email: emailSchema.optional(),
        displayName: z.string().trim().max(120).optional(),
        labelId: uuidSchema.optional(),
        source: z.enum(['manual', 'synced', 'qr', 'suggested', 'imported']).optional(),
      })
      .parse(request.body);

    const result = await addContact({ ownerId: authOf(request).userId, ...body });
    return reply.code(201).send(result);
  });

  app.patch('/contacts/:contactId', auth, async (request) => {
    const params = z.object({ contactId: uuidSchema }).parse(request.params);
    const body = z
      .object({
        displayName: z.string().trim().max(120).optional(),
        labelId: uuidSchema.nullable().optional(),
        isFavorite: z.boolean().optional(),
      })
      .parse(request.body);

    await updateContact(authOf(request).userId, params.contactId, body);
    return { message: 'Contact updated.' };
  });

  app.delete('/contacts/:contactId', auth, async (request) => {
    const params = z.object({ contactId: uuidSchema }).parse(request.params);
    await removeContact(authOf(request).userId, params.contactId);
    return { message: 'Contact removed.' };
  });

  /**
   * Contact sync. Bounded to 2,000 numbers per call: an unbounded list is both
   * a privacy hazard and a cheap way to make the database do expensive work.
   */
  app.post('/contacts/sync', auth, async (request) => {
    const body = z.object({ phones: z.array(z.string().min(6).max(20)).max(2000) }).parse(request.body);
    const matched = await matchKnownContacts(authOf(request).userId, body.phones);
    return { matched, matchedCount: matched.length, checkedCount: body.phones.length };
  });

  // -------------------------------------------------------------------------
  // Labels
  // -------------------------------------------------------------------------
  app.get('/contacts/labels', auth, async (request) => {
    return { labels: await listLabels(authOf(request).userId) };
  });

  app.post('/contacts/labels', auth, async (request, reply) => {
    const body = z
      .object({ name: z.string().trim().min(1).max(40), color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional() })
      .parse(request.body);

    const result = await createLabel(authOf(request).userId, body.name, body.color ?? '#888888');
    return reply.code(201).send(result);
  });

  app.delete('/contacts/labels/:labelId', auth, async (request) => {
    const params = z.object({ labelId: uuidSchema }).parse(request.params);
    await deleteLabel(authOf(request).userId, params.labelId);
    return { message: 'Label deleted.' };
  });

  // -------------------------------------------------------------------------
  // Blocking
  // -------------------------------------------------------------------------
  app.get('/blocks', auth, async (request) => {
    return { blocked: await listBlocked(authOf(request).userId) };
  });

  app.post('/blocks', auth, async (request, reply) => {
    const body = z.object({ userId: uuidSchema, reason: z.string().max(200).optional() }).parse(request.body);
    await blockUser(authOf(request).userId, body.userId, body.reason);
    return reply.code(201).send({
      message: 'User blocked. They can no longer message or call you.',
    });
  });

  app.delete('/blocks/:userId', auth, async (request) => {
    const params = z.object({ userId: uuidSchema }).parse(request.params);
    await unblockUser(authOf(request).userId, params.userId);
    return { message: 'User unblocked.' };
  });

  // -------------------------------------------------------------------------
  // Reporting
  // -------------------------------------------------------------------------
  app.post('/reports', auth, async (request, reply) => {
    const body = z
      .object({
        targetType: z.enum(['user', 'message', 'group', 'channel', 'community', 'status', 'business']),
        targetId: uuidSchema,
        reason: z.enum([
          'spam', 'scam', 'harassment', 'hate', 'violence', 'sexual_content',
          'child_safety', 'impersonation', 'intellectual_property', 'other',
        ]),
        details: z.string().max(2000).optional(),
      })
      .parse(request.body);

    const result = await createReport({ reporterId: authOf(request).userId, ...body });
    return reply.code(201).send({
      ...result,
      message: 'Thanks — your report has been sent to our moderation team.',
    });
  });
}
