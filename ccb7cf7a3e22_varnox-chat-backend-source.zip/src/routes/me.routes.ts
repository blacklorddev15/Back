import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { config } from '../config.js';
import { queryOne } from '../db/pool.js';
import { ErrorCodes, badRequest, forbidden, notFound } from '../lib/errors.js';
import { authenticateForMedia } from '../lib/mediaAuth.js';
import { countryCodeSchema, languageCodeSchema, uuidSchema } from '../lib/validation.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import { getUnreadCount, registerPushToken, unregisterPushToken } from '../services/notifications.service.js';
import {
  getSelf, listDirectory, requestDataExport, searchUsers, updateAppearanceSettings, updateNotificationSettings,
  updatePrivacySettings, updateProfile,
} from '../services/users.service.js';

/** The authenticated user's own profile, settings and privacy controls. */
export async function registerMeRoutes(app: FastifyInstance): Promise<void> {
  app.get('/me', { preHandler: requireAuth }, async (request) => {
    const auth = authOf(request);
    const [self, unreadNotifications] = await Promise.all([getSelf(auth.userId), getUnreadCount(auth.userId)]);
    return { ...self, unreadNotifications };
  });

  /**
   * A member's profile photo.
   *
   * WHY THIS EXISTS: `PATCH /me/profile` accepts `avatarUrl` as a URL, and the
   * upload endpoint hands back a URL built from MEDIA_PUBLIC_BASE_URL — which on
   * this deployment points at a host the phone cannot reach. Saving that URL
   * alone produces a profile photo that uploads successfully and then never
   * displays. This route resolves the stored URL back to the file on disk and
   * streams it, so the column keeps its documented meaning and the picture
   * still renders.
   *
   * Readable by any signed-in member: an avatar appears in the directory, in
   * statuses and in chats, so restricting it to contacts would break all three.
   * A token is accepted from the query string for the same reason as elsewhere —
   * React Native's <Image> cannot reliably send an Authorization header.
   */
  app.get('/me/avatar/:userId', async (request: FastifyRequest, reply: FastifyReply) => {
    const params = z.object({ userId: uuidSchema }).parse(request.params);
    await authenticateForMedia(request);

    const row = await queryOne<{ avatar_url: string | null }>(
      `SELECT avatar_url FROM user_profiles WHERE user_id = $1`,
      [params.userId],
    );
    if (!row?.avatar_url) throw notFound(ErrorCodes.USER_NOT_FOUND, 'No profile photo');

    // Remote storage already serves reachable URLs, so send the client there.
    if (config.MEDIA_DRIVER !== 'local') return reply.redirect(row.avatar_url, 302);

    const key = storageKeyFromUrl(row.avatar_url);
    if (!key) throw badRequest(ErrorCodes.VALIDATION_FAILED, 'The stored photo path is not usable');

    const root = resolve(config.MEDIA_LOCAL_DIR);
    const fullPath = resolve(root, key);
    if (!fullPath.startsWith(root)) {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Invalid storage path');
    }

    let size: number;
    try {
      size = (await stat(fullPath)).size;
    } catch {
      throw notFound(ErrorCodes.USER_NOT_FOUND, 'The stored file is missing');
    }

    reply.header('Content-Type', contentTypeFor(key));
    reply.header('Content-Length', String(size));
    reply.header('Cache-Control', 'private, max-age=86400');
    return reply.send(createReadStream(fullPath));
  });

  app.patch('/me/profile', { preHandler: requireAuth }, async (request) => {
    const body = z
      .object({
        displayName: z.string().trim().min(1).max(120).optional(),
        about: z.string().max(280).optional(),
        avatarUrl: z.string().url().max(2048).optional(),
        dateOfBirth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
        countryCode: countryCodeSchema.nullable().optional(),
        languageCode: languageCodeSchema.optional(),
        timezone: z.string().max(60).optional(),
      })
      .parse(request.body);

    await updateProfile(authOf(request).userId, body);
    return { profile: await getSelf(authOf(request).userId) };
  });

  const privacyPatchSchema = z
    .object({
      lastSeenVisibility: z.enum(['everyone', 'contacts', 'contacts_except', 'nobody']).optional(),
      onlineVisibility: z.enum(['everyone', 'contacts', 'contacts_except', 'nobody']).optional(),
      profilePhotoVisibility: z.enum(['everyone', 'contacts', 'contacts_except', 'nobody']).optional(),
      aboutVisibility: z.enum(['everyone', 'contacts', 'contacts_except', 'nobody']).optional(),
      statusVisibility: z.enum(['everyone', 'contacts', 'contacts_except', 'nobody']).optional(),
      readReceiptsEnabled: z.boolean().optional(),
      typingIndicatorEnabled: z.boolean().optional(),
      liveLocationEnabled: z.boolean().optional(),
      groupInvitePolicy: z.enum(['everyone', 'contacts', 'contacts_except', 'nobody']).optional(),
      discoverableByEmail: z.boolean().optional(),
      discoverableByPhone: z.boolean().optional(),
      discoverableByUsername: z.boolean().optional(),
      silenceUnknownCallers: z.boolean().optional(),
      screenshotProtection: z.boolean().optional(),
        securityNotifications: z.boolean().optional(),
      });

  app.patch('/me/privacy', { preHandler: requireAuth }, async (request) => {
    const body = privacyPatchSchema.parse(request.body);

    // camelCase in the API, snake_case in the database.
    const mapped: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(body)) {
      mapped[key.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`)] = value;
    }
    await updatePrivacySettings(authOf(request).userId, mapped);
    return { privacy: (await getSelf(authOf(request).userId)).privacy };
  });

  app.patch('/me/notifications', { preHandler: requireAuth }, async (request) => {
    const body = z
      .object({
        previewsEnabled: z.boolean().optional(),
        inAppEnabled: z.boolean().optional(),
        vibrationEnabled: z.boolean().optional(),
        vibrationPattern: z.string().max(40).optional(),
        defaultSound: z.string().max(60).optional(),
        notificationPrivacy: z.enum(['sender_and_message', 'sender_only', 'hidden']).optional(),
        badgeEnabled: z.boolean().optional(),
        emailSecurityAlerts: z.boolean().optional(),
        quietHoursStart: z.string().regex(/^\d{2}:\d{2}$/).nullable().optional(),
        quietHoursEnd: z.string().regex(/^\d{2}:\d{2}$/).nullable().optional(),
      })
      .parse(request.body);

    const mapped: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(body)) {
      mapped[key.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`)] = value;
    }
    await updateNotificationSettings(authOf(request).userId, mapped);
    return { notifications: (await getSelf(authOf(request).userId)).notifications };
  });

  app.patch('/me/appearance', { preHandler: requireAuth }, async (request) => {
    const body = z
      .object({
        theme: z.enum(['light', 'dark', 'system']).optional(),
        accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
        chatWallpaper: z.string().max(500).nullable().optional(),
        fontScale: z.number().min(0.8).max(2).optional(),
        highContrast: z.boolean().optional(),
        reduceMotion: z.boolean().optional(),
      })
      .parse(request.body);

    const mapped: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(body)) {
      mapped[key.replace(/[A-Z]/g, (c) => `_${c.toLowerCase()}`)] = value;
    }
    await updateAppearanceSettings(authOf(request).userId, mapped);
    return { appearance: (await getSelf(authOf(request).userId)).appearance };
  });

  // -------------------------------------------------------------------------
  // Privacy checkup — one call the client can use to show a summary screen
  // -------------------------------------------------------------------------
  app.get('/me/privacy-checkup', { preHandler: requireAuth }, async (request) => {
    const userId = authOf(request).userId;
    const self = await getSelf(userId);
    const privacy = (self.privacy ?? {}) as Record<string, unknown>;

    const findings: { key: string; severity: 'info' | 'warning'; message: string }[] = [];
    if (privacy.last_seen_visibility === 'everyone') {
      findings.push({ key: 'last_seen', severity: 'info', message: 'Everyone can see when you were last online.' });
    }
    if (privacy.read_receipts_enabled === false) {
      findings.push({ key: 'read_receipts', severity: 'info', message: 'Read receipts are off — you also will not see others’.' });
    }
    if (self.two_step_enabled === false) {
      findings.push({ key: 'two_step', severity: 'warning', message: 'Two-step verification is off.' });
    }
    if (self.email_verified_at === null) {
      findings.push({ key: 'email', severity: 'warning', message: 'Your email address is not verified.' });
    }
    if (privacy.discoverable_by_phone === true) {
      findings.push({ key: 'phone_discovery', severity: 'info', message: 'People who have your number can find you by phone.' });
    }

    return { findings, checkedAt: new Date().toISOString() };
  });

  // -------------------------------------------------------------------------
  // Push tokens
  // -------------------------------------------------------------------------
  app.post('/me/push-token', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ deviceId: uuidSchema, token: z.string().min(8).max(255), platform: z.string().max(20) }).parse(request.body);
    await registerPushToken({ userId: authOf(request).userId, ...body });
    return { message: 'Push notifications enabled for this device.' };
  });

  app.delete('/me/push-token', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ deviceId: uuidSchema }).parse(request.body);
    await unregisterPushToken(authOf(request).userId, body.deviceId);
    return { message: 'Push notifications disabled for this device.' };
  });

  // -------------------------------------------------------------------------
  // Data export
  // -------------------------------------------------------------------------
  app.post('/me/data-export', { preHandler: requireAuth }, async (request) => {
    const result = await requestDataExport(authOf(request).userId);
    return {
      requestId: result.requestId,
      message: 'Your export has been queued. You will be able to download it when it is ready.',
    };
  });

  // -------------------------------------------------------------------------
  // People discovery
  // -------------------------------------------------------------------------
  app.get('/users/search', { preHandler: requireAuth }, async (request) => {
    const query = z
      .object({ q: z.string().trim().min(3, 'Type at least 3 characters'), limit: z.coerce.number().int().min(1).max(50).default(20) })
      .parse(request.query);

    return { results: await searchUsers({ requesterId: authOf(request).userId, query: query.q, limit: query.limit }) };
  });

  /**
   * The browsable people directory.
   *
   * Unlike /users/search this needs no search term: with no `q` it returns the
   * whole member list, oldest account first, so the app can open straight into a
   * populated list instead of an empty prompt. `q` narrows it by display name or
   * username — a substring match, because this is browsing, not lookup.
   *
   * Never returns email or phone. Those remain available only through the
   * exact-match /users/search.
   */
  app.get('/users/directory', { preHandler: requireAuth }, async (request) => {
    const params = z
      .object({
        q: z.string().trim().max(120).optional(),
        limit: z.coerce.number().int().min(1).max(200).default(50),
        offset: z.coerce.number().int().min(0).default(0),
      })
      .parse(request.query);

    return listDirectory({
      requesterId: authOf(request).userId,
      query: params.q,
      limit: params.limit,
      offset: params.offset,
    });
  });
}

/**
 * Recovers the on-disk key from a stored media URL.
 *
 * The upload endpoint returns something like
 * `<MEDIA_PUBLIC_BASE_URL>/2026/09/ab12….jpg`, and that whole string is what
 * gets saved as `avatar_url`. The key is the part after the base path, so the
 * base is trimmed rather than assumed — otherwise every lookup would miss the
 * moment someone configures a different prefix.
 */
function storageKeyFromUrl(value: string): string | null {
  try {
    const path = new URL(value).pathname;
    const base = new URL(config.MEDIA_PUBLIC_BASE_URL).pathname.replace(/\/+$/, '');
    const relative = base && path.startsWith(base) ? path.slice(base.length) : path;
    const key = decodeURIComponent(relative.replace(/^\/+/, ''));
    return key.length > 0 ? key : null;
  } catch {
    return null;
  }
}

/** Minimal extension → type map; the uploads this serves are images. */
function contentTypeFor(key: string): string {
  const extension = key.slice(key.lastIndexOf('.') + 1).toLowerCase();
  switch (extension) {
    case 'png':
      return 'image/png';
    case 'gif':
      return 'image/gif';
    case 'webp':
      return 'image/webp';
    case 'heic':
      return 'image/heic';
    default:
      return 'image/jpeg';
  }
}
