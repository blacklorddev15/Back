import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { config } from '../config.js';
import { ErrorCodes, badRequest } from '../lib/errors.js';
import { verifyAccessToken } from '../lib/jwt.js';
import {
  emailSchema, otpSchema, passwordSchema, phoneSchema, pinSchema, usernameSchema,
} from '../lib/validation.js';
import {
  cancelAccountDeletion, changePassword, changePhoneNumber, completeTwoStepLogin,
  confirmEmailChange, disableTwoStep, getPublicUser, listDevices, login, logout,
  logoutAllSessions, refreshSession, registerUser, requestAccountDeletion,
  requestEmailChange, requestPasswordReset, resetPassword, revokeDevice,
  setTwoStepPin, setUsername, verifyEmailAndActivate,
} from '../services/auth.service.js';
import { requestOtp } from '../services/otp.service.js';
import { getSecurityLog } from '../services/users.service.js';
import { authOf, clientIp, requireAuth, userAgent } from '../middleware/auth.js';

/**
 * Authentication routes.
 *
 * Convention: handlers stay thin. Anything with a rule in it (lockouts, attempt
 * counters, rotation) lives in auth.service.ts so it can be reused by the
 * admin tooling and covered by tests without an HTTP layer.
 */

const deviceSchema = z.object({
  deviceId: z.string().uuid().optional(),
  platform: z.enum(['android', 'ios', 'web', 'windows', 'macos', 'linux', 'unknown']).optional(),
  deviceName: z.string().max(120).optional(),
  appVersion: z.string().max(40).optional(),
  osVersion: z.string().max(40).optional(),
  pushToken: z.string().max(255).optional(),
});

export async function registerAuthRoutes(app: FastifyInstance): Promise<void> {
  // -------------------------------------------------------------------------
  // Registration — email + phone, code delivered to EMAIL
  // -------------------------------------------------------------------------
  app.post('/auth/register', async (request, reply) => {
    const body = z
      .object({
        fullName: z.string().trim().min(1, 'Full name is required').max(120),
        email: emailSchema,
        phone: phoneSchema,
        password: passwordSchema,
      })
      .parse(request.body);

    const result = await registerUser({
      ...body,
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });

    return reply.code(201).send({
      userId: result.userId,
      message: 'We sent a verification code to your email address.',
      codeExpiresAt: result.expiresAt,
      // Present only with the console mail transport, for local development.
      devCode: config.MAIL_TRANSPORT === 'console' ? undefined : undefined,
    });
  });

  app.post('/auth/verify-email', async (request) => {
    const body = z
      .object({ email: emailSchema, code: otpSchema, device: deviceSchema.default({}) })
      .parse(request.body);

    const result = await verifyEmailAndActivate({
      email: body.email,
      code: body.code,
      device: body.device,
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });

    return { user: result.user, tokens: result.tokens, deviceId: result.deviceId };
  });

  app.post('/auth/resend-verification', async (request) => {
    const body = z.object({ email: emailSchema }).parse(request.body);
    const result = await requestOtp({
      destination: body.email,
      purpose: 'register',
      ip: clientIp(request),
      // The cooldown still applies to resends, but a user who mistyped nothing
      // and simply did not receive the mail should not wait for the first send.
      enforceCooldown: true,
    });
    return { message: 'If that address needs verification, a new code is on its way.', expiresAt: result.expiresAt };
  });

  // -------------------------------------------------------------------------
  // Login
  // -------------------------------------------------------------------------
  app.post('/auth/login', async (request) => {
    const body = z
      .object({
        identifier: z.string().trim().min(3, 'Enter your email, phone number or username'),
        password: z.string().min(1, 'Password is required'),
        device: deviceSchema.default({}),
      })
      .parse(request.body);

    const result = await login({
      identifier: body.identifier,
      password: body.password,
      device: body.device,
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });

    if (result.twoStepRequired) {
      return {
        twoStepRequired: true as const,
        challengeToken: result.challengeToken,
        message: 'Enter your two-step verification PIN to finish signing in.',
      };
    }

    return { twoStepRequired: false as const, user: result.user, tokens: result.tokens, deviceId: result.deviceId };
  });

  app.post('/auth/two-step/verify', async (request) => {
    const body = z
      .object({ challengeToken: z.string().min(10), pin: pinSchema, device: deviceSchema.default({}) })
      .parse(request.body);

    const result = await completeTwoStepLogin({
      challengeToken: body.challengeToken,
      pin: body.pin,
      device: body.device,
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });

    return { user: result.user, tokens: result.tokens, deviceId: result.deviceId };
  });

  // -------------------------------------------------------------------------
  // Session lifecycle
  // -------------------------------------------------------------------------
  app.post('/auth/refresh', async (request) => {
    const body = z.object({ refreshToken: z.string().min(20) }).parse(request.body);
    const tokens = await refreshSession({
      refreshToken: body.refreshToken,
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });
    return { tokens };
  });

  app.post('/auth/logout', async (request) => {
    const body = z.object({ refreshToken: z.string().min(20) }).parse(request.body);
    await logout(body.refreshToken);
    return { loggedOut: true };
  });

  /**
   * Remote logout: end every session.
   *
   * A separate route with its own preHandler rather than a flag on /auth/logout,
   * because this is the destructive variant and must require a valid access
   * token — a bare refresh token is not sufficient authority to sign out every
   * device a user owns.
   */
  app.post('/auth/logout/all', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ includeCurrentDevice: z.boolean().default(false) }).parse(request.body ?? {});
    const auth = authOf(request);

    const count = await logoutAllSessions(auth.userId, body.includeCurrentDevice ? undefined : auth.sessionId);
    return { loggedOut: true, sessionsEnded: count, currentDeviceKept: !body.includeCurrentDevice };
  });

  // -------------------------------------------------------------------------
  // Password recovery
  // -------------------------------------------------------------------------
  app.post('/auth/password/forgot', async (request) => {
    const body = z.object({ email: emailSchema }).parse(request.body);
    await requestPasswordReset(body.email, { ip: clientIp(request), userAgent: userAgent(request) });
    // Same response whether or not the account exists.
    return { message: 'If an account exists for that address, a reset code is on its way.' };
  });

  app.post('/auth/password/reset', async (request) => {
    const body = z
      .object({ email: emailSchema, code: otpSchema, newPassword: passwordSchema })
      .parse(request.body);

    await resetPassword({
      email: body.email,
      code: body.code,
      newPassword: body.newPassword,
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });
    return { message: 'Your password has been reset. Sign in with your new password.' };
  });

  app.post('/auth/password/change', { preHandler: requireAuth }, async (request) => {
    const body = z
      .object({ currentPassword: z.string().min(1), newPassword: passwordSchema })
      .parse(request.body);

    const auth = authOf(request);
    await changePassword({
      userId: auth.userId,
      currentPassword: body.currentPassword,
      newPassword: body.newPassword,
      keepSessionId: auth.sessionId, // keep the current device signed in
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });
    return { message: 'Password updated. Other devices have been signed out.' };
  });

  // -------------------------------------------------------------------------
  // Email & phone changes
  // -------------------------------------------------------------------------
  app.post('/auth/email/change/request', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ newEmail: emailSchema }).parse(request.body);
    const expiresAt = await requestEmailChange(authOf(request).userId, body.newEmail, {
      ip: clientIp(request),
      userAgent: userAgent(request),
    });
    return { message: 'We sent a verification code to the new address.', expiresAt };
  });

  app.post('/auth/email/change/confirm', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ newEmail: emailSchema, code: otpSchema }).parse(request.body);
    await confirmEmailChange({
      userId: authOf(request).userId,
      newEmail: body.newEmail,
      code: body.code,
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });
    return { message: 'Email address updated.' };
  });

  app.post('/auth/phone/change', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ newPhone: phoneSchema }).parse(request.body);
    await changePhoneNumber(authOf(request).userId, body.newPhone, {
      ip: clientIp(request),
      userAgent: userAgent(request),
    });
    return {
      message: 'Phone number updated.',
      note: 'Phone numbers are collected for contact discovery and are not independently verified.',
    };
  });

  // -------------------------------------------------------------------------
  // Two-step verification
  // -------------------------------------------------------------------------
  app.post('/auth/two-step/enable', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ password: z.string().min(1), pin: pinSchema }).parse(request.body);
    const result = await setTwoStepPin({
      userId: authOf(request).userId,
      password: body.password,
      pin: body.pin,
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });
    return {
      message: 'Two-step verification is on. Store these backup codes somewhere safe — each works once.',
      backupCodes: result.backupCodes,
    };
  });

  app.post('/auth/two-step/disable', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ password: z.string().min(1) }).parse(request.body);
    await disableTwoStep({
      userId: authOf(request).userId,
      password: body.password,
      ctx: { ip: clientIp(request), userAgent: userAgent(request) },
    });
    return { message: 'Two-step verification is off.' };
  });

  // -------------------------------------------------------------------------
  // Devices & security log
  // -------------------------------------------------------------------------
  app.get('/auth/devices', { preHandler: requireAuth }, async (request) => {
    return { devices: await listDevices(authOf(request).userId) };
  });

  app.delete('/auth/devices/:deviceId', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ deviceId: z.string().uuid() }).parse(request.params);
    await revokeDevice(authOf(request).userId, params.deviceId);
    return { message: 'That device has been signed out.' };
  });

  app.get('/auth/security-log', { preHandler: requireAuth }, async (request) => {
    const query = z.object({ limit: z.coerce.number().int().min(1).max(200).default(50) }).parse(request.query);
    return { events: await getSecurityLog(authOf(request).userId, query.limit) };
  });

  // -------------------------------------------------------------------------
  // Account deletion & recovery
  // -------------------------------------------------------------------------
  app.post('/auth/account/delete', { preHandler: requireAuth }, async (request) => {
    const scheduledFor = await requestAccountDeletion(authOf(request).userId, {
      ip: clientIp(request),
      userAgent: userAgent(request),
    });
    return {
      message: 'Your account is scheduled for deletion.',
      scheduledFor,
      recoverable: 'Sign in again before that date and use the cancel endpoint to restore the account.',
    };
  });

  app.post('/auth/account/delete/cancel', { preHandler: requireAuth }, async (request) => {
    await cancelAccountDeletion(authOf(request).userId, { ip: clientIp(request), userAgent: userAgent(request) });
    return { message: 'Account deletion cancelled.' };
  });

  // -------------------------------------------------------------------------
  // Username + passkeys
  // -------------------------------------------------------------------------
  app.post('/auth/username', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ username: usernameSchema }).parse(request.body);
    await setUsername(authOf(request).userId, body.username);
    const user = await getPublicUser(authOf(request).userId);
    return { user };
  });

  /**
   * Passkey (WebAuthn) login is not implemented.
   *
   * Returning 501 rather than a stub is deliberate: a half-implemented
   * credential flow that "works" in testing is a security hole in production.
   * Implementing this properly needs @simplewebauthn/server to generate the
   * challenge, verify the attestation on registration and verify the assertion
   * signature on login, plus a signed challenge store. The `auth_passkeys`
   * table is already in place for the credentials themselves.
   */
  app.post('/auth/passkey/register', { preHandler: requireAuth }, async (_request, reply) => {
    return reply.code(501).send({
      error: 'not_implemented',
      message:
        'Passkey support requires WebAuthn attestation verification (@simplewebauthn/server) and a challenge store. ' +
        'The auth_passkeys table is ready; the verification step is not built yet.',
    });
  });

  app.post('/auth/passkey/login', async (_request, reply) => {
    return reply.code(501).send({
      error: 'not_implemented',
      message: 'Passkey login is not implemented yet.',
    });
  });

  /** Lets a client confirm a token is still good without hitting a data route. */
  app.get('/auth/session', { preHandler: requireAuth }, async (request) => {
    const auth = authOf(request);
    return {
      userId: auth.userId,
      sessionId: auth.sessionId,
      deviceId: auth.deviceId ?? null,
      role: auth.role,
      user: await getPublicUser(auth.userId),
    };
  });

  /** Introspection endpoint, for debugging token contents locally. */
  app.post('/auth/debug/verify-token', async (request) => {
    if (config.isProduction) throw badRequest(ErrorCodes.FORBIDDEN_ACTION, 'Not available in production');
    const body = z.object({ token: z.string() }).parse(request.body);
    return verifyAccessToken(body.token);
  });
}
