import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { z } from 'zod';
import { config } from '../config.js';
import { queryOne } from '../db/pool.js';
import { ErrorCodes, badRequest, forbidden, notFound } from '../lib/errors.js';
import { authenticateForMedia } from '../lib/mediaAuth.js';

/**
 * Attachment delivery.
 *
 * WHY THIS EXISTS: with MEDIA_DRIVER=local the upload endpoint stores bytes on
 * disk and returns a `publicUrl` built from MEDIA_PUBLIC_BASE_URL — but nothing
 * serves that path, so images upload successfully and then never render. This
 * route is the missing half.
 *
 * WHY BY ID RATHER THAN BY STORAGE KEY: access control. Fetching
 * `/media/<storageKey>` would let anyone who learns a key read any file, and
 * keys leak (logs, screenshots, forwarded URLs). Resolving through the
 * attachment id lets us check chat membership first, which is the actual rule:
 * you may read a file if you may read the message it belongs to.
 *
 * AUTH VIA QUERY TOKEN: React Native's <Image> cannot be given an
 * Authorization header reliably across platforms, so a token is also accepted
 * from the query string — the same trade-off already made for the WebSocket
 * endpoint. Tokens are short-lived (15 minutes) which bounds the exposure.
 */

// authenticateForMedia now lives in lib/mediaAuth.ts so the status-media route
// shares exactly the same rules instead of a second copy that could drift.

export async function registerAttachmentRoutes(app: FastifyInstance): Promise<void> {
  app.get('/attachments/:attachmentId', async (request: FastifyRequest, reply: FastifyReply) => {
    const params = z.object({ attachmentId: z.string().uuid() }).parse(request.params);
    const userId = await authenticateForMedia(request);

    // One query answers both "does this exist" and "may this user see it".
    const row = await queryOne<{
      id: string;
      kind: string;
      mime_type: string;
      file_name: string | null;
      byte_size: string | number;
      storage_driver: string;
      storage_key: string;
      message_id: string;
      is_deleted: boolean;
    }>(
      `SELECT a.id, a.kind, a.mime_type, a.file_name, a.byte_size,
              a.storage_driver, a.storage_key,
              m.id AS message_id, m.is_deleted
         FROM attachments a
         JOIN messages m ON m.id = a.message_id
         JOIN chat_members cm
           ON cm.chat_id = m.chat_id
          AND cm.user_id = $2
          AND cm.left_at IS NULL
          AND cm.status = 'active'
        WHERE a.id = $1`,
      [params.attachmentId, userId],
    );

    // Deliberately the same 404 for "no such attachment" and "not your chat":
    // distinguishing them would leak the existence of other people's media.
    if (!row) throw notFound(ErrorCodes.MESSAGE_NOT_FOUND, 'Attachment not found');
    if (row.is_deleted) throw notFound(ErrorCodes.MESSAGE_ALREADY_DELETED, 'That message was deleted');

    if (row.storage_driver !== 'local') {
      // Object storage: hand the client the object URL. For a private bucket,
      // replace this with a signed URL rather than a redirect.
      if (!config.S3_ENDPOINT || !config.S3_BUCKET) {
        throw badRequest(ErrorCodes.INTERNAL, 'Object storage is not configured');
      }
      const url = `${config.S3_ENDPOINT.replace(/\/$/, '')}/${config.S3_BUCKET}/${row.storage_key}`;
      return reply.redirect(url, 302);
    }

    const root = resolve(config.MEDIA_LOCAL_DIR);
    const fullPath = resolve(root, row.storage_key);

    // Path traversal guard. storage_key comes from the database, so it should
    // never escape the root — but a database is not a trust boundary, and this
    // check costs nothing.
    if (!fullPath.startsWith(root)) {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Invalid storage path');
    }

    let size: number;
    try {
      const info = await stat(fullPath);
      size = info.size;
    } catch {
      throw notFound('not_found', 'The stored file is missing');
    }

    reply.header('Content-Type', row.mime_type);
    reply.header('Content-Length', String(size));
    // Private: this is one user's copy behind their own token, so no shared
    // caches may store it.
    reply.header('Cache-Control', 'private, max-age=3600');
    reply.header(
      'Content-Disposition',
      `${row.kind === 'document' ? 'attachment' : 'inline'}; filename="${(row.file_name ?? row.id).replace(/["\\\r\n]/g, '')}"`,
    );

    return reply.send(createReadStream(fullPath));
  });

  /**
   * Cheap existence/metadata probe so a client can decide whether to render an
   * <Image> or a download row without pulling the bytes.
   */
  app.get('/attachments/:attachmentId/meta', async (request) => {
    const params = z.object({ attachmentId: z.string().uuid() }).parse(request.params);
    const userId = await authenticateForMedia(request);

    const row = await queryOne(
      `SELECT a.id, a.kind, a.mime_type, a.file_name, a.byte_size, a.width, a.height, a.duration_ms
         FROM attachments a
         JOIN messages m ON m.id = a.message_id
         JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = $2 AND cm.left_at IS NULL
        WHERE a.id = $1 AND m.is_deleted = false`,
      [params.attachmentId, userId],
    );
    if (!row) throw notFound(ErrorCodes.MESSAGE_NOT_FOUND, 'Attachment not found');
    return { attachment: row };
  });
}
