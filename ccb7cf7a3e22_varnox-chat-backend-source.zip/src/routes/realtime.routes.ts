import { randomUUID } from 'node:crypto';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { verifyAccessToken } from '../lib/jwt.js';
import { queryOne } from '../db/pool.js';
import {
  addConnection, connectionCount, hubStats, publishToChat, removeConnection, setTyping, touchConnection,
} from '../realtime/hub.js';
import { requireAuth } from '../middleware/auth.js';
import { markDelivered, markRead } from '../services/messages.service.js';
import { requireMembership } from '../services/chats.service.js';

/**
 * WebSocket endpoint.
 *
 * AUTHENTICATION: browsers cannot set an Authorization header on a WebSocket
 * handshake, so the token arrives as a query parameter. That places it in
 * server logs and browser history, which is a real, accepted trade-off — the
 * mitigation is that access tokens are short-lived (15 minutes) and the socket
 * re-authenticates on reconnect. Prefer the header when the client is not a
 * browser.
 *
 * Every inbound frame is treated as untrusted: membership is re-checked for
 * anything that touches a conversation, so a socket from a removed user cannot
 * keep injecting typing indicators or read receipts.
 */

interface InboundFrame {
  type: string;
  chatId?: string;
  upToSeq?: number;
  typing?: boolean;
  t?: number;
}

export async function registerRealtimeRoutes(app: FastifyInstance): Promise<void> {
  app.get('/ws', { websocket: true }, async (socket, request) => {
    const query = z
      .object({ token: z.string().optional(), deviceId: z.string().uuid().optional() })
      .parse(request.query);

    const header = request.headers.authorization;
    const token = query.token ?? (header?.startsWith('Bearer ') ? header.slice(7) : undefined);

    if (!token) {
      socket.close(4401, 'authentication required');
      return;
    }

    const verified = verifyAccessToken(token);
    if (!verified.ok) {
      socket.close(4401, `invalid token: ${verified.reason}`);
      return;
    }
    if (verified.claims.stage !== 'full') {
      socket.close(4403, 'two-step verification required');
      return;
    }

    const session = await queryOne<{ revoked_at: Date | null }>(
      `SELECT revoked_at FROM sessions WHERE id = $1`,
      [verified.claims.sid],
    );
    if (!session || session.revoked_at) {
      socket.close(4401, 'session ended');
      return;
    }

    const userId = verified.claims.sub;
    const socketId = randomUUID();
    const deviceId = query.deviceId ?? verified.claims.did ?? null;

    addConnection({ socket, userId, deviceId, socketId });

    socket.send(
      JSON.stringify({
        type: 'ready',
        userId,
        serverTime: new Date().toISOString(),
        connections: connectionCount(userId),
      }),
    );

    // Mark the device as recently active so presence survives a restart.
    if (deviceId) {
      void queryOne(`UPDATE devices SET last_seen_at = now() WHERE id = $1`, [deviceId]).catch(() => {});
    }

    socket.on('message', async (raw: Buffer) => {
      let frame: InboundFrame;
      try {
        frame = JSON.parse(raw.toString('utf8')) as InboundFrame;
      } catch {
        socket.send(JSON.stringify({ type: 'error', code: 'bad_frame', message: 'Frames must be JSON' }));
        return;
      }

      try {
        switch (frame.type) {
          case 'pong':
            touchConnection(socketId);
            break;

          case 'ping':
            socket.send(JSON.stringify({ type: 'pong', t: frame.t ?? Date.now() }));
            break;

          case 'typing.start':
          case 'typing.stop': {
            if (!frame.chatId) throw new Error('chatId is required');
            await requireMembership(frame.chatId, userId);
            await setTyping(frame.chatId, userId, frame.type === 'typing.start');
            break;
          }

          case 'delivered': {
            if (!frame.chatId) throw new Error('chatId is required');
            await requireMembership(frame.chatId, userId);
            await markDelivered(userId, frame.chatId, frame.upToSeq);
            break;
          }

          case 'read': {
            if (!frame.chatId) throw new Error('chatId is required');
            await requireMembership(frame.chatId, userId);
            await markRead({ userId, chatId: frame.chatId, upToSeq: frame.upToSeq });
            break;
          }

          case 'subscribe': {
            if (!frame.chatId) throw new Error('chatId is required');
            await requireMembership(frame.chatId, userId);
            // No server-side subscription state is kept: fan-out is driven by
            // live membership in publishToChat, which cannot go stale the way a
            // cached subscription list can.
            socket.send(JSON.stringify({ type: 'ready', userId, serverTime: new Date().toISOString() }));
            break;
          }

          default:
            socket.send(JSON.stringify({ type: 'error', code: 'unknown_type', message: `Unsupported frame type: ${frame.type}` }));
        }
      } catch (err) {
        socket.send(
          JSON.stringify({
            type: 'error',
            code: 'frame_failed',
            message: err instanceof Error ? err.message : 'Frame could not be processed',
          }),
        );
      }
    });

    socket.on('close', () => {
      removeConnection(socketId);
    });

    socket.on('error', () => {
      removeConnection(socketId);
    });
  });

  app.get('/ws/stats', async () => hubStats());

  // Exposed so a client can poll for delivery/read state if the socket drops
  // and it does not want to re-fetch whole conversations.
  app.get('/realtime/status', { preHandler: requireAuth }, async (request) => {
    const userId = request.auth!.userId;
    return { online: connectionCount(userId) > 0, connections: connectionCount(userId), hub: hubStats() };
  });

  app.post('/realtime/broadcast', { preHandler: requireAuth }, async (request) => {
    const body = z.object({ chatId: z.string().uuid(), event: z.record(z.unknown()) }).parse(request.body);
    const userId = request.auth!.userId;

    await requireMembership(body.chatId, userId);
    // Only a small allowlist of event types may be injected by a client.
    await publishToChat(body.chatId, { type: 'chat.updated', chatId: body.chatId, chat: body.event });
    return { broadcast: true };
  });
}
