import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { uuidSchema } from '../lib/validation.js';
import { authOf, requireAuth } from '../middleware/auth.js';
import {
  createChannel,
  createChannelPost,
  deleteChannelPost,
  followChannel,
  getChannel,
  listChannelPosts,
  listMyChannels,
  markChannelRead,
  reactToChannelPost,
  searchChannels,
  setChannelMuted,
  unfollowChannel,
  updateChannel,
} from '../services/channels.service.js';

/** Channels — one-to-many broadcast, follow to read. */
export async function registerChannelRoutes(app: FastifyInstance): Promise<void> {
  const postAttachmentSchema = z.object({
    kind: z.enum(['image', 'video', 'audio', 'document']),
    mimeType: z.string().max(120),
    storageKey: z.string().max(512),
    byteSize: z.number().int().nonnegative().optional(),
    width: z.number().int().positive().optional(),
    height: z.number().int().positive().optional(),
    durationMs: z.number().int().nonnegative().optional(),
  });

  /** The directory. `q` searches name, handle and description. */
  app.get('/channels', { preHandler: requireAuth }, async (request) => {
    const params = z
      .object({
        q: z.string().trim().max(120).optional(),
        category: z.string().trim().max(60).optional(),
        limit: z.coerce.number().int().min(1).max(100).default(30),
        offset: z.coerce.number().int().min(0).default(0),
      })
      .parse(request.query);

    return searchChannels({
      requesterId: authOf(request).userId,
      search: params.q,
      category: params.category,
      limit: params.limit,
      offset: params.offset,
    });
  });

  /**
   * Channels you follow or own. Declared before /channels/:channelId so the
   * literal segment is unambiguous.
   */
  app.get('/channels/mine', { preHandler: requireAuth }, async (request) => ({
    channels: await listMyChannels(authOf(request).userId),
  }));

  app.post('/channels', { preHandler: requireAuth }, async (request, reply) => {
    const body = z
      .object({
        name: z.string().trim().min(3).max(80),
        description: z.string().trim().max(500).optional(),
        category: z.string().trim().max(60).optional(),
        handle: z.string().trim().max(40).optional(),
        isPublic: z.boolean().optional(),
      })
      .parse(request.body);

    const channel = await createChannel({ ownerId: authOf(request).userId, ...body });
    return reply.code(201).send({ channel });
  });

  app.get('/channels/:channelId', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ channelId: uuidSchema }).parse(request.params);
    return { channel: await getChannel({ channelId: params.channelId, requesterId: authOf(request).userId }) };
  });

  app.patch('/channels/:channelId', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ channelId: uuidSchema }).parse(request.params);
    const body = z
      .object({
        name: z.string().trim().min(3).max(80).optional(),
        description: z.string().trim().max(500).optional(),
        category: z.string().trim().max(60).optional(),
        photoUrl: z.string().url().max(2048).optional(),
        isPublic: z.boolean().optional(),
      })
      .parse(request.body);

    return {
      channel: await updateChannel({ channelId: params.channelId, requesterId: authOf(request).userId, ...body }),
    };
  });

  app.post('/channels/:channelId/follow', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ channelId: uuidSchema }).parse(request.params);
    return { channel: await followChannel(params.channelId, authOf(request).userId) };
  });

  app.delete('/channels/:channelId/follow', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ channelId: uuidSchema }).parse(request.params);
    return { channel: await unfollowChannel(params.channelId, authOf(request).userId) };
  });

  app.put('/channels/:channelId/mute', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ channelId: uuidSchema }).parse(request.params);
    const body = z.object({ muted: z.boolean() }).parse(request.body);
    return setChannelMuted(params.channelId, authOf(request).userId, body.muted);
  });

  /** Clears the unread watermark, so "N new posts" resets. */
  app.post('/channels/:channelId/read', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ channelId: uuidSchema }).parse(request.params);
    return markChannelRead(params.channelId, authOf(request).userId);
  });

  app.get('/channels/:channelId/posts', { preHandler: requireAuth }, async (request) => {
    const params = z.object({ channelId: uuidSchema }).parse(request.params);
    const query = z
      .object({
        limit: z.coerce.number().int().min(1).max(100).default(30),
        beforeSeq: z.coerce.number().int().nonnegative().optional(),
      })
      .parse(request.query);

    return {
      posts: await listChannelPosts({
        channelId: params.channelId,
        requesterId: authOf(request).userId,
        limit: query.limit,
        beforeSeq: query.beforeSeq,
      }),
    };
  });

  app.post('/channels/:channelId/posts', { preHandler: requireAuth }, async (request, reply) => {
    const params = z.object({ channelId: uuidSchema }).parse(request.params);
    const body = z
      .object({
        type: z.enum(['text', 'image', 'video', 'audio']),
        body: z.string().max(4000).optional(),
        attachments: z.array(postAttachmentSchema).max(10).optional(),
      })
      .parse(request.body);

    const post = await createChannelPost({
      channelId: params.channelId,
      requesterId: authOf(request).userId,
      ...body,
    });
    return reply.code(201).send({ post });
  });

  app.delete('/channels/:channelId/posts/:postId', { preHandler: requireAuth }, async (request, reply) => {
    const params = z.object({ channelId: uuidSchema, postId: uuidSchema }).parse(request.params);
    await deleteChannelPost(params.channelId, params.postId, authOf(request).userId);
    return reply.code(204).send();
  });

  app.post('/channels/posts/:postId/reactions', { preHandler: requireAuth }, async (request, reply) => {
    const params = z.object({ postId: uuidSchema }).parse(request.params);
    const body = z.object({ emoji: z.string().min(1).max(16) }).parse(request.body);
    await reactToChannelPost(params.postId, authOf(request).userId, body.emoji);
    return reply.code(204).send();
  });
}
