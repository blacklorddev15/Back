import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { query, queryOne, withTransaction } from '../db/pool.js';
import { ErrorCodes, badRequest, forbidden } from '../lib/errors.js';
import { uuidSchema } from '../lib/validation.js';
import { authOf, clientIp, requireAdmin, requireAuth, userAgent } from '../middleware/auth.js';
import { logAudit } from '../services/audit.service.js';
import { createNotification } from '../services/notifications.service.js';

/**
 * Administration.
 *
 * Two rules applied throughout:
 *
 *  - Every mutating action writes an audit row. An admin panel without an audit
 *    trail is worse than no panel, because it launders abuse as process.
 *  - Destructive actions on accounts require the `admin` role, not `support` or
 *    `moderator`. Support staff can read; only admins can destroy.
 */
export async function registerAdminRoutes(app: FastifyInstance): Promise<void> {
  const staff = { preHandler: [requireAuth, requireAdmin('support')] };
  const moderator = { preHandler: [requireAuth, requireAdmin('moderator')] };
  const admin = { preHandler: [requireAuth, requireAdmin('admin')] };

  // -------------------------------------------------------------------------
  // Dashboard statistics
  // -------------------------------------------------------------------------
  app.get('/admin/stats', staff, async () => {
    const [platform, growth, topChannels] = await Promise.all([
      query(`SELECT * FROM admin_platform_stats`),
      query(
        `SELECT to_char(d.day, 'YYYY-MM-DD') AS day,
                (SELECT count(*) FROM users u WHERE u.created_at < d.day + interval '1 day') AS cumulative_users,
                (SELECT count(*) FROM messages m WHERE m.created_at >= d.day AND m.created_at < d.day + interval '1 day') AS messages,
                (SELECT count(*) FROM calls c WHERE c.started_at >= d.day AND c.started_at < d.day + interval '1 day') AS calls
           FROM generate_series(now() - interval '29 days', now(), interval '1 day') AS d(day)
          ORDER BY d.day`,
      ),
      query(
        `SELECT id, name, follower_count, is_verified FROM channels
          WHERE deleted_at IS NULL ORDER BY follower_count DESC LIMIT 10`,
      ),
    ]);

    return { platform: platform.rows[0], growth: growth.rows, topChannels: topChannels.rows };
  });

  // -------------------------------------------------------------------------
  // User management
  // -------------------------------------------------------------------------
  app.get('/admin/users', staff, async (request) => {
    const q = z
      .object({
        search: z.string().trim().max(100).optional(),
        status: z.enum(['pending', 'active', 'suspended', 'deactivated', 'deleted']).optional(),
        limit: z.coerce.number().int().min(1).max(100).default(50),
        offset: z.coerce.number().int().min(0).default(0),
      })
      .parse(request.query);

    const res = await query(
      `SELECT u.id, u.email, u.phone, u.username, u.full_name, u.status, u.is_verified, u.is_business,
              u.email_verified_at, u.two_step_enabled, u.last_seen_at, u.created_at, u.deleted_at,
              ar.role AS admin_role,
              (SELECT count(*) FROM devices d WHERE d.user_id = u.id AND d.revoked_at IS NULL) AS device_count,
              (SELECT count(*) FROM reports r WHERE r.target_type = 'user' AND r.target_id = u.id::text AND r.status = 'open') AS open_reports
         FROM users u
         LEFT JOIN admin_roles ar ON ar.user_id = u.id AND ar.revoked_at IS NULL
        WHERE ($1::text IS NULL OR u.email ILIKE '%' || $1 || '%' OR u.username ILIKE '%' || $1 || '%' OR u.phone LIKE '%' || $1 || '%')
          AND ($2::text IS NULL OR u.status = $2::text)
        ORDER BY u.created_at DESC
        LIMIT $3 OFFSET $4`,
      [q.search ?? null, q.status ?? null, q.limit, q.offset],
    );

    const total = await queryOne<{ count: string }>(
      `SELECT count(*)::text AS count FROM users
        WHERE ($1::text IS NULL OR email ILIKE '%' || $1 || '%' OR username ILIKE '%' || $1 || '%' OR phone LIKE '%' || $1 || '%')
          AND ($2::text IS NULL OR status = $2::text)`,
      [q.search ?? null, q.status ?? null],
    );

    return { users: res.rows, total: Number(total?.count ?? 0), limit: q.limit, offset: q.offset };
  });

  app.get('/admin/users/:userId', staff, async (request) => {
    const params = z.object({ userId: uuidSchema }).parse(request.params);

    const [user, devices, sessions, reports, recentMessages, moderationActions] = await Promise.all([
      queryOne(`SELECT * FROM users WHERE id = $1`, [params.userId]),
      query(`SELECT id, platform, device_name, last_ip, last_seen_at, revoked_at, created_at FROM devices WHERE user_id = $1 ORDER BY created_at DESC`, [params.userId]),
      query(`SELECT id, issued_ip, user_agent, created_at, last_used_at, expires_at, revoked_at, revoked_reason FROM sessions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`, [params.userId]),
      query(`SELECT id, target_type, target_id, reason, status, priority, created_at FROM reports WHERE target_type = 'user' AND target_id = $1::text ORDER BY created_at DESC LIMIT 50`, [params.userId]),
      query(`SELECT count(*)::text AS count FROM messages WHERE sender_id = $1`, [params.userId]),
      query(`SELECT id, action, reason, duration_days, expires_at, created_at FROM moderation_actions WHERE target_type = 'user' AND target_id = $2::text ORDER BY created_at DESC LIMIT 50`, [params.userId, params.userId]),
    ]);

    if (!user) throw badRequest(ErrorCodes.USER_NOT_FOUND, 'User not found');

    return {
      user,
      devices: devices.rows,
      sessions: sessions.rows,
      reports: reports.rows,
      messageCount: Number((recentMessages.rows[0] as { count: string } | undefined)?.count ?? 0),
      moderationActions: moderationActions.rows,
    };
  });

  app.post('/admin/users/:userId/suspend', moderator, async (request) => {
    const params = z.object({ userId: uuidSchema }).parse(request.params);
    const body = z
      .object({
        reason: z.string().min(3).max(500),
        category: z.enum(['spam', 'scam', 'abuse', 'impersonation', 'policy', 'legal', 'other']).optional(),
        durationDays: z.number().int().min(1).max(3650).optional(),
        notifyUser: z.boolean().default(true),
      })
      .parse(request.body);

    const actor = authOf(request);
    if (params.userId === actor.userId) {
      throw badRequest(ErrorCodes.FORBIDDEN_ACTION, 'You cannot suspend your own account');
    }

    await withTransaction(async (tx) => {
      await tx.query(
        `INSERT INTO user_suspensions (user_id, suspended_by, reason, category, expires_at)
         VALUES ($1, $2, $3, $4, CASE WHEN $5::int IS NULL THEN NULL ELSE now() + ($5 || ' days')::interval END)`,
        [params.userId, actor.userId, body.reason, body.category ?? null, body.durationDays ?? null],
      );
      await tx.query(`UPDATE users SET status = 'suspended' WHERE id = $1`, [params.userId]);
      // Suspension must take effect now, not when existing tokens expire.
      await tx.query(
        `UPDATE sessions SET revoked_at = now(), revoked_reason = 'suspended' WHERE user_id = $1 AND revoked_at IS NULL`,
        [params.userId],
      );
      await tx.query(
        `INSERT INTO moderation_actions (moderator_id, target_type, target_id, action, reason, duration_days, expires_at)
         VALUES ($1, 'user', $2, 'suspend', $3, $4,
                 CASE WHEN $4::int IS NULL THEN NULL ELSE now() + ($4 || ' days')::interval END)`,
        [actor.userId, params.userId, body.reason, body.durationDays ?? null],
      );
    });

    await logAudit({
      actorId: actor.userId,
      actorRole: actor.role,
      action: 'admin.user.suspend',
      targetType: 'user',
      targetId: params.userId,
      metadata: { reason: body.reason, durationDays: body.durationDays },
      ip: clientIp(request),
      userAgent: userAgent(request),
    });

    if (body.notifyUser) {
      await createNotification({
        userId: params.userId,
        type: 'moderation',
        title: 'Your account has been suspended',
        body: body.reason,
        priority: 1,
      });
    }

    return { suspended: true };
  });

  app.post('/admin/users/:userId/unsuspend', moderator, async (request) => {
    const params = z.object({ userId: uuidSchema }).parse(request.params);
    const body = z.object({ reason: z.string().max(500).optional() }).parse(request.body ?? {});
    const actor = authOf(request);

    await withTransaction(async (tx) => {
      await tx.query(
        `UPDATE user_suspensions SET lifted_at = now(), lifted_by = $2 WHERE user_id = $1 AND lifted_at IS NULL`,
        [params.userId, actor.userId],
      );
      await tx.query(`UPDATE users SET status = 'active' WHERE id = $1 AND status = 'suspended'`, [params.userId]);
      await tx.query(
        `INSERT INTO moderation_actions (moderator_id, target_type, target_id, action, reason)
         VALUES ($1, 'user', $2, 'unsuspend', $3)`,
        [actor.userId, params.userId, body.reason ?? null],
      );
    });

    await logAudit({
      actorId: actor.userId,
      actorRole: actor.role,
      action: 'admin.user.unsuspend',
      targetType: 'user',
      targetId: params.userId,
      ip: clientIp(request),
    });

    return { unsuspended: true };
  });

  app.post('/admin/users/:userId/verify', admin, async (request) => {
    const params = z.object({ userId: uuidSchema }).parse(request.params);
    const body = z.object({ verified: z.boolean(), reason: z.string().max(300).optional() }).parse(request.body);

    await query(`UPDATE users SET is_verified = $2, verified_reason = $3 WHERE id = $1`, [
      params.userId,
      body.verified,
      body.reason ?? null,
    ]);

    await logAudit({
      actorId: authOf(request).userId,
      actorRole: authOf(request).role,
      action: body.verified ? 'admin.user.verify' : 'admin.user.unverify',
      targetType: 'user',
      targetId: params.userId,
      ip: clientIp(request),
    });

    return { verified: body.verified };
  });

  app.post('/admin/users/:userId/reset', admin, async (request) => {
    const params = z.object({ userId: uuidSchema }).parse(request.params);
    const body = z.object({ revokeSessions: z.boolean().default(true), requirePasswordReset: z.boolean().default(true) }).parse(request.body);

    if (body.revokeSessions) {
      await query(
        `UPDATE sessions SET revoked_at = now(), revoked_reason = 'admin_reset' WHERE user_id = $1 AND revoked_at IS NULL`,
        [params.userId],
      );
    }
    if (body.requirePasswordReset) {
      // Forces a reset by clearing the verification stamp; the user must go
      // through /auth/password/forgot, which proves control of the mailbox.
      await query(`UPDATE users SET email_verified_at = NULL WHERE id = $1`, [params.userId]);
    }

    await logAudit({
      actorId: authOf(request).userId,
      actorRole: authOf(request).role,
      action: 'admin.user.reset',
      targetType: 'user',
      targetId: params.userId,
      metadata: body,
      ip: clientIp(request),
    });

    return { reset: true };
  });

  app.delete('/admin/users/:userId', admin, async (request) => {
    const params = z.object({ userId: uuidSchema }).parse(request.params);
    const body = z.object({ reason: z.string().min(3).max(500) }).parse(request.body);
    const actor = authOf(request);

    if (params.userId === actor.userId) {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'You cannot delete your own account from the admin panel');
    }

    // Soft delete. Hard deletion of a user with message history would cascade
    // through conversations and destroy other people's records too, so it is
    // deliberately a separate, scheduled operation.
    await withTransaction(async (tx) => {
      await tx.query(
        `UPDATE users SET status = 'deleted', deleted_at = now() WHERE id = $1`,
        [params.userId],
      );
      await tx.query(
        `UPDATE sessions SET revoked_at = now(), revoked_reason = 'account_deleted' WHERE user_id = $1 AND revoked_at IS NULL`,
        [params.userId],
      );
      await tx.query(
        `INSERT INTO moderation_actions (moderator_id, target_type, target_id, action, reason)
         VALUES ($1, 'user', $2, 'ban', $3)`,
        [actor.userId, params.userId, body.reason],
      );
    });

    await logAudit({
      actorId: actor.userId,
      actorRole: actor.role,
      action: 'admin.user.delete',
      targetType: 'user',
      targetId: params.userId,
      metadata: { reason: body.reason },
      ip: clientIp(request),
    });

    return { deleted: true };
  });

  // -------------------------------------------------------------------------
  // Reports & moderation queue
  // -------------------------------------------------------------------------
  app.get('/admin/reports', staff, async (request) => {
    const q = z
      .object({
        status: z.enum(['open', 'reviewing', 'actioned', 'dismissed', 'escalated']).optional(),
        targetType: z.string().max(30).optional(),
        limit: z.coerce.number().int().min(1).max(100).default(50),
      })
      .parse(request.query);

    const res = await query(
      `SELECT r.*, u.username AS reporter_username, p.display_name AS reporter_name
         FROM reports r
         LEFT JOIN users u ON u.id = r.reporter_id
         LEFT JOIN user_profiles p ON p.user_id = r.reporter_id
        WHERE ($1::text IS NULL OR r.status = $1::text)
          AND ($2::text IS NULL OR r.target_type = $2::text)
        ORDER BY r.priority ASC, r.created_at ASC
        LIMIT $3`,
      [q.status ?? null, q.targetType ?? null, q.limit],
    );
    return { reports: res.rows };
  });

  app.post('/admin/reports/:reportId', moderator, async (request) => {
    const params = z.object({ reportId: uuidSchema }).parse(request.params);
    const body = z
      .object({
        status: z.enum(['reviewing', 'actioned', 'dismissed', 'escalated']),
        resolution: z.string().max(1000).optional(),
      })
      .parse(request.body);

    const actor = authOf(request);
    await query(
      `UPDATE reports SET status = $2, resolution = $3, reviewed_by = $4, reviewed_at = now() WHERE id = $1`,
      [params.reportId, body.status, body.resolution ?? null, actor.userId],
    );

    await logAudit({
      actorId: actor.userId,
      actorRole: actor.role,
      action: 'admin.report.review',
      targetType: 'report',
      targetId: params.reportId,
      metadata: { status: body.status },
      ip: clientIp(request),
    });

    return { updated: true };
  });

  /** Remove content from a conversation, leaving an auditable trace. */
  app.post('/admin/messages/:messageId/remove', moderator, async (request) => {
    const params = z.object({ messageId: uuidSchema }).parse(request.params);
    const body = z.object({ reason: z.string().min(3).max(500) }).parse(request.body);

    const message = await queryOne<{ chat_id: string; sender_id: string | null }>(
      `SELECT chat_id, sender_id FROM messages WHERE id = $1`,
      [params.messageId],
    );
    if (!message) throw badRequest(ErrorCodes.MESSAGE_NOT_FOUND, 'Message not found');

    await withTransaction(async (tx) => {
      await tx.query(
        `UPDATE messages SET is_deleted = true, deleted_at = now(), deleted_by = $2, body = NULL WHERE id = $1`,
        [params.messageId, authOf(request).userId],
      );
      await tx.query(`DELETE FROM attachments WHERE message_id = $1`, [params.messageId]);
      await tx.query(
        `INSERT INTO moderation_actions (moderator_id, target_type, target_id, action, reason)
         VALUES ($1, 'message', $2, 'remove_content', $3)`,
        [authOf(request).userId, params.messageId, body.reason],
      );
    });

    await logAudit({
      actorId: authOf(request).userId,
      actorRole: authOf(request).role,
      action: 'admin.message.remove',
      targetType: 'message',
      targetId: params.messageId,
      metadata: { chatId: message.chat_id, reason: body.reason },
      ip: clientIp(request),
    });

    return { removed: true };
  });

  // -------------------------------------------------------------------------
  // Abuse signals
  // -------------------------------------------------------------------------
  app.get('/admin/abuse-signals', staff, async (request) => {
    const q = z.object({ limit: z.coerce.number().int().min(1).max(200).default(50) }).parse(request.query);
    const res = await query(
      `SELECT * FROM abuse_signals WHERE resolved_at IS NULL ORDER BY score DESC, created_at DESC LIMIT $1`,
      [q.limit],
    );
    return { signals: res.rows };
  });

  // -------------------------------------------------------------------------
  // Audit log
  // -------------------------------------------------------------------------
  app.get('/admin/audit-logs', staff, async (request) => {
    const q = z
      .object({
        actorId: uuidSchema.optional(),
        action: z.string().max(80).optional(),
        limit: z.coerce.number().int().min(1).max(200).default(100),
      })
      .parse(request.query);

    const res = await query(
      `SELECT a.*, u.username AS actor_username
         FROM audit_logs a
         LEFT JOIN users u ON u.id = a.actor_id
        WHERE ($1::uuid IS NULL OR a.actor_id = $1::uuid)
          AND ($2::text IS NULL OR a.action = $2::text)
        ORDER BY a.created_at DESC
        LIMIT $3`,
      [q.actorId ?? null, q.action ?? null, q.limit],
    );
    return { logs: res.rows };
  });

  // -------------------------------------------------------------------------
  // Support tickets
  // -------------------------------------------------------------------------
  app.get('/admin/tickets', staff, async (request) => {
    const q = z
      .object({ status: z.string().max(20).optional(), limit: z.coerce.number().int().min(1).max(100).default(50) })
      .parse(request.query);

    const res = await query(
      `SELECT t.*, u.username, p.display_name
         FROM support_tickets t
         LEFT JOIN users u ON u.id = t.user_id
         LEFT JOIN user_profiles p ON p.user_id = t.user_id
        WHERE ($1::text IS NULL OR t.status = $1::text)
        ORDER BY t.priority ASC, t.created_at ASC
        LIMIT $2`,
      [q.status ?? null, q.limit],
    );
    return { tickets: res.rows };
  });

  app.post('/admin/tickets/:ticketId/reply', staff, async (request) => {
    const params = z.object({ ticketId: uuidSchema }).parse(request.params);
    const body = z.object({ message: z.string().min(1).max(5000), status: z.string().max(20).optional() }).parse(request.body);

    await withTransaction(async (tx) => {
      await tx.query(
        `INSERT INTO ticket_messages (ticket_id, author_id, is_staff, body) VALUES ($1, $2, true, $3)`,
        [params.ticketId, authOf(request).userId, body.message],
      );
      if (body.status) {
        await tx.query(`UPDATE support_tickets SET status = $2, updated_at = now() WHERE id = $1`, [params.ticketId, body.status]);
      } else {
        await tx.query(`UPDATE support_tickets SET status = 'pending_user', updated_at = now() WHERE id = $1`, [params.ticketId]);
      }
    });

    return { replied: true };
  });

  // -------------------------------------------------------------------------
  // System announcements
  // -------------------------------------------------------------------------
  app.post('/admin/announcements', admin, async (request, reply) => {
    const body = z
      .object({
        title: z.string().min(1).max(150),
        body: z.string().min(1).max(5000),
        audience: z.enum(['all', 'android', 'ios', 'web', 'suspended', 'business']).default('all'),
        severity: z.enum(['info', 'warning', 'critical']).default('info'),
        publishNow: z.boolean().default(true),
      })
      .parse(request.body);

    const res = await query<{ id: string }>(
      `INSERT INTO system_announcements (title, body, audience, severity, published_at, created_by)
       VALUES ($1, $2, $3, $4, CASE WHEN $5 THEN now() ELSE NULL END, $6)
       RETURNING id`,
      [body.title, body.body, body.audience, body.severity, body.publishNow, authOf(request).userId],
    );

    await logAudit({
      actorId: authOf(request).userId,
      actorRole: authOf(request).role,
      action: 'admin.announcement.create',
      targetType: 'announcement',
      targetId: res.rows[0]!.id,
      metadata: { audience: body.audience, severity: body.severity },
      ip: clientIp(request),
    });

    return reply.code(201).send({ id: res.rows[0]!.id, published: body.publishNow });
  });

  // -------------------------------------------------------------------------
  // Admin role management — superadmin only, because this is the keys to the
  // kingdom. Without this restriction any admin could mint a superadmin.
  // -------------------------------------------------------------------------
  app.post('/admin/roles', { preHandler: [requireAuth, requireAdmin('superadmin')] }, async (request) => {
    const body = z
      .object({
        userId: uuidSchema,
        role: z.enum(['support', 'moderator', 'admin', 'superadmin']),
        notes: z.string().max(300).optional(),
      })
      .parse(request.body);

    await query(
      `INSERT INTO admin_roles (user_id, role, granted_by, notes)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (user_id) DO UPDATE SET role = $2, granted_by = $3, revoked_at = NULL, notes = $4, granted_at = now()`,
      [body.userId, body.role, authOf(request).userId, body.notes ?? null],
    );

    await logAudit({
      actorId: authOf(request).userId,
      actorRole: authOf(request).role,
      action: 'admin.role.grant',
      targetType: 'user',
      targetId: body.userId,
      metadata: { role: body.role },
      ip: clientIp(request),
    });

    return { granted: true, role: body.role };
  });

  app.delete('/admin/roles/:userId', { preHandler: [requireAuth, requireAdmin('superadmin')] }, async (request) => {
    const params = z.object({ userId: uuidSchema }).parse(request.params);
    await query(`UPDATE admin_roles SET revoked_at = now() WHERE user_id = $1`, [params.userId]);

    await logAudit({
      actorId: authOf(request).userId,
      actorRole: authOf(request).role,
      action: 'admin.role.revoke',
      targetType: 'user',
      targetId: params.userId,
      ip: clientIp(request),
    });

    return { revoked: true };
  });
}
