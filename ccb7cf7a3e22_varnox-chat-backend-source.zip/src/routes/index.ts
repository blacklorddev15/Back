import type { FastifyInstance } from 'fastify';
import { registerAdminRoutes } from './admin.routes.js';
import { registerAttachmentRoutes } from './attachment.routes.js';
import { registerAuthRoutes } from './auth.routes.js';
import { registerChannelRoutes } from './channel.routes.js';
import { registerChatRoutes } from './chat.routes.js';
import { registerMeRoutes } from './me.routes.js';
import { registerNotificationRoutes } from './notifications.routes.js';
import { registerRealtimeRoutes } from './realtime.routes.js';
import { registerSocialRoutes } from './social.routes.js';
import { registerStatusRoutes } from './status.routes.js';

export async function registerRoutes(app: FastifyInstance): Promise<void> {
  await registerAuthRoutes(app);
  await registerMeRoutes(app);
  await registerSocialRoutes(app);
  await registerStatusRoutes(app);
  await registerChannelRoutes(app);
  await registerChatRoutes(app);
  await registerAttachmentRoutes(app);
  await registerNotificationRoutes(app);
  await registerRealtimeRoutes(app);
  await registerAdminRoutes(app);
}
