import { query, queryOne, withTransaction, type Tx } from '../db/pool.js';
import { ErrorCodes, badRequest, forbidden, notFound } from '../lib/errors.js';
import { extractMentions, extractUrls } from '../lib/validation.js';
import { publishToChat, publishToUsers } from '../realtime/hub.js';
import { isBlockedEitherWay } from './contacts.service.js';
import { assertCanSend, getChatMemberIds, requireMembership } from './chats.service.js';
import { notifyNewMessage } from './notifications.service.js';

/**
 * Message lifecycle: send, read, edit, delete, react, star, pin, forward, search.
 *
 * Three rules that are easy to get wrong and are enforced here:
 *
 *  - ONLY the author may edit or "delete for everyone". Anyone in the chat may
 *    "delete for me", and that must not affect anybody else's copy.
 *  - Edits are time-boxed (EDIT_WINDOW_SECONDS). Letting a sender rewrite an
 *    old message indefinitely is how a chat becomes a place where the record
 *    cannot be trusted.
 *  - Read state is a per-member watermark, not a row per message. See the note
 *    at the top of migration 003.
 */

/** How long after sending a message may its author still edit it. */
const EDIT_WINDOW_SECONDS = 15 * 60;

export type MessageType =
  | 'text' | 'image' | 'video' | 'audio' | 'voice' | 'document' | 'sticker' | 'gif'
  | 'location' | 'contact' | 'poll' | 'event' | 'system' | 'call_log';

export interface AttachmentInput {
  kind: 'image' | 'video' | 'audio' | 'voice' | 'document' | 'sticker' | 'gif';
  mimeType: string;
  fileName?: string;
  byteSize: number;
  storageDriver: string;
  storageKey: string;
  publicUrl?: string;
  thumbnailUrl?: string;
  width?: number;
  height?: number;
  durationMs?: number;
  waveform?: unknown;
  sha256?: string;
  isCompressed?: boolean;
  originalByteSize?: number;
}

export interface SendMessageInput {
  senderId: string;
  chatId: string;
  type?: MessageType;
  body?: string;
  metadata?: Record<string, unknown>;
  replyToId?: string;
  isViewOnce?: boolean;
  clientId?: string;
  attachments?: AttachmentInput[];
}

export interface MessageRow {
  id: string;
  seq: string | number;
  chat_id: string;
  sender_id: string | null;
  type: string;
  body: string | null;
  metadata: Record<string, unknown>;
  reply_to_id: string | null;
  forwarded_from_message_id: string | null;
  forward_count: number;
  is_deleted: boolean;
  edited_at: Date | null;
  is_view_once: boolean;
  expires_at: Date | null;
  created_at: Date;
  client_id: string | null;
}

/**
 * Returns the HYDRATED message (camelCase, with attachments, reactions and
 * mentions), matching what the list endpoint returns.
 *
 * This used to return the raw database row. Because the two shapes differ
 * (snake_case `chat_id`/`created_at` versus `chatId`/`createdAt`), the client
 * received a message with no attachments and an undefined `senderId` — so a
 * just-sent message rendered as though the other person had sent it.
 */
export async function sendMessage(input: SendMessageInput): Promise<Record<string, unknown>> {
  const type = input.type ?? 'text';

  if (type === 'text' && !input.body?.trim() && (input.attachments?.length ?? 0) === 0) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'A message needs text or an attachment');
  }

  // Computed before the transaction so that the idempotent-replay path can
  // report the same preview a fresh send would have produced. Declaring it
  // inside the transaction made it absent from that early return, which
  // silently widened the result type and would have sent "undefined" to the
  // notification body.
  const preview = buildPreview(type, input.body);

  const result = await withTransaction(async (tx) => {
    const ctx = await requireMembership(input.chatId, input.senderId, tx);
    assertCanSend(ctx);

    // Re-check the block inside the transaction: a block applied while the
    // message was being composed must still take effect.
    const chat = await tx.query<{ type: string; disappearing_seconds: number }>(
      `SELECT type, disappearing_seconds FROM chats WHERE id = $1 AND deleted_at IS NULL`,
      [input.chatId],
    );
    const chatRow = chat.rows[0];
    if (!chatRow) throw notFound(ErrorCodes.CHAT_NOT_FOUND, 'Conversation not found');

    if (chatRow.type === 'direct') {
      const peers = await tx.query<{ user_id: string }>(
        `SELECT user_id FROM chat_members
          WHERE chat_id = $1 AND user_id <> $2 AND left_at IS NULL`,
        [input.chatId, input.senderId],
      );
      const peerId = peers.rows[0]?.user_id;
      if (peerId && (await isBlockedEitherWay(input.senderId, peerId))) {
        throw forbidden(ErrorCodes.BLOCKED, 'You cannot send messages to this user');
      }
    }

    // A reply must point at a message in the same conversation, otherwise the
    // thread can be pointed at content the recipient cannot see.
    if (input.replyToId) {
      const replyTarget = await tx.query<{ id: string }>(
        `SELECT id FROM messages WHERE id = $1 AND chat_id = $2`,
        [input.replyToId, input.chatId],
      );
      if (replyTarget.rowCount === 0) {
        throw badRequest(ErrorCodes.MESSAGE_NOT_FOUND, 'The message being replied to is not in this conversation');
      }
    }

    // Idempotency: a retried send with the same client_id must not duplicate.
    if (input.clientId) {
      const dupe = await tx.query<MessageRow>(
        `SELECT * FROM messages WHERE chat_id = $1 AND sender_id = $2 AND client_id = $3`,
        [input.chatId, input.senderId, input.clientId],
      );
      if (dupe.rows[0]) {
        return { message: dupe.rows[0], memberIds: await memberIdsTx(tx, input.chatId), preview };
      }
    }

    const expiresAt =
      chatRow.disappearing_seconds > 0
        ? new Date(Date.now() + chatRow.disappearing_seconds * 1000)
        : null;

    const linkPreview = input.body ? buildLinkPreview(input.body) : null;

    const inserted = await tx.query<MessageRow>(
      `INSERT INTO messages
         (chat_id, sender_id, type, body, metadata, reply_to_id, is_view_once, expires_at, client_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        input.chatId,
        input.senderId,
        type,
        input.body ?? null,
        JSON.stringify({ ...(input.metadata ?? {}), ...(linkPreview ? { linkPreview } : {}) }),
        input.replyToId ?? null,
        input.isViewOnce ?? false,
        expiresAt,
        input.clientId ?? null,
      ],
    );
    const message = inserted.rows[0]!;

    if (input.attachments?.length) {
      for (const a of input.attachments) {
        await tx.query(
          `INSERT INTO attachments
             (message_id, kind, mime_type, file_name, byte_size, storage_driver, storage_key, public_url,
              thumbnail_url, width, height, duration_ms, waveform, sha256, is_compressed, original_byte_size)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
          [
            message.id, a.kind, a.mimeType, a.fileName ?? null, a.byteSize, a.storageDriver,
            a.storageKey, a.publicUrl ?? null, a.thumbnailUrl ?? null, a.width ?? null,
            a.height ?? null, a.durationMs ?? null, a.waveform ? JSON.stringify(a.waveform) : null,
            a.sha256 ?? null, a.isCompressed ?? false, a.originalByteSize ?? null,
          ],
        );
      }
    }

    // @mentions become rows so the notification path does not have to re-parse
    // message bodies on every read.
    if (input.body && input.body.includes('@')) {
      const usernames = extractMentions(input.body);
      if (usernames.length > 0) {
        await tx.query(
          `INSERT INTO message_mentions (message_id, user_id)
           SELECT $1, u.id FROM users u
            WHERE lower(u.username) = ANY($2::text[])
              AND EXISTS (SELECT 1 FROM chat_members cm
                           WHERE cm.chat_id = $3 AND cm.user_id = u.id AND cm.left_at IS NULL)
           ON CONFLICT DO NOTHING`,
          [message.id, usernames, input.chatId],
        );
      }
    }

    // Keep the chat list denormalisation consistent in the same transaction.
    await tx.query(
      `UPDATE chats
          SET last_message_id = $2, last_message_at = now(), last_message_preview = $3
        WHERE id = $1`,
      [input.chatId, message.id, preview],
    );

    // The sender has implicitly read their own message.
    await tx.query(
      `UPDATE chat_members SET last_read_seq = GREATEST(last_read_seq, $3), last_delivered_seq = GREATEST(last_delivered_seq, $3)
        WHERE chat_id = $1 AND user_id = $2`,
      [input.chatId, input.senderId, message.seq],
    );

    return { message, memberIds: await memberIdsTx(tx, input.chatId), preview };
  });

  const hydrated = await hydrateMessages([result.message]);
  const payload = hydrated[0]!;

  // Realtime fan-out is best-effort: a socket failure must never fail the send,
  // because the message is already durably committed at this point.
  await publishToChat(input.chatId, { type: 'message.new', chatId: input.chatId, message: payload });

  const recipients = result.memberIds.filter((id) => id !== input.senderId);
  if (recipients.length > 0) {
    await notifyNewMessage({
      chatId: input.chatId,
      messageId: String(result.message.id),
      recipientIds: recipients,
      senderId: input.senderId,
      preview: result.preview,
    }).catch(() => {});
  }

  // hydrateMessages returns unknown[], so the element needs a cast to satisfy
  // the declared shape. The runtime shape is fixed by hydrateMessages itself.
  return payload as Record<string, unknown>;
}

/**
 * One-line summary for the chat list and notification body. Kept separate so
 * the same text is used whether the message was just created or replayed via
 * its client id.
 */
function buildPreview(type: MessageType, body: string | undefined): string {
  if (type === 'text') return (body ?? '').slice(0, 140);
  switch (type) {
    case 'image': return '📷 Photo';
    case 'video': return '🎥 Video';
    case 'voice':
    case 'audio': return '🎤 Voice message';
    case 'document': return '📄 Document';
    case 'sticker': return 'Sticker';
    case 'gif': return 'GIF';
    case 'location': return '📍 Location';
    case 'contact': return '👤 Contact';
    case 'poll': return '📊 Poll';
    case 'event': return '📅 Event';
    case 'call_log': return '📞 Call';
    default: return 'New message';
  }
}

async function memberIdsTx(tx: Tx, chatId: string): Promise<string[]> {
  const res = await tx.query<{ user_id: string }>(
    `SELECT user_id FROM chat_members WHERE chat_id = $1 AND left_at IS NULL AND status = 'active'`,
    [chatId],
  );
  return res.rows.map((r) => r.user_id);
}

function buildLinkPreview(body: string): Record<string, unknown> | null {
  const urls = extractUrls(body);
  if (urls.length === 0) return null;
  // Only the first link is previewed, matching every mainstream client.
  try {
    const url = new URL(urls[0]!);
    return { url: url.toString(), domain: url.hostname };
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Reading
// ---------------------------------------------------------------------------

export async function listMessages(input: {
  userId: string;
  chatId: string;
  limit?: number;
  before?: number;
  after?: number;
}): Promise<{ messages: unknown[]; hasMore: boolean }> {
  await requireMembership(input.chatId, input.userId);
  const limit = Math.min(input.limit ?? 50, 200);

  const params: unknown[] = [input.chatId, input.userId];
  let cursorClause = '';
  if (input.before !== undefined) {
    params.push(input.before);
    cursorClause = `AND m.seq < $${params.length}`;
  }
  if (input.after !== undefined) {
    params.push(input.after);
    cursorClause += ` AND m.seq > $${params.length}`;
  }
  params.push(limit + 1);

  const res = await query<MessageRow>(
    `SELECT m.*
       FROM messages m
      WHERE m.chat_id = $1
        ${cursorClause}
        -- "Delete for me" hides a message from one user only.
        AND NOT EXISTS (
              SELECT 1 FROM message_deletions md
               WHERE md.message_id = m.id AND md.user_id = $2
            )
        -- Expired disappearing messages stop being readable immediately.
        AND (m.expires_at IS NULL OR m.expires_at > now())
      ORDER BY m.seq DESC
      LIMIT $${params.length}`,
    params,
  );

  const hasMore = res.rows.length > limit;
  const rows = hasMore ? res.rows.slice(0, limit) : res.rows;
  const hydrated = await hydrateMessages(rows, input.userId);

  return { messages: hydrated, hasMore };
}

/**
 * Attach reactions, attachments, mentions and per-user receipts to a set of
 * message rows.
 *
 * Done as four set-based queries rather than a loop per message: the naive
 * version is N+1 queries per page of history, which is the classic way a chat
 * backend falls over at a few hundred concurrent users.
 */
export async function hydrateMessages(rows: MessageRow[], viewerId?: string): Promise<unknown[]> {
  if (rows.length === 0) return [];
  const ids = rows.map((r) => r.id);

  const [reactions, attachments, mentions, votes] = await Promise.all([
    query(
      `SELECT message_id, emoji, user_id FROM message_reactions WHERE message_id = ANY($1::uuid[])`,
      [ids],
    ),
    query(
      `SELECT * FROM attachments WHERE message_id = ANY($1::uuid[]) ORDER BY created_at`,
      [ids],
    ),
    query(
      `SELECT message_id, user_id FROM message_mentions WHERE message_id = ANY($1::uuid[])`,
      [ids],
    ),
    query(
      `SELECT p.message_id, p.id AS poll_id, p.question, p.allows_multiple, p.closes_at, p.closed_at,
              o.id AS option_id, o.position, o.text
         FROM polls p
         JOIN poll_options o ON o.poll_id = p.id
        WHERE p.message_id = ANY($1::uuid[])
        ORDER BY o.position`,
      [ids],
    ),
  ]);

  const reactionsByMessage = new Map<string, { emoji: string; userIds: string[] }[]>();
  for (const r of reactions.rows as { message_id: string; emoji: string; user_id: string }[]) {
    const list = reactionsByMessage.get(r.message_id) ?? [];
    let bucket = list.find((e) => e.emoji === r.emoji);
    if (!bucket) {
      bucket = { emoji: r.emoji, userIds: [] };
      list.push(bucket);
    }
    bucket.userIds.push(r.user_id);
    reactionsByMessage.set(r.message_id, list);
  }

  const attachmentsByMessage = new Map<string, unknown[]>();
  for (const a of attachments.rows as { message_id: string }[]) {
    const list = attachmentsByMessage.get(a.message_id) ?? [];
    list.push(a);
    attachmentsByMessage.set(a.message_id, list);
  }

  const mentionsByMessage = new Map<string, string[]>();
  for (const m of mentions.rows as { message_id: string; user_id: string }[]) {
    const list = mentionsByMessage.get(m.message_id) ?? [];
    list.push(m.user_id);
    mentionsByMessage.set(m.message_id, list);
  }

  const pollsByMessage = new Map<string, { id: string; question: string; allowsMultiple: boolean; closesAt: Date | null; options: unknown[] }>();
  for (const p of votes.rows as Record<string, unknown>[]) {
    const messageId = p.message_id as string;
    let poll = pollsByMessage.get(messageId);
    if (!poll) {
      poll = {
        id: p.poll_id as string,
        question: p.question as string,
        allowsMultiple: Boolean(p.allows_multiple),
        closesAt: (p.closes_at as Date | null) ?? null,
        options: [],
      };
      pollsByMessage.set(messageId, poll);
    }
    poll.options.push({ id: p.option_id, position: p.position, text: p.text });
  }

  // Poll tallies, fetched only for the polls actually present on this page.
  const pollIds = [...pollsByMessage.values()].map((p) => p.id);
  const tallies = new Map<string, Map<string, { count: number; voterIds: string[] }>>();
  if (pollIds.length > 0) {
    const tallyRows = await query<{ poll_id: string; option_id: string; user_id: string }>(
      `SELECT poll_id, option_id, user_id FROM poll_votes WHERE poll_id = ANY($1::uuid[])`,
      [pollIds],
    );
    for (const t of tallyRows.rows) {
      const perPoll = tallies.get(t.poll_id) ?? new Map();
      const bucket = perPoll.get(t.option_id) ?? { count: 0, voterIds: [] };
      bucket.count += 1;
      bucket.voterIds.push(t.user_id);
      perPoll.set(t.option_id, bucket);
      tallies.set(t.poll_id, perPoll);
    }
  }

  return rows.map((row) => {
    // View-once media is only readable by the creator once it has been opened
    // by the recipient; see markRead for the consumption side.
    const attachmentsForMessage = (attachmentsByMessage.get(row.id) ?? []) as Record<string, unknown>[];

    const poll = pollsByMessage.get(row.id);
    const perPoll = poll ? tallies.get(poll.id) : undefined;

    return {
      id: row.id,
      seq: Number(row.seq),
      chatId: row.chat_id,
      senderId: row.sender_id,
      type: row.type,
      // A tombstone keeps its envelope so replies and receipts stay coherent,
      // but the content is gone.
      body: row.is_deleted ? null : row.body,
      metadata: row.metadata,
      replyToId: row.reply_to_id,
      forwardedFromMessageId: row.forwarded_from_message_id,
      forwardCount: row.forward_count,
      isDeleted: row.is_deleted,
      editedAt: row.edited_at,
      isViewOnce: row.is_view_once,
      expiresAt: row.expires_at,
      createdAt: row.created_at,
      clientId: row.client_id,
      reactions: row.is_deleted ? [] : reactionsByMessage.get(row.id) ?? [],
      attachments: row.is_deleted ? [] : attachmentsForMessage,
      mentions: row.is_deleted ? [] : mentionsByMessage.get(row.id) ?? [],
      poll: poll
        ? {
            ...poll,
            options: poll.options.map((o) => {
              const opt = o as { id: string; text: string; position: number };
              const tally = perPoll?.get(opt.id);
              return {
                ...opt,
                votes: tally?.count ?? 0,
                votedByMe: viewerId ? Boolean(tally?.voterIds.includes(viewerId)) : undefined,
              };
            }),
          }
        : null,
    };
  });
}

// ---------------------------------------------------------------------------
// Mutations
// ---------------------------------------------------------------------------

async function loadOwnMessage(messageId: string, chatId: string, tx?: Tx): Promise<MessageRow> {
  const sql = `SELECT * FROM messages WHERE id = $1 AND chat_id = $2`;
  const res = tx ? await tx.query<MessageRow>(sql, [messageId, chatId]) : await query<MessageRow>(sql, [messageId, chatId]);
  const row = res.rows[0];
  if (!row) throw notFound(ErrorCodes.MESSAGE_NOT_FOUND, 'Message not found');
  return row;
}

export async function editMessage(input: {
  userId: string;
  chatId: string;
  messageId: string;
  body: string;
}): Promise<unknown> {
  const updated = await withTransaction(async (tx) => {
    await requireMembership(input.chatId, input.userId, tx);
    const message = await loadOwnMessage(input.messageId, input.chatId, tx);

    if (message.sender_id !== input.userId) {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'You can only edit your own messages');
    }
    if (message.is_deleted) {
      throw badRequest(ErrorCodes.MESSAGE_ALREADY_DELETED, 'This message was deleted');
    }
    const ageSeconds = (Date.now() - new Date(message.created_at).getTime()) / 1000;
    if (ageSeconds > EDIT_WINDOW_SECONDS) {
      throw badRequest(ErrorCodes.EDIT_WINDOW_CLOSED, 'This message is too old to edit');
    }

    // Preserve the previous revision before overwriting it.
    await tx.query(
      `INSERT INTO message_edits (message_id, old_body, edited_by) VALUES ($1, $2, $3)`,
      [message.id, message.body, input.userId],
    );

    const res = await tx.query<MessageRow>(
      `UPDATE messages
          SET body = $2, edited_at = now(), edit_count = edit_count + 1
        WHERE id = $1
        RETURNING *`,
      [message.id, input.body],
    );
    return res.rows[0]!;
  });

  const hydrated = (await hydrateMessages([updated]))[0];
  await publishToChat(input.chatId, { type: 'message.updated', chatId: input.chatId, message: hydrated });
  return hydrated;
}

/** Tombstone the message for everyone. Author-only, and irreversible. */
export async function deleteMessageForEveryone(input: {
  userId: string;
  chatId: string;
  messageId: string;
}): Promise<void> {
  await withTransaction(async (tx) => {
    const ctx = await requireMembership(input.chatId, input.userId, tx);
    const message = await loadOwnMessage(input.messageId, input.chatId, tx);

    const isAuthor = message.sender_id === input.userId;
    const isAdmin = ctx.role === 'admin' || ctx.role === 'owner';
    // Admins may remove content in groups they moderate, but not in a 1:1 chat.
    if (!isAuthor && !(isAdmin && ctx.role !== 'member')) {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'You can only delete your own messages');
    }

    if (message.is_deleted) return;

    await tx.query(
      `UPDATE messages
          SET is_deleted = true, deleted_at = now(), deleted_by = $2, body = NULL
        WHERE id = $1`,
      [message.id, input.userId],
    );
    // Attachments must not remain reachable after the message is revoked.
    await tx.query(`DELETE FROM attachments WHERE message_id = $1`, [message.id]);
  });

  await publishToChat(input.chatId, {
    type: 'message.deleted',
    chatId: input.chatId,
    messageId: input.messageId,
    scope: 'everyone',
  });
}

/** Hide a message for the caller only. */
export async function deleteMessageForMe(input: {
  userId: string;
  chatId: string;
  messageId: string;
}): Promise<void> {
  await requireMembership(input.chatId, input.userId);
  await loadOwnMessage(input.messageId, input.chatId);

  await query(
    `INSERT INTO message_deletions (message_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
    [input.messageId, input.userId],
  );
  // Only this user's own devices need to know.
  publishToUsers([input.userId], {
    type: 'message.deleted',
    chatId: input.chatId,
    messageId: input.messageId,
    scope: 'me',
  });
}

export async function addReaction(input: {
  userId: string;
  chatId: string;
  messageId: string;
  emoji: string;
}): Promise<void> {
  await requireMembership(input.chatId, input.userId);
  await loadOwnMessage(input.messageId, input.chatId);

  await query(
    `INSERT INTO message_reactions (message_id, user_id, emoji) VALUES ($1, $2, $3)
     ON CONFLICT (message_id, user_id, emoji) DO NOTHING`,
    [input.messageId, input.userId, input.emoji],
  );
  await publishToChat(input.chatId, {
    type: 'message.reaction',
    chatId: input.chatId,
    messageId: input.messageId,
    userId: input.userId,
    emoji: input.emoji,
    removed: false,
  });
}

export async function removeReaction(input: {
  userId: string;
  chatId: string;
  messageId: string;
  emoji: string;
}): Promise<void> {
  await requireMembership(input.chatId, input.userId);
  await query(`DELETE FROM message_reactions WHERE message_id = $1 AND user_id = $2 AND emoji = $3`, [
    input.messageId,
    input.userId,
    input.emoji,
  ]);
  await publishToChat(input.chatId, {
    type: 'message.reaction',
    chatId: input.chatId,
    messageId: input.messageId,
    userId: input.userId,
    emoji: input.emoji,
    removed: true,
  });
}

export async function setStar(userId: string, messageId: string, starred: boolean): Promise<void> {
  if (starred) {
    await query(
      `INSERT INTO message_stars (message_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
      [messageId, userId],
    );
  } else {
    await query(`DELETE FROM message_stars WHERE message_id = $1 AND user_id = $2`, [messageId, userId]);
  }
}

export async function listStarred(userId: string, limit = 100) {
  const res = await query(
    `SELECT m.*, s.created_at AS starred_at
       FROM message_stars s
       JOIN messages m ON m.id = s.message_id
       JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = $1 AND cm.left_at IS NULL
      WHERE s.user_id = $1 AND m.is_deleted = false
      ORDER BY s.created_at DESC
      LIMIT $2`,
    [userId, limit],
  );
  return hydrateMessages(res.rows as MessageRow[], userId);
}

export async function setPin(input: {
  userId: string;
  chatId: string;
  messageId: string;
  pinned: boolean;
}): Promise<void> {
  await withTransaction(async (tx) => {
    const ctx = await requireMembership(input.chatId, input.userId, tx);
    // Same reasoning as assertCanSend: a direct chat has no admins, so an
    // admin-only pin policy would mean nobody could ever pin anything.
    if (ctx.chatType !== 'direct' && ctx.role === 'member' && ctx.whoCanPin === 'admins') {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Only admins can pin messages');
    }
    if (input.pinned) {
      await tx.query(
        `INSERT INTO message_pins (chat_id, message_id, pinned_by) VALUES ($1, $2, $3)
         ON CONFLICT (chat_id, message_id) DO NOTHING`,
        [input.chatId, input.messageId, input.userId],
      );
    } else {
      await tx.query(`DELETE FROM message_pins WHERE chat_id = $1 AND message_id = $2`, [
        input.chatId,
        input.messageId,
      ]);
    }
  });

  const hydrated = input.pinned
    ? (await hydrateMessages([await loadOwnMessage(input.messageId, input.chatId)]))[0]
    : null;
  await publishToChat(input.chatId, {
    type: 'chat.updated',
    chatId: input.chatId,
    chat: { pinnedMessage: hydrated, pinned: input.pinned, messageId: input.messageId },
  });
}

export async function listPinned(chatId: string, userId: string) {
  await requireMembership(chatId, userId);
  const res = await query(
    `SELECT m.*, mp.pinned_at, mp.pinned_by
       FROM message_pins mp
       JOIN messages m ON m.id = mp.message_id
      WHERE mp.chat_id = $1
      ORDER BY mp.pinned_at DESC`,
    [chatId],
  );
  return hydrateMessages(res.rows as MessageRow[], userId);
}

/**
 * Forward messages to one or more conversations.
 * Forwarding re-checks membership of every destination, so a user cannot
 * forward into a chat they are not in by guessing an id.
 */
export async function forwardMessages(input: {
  userId: string;
  messageIds: string[];
  targetChatIds: string[];
}): Promise<{ forwarded: number; chatIds: string[] }> {
  if (input.messageIds.length === 0 || input.targetChatIds.length === 0) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'Select messages and at least one destination');
  }
  if (input.messageIds.length > 20) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'Forward at most 20 messages at a time');
  }

  let forwarded = 0;
  for (const chatId of input.targetChatIds) {
    await requireMembership(chatId, input.userId);

    const sources = await query<MessageRow & { origin_chat_id: string }>(
      `SELECT m.*, m.chat_id AS origin_chat_id
         FROM messages m
         JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = $2 AND cm.left_at IS NULL
        WHERE m.id = ANY($1::uuid[]) AND m.is_deleted = false
        ORDER BY m.seq`,
      [input.messageIds, input.userId],
    );

    for (const src of sources.rows) {
      await withTransaction(async (tx) => {
        const ctx = await requireMembership(chatId, input.userId, tx);
        assertCanSend(ctx);
        const chatRow = await tx.query<{ disappearing_seconds: number }>(
          `SELECT disappearing_seconds FROM chats WHERE id = $1`,
          [chatId],
        );

        const newMessage = await tx.query<MessageRow>(
          `INSERT INTO messages
             (chat_id, sender_id, type, body, metadata, forwarded_from_message_id, forwarded_from_user_id,
              is_view_once, expires_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, false, $8)
           RETURNING *`,
          [
            chatId,
            input.userId,
            src.type,
            src.body,
            JSON.stringify(src.metadata ?? {}),
            src.id,
            src.sender_id,
            chatRow.rows[0]?.disappearing_seconds
              ? new Date(Date.now() + chatRow.rows[0].disappearing_seconds * 1000)
              : null,
          ],
        );

        // Copies of attachments, because the original may later be deleted.
        await tx.query(
          `INSERT INTO attachments
             (message_id, kind, mime_type, file_name, byte_size, storage_driver, storage_key, public_url,
              thumbnail_url, width, height, duration_ms, sha256)
           SELECT $1, kind, mime_type, file_name, byte_size, storage_driver, storage_key, public_url,
                  thumbnail_url, width, height, duration_ms, sha256
             FROM attachments WHERE message_id = $2`,
          [newMessage.rows[0]!.id, src.id],
        );

        // Bump the forward counter on the original — the "forwarded many times"
        // affordance depends on it.
        await tx.query(`UPDATE messages SET forward_count = forward_count + 1 WHERE id = $1`, [src.id]);
        await tx.query(
          `UPDATE chats SET last_message_id = $2, last_message_at = now(), last_message_preview = $3 WHERE id = $1`,
          [chatId, newMessage.rows[0]!.id, src.body?.slice(0, 140) ?? 'Forwarded message'],
        );

        forwarded += 1;
        const hydrated = (await hydrateMessages([newMessage.rows[0]!]))[0];
        await publishToChat(chatId, { type: 'message.new', chatId, message: hydrated });
      });
    }
  }

  return { forwarded, chatIds: input.targetChatIds };
}

// ---------------------------------------------------------------------------
// Delivery / read state
// ---------------------------------------------------------------------------

/**
 * Advance the caller's delivered watermark and report it back to senders so
 * their ticks update.
 *
 * View-once consumption happens here too: reading a view-once message burns it
 * for the reader immediately, which is the only place that can be enforced
 * server-side (a rooted device can always screenshot).
 */
export async function markDelivered(userId: string, chatId: string, upToSeq?: number): Promise<void> {
  const target =
    upToSeq ??
    Number(
      (await queryOne<{ max_seq: string | null }>(`SELECT max(seq)::text AS max_seq FROM messages WHERE chat_id = $1`, [chatId]))
        ?.max_seq ?? 0,
    );

  const res = await query(
    `UPDATE chat_members
        SET last_delivered_seq = GREATEST(last_delivered_seq, $3)
      WHERE chat_id = $1 AND user_id = $2
      RETURNING last_delivered_seq`,
    [chatId, userId, target],
  );
  if (res.rowCount === 0) throw forbidden(ErrorCodes.NOT_A_MEMBER, 'You are not a member of this conversation');

  await publishToChat(chatId, {
    type: 'receipt.update',
    chatId,
    userId,
    deliveredUpTo: Number((res.rows[0] as { last_delivered_seq: string }).last_delivered_seq),
  });
}

export async function markRead(input: { userId: string; chatId: string; upToSeq?: number }): Promise<number> {
  const target =
    input.upToSeq ??
    Number(
      (await queryOne<{ max_seq: string | null }>(`SELECT max(seq)::text AS max_seq FROM messages WHERE chat_id = $1`, [input.chatId]))
        ?.max_seq ?? 0,
    );

  const readWatermark = await queryOne<{ last_read_seq: string }>(
    `UPDATE chat_members
        SET last_read_seq = GREATEST(last_read_seq, $3),
            last_delivered_seq = GREATEST(last_delivered_seq, $3)
      WHERE chat_id = $1 AND user_id = $2
      RETURNING last_read_seq`,
    [input.chatId, input.userId, target],
  );
  if (!readWatermark) throw forbidden(ErrorCodes.NOT_A_MEMBER, 'You are not a member of this conversation');

  // Per-message receipts for the specific messages being marked read. This is
  // the "who has read this" data that a watermark cannot answer.
  await query(
    `INSERT INTO message_receipts (message_id, user_id, delivered_at, read_at)
     SELECT m.id, $2, now(), now()
       FROM messages m
      WHERE m.chat_id = $1 AND m.seq <= $3 AND m.sender_id <> $2
     ON CONFLICT (message_id, user_id)
     DO UPDATE SET delivered_at = COALESCE(message_receipts.delivered_at, now()),
                   read_at = COALESCE(message_receipts.read_at, now())`,
    [input.chatId, input.userId, target],
  );

  await publishToChat(input.chatId, {
    type: 'receipt.update',
    chatId: input.chatId,
    userId: input.userId,
    readUpTo: Number(readWatermark.last_read_seq),
  });

  return Number(readWatermark.last_read_seq);
}

/** Who has read a specific message (group chats). */
export async function listReaders(chatId: string, messageId: string, requesterId: string) {
  await requireMembership(chatId, requesterId);
  const res = await query(
    `SELECT r.user_id, r.delivered_at, r.read_at, u.username, p.display_name
       FROM message_receipts r
       JOIN users u ON u.id = r.user_id
       LEFT JOIN user_profiles p ON p.user_id = u.id
      WHERE r.message_id = $1
      ORDER BY r.read_at NULLS LAST`,
    [messageId],
  );
  return res.rows;
}

// ---------------------------------------------------------------------------
// Search & retention
// ---------------------------------------------------------------------------

export async function searchMessages(input: {
  userId: string;
  query: string;
  chatId?: string;
  type?: MessageType;
  fromUserId?: string;
  before?: string;
  after?: string;
  limit?: number;
}) {
  const term = input.query.trim();
  if (term.length < 2) return [];

  const params: unknown[] = [input.userId, term];
  const filters: string[] = [];

  if (input.chatId) {
    // Searching inside one conversation still requires membership.
    await requireMembership(input.chatId, input.userId);
    params.push(input.chatId);
    filters.push(`AND m.chat_id = $${params.length}`);
  }
  if (input.type) {
    params.push(input.type);
    filters.push(`AND m.type = $${params.length}`);
  }
  if (input.fromUserId) {
    params.push(input.fromUserId);
    filters.push(`AND m.sender_id = $${params.length}`);
  }
  if (input.after) {
    params.push(input.after);
    filters.push(`AND m.created_at >= $${params.length}`);
  }
  if (input.before) {
    params.push(input.before);
    filters.push(`AND m.created_at <= $${params.length}`);
  }

  const limit = Math.min(input.limit ?? 50, 100);
  params.push(limit);

  // Full-text first, with a substring fallback so short or partial terms still
  // match. The tsquery path uses the GIN index; the ILIKE path does not, which
  // is why it is bounded by LIMIT and only applies to the caller's own chats.
  const res = await query<MessageRow>(
    `SELECT m.*
       FROM messages m
       JOIN chat_members cm ON cm.chat_id = m.chat_id AND cm.user_id = $1 AND cm.left_at IS NULL
      WHERE m.is_deleted = false
        AND (m.expires_at IS NULL OR m.expires_at > now())
        AND NOT EXISTS (SELECT 1 FROM message_deletions md WHERE md.message_id = m.id AND md.user_id = $1)
        AND (m.search_vector @@ plainto_tsquery('simple', $2) OR m.body ILIKE '%' || $2 || '%')
        ${filters.join('\n        ')}
      ORDER BY m.seq DESC
      LIMIT $${params.length}`,
    params,
  );

  return hydrateMessages(res.rows, input.userId);
}

/**
 * Purge expired messages and statuses.
 *
 * Neon has no pg_cron on every plan, so this is called from a startup interval
 * as well as being safe to run from an external scheduler. It is deliberately
 * bounded so a large backlog cannot lock the table for a long time.
 */
export async function purgeExpired(batchSize = 5_000): Promise<{ messages: number; statuses: number }> {
  const messages = await query(
    `DELETE FROM messages
      WHERE id IN (
        SELECT id FROM messages
         WHERE expires_at IS NOT NULL AND expires_at < now()
         LIMIT $1
      )`,
    [batchSize],
  );

  const statuses = await query(
    `DELETE FROM statuses
      WHERE id IN (
        SELECT id FROM statuses
         WHERE (expires_at < now() OR deleted_at IS NOT NULL)
         LIMIT $1
      )`,
    [batchSize],
  );

  return { messages: messages.rowCount ?? 0, statuses: statuses.rowCount ?? 0 };
}

export async function getMessageById(chatId: string, messageId: string, userId: string) {
  await requireMembership(chatId, userId);
  const row = await loadOwnMessage(messageId, chatId);
  return (await hydrateMessages([row], userId))[0];
}

export { getChatMemberIds };
