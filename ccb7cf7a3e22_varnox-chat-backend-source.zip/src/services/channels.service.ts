import { query, queryOne, withTransaction } from '../db/pool.js';
import { ErrorCodes, badRequest, forbidden, notFound } from '../lib/errors.js';

/**
 * Channels — one-to-many broadcast.
 *
 * A channel is a page you follow: the owner posts, followers read, and nobody
 * replies in the channel itself. The tables were already migrated:
 *
 *   channels                the channel and its counters
 *   channel_subscribers     who follows, with a role and a read watermark
 *   channel_posts           the updates, ordered by a monotonic seq
 *   channel_post_reactions  emoji per follower per post
 *   channel_post_attachments media on a post
 *
 * Three decisions worth noting:
 *
 * 1. **`seq` orders the feed, not `created_at`.** It is a bigserial, so two
 *    posts in the same millisecond still have a stable order and `last_read_post_seq`
 *    can be a cheap comparison rather than a COUNT(*).
 *
 * 2. **Counters are maintained on write, not counted on read.** `follower_count`
 *    and `post_count` are updated in the same transaction as the row that
 *    changes them, so a directory listing never fans out into aggregates.
 *
 * 3. **Following is idempotent and reversible.** Unfollowing stamps `left_at`
 *    instead of deleting the row, so a re-follow keeps the original `joined_at`
 *    and the read watermark, and a departed follower's history is not lost.
 */

export type ChannelRole = 'follower' | 'admin' | 'owner';

export interface ChannelSummary {
  id: string;
  handle: string | null;
  name: string;
  description: string | null;
  photoUrl: string | null;
  category: string | null;
  isVerified: boolean;
  isSponsored: boolean;
  sponsorLabel: string | null;
  followerCount: number;
  postCount: number;
  createdAt: Date;
  /** Present when the caller is signed in and has a relationship with it. */
  isFollowing?: boolean;
  isMuted?: boolean;
  myRole?: ChannelRole | null;
  /** Posts the caller has not read, from the seq watermark. */
  unreadCount?: number;
  latestPostAt?: Date | null;
}

export interface ChannelPost {
  id: string;
  seq: number;
  type: string;
  body: string | null;
  metadata: Record<string, unknown>;
  isPinned: boolean;
  editedAt: Date | null;
  createdAt: Date;
  reactions: Array<{ emoji: string; count: number }>;
  myReaction: string | null;
  attachments: Array<{
    id: string;
    kind: string;
    mimeType: string;
    storageKey: string;
    byteSize: number;
    width: number | null;
    height: number | null;
  }>;
}

const DEFAULT_POST_LIMIT = 30;

/** Slug a channel name into a handle, which has to be unique. */
function toHandle(name: string): string {
  const base = name
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 32);
  return base.length >= 3 ? base : `channel_${Math.random().toString(36).slice(2, 8)}`;
}

// ---------------------------------------------------------------------------
// Read
// ---------------------------------------------------------------------------

function mapChannel(row: Record<string, unknown>): ChannelSummary {
  return {
    id: row.id as string,
    handle: (row.handle as string | null) ?? null,
    name: row.name as string,
    description: (row.description as string | null) ?? null,
    photoUrl: (row.photo_url as string | null) ?? null,
    category: (row.category as string | null) ?? null,
    isVerified: Boolean(row.is_verified),
    isSponsored: Boolean(row.is_sponsored),
    sponsorLabel: (row.sponsor_label as string | null) ?? null,
    followerCount: Number(row.follower_count ?? 0),
    postCount: Number(row.post_count ?? 0),
    createdAt: row.created_at as Date,
  };
}

/**
 * The directory. Signed-out-safe shape, but the caller's own relationship is
 * included when there is one so a list can show "Following" without a second
 * request per row.
 */
export async function searchChannels(input: {
  requesterId: string;
  search?: string;
  category?: string;
  limit?: number;
  offset?: number;
}): Promise<{ channels: ChannelSummary[]; total: number; limit: number; offset: number }> {
  const limit = input.limit ?? 30;
  const offset = input.offset ?? 0;
  const term = input.search?.trim() ? `%${input.search.trim()}%` : null;

  // The filter fragment is shared so the page and the total can never disagree
  // about what is being listed. That constrains the parameter order: the filters
  // must own $1 and $2, with pagination and the requester after them. Postgres
  // rejects a statement that supplies a parameter the SQL never mentions, which
  // is exactly what happened when the requester came first and the count query —
  // which has no use for it — still had to bind it.
  const filters = `
      c.deleted_at IS NULL
      AND c.is_public
      AND c.is_directory_listed
      AND ($1::text IS NULL OR c.name ILIKE $1 OR c.handle ILIKE $1 OR c.description ILIKE $1)
      AND ($2::text IS NULL OR c.category = $2)`;

  const [page, total] = await Promise.all([
    query(
      `SELECT c.*, s.role AS my_role, s.left_at AS my_left_at, s.is_muted AS my_muted
         FROM channels c
         LEFT JOIN channel_subscribers s ON s.channel_id = c.id AND s.user_id = $5
        WHERE ${filters}
        ORDER BY c.follower_count DESC, c.created_at DESC
        LIMIT $3 OFFSET $4`,
      [term, input.category ?? null, limit, offset, input.requesterId],
    ),
    query(`SELECT count(*)::int AS n FROM channels c WHERE ${filters}`, [term, input.category ?? null]),
  ]);

  // Unread is computed from the watermark, which is a different query because it
  // needs the subscriber's last_read_post_seq alongside the post high-water mark.
  const ids = page.rows.map((row) => row.id as string);
  const unreadByChannel = new Map<string, number>();
  if (ids.length > 0) {
    const unread = await query(
      `SELECT c.id,
              GREATEST(0, count(p.id))::int AS unread
         FROM channels c
         JOIN channel_subscribers s ON s.channel_id = c.id AND s.user_id = $1 AND s.left_at IS NULL
         LEFT JOIN channel_posts p ON p.channel_id = c.id AND p.is_deleted = false AND p.seq > s.last_read_post_seq
        WHERE c.id = ANY($2::uuid[])
        GROUP BY c.id`,
      [input.requesterId, ids],
    );
    for (const row of unread.rows) unreadByChannel.set(row.id as string, Number(row.unread ?? 0));
  }

  return {
    channels: page.rows.map((row) => {
      const channel = mapChannel(row);
      const role = (row.my_role as ChannelRole | null) ?? null;
      const active = row.my_left_at === null && role !== null;
      channel.isFollowing = active;
      channel.myRole = active ? role : null;
      channel.isMuted = active ? Boolean(row.my_muted) : undefined;
      const unread = unreadByChannel.get(channel.id);
      if (unread !== undefined) channel.unreadCount = unread;
      return channel;
    }),
    total: Number(total.rows[0]?.n ?? 0),
    limit,
    offset,
  };
}

/** Channels the caller owns or follows, most recently active first. */
export async function listMyChannels(requesterId: string): Promise<ChannelSummary[]> {
  const { rows } = await query(
    `SELECT c.*, s.role AS my_role, s.is_muted AS my_muted,
            (SELECT max(p.created_at) FROM channel_posts p WHERE p.channel_id = c.id AND p.is_deleted = false) AS latest_post_at
       FROM channels c
       JOIN channel_subscribers s ON s.channel_id = c.id AND s.user_id = $1 AND s.left_at IS NULL
      WHERE c.deleted_at IS NULL
      ORDER BY latest_post_at DESC NULLS LAST, c.created_at DESC`,
    [requesterId],
  );

  const ids = rows.map((row) => row.id as string);
  const unreadByChannel = new Map<string, number>();
  if (ids.length > 0) {
    const unread = await query(
      `SELECT c.id, GREATEST(0, count(p.id))::int AS unread
         FROM channels c
         JOIN channel_subscribers s ON s.channel_id = c.id AND s.user_id = $1 AND s.left_at IS NULL
         LEFT JOIN channel_posts p ON p.channel_id = c.id AND p.is_deleted = false AND p.seq > s.last_read_post_seq
        WHERE c.id = ANY($2::uuid[])
        GROUP BY c.id`,
      [requesterId, ids],
    );
    for (const row of unread.rows) unreadByChannel.set(row.id as string, Number(row.unread ?? 0));
  }

  return rows.map((row) => {
    const channel = mapChannel(row);
    channel.isFollowing = true;
    channel.myRole = (row.my_role as ChannelRole) ?? 'follower';
    channel.isMuted = Boolean(row.my_muted);
    channel.unreadCount = unreadByChannel.get(channel.id) ?? 0;
    channel.latestPostAt = (row.latest_post_at as Date | null) ?? null;
    return channel;
  });
}

export async function getChannel(input: { channelId: string; requesterId: string }): Promise<ChannelSummary> {
  const row = await queryOne(
    `SELECT c.*, s.role AS my_role, s.left_at AS my_left_at, s.is_muted AS my_muted
       FROM channels c
       LEFT JOIN channel_subscribers s ON s.channel_id = c.id AND s.user_id = $2
      WHERE c.id = $1 AND c.deleted_at IS NULL`,
    [input.channelId, input.requesterId],
  );
  if (!row) throw notFound(ErrorCodes.CHANNEL_NOT_FOUND, 'Channel not found');

  const channel = mapChannel(row);
  const role = (row.my_role as ChannelRole | null) ?? null;
  const active = row.my_left_at === null && role !== null;
  channel.isFollowing = active;
  channel.myRole = active ? role : null;
  channel.isMuted = active ? Boolean(row.my_muted) : undefined;
  return channel;
}

export async function listChannelPosts(input: {
  channelId: string;
  requesterId: string;
  limit?: number;
  beforeSeq?: number;
}): Promise<ChannelPost[]> {
  // Any signed-in user may read a public channel; a private one requires a
  // subscription. Checked here so the post query stays simple.
  const channel = await queryOne<{ is_public: boolean }>(
    `SELECT is_public FROM channels WHERE id = $1 AND deleted_at IS NULL`,
    [input.channelId],
  );
  if (!channel) throw notFound(ErrorCodes.CHANNEL_NOT_FOUND, 'Channel not found');

  if (!channel.is_public) {
    const subscriber = await queryOne(
      `SELECT 1 FROM channel_subscribers WHERE channel_id = $1 AND user_id = $2 AND left_at IS NULL`,
      [input.channelId, input.requesterId],
    );
    if (!subscriber) throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'This channel is private');
  }

  const limit = input.limit ?? DEFAULT_POST_LIMIT;
  const { rows } = await query(
    `SELECT p.*,
            (SELECT emoji FROM channel_post_reactions r WHERE r.post_id = p.id AND r.user_id = $2 LIMIT 1) AS my_reaction
       FROM channel_posts p
      WHERE p.channel_id = $1
        AND p.is_deleted = false
        AND ($3::bigint IS NULL OR p.seq < $3)
      ORDER BY p.is_pinned DESC, p.seq DESC
      LIMIT $4`,
    [input.channelId, input.requesterId, input.beforeSeq ?? null, limit],
  );

  if (rows.length === 0) return [];
  const postIds = rows.map((row) => row.id as string);

  const [reactions, attachments] = await Promise.all([
    query(
      `SELECT post_id, emoji, count(*)::int AS n
         FROM channel_post_reactions
        WHERE post_id = ANY($1::uuid[])
        GROUP BY post_id, emoji
        ORDER BY n DESC`,
      [postIds],
    ),
    query(
      `SELECT id, post_id, kind, mime_type, storage_key, byte_size, width, height
         FROM channel_post_attachments
        WHERE post_id = ANY($1::uuid[])`,
      [postIds],
    ),
  ]);

  const reactionsByPost = new Map<string, Array<{ emoji: string; count: number }>>();
  for (const row of reactions.rows) {
    const list = reactionsByPost.get(row.post_id as string) ?? [];
    list.push({ emoji: row.emoji as string, count: Number(row.n ?? 0) });
    reactionsByPost.set(row.post_id as string, list);
  }

  const attachmentsByPost = new Map<string, ChannelPost['attachments']>();
  for (const row of attachments.rows) {
    const list = attachmentsByPost.get(row.post_id as string) ?? [];
    list.push({
      id: row.id as string,
      kind: row.kind as string,
      mimeType: row.mime_type as string,
      storageKey: row.storage_key as string,
      byteSize: Number(row.byte_size ?? 0),
      width: (row.width as number | null) ?? null,
      height: (row.height as number | null) ?? null,
    });
    attachmentsByPost.set(row.post_id as string, list);
  }

  return rows.map((row) => ({
    id: row.id as string,
    seq: Number(row.seq),
    type: row.type as string,
    body: (row.body as string | null) ?? null,
    metadata: (row.metadata as Record<string, unknown>) ?? {},
    isPinned: Boolean(row.is_pinned),
    editedAt: (row.edited_at as Date | null) ?? null,
    createdAt: row.created_at as Date,
    reactions: reactionsByPost.get(row.id as string) ?? [],
    myReaction: (row.my_reaction as string | null) ?? null,
    attachments: attachmentsByPost.get(row.id as string) ?? [],
  }));
}

// ---------------------------------------------------------------------------
// Write
// ---------------------------------------------------------------------------

export async function createChannel(input: {
  ownerId: string;
  name: string;
  description?: string;
  category?: string;
  isPublic?: boolean;
  handle?: string;
}): Promise<ChannelSummary> {
  const name = input.name.trim();
  if (name.length < 3 || name.length > 80) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'A channel name needs to be 3 to 80 characters');
  }

  // The handle is derived and then uniquified: two channels may legitimately be
  // called the same thing, but a handle has to resolve to exactly one.
  const requested = input.handle?.trim() ? toHandle(input.handle) : toHandle(name);
  let handle = requested;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const clash = await queryOne(`SELECT 1 FROM channels WHERE handle = $1`, [handle]);
    if (!clash) break;
    handle = `${requested}_${Math.random().toString(36).slice(2, 6)}`;
  }

  return withTransaction(async (tx) => {
    const inserted = await tx.query(
      `INSERT INTO channels (handle, name, description, category, owner_id, is_public)
            VALUES ($1, $2, $3, $4, $5, $6)
         RETURNING *`,
      [handle, name, input.description?.trim() ?? null, input.category?.trim() ?? null, input.ownerId, input.isPublic ?? true],
    );
    const channel = inserted.rows[0]!;

    // The creator is a subscriber from the start, as owner, so every read path
    // that joins subscribers finds them.
    await tx.query(
      `INSERT INTO channel_subscribers (channel_id, user_id, role)
            VALUES ($1, $2, 'owner')
       ON CONFLICT (channel_id, user_id) DO UPDATE SET role = 'owner', left_at = NULL`,
      [channel.id, input.ownerId],
    );
    await tx.query(`UPDATE channels SET follower_count = 1 WHERE id = $1`, [channel.id]);
    channel.follower_count = 1;

    // The relationship fields are filled in rather than left to a follow-up
    // read: the creator is a follower by construction, and a create response
    // without them made the new channel look like one the caller had not joined.
    const summary = mapChannel(channel);
    summary.isFollowing = true;
    summary.myRole = 'owner';
    summary.unreadCount = 0;
    return summary;
  });
}

/** Owner or admin only. */
async function requireChannelAdmin(channelId: string, userId: string): Promise<ChannelRole> {
  const row = await queryOne<{ role: ChannelRole; owner_id: string | null }>(
    `SELECT s.role, c.owner_id
       FROM channels c
       LEFT JOIN channel_subscribers s ON s.channel_id = c.id AND s.user_id = $2 AND s.left_at IS NULL
      WHERE c.id = $1 AND c.deleted_at IS NULL`,
    [channelId, userId],
  );
  if (!row) throw notFound(ErrorCodes.CHANNEL_NOT_FOUND, 'Channel not found');
  if (row.owner_id === userId) return 'owner';
  if (row.role === 'admin' || row.role === 'owner') return row.role;
  throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Only the channel owner or an admin can do that');
}

export async function updateChannel(input: {
  channelId: string;
  requesterId: string;
  name?: string;
  description?: string;
  category?: string;
  photoUrl?: string;
  isPublic?: boolean;
}): Promise<ChannelSummary> {
  await requireChannelAdmin(input.channelId, input.requesterId);

  const updates: string[] = [];
  const params: unknown[] = [input.channelId];
  const set = (column: string, value: unknown) => {
    params.push(value);
    updates.push(`${column} = $${params.length}`);
  };

  if (input.name !== undefined) set('name', input.name.trim());
  if (input.description !== undefined) set('description', input.description.trim() || null);
  if (input.category !== undefined) set('category', input.category.trim() || null);
  if (input.photoUrl !== undefined) set('photo_url', input.photoUrl);
  if (input.isPublic !== undefined) set('is_public', input.isPublic);

  if (updates.length === 0) throw badRequest(ErrorCodes.VALIDATION_FAILED, 'Nothing to update');

  await query(`UPDATE channels SET ${updates.join(', ')}, updated_at = now() WHERE id = $1`, params);
  return getChannel({ channelId: input.channelId, requesterId: input.requesterId });
}

export async function followChannel(channelId: string, userId: string): Promise<ChannelSummary> {
  return withTransaction(async (tx) => {
    const channel = await tx.query(`SELECT id FROM channels WHERE id = $1 AND deleted_at IS NULL`, [channelId]);
    if (channel.rowCount === 0) throw notFound(ErrorCodes.CHANNEL_NOT_FOUND, 'Channel not found');

    // ON CONFLICT revives a departed follower rather than inserting a second
    // row, so the unique key and the counters both stay correct.
    const revived = await tx.query(
      `INSERT INTO channel_subscribers (channel_id, user_id, role)
            VALUES ($1, $2, 'follower')
       ON CONFLICT (channel_id, user_id)
       DO UPDATE SET left_at = NULL
       RETURNING (xmax = 0) AS was_insert`,
      [channelId, userId],
    );

    if (revived.rows[0]?.was_insert) {
      await tx.query(`UPDATE channels SET follower_count = follower_count + 1 WHERE id = $1`, [channelId]);
    }
    return { newlyFollowed: Boolean(revived.rows[0]?.was_insert) };
  }).then(() => getChannel({ channelId, requesterId: userId }));
}

export async function unfollowChannel(channelId: string, userId: string): Promise<ChannelSummary> {
  await withTransaction(async (tx) => {
    const current = await tx.query<{ role: ChannelRole }>(
      `SELECT role FROM channel_subscribers
        WHERE channel_id = $1 AND user_id = $2 AND left_at IS NULL`,
      [channelId, userId],
    );
    if (current.rowCount === 0) return;

    // The owner leaving would leave the channel unmanageable, so ownership has
    // to be handed over or the channel deleted instead.
    if (current.rows[0]!.role === 'owner') {
      throw badRequest(ErrorCodes.FORBIDDEN_ACTION, 'The owner cannot leave their own channel — delete it instead');
    }

    await tx.query(
      `UPDATE channel_subscribers SET left_at = now() WHERE channel_id = $1 AND user_id = $2`,
      [channelId, userId],
    );
    await tx.query(`UPDATE channels SET follower_count = GREATEST(follower_count - 1, 0) WHERE id = $1`, [channelId]);
  });

  return getChannel({ channelId, requesterId: userId });
}

export async function setChannelMuted(channelId: string, userId: string, muted: boolean): Promise<{ isMuted: boolean }> {
  const result = await query(
    `UPDATE channel_subscribers SET is_muted = $3
      WHERE channel_id = $1 AND user_id = $2 AND left_at IS NULL`,
    [channelId, userId, muted],
  );
  if (result.rowCount === 0) throw notFound(ErrorCodes.CHANNEL_NOT_FOUND, 'You do not follow that channel');
  return { isMuted: muted };
}

/** Moves the read watermark to the newest post, clearing the unread count. */
export async function markChannelRead(channelId: string, userId: string): Promise<{ lastReadSeq: number }> {
  const result = await query(
    `UPDATE channel_subscribers s
        SET last_read_post_seq = COALESCE(
              (SELECT max(p.seq) FROM channel_posts p WHERE p.channel_id = s.channel_id AND p.is_deleted = false),
              0)
      WHERE s.channel_id = $1 AND s.user_id = $2 AND s.left_at IS NULL
      RETURNING s.last_read_post_seq`,
    [channelId, userId],
  );
  if (result.rowCount === 0) throw notFound(ErrorCodes.CHANNEL_NOT_FOUND, 'You do not follow that channel');
  return { lastReadSeq: Number(result.rows[0]!.last_read_post_seq ?? 0) };
}

export async function createChannelPost(input: {
  channelId: string;
  requesterId: string;
  type: string;
  body?: string;
  attachments?: Array<{
    kind: 'image' | 'video' | 'audio' | 'document';
    mimeType: string;
    storageKey: string;
    byteSize?: number;
    width?: number;
    height?: number;
    durationMs?: number;
  }>;
}): Promise<ChannelPost> {
  await requireChannelAdmin(input.channelId, input.requesterId);

  const attachments = input.attachments ?? [];
  if (!['text', 'image', 'video', 'audio'].includes(input.type)) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'A channel post can be text, image, video or audio');
  }
  if (input.type === 'text' && !input.body?.trim()) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'A text post needs some text');
  }
  if (input.type !== 'text' && attachments.length === 0) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, `A ${input.type} post needs an attachment`);
  }

  return withTransaction(async (tx) => {
    const inserted = await tx.query(
      `INSERT INTO channel_posts (channel_id, author_id, type, body)
            VALUES ($1, $2, $3, $4)
         RETURNING *`,
      [input.channelId, input.requesterId, input.type, input.body?.trim() ?? null],
    );
    const post = inserted.rows[0]!;

    const savedAttachments: ChannelPost['attachments'] = [];
    for (const attachment of attachments) {
      const row = await tx.query(
        `INSERT INTO channel_post_attachments
               (post_id, kind, mime_type, storage_key, byte_size, width, height, duration_ms)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
         RETURNING id, kind, mime_type, storage_key, byte_size, width, height`,
        [
          post.id,
          attachment.kind,
          attachment.mimeType,
          attachment.storageKey,
          attachment.byteSize ?? 0,
          attachment.width ?? null,
          attachment.height ?? null,
          attachment.durationMs ?? null,
        ],
      );
      const saved = row.rows[0]!;
      savedAttachments.push({
        id: saved.id as string,
        kind: saved.kind as string,
        mimeType: saved.mime_type as string,
        storageKey: saved.storage_key as string,
        byteSize: Number(saved.byte_size ?? 0),
        width: (saved.width as number | null) ?? null,
        height: (saved.height as number | null) ?? null,
      });
    }

    // The counter is bumped in the same transaction as the post, so the
    // directory never has to aggregate to show a post count.
    await tx.query(`UPDATE channels SET post_count = post_count + 1, updated_at = now() WHERE id = $1`, [
      input.channelId,
    ]);

    return {
      id: post.id as string,
      seq: Number(post.seq),
      type: post.type as string,
      body: (post.body as string | null) ?? null,
      metadata: {},
      isPinned: false,
      editedAt: null,
      createdAt: post.created_at as Date,
      reactions: [],
      myReaction: null,
      attachments: savedAttachments,
    };
  });
}

export async function deleteChannelPost(channelId: string, postId: string, requesterId: string): Promise<void> {
  await requireChannelAdmin(channelId, requesterId);

  await withTransaction(async (tx) => {
    const result = await tx.query(
      `UPDATE channel_posts SET is_deleted = true, updated_at = now()
        WHERE id = $1 AND channel_id = $2 AND is_deleted = false`,
      [postId, channelId],
    );
    if (result.rowCount === 0) throw notFound(ErrorCodes.POST_NOT_FOUND, 'Post not found');
    await tx.query(`UPDATE channels SET post_count = GREATEST(post_count - 1, 0) WHERE id = $1`, [channelId]);
  });
}

export async function reactToChannelPost(postId: string, userId: string, emoji: string): Promise<void> {
  const post = await queryOne(`SELECT id FROM channel_posts WHERE id = $1 AND is_deleted = false`, [postId]);
  if (!post) throw notFound(ErrorCodes.POST_NOT_FOUND, 'Post not found');

  const trimmed = emoji.trim();
  if (!trimmed || trimmed.length > 16) throw badRequest(ErrorCodes.VALIDATION_FAILED, 'Send a single emoji');

  // Toggle: the same emoji twice removes it, which is what a reaction is
  // expected to do. A different emoji replaces nothing — the table allows a
  // person several emoji per post, as chat reactions do.
  const existing = await queryOne(
    `SELECT 1 FROM channel_post_reactions WHERE post_id = $1 AND user_id = $2 AND emoji = $3`,
    [postId, userId, trimmed],
  );
  if (existing) {
    await query(`DELETE FROM channel_post_reactions WHERE post_id = $1 AND user_id = $2 AND emoji = $3`, [
      postId,
      userId,
      trimmed,
    ]);
    return;
  }
  await query(
    `INSERT INTO channel_post_reactions (post_id, user_id, emoji) VALUES ($1, $2, $3)
     ON CONFLICT (post_id, user_id, emoji) DO NOTHING`,
    [postId, userId, trimmed],
  );
}
