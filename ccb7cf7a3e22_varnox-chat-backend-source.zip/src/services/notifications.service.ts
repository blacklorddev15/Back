import { config } from '../config.js';
import { query, queryOne } from '../db/pool.js';
import { publishToUser } from '../realtime/hub.js';

/**
 * Notifications: durable record, realtime push to open sockets, and Expo push
 * for devices that are not currently connected.
 *
 * The durable row is written first and is the source of truth. Everything after
 * that is best-effort delivery — if Expo is down, the user still sees the
 * notification the next time they open the app, and the in-app badge is driven
 * by the database, not by whether a push succeeded.
 */

export type NotificationType =
  | 'message' | 'group_message' | 'channel_post' | 'status' | 'mention' | 'reaction'
  | 'reply' | 'voice_call' | 'video_call' | 'missed_call' | 'join_request'
  | 'group_invite' | 'community_invite' | 'channel_update' | 'order_update'
  | 'payment' | 'security' | 'system' | 'moderation' | 'report_update' | 'follow';

export interface CreateNotificationInput {
  userId: string;
  type: NotificationType;
  title?: string;
  body?: string;
  targetType?: string;
  targetId?: string;
  metadata?: Record<string, unknown>;
  priority?: number;
  /** Skip push entirely (used for bulk/backfill writes). */
  silent?: boolean;
}

export async function createNotification(input: CreateNotificationInput): Promise<string | null> {
  const row = await queryOne<{ id: string }>(
    `INSERT INTO notifications (user_id, type, title, body, target_type, target_id, metadata, priority)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
     RETURNING id`,
    [
      input.userId,
      input.type,
      input.title ?? null,
      input.body ?? null,
      input.targetType ?? null,
      input.targetId ?? null,
      JSON.stringify(input.metadata ?? {}),
      input.priority ?? 3,
    ],
  );
  if (!row) return null;

  // Realtime first: it is free and instant for anyone with the app open.
  const deliveredInApp = publishToUser(input.userId, {
    type: 'notification.new',
    notification: {
      id: row.id,
      type: input.type,
      title: input.title,
      body: input.body,
      targetType: input.targetType,
      targetId: input.targetId,
      metadata: input.metadata ?? {},
      createdAt: new Date().toISOString(),
    },
  });

  if (!input.silent) {
    // Push is skipped only when the user demonstrably has the app open — if any
    // of their sockets received it, they are looking at the app already.
    void sendPushForNotification(row.id, input.userId, deliveredInApp > 0).catch((err) => {
      // eslint-disable-next-line no-console
      console.error('[notifications] push failed', (err as Error).message);
    });
  }

  return row.id;
}

/**
 * Fan out a new-message notification.
 *
 * Deliberately not one notification row per recipient message-by-message: the
 * notification is per recipient, and muted/archived chats are filtered here so
 * the caller does not have to think about it.
 */
export async function notifyNewMessage(input: {
  chatId: string;
  messageId: string;
  recipientIds: string[];
  senderId: string;
  preview: string;
}): Promise<void> {
  const sender = await queryOne<{ display_name: string | null; username: string | null }>(
    `SELECT p.display_name, u.username
       FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id
      WHERE u.id = $1`,
    [input.senderId],
  );
  const senderName = sender?.display_name ?? sender?.username ?? 'Someone';

  const settings = await query<{
    user_id: string;
    muted_until: Date | null;
    is_archived: boolean;
    chat_type: string;
    title: string | null;
    previews_enabled: boolean | null;
    in_app_enabled: boolean | null;
  }>(
    `SELECT cm.user_id, cm.muted_until, cm.is_archived, c.type AS chat_type, c.title,
            uns.previews_enabled, uns.in_app_enabled
       FROM chat_members cm
       JOIN chats c ON c.id = cm.chat_id
       LEFT JOIN user_notification_settings uns ON uns.user_id = cm.user_id
      WHERE cm.chat_id = $1 AND cm.user_id = ANY($2::uuid[])`,
    [input.chatId, input.recipientIds],
  );

  const now = Date.now();

  for (const row of settings.rows) {
    // Respect mute. An expired mute is treated as unmuted.
    if (row.muted_until && row.muted_until.getTime() > now) continue;
    if (row.in_app_enabled === false) continue;

    const showPreview = row.previews_enabled !== false;
    const isGroup = row.chat_type !== 'direct';
    const title = isGroup ? (row.title ?? 'Group') : senderName;
    const body = showPreview ? `${isGroup ? `${senderName}: ` : ''}${input.preview}` : 'New message';

    await createNotification({
      userId: row.user_id,
      type: isGroup ? 'group_message' : 'message',
      title,
      body,
      targetType: 'chat',
      targetId: input.chatId,
      // Archived chats notify quietly; the priority feeds the client's grouping.
      priority: row.is_archived ? 4 : 3,
      metadata: { chatId: input.chatId, messageId: input.messageId, senderId: input.senderId },
    });
  }
}

// ---------------------------------------------------------------------------
// Expo push
// ---------------------------------------------------------------------------

interface ExpoMessage {
  to: string;
  title?: string;
  body?: string;
  data?: Record<string, unknown>;
  sound?: 'default' | null;
  badge?: number;
  priority?: 'default' | 'normal' | 'high';
  channelId?: string;
}

/**
 * Deliver to every registered device for a user.
 *
 * Failure handling matters more than the happy path here: Expo returns HTTP
 * 200 even for per-token failures, and tells you about a dead token with
 * `DeviceNotRegistered`. Ignoring that is how a push list fills up with dead
 * tokens and deliverability quietly rots.
 */
async function sendPushForNotification(
  notificationId: string,
  userId: string,
  alreadyInApp: boolean,
): Promise<void> {
  const devices = await query<{ id: string; push_token: string; platform: string }>(
    `SELECT id, push_token, platform FROM devices
      WHERE user_id = $1 AND push_token IS NOT NULL AND push_enabled AND revoked_at IS NULL`,
    [userId],
  );
  if (devices.rows.length === 0) return;

  const notification = await queryOne<{
    title: string | null; body: string | null; type: string;
    target_type: string | null; target_id: string | null; metadata: Record<string, unknown>;
  }>(
    `SELECT title, body, type, target_type, target_id, metadata FROM notifications WHERE id = $1`,
    [notificationId],
  );

  const pending: { deviceId: string; message: ExpoMessage }[] = [];
  for (const device of devices.rows) {
    await query(
      `INSERT INTO notification_deliveries (notification_id, device_id, channel, status)
       VALUES ($1, $2, 'push', 'pending')`,
      [notificationId, device.id],
    );
    pending.push({
      deviceId: device.id,
      message: {
        to: device.push_token,
        title: notification?.title ?? undefined,
        body: notification?.body ?? undefined,
        data: {
          type: notification?.type,
          targetType: notification?.target_type,
          targetId: notification?.target_id,
          ...(notification?.metadata ?? {}),
        },
        sound: 'default',
        priority: 'high',
        ...(alreadyInApp ? { sound: null as unknown as 'default' } : {}),
      },
    });
  }

  if (!config.PUSH_ENABLED) {
    await query(
      `UPDATE notification_deliveries
          SET status = 'skipped', error = 'PUSH_ENABLED=false'
        WHERE notification_id = $1`,
      [notificationId],
    );
    return;
  }

  // Expo accepts up to 100 messages per request.
  for (let i = 0; i < pending.length; i += 100) {
    const batch = pending.slice(i, i + 100);
    try {
      const res = await fetch(config.EXPO_PUSH_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(batch.map((b) => b.message)),
      });

      const json = (await res.json()) as { data?: { status: string; message?: string; details?: { error?: string } }[] };
      const results = json.data ?? [];

      for (let j = 0; j < batch.length; j += 1) {
        const entry = batch[j]!;
        const result = results[j];
        if (result?.status === 'ok') {
          await query(
            `UPDATE notification_deliveries SET status = 'sent', sent_at = now(), attempts = attempts + 1, provider_ref = $3
              WHERE notification_id = $1 AND device_id = $2`,
            [notificationId, entry.deviceId, result.message ?? null],
          );
        } else {
          const errorCode = result?.details?.error ?? 'unknown';
          await query(
            `UPDATE notification_deliveries
                SET status = 'failed', attempts = attempts + 1, error = $3
              WHERE notification_id = $1 AND device_id = $2`,
            [notificationId, entry.deviceId, errorCode],
          );
          // A token Expo says is dead will never work again.
          if (errorCode === 'DeviceNotRegistered') {
            await query(`UPDATE devices SET push_enabled = false WHERE id = $1`, [entry.deviceId]);
          }
        }
      }
    } catch (err) {
      await query(
        `UPDATE notification_deliveries SET status = 'failed', attempts = attempts + 1, error = $2
          WHERE notification_id = $1`,
        [notificationId, (err as Error).message],
      );
    }
  }
}

// ---------------------------------------------------------------------------
// Reading & managing
// ---------------------------------------------------------------------------

export async function listNotifications(userId: string, opts: { unreadOnly?: boolean; limit?: number } = {}) {
  const res = await query(
    `SELECT id, type, title, body, target_type, target_id, metadata, priority, read_at, created_at
       FROM notifications
      WHERE user_id = $1
        AND ($2::boolean IS NOT TRUE OR read_at IS NULL)
      ORDER BY created_at DESC
      LIMIT $3`,
    [userId, opts.unreadOnly ?? false, Math.min(opts.limit ?? 50, 200)],
  );
  return res.rows;
}

export async function getUnreadCount(userId: string): Promise<number> {
  const row = await queryOne<{ count: string }>(
    `SELECT count(*)::text AS count FROM notifications WHERE user_id = $1 AND read_at IS NULL`,
    [userId],
  );
  return Number(row?.count ?? 0);
}

export async function markNotificationsRead(userId: string, ids?: string[]): Promise<number> {
  const res = ids?.length
    ? await query(
        `UPDATE notifications SET read_at = now() WHERE user_id = $1 AND id = ANY($2::uuid[]) AND read_at IS NULL`,
        [userId, ids],
      )
    : await query(`UPDATE notifications SET read_at = now() WHERE user_id = $1 AND read_at IS NULL`, [userId]);
  return res.rowCount ?? 0;
}

export async function registerPushToken(input: {
  userId: string;
  deviceId: string;
  token: string;
  platform: string;
}): Promise<void> {
  await query(
    `UPDATE devices
        SET push_token = $3,
            push_provider = CASE WHEN $4 = 'web' THEN 'fcm' ELSE 'expo' END,
            push_enabled = true,
            last_seen_at = now()
      WHERE id = $1 AND user_id = $2`,
    [input.deviceId, input.userId, input.token, input.platform],
  );
}

export async function unregisterPushToken(userId: string, deviceId: string): Promise<void> {
  await query(`UPDATE devices SET push_token = NULL, push_enabled = false WHERE id = $1 AND user_id = $2`, [
    deviceId,
    userId,
  ]);
}
