import { config } from '../config.js';
import { query, queryOne, withTransaction, type Tx } from '../db/pool.js';
import { hashPassword, hashPin, hashToken, randomToken, verifyPassword, verifyPin } from '../lib/crypto.js';
import { ErrorCodes, badRequest, conflict, forbidden, notFound, tooManyRequests, unauthorized } from '../lib/errors.js';
import { issueAccessToken } from '../lib/jwt.js';
import { sendSecurityAlertEmail } from '../lib/mailer.js';
import { consume } from '../lib/rate-limit.js';
import { logAudit, logSecurityEvent } from './audit.service.js';
import { requestOtp, verifyOtp } from './otp.service.js';

export interface DeviceInput {
  /** Stable id the client generates once and persists. Lets us recognise a device across logins. */
  deviceId?: string;
  platform?: 'android' | 'ios' | 'web' | 'windows' | 'macos' | 'linux' | 'unknown';
  deviceName?: string;
  appVersion?: string;
  osVersion?: string;
  pushToken?: string;
}

export interface AuthContext {
  ip?: string;
  userAgent?: string;
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  accessTokenExpiresAt: Date;
  refreshTokenExpiresAt: Date;
}

export interface PublicUser {
  id: string;
  email: string | null;
  phone: string | null;
  username: string | null;
  fullName: string | null;
  status: string;
  isBusiness: boolean;
  isVerified: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
  twoStepEnabled: boolean;
  createdAt: Date;
}

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------

/**
 * Creates the account in `pending` state and emails a verification code.
 *
 * No tokens are issued here — the checklist requires the email code be
 * completed first, and issuing a session before verification would make the
 * code decorative.
 */
export async function registerUser(input: {
  fullName: string;
  email: string;
  phone: string;
  password: string;
  ctx: AuthContext;
}): Promise<{ userId: string; expiresAt: Date }> {
  const email = input.email.trim().toLowerCase();
  const phone = input.phone.trim();

  // Cheap upfront checks for a friendly error. The unique indexes remain the
  // real guarantee — two simultaneous registrations can both pass this check,
  // which is why the insert below is wrapped and mapped.
  const existing = await queryOne<{
    id: string;
    email: string | null;
    phone: string | null;
    status: string;
    email_verified_at: Date | null;
  }>(
    `SELECT id, email, phone, status, email_verified_at FROM users
      WHERE deleted_at IS NULL
        AND (lower(email) = $1 OR phone = $2)
      LIMIT 1`,
    [email, phone],
  );

  if (existing) {
    const sameEmail = existing.email?.toLowerCase() === email;

    /**
     * An account that was created but never verified is NOT "taken".
     *
     * Without this, any failure on the very first attempt (a transient network
     * error, a mail provider outage) permanently strands the user: the first
     * request wrote the user row before the email failed, so every retry hits
     * "email already taken" and they can never finish signing up.
     *
     * It is safe to let the retry through: the verification code still goes to
     * the same mailbox, so whoever can read that inbox is the legitimate owner.
     */
    const retryable = sameEmail && existing.status === 'pending' && existing.email_verified_at === null;

    if (!retryable) {
      if (sameEmail) {
        throw conflict(ErrorCodes.EMAIL_TAKEN, 'An account with that email already exists');
      }
      throw conflict(ErrorCodes.PHONE_TAKEN, 'An account with that phone number already exists');
    }

    const retryHash = await hashPassword(input.password);
    await query(
      `UPDATE users SET password_hash = $2, full_name = $3, phone = $4 WHERE id = $1`,
      [existing.id, retryHash, input.fullName.trim(), phone],
    );

    const retryOtp = await requestOtp({
      destination: email,
      purpose: 'register',
      userId: existing.id,
      ip: input.ctx.ip,
      enforceCooldown: false,
    });

    await logAudit({
      actorId: existing.id,
      action: 'user.register_retry',
      targetType: 'user',
      targetId: existing.id,
      ip: input.ctx.ip,
      userAgent: input.ctx.userAgent,
    });

    return { userId: existing.id, expiresAt: retryOtp.expiresAt };
  }

  const passwordHash = await hashPassword(input.password);

  const userId = await withTransaction(async (tx) => {
    const inserted = await tx.query<{ id: string }>(
      `INSERT INTO users (email, phone, password_hash, full_name, status)
       VALUES ($1, $2, $3, $4, 'pending')
       RETURNING id`,
      [email, phone, passwordHash, input.fullName.trim()],
    );
    const id = inserted.rows[0]!.id;

    // Every user gets the same baseline rows so that later code can assume
    // they exist rather than defensively upserting everywhere.
    await tx.query(`INSERT INTO user_profiles (user_id, display_name) VALUES ($1, $2)`, [id, input.fullName.trim()]);
    await tx.query(`INSERT INTO user_privacy_settings (user_id) VALUES ($1)`, [id]);
    await tx.query(`INSERT INTO user_notification_settings (user_id) VALUES ($1)`, [id]);
    await tx.query(`INSERT INTO user_appearance_settings (user_id) VALUES ($1)`, [id]);

    return id;
  });

  const otp = await requestOtp({
    destination: email,
    purpose: 'register',
    userId,
    ip: input.ctx.ip,
    enforceCooldown: false,
  });

  await logAudit({
    actorId: userId,
    action: 'user.register',
    targetType: 'user',
    targetId: userId,
    ip: input.ctx.ip,
    userAgent: input.ctx.userAgent,
  });

  return { userId, expiresAt: otp.expiresAt };
}

/**
 * Completes registration: consumes the email code, activates the account,
 * registers the device and issues the first session.
 */
export async function verifyEmailAndActivate(input: {
  email: string;
  code: string;
  device: DeviceInput;
  ctx: AuthContext;
}): Promise<{ user: PublicUser; tokens: TokenPair; deviceId: string; isNewDevice: boolean }> {
  const email = input.email.trim().toLowerCase();

  await verifyOtp({ destination: email, purpose: 'register', code: input.code });

  const user = await queryOne<{ id: string; status: string }>(
    `SELECT id, status FROM users WHERE lower(email) = $1 AND deleted_at IS NULL`,
    [email],
  );
  if (!user) throw notFound(ErrorCodes.USER_NOT_FOUND, 'No account found for that email address');

  await query(
    `UPDATE users
        SET email_verified_at = now(),
            status = CASE WHEN status = 'pending' THEN 'active' ELSE status END
      WHERE id = $1`,
    [user.id],
  );

  const { deviceId, isNewDevice } = await resolveDevice(user.id, input.device, input.ctx);
  const tokens = await issueSession(user.id, deviceId, input.ctx);

  await logSecurityEvent({
    userId: user.id,
    deviceId,
    type: 'login_success',
    ip: input.ctx.ip,
    userAgent: input.ctx.userAgent,
    metadata: { flow: 'registration' },
  });

  return { user: (await getPublicUser(user.id))!, tokens, deviceId, isNewDevice };
}

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------

export type LoginResult =
  | { twoStepRequired: true; challengeToken: string; userId: string }
  | { twoStepRequired: false; user: PublicUser; tokens: TokenPair; deviceId: string; isNewDevice: boolean };

export async function login(input: {
  identifier: string;
  password: string;
  device: DeviceInput;
  ctx: AuthContext;
}): Promise<LoginResult> {
  const identifier = input.identifier.trim();

  // Throttle by identifier and by IP. Both matter: the first stops a
  // credential-stuffing run against one account, the second stops a spray
  // across many accounts from one source.
  const byIdentifier = consume(`login:id:${identifier.toLowerCase()}`, 10, 900);
  if (!byIdentifier.allowed) {
    throw tooManyRequests(ErrorCodes.ACCOUNT_LOCKED, 'Too many sign-in attempts. Try again later.', {
      retryAfterSeconds: byIdentifier.retryAfterSeconds,
    });
  }
  if (input.ctx.ip) {
    const byIp = consume(`login:ip:${input.ctx.ip}`, 60, 900);
    if (!byIp.allowed) {
      throw tooManyRequests(ErrorCodes.ACCOUNT_LOCKED, 'Too many sign-in attempts from this network.', {
        retryAfterSeconds: byIp.retryAfterSeconds,
      });
    }
  }

  const user = await queryOne<{
    id: string;
    password_hash: string;
    status: string;
    email_verified_at: Date | null;
    two_step_enabled: boolean;
    locked_until: Date | null;
    failed_login_count: number;
  }>(
    `SELECT id, password_hash, status, email_verified_at, two_step_enabled, locked_until, failed_login_count
       FROM users
      WHERE deleted_at IS NULL
        AND (lower(email) = lower($1) OR phone = $1 OR lower(username) = lower($1))
      LIMIT 1`,
    [identifier],
  );

  // Deliberately identical error for "no such user" and "wrong password" so
  // the endpoint cannot be used to enumerate accounts.
  const genericFailure = unauthorized(ErrorCodes.INVALID_CREDENTIALS, 'Incorrect email or password');

  if (!user) {
    await logSecurityEvent({
      userId: null,
      type: 'login_failed',
      ip: input.ctx.ip,
      userAgent: input.ctx.userAgent,
      metadata: { reason: 'unknown_identifier' },
    });
    throw genericFailure;
  }

  if (user.locked_until && user.locked_until.getTime() > Date.now()) {
    throw forbidden(ErrorCodes.ACCOUNT_LOCKED, 'This account is temporarily locked. Try again later.');
  }

  const passwordOk = await verifyPassword(input.password, user.password_hash);
  if (!passwordOk) {
    // Escalating lockout: 5 failures locks for 15 minutes, 10 for an hour.
    const failures = user.failed_login_count + 1;
    const lockMinutes = failures >= 10 ? 60 : failures >= 5 ? 15 : 0;
    await query(
      `UPDATE users
          SET failed_login_count = $2,
              locked_until = CASE WHEN $3 > 0 THEN now() + ($3 || ' minutes')::interval ELSE locked_until END
        WHERE id = $1`,
      [user.id, failures, lockMinutes],
    );
    await logSecurityEvent({
      userId: user.id,
      type: 'login_failed',
      ip: input.ctx.ip,
      userAgent: input.ctx.userAgent,
      metadata: { failures, lockedForMinutes: lockMinutes },
    });
    throw genericFailure;
  }

  if (user.status === 'suspended') {
    throw forbidden(ErrorCodes.ACCOUNT_SUSPENDED, 'This account has been suspended. Contact support.');
  }
  if (user.status === 'deleted' || user.status === 'deactivated') {
    throw forbidden(ErrorCodes.ACCOUNT_SUSPENDED, 'This account is no longer active.');
  }

  // The phone number is collected but not verified, so email verification is
  // what gates access.
  if (!user.email_verified_at) {
    throw forbidden(ErrorCodes.EMAIL_NOT_VERIFIED, 'Verify your email address before signing in.');
  }

  // --- Two-step verification ---------------------------------------------
  if (user.two_step_enabled) {
    // A provisional session row carries the challenge so the token has a real
    // `sid` and can be revoked if the challenge is abandoned.
    const sessionId = await createSession(user.id, null, input.ctx, 5 * 60);
    const challenge = issueAccessToken({
      userId: user.id,
      sessionId,
      stage: 'two_step',
      ttlSeconds: 300,
    });
    return { twoStepRequired: true, challengeToken: challenge.token, userId: user.id };
  }

  const session = await completeLogin(user.id, input.device, input.ctx);
  return { twoStepRequired: false, ...session };
}

/** Second half of a two-step login: PIN (or a backup code) completes the session. */
export async function completeTwoStepLogin(input: {
  challengeToken: string;
  pin: string;
  device: DeviceInput;
  ctx: AuthContext;
}): Promise<{ user: PublicUser; tokens: TokenPair; deviceId: string; isNewDevice: boolean }> {
  // Imported lazily to avoid a circular import between auth and jwt helpers.
  const { verifyAccessToken } = await import('../lib/jwt.js');
  const verified = verifyAccessToken(input.challengeToken);
  if (!verified.ok) {
    throw unauthorized(ErrorCodes.TOKEN_EXPIRED, 'Your verification session expired. Sign in again.');
  }
  if (verified.claims.stage !== 'two_step') {
    throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Invalid verification token');
  }

  const userId = verified.claims.sub;
  const attempts = consume(`twostep:${userId}`, 5, 900);
  if (!attempts.allowed) {
    throw tooManyRequests(ErrorCodes.ACCOUNT_LOCKED, 'Too many incorrect PIN attempts. Try again later.');
  }

  const row = await queryOne<{ two_step_pin_hash: string | null }>(
    `SELECT two_step_pin_hash FROM users WHERE id = $1 AND deleted_at IS NULL`,
    [userId],
  );
  if (!row?.two_step_pin_hash) {
    throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Two-step verification is not configured');
  }

  let ok = await verifyPin(input.pin, row.two_step_pin_hash);

  // Backup codes are a one-shot fallback so a forgotten PIN does not lock the
  // user out permanently.
  if (!ok) {
    const backup = await queryOne<{ id: string; code_hash: string }>(
      `SELECT id, code_hash FROM auth_two_step_backup_codes
        WHERE user_id = $1 AND used_at IS NULL`,
      [userId],
    );
    if (backup) {
      const { verifyPassword } = await import('../lib/crypto.js');
      if (await verifyPassword(`backup:${input.pin}`, backup.code_hash)) {
        await query(`UPDATE auth_two_step_backup_codes SET used_at = now() WHERE id = $1`, [backup.id]);
        ok = true;
      }
    }
  }

  if (!ok) {
    await logSecurityEvent({ userId, type: 'otp_failed', ip: input.ctx.ip, userAgent: input.ctx.userAgent });
    throw unauthorized(ErrorCodes.TWO_STEP_INVALID, 'Incorrect PIN');
  }

  // The provisional challenge session did its job; retire it.
  await query(`UPDATE sessions SET revoked_at = now(), revoked_reason = 'two_step_completed' WHERE id = $1`, [
    verified.claims.sid,
  ]);

  return completeLogin(userId, input.device, input.ctx);
}

async function completeLogin(
  userId: string,
  device: DeviceInput,
  ctx: AuthContext,
): Promise<{ user: PublicUser; tokens: TokenPair; deviceId: string; isNewDevice: boolean }> {
  const { deviceId, isNewDevice } = await resolveDevice(userId, device, ctx);
  const tokens = await issueSession(userId, deviceId, ctx);

  // A successful sign-in clears the failure counter and any lock.
  await query(`UPDATE users SET failed_login_count = 0, locked_until = NULL WHERE id = $1`, [userId]);

  await logSecurityEvent({
    userId,
    deviceId,
    type: isNewDevice ? 'login_new_device' : 'login_success',
    ip: ctx.ip,
    userAgent: ctx.userAgent,
  });

  if (isNewDevice) {
    // "New-device login alerts" from the checklist. Sent after the response is
    // prepared but awaited here for simplicity; move to a queue if email
    // latency becomes visible.
    await notifyNewDevice(userId, device, ctx).catch(() => {});
  }

  return { user: (await getPublicUser(userId))!, tokens, deviceId, isNewDevice };
}

async function notifyNewDevice(userId: string, device: DeviceInput, ctx: AuthContext): Promise<void> {
  const user = await queryOne<{ email: string | null; notification_enabled: boolean | null }>(
    `SELECT u.email, uns.email_security_alerts AS notification_enabled
       FROM users u
       LEFT JOIN user_notification_settings uns ON uns.user_id = u.id
      WHERE u.id = $1`,
    [userId],
  );
  if (!user?.email || user.notification_enabled === false) return;

  await sendSecurityAlertEmail({
    to: user.email,
    subject: 'New sign-in to your account',
    body:
      `A new device just signed in to your account.\n\n` +
      `Device:  ${device.deviceName ?? 'Unknown'} (${device.platform ?? 'unknown'})\n` +
      `IP:      ${ctx.ip ?? 'unknown'}\n` +
      `Time:    ${new Date().toISOString()}`,
  });
}

// ---------------------------------------------------------------------------
// Sessions & devices
// ---------------------------------------------------------------------------

/**
 * Resolve (or create) the device row for this client.
 *
 * `isNewDevice` is the honest answer to "have we seen this device before",
 * computed before the current row is touched.
 */
async function resolveDevice(
  userId: string,
  device: DeviceInput,
  ctx: AuthContext,
): Promise<{ deviceId: string; isNewDevice: boolean }> {
  const platform = device.platform ?? 'unknown';

  if (device.deviceId) {
    const existing = await queryOne<{ id: string; user_id: string }>(
      `SELECT id, user_id FROM devices WHERE id = $1`,
      [device.deviceId],
    );
    // Never let one client claim another user's device id.
    if (existing && existing.user_id === userId) {
      await query(
        `UPDATE devices
            SET platform = $2,
                device_name = COALESCE($3, device_name),
                app_version = COALESCE($4, app_version),
                os_version = COALESCE($5, os_version),
                push_token = COALESCE($6, push_token),
                last_ip = $7,
                last_seen_at = now()
          WHERE id = $1`,
        [
          existing.id,
          platform,
          device.deviceName ?? null,
          device.appVersion ?? null,
          device.osVersion ?? null,
          device.pushToken ?? null,
          ctx.ip ?? null,
        ],
      );
      const seen = await queryOne<{ count: string }>(
        `SELECT count(*)::text AS count FROM sessions WHERE device_id = $1`,
        [existing.id],
      );
      return { deviceId: existing.id, isNewDevice: (seen?.count ?? '0') === '0' };
    }
  }

  const created = await query<{ id: string }>(
    `INSERT INTO devices (user_id, platform, device_name, app_version, os_version, push_token, last_ip, last_seen_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, now())
     RETURNING id`,
    [
      userId,
      platform,
      device.deviceName ?? null,
      device.appVersion ?? null,
      device.osVersion ?? null,
      device.pushToken ?? null,
      ctx.ip ?? null,
    ],
  );
  return { deviceId: created.rows[0]!.id, isNewDevice: true };
}

/**
 * Create a session row and mint the token pair.
 *
 * Only the SHA-256 of the refresh token is stored, so reading the sessions
 * table does not yield usable credentials.
 */
async function issueSession(
  userId: string,
  deviceId: string | null,
  ctx: AuthContext,
): Promise<TokenPair> {
  const refreshToken = randomToken(48);
  const refreshExpiresAt = new Date(Date.now() + config.REFRESH_TOKEN_TTL_DAYS * 86_400_000);

  const session = await createSession(userId, deviceId, ctx, config.REFRESH_TOKEN_TTL_DAYS * 86_400);

  await query(`UPDATE sessions SET refresh_token_hash = $2 WHERE id = $1`, [
    session,
    hashToken(refreshToken),
  ]);

  const role = await getAdminRole(userId);
  const access = issueAccessToken({ userId, sessionId: session, deviceId: deviceId ?? undefined, role: role ?? undefined });

  return {
    accessToken: access.token,
    refreshToken,
    accessTokenExpiresAt: access.expiresAt,
    refreshTokenExpiresAt: refreshExpiresAt,
  };
}

async function createSession(
  userId: string,
  deviceId: string | null,
  ctx: AuthContext,
  ttlSeconds: number,
): Promise<string> {
  const res = await query<{ id: string }>(
    `INSERT INTO sessions (user_id, device_id, refresh_token_hash, issued_ip, user_agent, expires_at)
     VALUES ($1, $2, $3, $4, $5, now() + ($6 || ' seconds')::interval)
     RETURNING id`,
    [userId, deviceId, randomToken(32), ctx.ip ?? null, ctx.userAgent ?? null, String(ttlSeconds)],
  );
  return res.rows[0]!.id;
}

export async function getAdminRole(userId: string): Promise<string | null> {
  const row = await queryOne<{ role: string }>(
    `SELECT role FROM admin_roles WHERE user_id = $1 AND revoked_at IS NULL`,
    [userId],
  );
  return row?.role ?? null;
}

/**
 * Rotate a refresh token.
 *
 * Rotation (rather than reuse) means a stolen refresh token is only useful
 * until the legitimate client next refreshes — at which point the thief's copy
 * is dead and the theft becomes detectable.
 */
export async function refreshSession(input: { refreshToken: string; ctx: AuthContext }): Promise<TokenPair> {
  const tokenHash = hashToken(input.refreshToken);

  const row = await queryOne<{
    id: string;
    user_id: string;
    device_id: string | null;
    expires_at: Date;
    revoked_at: Date | null;
  }>(
    `SELECT id, user_id, device_id, expires_at, revoked_at FROM sessions WHERE refresh_token_hash = $1`,
    [tokenHash],
  );

  if (!row) throw unauthorized(ErrorCodes.SESSION_REVOKED, 'Session not found. Sign in again.');
  if (row.revoked_at) {
    // Reuse of a revoked token is a strong signal of theft. Kill every session
    // for that user rather than just refusing this one.
    await query(
      `UPDATE sessions SET revoked_at = now(), revoked_reason = 'refresh_token_reuse'
        WHERE user_id = $1 AND revoked_at IS NULL`,
      [row.user_id],
    );
    await logSecurityEvent({
      userId: row.user_id,
      type: 'session_revoked',
      ip: input.ctx.ip,
      metadata: { reason: 'refresh_token_reuse' },
    });
    throw unauthorized(ErrorCodes.SESSION_REVOKED, 'This session was already ended. Sign in again.');
  }
  if (row.expires_at.getTime() <= Date.now()) {
    throw unauthorized(ErrorCodes.TOKEN_EXPIRED, 'Session expired. Sign in again.');
  }

  await query(`UPDATE sessions SET revoked_at = now(), revoked_reason = 'rotated' WHERE id = $1`, [row.id]);

  const userId = row.user_id;
  const deviceId = row.device_id;
  const refreshToken = randomToken(48);
  const refreshExpiresAt = new Date(Date.now() + config.REFRESH_TOKEN_TTL_DAYS * 86_400_000);

  const newSessionId = await createSession(userId, deviceId, input.ctx, config.REFRESH_TOKEN_TTL_DAYS * 86_400);
  await query(`UPDATE sessions SET refresh_token_hash = $2 WHERE id = $1`, [newSessionId, hashToken(refreshToken)]);

  const role = await getAdminRole(userId);
  const access = issueAccessToken({
    userId,
    sessionId: newSessionId,
    deviceId: deviceId ?? undefined,
    role: role ?? undefined,
  });

  await query(`UPDATE sessions SET last_used_at = now() WHERE id = $1`, [newSessionId]);
  if (deviceId) await query(`UPDATE devices SET last_seen_at = now() WHERE id = $1`, [deviceId]);

  return { accessToken: access.token, refreshToken, accessTokenExpiresAt: access.expiresAt, refreshTokenExpiresAt: refreshExpiresAt };
}

export async function logout(refreshToken: string): Promise<void> {
  await query(
    `UPDATE sessions SET revoked_at = now(), revoked_reason = 'user_logout'
      WHERE refresh_token_hash = $1 AND revoked_at IS NULL`,
    [hashToken(refreshToken)],
  );
}

/** "Remote logout": end every session, optionally sparing the current one. */
export async function logoutAllSessions(userId: string, exceptSessionId?: string): Promise<number> {
  const res = await query(
    `UPDATE sessions
        SET revoked_at = now(), revoked_reason = 'logout_all'
      WHERE user_id = $1 AND revoked_at IS NULL AND ($2::uuid IS NULL OR id <> $2::uuid)`,
    [userId, exceptSessionId ?? null],
  );
  await logSecurityEvent({ userId, type: 'logout', metadata: { scope: 'all', count: res.rowCount } });
  return res.rowCount ?? 0;
}

export async function listDevices(userId: string) {
  const res = await query(
    `SELECT d.id, d.platform, d.device_name, d.app_version, d.os_version,
            d.is_primary, d.linked_via_qr, d.last_ip, d.last_seen_at, d.created_at,
            (SELECT max(s.last_used_at) FROM sessions s WHERE s.device_id = d.id AND s.revoked_at IS NULL) AS last_session_at,
            (SELECT count(*) FROM sessions s WHERE s.device_id = d.id AND s.revoked_at IS NULL) AS active_sessions
       FROM devices d
      WHERE d.user_id = $1 AND d.revoked_at IS NULL
      ORDER BY d.last_seen_at DESC NULLS LAST`,
    [userId],
  );
  return res.rows;
}

export async function revokeDevice(userId: string, deviceId: string, reason = 'user_revoked'): Promise<void> {
  await withTransaction(async (tx) => {
    const dev = await tx.query(
      `UPDATE devices SET revoked_at = now(), revoked_reason = $3
        WHERE id = $1 AND user_id = $2 AND revoked_at IS NULL`,
      [deviceId, userId, reason],
    );
    if (dev.rowCount === 0) throw notFound(ErrorCodes.USER_NOT_FOUND, 'Device not found');

    await tx.query(
      `UPDATE sessions SET revoked_at = now(), revoked_reason = 'device_revoked'
        WHERE device_id = $1 AND revoked_at IS NULL`,
      [deviceId],
    );
  });
  await logSecurityEvent({ userId, deviceId, type: 'device_revoked' });
}

// ---------------------------------------------------------------------------
// Passwords & recovery
// ---------------------------------------------------------------------------

export async function changePassword(input: {
  userId: string;
  currentPassword: string;
  newPassword: string;
  keepSessionId?: string;
  ctx: AuthContext;
}): Promise<void> {
  const row = await queryOne<{ password_hash: string; email: string | null }>(
    `SELECT password_hash, email FROM users WHERE id = $1 AND deleted_at IS NULL`,
    [input.userId],
  );
  if (!row) throw notFound(ErrorCodes.USER_NOT_FOUND, 'Account not found');

  if (!(await verifyPassword(input.currentPassword, row.password_hash))) {
    throw unauthorized(ErrorCodes.INVALID_CREDENTIALS, 'Current password is incorrect');
  }

  const newHash = await hashPassword(input.newPassword);
  await withTransaction(async (tx) => {
    await tx.query(`UPDATE users SET password_hash = $2 WHERE id = $1`, [input.userId, newHash]);
    // Changing a password must invalidate other sessions — that is the entire
    // point of doing it after a suspected compromise.
    await tx.query(
      `UPDATE sessions SET revoked_at = now(), revoked_reason = 'password_changed'
        WHERE user_id = $1 AND revoked_at IS NULL AND ($2::uuid IS NULL OR id <> $2::uuid)`,
      [input.userId, input.keepSessionId ?? null],
    );
  });

  await logSecurityEvent({ userId: input.userId, type: 'password_changed', ip: input.ctx.ip });
  if (row.email) {
    await sendSecurityAlertEmail({
      to: row.email,
      subject: 'Your password was changed',
      body: `Your account password was changed on ${new Date().toISOString()} from ${input.ctx.ip ?? 'an unknown IP'}.`,
    });
  }
}

/** Step 1: request a reset code by email. Always reports success. */
export async function requestPasswordReset(email: string, ctx: AuthContext): Promise<void> {
  const normalized = email.trim().toLowerCase();
  const user = await queryOne<{ id: string }>(
    `SELECT id FROM users WHERE lower(email) = $1 AND deleted_at IS NULL AND status <> 'deleted'`,
    [normalized],
  );

  if (!user) {
    // Deliberate: telling the caller "no such account" turns this endpoint into
    // an account-enumeration oracle. The response is identical either way.
    return;
  }

  await requestOtp({ destination: normalized, purpose: 'reset_password', userId: user.id, ip: ctx.ip });
}

/** Step 2: consume the code and set the new password. */
export async function resetPassword(input: {
  email: string;
  code: string;
  newPassword: string;
  ctx: AuthContext;
}): Promise<void> {
  const email = input.email.trim().toLowerCase();
  await verifyOtp({ destination: email, purpose: 'reset_password', code: input.code });

  const user = await queryOne<{ id: string }>(
    `SELECT id FROM users WHERE lower(email) = $1 AND deleted_at IS NULL`,
    [email],
  );
  if (!user) throw notFound(ErrorCodes.USER_NOT_FOUND, 'Account not found');

  const newHash = await hashPassword(input.newPassword);
  await withTransaction(async (tx) => {
    await tx.query(
      `UPDATE users SET password_hash = $2, failed_login_count = 0, locked_until = NULL WHERE id = $1`,
      [user.id, newHash],
    );
    await tx.query(
      `UPDATE sessions SET revoked_at = now(), revoked_reason = 'password_reset' WHERE user_id = $1 AND revoked_at IS NULL`,
      [user.id],
    );
  });

  await logSecurityEvent({ userId: user.id, type: 'password_changed', ip: input.ctx.ip, metadata: { via: 'reset' } });
}

// ---------------------------------------------------------------------------
// Email & phone changes
// ---------------------------------------------------------------------------

export async function requestEmailChange(userId: string, newEmail: string, ctx: AuthContext): Promise<Date> {
  const email = newEmail.trim().toLowerCase();

  const taken = await queryOne<{ id: string }>(
    `SELECT id FROM users WHERE lower(email) = $1 AND deleted_at IS NULL AND id <> $2`,
    [email, userId],
  );
  if (taken) throw conflict(ErrorCodes.EMAIL_TAKEN, 'That email address is already in use');

  const otp = await requestOtp({ destination: email, purpose: 'change_email', userId, ip: ctx.ip });
  return otp.expiresAt;
}

export async function confirmEmailChange(input: {
  userId: string;
  newEmail: string;
  code: string;
  ctx: AuthContext;
}): Promise<void> {
  const email = input.newEmail.trim().toLowerCase();
  await verifyOtp({ destination: email, purpose: 'change_email', code: input.code });

  try {
    await query(`UPDATE users SET email = $2, email_verified_at = now() WHERE id = $1`, [input.userId, email]);
  } catch {
    throw conflict(ErrorCodes.EMAIL_TAKEN, 'That email address is already in use');
  }

  await logSecurityEvent({ userId: input.userId, type: 'email_changed', ip: input.ctx.ip, metadata: { email } });
  await sendSecurityAlertEmail({
    to: email,
    subject: 'Your email address was changed',
    body: `Your account email was changed to ${email} on ${new Date().toISOString()}.`,
  });
}

/**
 * Phone numbers are stored as identifiers only and are NOT verified — the
 * product spec sends codes to email. If you later switch on SMS verification,
 * this must move to a two-step confirm flow so an unverified number cannot be
 * used to take over an account.
 */
export async function changePhoneNumber(userId: string, newPhone: string, ctx: AuthContext): Promise<void> {
  const phone = newPhone.trim();

  const taken = await queryOne<{ id: string }>(
    `SELECT id FROM users WHERE phone = $1 AND deleted_at IS NULL AND id <> $2`,
    [phone, userId],
  );
  if (taken) throw conflict(ErrorCodes.PHONE_TAKEN, 'That phone number is already in use');

  await query(`UPDATE users SET phone = $2, phone_verified_at = NULL WHERE id = $1`, [userId, phone]);
  await logSecurityEvent({ userId, type: 'phone_changed', ip: ctx.ip, metadata: { phone } });
}

// ---------------------------------------------------------------------------
// Two-step verification (the app PIN)
// ---------------------------------------------------------------------------

export async function setTwoStepPin(input: {
  userId: string;
  password: string;
  pin: string;
  ctx: AuthContext;
}): Promise<{ backupCodes: string[] }> {
  const row = await queryOne<{ password_hash: string }>(
    `SELECT password_hash FROM users WHERE id = $1`,
    [input.userId],
  );
  if (!row) throw notFound(ErrorCodes.USER_NOT_FOUND, 'Account not found');
  if (!(await verifyPassword(input.password, row.password_hash))) {
    throw unauthorized(ErrorCodes.INVALID_CREDENTIALS, 'Password is incorrect');
  }

  const pinHash = await hashPin(input.pin);

  // Ten single-use backup codes, because a forgotten PIN must not mean a
  // permanently locked account.
  const codes: string[] = [];
  const hashes: string[] = [];
  for (let i = 0; i < 10; i += 1) {
    const code = randomToken(5).replace(/[^a-zA-Z0-9]/g, '').slice(0, 8).toUpperCase();
    codes.push(code);
    hashes.push(await hashPassword(`backup:${code}`));
  }

  await withTransaction(async (tx) => {
    await tx.query(
      `UPDATE users SET two_step_enabled = true, two_step_pin_hash = $2, two_step_pin_set_at = now() WHERE id = $1`,
      [input.userId, pinHash],
    );
    await tx.query(`DELETE FROM auth_two_step_backup_codes WHERE user_id = $1`, [input.userId]);
    for (const hash of hashes) {
      await tx.query(`INSERT INTO auth_two_step_backup_codes (user_id, code_hash) VALUES ($1, $2)`, [
        input.userId,
        hash,
      ]);
    }
  });

  await logSecurityEvent({ userId: input.userId, type: 'two_step_enabled', ip: input.ctx.ip });
  return { backupCodes: codes };
}

export async function disableTwoStep(input: {
  userId: string;
  password: string;
  ctx: AuthContext;
}): Promise<void> {
  const row = await queryOne<{ password_hash: string }>(
    `SELECT password_hash FROM users WHERE id = $1`,
    [input.userId],
  );
  if (!row) throw notFound(ErrorCodes.USER_NOT_FOUND, 'Account not found');
  if (!(await verifyPassword(input.password, row.password_hash))) {
    throw unauthorized(ErrorCodes.INVALID_CREDENTIALS, 'Password is incorrect');
  }

  await withTransaction(async (tx) => {
    await tx.query(
      `UPDATE users SET two_step_enabled = false, two_step_pin_hash = NULL, two_step_pin_set_at = NULL WHERE id = $1`,
      [input.userId],
    );
    await tx.query(`DELETE FROM auth_two_step_backup_codes WHERE user_id = $1`, [input.userId]);
  });

  await logSecurityEvent({ userId: input.userId, type: 'two_step_disabled', ip: input.ctx.ip });
}

// ---------------------------------------------------------------------------
// Account deletion
// ---------------------------------------------------------------------------

/**
 * Soft-delete immediately, and schedule hard deletion.
 *
 * The delay exists so that an accidental or coerced deletion is recoverable,
 * and so that "account recovery" has something to recover.
 */
export async function requestAccountDeletion(userId: string, ctx: AuthContext): Promise<Date> {
  const scheduledFor = new Date(Date.now() + 30 * 86_400_000);

  await withTransaction(async (tx) => {
    await tx.query(
      `UPDATE users SET status = 'deactivated', deletion_requested_at = now(), deletion_scheduled_for = $2
        WHERE id = $1 AND deleted_at IS NULL`,
      [userId, scheduledFor],
    );
    await tx.query(
      `INSERT INTO data_requests (user_id, kind, status) VALUES ($1, 'delete', 'pending')`,
      [userId],
    );
    await tx.query(
      `UPDATE sessions SET revoked_at = now(), revoked_reason = 'account_deletion' WHERE user_id = $1 AND revoked_at IS NULL`,
      [userId],
    );
  });

  await logSecurityEvent({ userId, type: 'account_deletion_requested', ip: ctx.ip });
  return scheduledFor;
}

export async function cancelAccountDeletion(userId: string, ctx: AuthContext): Promise<void> {
  await withTransaction(async (tx) => {
    await tx.query(
      `UPDATE users SET status = 'active', deletion_requested_at = NULL, deletion_scheduled_for = NULL
        WHERE id = $1 AND deleted_at IS NULL`,
      [userId],
    );
    await tx.query(
      `UPDATE data_requests SET status = 'cancelled' WHERE user_id = $1 AND kind = 'delete' AND status = 'pending'`,
      [userId],
    );
  });
  await logSecurityEvent({ userId, type: 'account_deletion_cancelled', ip: ctx.ip });
}

// ---------------------------------------------------------------------------
// Read helpers
// ---------------------------------------------------------------------------

export async function getPublicUser(userId: string): Promise<PublicUser | null> {
  const row = await queryOne<{
    id: string; email: string | null; phone: string | null; username: string | null;
    full_name: string | null; status: string; is_business: boolean; is_verified: boolean;
    email_verified_at: Date | null; phone_verified_at: Date | null;
    two_step_enabled: boolean; created_at: Date;
  }>(
    `SELECT id, email, phone, username, full_name, status, is_business, is_verified,
            email_verified_at, phone_verified_at, two_step_enabled, created_at
       FROM users WHERE id = $1 AND deleted_at IS NULL`,
    [userId],
  );
  if (!row) return null;

  return {
    id: row.id,
    email: row.email,
    phone: row.phone,
    username: row.username,
    fullName: row.full_name,
    status: row.status,
    isBusiness: row.is_business,
    isVerified: row.is_verified,
    emailVerified: row.email_verified_at !== null,
    phoneVerified: row.phone_verified_at !== null,
    twoStepEnabled: row.two_step_enabled,
    createdAt: row.created_at,
  };
}

export async function setUsername(userId: string, username: string): Promise<void> {
  const normalized = username.trim().toLowerCase();
  const taken = await queryOne<{ id: string }>(
    `SELECT id FROM users WHERE lower(username) = $1 AND deleted_at IS NULL AND id <> $2`,
    [normalized, userId],
  );
  if (taken) throw conflict(ErrorCodes.USERNAME_TAKEN, 'That username is already taken');

  try {
    await query(`UPDATE users SET username = $2 WHERE id = $1 AND deleted_at IS NULL`, [userId, normalized]);
  } catch {
    throw conflict(ErrorCodes.USERNAME_TAKEN, 'That username is already taken');
  }
}
