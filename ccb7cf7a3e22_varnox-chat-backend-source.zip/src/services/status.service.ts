import { query, queryOne, withTransaction } from '../db/pool.js';
import { ErrorCodes, badRequest, forbidden, notFound } from '../lib/errors.js';

/**
 * Status — the stories feature: a post that disappears after 24 hours.
 *
 * The shape follows the tables that were already migrated:
 *
 *   statuses            one row per post, with an explicit expires_at
 *   status_attachments  the media on that post
 *   status_audience     include/exclude rows for "share with…"/"hide from…"
 *   status_views        who has seen it
 *   status_reactions    emoji left on it
 *
 * Two decisions worth stating, because they are the ones that surprise people:
 *
 * 1. **Who can see a status is a profile setting, not a per-post one.** The
 *    audience comes from `user_privacy_settings.status_visibility`, exactly as
 *    WhatsApp treats it, and it defaults to `contacts`. On a deployment where
 *    nobody has built a contact list yet, that default means a new user sees an
 *    empty Updates tab until somebody switches to 'everyone'. That is the
 *    setting behaving correctly rather than a bug, so the API exposes it and the
 *    app surfaces the control instead of quietly widening the default.
 *
 * 2. **Expiry is enforced on read, not by a job.** Every query filters on
 *    `expires_at > now()`, so a status stops being visible the moment it lapses
 *    even though the row is still there. Nothing depends on a scheduler running.
 */

export type StatusType = 'text' | 'image' | 'video' | 'gif' | 'voice';
export type StatusVisibility = 'everyone' | 'contacts' | 'contacts_except' | 'nobody';

export interface StatusAttachmentInput {
  kind: 'image' | 'video' | 'voice' | 'gif';
  mimeType: string;
  storageKey: string;
  publicUrl?: string;
  thumbnailUrl?: string;
  byteSize?: number;
  durationMs?: number;
  width?: number;
  height?: number;
}

export interface StatusAttachment {
  id: string;
  kind: string;
  mimeType: string;
  storageKey: string;
  publicUrl: string | null;
  thumbnailUrl: string | null;
  byteSize: number;
  durationMs: number | null;
  width: number | null;
  height: number | null;
}

export interface StatusItem {
  id: string;
  type: StatusType;
  body: string | null;
  caption: string | null;
  backgroundColor: string | null;
  createdAt: Date;
  expiresAt: Date;
  attachments: StatusAttachment[];
  /** Only present on your own statuses, and on the single-status read. */
  viewCount?: number;
  myReaction?: string | null;
}

export interface StatusGroup {
  user: { id: string; displayName: string | null; username: string | null; avatarUrl: string | null };
  statuses: StatusItem[];
  latestAt: Date;
  hasUnviewed: boolean;
}

/**
 * The visibility predicate, shared by every read so the feed, the single-status
 * read and the viewer list can never disagree about who may look.
 *
 * `$1` is the viewer, `s` is the statuses row.
 */
const VISIBLE_TO_VIEWER = `
      s.deleted_at IS NULL
      AND s.expires_at > now()
      AND s.user_id <> $1
      AND NOT EXISTS (
            SELECT 1 FROM user_blocks b
             WHERE (b.blocker_id = s.user_id AND b.blocked_id = $1)
                OR (b.blocker_id = $1 AND b.blocked_id = s.user_id)
          )
      -- An explicit include row restricts the post to that list.
      AND (
            NOT EXISTS (SELECT 1 FROM status_audience a WHERE a.status_id = s.id AND a.mode = 'include')
            OR EXISTS (SELECT 1 FROM status_audience a WHERE a.status_id = s.id AND a.user_id = $1 AND a.mode = 'include')
          )
      -- An exclude row always wins, whatever the profile setting says.
      AND NOT EXISTS (SELECT 1 FROM status_audience a WHERE a.status_id = s.id AND a.user_id = $1 AND a.mode = 'exclude')
      AND CASE COALESCE(author_privacy.status_visibility, 'contacts')
            WHEN 'everyone' THEN true
            WHEN 'nobody'   THEN false
            -- 'contacts' and 'contacts_except' both mean "my contacts"; the
            -- "except" half is the exclude rows already applied above.
            ELSE EXISTS (
                   SELECT 1 FROM contacts c
                    WHERE c.owner_id = s.user_id AND c.contact_user_id = $1
                 )
          END`;

function statusRowsToItems(rows: Record<string, unknown>[], attachments: Map<string, StatusAttachment[]>, viewCounts: Map<string, number>, reactions: Map<string, string | null>): StatusItem[] {
  return rows.map((row) => {
    const id = row.id as string;
    const item: StatusItem = {
      id,
      type: row.type as StatusType,
      body: (row.body as string | null) ?? null,
      caption: (row.caption as string | null) ?? null,
      backgroundColor: (row.background_color as string | null) ?? null,
      createdAt: row.created_at as Date,
      expiresAt: row.expires_at as Date,
      attachments: attachments.get(id) ?? [],
    };
    if (viewCounts.has(id)) item.viewCount = viewCounts.get(id);
    if (reactions.has(id)) item.myReaction = reactions.get(id) ?? null;
    return item;
  });
}

async function attachmentsFor(statusIds: string[]): Promise<Map<string, StatusAttachment[]>> {
  const byStatus = new Map<string, StatusAttachment[]>();
  if (statusIds.length === 0) return byStatus;

  const { rows } = await query(
    `SELECT id, status_id, kind, mime_type, storage_key, public_url, thumbnail_url,
            byte_size, duration_ms, width, height
       FROM status_attachments
      WHERE status_id = ANY($1::uuid[])`,
    [statusIds],
  );

  for (const row of rows) {
    const list = byStatus.get(row.status_id as string) ?? [];
    list.push({
      id: row.id as string,
      kind: row.kind as string,
      mimeType: row.mime_type as string,
      storageKey: row.storage_key as string,
      publicUrl: (row.public_url as string | null) ?? null,
      thumbnailUrl: (row.thumbnail_url as string | null) ?? null,
      byteSize: Number(row.byte_size ?? 0),
      durationMs: (row.duration_ms as number | null) ?? null,
      width: (row.width as number | null) ?? null,
      height: (row.height as number | null) ?? null,
    });
    byStatus.set(row.status_id as string, list);
  }
  return byStatus;
}

// ---------------------------------------------------------------------------
// Visibility setting
// ---------------------------------------------------------------------------

export async function getStatusVisibility(userId: string): Promise<StatusVisibility> {
  const row = await queryOne<{ status_visibility: StatusVisibility }>(
    `SELECT status_visibility FROM user_privacy_settings WHERE user_id = $1`,
    [userId],
  );
  // No row yet means the table default applies.
  return row?.status_visibility ?? 'contacts';
}

export async function setStatusVisibility(userId: string, visibility: StatusVisibility): Promise<StatusVisibility> {
  await query(
    `INSERT INTO user_privacy_settings (user_id, status_visibility, updated_at)
          VALUES ($1, $2, now())
     ON CONFLICT (user_id)
     DO UPDATE SET status_visibility = EXCLUDED.status_visibility, updated_at = now()`,
    [userId, visibility],
  );
  return visibility;
}

// ---------------------------------------------------------------------------
// Create
// ---------------------------------------------------------------------------

export async function createStatus(input: {
  userId: string;
  type: StatusType;
  body?: string;
  caption?: string;
  backgroundColor?: string;
  attachments?: StatusAttachmentInput[];
}): Promise<StatusItem> {
  const attachments = input.attachments ?? [];

  if (input.type === 'text' && !input.body?.trim()) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'A text status needs some text');
  }
  if (input.type !== 'text' && attachments.length === 0) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, `A ${input.type} status needs an attachment`);
  }

  return withTransaction(async (tx) => {
    const inserted = await tx.query(
      `INSERT INTO statuses (user_id, type, body, caption, background_color)
            VALUES ($1, $2, $3, $4, $5)
         RETURNING id, type, body, caption, background_color, created_at, expires_at`,
      [input.userId, input.type, input.body?.trim() ?? null, input.caption?.trim() ?? null, input.backgroundColor ?? null],
    );
    const status = inserted.rows[0]!;

    // Rows are read back through RETURNING rather than a follow-up SELECT: the
    // inserts are still uncommitted, so a separate connection would not see
    // them and the response would come back with an empty attachment list even
    // though the rows were written.
    const saved: StatusAttachment[] = [];
    for (const attachment of attachments) {
      const row = await tx.query(
        `INSERT INTO status_attachments
               (status_id, kind, mime_type, storage_key, public_url, thumbnail_url, byte_size, duration_ms, width, height)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
         RETURNING id, kind, mime_type, storage_key, public_url, thumbnail_url, byte_size, duration_ms, width, height`,
        [
          status.id,
          attachment.kind,
          attachment.mimeType,
          attachment.storageKey,
          attachment.publicUrl ?? null,
          attachment.thumbnailUrl ?? null,
          attachment.byteSize ?? 0,
          attachment.durationMs ?? null,
          attachment.width ?? null,
          attachment.height ?? null,
        ],
      );
      const saved_row = row.rows[0]!;
      saved.push({
        id: saved_row.id as string,
        kind: saved_row.kind as string,
        mimeType: saved_row.mime_type as string,
        storageKey: saved_row.storage_key as string,
        publicUrl: (saved_row.public_url as string | null) ?? null,
        thumbnailUrl: (saved_row.thumbnail_url as string | null) ?? null,
        byteSize: Number(saved_row.byte_size ?? 0),
        durationMs: (saved_row.duration_ms as number | null) ?? null,
        width: (saved_row.width as number | null) ?? null,
        height: (saved_row.height as number | null) ?? null,
      });
    }

    return {
      id: status.id as string,
      type: status.type as StatusType,
      body: (status.body as string | null) ?? null,
      caption: (status.caption as string | null) ?? null,
      backgroundColor: (status.background_color as string | null) ?? null,
      createdAt: status.created_at as Date,
      expiresAt: status.expires_at as Date,
      attachments: saved,
    };
  });
}

// ---------------------------------------------------------------------------
// Read
// ---------------------------------------------------------------------------

export async function listMyStatuses(userId: string): Promise<StatusItem[]> {
  const { rows } = await query(
    `SELECT id, type, body, caption, background_color, created_at, expires_at
       FROM statuses
      WHERE user_id = $1 AND deleted_at IS NULL AND expires_at > now()
      ORDER BY created_at ASC`,
    [userId],
  );
  if (rows.length === 0) return [];

  const ids = rows.map((row) => row.id as string);
  const [attachments, counts] = await Promise.all([
    attachmentsFor(ids),
    query(`SELECT status_id, count(*)::int AS n FROM status_views WHERE status_id = ANY($1::uuid[]) GROUP BY status_id`, [ids]),
  ]);

  const viewCounts = new Map(counts.rows.map((row) => [row.status_id as string, Number(row.n ?? 0)]));
  return statusRowsToItems(rows, attachments, viewCounts, new Map());
}

/**
 * Everyone else's statuses, newest first, grouped by the person who posted.
 *
 * Grouping here rather than in SQL because a person can have several live
 * statuses and the viewer shows them as one continuous run, which is how every
 * stories interface behaves.
 */
export async function listStatusFeed(userId: string, limit = 60): Promise<StatusGroup[]> {
  const { rows } = await query(
    `SELECT s.id, s.user_id, s.type, s.body, s.caption, s.background_color, s.created_at, s.expires_at,
            p.display_name, p.avatar_url, u.username,
            EXISTS (SELECT 1 FROM status_views v WHERE v.status_id = s.id AND v.viewer_id = $1) AS viewed
       FROM statuses s
       JOIN users u ON u.id = s.user_id
       LEFT JOIN user_profiles p ON p.user_id = s.user_id
       LEFT JOIN user_privacy_settings author_privacy ON author_privacy.user_id = s.user_id
      WHERE ${VISIBLE_TO_VIEWER}
      ORDER BY s.created_at DESC
      LIMIT $2`,
    [userId, limit],
  );
  if (rows.length === 0) return [];

  const attachments = await attachmentsFor(rows.map((row) => row.id as string));

  const groups = new Map<string, StatusGroup>();
  for (const row of rows) {
    const authorId = row.user_id as string;
    let group = groups.get(authorId);
    if (!group) {
      group = {
        user: {
          id: authorId,
          displayName: (row.display_name as string | null) ?? null,
          username: (row.username as string | null) ?? null,
          avatarUrl: (row.avatar_url as string | null) ?? null,
        },
        statuses: [],
        latestAt: row.created_at as Date,
        hasUnviewed: false,
      };
      groups.set(authorId, group);
    }
    group.statuses.push({
      id: row.id as string,
      type: row.type as StatusType,
      body: (row.body as string | null) ?? null,
      caption: (row.caption as string | null) ?? null,
      backgroundColor: (row.background_color as string | null) ?? null,
      createdAt: row.created_at as Date,
      expiresAt: row.expires_at as Date,
      attachments: attachments.get(row.id as string) ?? [],
    });
    if (!row.viewed) group.hasUnviewed = true;
  }

  // Within a run of stories, oldest first reads more naturally; the groups
  // themselves stay ordered by the newest post.
  for (const group of groups.values()) {
    group.statuses.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  return [...groups.values()];
}

export async function getStatusForViewer(userId: string, statusId: string): Promise<StatusItem> {
  const row = await queryOne(
    `SELECT s.id, s.user_id, s.type, s.body, s.caption, s.background_color, s.created_at, s.expires_at
       FROM statuses s
       LEFT JOIN user_privacy_settings author_privacy ON author_privacy.user_id = s.user_id
      WHERE s.id = $2 AND ${VISIBLE_TO_VIEWER}`,
    [userId, statusId],
  );
  if (!row) throw notFound(ErrorCodes.USER_NOT_FOUND, 'That status is no longer available');

  const attachments = await attachmentsFor([statusId]);
  return {
    id: row.id as string,
    type: row.type as StatusType,
    body: (row.body as string | null) ?? null,
    caption: (row.caption as string | null) ?? null,
    backgroundColor: (row.background_color as string | null) ?? null,
    createdAt: row.created_at as Date,
    expiresAt: row.expires_at as Date,
    attachments: attachments.get(statusId) ?? [],
  };
}

export async function markStatusViewed(userId: string, statusId: string): Promise<void> {
  const owner = await queryOne<{ user_id: string }>(`SELECT user_id FROM statuses WHERE id = $1`, [statusId]);
  if (!owner) throw notFound(ErrorCodes.USER_NOT_FOUND, 'That status is no longer available');

  // The author is not a viewer of their own status; recording it would inflate
  // the count they are shown.
  if (owner.user_id === userId) return;

  await query(
    `INSERT INTO status_views (status_id, viewer_id) VALUES ($1, $2)
     ON CONFLICT (status_id, viewer_id) DO NOTHING`,
    [statusId, userId],
  );
}

export async function listStatusViewers(userId: string, statusId: string): Promise<Array<{ id: string; displayName: string | null; username: string | null; avatarUrl: string | null; viewedAt: Date }>> {
  const owner = await queryOne<{ user_id: string }>(`SELECT user_id FROM statuses WHERE id = $1`, [statusId]);
  if (!owner) throw notFound(ErrorCodes.USER_NOT_FOUND, 'That status is no longer available');
  if (owner.user_id !== userId) {
    throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Only the author can see who viewed a status');
  }

  const { rows } = await query(
    `SELECT v.viewer_id, v.viewed_at, p.display_name, p.avatar_url, u.username
       FROM status_views v
       JOIN users u ON u.id = v.viewer_id
       LEFT JOIN user_profiles p ON p.user_id = v.viewer_id
      WHERE v.status_id = $1
      ORDER BY v.viewed_at DESC`,
    [statusId],
  );

  return rows.map((row) => ({
    id: row.viewer_id as string,
    displayName: (row.display_name as string | null) ?? null,
    username: (row.username as string | null) ?? null,
    avatarUrl: (row.avatar_url as string | null) ?? null,
    viewedAt: row.viewed_at as Date,
  }));
}

// ---------------------------------------------------------------------------
// Mutate
// ---------------------------------------------------------------------------

export async function deleteStatus(userId: string, statusId: string): Promise<void> {
  const status = await queryOne<{ user_id: string }>(
    `SELECT user_id FROM statuses WHERE id = $1 AND deleted_at IS NULL`,
    [statusId],
  );
  if (!status) throw notFound(ErrorCodes.USER_NOT_FOUND, 'That status is no longer available');
  if (status.user_id !== userId) {
    throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Only the author can delete a status');
  }

  // Soft delete, so the row survives for the audit trail; every read filters it.
  await query(`UPDATE statuses SET deleted_at = now() WHERE id = $1`, [statusId]);
}

export async function reactToStatus(userId: string, statusId: string, emoji: string): Promise<void> {
  const row = await queryOne(
    `SELECT s.id FROM statuses s
       LEFT JOIN user_privacy_settings author_privacy ON author_privacy.user_id = s.user_id
      WHERE s.id = $2 AND ${VISIBLE_TO_VIEWER}`,
    [userId, statusId],
  );
  if (!row) throw notFound(ErrorCodes.USER_NOT_FOUND, 'That status is no longer available');

  const trimmed = emoji.trim();
  if (!trimmed || trimmed.length > 16) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'Send a single emoji');
  }

  // One reaction per person per status: replacing is friendlier than stacking,
  // and matches how every chat app treats a reaction on a story.
  await withTransaction(async (tx) => {
    await tx.query(`DELETE FROM status_reactions WHERE status_id = $1 AND user_id = $2`, [statusId, userId]);
    await tx.query(`INSERT INTO status_reactions (status_id, user_id, emoji) VALUES ($1, $2, $3)`, [statusId, userId, trimmed]);
  });
}

export async function listStatusReactions(statusId: string): Promise<Array<{ emoji: string; count: number }>> {
  const { rows } = await query(
    `SELECT emoji, count(*)::int AS n FROM status_reactions WHERE status_id = $1 GROUP BY emoji ORDER BY n DESC`,
    [statusId],
  );
  return rows.map((row) => ({ emoji: row.emoji as string, count: Number(row.n ?? 0) }));
}
