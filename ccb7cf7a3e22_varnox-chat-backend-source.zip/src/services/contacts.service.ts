import { query, queryOne } from '../db/pool.js';
import { ErrorCodes, badRequest, conflict, notFound } from '../lib/errors.js';
import { logAudit } from './audit.service.js';

/**
 * Contacts, labels, blocking and reporting.
 *
 * Blocking is enforced in two directions by the read paths that matter:
 *   - the blocker must not receive messages or calls from the blocked user
 *   - neither party should be able to discover the other via search
 * Rather than duplicate the check everywhere, `assertNotBlocked` is the single
 * gate used by messaging and calls, and search filters in SQL.
 */

export async function listContacts(ownerId: string, opts: { favoritesOnly?: boolean; labelId?: string } = {}) {
  const res = await query(
    `SELECT c.id, c.contact_user_id, c.phone, c.email, c.display_name, c.is_favorite,
            c.source, c.label_id, cl.name AS label_name, cl.color AS label_color,
            u.username, u.is_verified, u.is_business, u.last_seen_at,
            p.display_name AS profile_name, p.avatar_url
       FROM contacts c
       LEFT JOIN contact_labels cl ON cl.id = c.label_id
       LEFT JOIN users u ON u.id = c.contact_user_id AND u.deleted_at IS NULL
       LEFT JOIN user_profiles p ON p.user_id = u.id
      WHERE c.owner_id = $1
        AND ($2::boolean IS NOT TRUE OR c.is_favorite)
        AND ($3::uuid IS NULL OR c.label_id = $3::uuid)
      ORDER BY COALESCE(c.display_name, p.display_name, u.username, c.phone) NULLS LAST`,
    [ownerId, opts.favoritesOnly ?? false, opts.labelId ?? null],
  );
  return res.rows;
}

export async function addContact(input: {
  ownerId: string;
  contactUserId?: string;
  phone?: string;
  email?: string;
  displayName?: string;
  labelId?: string;
  source?: 'manual' | 'synced' | 'qr' | 'suggested' | 'imported';
}) {
  if (!input.contactUserId && !input.phone && !input.email) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'Provide a user, phone number or email address');
  }
  if (input.contactUserId === input.ownerId) {
    throw badRequest(ErrorCodes.VALIDATION_FAILED, 'You cannot add yourself as a contact');
  }

  // Adding someone who blocked you would be a way to probe for their existence,
  // so treat it the same as "not found".
  if (input.contactUserId) {
    const blocked = await queryOne<{ exists: boolean }>(
      `SELECT EXISTS (SELECT 1 FROM user_blocks WHERE blocker_id = $1 AND blocked_id = $2) AS exists`,
      [input.contactUserId, input.ownerId],
    );
    if (blocked?.exists) throw notFound(ErrorCodes.USER_NOT_FOUND, 'User not found');
  }

  const existing = await queryOne<{ id: string }>(
    `SELECT id FROM contacts
      WHERE owner_id = $1
        AND (($2::uuid IS NOT NULL AND contact_user_id = $2::uuid)
          OR ($3::text IS NOT NULL AND lower(email) = lower($3::text))
          OR ($4::text IS NOT NULL AND phone = $4::text))
      LIMIT 1`,
    [input.ownerId, input.contactUserId ?? null, input.email ?? null, input.phone ?? null],
  );
  if (existing) throw conflict(ErrorCodes.CONFLICT, 'That contact already exists');

  const res = await query<{ id: string }>(
    `INSERT INTO contacts (owner_id, contact_user_id, phone, email, display_name, label_id, source)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING id`,
    [
      input.ownerId,
      input.contactUserId ?? null,
      input.phone ?? null,
      input.email ?? null,
      input.displayName ?? null,
      input.labelId ?? null,
      input.source ?? 'manual',
    ],
  );
  return { id: res.rows[0]!.id };
}

export async function updateContact(
  ownerId: string,
  contactId: string,
  patch: { displayName?: string; labelId?: string | null; isFavorite?: boolean },
): Promise<void> {
  const values: unknown[] = [contactId, ownerId];
  const fields: string[] = [];
  const push = (column: string, value: unknown) => {
    values.push(value);
    fields.push(`${column} = $${values.length}`);
  };

  if (patch.displayName !== undefined) push('display_name', patch.displayName);
  if (patch.labelId !== undefined) push('label_id', patch.labelId);
  if (patch.isFavorite !== undefined) push('is_favorite', patch.isFavorite);
  if (fields.length === 0) return;

  const res = await query(
    `UPDATE contacts SET ${fields.join(', ')}, updated_at = now()
      WHERE id = $1 AND owner_id = $2`,
    values,
  );
  if (res.rowCount === 0) throw notFound('not_found', 'Contact not found');
}

export async function removeContact(ownerId: string, contactId: string): Promise<void> {
  const res = await query(`DELETE FROM contacts WHERE id = $1 AND owner_id = $2`, [contactId, ownerId]);
  if (res.rowCount === 0) throw notFound('not_found', 'Contact not found');
}

// ---------------------------------------------------------------------------
// Labels
// ---------------------------------------------------------------------------

export async function listLabels(ownerId: string) {
  const res = await query(
    `SELECT cl.id, cl.name, cl.color, count(c.id)::int AS contact_count
       FROM contact_labels cl
       LEFT JOIN contacts c ON c.label_id = cl.id
      WHERE cl.owner_id = $1
      GROUP BY cl.id
      ORDER BY cl.name`,
    [ownerId],
  );
  return res.rows;
}

export async function createLabel(ownerId: string, name: string, color = '#888888') {
  try {
    const res = await query<{ id: string }>(
      `INSERT INTO contact_labels (owner_id, name, color) VALUES ($1, $2, $3) RETURNING id`,
      [ownerId, name.trim(), color],
    );
    return { id: res.rows[0]!.id };
  } catch {
    throw conflict(ErrorCodes.CONFLICT, 'A label with that name already exists');
  }
}

export async function deleteLabel(ownerId: string, labelId: string): Promise<void> {
  const res = await query(`DELETE FROM contact_labels WHERE id = $1 AND owner_id = $2`, [labelId, ownerId]);
  if (res.rowCount === 0) throw notFound('not_found', 'Label not found');
}

// ---------------------------------------------------------------------------
// Blocking
// ---------------------------------------------------------------------------

export async function blockUser(blockerId: string, blockedId: string, reason?: string): Promise<void> {
  if (blockerId === blockedId) throw badRequest(ErrorCodes.VALIDATION_FAILED, 'You cannot block yourself');

  await query(
    `INSERT INTO user_blocks (blocker_id, blocked_id, reason) VALUES ($1, $2, $3)
     ON CONFLICT (blocker_id, blocked_id) DO NOTHING`,
    [blockerId, blockedId, reason ?? null],
  );
  await logAudit({ actorId: blockerId, action: 'user.blocked', targetType: 'user', targetId: blockedId });
}

export async function unblockUser(blockerId: string, blockedId: string): Promise<void> {
  await query(`DELETE FROM user_blocks WHERE blocker_id = $1 AND blocked_id = $2`, [blockerId, blockedId]);
  await logAudit({ actorId: blockerId, action: 'user.unblocked', targetType: 'user', targetId: blockedId });
}

export async function listBlocked(blockerId: string) {
  const res = await query(
    `SELECT b.id, b.blocked_id, b.reason, b.created_at,
            u.username, p.display_name, p.avatar_url
       FROM user_blocks b
       JOIN users u ON u.id = b.blocked_id
       LEFT JOIN user_profiles p ON p.user_id = u.id
      WHERE b.blocker_id = $1
      ORDER BY b.created_at DESC`,
    [blockerId],
  );
  return res.rows;
}

/**
 * The single gate used by messaging and calling. Returns true when either
 * direction of the block exists, because a block is not symmetric in intent
 * but must be symmetric in effect for delivery.
 */
export async function isBlockedEitherWay(userA: string, userB: string): Promise<boolean> {
  const row = await queryOne<{ exists: boolean }>(
    `SELECT EXISTS (
       SELECT 1 FROM user_blocks
        WHERE (blocker_id = $1 AND blocked_id = $2)
           OR (blocker_id = $2 AND blocked_id = $1)
     ) AS exists`,
    [userA, userB],
  );
  return row?.exists ?? false;
}

// ---------------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------------

export async function createReport(input: {
  reporterId: string;
  targetType: 'user' | 'message' | 'group' | 'channel' | 'community' | 'status' | 'business';
  targetId: string;
  reason: string;
  details?: string;
}) {
  // Spam that is also abusive should surface above routine reports.
  const priority = ['scam', 'child_safety', 'violence'].includes(input.reason) ? 1 : 3;

  const res = await query<{ id: string }>(
    `INSERT INTO reports (reporter_id, target_type, target_id, reason, details, priority)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id`,
    [input.reporterId, input.targetType, input.targetId, input.reason, input.details ?? null, priority],
  );

  await logAudit({
    actorId: input.reporterId,
    action: 'report.created',
    targetType: input.targetType,
    targetId: input.targetId,
    metadata: { reason: input.reason },
  });

  return { id: res.rows[0]!.id };
}
