import { config } from '../config.js';
import { query, queryOne } from '../db/pool.js';
import { generateOtp, hashOtp, verifyOtpHash } from '../lib/crypto.js';
import { ErrorCodes, badRequest, tooManyRequests } from '../lib/errors.js';
import { sendOtpEmail } from '../lib/mailer.js';
import { consume, consumePersistent } from '../lib/rate-limit.js';

/**
 * Email OTP lifecycle.
 *
 * Per the product spec, verification codes are delivered to EMAIL only. The
 * phone number is collected as an identifier but is never independently
 * verified — so `channel` is fixed to 'email' here. Adding SMS later means
 * adding a provider call, not changing this contract.
 *
 * The rules implemented here, all of which the checklist calls for:
 *   - a 6-digit code
 *   - an expiry (default 10 minutes)
 *   - resend, with a cooldown so "resend" cannot be used as a spam cannon
 *   - a cap on incorrect attempts, after which the code is burned
 *   - a per-address hourly cap, independent of the cooldown
 *
 * Only the HMAC of the code is stored (see lib/crypto.ts), so a database leak
 * does not reveal live codes.
 */

export type OtpPurpose =
  | 'register' | 'login' | 'reset_password' | 'change_email'
  | 'change_phone' | 'verify_phone' | 'two_step' | 'delete_account';

export interface RequestOtpResult {
  sent: boolean;
  expiresAt: Date;
  /** Only populated by the console mail transport, to make local testing sane. */
  devCode?: string;
}

export async function requestOtp(params: {
  destination: string;
  purpose: OtpPurpose;
  userId?: string | null;
  ip?: string;
  /** Some flows resend on demand; registration does not. */
  enforceCooldown?: boolean;
}): Promise<RequestOtpResult> {
  const destination = params.destination.trim().toLowerCase();
  const enforceCooldown = params.enforceCooldown !== false;

  // --- Layer 1: cooldown between sends to the same address -----------------
  if (enforceCooldown) {
    const recent = await queryOne<{ seconds_since: number }>(
      `SELECT EXTRACT(EPOCH FROM (now() - created_at))::int AS seconds_since
         FROM auth_otp_codes
        WHERE lower(destination) = $1 AND purpose = $2
        ORDER BY created_at DESC
        LIMIT 1`,
      [destination, params.purpose],
    );

    if (recent && recent.seconds_since < config.OTP_RESEND_COOLDOWN_SECONDS) {
      const wait = config.OTP_RESEND_COOLDOWN_SECONDS - recent.seconds_since;
      throw tooManyRequests(
        ErrorCodes.OTP_RESEND_TOO_SOON,
        `Please wait ${wait} second${wait === 1 ? '' : 's'} before requesting another code`,
        { retryAfterSeconds: wait },
      );
    }
  }

  // --- Layer 2: hourly ceiling per address, and per IP ---------------------
  const addressCount = await consumePersistent('otp:address', destination, 3600);
  if (addressCount > config.OTP_MAX_PER_HOUR) {
    throw tooManyRequests(ErrorCodes.OTP_RATE_LIMITED, 'Too many codes requested for this address. Try again later.');
  }
  if (params.ip) {
    const ipLimit = consume(`otp:ip:${params.ip}`, config.OTP_MAX_PER_HOUR * 3, 3600);
    if (!ipLimit.allowed) {
      throw tooManyRequests(ErrorCodes.OTP_RATE_LIMITED, 'Too many codes requested. Try again later.');
    }
  }

  const code = generateOtp(config.OTP_LENGTH);
  const expiresAt = new Date(Date.now() + config.OTP_TTL_SECONDS * 1000);

  // Invalidate any outstanding code for this destination+purpose so that only
  // the newest code can be used. Leaving old codes live widens the guessing
  // window for no benefit.
  await query(
    `UPDATE auth_otp_codes
        SET consumed_at = now()
      WHERE lower(destination) = $1 AND purpose = $2 AND consumed_at IS NULL`,
    [destination, params.purpose],
  );

  await query(
    `INSERT INTO auth_otp_codes (user_id, destination, channel, purpose, code_hash, max_attempts, expires_at, request_ip)
     VALUES ($1, $2, 'email', $3, $4, $5, $6, $7)`,
    [
      params.userId ?? null,
      destination,
      params.purpose,
      hashOtp(code, destination, params.purpose),
      config.OTP_MAX_ATTEMPTS,
      expiresAt,
      params.ip ?? null,
    ],
  );

  await sendOtpEmail({
    to: destination,
    code,
    purpose: params.purpose,
    ttlSeconds: config.OTP_TTL_SECONDS,
  });

  return {
    sent: true,
    expiresAt,
    // Surfacing the code is a convenience of the console transport only; with
    // SMTP configured this is undefined and the code exists nowhere but the
    // recipient's inbox.
    devCode: config.MAIL_TRANSPORT === 'console' ? code : undefined,
  };
}

/**
 * Verify and consume a code. Throws on every failure mode with a specific code
 * so the client can distinguish "wrong digits" from "expired" from "you have
 * tried too many times".
 */
export async function verifyOtp(params: {
  destination: string;
  purpose: OtpPurpose;
  code: string;
}): Promise<{ userId: string | null }> {
  const destination = params.destination.trim().toLowerCase();

  const row = await queryOne<{
    id: string;
    user_id: string | null;
    code_hash: string;
    attempts: number;
    max_attempts: number;
    expires_at: Date;
    consumed_at: Date | null;
  }>(
    `SELECT id, user_id, code_hash, attempts, max_attempts, expires_at, consumed_at
       FROM auth_otp_codes
      WHERE lower(destination) = $1 AND purpose = $2 AND consumed_at IS NULL
      ORDER BY created_at DESC
      LIMIT 1`,
    [destination, params.purpose],
  );

  if (!row) {
    throw badRequest(ErrorCodes.OTP_INVALID, 'No active code was found. Request a new one.');
  }

  if (row.expires_at.getTime() <= Date.now()) {
    await query('UPDATE auth_otp_codes SET consumed_at = now() WHERE id = $1', [row.id]);
    throw badRequest(ErrorCodes.OTP_EXPIRED, 'That code has expired. Request a new one.');
  }

  if (row.attempts >= row.max_attempts) {
    await query('UPDATE auth_otp_codes SET consumed_at = now() WHERE id = $1', [row.id]);
    throw badRequest(
      ErrorCodes.OTP_ATTEMPTS_EXCEEDED,
      'Too many incorrect attempts. Request a new code.',
    );
  }

  // The attempt counter is incremented even on success paths that follow, so
  // it must happen before the comparison.
  const matches = verifyOtpHash(params.code, destination, params.purpose, row.code_hash);

  if (!matches) {
    const updated = await query<{ attempts: number; max_attempts: number }>(
      `UPDATE auth_otp_codes
          SET attempts = attempts + 1,
              consumed_at = CASE WHEN attempts + 1 >= max_attempts THEN now() ELSE consumed_at END
        WHERE id = $1
        RETURNING attempts, max_attempts`,
      [row.id],
    );
    const attempts = updated.rows[0]?.attempts ?? row.attempts + 1;
    const remaining = Math.max(0, row.max_attempts - attempts);

    throw badRequest(
      remaining === 0 ? ErrorCodes.OTP_ATTEMPTS_EXCEEDED : ErrorCodes.OTP_INVALID,
      remaining === 0
        ? 'Too many incorrect attempts. Request a new code.'
        : `Incorrect code. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining.`,
      { attemptsRemaining: remaining },
    );
  }

  await query('UPDATE auth_otp_codes SET consumed_at = now() WHERE id = $1', [row.id]);
  return { userId: row.user_id };
}

/** Housekeeping for expired codes; safe to run on a schedule. */
export async function pruneExpiredOtps(): Promise<number> {
  const res = await query(`DELETE FROM auth_otp_codes WHERE expires_at < now() - interval '1 day'`);
  return res.rowCount ?? 0;
}
