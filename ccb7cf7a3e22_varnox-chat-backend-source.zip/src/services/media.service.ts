import { createHash, randomUUID } from 'node:crypto';
import { mkdir, writeFile } from 'node:fs/promises';
import { extname, join, resolve } from 'node:path';
import { config } from '../config.js';
import { ErrorCodes, badRequest } from '../lib/errors.js';

/**
 * Attachment storage.
 *
 * Two drivers, one interface. `local` writes to disk and is what you want on a
 * VPS or a container with a mounted volume. `s3` covers Cloudflare R2, Backblaze
 * B2, MinIO and AWS S3 — anything with an S3-compatible API — and is what you
 * want once a single server's disk is a liability.
 *
 * NEON NOTE: Neon is a database, not object storage. Media does NOT belong in
 * Postgres (bytea columns destroy your backup and query performance), so the
 * bytes go here and only the key/metadata goes in the attachments table.
 */

export interface StoredFile {
  storageDriver: string;
  storageKey: string;
  publicUrl: string | null;
  byteSize: number;
  sha256: string;
}

/** Guards against a filename like ../../etc/passwd or a Windows drive path. */
function sanitiseExtension(fileName: string | undefined, mimeType: string): string {
  const fromName = fileName ? extname(fileName).toLowerCase().replace(/[^a-z0-9.]/g, '') : '';
  if (fromName && fromName.length <= 10) return fromName;

  const fromMime = mimeType.split('/')[1]?.toLowerCase().replace(/[^a-z0-9]/g, '');
  return fromMime ? `.${fromMime}` : '.bin';
}

/**
 * Keys are derived from the content hash, which gives us two properties for
 * free: identical files uploaded twice occupy one blob, and the key is stable
 * so a retried upload cannot orphan a partial file under a random name.
 */
function buildKey(params: { userId: string; sha256: string; ext: string }): string {
  const now = new Date();
  const prefix = `${now.getUTCFullYear()}/${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
  return `${params.userId}/${prefix}/${params.sha256.slice(0, 32)}${params.ext}`;
}

export async function storeBuffer(params: {
  buffer: Buffer;
  mimeType: string;
  fileName?: string;
  userId: string;
}): Promise<StoredFile> {
  if (params.buffer.byteLength === 0) {
    throw badRequest(ErrorCodes.UNSUPPORTED_MEDIA, 'The uploaded file is empty');
  }
  if (params.buffer.byteLength > config.MEDIA_MAX_UPLOAD_BYTES) {
    throw badRequest(
      ErrorCodes.FILE_TOO_LARGE,
      `Files must be smaller than ${Math.round(config.MEDIA_MAX_UPLOAD_BYTES / 1_048_576)} MB`,
    );
  }

  const sha256 = createHash('sha256').update(params.buffer).digest('hex');
  const ext = sanitiseExtension(params.fileName, params.mimeType);
  const storageKey = buildKey({ userId: params.userId, sha256, ext });

  if (config.MEDIA_DRIVER === 'local') {
    const root = resolve(config.MEDIA_LOCAL_DIR);
    const target = resolve(join(root, storageKey));
    // Belt-and-braces against path traversal: the resolved path must stay
    // inside the configured root even if sanitisation were bypassed.
    if (!target.startsWith(root)) {
      throw badRequest(ErrorCodes.VALIDATION_FAILED, 'Invalid storage path');
    }
    await mkdir(resolve(target, '..'), { recursive: true });
    await writeFile(target, params.buffer);

    return {
      storageDriver: 'local',
      storageKey,
      publicUrl: `${config.MEDIA_PUBLIC_BASE_URL.replace(/\/$/, '')}/${storageKey}`,
      byteSize: params.buffer.byteLength,
      sha256,
    };
  }

  // --- S3-compatible driver ------------------------------------------------
  // Deliberately minimal: a signed PUT built on fetch, so the project does not
  // carry the AWS SDK for one operation. If you need multipart uploads for
  // large video files, add @aws-sdk/client-s3 here instead of extending this.
  if (!config.S3_BUCKET || !config.S3_ENDPOINT) {
    throw badRequest(
      ErrorCodes.INTERNAL,
      'MEDIA_DRIVER=s3 requires S3_BUCKET, S3_ENDPOINT, S3_REGION and credentials to be configured',
    );
  }

  const { signS3Put } = await import('../lib/s3.js');
  const url = await signS3Put({ key: storageKey, mimeType: params.mimeType, body: params.buffer });

  const res = await fetch(url, {
    method: 'PUT',
    headers: { 'Content-Type': params.mimeType, 'Content-Length': String(params.buffer.byteLength) },
    body: new Uint8Array(params.buffer),
  });
  if (!res.ok) {
    throw badRequest(ErrorCodes.INTERNAL, `Object storage rejected the upload (${res.status})`);
  }

  return {
    storageDriver: 's3',
    storageKey,
    publicUrl: `${config.S3_ENDPOINT.replace(/\/$/, '')}/${config.S3_BUCKET}/${storageKey}`,
    byteSize: params.buffer.byteLength,
    sha256,
  };
}

/**
 * Decide the attachment kind from the MIME type. Used to reject a file that
 * claims one type and is another — the client's `kind` field is a hint, not
 * something to be trusted for storage decisions.
 */
export function inferKind(mimeType: string): 'image' | 'video' | 'audio' | 'voice' | 'document' | 'sticker' | 'gif' {
  if (mimeType === 'image/gif') return 'gif';
  if (mimeType === 'image/webp') return 'sticker';
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  return 'document';
}

export const ALLOWED_MIME_PREFIXES = ['image/', 'video/', 'audio/'];

export const ALLOWED_DOCUMENT_MIME = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/zip',
  'application/x-zip-compressed',
  'text/plain',
  'text/csv',
  'application/json',
];

export function isAllowedMimeType(mimeType: string): boolean {
  return (
    ALLOWED_MIME_PREFIXES.some((prefix) => mimeType.startsWith(prefix)) ||
    ALLOWED_DOCUMENT_MIME.includes(mimeType)
  );
}

export function newUploadId(): string {
  return randomUUID();
}
