import { acquireTransactionLock, query, queryOne, withTransaction, type Tx } from '../db/pool.js';
import { directChatKey, hashToken, randomToken, shortCode } from '../lib/crypto.js';
import { ErrorCodes, badRequest, conflict, forbidden, notFound } from '../lib/errors.js';
import { isBlockedEitherWay } from './contacts.service.js';

/**
 * Conversations: creation, membership, permissions and per-user state.
 *
 * Two invariants this file exists to protect:
 *
 *  1. There is at most ONE direct chat per pair of users. Enforced by taking a
 *     transaction-scoped advisory lock on a deterministic pair key, so two
 *     simultaneous "open a chat with Bob" requests cannot both insert.
 *     (A session-scoped advisory lock would NOT work here — Neon's pooler
 *     returns the connection after the transaction, silently dropping it.)
 *
 *  2. Every mutating operation re-checks membership and role inside the same
 *     transaction. Checking in the route handler and acting later is a
 *     time-of-check/time-of-use hole: a user removed mid-request could still
 *     complete the write.
 */

export type ChatRole = 'member' | 'admin' | 'owner';

export interface MemberContext {
  chatId: string;
  userId: string;
  role: ChatRole;
  /** Needed to make the group-permission rules a no-op in direct chats. */
  chatType: string;
  isAnnouncement: boolean;
  whoCanSend: string;
  whoCanEditInfo: string;
  whoCanAddMembers: string;
  whoCanPin: string;
  mutedUntil: Date | null;
}

/**
 * Load the caller's membership, or throw. The single entry point for access
 * control. Pass the surrounding transaction when calling from inside one, so
 * the permission check sees the same snapshot as the write it guards.
 */
export async function requireMembership(chatId: string, userId: string, tx?: Tx): Promise<MemberContext> {
  const sql = `SELECT cm.role, cm.muted_until, c.type, c.is_announcement,
                      c.who_can_send, c.who_can_edit_info, c.who_can_add_members, c.who_can_pin, c.deleted_at
                 FROM chat_members cm
                 JOIN chats c ON c.id = cm.chat_id
                WHERE cm.chat_id = $1 AND cm.user_id = $2
                  AND cm.left_at IS NULL AND cm.status = 'active'`;
  const res = tx
    ? await tx.query(sql, [chatId, userId])
    : await query(sql, [chatId, userId]);

  const row = (res.rows as Record<string, unknown>[])[0];
  if (!row) throw forbidden(ErrorCodes.NOT_A_MEMBER, 'You are not a member of this conversation');
  if (row.deleted_at) throw notFound(ErrorCodes.CHAT_NOT_FOUND, 'Conversation not found');

  return {
    chatId,
    userId,
    role: row.role as ChatRole,
    chatType: String(row.type),
    isAnnouncement: Boolean(row.is_announcement),
    whoCanSend: String(row.who_can_send),
    whoCanEditInfo: String(row.who_can_edit_info),
    whoCanAddMembers: String(row.who_can_add_members),
    whoCanPin: String(row.who_can_pin),
    mutedUntil: (row.muted_until as Date | null) ?? null,
  };
}

export function assertCanSend(ctx: MemberContext): void {
  // A direct chat has no admins, so applying an admin-only rule there would
  // lock out both participants permanently and unrecoverably. These policies
  // only mean anything in groups, channels and communities.
  if (ctx.chatType === 'direct') return;

  if (ctx.role === 'member' && (ctx.whoCanSend === 'admins' || ctx.isAnnouncement)) {
    throw forbidden(ErrorCodes.CANNOT_SEND, 'Only admins can send messages in this conversation');
  }
}

export function assertAdmin(ctx: MemberContext, message = 'Only admins can do that'): void {
  if (ctx.role !== 'admin' && ctx.role !== 'owner') {
    throw forbidden(ErrorCodes.FORBIDDEN_ACTION, message);
  }
}

// ---------------------------------------------------------------------------
// Direct chats
// ---------------------------------------------------------------------------

export async function getOrCreateDirectChat(userId: string, peerId: string): Promise<{ chatId: string; created: boolean }> {
  if (userId === peerId) throw badRequest(ErrorCodes.VALIDATION_FAILED, 'Cannot start a conversation with yourself');

  // Same membership rule as the people directory: anyone who is not removed
  // counts as a user, including a registration that has not verified its email
  // yet. If the directory lists someone, tapping them has to work — otherwise a
  // visible row is a dead end.
  const peer = await queryOne<{ id: string }>(
    `SELECT id FROM users
      WHERE id = $1 AND deleted_at IS NULL
        AND status NOT IN ('suspended', 'deactivated', 'deleted')`,
    [peerId],
  );
  if (!peer) throw notFound(ErrorCodes.USER_NOT_FOUND, 'User not found');

  if (await isBlockedEitherWay(userId, peerId)) {
    throw forbidden(ErrorCodes.BLOCKED, 'You cannot message this user');
  }

  const key = directChatKey(userId, peerId);

  return withTransaction(async (tx) => {
    // Serialise concurrent creation for this exact pair.
    await acquireTransactionLock(tx, key);

    const existing = await tx.query<{ id: string }>(
      `SELECT c.id
         FROM chats c
         JOIN chat_members a ON a.chat_id = c.id AND a.user_id = $1
         JOIN chat_members b ON b.chat_id = c.id AND b.user_id = $2
        WHERE c.type = 'direct' AND c.deleted_at IS NULL
        LIMIT 1`,
      [userId, peerId],
    );
    if (existing.rows[0]) return { chatId: existing.rows[0].id, created: false };

    const chat = await tx.query<{ id: string }>(
      `INSERT INTO chats (type, created_by, member_count) VALUES ('direct', $1, 2) RETURNING id`,
      [userId],
    );
    const chatId = chat.rows[0]!.id;

    await tx.query(
      `INSERT INTO chat_members (chat_id, user_id, role) VALUES ($1, $2, 'member'), ($1, $3, 'member')`,
      [chatId, userId, peerId],
    );

    return { chatId, created: true };
  });
}

// ---------------------------------------------------------------------------
// Groups
// ---------------------------------------------------------------------------

export async function createGroup(input: {
  creatorId: string;
  title: string;
  description?: string;
  memberIds?: string[];
  photoUrl?: string;
}): Promise<{ chatId: string }> {
  const memberIds = [...new Set(input.memberIds ?? [])].filter((id) => id !== input.creatorId);

  // Default-deny: anyone who blocked the creator, or whom the creator blocked,
  // is silently dropped rather than failing the whole group creation.
  const blocked = memberIds.length
    ? (
        await query<{ id: string }>(
          `SELECT u.id FROM unnest($2::uuid[]) AS u(id)
            WHERE EXISTS (
              SELECT 1 FROM user_blocks b
               WHERE (b.blocker_id = u.id AND b.blocked_id = $1)
                  OR (b.blocker_id = $1 AND b.blocked_id = u.id)
            )`,
          [input.creatorId, memberIds],
        )
      ).rows.map((r) => r.id)
    : [];
  const allowed = memberIds.filter((id) => !blocked.includes(id));

  return withTransaction(async (tx) => {
    const chat = await tx.query<{ id: string }>(
      `INSERT INTO chats (type, title, description, photo_url, created_by, member_count)
       VALUES ('group', $1, $2, $3, $4, $5)
       RETURNING id`,
      [input.title.trim(), input.description ?? null, input.photoUrl ?? null, input.creatorId, allowed.length + 1],
    );
    const chatId = chat.rows[0]!.id;

    await tx.query(
      `INSERT INTO chat_members (chat_id, user_id, role) VALUES ($1, $2, 'owner')`,
      [chatId, input.creatorId],
    );
    if (allowed.length > 0) {
      await tx.query(
        `INSERT INTO chat_members (chat_id, user_id, role, invited_by)
         SELECT $1, u, 'member', $2 FROM unnest($3::uuid[]) AS u`,
        [chatId, input.creatorId, allowed],
      );
    }
    // System message so the group has a visible origin.
    await tx.query(
      `INSERT INTO messages (chat_id, sender_id, type, body) VALUES ($1, $2, 'system', $3)`,
      [chatId, input.creatorId, `${input.title.trim()} was created`],
    );

    return { chatId };
  });
}

export async function addMembers(actorId: string, chatId: string, userIds: string[]): Promise<{ added: string[] }> {
  const unique = [...new Set(userIds)].filter((id) => id !== actorId);
  if (unique.length === 0) return { added: [] };

  return withTransaction(async (tx) => {
    const ctx = await requireMembership(chatId, actorId, tx);

    // A direct conversation is defined by having exactly two people; adding a
    // third would silently produce a broken "direct" chat that no longer has a
    // peer. Group creation is the correct operation for that intent.
    if (ctx.chatType === 'direct') {
      throw badRequest(ErrorCodes.VALIDATION_FAILED, 'Cannot add members to a direct conversation — create a group instead');
    }
    if (ctx.role === 'member' && ctx.whoCanAddMembers === 'admins') {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Only admins can add members');
    }

    // Respect the invitee's "who can add me to groups" privacy setting.
    const candidates = await tx.query<{ id: string }>(
      `SELECT u.id
         FROM unnest($2::uuid[]) AS u(id)
         JOIN users usr ON usr.id = u.id AND usr.deleted_at IS NULL
         LEFT JOIN user_privacy_settings ps ON ps.user_id = u.id
         LEFT JOIN contacts ct ON ct.owner_id = u.id AND ct.contact_user_id = $1
        WHERE COALESCE(ps.group_invite_policy, 'contacts') = 'everyone'
           OR (COALESCE(ps.group_invite_policy, 'contacts') = 'contacts' AND ct.id IS NOT NULL)`,
      [actorId, unique],
    );
    const addable = candidates.rows.map((r) => r.id);
    if (addable.length === 0) return { added: [] };

    const inserted = await tx.query<{ user_id: string }>(
      `INSERT INTO chat_members (chat_id, user_id, role, invited_by)
       SELECT $1, u, 'member', $2 FROM unnest($3::uuid[]) AS u
       ON CONFLICT (chat_id, user_id) DO UPDATE
         SET left_at = NULL, status = 'active', joined_at = now()
       RETURNING user_id`,
      [chatId, actorId, addable],
    );

    const added = inserted.rows.map((r) => r.user_id);
    await tx.query(`UPDATE chats SET member_count = member_count + $2 WHERE id = $1`, [chatId, added.length]);

    if (added.length > 0) {
      await tx.query(
        `INSERT INTO messages (chat_id, sender_id, type, body, metadata)
         VALUES ($1, $2, 'system', $3, $4)`,
        [chatId, actorId, `${added.length} member${added.length === 1 ? '' : 's'} added`, JSON.stringify({ added })],
      );
    }

    return { added };
  });
}

export async function removeMember(input: {
  actorId: string;
  chatId: string;
  userId: string;
  ban?: boolean;
  reason?: string;
}): Promise<void> {
  await withTransaction(async (tx) => {
    const ctx = await requireMembership(input.chatId, input.actorId, tx);
    const isSelf = input.actorId === input.userId;

    if (!isSelf) {
      assertAdmin(ctx, 'Only admins can remove members');
      const target = await tx.query<{ role: string }>(
        `SELECT role FROM chat_members WHERE chat_id = $1 AND user_id = $2`,
        [input.chatId, input.userId],
      );
      // An admin must not be able to remove the owner, or a group can be stolen.
      if (target.rows[0]?.role === 'owner') {
        throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'The group owner cannot be removed');
      }
    }

    await tx.query(
      `UPDATE chat_members
          SET left_at = now(), status = $3, removed_by = $4, removed_at = now(), ban_reason = $5
        WHERE chat_id = $1 AND user_id = $2`,
      [
        input.chatId,
        input.userId,
        input.ban ? 'banned' : isSelf ? 'left' : 'removed',
        isSelf ? null : input.actorId,
        input.reason ?? null,
      ],
    );
    await tx.query(`UPDATE chats SET member_count = GREATEST(0, member_count - 1) WHERE id = $1`, [input.chatId]);
  });
}

export async function setMemberRole(input: {
  actorId: string;
  chatId: string;
  userId: string;
  role: 'admin' | 'member';
}): Promise<void> {
  await withTransaction(async (tx) => {
    const ctx = await requireMembership(input.chatId, input.actorId, tx);
    // Only the owner may mint or demote admins; letting admins do it means any
    // admin can promote an accomplice and seize the group.
    if (ctx.role !== 'owner') throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Only the owner can change admin roles');

    await tx.query(`UPDATE chat_members SET role = $3 WHERE chat_id = $1 AND user_id = $2`, [
      input.chatId,
      input.userId,
      input.role,
    ]);
  });
}

export async function updateChat(
  actorId: string,
  chatId: string,
  patch: {
    title?: string;
    description?: string;
    photoUrl?: string;
    disappearingSeconds?: number;
    whoCanSend?: string;
    whoCanEditInfo?: string;
    whoCanAddMembers?: string;
    whoCanPin?: string;
  },
): Promise<void> {
  await withTransaction(async (tx) => {
    const ctx = await requireMembership(chatId, actorId, tx);

    const isInfoPatch =
      patch.title !== undefined || patch.description !== undefined || patch.photoUrl !== undefined;
    if (isInfoPatch && ctx.chatType !== 'direct' && ctx.role === 'member' && ctx.whoCanEditInfo === 'admins') {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Only admins can edit group information');
    }
    const isPolicyPatch =
      patch.whoCanSend !== undefined || patch.whoCanEditInfo !== undefined ||
      patch.whoCanAddMembers !== undefined || patch.whoCanPin !== undefined;
    if (isPolicyPatch) assertAdmin(ctx, 'Only admins can change group permissions');

    const values: unknown[] = [chatId];
    const fields: string[] = [];
    const push = (column: string, value: unknown) => {
      values.push(value);
      fields.push(`${column} = $${values.length}`);
    };

    if (patch.title !== undefined) push('title', patch.title.trim());
    if (patch.description !== undefined) push('description', patch.description);
    if (patch.photoUrl !== undefined) push('photo_url', patch.photoUrl);
    if (patch.disappearingSeconds !== undefined) {
      if (!Number.isInteger(patch.disappearingSeconds) || patch.disappearingSeconds < 0) {
        throw badRequest(ErrorCodes.VALIDATION_FAILED, 'disappearingSeconds must be a non-negative integer');
      }
      push('disappearing_seconds', patch.disappearingSeconds);
    }
    if (patch.whoCanSend !== undefined) push('who_can_send', patch.whoCanSend);
    if (patch.whoCanEditInfo !== undefined) push('who_can_edit_info', patch.whoCanEditInfo);
    if (patch.whoCanAddMembers !== undefined) push('who_can_add_members', patch.whoCanAddMembers);
    if (patch.whoCanPin !== undefined) push('who_can_pin', patch.whoCanPin);

    if (fields.length === 0) return;
    await tx.query(`UPDATE chats SET ${fields.join(', ')}, updated_at = now() WHERE id = $1`, values);

    if (patch.title !== undefined || patch.disappearingSeconds !== undefined) {
      await tx.query(
        `INSERT INTO messages (chat_id, sender_id, type, body, metadata)
         VALUES ($1, $2, 'system', $3, $4)`,
        [chatId, actorId, 'Group settings were updated', JSON.stringify({ patch })],
      );
    }
  });
}

// ---------------------------------------------------------------------------
// Invites & join requests
// ---------------------------------------------------------------------------

export async function createInvite(input: {
  actorId: string;
  chatId: string;
  expiresInHours?: number;
  maxUses?: number;
  requireApproval?: boolean;
}) {
  return withTransaction(async (tx) => {
    const ctx = await requireMembership(input.chatId, input.actorId, tx);
    if (ctx.role === 'member' && ctx.whoCanAddMembers === 'admins') {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Only admins can create invite links');
    }

    const code = shortCode(12);
    const res = await tx.query<{ id: string; code: string }>(
      `INSERT INTO chat_invites (chat_id, code, created_by, require_approval, max_uses, expires_at)
       VALUES ($1, $2, $3, $4, $5,
               CASE WHEN $6::int IS NULL THEN NULL ELSE now() + ($6 || ' hours')::interval END)
       RETURNING id, code`,
      [
        input.chatId,
        code,
        input.actorId,
        input.requireApproval ?? false,
        input.maxUses ?? null,
        input.expiresInHours ?? null,
      ],
    );
    return res.rows[0]!;
  });
}

export async function revokeInvite(actorId: string, inviteId: string): Promise<void> {
  const res = await query(
    `UPDATE chat_invites i
        SET revoked_at = now()
       FROM chat_members cm
      WHERE i.id = $1
        AND cm.chat_id = i.chat_id AND cm.user_id = $2
        AND cm.role IN ('admin','owner') AND cm.left_at IS NULL`,
    [inviteId, actorId],
  );
  if (res.rowCount === 0) throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Only admins can revoke invite links');
}

export type JoinResult =
  | { joined: true; chatId: string }
  | { joined: false; pendingApproval: true; requestId: string };

export async function joinViaInvite(userId: string, code: string): Promise<JoinResult> {
  return withTransaction(async (tx) => {
    const invite = await tx.query<{
      id: string; chat_id: string; require_approval: boolean; max_uses: number | null;
      uses: number; expires_at: Date | null; revoked_at: Date | null;
    }>(
      `SELECT id, chat_id, require_approval, max_uses, uses, expires_at, revoked_at
         FROM chat_invites WHERE code = $1 FOR UPDATE`,
      [code],
    );
    const row = invite.rows[0];
    if (!row) throw notFound(ErrorCodes.INVALID_INVITE, 'That invite link is not valid');
    if (row.revoked_at) throw notFound(ErrorCodes.INVALID_INVITE, 'That invite link was revoked');
    if (row.expires_at && row.expires_at.getTime() <= Date.now()) {
      throw notFound(ErrorCodes.INVITE_EXPIRED, 'That invite link has expired');
    }
    if (row.max_uses !== null && row.uses >= row.max_uses) {
      throw notFound(ErrorCodes.INVITE_EXPIRED, 'That invite link has reached its usage limit');
    }

    const already = await tx.query<{ status: string; left_at: Date | null }>(
      `SELECT status, left_at FROM chat_members WHERE chat_id = $1 AND user_id = $2`,
      [row.chat_id, userId],
    );
    const existing = already.rows[0];
    if (existing && existing.left_at === null && existing.status === 'active') {
      return { joined: true, chatId: row.chat_id };
    }
    // A banned member must not be able to rejoin through a link.
    if (existing?.status === 'banned') {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'You are no longer able to join this conversation');
    }

    if (row.require_approval) {
      const req = await tx.query<{ id: string }>(
        `INSERT INTO chat_join_requests (chat_id, user_id, invite_code, status)
         VALUES ($1, $2, $3, 'pending')
         ON CONFLICT (chat_id, user_id, status) DO UPDATE SET created_at = now()
         RETURNING id`,
        [row.chat_id, userId, code],
      );
      return { joined: false, pendingApproval: true, requestId: req.rows[0]!.id };
    }

    await tx.query(
      `INSERT INTO chat_members (chat_id, user_id, role, status, joined_at)
       VALUES ($1, $2, 'member', 'active', now())
       ON CONFLICT (chat_id, user_id) DO UPDATE SET left_at = NULL, status = 'active', joined_at = now()`,
      [row.chat_id, userId],
    );
    await tx.query(`UPDATE chat_invites SET uses = uses + 1 WHERE id = $1`, [row.id]);
    await tx.query(`UPDATE chats SET member_count = member_count + 1 WHERE id = $1`, [row.chat_id]);

    return { joined: true, chatId: row.chat_id };
  });
}

export async function reviewJoinRequest(input: {
  actorId: string;
  requestId: string;
  approve: boolean;
}): Promise<void> {
  await withTransaction(async (tx) => {
    const req = await tx.query<{ id: string; chat_id: string; user_id: string }>(
      `SELECT id, chat_id, user_id FROM chat_join_requests WHERE id = $1 AND status = 'pending' FOR UPDATE`,
      [input.requestId],
    );
    const row = req.rows[0];
    if (!row) throw notFound('not_found', 'Join request not found');

    const ctx = await requireMembership(row.chat_id, input.actorId, tx);
    assertAdmin(ctx, 'Only admins can review join requests');

    await tx.query(`UPDATE chat_join_requests SET status = $2, reviewed_by = $3, reviewed_at = now() WHERE id = $1`, [
      row.id,
      input.approve ? 'approved' : 'rejected',
      input.actorId,
    ]);

    if (input.approve) {
      await tx.query(
        `INSERT INTO chat_members (chat_id, user_id, role, status, joined_at, invited_by)
         VALUES ($1, $2, 'member', 'active', now(), $3)
         ON CONFLICT (chat_id, user_id) DO UPDATE SET left_at = NULL, status = 'active', joined_at = now()`,
        [row.chat_id, row.user_id, input.actorId],
      );
      await tx.query(`UPDATE chats SET member_count = member_count + 1 WHERE id = $1`, [row.chat_id]);
    }
  });
}

// ---------------------------------------------------------------------------
// Per-user chat state
// ---------------------------------------------------------------------------

export async function updateMemberState(
  userId: string,
  chatId: string,
  patch: {
    mutedUntil?: string | null;
    isArchived?: boolean;
    pinned?: boolean;
    isFavorite?: boolean;
    wallpaper?: string | null;
    theme?: string | null;
    notificationSound?: string | null;
    nickname?: string | null;
  },
): Promise<void> {
  const values: unknown[] = [chatId, userId];
  const fields: string[] = [];
  const push = (column: string, value: unknown) => {
    values.push(value);
    fields.push(`${column} = $${values.length}`);
  };

  const map: Record<string, string> = {
    mutedUntil: 'muted_until',
    isArchived: 'is_archived',
    isFavorite: 'is_favorite',
    wallpaper: 'wallpaper',
    theme: 'theme',
    notificationSound: 'notification_sound',
    nickname: 'nickname',
  };
  for (const [key, column] of Object.entries(map)) {
    const value = (patch as Record<string, unknown>)[key];
    if (value !== undefined) push(column, value);
  }
  if (patch.isArchived !== undefined) push('archived_at', patch.isArchived ? new Date() : null);
  if (patch.pinned !== undefined) push('pinned_at', patch.pinned ? new Date() : null);

  if (fields.length === 0) return;

  const res = await query(
    `UPDATE chat_members SET ${fields.join(', ')}, updated_at = now()
      WHERE chat_id = $1 AND user_id = $2 AND left_at IS NULL`,
    values,
  );
  if (res.rowCount === 0) throw forbidden(ErrorCodes.NOT_A_MEMBER, 'You are not a member of this conversation');
}

const MUTE_FOREVER = () => new Date('9999-12-31T00:00:00Z');

export async function muteChat(userId: string, chatId: string, durationSeconds: number | null): Promise<Date | null> {
  // A null duration means "until I turn it back on".
  const until = durationSeconds === null ? MUTE_FOREVER() : new Date(Date.now() + durationSeconds * 1000);
  await updateMemberState(userId, chatId, { mutedUntil: until.toISOString() });
  return until;
}

export async function lockChat(userId: string, chatId: string, secret?: string): Promise<void> {
  await query(
    `UPDATE chat_members
        SET is_locked = true, lock_secret_hash = $3
      WHERE chat_id = $1 AND user_id = $2`,
    [chatId, userId, secret ? hashToken(secret) : null],
  );
}

export async function unlockChat(userId: string, chatId: string, secret?: string): Promise<void> {
  const row = await queryOne<{ lock_secret_hash: string | null }>(
    `SELECT lock_secret_hash FROM chat_members WHERE chat_id = $1 AND user_id = $2`,
    [chatId, userId],
  );
  if (!row) throw forbidden(ErrorCodes.NOT_A_MEMBER, 'You are not a member of this conversation');

  if (row.lock_secret_hash) {
    if (!secret || hashToken(secret) !== row.lock_secret_hash) {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Incorrect chat lock code');
    }
  }
  await query(`UPDATE chat_members SET is_locked = false WHERE chat_id = $1 AND user_id = $2`, [chatId, userId]);
}

/** "Clear chat" for one user: hides everything up to now without touching others. */
export async function clearChat(userId: string, chatId: string): Promise<void> {
  const watermark = await queryOne<{ max_seq: string | null }>(
    `SELECT max(seq)::text AS max_seq FROM messages WHERE chat_id = $1`,
    [chatId],
  );
  const seq = Number(watermark?.max_seq ?? 0);
  // Hiding history for this user only: everything up to now is considered read.
  // Other members are unaffected, which is what "clear chat" means.
  await query(
    `UPDATE chat_members SET last_read_seq = GREATEST(last_read_seq, $3)
      WHERE chat_id = $1 AND user_id = $2`,
    [chatId, userId, seq],
  );
}

export async function markChatRead(userId: string, chatId: string, upToSeq?: number): Promise<number> {
  const target =
    upToSeq ??
    Number(
      (
        await queryOne<{ max_seq: string | null }>(
          `SELECT max(seq)::text AS max_seq FROM messages WHERE chat_id = $1`,
          [chatId],
        )
      )?.max_seq ?? 0,
    );

  const res = await query(
    `UPDATE chat_members
        SET last_read_seq = GREATEST(last_read_seq, $3),
            last_delivered_seq = GREATEST(last_delivered_seq, $3)
      WHERE chat_id = $1 AND user_id = $2
      RETURNING last_read_seq`,
    [chatId, userId, target],
  );
  if (res.rowCount === 0) throw forbidden(ErrorCodes.NOT_A_MEMBER, 'You are not a member of this conversation');
  return Number((res.rows[0] as { last_read_seq: string }).last_read_seq);
}

/** "Mark as unread" — rewind the watermark one message. */
export async function markChatUnread(userId: string, chatId: string): Promise<void> {
  await query(
    `UPDATE chat_members cm
        SET last_read_seq = GREATEST(0, COALESCE((
              SELECT max(seq) FROM messages m
               WHERE m.chat_id = cm.chat_id AND m.seq < cm.last_read_seq
            ), 0))
      WHERE cm.chat_id = $1 AND cm.user_id = $2`,
    [chatId, userId],
  );
}

// ---------------------------------------------------------------------------
// Chat list & details
// ---------------------------------------------------------------------------

export type ChatFilter = 'all' | 'unread' | 'groups' | 'direct' | 'archived' | 'favorites';

export async function listChats(userId: string, filter: ChatFilter = 'all', limit = 50) {
  const res = await query(
    `SELECT
        c.id, c.type, c.title, c.photo_url, c.last_message_at, c.last_message_preview,
        c.member_count, c.is_announcement, c.disappearing_seconds,
        cm.role, cm.muted_until, cm.is_archived, cm.pinned_at, cm.is_favorite,
        cm.is_locked, cm.last_read_seq, cm.last_delivered_seq,
        GREATEST(0, COALESCE(mx.max_seq, 0) - cm.last_read_seq) AS unread_count,
        CASE WHEN c.type = 'direct' THEN peer_info.id ELSE NULL END AS peer_id,
        CASE WHEN c.type = 'direct' THEN peer_info.username ELSE NULL END AS peer_username,
        CASE WHEN c.type = 'direct' THEN peer_info.display_name ELSE NULL END AS peer_display_name,
        CASE WHEN c.type = 'direct' THEN peer_info.avatar_url ELSE NULL END AS peer_avatar_url,
        CASE WHEN c.type = 'direct' THEN peer_info.last_seen_at ELSE NULL END AS peer_last_seen_at
      FROM chat_members cm
      JOIN chats c ON c.id = cm.chat_id AND c.deleted_at IS NULL
      LEFT JOIN LATERAL (
        SELECT max(m.seq) AS max_seq FROM messages m WHERE m.chat_id = c.id AND m.is_deleted = false
      ) mx ON true
      LEFT JOIN LATERAL (
        SELECT u.id, u.username, p.display_name, p.avatar_url, u.last_seen_at
          FROM chat_members other
          JOIN users u ON u.id = other.user_id
          LEFT JOIN user_profiles p ON p.user_id = u.id
         WHERE other.chat_id = c.id AND other.user_id <> $1
         LIMIT 1
      ) peer_info ON c.type = 'direct'
     WHERE cm.user_id = $1
       AND cm.left_at IS NULL
       AND cm.status = 'active'
       AND (
         ($2 = 'all'       AND cm.is_archived = false)
      OR ($2 = 'archived'  AND cm.is_archived = true)
      OR ($2 = 'unread'    AND cm.is_archived = false AND COALESCE(mx.max_seq, 0) > cm.last_read_seq)
      OR ($2 = 'groups'    AND cm.is_archived = false AND c.type <> 'direct')
      OR ($2 = 'direct'    AND cm.is_archived = false AND c.type = 'direct')
      OR ($2 = 'favorites' AND cm.is_archived = false AND cm.is_favorite = true)
       )
     ORDER BY cm.pinned_at DESC NULLS LAST, c.last_message_at DESC NULLS LAST, c.created_at DESC
     LIMIT $3`,
    [userId, filter, limit],
  );
  return res.rows;
}

export async function getChatDetails(chatId: string, userId: string) {
  const ctx = await requireMembership(chatId, userId);

  const chat = await queryOne(
    `SELECT c.*, cm.role, cm.muted_until, cm.is_archived, cm.pinned_at, cm.is_favorite,
            cm.is_locked, cm.wallpaper, cm.theme, cm.last_read_seq
       FROM chats c
       JOIN chat_members cm ON cm.chat_id = c.id AND cm.user_id = $2
      WHERE c.id = $1 AND cm.left_at IS NULL`,
    [chatId, userId],
  );
  if (!chat) throw notFound(ErrorCodes.CHAT_NOT_FOUND, 'Conversation not found');

  const members = await query(
    `SELECT cm.user_id, cm.role, cm.nickname, cm.member_label, cm.joined_at,
            -- Exposed so a client opening a conversation can render the correct
            -- delivery/read ticks for history it has just loaded. Without these
            -- watermarks a freshly opened chat can only show single ticks until
            -- new realtime events arrive, which looks like a bug to the user.
            cm.last_read_seq, cm.last_delivered_seq,
            u.username, u.last_seen_at, u.is_verified,
            p.display_name, p.avatar_url
       FROM chat_members cm
       JOIN users u ON u.id = cm.user_id
       LEFT JOIN user_profiles p ON p.user_id = u.id
      WHERE cm.chat_id = $1 AND cm.left_at IS NULL AND cm.status = 'active'
      ORDER BY cm.role DESC, cm.joined_at`,
    [chatId],
  );

  const pinned = await query(
    `SELECT message_id, pinned_at FROM message_pins WHERE chat_id = $1 ORDER BY pinned_at DESC LIMIT 50`,
    [chatId],
  );

  return { chat, role: ctx.role, members: members.rows, pinnedMessages: pinned.rows, permissions: {
    whoCanSend: ctx.whoCanSend,
    whoCanEditInfo: ctx.whoCanEditInfo,
    whoCanAddMembers: ctx.whoCanAddMembers,
    whoCanPin: ctx.whoCanPin,
  } };
}

export async function getChatMemberIds(chatId: string): Promise<string[]> {
  const res = await query<{ user_id: string }>(
    `SELECT user_id FROM chat_members WHERE chat_id = $1 AND left_at IS NULL AND status = 'active'`,
    [chatId],
  );
  return res.rows.map((r) => r.user_id);
}

export async function exportChat(userId: string, chatId: string, limit = 5000) {
  await requireMembership(chatId, userId);
  const res = await query(
    `SELECT m.id, m.seq, m.type, m.body, m.created_at, m.edited_at, m.is_deleted,
            u.username AS sender_username
       FROM messages m
       LEFT JOIN users u ON u.id = m.sender_id
      WHERE m.chat_id = $1
      ORDER BY m.seq ASC
      LIMIT $2`,
    [chatId, limit],
  );
  return { chatId, exportedAt: new Date().toISOString(), messageCount: res.rowCount, messages: res.rows };
}
