import { query } from '../db/pool.js';

/**
 * Audit and security-event writing.
 *
 * Both functions are deliberately fire-and-forget-friendly: a failure to write
 * an audit row must never fail the user's request, but it must be loud in the
 * logs, because silent audit loss is worse than a noisy one.
 */

export interface AuditInput {
  actorId?: string | null;
  actorRole?: string | null;
  action: string;
  targetType?: string;
  targetId?: string;
  metadata?: Record<string, unknown>;
  ip?: string;
  userAgent?: string;
}

export async function logAudit(input: AuditInput): Promise<void> {
  try {
    await query(
      `INSERT INTO audit_logs (actor_id, actor_role, action, target_type, target_id, metadata, ip, user_agent)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        input.actorId ?? null,
        input.actorRole ?? null,
        input.action,
        input.targetType ?? null,
        input.targetId ?? null,
        JSON.stringify(input.metadata ?? {}),
        input.ip ?? null,
        input.userAgent ?? null,
      ],
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('[audit] failed to write audit log', input.action, (err as Error).message);
  }
}

export type SecurityEventType =
  | 'login_success' | 'login_failed' | 'login_new_device' | 'logout'
  | 'password_changed' | 'email_changed' | 'phone_changed'
  | 'two_step_enabled' | 'two_step_disabled' | 'passkey_added' | 'passkey_removed'
  | 'device_linked' | 'device_revoked' | 'session_revoked'
  | 'account_locked' | 'otp_failed' | 'data_export_requested'
  | 'account_deletion_requested' | 'account_deletion_cancelled';

export async function logSecurityEvent(input: {
  userId: string | null;
  deviceId?: string | null;
  type: SecurityEventType;
  ip?: string;
  userAgent?: string;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  try {
    await query(
      `INSERT INTO security_events (user_id, device_id, event_type, ip, user_agent, metadata)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        input.userId,
        input.deviceId ?? null,
        input.type,
        input.ip ?? null,
        input.userAgent ?? null,
        JSON.stringify(input.metadata ?? {}),
      ],
    );
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('[audit] failed to write security event', input.type, (err as Error).message);
  }
}

export async function listSecurityEvents(userId: string, limit = 50) {
  const res = await query(
    `SELECT id, event_type, ip, user_agent, metadata, created_at
       FROM security_events
      WHERE user_id = $1
      ORDER BY created_at DESC
      LIMIT $2`,
    [userId, limit],
  );
  return res.rows;
}
