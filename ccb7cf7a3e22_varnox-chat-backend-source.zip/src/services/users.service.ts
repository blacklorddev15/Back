import { query, queryOne } from '../db/pool.js';
import { notFound } from '../lib/errors.js';
import { isOnline } from '../realtime/hub.js';
import { logAudit, listSecurityEvents } from './audit.service.js';

/**
 * Profile, settings and discovery.
 *
 * The important logic here is `buildUserView`, which decides what one user is
 * allowed to see about another. Privacy settings are only meaningful if every
 * read path funnels through one place — scattering the checks across handlers
 * is how "last seen: nobody" quietly leaks.
 */

export interface UserView {
  id: string;
  username: string | null;
  displayName: string | null;
  about: string | null;
  avatarUrl: string | null;
  countryCode: string | null;
  languageCode: string | null;
  isBusiness: boolean;
  isVerified: boolean;
  lastSeenAt: Date | null;
  online: boolean;
  isContact: boolean;
  blockedByMe: boolean;
}

type Visibility = 'everyone' | 'contacts' | 'contacts_except' | 'nobody';

function visibleTo(
  setting: Visibility,
  relationship: { isContact: boolean; isExcepted: boolean },
): boolean {
  switch (setting) {
    case 'everyone':
      return true;
    case 'contacts':
      return relationship.isContact;
    case 'contacts_except':
      // "Share with contacts except these people"
      return relationship.isContact && !relationship.isExcepted;
    case 'nobody':
      return false;
    default:
      return false;
  }
}

/**
 * Build the outward-facing view of a user for a specific viewer.
 * `viewerId === targetId` returns the full self view.
 */
export async function buildUserView(viewerId: string, targetId: string): Promise<UserView | null> {
  const row = await queryOne<{
    id: string; username: string | null; display_name: string | null; about: string | null;
    avatar_url: string | null; country_code: string | null; language_code: string | null;
    is_business: boolean; is_verified: boolean; last_seen_at: Date | null;
  }>(
    `SELECT u.id, u.username, p.display_name, p.about, p.avatar_url, p.country_code, p.language_code,
            u.is_business, u.is_verified, u.last_seen_at
       FROM users u
       LEFT JOIN user_profiles p ON p.user_id = u.id
      WHERE u.id = $1 AND u.deleted_at IS NULL`,
    [targetId],
  );
  if (!row) return null;

  const isSelf = viewerId === targetId;

  const relationship = await queryOne<{ is_contact: boolean; blocked_by_me: boolean }>(
    `SELECT
       EXISTS (SELECT 1 FROM contacts WHERE owner_id = $1 AND contact_user_id = $2) AS is_contact,
       EXISTS (SELECT 1 FROM user_blocks WHERE blocker_id = $1 AND blocked_id = $2) AS blocked_by_me`,
    [viewerId, targetId],
  );

  const rel = { isContact: relationship?.is_contact ?? false, isExcepted: false };

  let privacy = {
    last_seen_visibility: 'contacts' as Visibility,
    online_visibility: 'contacts' as Visibility,
    about_visibility: 'everyone' as Visibility,
    profile_photo_visibility: 'everyone' as Visibility,
  };

  if (!isSelf) {
    const settings = await queryOne<{
      last_seen_visibility: Visibility; online_visibility: Visibility;
      about_visibility: Visibility; profile_photo_visibility: Visibility;
    }>(
      `SELECT last_seen_visibility, online_visibility, about_visibility, profile_photo_visibility
         FROM user_privacy_settings WHERE user_id = $1`,
      [targetId],
    );
    if (settings) privacy = settings;
  }

  // Only relevant for the 'contacts_except' mode.
  if (!isSelf && (privacy.about_visibility === 'contacts_except' || privacy.last_seen_visibility === 'contacts_except')) {
    const excepted = await queryOne<{ exists: boolean }>(
      `SELECT EXISTS (
         SELECT 1 FROM contacts
          WHERE owner_id = $1 AND contact_user_id = $2 AND label_id IS NULL AND display_name IS NULL
       ) AS exists`,
      [targetId, viewerId],
    );
    rel.isExcepted = excepted?.exists ?? false;
  }

  const online = isOnline(targetId);

  return {
    id: row.id,
    username: row.username,
    displayName: row.display_name,
    about: visibleTo(privacy.about_visibility, rel) ? row.about : null,
    avatarUrl: visibleTo(privacy.profile_photo_visibility, rel) ? row.avatar_url : null,
    countryCode: row.country_code,
    languageCode: row.language_code,
    isBusiness: row.is_business,
    isVerified: row.is_verified,
    lastSeenAt: visibleTo(privacy.last_seen_visibility, rel) ? row.last_seen_at : null,
    online: visibleTo(privacy.online_visibility, rel) ? online : false,
    isContact: rel.isContact,
    blockedByMe: relationship?.blocked_by_me ?? false,
  };
}

/**
 * Explicit row shape for the self view. Without this the driver returns a
 * generic QueryResultRow and every property access downstream is untyped —
 * which is how a typo in a column name survives to production.
 */
export interface SelfRow {
  id: string;
  email: string | null;
  phone: string | null;
  username: string | null;
  full_name: string | null;
  status: string;
  is_business: boolean;
  is_verified: boolean;
  email_verified_at: Date | null;
  phone_verified_at: Date | null;
  two_step_enabled: boolean;
  created_at: Date;
  display_name: string | null;
  about: string | null;
  avatar_url: string | null;
  date_of_birth: Date | null;
  country_code: string | null;
  language_code: string | null;
  timezone: string | null;
  privacy: Record<string, unknown> | null;
  notifications: Record<string, unknown> | null;
  appearance: Record<string, unknown> | null;
}

/** The user/profile columns; the three settings objects are joined in separately. */
type SelfBaseRow = Omit<SelfRow, 'privacy' | 'notifications' | 'appearance'>;

export async function getSelf(userId: string): Promise<SelfRow> {
  // Cast rather than a generic: a mapped type over an interface loses its
  // implicit index signature, and spreading a possibly-null row then drops
  // every property from the returned type.
  const profile = (await queryOne(
    `SELECT u.id, u.email, u.phone, u.username, u.full_name, u.status, u.is_business, u.is_verified,
            u.email_verified_at, u.phone_verified_at, u.two_step_enabled, u.created_at,
            p.display_name, p.about, p.avatar_url, p.date_of_birth, p.country_code, p.language_code, p.timezone
       FROM users u
       LEFT JOIN user_profiles p ON p.user_id = u.id
      WHERE u.id = $1 AND u.deleted_at IS NULL`,
    [userId],
  )) as SelfBaseRow | null;

  if (!profile) throw notFound('user_not_found', 'Account not found');

  const [privacy, notifications, appearance] = await Promise.all([
    queryOne(`SELECT * FROM user_privacy_settings WHERE user_id = $1`, [userId]),
    queryOne(`SELECT * FROM user_notification_settings WHERE user_id = $1`, [userId]),
    queryOne(`SELECT * FROM user_appearance_settings WHERE user_id = $1`, [userId]),
  ]);

  return { ...profile, privacy, notifications, appearance };
}

export interface ProfilePatch {
  displayName?: string;
  about?: string;
  avatarUrl?: string;
  dateOfBirth?: string | null;
  countryCode?: string | null;
  languageCode?: string;
  timezone?: string;
}

export async function updateProfile(userId: string, patch: ProfilePatch): Promise<void> {
  const fields: string[] = [];
  const values: unknown[] = [userId];

  const push = (column: string, value: unknown) => {
    values.push(value);
    fields.push(`${column} = $${values.length}`);
  };

  if (patch.displayName !== undefined) push('display_name', patch.displayName);
  if (patch.about !== undefined) push('about', patch.about);
  if (patch.avatarUrl !== undefined) push('avatar_url', patch.avatarUrl);
  if (patch.dateOfBirth !== undefined) push('date_of_birth', patch.dateOfBirth);
  if (patch.countryCode !== undefined) push('country_code', patch.countryCode);
  if (patch.languageCode !== undefined) push('language_code', patch.languageCode);
  if (patch.timezone !== undefined) push('timezone', patch.timezone);

  if (fields.length === 0) return;

  // Profile rows are created at registration, but use an upsert anyway so this
  // cannot silently affect zero rows.
  await query(
    `INSERT INTO user_profiles (user_id) VALUES ($1)
     ON CONFLICT (user_id) DO UPDATE SET ${fields.join(', ')}, updated_at = now()`,
    values,
  );

  if (patch.displayName !== undefined) {
    await query(`UPDATE users SET full_name = $2 WHERE id = $1`, [userId, patch.displayName]);
  }
}

const PRIVACY_COLUMNS = new Set([
  'last_seen_visibility', 'online_visibility', 'profile_photo_visibility', 'about_visibility',
  'status_visibility', 'read_receipts_enabled', 'typing_indicator_enabled', 'live_location_enabled',
  'group_invite_policy', 'discoverable_by_email', 'discoverable_by_phone', 'discoverable_by_username',
  'silence_unknown_callers', 'screenshot_protection', 'security_notifications',
]);

export async function updatePrivacySettings(userId: string, patch: Record<string, unknown>): Promise<void> {
  // Whitelist: the column names come from the request body, so they must never
  // be interpolated without validation.
  const entries = Object.entries(patch).filter(([k, v]) => PRIVACY_COLUMNS.has(k) && v !== undefined);
  if (entries.length === 0) return;

  const values: unknown[] = [userId];
  const fields = entries.map(([column, value]) => {
    values.push(value);
    return `${column} = $${values.length}`;
  });

  await query(
    `INSERT INTO user_privacy_settings (user_id) VALUES ($1)
     ON CONFLICT (user_id) DO UPDATE SET ${fields.join(', ')}, updated_at = now()`,
    values,
  );
}

const NOTIFICATION_COLUMNS = new Set([
  'previews_enabled', 'in_app_enabled', 'vibration_enabled', 'vibration_pattern', 'default_sound',
  'notification_privacy', 'badge_enabled', 'email_security_alerts',
]);

export async function updateNotificationSettings(userId: string, patch: Record<string, unknown>): Promise<void> {
  const entries = Object.entries(patch).filter(([k, v]) => NOTIFICATION_COLUMNS.has(k) && v !== undefined);
  const extraFields: string[] = [];
  const values: unknown[] = [userId];

  const push = (column: string, value: unknown) => {
    values.push(value);
    extraFields.push(`${column} = $${values.length}`);
  };
  for (const [k, v] of entries) push(k, v);
  if (patch.quietHoursStart !== undefined) push('quiet_hours_start', patch.quietHoursStart);
  if (patch.quietHoursEnd !== undefined) push('quiet_hours_end', patch.quietHoursEnd);

  if (extraFields.length === 0) return;

  await query(
    `INSERT INTO user_notification_settings (user_id) VALUES ($1)
     ON CONFLICT (user_id) DO UPDATE SET ${extraFields.join(', ')}, updated_at = now()`,
    values,
  );
}

export async function updateAppearanceSettings(userId: string, patch: Record<string, unknown>): Promise<void> {
  const allowed = new Set(['theme', 'accent_color', 'chat_wallpaper', 'font_scale', 'high_contrast', 'reduce_motion']);
  const entries = Object.entries(patch).filter(([k, v]) => allowed.has(k) && v !== undefined);
  if (entries.length === 0) return;

  const values: unknown[] = [userId];
  const fields = entries.map(([column, value]) => {
    values.push(value);
    return `${column} = $${values.length}`;
  });

  await query(
    `INSERT INTO user_appearance_settings (user_id) VALUES ($1)
     ON CONFLICT (user_id) DO UPDATE SET ${fields.join(', ')}, updated_at = now()`,
    values,
  );
}

// ---------------------------------------------------------------------------
// Discovery / search
// ---------------------------------------------------------------------------

export interface SearchUsersInput {
  requesterId: string;
  query: string;
  limit?: number;
}

/**
 * Find people by email, phone or username.
 *
 * Results are filtered by the target's own discoverability flags and exclude
 * anyone who has blocked the requester. Exact-match search on email/phone is
 * intentionally the only mode: prefix-searching emails or phone numbers would
 * turn this into a harvesting tool for the whole user base.
 */
export async function searchUsers(input: SearchUsersInput) {
  const term = input.query.trim();
  const limit = Math.min(input.limit ?? 20, 50);
  if (term.length < 3) return [];

  const res = await query(
    `SELECT u.id, u.username, p.display_name, p.avatar_url, u.is_verified, u.is_business,
            (SELECT count(*) FROM contacts c WHERE c.owner_id = $1 AND c.contact_user_id = u.id) > 0 AS is_contact
       FROM users u
       LEFT JOIN user_profiles p ON p.user_id = u.id
       LEFT JOIN user_privacy_settings ps ON ps.user_id = u.id
      WHERE u.id <> $1
        AND u.deleted_at IS NULL
        AND u.status = 'active'
        -- Exclude anyone who blocked the requester.
        AND NOT EXISTS (
              SELECT 1 FROM user_blocks b WHERE b.blocker_id = u.id AND b.blocked_id = $1
            )
        AND (
              (lower(u.username) = lower($2) AND COALESCE(ps.discoverable_by_username, true))
           OR (lower(u.email)    = lower($2) AND COALESCE(ps.discoverable_by_email, true))
           OR (u.phone           = $2        AND COALESCE(ps.discoverable_by_phone, true))
           OR (lower(u.username) LIKE lower($2) || '%' AND COALESCE(ps.discoverable_by_username, true))
        )
      ORDER BY is_contact DESC, u.is_verified DESC, p.display_name NULLS LAST
      LIMIT $3`,
    [input.requesterId, term, limit],
  );
  return res.rows;
}

export interface DirectoryInput {
  requesterId: string;
  /** Optional name/username filter. Empty string lists everybody. */
  query?: string;
  limit?: number;
  offset?: number;
}

/**
 * The people directory: everyone on this deployment, so the app can show a
 * browsable list instead of forcing the user to guess a search term first.
 *
 * PRIVACY — this is the most exposure-increasing endpoint in the API, so the
 * rules are deliberate:
 *
 *  - Only display-safe fields are returned. Email and phone are NEVER included
 *    here; those stay behind the exact-match only /users/search, so this cannot
 *    be used to harvest contact details.
 *  - Anyone with "findable by username" turned off is omitted entirely. That
 *    setting is the user's switch for appearing in listings. Without an opt-out
 *    a directory silently publishes the whole user base to every member.
 *  - Blocked relationships are excluded in BOTH directions: you do not see
 *    people you blocked, and people who blocked you do not see you.
 *  - Suspended, deactivated and deleted accounts are excluded.
 *
 * Ordering is by signup date, oldest first — the earliest members appear at the
 * top, which is what "who joined first" should look like.
 */
export async function listDirectory(input: DirectoryInput) {
  const term = (input.query ?? '').trim();
  const limit = Math.min(Math.max(input.limit ?? 50, 1), 200);
  const offset = Math.max(input.offset ?? 0, 0);

  // Shared WHERE clause so the page and the total can never disagree.
  //
  // status is a denylist rather than an allowlist of 'active'. 'pending' means
  // the account registered but has not clicked the emailed link yet — those
  // people are real members of the deployment and the directory is meant to be
  // the complete list, so hiding them makes the list look short and wrong. The
  // removed states (suspended, deactivated, deleted) stay out.
  const filters = `
      u.id <> $1
      AND u.deleted_at IS NULL
      AND u.status NOT IN ('suspended', 'deactivated', 'deleted')
      AND COALESCE(ps.discoverable_by_username, true)
      AND NOT EXISTS (
            SELECT 1 FROM user_blocks b
             WHERE (b.blocker_id = u.id AND b.blocked_id = $1)
                OR (b.blocker_id = $1 AND b.blocked_id = u.id)
          )
      AND (
            $2 = ''
         OR lower(COALESCE(p.display_name, '')) LIKE '%' || lower($2) || '%'
         OR lower(COALESCE(u.username, ''))     LIKE '%' || lower($2) || '%'
      )`;

  const [page, total] = await Promise.all([
    query(
      `SELECT u.id, u.username, u.is_verified, u.is_business, u.created_at, u.last_seen_at,
              p.display_name, p.avatar_url,
              EXISTS (SELECT 1 FROM contacts c WHERE c.owner_id = $1 AND c.contact_user_id = u.id) AS is_contact
         FROM users u
         LEFT JOIN user_profiles p ON p.user_id = u.id
         LEFT JOIN user_privacy_settings ps ON ps.user_id = u.id
        WHERE ${filters}
        ORDER BY u.created_at ASC, u.id ASC
        LIMIT $3 OFFSET $4`,
      [input.requesterId, term, limit, offset],
    ),
    query<{ n: number }>(
      `SELECT count(*)::int AS n
         FROM users u
         LEFT JOIN user_profiles p ON p.user_id = u.id
         LEFT JOIN user_privacy_settings ps ON ps.user_id = u.id
        WHERE ${filters}`,
      [input.requesterId, term],
    ),
  ]);

  return { members: page.rows, total: total.rows[0]?.n ?? 0, limit, offset };
}

/**
 * Contact sync: given the phone numbers on a device, report which are already
 * registered. Numbers are normalised by the caller; matching is exact.
 */
export async function matchKnownContacts(requesterId: string, phones: string[]) {
  if (phones.length === 0) return [];
  const res = await query(
    `SELECT u.id, u.phone, u.username, p.display_name, p.avatar_url
       FROM users u
       LEFT JOIN user_profiles p ON p.user_id = u.id
      WHERE u.phone = ANY($2::text[])
        AND u.id <> $1
        AND u.deleted_at IS NULL
        AND u.status = 'active'
        AND NOT EXISTS (SELECT 1 FROM user_blocks b WHERE b.blocker_id = u.id AND b.blocked_id = $1)`,
    [requesterId, phones],
  );
  return res.rows;
}

// ---------------------------------------------------------------------------
// Data export
// ---------------------------------------------------------------------------

export async function requestDataExport(userId: string): Promise<{ requestId: string }> {
  const row = await queryOne<{ id: string }>(
    `INSERT INTO data_requests (user_id, kind, status) VALUES ($1, 'export', 'pending') RETURNING id`,
    [userId],
  );
  await logAudit({ actorId: userId, action: 'user.data_export_requested', targetType: 'user', targetId: userId });
  return { requestId: row!.id };
}

export async function getSecurityLog(userId: string, limit = 50) {
  return listSecurityEvents(userId, limit);
}
