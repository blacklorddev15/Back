import { readdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import pg from 'pg';
import { config } from '../config.js';

const { Pool, Client } = pg;

/**
 * Database connection layer.
 *
 * NEON CONSTRAINT: the pooled endpoint runs PgBouncer in `transaction` mode.
 * That means a connection is handed back after every transaction, so all of
 * these break in ways that are confusing to debug:
 *
 *   - LISTEN / NOTIFY            (no session to stay attached to)
 *   - session advisory locks     (pg_advisory_lock leaks across requests)
 *   - SET / RESET session vars   (silently lost — even SET search_path)
 *   - SQL-level PREPARE / EXECUTE
 *   - WITH HOLD cursors
 *
 * The app pool therefore never uses any of those. Realtime fan-out is in-process
 * in the WebSocket hub instead of via LISTEN/NOTIFY, and locking uses
 * `pg_advisory_xact_lock` (transaction-scoped) rather than the session variant.
 *
 * node-postgres does not create named prepared statements unless you pass a
 * `name` option, so the driver is pooler-safe as-is. Do NOT introduce
 * `client.query({ name: ... })` against the pooled connection without checking
 * Neon's max_prepared_statements behaviour first.
 *
 * ---------------------------------------------------------------------------
 * MULTIPLE CANDIDATE DATABASES
 *
 * The backend can be given an ordered list of databases and will pick the first
 * one that is BOTH reachable AND fully migrated. Two properties are deliberate:
 *
 *   1. Selection happens ONCE, at boot. It never switches while running. A live
 *      process holding connections and in-flight transactions to one database
 *      must not have that ground shift underneath it; that is how you get
 *      half-written state spread across two datasets.
 *
 *   2. A candidate whose `schema_migrations` is behind the migrations shipped
 *      with this code is REJECTED. Otherwise a failover would silently serve
 *      older data — users "disappearing", messages missing — with no error
 *      anywhere. Failing to start is far better than that.
 *
 * WHAT THIS IS NOT: it is not replication. Two independent Neon databases do
 * not stay in sync; they are two divergent datasets. Neon read replicas do read
 * the same storage as their primary, but they are read-only, so they cannot be
 * failed over to. Using this for a standby only makes sense when you accept
 * that the standby's data is as old as its last sync — see the note in
 * MIGRATION.md. Without that understanding, switching databases loses data.
 * ---------------------------------------------------------------------------
 */

let pool: pg.Pool | null = null;
let activeTarget: DatabaseTarget | null = null;

export interface DatabaseTarget {
  /** Masked, safe to log: hostname/database only, never credentials. */
  label: string;
  pooler: boolean;
  appliedMigrations: number;
}

export interface DatabaseSelection {
  target: DatabaseTarget;
  tried: { label: string; ok: boolean; reason?: string }[];
}

/** host/db only — the URL contains a password and must never be logged. */
function labelOf(url: string): string {
  try {
    const u = new URL(url);
    return `${u.hostname}${u.pathname}`;
  } catch {
    return '(unparseable url)';
  }
}

function isPooler(url: string): boolean {
  try {
    return new URL(url).hostname.includes('-pooler');
  } catch {
    return false;
  }
}

/**
 * Candidate list in preference order.
 *
 * `DATABASE_URL` is always the first choice. `DATABASE_URLS` adds fallbacks and
 * is only consulted when DATABASE_FAILOVER is explicitly enabled, so a typo in
 * that variable can never quietly redirect production to a different database.
 */
function candidates(): string[] {
  if (!config.DATABASE_FAILOVER) return [config.DATABASE_URL];

  const extra = (config.DATABASE_URLS ?? '')
    .split(/[;,\n]/)
    .map((entry) => entry.trim())
    .filter(Boolean);

  // De-duplicate: the same database listed twice would just be probed twice.
  return [...new Set([config.DATABASE_URL, ...extra])];
}

function createPool(url: string): pg.Pool {
  const created = new Pool({
    connectionString: url,
    max: config.DB_POOL_MAX,
    idleTimeoutMillis: config.DB_IDLE_TIMEOUT_MS,
    // Neon always requires TLS; locally it usually is not configured.
    ssl: config.DB_SSL ? { rejectUnauthorized: false } : undefined,
    application_name: 'chat-backend',
  });

  // A pool that errors asynchronously (e.g. Neon scaled the compute to zero and
  // killed an idle connection) would otherwise crash the process.
  created.on('error', (err) => {
    // eslint-disable-next-line no-console
    console.error('[db] idle client error', err.message);
  });

  return created;
}

/** How many migrations this build ships. 0 means "unknown, skip the check". */
async function expectedMigrationCount(): Promise<number> {
  // Tries the common layouts: running from src (tsx) and from dist after a build.
  const guesses = [resolve(process.cwd(), 'migrations'), resolve(process.cwd(), '..', 'migrations')];
  for (const dir of guesses) {
    try {
      const files = await readdir(dir);
      const count = files.filter((f) => f.endsWith('.sql')).length;
      if (count > 0) return count;
    } catch {
      // try the next location
    }
  }
  return 0;
}

type ProbeResult = { ok: true; applied: number } | { ok: false; reason: string };

async function probe(url: string, expected: number): Promise<ProbeResult> {
  const client = new Client({
    connectionString: url,
    ssl: config.DB_SSL ? { rejectUnauthorized: false } : undefined,
    connectionTimeoutMillis: 10_000,
    application_name: 'chat-backend-probe',
  });

  try {
    await client.connect();

    const table = await client.query<{ present: boolean }>(
      `SELECT EXISTS (
         SELECT 1 FROM information_schema.tables
          WHERE table_schema = 'public' AND table_name = 'schema_migrations'
       ) AS present`,
    );
    if (!table.rows[0]?.present) {
      return { ok: false, reason: 'no schema_migrations table — migrations were never run here' };
    }

    const applied = await client.query<{ n: number }>('SELECT count(*)::int AS n FROM schema_migrations');
    const count = applied.rows[0]?.n ?? 0;

    if (expected > 0 && count < expected) {
      return {
        ok: false,
        reason: `schema is behind: ${count}/${expected} migrations applied — run \`npm run migrate\``,
      };
    }
    return { ok: true, applied: count };
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : 'unreachable' };
  } finally {
    await client.end().catch(() => {});
  }
}

/**
 * Choose the database and open the pool. Must be awaited during boot, before
 * any route can serve a request.
 */
export async function initialiseDatabase(): Promise<DatabaseSelection> {
  const expected = await expectedMigrationCount();
  const tried: DatabaseSelection['tried'] = [];

  for (const url of candidates()) {
    const label = labelOf(url);
    const result = await probe(url, expected);

    if (result.ok) {
      tried.push({ label, ok: true });
      pool = createPool(url);
      activeTarget = { label, pooler: isPooler(url), appliedMigrations: result.applied };
      return { target: activeTarget, tried };
    }

    tried.push({ label, ok: false, reason: result.reason });
  }

  // No usable database. Fail loudly at boot with every reason, rather than
  // starting up and 500-ing on every request.
  const detail = tried.map((t) => `  - ${t.label}: ${t.reason}`).join('\n');
  throw new Error(
    `No usable database. Tried ${tried.length} candidate(s):\n${detail}\n\n` +
      (expected > 0 ? `This build expects ${expected} migrations to be applied.\n` : ''),
  );
}

export function databaseTarget(): DatabaseTarget | null {
  return activeTarget;
}

function getPool(): pg.Pool {
  if (!pool) {
    throw new Error('Database not initialised. initialiseDatabase() must be awaited during boot.');
  }
  return pool;
}

export type QueryParams = readonly unknown[];

/** Single query, autocommit. Use `withTransaction` for anything multi-step. */
export async function query<T extends pg.QueryResultRow = pg.QueryResultRow>(
  text: string,
  params: QueryParams = [],
): Promise<pg.QueryResult<T>> {
  return getPool().query<T>(text, params as unknown[]);
}

/** Convenience: return the first row, or null. */
export async function queryOne<T extends pg.QueryResultRow = pg.QueryResultRow>(
  text: string,
  params: QueryParams = [],
): Promise<T | null> {
  const res = await query<T>(text, params);
  return res.rows[0] ?? null;
}

export type Tx = pg.PoolClient;

/**
 * Run `fn` inside a single transaction. Rolls back on any throw.
 *
 * Anything involving money, membership counts, or denormalised counters must go
 * through here — the alternative is state that is subtly wrong forever.
 */
export async function withTransaction<T>(fn: (tx: Tx) => Promise<T>): Promise<T> {
  const client = await getPool().connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch {
      // A rollback failure means the connection is dead; the pool discards it.
    }
    throw err;
  } finally {
    client.release();
  }
}

/**
 * Transaction-scoped advisory lock — the pooler-safe way to serialise work on a
 * logical key (e.g. "only one direct chat may exist between A and B").
 * Released automatically when the transaction ends.
 */
export async function acquireTransactionLock(tx: Tx, key: string): Promise<void> {
  await tx.query('SELECT pg_advisory_xact_lock(hashtext($1))', [key]);
}

export async function closePool(): Promise<void> {
  if (pool) {
    await pool.end();
    pool = null;
  }
}
