/**
 * Migration runner.
 *
 *   npm run migrate          apply everything pending
 *   npm run migrate:status   show applied vs pending, change nothing
 *
 * NEON CONSTRAINT: migrations run on the DIRECT connection, never the pooled
 * one. PgBouncer in transaction mode cannot reliably run DDL inside a
 * transaction that also issues session-level statements, and tooling that
 * relies on `SET` silently misbehaves behind the pooler. Neon's own docs make
 * the same recommendation.
 */
import { createHash } from 'node:crypto';
import { readdir, readFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';
import { config } from '../config.js';

const here = dirname(fileURLToPath(import.meta.url));
// Works both from src/ (tsx) and dist/src/ (compiled), because migrations/
// sits at the project root in both cases.
const MIGRATIONS_DIR = resolve(here, '..', '..', 'migrations');

interface MigrationFile {
  name: string;
  sql: string;
  checksum: string;
}

async function loadMigrations(): Promise<MigrationFile[]> {
  const entries = await readdir(MIGRATIONS_DIR);
  const files = entries.filter((f) => f.endsWith('.sql')).sort();
  const out: MigrationFile[] = [];
  for (const name of files) {
    const sql = await readFile(join(MIGRATIONS_DIR, name), 'utf8');
    out.push({ name, sql, checksum: createHash('sha256').update(sql).digest('hex').slice(0, 16) });
  }
  return out;
}

async function ensureRegistry(client: pg.Client): Promise<void> {
  await client.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      name        text PRIMARY KEY,
      checksum    text NOT NULL,
      applied_at  timestamptz NOT NULL DEFAULT now(),
      duration_ms integer NOT NULL DEFAULT 0
    )
  `);
}

async function main(): Promise<void> {
  const statusOnly = process.argv.includes('--status');

  const client = new pg.Client({
    connectionString: config.directDatabaseUrl,
    ssl: config.DB_SSL ? { rejectUnauthorized: false } : undefined,
    application_name: 'chat-backend-migrate',
  });

  await client.connect();
  console.log(`[migrate] connected (${config.directDatabaseUrl.replace(/:[^:@/]+@/, ':***@')})`);

  try {
    await ensureRegistry(client);

    const applied = new Map<string, string>(
      (await client.query<{ name: string; checksum: string }>('SELECT name, checksum FROM schema_migrations')).rows.map(
        (r) => [r.name, r.checksum],
      ),
    );

    const migrations = await loadMigrations();
    const pending = migrations.filter((m) => !applied.has(m.name));

    if (statusOnly) {
      console.log(`\n${migrations.length} migration file(s), ${applied.size} applied, ${pending.length} pending\n`);
      for (const m of migrations) {
        const state = applied.has(m.name) ? 'applied' : 'PENDING';
        const drift = applied.has(m.name) && applied.get(m.name) !== m.checksum ? '  <-- CHECKSUM CHANGED' : '';
        console.log(`  [${state.padEnd(7)}] ${m.name}${drift}`);
      }
      return;
    }

    if (pending.length === 0) {
      console.log('[migrate] nothing to do — database is up to date');
      return;
    }

    // An already-applied file whose contents changed means the database and
    // the repository disagree. Refusing is the safe default: silently
    // continuing is how environments drift apart unnoticed.
    for (const m of migrations) {
      const prev = applied.get(m.name);
      if (prev && prev !== m.checksum) {
        throw new Error(
          `Migration ${m.name} was modified after it was applied (recorded ${prev}, found ${m.checksum}). ` +
            `Add a new migration instead of editing this one.`,
        );
      }
    }

    for (const m of pending) {
      const started = Date.now();
      process.stdout.write(`[migrate] applying ${m.name} ... `);
      try {
        await client.query('BEGIN');
        await client.query(m.sql);
        await client.query(
          'INSERT INTO schema_migrations (name, checksum, duration_ms) VALUES ($1, $2, $3)',
          [m.name, m.checksum, Date.now() - started],
        );
        await client.query('COMMIT');
        console.log(`ok (${Date.now() - started}ms)`);
      } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        console.log('FAILED');
        throw err;
      }
    }

    console.log(`[migrate] done — applied ${pending.length} migration(s)`);
  } finally {
    await client.end();
  }
}

main().catch((err: unknown) => {
  const message = err instanceof Error ? err.message : String(err);
  console.error(`\n[migrate] error: ${message}`);
  process.exit(1);
});
