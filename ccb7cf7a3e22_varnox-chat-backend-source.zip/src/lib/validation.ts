import { z } from 'zod';
import { config } from '../config.js';

/**
 * Shared zod schemas.
 *
 * The phone rule is intentionally loose: phone numbers are collected as a
 * contact identifier, and international formats vary far too much for a strict
 * regex to be anything but a source of false rejections. We require a leading
 * +, a plausible digit count, and normalise to E.164-ish storage.
 */
export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .email('Enter a valid email address')
  .max(254, 'Email address is too long');

export const phoneSchema = z
  .string()
  .trim()
  .transform((v) => v.replace(/[\s()-]/g, ''))
  .refine((v) => /^\+?[1-9]\d{6,14}$/.test(v), 'Enter a valid phone number in international format');

export const usernameSchema = z
  .string()
  .trim()
  .toLowerCase()
  .min(3, 'Username must be at least 3 characters')
  .max(32, 'Username must be at most 32 characters')
  .regex(/^[a-z0-9._]+$/, 'Usernames may contain letters, numbers, dots and underscores only')
  .refine((v) => !v.startsWith('.') && !v.endsWith('.'), 'Username cannot start or end with a dot');

export const passwordSchema = z
  .string()
  .min(config.PASSWORD_MIN_LENGTH, `Password must be at least ${config.PASSWORD_MIN_LENGTH} characters`)
  .max(200, 'Password is too long')
  // Deliberately NOT requiring symbol/number mixes: length is the property that
  // actually resists offline cracking, and composition rules push users toward
  // predictable substitutions ("Password1!"). A breach-list check is the
  // higher-value addition here — see the note in the README.
  .refine((v) => !/^\s|\s$/.test(v), 'Password cannot start or end with whitespace');

export const otpSchema = z
  .string()
  .trim()
  .regex(new RegExp(`^\\d{${config.OTP_LENGTH}}$`), `Enter the ${config.OTP_LENGTH}-digit code`);

export const pinSchema = z
  .string()
  .trim()
  .regex(new RegExp(`^\\d{${config.PIN_LENGTH}}$`), `PIN must be ${config.PIN_LENGTH} digits`);

export const uuidSchema = z.string().uuid('Expected a UUID');

export const languageCodeSchema = z.string().trim().min(2).max(10);

export const countryCodeSchema = z.string().trim().length(2, 'Use a 2-letter ISO country code').toUpperCase();

/** Cursor pagination. `before`/`after` are message `seq` values. */
export const paginationSchema = z.object({
  limit: z.coerce.number().int().min(1).max(200).default(50),
  before: z.coerce.number().int().nonnegative().optional(),
  after: z.coerce.number().int().nonnegative().optional(),
});

export type Pagination = z.infer<typeof paginationSchema>;

// ---------------------------------------------------------------------------
// Content validation shared by messages, posts and statuses
// ---------------------------------------------------------------------------
export const MAX_MESSAGE_LENGTH = 16_384;

export const messageBodySchema = z.string().max(MAX_MESSAGE_LENGTH, 'Message is too long');

/**
 * Link extraction for previews and the suspicious-link warning feature.
 * Deliberately simple: the check that matters is the domain lookup against
 * `link_reputation`, not exhaustive URL parsing.
 */
export function extractUrls(text: string): string[] {
  const matches = text.match(/\bhttps?:\/\/[^\s<>"']+/gi) ?? [];
  const unique = new Set<string>();
  for (const raw of matches) {
    try {
      unique.add(new URL(raw).toString());
    } catch {
      // Not a parseable URL — ignore rather than reject the whole message.
    }
  }
  return [...unique];
}

export function extractMentions(text: string): string[] {
  const matches = text.match(/@([a-z0-9._]{3,32})/gi) ?? [];
  return [...new Set(matches.map((m) => m.slice(1).toLowerCase()))];
}
