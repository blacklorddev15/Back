/**
 * A single error type the whole API throws. Every route handler can throw
 * AppError and the central error handler turns it into a consistent JSON body,
 * so no handler needs to know about HTTP plumbing.
 */
export class AppError extends Error {
  readonly statusCode: number;
  readonly code: string;
  readonly details?: unknown;

  constructor(statusCode: number, code: string, message: string, details?: unknown) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
  }
}

export const badRequest = (code: string, message: string, details?: unknown) =>
  new AppError(400, code, message, details);

export const unauthorized = (code = 'unauthorized', message = 'Authentication required') =>
  new AppError(401, code, message);

export const forbidden = (code = 'forbidden', message = 'You do not have access to this resource') =>
  new AppError(403, code, message);

export const notFound = (code = 'not_found', message = 'Resource not found') =>
  new AppError(404, code, message);

export const conflict = (code: string, message: string, details?: unknown) =>
  new AppError(409, code, message, details);

export const tooManyRequests = (code = 'rate_limited', message = 'Too many requests', details?: unknown) =>
  new AppError(429, code, message, details);

export const gone = (code: string, message: string) => new AppError(410, code, message);

export const unprocessable = (code: string, message: string, details?: unknown) =>
  new AppError(422, code, message, details);

// ---------------------------------------------------------------------------
// Stable error codes. Clients branch on these, so they are part of the API
// contract and must not be renamed casually.
// ---------------------------------------------------------------------------
export const ErrorCodes = {
  // auth
  INVALID_CREDENTIALS: 'invalid_credentials',
  EMAIL_TAKEN: 'email_taken',
  PHONE_TAKEN: 'phone_taken',
  USERNAME_TAKEN: 'username_taken',
  EMAIL_NOT_VERIFIED: 'email_not_verified',
  ACCOUNT_SUSPENDED: 'account_suspended',
  ACCOUNT_LOCKED: 'account_locked',
  OTP_INVALID: 'otp_invalid',
  OTP_EXPIRED: 'otp_expired',
  OTP_ATTEMPTS_EXCEEDED: 'otp_attempts_exceeded',
  OTP_RESEND_TOO_SOON: 'otp_resend_too_soon',
  OTP_RATE_LIMITED: 'otp_rate_limited',
  TWO_STEP_REQUIRED: 'two_step_required',
  TWO_STEP_INVALID: 'two_step_invalid',
  TOKEN_EXPIRED: 'token_expired',
  SESSION_REVOKED: 'session_revoked',
  WEAK_PASSWORD: 'weak_password',
  // resources
  CHAT_NOT_FOUND: 'chat_not_found',
  CHANNEL_NOT_FOUND: 'channel_not_found',
  POST_NOT_FOUND: 'post_not_found',
  NOT_A_MEMBER: 'not_a_member',
  CANNOT_SEND: 'cannot_send',
  MESSAGE_NOT_FOUND: 'message_not_found',
  MESSAGE_ALREADY_DELETED: 'message_already_deleted',
  EDIT_WINDOW_CLOSED: 'edit_window_closed',
  BLOCKED: 'blocked_by_recipient',
  USER_NOT_FOUND: 'user_not_found',
  INVALID_INVITE: 'invalid_invite',
  INVITE_EXPIRED: 'invite_expired',
  FORBIDDEN_ACTION: 'forbidden_action',
  // media
  FILE_TOO_LARGE: 'file_too_large',
  UNSUPPORTED_MEDIA: 'unsupported_media_type',
  // generic
  VALIDATION_FAILED: 'validation_failed',
  CONFLICT: 'conflict',
  INTERNAL: 'internal_error',
} as const;

export type ErrorCode = (typeof ErrorCodes)[keyof typeof ErrorCodes];
