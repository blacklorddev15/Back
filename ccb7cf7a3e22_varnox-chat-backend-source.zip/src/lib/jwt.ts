import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { config } from '../config.js';

/**
 * Minimal HS256 JWT implementation.
 *
 * Why hand-rolled rather than a library: this service only ever *issues and
 * verifies its own* tokens with a single symmetric algorithm. That removes the
 * entire class of JWT vulnerabilities that libraries exist to guard against —
 * the `alg: none` downgrade and RS256/HS256 confusion attacks both require the
 * verifier to honour attacker-chosen algorithm headers. Here the algorithm is
 * hard-coded and the header is not consulted for algorithm selection at all.
 *
 * If you ever need asymmetric keys (so a separate service can verify without
 * being able to mint), replace this with a vetted library rather than extending it.
 */

export interface AccessTokenClaims {
  sub: string;        // user id
  sid: string;        // session id
  did?: string;       // device id
  role?: string;      // admin role, if any
  typ: 'access';
  /**
   * 'full'     — a normal authenticated session.
   * 'two_step' — the password was correct but the second factor has not been
   *              satisfied yet. Such a token may ONLY be exchanged at the
   *              two-step endpoint, never used to call the API. Without this
   *              distinction, enabling the PIN would be security theatre: the
   *              client could simply ignore the challenge and use the token
   *              it was handed.
   */
  stage: 'full' | 'two_step';
  iat: number;
  exp: number;
  jti: string;
}

const ALG = 'HS256';

function b64url(input: Buffer | string): string {
  return Buffer.from(input).toString('base64url');
}

function sign(data: string): string {
  return createHmac('sha256', config.JWT_SECRET).update(data).digest('base64url');
}

export function issueAccessToken(params: {
  userId: string;
  sessionId: string;
  deviceId?: string;
  role?: string;
  stage?: 'full' | 'two_step';
  ttlSeconds?: number;
}): { token: string; expiresAt: Date } {
  const now = Math.floor(Date.now() / 1000);
  const ttl = params.ttlSeconds ?? config.ACCESS_TOKEN_TTL_SECONDS;
  const claims: AccessTokenClaims = {
    sub: params.userId,
    sid: params.sessionId,
    did: params.deviceId,
    role: params.role,
    typ: 'access',
    stage: params.stage ?? 'full',
    iat: now,
    exp: now + ttl,
    jti: randomUUID(),
  };

  const header = b64url(JSON.stringify({ alg: ALG, typ: 'JWT' }));
  const payload = b64url(JSON.stringify(claims));
  const signature = sign(`${header}.${payload}`);
  return { token: `${header}.${payload}.${signature}`, expiresAt: new Date(claims.exp * 1000) };
}

export type VerifyResult =
  | { ok: true; claims: AccessTokenClaims }
  | { ok: false; reason: 'malformed' | 'bad_signature' | 'expired' | 'wrong_type' };

export function verifyAccessToken(token: string): VerifyResult {
  const parts = token.split('.');
  if (parts.length !== 3) return { ok: false, reason: 'malformed' };
  const [header, payload, signature] = parts as [string, string, string];

  // Length check first: timingSafeEqual throws on length mismatch.
  const expected = sign(`${header}.${payload}`);
  if (expected.length !== signature.length) return { ok: false, reason: 'bad_signature' };
  if (!timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) {
    return { ok: false, reason: 'bad_signature' };
  }

  let claims: AccessTokenClaims;
  try {
    claims = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as AccessTokenClaims;
  } catch {
    return { ok: false, reason: 'malformed' };
  }

  if (claims.typ !== 'access') return { ok: false, reason: 'wrong_type' };
  if (typeof claims.exp !== 'number' || claims.exp * 1000 <= Date.now()) {
    return { ok: false, reason: 'expired' };
  }
  return { ok: true, claims };
}
