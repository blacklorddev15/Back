import { query } from '../db/pool.js';

/**
 * Rate limiting, in two layers.
 *
 * LAYER 1 — in-memory fixed window, checked on every request. Zero latency and
 * zero database load, which matters because the things being protected (login,
 * OTP send) are exactly the endpoints an attacker will hammer.
 *
 * LIMITATION, stated plainly: this is per-process. Run four API instances and
 * a caller gets four times the allowance. That is an acceptable trade for
 * cheap protection, but if you scale horizontally, move this to Redis or make
 * every check go through `consumePersistent`.
 *
 * LAYER 2 — the `rate_limit_counters` table, which survives restarts and gives
 * moderators a history. Used for the expensive, abuse-prone operations where
 * correctness matters more than a few milliseconds.
 */

interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();

// Without eviction this map is an unbounded memory leak driven by attacker
// input, which is a denial-of-service vector in itself.
const MAX_BUCKETS = 50_000;
let lastSweep = Date.now();

function sweep(now: number): void {
  if (now - lastSweep < 60_000 && buckets.size < MAX_BUCKETS) return;
  lastSweep = now;
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt <= now) buckets.delete(key);
  }
  // If still oversized after dropping expired entries, clear the oldest half
  // rather than growing without bound.
  if (buckets.size >= MAX_BUCKETS) {
    const entries = [...buckets.entries()].sort((a, b) => a[1].resetAt - b[1].resetAt);
    for (const [key] of entries.slice(0, Math.floor(entries.length / 2))) buckets.delete(key);
  }
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  retryAfterSeconds: number;
}

export function consume(key: string, limit: number, windowSeconds: number): RateLimitResult {
  const now = Date.now();
  sweep(now);

  const existing = buckets.get(key);
  if (!existing || existing.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowSeconds * 1000 });
    return { allowed: true, remaining: limit - 1, retryAfterSeconds: 0 };
  }

  existing.count += 1;
  if (existing.count > limit) {
    return {
      allowed: false,
      remaining: 0,
      retryAfterSeconds: Math.max(1, Math.ceil((existing.resetAt - now) / 1000)),
    };
  }
  return { allowed: true, remaining: limit - existing.count, retryAfterSeconds: 0 };
}

/** Read-only peek, for reporting remaining quota without consuming any. */
export function peek(key: string): number {
  const existing = buckets.get(key);
  if (!existing || existing.resetAt <= Date.now()) return 0;
  return existing.count;
}

export function reset(key: string): void {
  buckets.delete(key);
}

// ---------------------------------------------------------------------------
// Persistent layer
// ---------------------------------------------------------------------------

/**
 * Increment a durable counter for the current hour and return the new total.
 * Uses an upsert so concurrent callers cannot both read the same starting
 * value — a read-then-write here would let two requests through.
 */
export async function consumePersistent(
  bucket: string,
  subject: string,
  windowSeconds = 3600,
): Promise<number> {
  const windowStart = new Date(Math.floor(Date.now() / (windowSeconds * 1000)) * windowSeconds * 1000);
  const row = await query<{ count: number }>(
    `INSERT INTO rate_limit_counters (bucket, subject, window_start, count)
     VALUES ($1, $2, $3, 1)
     ON CONFLICT (bucket, subject, window_start)
     DO UPDATE SET count = rate_limit_counters.count + 1
     RETURNING count`,
    [bucket, subject, windowStart],
  );
  return row.rows[0]?.count ?? 1;
}

/** Housekeeping: drop counters older than a day. Safe to call periodically. */
export async function prunePersistentCounters(): Promise<void> {
  await query(`DELETE FROM rate_limit_counters WHERE window_start < now() - interval '1 day'`);
}
