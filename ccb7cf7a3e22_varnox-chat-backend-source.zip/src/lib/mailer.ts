import nodemailer, { type Transporter } from 'nodemailer';
import { config } from '../config.js';

/**
 * Transactional email.
 *
 * DEVELOPMENT: MAIL_TRANSPORT=console prints messages to stdout. OTP flows are
 * painful to test against a real inbox, and a console transport makes the code
 * visible in logs without a provider account.
 *
 * PRODUCTION: MAIL_TRANSPORT=smtp with real credentials. Boot refuses to start
 * in production with the console transport, because silently not sending
 * verification codes would look like a bug in the OTP logic.
 *
 * DELIVERABILITY NOTE: sending from a domain you do not control lands in spam
 * almost immediately. Before launch, add the provider's SPF, DKIM and DMARC
 * records for your sending domain, or your users simply will not receive codes.
 */

let transporter: Transporter | null = null;

function getTransporter(): Transporter {
  if (transporter) return transporter;
  if (!config.SMTP_HOST) {
    throw new Error('MAIL_TRANSPORT=smtp requires SMTP_HOST to be set');
  }
  transporter = nodemailer.createTransport({
    host: config.SMTP_HOST,
    port: config.SMTP_PORT,
    secure: config.SMTP_SECURE,
    auth: config.SMTP_USER ? { user: config.SMTP_USER, pass: config.SMTP_PASS } : undefined,
  });
  return transporter;
}

export interface MailMessage {
  to: string;
  subject: string;
  text: string;
  html?: string;
}

export async function sendMail(message: MailMessage): Promise<void> {
  // HTTPS transport. Preferred on container hosts where outbound SMTP is
  // blocked; it also reports failures with a readable body instead of the
  // opaque "connection timeout" that SMTP gives you.
  if (config.MAIL_TRANSPORT === 'resend') {
    const apiKey = config.RESEND_API_KEY;
    if (!apiKey) {
      throw new Error('MAIL_TRANSPORT=resend requires RESEND_API_KEY to be set');
    }
    const from = config.RESEND_FROM ?? config.MAIL_FROM;

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from,
        to: [message.to],
        subject: message.subject,
        text: message.text,
        ...(message.html ? { html: message.html } : {}),
      }),
    });

    if (!res.ok) {
      // Surface the provider's own message — it distinguishes "bad key" from
      // "domain not verified" from "recipient suppressed", which are three
      // completely different problems.
      const body = await res.text().catch(() => '');
      throw new Error(`Resend rejected the message (HTTP ${res.status}): ${body.slice(0, 300)}`);
    }
    return;
  }

  if (config.MAIL_TRANSPORT === 'console') {
    // eslint-disable-next-line no-console
    console.log(
      `\n──── EMAIL (console transport) ────\nTo:      ${message.to}\nSubject: ${message.subject}\n\n${message.text}\n───────────────────────────────────\n`,
    );
    return;
  }

  await getTransporter().sendMail({
    from: config.MAIL_FROM,
    to: message.to,
    subject: message.subject,
    text: message.text,
    html: message.html,
  });
}

// ---------------------------------------------------------------------------
// Templates. Kept plain-text-first: the text part is what most clients
// actually render for transactional codes, and an HTML-only email scores worse
// with spam filters.
// ---------------------------------------------------------------------------

export async function sendOtpEmail(params: {
  to: string;
  code: string;
  purpose: string;
  ttlSeconds: number;
}): Promise<void> {
  const minutes = Math.max(1, Math.round(params.ttlSeconds / 60));
  const purposeLabel = OTP_PURPOSE_LABELS[params.purpose] ?? 'verify your account';

  await sendMail({
    to: params.to,
    subject: `${params.code} is your verification code`,
    text:
      `Your verification code is: ${params.code}\n\n` +
      `Use it to ${purposeLabel}. The code expires in ${minutes} minute${minutes === 1 ? '' : 's'}.\n\n` +
      `If you did not request this, you can safely ignore this email — do not share this code with anyone.`,
  });
}

export async function sendSecurityAlertEmail(params: {
  to: string;
  subject: string;
  body: string;
}): Promise<void> {
  await sendMail({
    to: params.to,
    subject: params.subject,
    text: `${params.body}\n\nIf this was not you, reset your password immediately and review your linked devices.`,
  });
}

const OTP_PURPOSE_LABELS: Record<string, string> = {
  register: 'finish creating your account',
  login: 'sign in',
  reset_password: 'reset your password',
  change_email: 'confirm your new email address',
  change_phone: 'confirm your new phone number',
  verify_phone: 'verify your phone number',
  two_step: 'complete two-step verification',
  delete_account: 'confirm account deletion',
};
