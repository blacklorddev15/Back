import {
  createCipheriv,
  createDecipheriv,
  createHash,
  createHmac,
  hkdfSync,
  randomBytes,
  randomInt,
  scrypt as scryptCb,
  timingSafeEqual,
} from 'node:crypto';
import { promisify } from 'node:util';
import { config } from '../config.js';

const scrypt = promisify(scryptCb) as (
  password: string | Buffer,
  salt: string | Buffer,
  keylen: number,
  options: { N: number; r: number; p: number; maxmem: number },
) => Promise<Buffer>;

// ---------------------------------------------------------------------------
// Passwords — scrypt from node:crypto, deliberately not bcrypt/argon2.
// Those are fine choices but both are native modules, which means a compiler
// on every deploy target. scrypt is memory-hard, built in, and adequate.
// ---------------------------------------------------------------------------

const SCRYPT_PARAMS = { N: 1 << 15, r: 8, p: 1, maxmem: 128 * 1024 * 1024 };
const SCRYPT_KEYLEN = 64;

/** Stored format: scrypt$N$r$p$<salt-hex>$<hash-hex> */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const derived = await scrypt(password.normalize('NFKC'), salt, SCRYPT_KEYLEN, SCRYPT_PARAMS);
  const { N, r, p } = SCRYPT_PARAMS;
  return `scrypt$${N}$${r}$${p}$${salt.toString('hex')}$${derived.toString('hex')}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const N = Number(parts[1]);
  const r = Number(parts[2]);
  const p = Number(parts[3]);
  const salt = Buffer.from(parts[4]!, 'hex');
  const expected = Buffer.from(parts[5]!, 'hex');
  if (!Number.isFinite(N) || !Number.isFinite(r) || !Number.isFinite(p)) return false;

  try {
    const derived = await scrypt(password.normalize('NFKC'), salt, expected.length, {
      N, r, p, maxmem: 128 * 1024 * 1024,
    });
    return timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Tokens
// ---------------------------------------------------------------------------

export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString('base64url');
}

/**
 * Refresh/reset tokens are stored only as hashes, so a database read does not
 * hand out usable sessions. Plain SHA-256 is correct here (unlike for
 * passwords) because the token is 256 bits of entropy — there is nothing to
 * brute force, so no need for a slow KDF.
 */
export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

export function constantTimeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}

// ---------------------------------------------------------------------------
// One-time codes
// ---------------------------------------------------------------------------

export function generateOtp(length = config.OTP_LENGTH): string {
  // randomInt is CSPRNG-backed and uniformly distributed across the range —
  // Math.random() here would be a real vulnerability.
  const max = 10 ** length;
  return randomInt(0, max).toString().padStart(length, '0');
}

/**
 * Codes are HMAC'd with the app secret and the destination address, so the
 * stored value is useless without the secret AND cannot be replayed against a
 * different email address.
 */
export function hashOtp(code: string, destination: string, purpose: string): string {
  return createHmac('sha256', config.JWT_SECRET)
    .update(`${purpose}:${destination.toLowerCase()}:${code}`)
    .digest('hex');
}

export function verifyOtpHash(code: string, destination: string, purpose: string, expectedHash: string): boolean {
  return constantTimeEqual(hashOtp(code, destination, purpose), expectedHash);
}

/** Six-digit app PIN, hashed the same way as a password (it is long-lived). */
export async function hashPin(pin: string): Promise<string> {
  return hashPassword(`pin:${pin}`);
}

export async function verifyPin(pin: string, stored: string): Promise<boolean> {
  return verifyPassword(`pin:${pin}`, stored);
}

// ---------------------------------------------------------------------------
// Short codes for invite links / QR payloads.
// Alphabet excludes 0/O/1/I/L so a code read aloud or typed from a screenshot
// does not fail on ambiguous glyphs.
// ---------------------------------------------------------------------------
const CODE_ALPHABET = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';

export function shortCode(length = 10): string {
  let out = '';
  for (let i = 0; i < length; i += 1) {
    out += CODE_ALPHABET[randomInt(0, CODE_ALPHABET.length)];
  }
  return out;
}

// ---------------------------------------------------------------------------
// At-rest encryption for anything sensitive that must be readable by the
// server (e.g. a TURN credential, a stored provider token).
//
// Key is derived from JWT_SECRET via HKDF with a distinct label, so rotating
// the signing key also rotates this — acceptable for now, but if you later
// need to rotate one without the other, promote this to its own env var.
// ---------------------------------------------------------------------------
const AT_REST_KEY = Buffer.from(hkdfSync('sha256', config.JWT_SECRET, 'chat-backend', 'at-rest-encryption', 32));

/** AES-256-GCM. Returns base64url(iv | tag | ciphertext). */
export function encryptSecret(plaintext: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', AT_REST_KEY, iv);
  const enc = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), enc]).toString('base64url');
}

export function decryptSecret(payload: string): string {
  const raw = Buffer.from(payload, 'base64url');
  const iv = raw.subarray(0, 12);
  const tag = raw.subarray(12, 28);
  const data = raw.subarray(28);
  const decipher = createDecipheriv('aes-256-gcm', AT_REST_KEY, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
}

/** Deterministic key for "only one direct chat per pair of users". */
export function directChatKey(userA: string, userB: string): string {
  const [a, b] = [userA, userB].sort();
  return `direct:${a}:${b}`;
}
