import { createHash, createHmac } from 'node:crypto';
import { config } from '../config.js';

/**
 * Minimal AWS SigV4 signer for a single PUT.
 *
 * Why not @aws-sdk/client-s3: the SDK is tens of megabytes of dependency for
 * one operation. This implements exactly the subset needed — a single-object
 * upload to any S3-compatible endpoint (AWS, Cloudflare R2, Backblaze B2,
 * MinIO) — which is a well-specified algorithm.
 *
 * LIMITS, stated honestly: this signs a single PUT with a known body length.
 * It does NOT implement multipart upload, so a very large video that needs
 * chunked/resumable upload requires the SDK instead. The size cap in
 * MEDIA_MAX_UPLOAD_BYTES is what keeps that from being a problem in practice.
 *
 * Reference: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv4-signing-elements.html
 */

function sha256Hex(data: string | Buffer): string {
  return createHash('sha256').update(data).digest('hex');
}

function hmac(key: Buffer | string, data: string): Buffer {
  return createHmac('sha256', key).update(data).digest();
}

function amzDate(): { dateTime: string; date: string } {
  // Format: 20130524T000000Z
  const dateTime = new Date().toISOString().replace(/[:-]|\.\d{3}/g, '');
  return { dateTime, date: dateTime.slice(0, 8) };
}

/**
 * Percent-encode per RFC 3986, which differs from encodeURIComponent: it must
 * escape ! ' ( ) * as well. Getting this wrong produces a signature mismatch
 * that is genuinely painful to debug.
 */
function encodeRfc3986(value: string): string {
  return encodeURIComponent(value).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}

function canonicalUri(key: string): string {
  return `/${key
    .split('/')
    .map((segment) => encodeRfc3986(segment))
    .join('/')}`;
}

export async function signS3Put(params: {
  key: string;
  mimeType: string;
  body: Buffer;
}): Promise<string> {
  const accessKey = config.S3_ACCESS_KEY_ID;
  const secretKey = config.S3_SECRET_ACCESS_KEY;
  const region = config.S3_REGION;
  const bucket = config.S3_BUCKET;
  const endpoint = config.S3_ENDPOINT;

  if (!accessKey || !secretKey || !region || !bucket || !endpoint) {
    throw new Error('S3 credentials are incomplete: S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, S3_REGION, S3_BUCKET and S3_ENDPOINT are all required');
  }

  const url = new URL(`${endpoint.replace(/\/$/, '')}/${bucket}/${params.key}`);
  const host = url.host;
  const { dateTime, date } = amzDate();
  const payloadHash = sha256Hex(params.body);
  const contentType = params.mimeType;

  const canonicalHeaders =
    `content-type:${contentType}\n` + `host:${host}\n` + `x-amz-content-sha256:${payloadHash}\n` + `x-amz-date:${dateTime}\n`;
  const signedHeaders = 'content-type;host;x-amz-content-sha256;x-amz-date';

  const canonicalRequest = [
    'PUT',
    canonicalUri(`${bucket}/${params.key}`),
    '', // no query string
    canonicalHeaders,
    signedHeaders,
    payloadHash,
  ].join('\n');

  const scope = `${date}/${region}/s3/aws4_request`;
  const stringToSign = ['AWS4-HMAC-SHA256', dateTime, scope, sha256Hex(canonicalRequest)].join('\n');

  const kDate = hmac(`AWS4${secretKey}`, date);
  const kRegion = hmac(kDate, region);
  const kService = hmac(kRegion, 's3');
  const kSigning = hmac(kService, 'aws4_request');
  const signature = createHmac('sha256', kSigning).update(stringToSign).digest('hex');

  const authorization =
    `AWS4-HMAC-SHA256 Credential=${accessKey}/${scope}, ` +
    `SignedHeaders=${signedHeaders}, Signature=${signature}`;

  return url.toString() + `#headers=${encodeRfc3986(authorization)}&x-amz-date=${dateTime}&x-amz-content-sha256=${payloadHash}`;
}
