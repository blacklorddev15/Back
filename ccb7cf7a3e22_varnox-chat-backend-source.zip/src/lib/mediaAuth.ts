import type { FastifyRequest } from 'fastify';
import { ErrorCodes, forbidden, unauthorized } from './errors.js';
import { verifyAccessToken } from './jwt.js';

/**
 * Identifies the user asking for a media file.
 *
 * Extracted from the attachment route so the status-media route can use the
 * same rules rather than a second, subtly different copy — the two must agree
 * about what a valid caller looks like.
 *
 * A token is accepted from the query string as well as the Authorization
 * header because React Native's `<Image>` cannot reliably carry a header across
 * platforms. That is the same trade-off the WebSocket endpoint already makes;
 * access tokens are short-lived, which bounds how long a leaked URL stays
 * useful.
 */
export async function authenticateForMedia(request: FastifyRequest): Promise<string> {
  const header = request.headers.authorization;
  const query = request.query as { token?: string } | undefined;
  const token = header?.startsWith('Bearer ') ? header.slice(7).trim() : query?.token;

  if (!token) throw unauthorized(ErrorCodes.TOKEN_EXPIRED, 'A token is required to read attachments');

  const verified = verifyAccessToken(token);
  if (!verified.ok) {
    throw unauthorized(
      verified.reason === 'expired' ? ErrorCodes.TOKEN_EXPIRED : 'unauthorized',
      verified.reason === 'expired' ? 'Attachment link expired — reopen the conversation' : 'Invalid token',
    );
  }
  if (verified.claims.stage !== 'full') {
    throw forbidden(ErrorCodes.TWO_STEP_REQUIRED, 'Two-step verification is required');
  }
  return verified.claims.sub;
}
