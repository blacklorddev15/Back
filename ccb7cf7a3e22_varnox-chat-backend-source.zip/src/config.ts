import 'dotenv/config';
import { z } from 'zod';

/**
 * Container hosts tell you which port to bind rather than letting you choose.
 * Pterodactyl injects SERVER_PORT (the port it has actually mapped and opened
 * on the host); binding anywhere else means the panel's port looks dead even
 * though the process is running happily on 8080.
 *
 * SERVER_PORT therefore wins outright when it is present. It is only ever set by
 * the host, and the host's port is the only one reachable from outside, so a
 * PORT left over in a config file is always the wrong answer in that situation.
 * Local development never sets SERVER_PORT, so PORT still works there.
 */
if (process.env.SERVER_PORT) {
  if (process.env.PORT && process.env.PORT !== process.env.SERVER_PORT) {
    // eslint-disable-next-line no-console
    console.warn(
      `[config] ignoring PORT=${process.env.PORT} in favour of the host-provided SERVER_PORT=${process.env.SERVER_PORT}`,
    );
  }
  process.env.PORT = process.env.SERVER_PORT;
}

/**
 * All environment parsing lives here so that a misconfiguration fails at boot
 * with a readable message rather than at 3am on the first request that happens
 * to touch a missing variable.
 */
const bool = (def: boolean) =>
  z
    .string()
    .optional()
    .transform((v) => (v === undefined || v === '' ? def : ['1', 'true', 'yes', 'on'].includes(v.toLowerCase())));

const int = (def: number) =>
  z
    .string()
    .optional()
    .transform((v) => (v === undefined || v === '' ? def : Number(v)))
    .pipe(z.number().int());

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: int(8080),
  HOST: z.string().default('0.0.0.0'),
  /**
   * Optional path for a persistent JSON log. Hosts like Pterodactyl do not
   * expose container stdout, so without this a 500 is invisible — you get
   * "Something went wrong" and no way to find out what. Set LOG_FILE to a path
   * inside the server directory (e.g. ./var/app.log) and read it through the
   * panel's file manager.
   */
  LOG_FILE: z.string().optional(),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  CORS_ORIGINS: z.string().default('*'),

  // Database. DATABASE_URL is the pooled endpoint used by the API;
  // DATABASE_URL_DIRECT bypasses the pooler and is used only for migrations.
  DATABASE_URL: z.string().min(1, 'DATABASE_URL is required'),
  DATABASE_URL_DIRECT: z.string().optional(),
  /**
   * Extra databases to fall back to, in preference order, separated by
   * semicolons or commas. Consulted ONLY when DATABASE_FAILOVER is true, so a
   * stray value here can never silently redirect traffic on its own.
   */
  DATABASE_URLS: z.string().optional(),
  /**
   * Lets the backend start against a fallback database when the primary is
   * unreachable or under-migrated. Off by default: choosing a database is a
   * data decision, not merely an availability one — see db/pool.ts.
   */
  DATABASE_FAILOVER: bool(false),
  DB_IS_POOLED: bool(false),
  DB_SSL: bool(false),
  DB_POOL_MAX: int(10),
  DB_IDLE_TIMEOUT_MS: int(30_000),

  JWT_SECRET: z.string().min(16, 'JWT_SECRET must be at least 16 characters — generate one with `openssl rand -base64 48`'),
  ACCESS_TOKEN_TTL_SECONDS: int(900),
  REFRESH_TOKEN_TTL_DAYS: int(60),

  OTP_LENGTH: int(6),
  OTP_TTL_SECONDS: int(600),
  OTP_MAX_ATTEMPTS: int(5),
  OTP_RESEND_COOLDOWN_SECONDS: int(60),
  OTP_MAX_PER_HOUR: int(8),

  PASSWORD_MIN_LENGTH: int(8),
  PIN_LENGTH: int(6),

  /**
   * 'resend' posts to Resend's HTTPS API on port 443.
   *
   * This matters on game/container hosts: outbound SMTP (25/465/587) is very
   * commonly blocked at the network edge to stop the node being used as a spam
   * relay. HTTPS is never blocked, so the API transport keeps working where
   * SMTP silently fails.
   */
  MAIL_TRANSPORT: z.enum(['console', 'smtp', 'resend']).default('console'),
  MAIL_FROM: z.string().default('My App <no-reply@example.com>'),
  RESEND_API_KEY: z.string().optional(),
  RESEND_FROM: z.string().optional(),
  SMTP_HOST: z.string().optional(),
  SMTP_PORT: int(587),
  SMTP_SECURE: bool(false),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),

  MEDIA_DRIVER: z.enum(['local', 's3']).default('local'),
  MEDIA_LOCAL_DIR: z.string().default('./var/media'),
  MEDIA_PUBLIC_BASE_URL: z.string().default('http://localhost:8080/media'),
  MEDIA_MAX_UPLOAD_BYTES: int(52_428_800),
  S3_BUCKET: z.string().optional(),
  S3_REGION: z.string().optional(),
  S3_ENDPOINT: z.string().optional(),
  S3_ACCESS_KEY_ID: z.string().optional(),
  S3_SECRET_ACCESS_KEY: z.string().optional(),

  PUSH_ENABLED: bool(false),
  EXPO_PUSH_URL: z.string().default('https://exp.host/--/api/v2/push/send'),

  // Only used by `npm run seed:admin` to bootstrap the first superadmin.
  SUPERADMIN_EMAIL: z.string().optional(),
  SUPERADMIN_PASSWORD: z.string().optional(),
});

const parsed = schema.safeParse(process.env);

if (!parsed.success) {
  const issues = parsed.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`).join('\n');
  // eslint-disable-next-line no-console
  console.error(`Invalid environment configuration:\n${issues}\n\nCopy .env.example to .env and fill it in.`);
  process.exit(1);
}

const env = parsed.data;

export const config = {
  ...env,
  isProduction: env.NODE_ENV === 'production',
  isTest: env.NODE_ENV === 'test',
  directDatabaseUrl: env.DATABASE_URL_DIRECT || env.DATABASE_URL,
  corsOrigins: env.CORS_ORIGINS === '*' ? true : env.CORS_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean),
} as const;

export type Config = typeof config;

/**
 * Refuse to start in production with development secrets. Shipping a default
 * JWT secret is one of the few mistakes that is both trivially avoidable and
 * catastrophic — anyone can mint admin tokens.
 */
if (config.isProduction) {
  const problems: string[] = [];
  if (config.JWT_SECRET.includes('dev-only') || config.JWT_SECRET.includes('change-me')) {
    problems.push('JWT_SECRET is still a placeholder value');
  }
  if (config.MAIL_TRANSPORT === 'console') {
    problems.push('MAIL_TRANSPORT=console means OTP codes are printed to logs instead of sent');
  }
  if (problems.length > 0) {
    // eslint-disable-next-line no-console
    console.error(`Refusing to start in production:\n${problems.map((p) => `  - ${p}`).join('\n')}`);
    process.exit(1);
  }
}
