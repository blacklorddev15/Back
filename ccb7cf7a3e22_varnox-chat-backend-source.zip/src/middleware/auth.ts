import type { FastifyReply, FastifyRequest, preHandlerHookHandler } from 'fastify';
import { AppError, ErrorCodes, forbidden, unauthorized } from '../lib/errors.js';
import { verifyAccessToken } from '../lib/jwt.js';
import { getAdminRole } from '../services/auth.service.js';

/**
 * Authentication middleware.
 *
 * Two things worth calling out:
 *
 *  - A token with `stage: 'two_step'` is NOT an authenticated session. It only
 *    proves the password was correct. Rejecting it here is what makes the PIN
 *    meaningful — see the note in lib/jwt.ts.
 *
 *  - The admin role is read from the database on every request rather than
 *    trusted from the token. Tokens live for 15 minutes, and a revoked admin
 *    must lose access immediately, not when their token happens to expire.
 */

export interface AuthContext {
  userId: string;
  sessionId: string;
  deviceId?: string;
  role: string | null;
}

declare module 'fastify' {
  interface FastifyRequest {
    auth?: AuthContext;
  }
}

export const requireAuth: preHandlerHookHandler = async (request: FastifyRequest) => {
  const header = request.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    throw unauthorized('unauthorized', 'Missing bearer token');
  }

  const result = verifyAccessToken(header.slice('Bearer '.length).trim());
  if (!result.ok) {
    const message =
      result.reason === 'expired'
        ? 'Access token expired'
        : result.reason === 'wrong_type'
          ? 'Invalid token type'
          : 'Invalid access token';
    throw unauthorized(result.reason === 'expired' ? ErrorCodes.TOKEN_EXPIRED : 'unauthorized', message);
  }

  if (result.claims.stage !== 'full') {
    throw forbidden(ErrorCodes.TWO_STEP_REQUIRED, 'Two-step verification is required to complete sign-in');
  }

  // Confirm the session still exists and has not been revoked. Skipping this
  // would make "log out my other devices" ineffective until tokens expire.
  const { queryOne } = await import('../db/pool.js');
  const session = await queryOne<{ revoked_at: Date | null }>(
    `SELECT revoked_at FROM sessions WHERE id = $1`,
    [result.claims.sid],
  );
  if (!session || session.revoked_at) {
    throw unauthorized(ErrorCodes.SESSION_REVOKED, 'This session has ended. Sign in again.');
  }

  request.auth = {
    userId: result.claims.sub,
    sessionId: result.claims.sid,
    deviceId: result.claims.did,
    role: result.claims.role ?? null,
  };
};

/** For routes that a suspended account must not reach even with a valid token. */
export const requireActiveAccount: preHandlerHookHandler = async (request: FastifyRequest) => {
  if (!request.auth) throw unauthorized();
  const { queryOne } = await import('../db/pool.js');
  const row = await queryOne<{ status: string; deletion_scheduled_for: Date | null }>(
    `SELECT status, deletion_scheduled_for FROM users WHERE id = $1 AND deleted_at IS NULL`,
    [request.auth.userId],
  );
  if (!row) throw unauthorized(ErrorCodes.SESSION_REVOKED, 'Account no longer exists');
  if (row.status === 'suspended') {
    throw forbidden(ErrorCodes.ACCOUNT_SUSPENDED, 'This account is suspended');
  }
};

const ROLE_RANK: Record<string, number> = { support: 1, moderator: 2, admin: 3, superadmin: 4 };

/** Admin gate. Usage: `{ preHandler: [requireAuth, requireAdmin('moderator')] }` */
export function requireAdmin(minimum: keyof typeof ROLE_RANK = 'support'): preHandlerHookHandler {
  return async (request: FastifyRequest) => {
    if (!request.auth) throw unauthorized();

    const role = await getAdminRole(request.auth.userId);
    if (!role) throw forbidden(ErrorCodes.FORBIDDEN_ACTION, 'Administrator access required');

    if ((ROLE_RANK[role] ?? 0) < (ROLE_RANK[minimum] ?? 0)) {
      throw forbidden(ErrorCodes.FORBIDDEN_ACTION, `This action requires the ${minimum} role or higher`);
    }
    request.auth.role = role;
  };
}

/** Helper for handlers: narrow away the optional auth without a non-null assertion. */
export function authOf(request: FastifyRequest): AuthContext {
  if (!request.auth) throw unauthorized();
  return request.auth;
}

export function clientIp(request: FastifyRequest): string | undefined {
  // Behind a reverse proxy, the socket address is the proxy's. Fastify only
  // trusts X-Forwarded-For when `trustProxy` is enabled (see src/index.ts), so
  // this is safe to read here.
  return request.ip;
}

export function userAgent(request: FastifyRequest): string | undefined {
  const ua = request.headers['user-agent'];
  return typeof ua === 'string' ? ua.slice(0, 500) : undefined;
}

export { AppError };
