-- ===========================================================================
-- 004_communities_channels_status.sql
-- Communities, channels, status/stories — plus the deferred FK from chats,
-- which could not reference communities in migration 003 because the table
-- did not exist yet.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Communities: a container of groups, with one announcement group on top.
-- ---------------------------------------------------------------------------
CREATE TABLE communities (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                  text NOT NULL,
  description           text,
  image_url             text,
  owner_id              uuid REFERENCES users(id) ON DELETE SET NULL,

  -- The read-only group every member is in, for community-wide announcements.
  announcement_chat_id  uuid REFERENCES chats(id) ON DELETE SET NULL,

  who_can_create_groups text NOT NULL DEFAULT 'admins'   CHECK (who_can_create_groups IN ('everyone','admins')),
  who_can_send         text NOT NULL DEFAULT 'admins'    CHECK (who_can_send         IN ('everyone','admins')),
  is_verified           boolean NOT NULL DEFAULT false,

  member_count          integer NOT NULL DEFAULT 0,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  deleted_at            timestamptz
);

CREATE TRIGGER communities_set_updated_at
  BEFORE UPDATE ON communities
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Deferred foreign keys from migration 003.
ALTER TABLE chats
  ADD CONSTRAINT chats_community_fk
  FOREIGN KEY (community_id) REFERENCES communities(id) ON DELETE SET NULL;

CREATE TABLE community_topics (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id  uuid NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  name          text NOT NULL,
  position      smallint NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (community_id, name)
);

ALTER TABLE chats
  ADD CONSTRAINT chats_community_topic_fk
  FOREIGN KEY (community_topic_id) REFERENCES community_topics(id) ON DELETE SET NULL;

CREATE TABLE community_members (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id  uuid NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role          text NOT NULL DEFAULT 'member' CHECK (role IN ('member','admin','owner')),
  joined_at     timestamptz NOT NULL DEFAULT now(),
  left_at       timestamptz,
  UNIQUE (community_id, user_id)
);

CREATE INDEX community_members_user_idx ON community_members (user_id) WHERE left_at IS NULL;

CREATE TABLE community_invites (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id  uuid NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  code          text NOT NULL UNIQUE,
  created_by    uuid REFERENCES users(id) ON DELETE SET NULL,
  expires_at    timestamptz,
  revoked_at    timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- ===========================================================================
-- Channels (one-to-many broadcast to followers; posts are not messages)
-- ===========================================================================
CREATE TABLE channels (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  handle         text UNIQUE,
  name           text NOT NULL,
  description    text,
  photo_url      text,
  owner_id       uuid REFERENCES users(id) ON DELETE SET NULL,
  category       text,
  language_code  text NOT NULL DEFAULT 'en',

  is_verified    boolean NOT NULL DEFAULT false,
  verified_at    timestamptz,
  is_sponsored   boolean NOT NULL DEFAULT false,
  sponsor_label  text,
  is_public      boolean NOT NULL DEFAULT true,
  is_directory_listed boolean NOT NULL DEFAULT true,

  follower_count integer NOT NULL DEFAULT 0,
  post_count     integer NOT NULL DEFAULT 0,

  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  deleted_at     timestamptz
);

CREATE INDEX channels_directory_idx ON channels (category, follower_count DESC) WHERE deleted_at IS NULL AND is_public;
CREATE INDEX channels_owner_idx     ON channels (owner_id) WHERE deleted_at IS NULL;

CREATE TRIGGER channels_set_updated_at
  BEFORE UPDATE ON channels
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE channel_subscribers (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id      uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id         uuid NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  role            text NOT NULL DEFAULT 'follower' CHECK (role IN ('follower','admin','owner')),
  is_muted        boolean NOT NULL DEFAULT false,
  notifications_enabled boolean NOT NULL DEFAULT true,
  -- Watermark so "N new posts" is a cheap comparison, not a COUNT(*).
  last_read_post_seq bigint NOT NULL DEFAULT 0,
  joined_at       timestamptz NOT NULL DEFAULT now(),
  left_at         timestamptz,
  UNIQUE (channel_id, user_id)
);

CREATE INDEX channel_subs_user_idx ON channel_subscribers (user_id) WHERE left_at IS NULL;

CREATE TABLE channel_posts (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seq          bigserial NOT NULL,
  channel_id   uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  author_id    uuid REFERENCES users(id) ON DELETE SET NULL,
  type         text NOT NULL DEFAULT 'text' CHECK (type IN ('text','image','video','audio','poll','forwarded')),
  body         text,
  metadata     jsonb NOT NULL DEFAULT '{}'::jsonb,
  poll_id      uuid REFERENCES polls(id) ON DELETE SET NULL,
  forwarded_from_channel_id uuid REFERENCES channels(id) ON DELETE SET NULL,
  is_pinned    boolean NOT NULL DEFAULT false,
  edited_at    timestamptz,
  is_deleted   boolean NOT NULL DEFAULT false,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX channel_posts_channel_idx ON channel_posts (channel_id, seq DESC);

CREATE TRIGGER channel_posts_set_updated_at
  BEFORE UPDATE ON channel_posts
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE channel_post_reactions (
  post_id    uuid NOT NULL REFERENCES channel_posts(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  emoji      text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (post_id, user_id, emoji)
);

CREATE TABLE channel_post_attachments (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id    uuid NOT NULL REFERENCES channel_posts(id) ON DELETE CASCADE,
  kind       text NOT NULL CHECK (kind IN ('image','video','audio','document')),
  mime_type  text NOT NULL,
  storage_key text NOT NULL,
  public_url text,
  byte_size  bigint NOT NULL DEFAULT 0,
  width      integer,
  height     integer,
  duration_ms integer,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE channel_verification_requests (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id   uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  requested_by uuid REFERENCES users(id) ON DELETE SET NULL,
  status       text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  evidence     jsonb NOT NULL DEFAULT '{}'::jsonb,
  reviewed_by  uuid REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at  timestamptz,
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- ===========================================================================
-- Status / stories (24-hour ephemeral posts)
-- ===========================================================================
CREATE TABLE statuses (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type           text NOT NULL CHECK (type IN ('text','image','video','gif','voice')),
  body           text,
  caption        text,
  link_url       text,
  music_title    text,
  music_url      text,
  background_color text,
  metadata       jsonb NOT NULL DEFAULT '{}'::jsonb,

  -- Set when the status is a reshare of someone else's mention
  reshared_status_id uuid REFERENCES statuses(id) ON DELETE SET NULL,

  created_at     timestamptz NOT NULL DEFAULT now(),
  -- Always created_at + 24h; stored explicitly so the retention rule can
  -- change without rewriting history.
  expires_at     timestamptz NOT NULL DEFAULT (now() + interval '24 hours'),
  deleted_at     timestamptz
);

CREATE INDEX statuses_user_idx    ON statuses (user_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX statuses_expiry_idx  ON statuses (expires_at) WHERE deleted_at IS NULL;

CREATE TABLE status_attachments (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status_id   uuid NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
  kind        text NOT NULL CHECK (kind IN ('image','video','voice','gif')),
  mime_type   text NOT NULL,
  storage_key text NOT NULL,
  public_url  text,
  thumbnail_url text,
  byte_size   bigint NOT NULL DEFAULT 0,
  duration_ms integer,
  width       integer,
  height      integer
);

-- Explicit audience rules. mode='include' is the "share with selected
-- contacts" list; mode='exclude' is "hide from selected contacts". Having both
-- as rows (rather than a mode column on the status) lets one status be edited
-- without rewriting the audience decision.
CREATE TABLE status_audience (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status_id   uuid NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  mode        text NOT NULL CHECK (mode IN ('include','exclude')),
  UNIQUE (status_id, user_id)
);

CREATE TABLE status_views (
  status_id uuid NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
  viewer_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  viewed_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (status_id, viewer_id)
);

CREATE TABLE status_reactions (
  status_id  uuid NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  emoji      text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (status_id, user_id, emoji)
);

-- A reply to a status is a normal direct message plus this link row.
CREATE TABLE status_replies (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status_id  uuid NOT NULL REFERENCES statuses(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message_id uuid REFERENCES messages(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX status_replies_status_idx ON status_replies (status_id, created_at DESC);
