-- ===========================================================================
-- 006_notifications_moderation.sql — notifications, moderation, admin, search
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Notifications (durable record + delivery tracking)
-- ---------------------------------------------------------------------------
CREATE TABLE notifications (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type        text NOT NULL CHECK (type IN (
                'message','group_message','channel_post','status','mention','reaction',
                'reply','voice_call','video_call','missed_call','join_request',
                'group_invite','community_invite','channel_update','order_update',
                'payment','security','system','moderation','report_update','follow')),
  title       text,
  body        text,
  -- What to open when tapped
  target_type text,
  target_id   text,
  metadata    jsonb NOT NULL DEFAULT '{}'::jsonb,
  priority    smallint NOT NULL DEFAULT 3 CHECK (priority BETWEEN 1 AND 5),
  read_at     timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- The chat-list badge and the notification tray both hit this index.
CREATE INDEX notifications_unread_idx ON notifications (user_id, created_at DESC) WHERE read_at IS NULL;
CREATE INDEX notifications_user_idx   ON notifications (user_id, created_at DESC);

-- One row per device per notification, so "delivered to which device" and
-- retry state are answerable.
CREATE TABLE notification_deliveries (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  notification_id uuid NOT NULL REFERENCES notifications(id) ON DELETE CASCADE,
  device_id       uuid REFERENCES devices(id) ON DELETE CASCADE,
  channel         text NOT NULL DEFAULT 'push' CHECK (channel IN ('push','email','in_app','sms')),
  status          text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','delivered','failed','skipped')),
  attempts        smallint NOT NULL DEFAULT 0,
  provider_ref    text,
  error           text,
  sent_at         timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX notif_deliveries_pending_idx ON notification_deliveries (status, created_at) WHERE status = 'pending';

-- ===========================================================================
-- Moderation
-- ===========================================================================
CREATE TABLE moderation_actions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  moderator_id uuid REFERENCES users(id) ON DELETE SET NULL,
  target_type  text NOT NULL CHECK (target_type IN ('user','message','group','channel','community','status','business')),
  target_id    text NOT NULL,
  action       text NOT NULL CHECK (action IN (
                 'warn','remove_content','suspend','unsuspend','ban','unban',
                 'verify','unverify','reset_account','restrict_features','unrestrict')),
  reason       text,
  duration_days integer,
  expires_at   timestamptz,
  metadata     jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX moderation_target_idx ON moderation_actions (target_type, target_id, created_at DESC);

CREATE TABLE user_suspensions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  suspended_by uuid REFERENCES users(id) ON DELETE SET NULL,
  reason       text NOT NULL,
  category     text CHECK (category IN ('spam','scam','abuse','impersonation','policy','legal','other')),
  expires_at   timestamptz,
  lifted_at    timestamptz,
  lifted_by    uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX suspensions_active_idx ON user_suspensions (user_id) WHERE lifted_at IS NULL;

-- Automated abuse signals. Written by heuristics, read by moderators.
CREATE TABLE abuse_signals (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_type text NOT NULL CHECK (subject_type IN ('user','message','chat','channel','business')),
  subject_id  text NOT NULL,
  signal      text NOT NULL,
  score       numeric(5,4) NOT NULL DEFAULT 0,
  details     jsonb NOT NULL DEFAULT '{}'::jsonb,
  resolved_at timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX abuse_signals_open_idx ON abuse_signals (subject_type, subject_id) WHERE resolved_at IS NULL;
CREATE INDEX abuse_signals_score_idx ON abuse_signals (score DESC) WHERE resolved_at IS NULL;

-- Domain reputation for the "suspicious link warnings" feature.
CREATE TABLE link_reputation (
  domain       text PRIMARY KEY,
  verdict      text NOT NULL DEFAULT 'unknown' CHECK (verdict IN ('unknown','safe','suspicious','malicious')),
  reason       text,
  checked_at   timestamptz NOT NULL DEFAULT now()
);

-- Persistent rate limiting. In-memory buckets handle hot paths; this table
-- survives restarts and gives moderators a history to look at.
CREATE TABLE rate_limit_counters (
  bucket       text NOT NULL,
  subject      text NOT NULL,
  window_start timestamptz NOT NULL,
  count        integer NOT NULL DEFAULT 0,
  PRIMARY KEY (bucket, subject, window_start)
);

CREATE INDEX rate_limit_window_idx ON rate_limit_counters (window_start);

-- Supporting tables, because moderation without them is unusable.
CREATE TABLE spam_flags (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  flagged_by   uuid REFERENCES users(id) ON DELETE SET NULL,
  reason       text NOT NULL,
  auto_detected boolean NOT NULL DEFAULT false,
  resolved_at  timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX spam_flags_user_idx ON spam_flags (user_id) WHERE resolved_at IS NULL;

-- ---------------------------------------------------------------------------
-- Support tickets
-- ---------------------------------------------------------------------------
CREATE TABLE support_tickets (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid REFERENCES users(id) ON DELETE SET NULL,
  subject     text NOT NULL,
  category    text,
  status      text NOT NULL DEFAULT 'open' CHECK (status IN ('open','pending_user','pending_staff','resolved','closed')),
  priority    smallint NOT NULL DEFAULT 3 CHECK (priority BETWEEN 1 AND 5),
  assigned_to uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX tickets_status_idx ON support_tickets (status, priority, created_at);

CREATE TRIGGER tickets_set_updated_at
  BEFORE UPDATE ON support_tickets
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE ticket_messages (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id  uuid NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  author_id  uuid REFERENCES users(id) ON DELETE SET NULL,
  is_staff   boolean NOT NULL DEFAULT false,
  body       text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX ticket_messages_idx ON ticket_messages (ticket_id, created_at);

-- ---------------------------------------------------------------------------
-- System announcements (admin broadcast to the whole user base)
-- ---------------------------------------------------------------------------
CREATE TABLE system_announcements (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title        text NOT NULL,
  body         text NOT NULL,
  audience     text NOT NULL DEFAULT 'all' CHECK (audience IN ('all','android','ios','web','suspended','business')),
  severity     text NOT NULL DEFAULT 'info' CHECK (severity IN ('info','warning','critical')),
  published_at timestamptz,
  expires_at   timestamptz,
  created_by   uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX announcements_live_idx ON system_announcements (published_at DESC) WHERE published_at IS NOT NULL;

-- ===========================================================================
-- Search support
-- ===========================================================================
-- Full-text search over message bodies.
--
-- The 'simple' configuration is used deliberately: this app is multilingual,
-- and 'simple' performs no language-specific stemming — which is wrong for
-- English but never *badly* wrong for any language. Swap to per-language
-- columns later if search quality demands it.
--
-- Generated columns must use an IMMUTABLE expression, and to_tsvector with a
-- literal config qualifies.
ALTER TABLE messages
  ADD COLUMN search_vector tsvector
  GENERATED ALWAYS AS (to_tsvector('simple', coalesce(body, ''))) STORED;

CREATE INDEX messages_search_idx ON messages USING GIN (search_vector);

-- pg_trgm must exist BEFORE any trigram index is created, so this block runs
-- first. It is guarded because CREATE EXTENSION needs privileges that some
-- managed Postgres roles do not have; if it fails we still get full-text
-- search, and substring matching degrades to an unindexed ILIKE.
DO $$
BEGIN
  CREATE EXTENSION IF NOT EXISTS pg_trgm;
EXCEPTION WHEN insufficient_privilege OR feature_not_supported THEN
  RAISE NOTICE 'pg_trgm unavailable; substring search will use ILIKE without an index';
END;
$$;

-- Trigram indexes power substring / typo-tolerant matching for search.
DO $$
BEGIN
  CREATE INDEX IF NOT EXISTS messages_body_trgm_idx ON messages USING GIN (body gin_trgm_ops);
  CREATE INDEX IF NOT EXISTS users_username_trgm_idx ON users USING GIN (lower(username) gin_trgm_ops);
  CREATE INDEX IF NOT EXISTS channel_name_trgm_idx ON channels USING GIN (lower(name) gin_trgm_ops);
EXCEPTION WHEN undefined_object THEN
  RAISE NOTICE 'pg_trgm operator class missing; skipping trigram indexes';
END;
$$;

-- ---------------------------------------------------------------------------
-- Reporting helpers
-- ---------------------------------------------------------------------------
-- Unread counts. Computing this with COUNT(*) over messages per chat is a
-- classic performance trap; comparing the member's read watermark against the
-- chat's last seq makes it a subtraction.
CREATE OR REPLACE VIEW chat_unread_counts AS
SELECT
  cm.chat_id,
  cm.user_id,
  -- NULLIF guards the empty-chat case so we do not count the seq 0 baseline.
  GREATEST(0, COALESCE(m.max_seq, 0) - cm.last_read_seq) AS unread_count
FROM chat_members cm
LEFT JOIN LATERAL (
  SELECT max(seq) AS max_seq
  FROM messages
  WHERE messages.chat_id = cm.chat_id AND messages.is_deleted = false
) m ON true
WHERE cm.left_at IS NULL;

-- Admin dashboard counters, in one place so the numbers cannot drift apart.
CREATE OR REPLACE VIEW admin_platform_stats AS
SELECT
  (SELECT count(*) FROM users WHERE deleted_at IS NULL)                          AS total_users,
  (SELECT count(*) FROM users WHERE deleted_at IS NULL AND status = 'active')    AS active_users,
  (SELECT count(*) FROM users WHERE deleted_at IS NULL AND status = 'suspended') AS suspended_users,
  (SELECT count(*) FROM users WHERE last_seen_at > now() - interval '24 hours')  AS dau,
  (SELECT count(*) FROM users WHERE last_seen_at > now() - interval '30 days')   AS mau,
  (SELECT count(*) FROM chats WHERE deleted_at IS NULL AND type = 'group')       AS total_groups,
  (SELECT count(*) FROM channels WHERE deleted_at IS NULL)                       AS total_channels,
  (SELECT count(*) FROM communities WHERE deleted_at IS NULL)                    AS total_communities,
  (SELECT count(*) FROM messages WHERE is_deleted = false)                       AS total_messages,
  (SELECT count(*) FROM messages WHERE created_at > now() - interval '24 hours') AS messages_24h,
  (SELECT count(*) FROM calls WHERE started_at > now() - interval '24 hours')    AS calls_24h,
  (SELECT count(*) FROM reports WHERE status = 'open')                           AS open_reports,
  (SELECT count(*) FROM support_tickets WHERE status IN ('open','pending_staff')) AS open_tickets;
