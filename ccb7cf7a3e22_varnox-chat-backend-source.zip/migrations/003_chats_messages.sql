-- ===========================================================================
-- 003_chats_messages.sql — conversations, messages, receipts, media, polls
-- ===========================================================================
--
-- Two deliberate design choices worth stating up front.
--
-- 1. ORDERING. Messages carry a global bigserial `seq` in addition to their
--    uuid. UUIDv4 has no order, so paginating a conversation by timestamp
--    breaks on ties (very common — two messages in the same millisecond) and
--    makes "messages since X" unreliable. A monotonic seq gives stable,
--    gap-tolerant pagination and a cheap cursor.
--
-- 2. READ STATE. Real messaging products do NOT store one receipt row per
--    (message, recipient) for group chats — a 500-member group with 1,000
--    messages would need 500,000 rows to answer "what is the tick state".
--    Instead each membership carries a read/delivered watermark
--    (chat_members.last_read_seq), which answers unread counts and group tick
--    state in O(1) reads. The message_receipts table is kept for the cases
--    that genuinely need per-user facts: direct chats, and "who has read
--    this" in a group.
-- ===========================================================================

CREATE TABLE chats (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type                text NOT NULL CHECK (type IN (
                        'direct','group','community_announcement','community_group','channel_discussion')),
  title               text,
  description         text,
  photo_url           text,

  created_by          uuid REFERENCES users(id) ON DELETE SET NULL,

  -- Set for community-owned chats. The FK to communities is added in
  -- migration 004, because that table does not exist yet at this point.
  community_id        uuid,
  community_topic_id  uuid,

  -- Group policies (the "restrict who can..." checklist items)
  who_can_send        text NOT NULL DEFAULT 'everyone'   CHECK (who_can_send        IN ('everyone','admins')),
  who_can_edit_info   text NOT NULL DEFAULT 'admins'     CHECK (who_can_edit_info   IN ('everyone','admins')),
  who_can_add_members text NOT NULL DEFAULT 'everyone'   CHECK (who_can_add_members IN ('everyone','admins')),
  who_can_pin         text NOT NULL DEFAULT 'admins'     CHECK (who_can_pin         IN ('everyone','admins')),

  -- Disappearing messages: 0 = off, otherwise a duration in seconds
  -- (86400 = 24h, 604800 = 7d, 7776000 = 90d).
  disappearing_seconds integer NOT NULL DEFAULT 0 CHECK (disappearing_seconds >= 0),

  -- Announcement channels/groups: only admins post, everyone reads.
  is_announcement     boolean NOT NULL DEFAULT false,
  is_locked           boolean NOT NULL DEFAULT false,

  -- Denormalised for the chat list. Maintained by the message service inside
  -- the same transaction as the insert, so a crash cannot leave it stale.
  last_message_id     uuid,
  last_message_at     timestamptz,
  last_message_preview text,
  member_count        integer NOT NULL DEFAULT 0,

  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  deleted_at          timestamptz
);

CREATE INDEX chats_last_message_idx ON chats (last_message_at DESC NULLS LAST) WHERE deleted_at IS NULL;
CREATE INDEX chats_community_idx    ON chats (community_id) WHERE community_id IS NOT NULL;
-- Exactly one direct chat per user pair is enforced in the service layer by
-- looking up a deterministic pair key; see src/services/chats.service.ts.

CREATE TRIGGER chats_set_updated_at
  BEFORE UPDATE ON chats
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Membership. Everything a user can personalise about a chat lives here.
-- ---------------------------------------------------------------------------
CREATE TABLE chat_members (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id              uuid NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  user_id              uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,

  role                 text NOT NULL DEFAULT 'member' CHECK (role IN ('member','admin','owner')),
  nickname             text,
  member_label         text,

  invited_by           uuid REFERENCES users(id) ON DELETE SET NULL,
  joined_at            timestamptz NOT NULL DEFAULT now(),
  left_at              timestamptz,

  -- Read/delivery watermarks (see the note at the top of this file)
  last_read_seq        bigint NOT NULL DEFAULT 0,
  last_delivered_seq   bigint NOT NULL DEFAULT 0,

  -- Per-user chat controls
  muted_until          timestamptz,
  notification_sound   text,
  is_archived          boolean NOT NULL DEFAULT false,
  archived_at          timestamptz,
  pinned_at            timestamptz,
  is_favorite          boolean NOT NULL DEFAULT false,

  -- "Lock chat" with a secret code
  is_locked            boolean NOT NULL DEFAULT false,
  lock_secret_hash     text,

  -- Per-chat wallpaper / theme overrides
  wallpaper            text,
  theme                text,

  -- Group join approval state
  status               text NOT NULL DEFAULT 'active' CHECK (status IN ('active','pending','removed','banned','left')),
  removed_by           uuid REFERENCES users(id) ON DELETE SET NULL,
  removed_at           timestamptz,
  ban_reason           text,

  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  UNIQUE (chat_id, user_id)
);

CREATE INDEX chat_members_user_idx        ON chat_members (user_id) WHERE left_at IS NULL;
CREATE INDEX chat_members_chat_idx        ON chat_members (chat_id) WHERE left_at IS NULL;
CREATE INDEX chat_members_archived_idx    ON chat_members (user_id) WHERE is_archived;
CREATE INDEX chat_members_unread_idx      ON chat_members (user_id, chat_id);
CREATE INDEX chat_members_role_idx        ON chat_members (chat_id, role) WHERE role <> 'member';

CREATE TRIGGER chat_members_set_updated_at
  BEFORE UPDATE ON chat_members
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Invite links, QR codes and join requests
-- ---------------------------------------------------------------------------
CREATE TABLE chat_invites (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id          uuid NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  code             text NOT NULL UNIQUE,
  created_by       uuid REFERENCES users(id) ON DELETE SET NULL,
  require_approval boolean NOT NULL DEFAULT false,
  max_uses         integer,
  uses             integer NOT NULL DEFAULT 0,
  expires_at       timestamptz,
  revoked_at       timestamptz,
  created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX chat_invites_chat_idx ON chat_invites (chat_id) WHERE revoked_at IS NULL;

CREATE TABLE chat_join_requests (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id      uuid NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  invite_code  text,
  message      text,
  status       text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','cancelled')),
  reviewed_by  uuid REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at  timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (chat_id, user_id, status)
);

CREATE INDEX chat_join_requests_pending_idx ON chat_join_requests (chat_id, created_at) WHERE status = 'pending';

-- ---------------------------------------------------------------------------
-- Messages
-- ---------------------------------------------------------------------------
CREATE TABLE messages (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  -- Monotonic ordering cursor. bigserial so it survives concurrent inserts.
  seq                   bigserial NOT NULL,
  chat_id               uuid NOT NULL REFERENCES chats(id) ON DELETE CASCADE,
  sender_id             uuid REFERENCES users(id) ON DELETE SET NULL,

  type                  text NOT NULL DEFAULT 'text' CHECK (type IN (
                          'text','image','video','audio','voice','document','sticker','gif',
                          'location','contact','poll','event','system','call_log')),

  body                  text,
  -- Non-text payloads (location lat/lng, contact card, link preview, etc.)
  metadata              jsonb NOT NULL DEFAULT '{}'::jsonb,

  reply_to_id           uuid REFERENCES messages(id) ON DELETE SET NULL,
  forwarded_from_message_id uuid REFERENCES messages(id) ON DELETE SET NULL,
  forwarded_from_user_id    uuid REFERENCES users(id)    ON DELETE SET NULL,
  forward_count         integer NOT NULL DEFAULT 0,

  -- "Delete for everyone" is a tombstone: body is cleared, row kept, so that
  -- replies pointing at it and audit trails do not break.
  is_deleted            boolean NOT NULL DEFAULT false,
  deleted_at            timestamptz,
  deleted_by            uuid REFERENCES users(id) ON DELETE SET NULL,

  -- "Delete for me" rows live in message_deletions.

  edited_at             timestamptz,
  edit_count            smallint NOT NULL DEFAULT 0,

  -- View-once media and disappearing messages
  is_view_once          boolean NOT NULL DEFAULT false,
  expires_at            timestamptz,

  -- Client-supplied id so a retried send after a network failure does not
  -- create a duplicate message (the "failed message / resend" flow).
  client_id             text,

  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX messages_seq_unique      ON messages (seq);
CREATE INDEX messages_chat_seq_idx           ON messages (chat_id, seq DESC);
CREATE INDEX messages_sender_idx             ON messages (sender_id, created_at DESC);
CREATE INDEX messages_expiry_idx             ON messages (expires_at) WHERE expires_at IS NOT NULL AND is_deleted = false;
CREATE UNIQUE INDEX messages_client_id_unique ON messages (chat_id, sender_id, client_id) WHERE client_id IS NOT NULL;

CREATE TRIGGER messages_set_updated_at
  BEFORE UPDATE ON messages
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Precise per-user delivery/read facts.
CREATE TABLE message_receipts (
  message_id   uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id      uuid NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  delivered_at timestamptz,
  read_at      timestamptz,
  failed_at    timestamptz,
  failure_code text,
  PRIMARY KEY (message_id, user_id)
);

CREATE INDEX message_receipts_user_idx ON message_receipts (user_id) WHERE read_at IS NULL;

-- ---------------------------------------------------------------------------
-- Message interactions
-- ---------------------------------------------------------------------------
CREATE TABLE message_reactions (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  emoji      text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  -- One reaction per emoji per user; a user may stack several emojis.
  UNIQUE (message_id, user_id, emoji)
);

CREATE INDEX message_reactions_message_idx ON message_reactions (message_id);

CREATE TABLE message_stars (
  message_id uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id)
);

CREATE TABLE message_pins (
  chat_id    uuid NOT NULL REFERENCES chats(id)    ON DELETE CASCADE,
  message_id uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  pinned_by  uuid REFERENCES users(id) ON DELETE SET NULL,
  pinned_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (chat_id, message_id)
);

-- Edit history, so moderation and the "edited" affordance have a real record.
CREATE TABLE message_edits (
  id         bigserial PRIMARY KEY,
  message_id uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  old_body   text,
  edited_by  uuid REFERENCES users(id) ON DELETE SET NULL,
  edited_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX message_edits_message_idx ON message_edits (message_id, edited_at DESC);

-- "Delete for me"
CREATE TABLE message_deletions (
  message_id uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  deleted_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id)
);

CREATE TABLE message_mentions (
  message_id  uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id     uuid NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  created_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (message_id, user_id)
);

CREATE INDEX message_mentions_user_idx ON message_mentions (user_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- Attachments (media, documents, voice notes)
-- ---------------------------------------------------------------------------
CREATE TABLE attachments (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id     uuid NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  kind           text NOT NULL CHECK (kind IN ('image','video','audio','voice','document','sticker','gif')),
  mime_type      text NOT NULL,
  file_name      text,
  byte_size      bigint NOT NULL DEFAULT 0,
  -- Which storage backend holds the bytes (local disk, R2/S3, ...)
  storage_driver text NOT NULL DEFAULT 'local',
  storage_key    text NOT NULL,
  public_url     text,

  -- Derivative assets (thumbnails, transcodes, waveforms)
  thumbnail_url  text,
  width          integer,
  height         integer,
  duration_ms    integer,
  waveform       jsonb,

  -- Provenance / integrity
  sha256         text,
  is_compressed  boolean NOT NULL DEFAULT false,
  original_byte_size bigint,

  -- Downloadable / saveable to gallery
  downloadable   boolean NOT NULL DEFAULT true,

  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX attachments_message_idx ON attachments (message_id);
CREATE INDEX attachments_kind_idx    ON attachments (kind);

-- ---------------------------------------------------------------------------
-- Polls and events (the "group polls" / "group events" checklist items)
-- ---------------------------------------------------------------------------
CREATE TABLE polls (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id         uuid NOT NULL REFERENCES chats(id)    ON DELETE CASCADE,
  message_id      uuid REFERENCES messages(id) ON DELETE CASCADE,
  created_by      uuid REFERENCES users(id) ON DELETE SET NULL,
  question        text NOT NULL,
  allows_multiple boolean NOT NULL DEFAULT false,
  is_anonymous    boolean NOT NULL DEFAULT false,
  closes_at       timestamptz,
  closed_at       timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX polls_chat_idx ON polls (chat_id, created_at DESC);

CREATE TABLE poll_options (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id    uuid NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
  position   smallint NOT NULL,
  text       text NOT NULL,
  UNIQUE (poll_id, position)
);

CREATE TABLE poll_votes (
  poll_id    uuid NOT NULL REFERENCES polls(id) ON DELETE CASCADE,
  option_id  uuid NOT NULL REFERENCES poll_options(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (option_id, user_id)
);

CREATE INDEX poll_votes_poll_idx ON poll_votes (poll_id, user_id);

CREATE TABLE events (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  -- Polymorphic owner: a chat (group event) or a community (community event)
  owner_type  text NOT NULL CHECK (owner_type IN ('chat','community')),
  owner_id    uuid NOT NULL,
  message_id  uuid REFERENCES messages(id) ON DELETE SET NULL,
  created_by  uuid REFERENCES users(id) ON DELETE SET NULL,
  title       text NOT NULL,
  description text,
  location    text,
  starts_at   timestamptz NOT NULL,
  ends_at     timestamptz,
  is_all_day  boolean NOT NULL DEFAULT false,
  cancelled_at timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX events_owner_idx  ON events (owner_type, owner_id, starts_at);
CREATE INDEX events_starts_idx ON events (starts_at) WHERE cancelled_at IS NULL;

CREATE TABLE event_attendees (
  event_id   uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id    uuid NOT NULL REFERENCES users(id)  ON DELETE CASCADE,
  response   text NOT NULL DEFAULT 'going' CHECK (response IN ('going','maybe','declined')),
  responded_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (event_id, user_id)
);
