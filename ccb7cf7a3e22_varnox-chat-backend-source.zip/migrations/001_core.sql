-- ===========================================================================
-- 001_core.sql — identity, credentials, sessions, devices, security events
-- ---------------------------------------------------------------------------
-- Design notes (these apply to every migration in this project):
--
--  * UUID primary keys via gen_random_uuid() — built into Postgres 13+, so no
--    pgcrypto extension is required.
--  * Enumerations are `text` + CHECK constraints, never native ENUM types.
--    Native enums cannot be extended or reordered without an exclusive lock
--    and a rewrite; CHECK constraints can be replaced cheaply as the product
--    evolves — which matters a lot for a feature list this large.
--  * Emails/usernames are stored as given and made unique case-insensitively
--    with a unique index on lower(...). This deliberately avoids citext so the
--    schema runs on any managed Postgres without extension privileges.
--  * Rows are soft-deleted (deleted_at) so "delete account" stays reversible
--    for the recovery window and moderation retains its audit trail.
--  * No table relies on session-level state, advisory locks or LISTEN/NOTIFY.
--    Neon's pooled endpoint runs PgBouncer in transaction mode and silently
--    breaks all three.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Helper: keep updated_at honest. Without this, a forgotten UPDATE clause
-- silently produces stale rows and debugging it later is miserable.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- ---------------------------------------------------------------------------
-- Platform configuration & feature flags
-- ---------------------------------------------------------------------------
CREATE TABLE app_settings (
  key         text PRIMARY KEY,
  value       jsonb       NOT NULL,
  description text,
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE feature_flags (
  key         text PRIMARY KEY,
  enabled     boolean     NOT NULL DEFAULT false,
  rollout_pct smallint    NOT NULL DEFAULT 0 CHECK (rollout_pct BETWEEN 0 AND 100),
  description text,
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- ===========================================================================
-- Users
-- ===========================================================================
CREATE TABLE users (
  id                     uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Credentials / identifiers. At least one of email or phone must exist,
  -- enforced by users_has_identifier below.
  email                  text,
  phone                  text,
  username               text,

  password_hash          text        NOT NULL,

  full_name              text,

  -- Lifecycle
  status                 text        NOT NULL DEFAULT 'active'
                                     CHECK (status IN ('pending','active','suspended','deactivated','deleted')),
  email_verified_at      timestamptz,
  phone_verified_at      timestamptz,

  -- Business / official badges
  is_business            boolean     NOT NULL DEFAULT false,
  is_verified            boolean     NOT NULL DEFAULT false,
  verified_reason        text,

  -- Presence bookkeeping. Live online/typing state is held in memory by the
  -- realtime hub (see src/realtime/hub.ts); this column is the durable
  -- last-seen fallback so presence survives a restart.
  last_seen_at           timestamptz,
  registered_device      text,

  -- Brute-force protection (password + PIN attempts)
  failed_login_count     integer     NOT NULL DEFAULT 0,
  locked_until           timestamptz,

  -- Two-step verification (the 6-digit app PIN, distinct from the email OTP)
  two_step_enabled       boolean     NOT NULL DEFAULT false,
  two_step_pin_hash      text,
  two_step_pin_set_at    timestamptz,

  -- Account deletion / export workflow
  deletion_requested_at  timestamptz,
  deletion_scheduled_for timestamptz,

  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),
  deleted_at             timestamptz,

  CONSTRAINT users_has_identifier CHECK (email IS NOT NULL OR phone IS NOT NULL)
);

-- Case-insensitive uniqueness, but only among live accounts, so that a
-- deleted account does not permanently burn its email address.
CREATE UNIQUE INDEX users_email_unique   ON users (lower(email))  WHERE email    IS NOT NULL AND deleted_at IS NULL;
CREATE UNIQUE INDEX users_phone_unique   ON users (phone)         WHERE phone    IS NOT NULL AND deleted_at IS NULL;
CREATE UNIQUE INDEX users_username_unique ON users (lower(username)) WHERE username IS NOT NULL AND deleted_at IS NULL;

CREATE INDEX users_username_trgm_placeholder ON users (lower(username));
CREATE INDEX users_created_at_idx ON users (created_at DESC);
CREATE INDEX users_status_idx     ON users (status) WHERE deleted_at IS NULL;

CREATE TRIGGER users_set_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Profile (the "one row per user, edited often" split keeps `users` narrow so
-- authentication queries stay fast)
-- ---------------------------------------------------------------------------
CREATE TABLE user_profiles (
  user_id        uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  display_name   text,
  about          text CHECK (about IS NULL OR length(about) <= 280),
  avatar_url     text,
  avatar_thumb_url text,
  date_of_birth  date,
  country_code   char(2),
  language_code  text NOT NULL DEFAULT 'en',
  timezone       text,
  updated_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TRIGGER user_profiles_set_updated_at
  BEFORE UPDATE ON user_profiles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Privacy controls — one row per user, one column per togglable control from
-- the feature checklist. Defaults follow the privacy-preserving choice.
-- ---------------------------------------------------------------------------
CREATE TABLE user_privacy_settings (
  user_id                    uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,

  -- Visibility vocab: everyone | contacts | contacts_except | nobody
  last_seen_visibility       text NOT NULL DEFAULT 'contacts' CHECK (last_seen_visibility IN ('everyone','contacts','contacts_except','nobody')),
  online_visibility          text NOT NULL DEFAULT 'contacts' CHECK (online_visibility  IN ('everyone','contacts','contacts_except','nobody')),
  profile_photo_visibility   text NOT NULL DEFAULT 'everyone' CHECK (profile_photo_visibility IN ('everyone','contacts','contacts_except','nobody')),
  about_visibility           text NOT NULL DEFAULT 'everyone' CHECK (about_visibility IN ('everyone','contacts','contacts_except','nobody')),
  status_visibility          text NOT NULL DEFAULT 'contacts' CHECK (status_visibility  IN ('everyone','contacts','contacts_except','nobody')),

  read_receipts_enabled      boolean NOT NULL DEFAULT true,
  typing_indicator_enabled   boolean NOT NULL DEFAULT true,
  live_location_enabled      boolean NOT NULL DEFAULT false,

  -- Who may add me to groups: everyone | contacts | contacts_except | nobody
  group_invite_policy        text NOT NULL DEFAULT 'contacts' CHECK (group_invite_policy IN ('everyone','contacts','contacts_except','nobody')),

  -- Discoverability (contact & discovery section of the checklist)
  discoverable_by_email      boolean NOT NULL DEFAULT true,
  discoverable_by_phone      boolean NOT NULL DEFAULT true,
  discoverable_by_username   boolean NOT NULL DEFAULT true,

  silence_unknown_callers    boolean NOT NULL DEFAULT false,
  screenshot_protection      boolean NOT NULL DEFAULT false,
  security_notifications     boolean NOT NULL DEFAULT true,

  updated_at                 timestamptz NOT NULL DEFAULT now()
);

CREATE TRIGGER user_privacy_settings_set_updated_at
  BEFORE UPDATE ON user_privacy_settings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Notification preferences
-- ---------------------------------------------------------------------------
CREATE TABLE user_notification_settings (
  user_id                uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  previews_enabled       boolean NOT NULL DEFAULT true,
  in_app_enabled         boolean NOT NULL DEFAULT true,
  vibration_enabled      boolean NOT NULL DEFAULT true,
  vibration_pattern      text    NOT NULL DEFAULT 'default',
  default_sound          text    NOT NULL DEFAULT 'default',
  notification_privacy   text    NOT NULL DEFAULT 'sender_and_message'
                                 CHECK (notification_privacy IN ('sender_and_message','sender_only','hidden')),
  quiet_hours_start      time,
  quiet_hours_end        time,
  badge_enabled          boolean NOT NULL DEFAULT true,
  email_security_alerts  boolean NOT NULL DEFAULT true,
  updated_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TRIGGER user_notification_settings_set_updated_at
  BEFORE UPDATE ON user_notification_settings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Per-chat / per-contact sound overrides ("custom sounds per contact")
CREATE TABLE notification_sound_overrides (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_type text NOT NULL CHECK (target_type IN ('user','chat')),
  target_id   uuid NOT NULL,
  sound       text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, target_type, target_id)
);

-- ---------------------------------------------------------------------------
-- Appearance / chat customisation defaults
-- ---------------------------------------------------------------------------
CREATE TABLE user_appearance_settings (
  user_id            uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  theme              text NOT NULL DEFAULT 'system' CHECK (theme IN ('light','dark','system')),
  accent_color       text NOT NULL DEFAULT '#1F8A70',
  chat_wallpaper     text,
  font_scale         numeric(3,2) NOT NULL DEFAULT 1.00,
  high_contrast      boolean NOT NULL DEFAULT false,
  reduce_motion      boolean NOT NULL DEFAULT false,
  updated_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TRIGGER user_appearance_settings_set_updated_at
  BEFORE UPDATE ON user_appearance_settings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ===========================================================================
-- Devices & sessions
-- ===========================================================================
CREATE TABLE devices (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform        text NOT NULL CHECK (platform IN ('android','ios','web','windows','macos','linux','unknown')),
  device_name     text,
  app_version     text,
  os_version      text,

  -- Push delivery. Expo push tokens look like ExponentPushToken[...].
  push_token      text,
  push_provider   text DEFAULT 'expo' CHECK (push_provider IN ('expo','fcm','apns')),
  push_enabled    boolean NOT NULL DEFAULT true,

  -- Linked-device flow (QR pairing for the web/desktop apps)
  linked_via_qr   boolean NOT NULL DEFAULT false,
  is_primary      boolean NOT NULL DEFAULT true,

  last_ip         inet,
  last_seen_at    timestamptz,
  revoked_at      timestamptz,
  revoked_reason  text,

  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX devices_user_idx ON devices (user_id) WHERE revoked_at IS NULL;
CREATE INDEX devices_push_token_idx ON devices (push_token) WHERE push_token IS NOT NULL AND revoked_at IS NULL;

CREATE TRIGGER devices_set_updated_at
  BEFORE UPDATE ON devices
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Refresh tokens are stored as SHA-256 hashes; a database leak must not hand
-- an attacker usable sessions.
CREATE TABLE sessions (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id           uuid REFERENCES devices(id) ON DELETE SET NULL,
  refresh_token_hash  text NOT NULL UNIQUE,
  issued_ip           inet,
  user_agent          text,
  created_at          timestamptz NOT NULL DEFAULT now(),
  last_used_at        timestamptz,
  expires_at          timestamptz NOT NULL,
  revoked_at          timestamptz,
  revoked_reason      text
);

CREATE INDEX sessions_user_idx    ON sessions (user_id) WHERE revoked_at IS NULL;
CREATE INDEX sessions_expires_idx ON sessions (expires_at);

-- ===========================================================================
-- Email OTP verification (codes go to EMAIL only, per the product spec)
-- ===========================================================================
CREATE TABLE auth_otp_codes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid REFERENCES users(id) ON DELETE CASCADE,
  -- May be set before a user row exists (registration flow).
  destination   text NOT NULL,
  channel       text NOT NULL DEFAULT 'email' CHECK (channel IN ('email','sms')),
  purpose       text NOT NULL CHECK (purpose IN (
                  'register','login','reset_password','change_email',
                  'change_phone','verify_phone','two_step','delete_account')),

  -- Only a hash of the 6-digit code is stored.
  code_hash     text NOT NULL,
  attempts      smallint NOT NULL DEFAULT 0,
  max_attempts  smallint NOT NULL DEFAULT 5,
  consumed_at   timestamptz,
  expires_at    timestamptz NOT NULL,
  request_ip    inet,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX auth_otp_lookup_idx   ON auth_otp_codes (lower(destination), purpose, created_at DESC);
CREATE INDEX auth_otp_active_idx   ON auth_otp_codes (expires_at) WHERE consumed_at IS NULL;
CREATE INDEX auth_otp_user_idx     ON auth_otp_codes (user_id, purpose, created_at DESC);

-- ===========================================================================
-- Password reset & account recovery
-- ===========================================================================
CREATE TABLE auth_password_resets (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  text NOT NULL UNIQUE,
  expires_at  timestamptz NOT NULL,
  used_at     timestamptz,
  request_ip  inet,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX auth_password_resets_user_idx ON auth_password_resets (user_id, created_at DESC);

-- Backup codes for two-step verification, plus recovery contacts.
CREATE TABLE auth_two_step_backup_codes (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code_hash  text NOT NULL,
  used_at    timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE auth_recovery_contacts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  email       text,
  phone       text,
  verified_at timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT auth_recovery_has_contact CHECK (email IS NOT NULL OR phone IS NOT NULL)
);

-- ===========================================================================
-- Passkeys (WebAuthn). Storing the credential is the easy half; the public
-- key must be verified with @simplewebauthn/server during registration, which
-- is why the API exposes this as an explicit "not yet wired" endpoint.
-- ===========================================================================
CREATE TABLE auth_passkeys (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id         uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  credential_id   text NOT NULL UNIQUE,
  public_key      text NOT NULL,           -- base64url COSE key
  sign_count      bigint NOT NULL DEFAULT 0,
  transports      text[],
  friendly_name   text,
  aaguid          text,
  last_used_at    timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  revoked_at      timestamptz
);

CREATE INDEX auth_passkeys_user_idx ON auth_passkeys (user_id) WHERE revoked_at IS NULL;

-- ===========================================================================
-- Security events / new-device login alerts
-- ===========================================================================
CREATE TABLE security_events (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid REFERENCES users(id) ON DELETE CASCADE,
  device_id     uuid REFERENCES devices(id) ON DELETE SET NULL,
  event_type    text NOT NULL CHECK (event_type IN (
                  'login_success','login_failed','login_new_device','logout',
                  'password_changed','email_changed','phone_changed',
                  'two_step_enabled','two_step_disabled','passkey_added','passkey_removed',
                  'device_linked','device_revoked','session_revoked',
                  'account_locked','otp_failed','data_export_requested',
                  'account_deletion_requested','account_deletion_cancelled')),
  ip            inet,
  user_agent    text,
  metadata      jsonb NOT NULL DEFAULT '{}'::jsonb,
  notified_at   timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX security_events_user_idx ON security_events (user_id, created_at DESC);

-- ===========================================================================
-- Admin roles & audit trail
-- ===========================================================================
CREATE TABLE admin_roles (
  user_id     uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  role        text NOT NULL CHECK (role IN ('support','moderator','admin','superadmin')),
  granted_by  uuid REFERENCES users(id) ON DELETE SET NULL,
  granted_at  timestamptz NOT NULL DEFAULT now(),
  revoked_at  timestamptz,
  notes       text
);

-- Append-only. Nothing in the application issues UPDATE or DELETE here.
CREATE TABLE audit_logs (
  id           bigserial PRIMARY KEY,
  actor_id     uuid REFERENCES users(id) ON DELETE SET NULL,
  actor_role   text,
  action       text NOT NULL,
  target_type  text,
  target_id    text,
  metadata     jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip           inet,
  user_agent   text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX audit_logs_actor_idx  ON audit_logs (actor_id, created_at DESC);
CREATE INDEX audit_logs_target_idx ON audit_logs (target_type, target_id, created_at DESC);
CREATE INDEX audit_logs_action_idx ON audit_logs (action, created_at DESC);

-- ===========================================================================
-- Data export / deletion requests (privacy compliance)
-- ===========================================================================
CREATE TABLE data_requests (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind         text NOT NULL CHECK (kind IN ('export','delete')),
  status       text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','processing','ready','completed','rejected','cancelled')),
  download_url text,
  expires_at   timestamptz,
  handled_by   uuid REFERENCES users(id) ON DELETE SET NULL,
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

CREATE INDEX data_requests_user_idx ON data_requests (user_id, created_at DESC);
