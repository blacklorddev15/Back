-- ===========================================================================
-- 005_calls_business.sql — voice/video calls, business tools, payments
-- ===========================================================================
--
-- IMPORTANT: the tables here record call *state and history*. The media path
-- itself is WebRTC and does not live in this database — signalling, ICE
-- candidate exchange and TURN relaying happen in the realtime layer. Storing
-- call rows without a signalling implementation is fine (history, missed-call
-- badges, call links all work); placing actual audio/video is a separate,
-- later piece of work.
-- ===========================================================================

CREATE TABLE calls (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id           uuid REFERENCES chats(id) ON DELETE SET NULL,
  initiator_id      uuid REFERENCES users(id) ON DELETE SET NULL,
  kind              text NOT NULL CHECK (kind IN ('voice','video')),

  status            text NOT NULL DEFAULT 'ringing' CHECK (status IN (
                      'ringing','ongoing','ended','missed','declined','failed','cancelled')),
  is_group          boolean NOT NULL DEFAULT false,

  started_at        timestamptz NOT NULL DEFAULT now(),
  answered_at       timestamptz,
  ended_at          timestamptz,
  duration_seconds  integer,
  ended_by          uuid REFERENCES users(id) ON DELETE SET NULL,
  end_reason        text,

  -- Low-data mode / quality indicator reporting
  low_data_mode     boolean NOT NULL DEFAULT false,
  quality_score     smallint CHECK (quality_score IS NULL OR quality_score BETWEEN 1 AND 5),
  screen_shared     boolean NOT NULL DEFAULT false,
  screen_share_with_audio boolean NOT NULL DEFAULT false,
  recording_url     text,

  created_at        timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX calls_chat_idx      ON calls (chat_id, started_at DESC);
CREATE INDEX calls_initiator_idx ON calls (initiator_id, started_at DESC);
CREATE INDEX calls_active_idx    ON calls (status) WHERE status IN ('ringing','ongoing');

CREATE TABLE call_participants (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  call_id      uuid NOT NULL REFERENCES calls(id) ON DELETE CASCADE,
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role         text NOT NULL DEFAULT 'participant' CHECK (role IN ('caller','participant','observer')),
  status       text NOT NULL DEFAULT 'invited' CHECK (status IN ('invited','joined','left','declined','missed','removed')),
  invited_by   uuid REFERENCES users(id) ON DELETE SET NULL,
  joined_at    timestamptz,
  left_at      timestamptz,
  was_muted    boolean NOT NULL DEFAULT false,
  camera_off   boolean NOT NULL DEFAULT false,
  UNIQUE (call_id, user_id)
);

CREATE INDEX call_participants_user_idx ON call_participants (user_id, joined_at DESC);

-- Signalling / lifecycle trail, also useful for debugging dropped calls.
CREATE TABLE call_events (
  id         bigserial PRIMARY KEY,
  call_id    uuid NOT NULL REFERENCES calls(id) ON DELETE CASCADE,
  user_id    uuid REFERENCES users(id) ON DELETE SET NULL,
  event_type text NOT NULL CHECK (event_type IN (
               'invite','ring','answer','decline','join','leave','mute','unmute',
               'camera_on','camera_off','screen_share_start','screen_share_stop',
               'switch_camera','speaker_on','speaker_off','participant_added',
               'participant_removed','quality','end','failed')),
  payload    jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX call_events_call_idx ON call_events (call_id, created_at);

-- Shareable call links ("call links" checklist item)
CREATE TABLE call_links (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code       text NOT NULL UNIQUE,
  chat_id    uuid REFERENCES chats(id) ON DELETE CASCADE,
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  kind       text NOT NULL DEFAULT 'video' CHECK (kind IN ('voice','video')),
  expires_at timestamptz,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ===========================================================================
-- Business accounts
-- ===========================================================================
CREATE TABLE businesses (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name           text NOT NULL,
  category       text,
  description    text,
  address        text,
  email          text,
  website        text,
  hours          jsonb NOT NULL DEFAULT '{}'::jsonb,
  logo_url       text,
  cover_url      text,
  short_link     text UNIQUE,
  timezone       text,
  currency       text NOT NULL DEFAULT 'USD',

  is_verified    boolean NOT NULL DEFAULT false,
  verified_at    timestamptz,
  verification_status text NOT NULL DEFAULT 'unverified'
                 CHECK (verification_status IN ('unverified','pending','verified','rejected')),
  is_official    boolean NOT NULL DEFAULT false,

  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  deleted_at     timestamptz
);

CREATE INDEX businesses_owner_idx ON businesses (owner_id) WHERE deleted_at IS NULL;

CREATE TRIGGER businesses_set_updated_at
  BEFORE UPDATE ON businesses
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE business_agents (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role        text NOT NULL DEFAULT 'agent' CHECK (role IN ('agent','admin','owner')),
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, user_id)
);

-- Catalog: products and services share a table because they differ only by
-- `kind` and the checkout behaviour, not by their attributes.
CREATE TABLE business_catalog_items (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id   uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  collection_id uuid,
  kind          text NOT NULL DEFAULT 'product' CHECK (kind IN ('product','service')),
  name          text NOT NULL,
  description   text,
  price_cents   bigint CHECK (price_cents IS NULL OR price_cents >= 0),
  currency      text NOT NULL DEFAULT 'USD',
  sku           text,
  category      text,
  images        jsonb NOT NULL DEFAULT '[]'::jsonb,
  stock         integer,
  is_active     boolean NOT NULL DEFAULT true,
  position      integer NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  deleted_at    timestamptz
);

CREATE INDEX catalog_business_idx ON business_catalog_items (business_id, is_active) WHERE deleted_at IS NULL;

CREATE TRIGGER catalog_set_updated_at
  BEFORE UPDATE ON business_catalog_items
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE business_collections (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name        text NOT NULL,
  position    integer NOT NULL DEFAULT 0,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, name)
);

ALTER TABLE business_catalog_items
  ADD CONSTRAINT catalog_collection_fk
  FOREIGN KEY (collection_id) REFERENCES business_collections(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- Carts and orders
-- ---------------------------------------------------------------------------
CREATE TABLE carts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, business_id)
);

CREATE TABLE cart_items (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cart_id    uuid NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
  item_id    uuid NOT NULL REFERENCES business_catalog_items(id) ON DELETE CASCADE,
  quantity   integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  notes      text,
  added_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (cart_id, item_id)
);

CREATE TABLE orders (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number   text NOT NULL UNIQUE,
  business_id    uuid NOT NULL REFERENCES businesses(id) ON DELETE RESTRICT,
  buyer_id       uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  chat_id        uuid REFERENCES chats(id) ON DELETE SET NULL,
  status         text NOT NULL DEFAULT 'pending' CHECK (status IN (
                   'pending','confirmed','paid','fulfilled','shipped','delivered',
                   'cancelled','refunded','disputed')),
  subtotal_cents bigint NOT NULL DEFAULT 0,
  shipping_cents bigint NOT NULL DEFAULT 0,
  tax_cents      bigint NOT NULL DEFAULT 0,
  total_cents    bigint NOT NULL DEFAULT 0,
  currency       text NOT NULL DEFAULT 'USD',
  notes          text,
  tracking_url   text,
  tracking_number text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX orders_business_idx ON orders (business_id, created_at DESC);
CREATE INDEX orders_buyer_idx    ON orders (buyer_id, created_at DESC);

CREATE TRIGGER orders_set_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE order_items (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id      uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  item_id       uuid REFERENCES business_catalog_items(id) ON DELETE SET NULL,
  name_snapshot text NOT NULL,
  unit_price_cents bigint NOT NULL,
  quantity      integer NOT NULL CHECK (quantity > 0)
);

CREATE INDEX order_items_order_idx ON order_items (order_id);

-- ---------------------------------------------------------------------------
-- Business messaging automation
-- ---------------------------------------------------------------------------
CREATE TABLE business_replies (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  kind        text NOT NULL CHECK (kind IN ('quick','saved','greeting','away','welcome')),
  shortcut    text,
  body        text NOT NULL,
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX business_replies_idx ON business_replies (business_id, kind) WHERE is_active;

CREATE TRIGGER business_replies_set_updated_at
  BEFORE UPDATE ON business_replies
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Outbound template messages (e.g. order updates). `status` mirrors the
-- approval workflow a real messaging provider requires before you may send
-- non-session messages.
CREATE TABLE message_templates (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id  uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name         text NOT NULL,
  category     text,
  language_code text NOT NULL DEFAULT 'en',
  body         text NOT NULL,
  variables    jsonb NOT NULL DEFAULT '[]'::jsonb,
  status       text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending','approved','rejected','paused')),
  external_id  text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, name)
);

-- ---------------------------------------------------------------------------
-- Payments. Provider-agnostic on purpose: a real deployment plugs in Stripe,
-- a local wallet or a bank rail. Nothing here moves money by itself.
-- ---------------------------------------------------------------------------
CREATE TABLE payment_accounts (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid REFERENCES users(id)      ON DELETE CASCADE,
  business_id   uuid REFERENCES businesses(id) ON DELETE CASCADE,
  provider      text NOT NULL,
  external_id   text,
  currency      text NOT NULL DEFAULT 'USD',
  status        text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','restricted','disabled')),
  metadata      jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at    timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT payment_account_owner CHECK (user_id IS NOT NULL OR business_id IS NOT NULL)
);

CREATE TABLE payment_pins (
  user_id    uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  pin_hash   text NOT NULL,
  failed_attempts integer NOT NULL DEFAULT 0,
  locked_until timestamptz,
  set_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE payments (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payer_id      uuid REFERENCES users(id) ON DELETE SET NULL,
  payee_id      uuid REFERENCES users(id) ON DELETE SET NULL,
  business_id   uuid REFERENCES businesses(id) ON DELETE SET NULL,
  order_id      uuid REFERENCES orders(id) ON DELETE SET NULL,
  direction     text NOT NULL DEFAULT 'outgoing' CHECK (direction IN ('incoming','outgoing','refund')),
  amount_cents  bigint NOT NULL CHECK (amount_cents >= 0),
  fee_cents     bigint NOT NULL DEFAULT 0,
  currency      text NOT NULL DEFAULT 'USD',
  status        text NOT NULL DEFAULT 'pending' CHECK (status IN (
                  'pending','processing','succeeded','failed','refunded','cancelled','disputed')),
  provider      text,
  provider_ref  text,
  failure_reason text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  settled_at    timestamptz
);

CREATE INDEX payments_payer_idx   ON payments (payer_id, created_at DESC);
CREATE INDEX payments_payee_idx   ON payments (payee_id, created_at DESC);
CREATE INDEX payments_order_idx   ON payments (order_id);

-- Click-to-chat / QR contact links and ad entry points
CREATE TABLE business_links (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  kind        text NOT NULL DEFAULT 'click_to_chat' CHECK (kind IN ('click_to_chat','qr','ad','short')),
  code        text NOT NULL UNIQUE,
  campaign    text,
  clicks      integer NOT NULL DEFAULT 0,
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);
