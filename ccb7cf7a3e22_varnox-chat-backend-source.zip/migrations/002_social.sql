-- ===========================================================================
-- 002_social.sql — contacts, labels, blocks, reports, favourites, broadcasts
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Contacts. This is a directed graph (my contact list), not a friendship:
-- WhatsApp-style products let one side have a contact without reciprocity.
-- ---------------------------------------------------------------------------
CREATE TABLE contacts (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id         uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  contact_user_id  uuid REFERENCES users(id) ON DELETE CASCADE,
  -- A contact may exist before that person joins the app.
  phone            text,
  email            text,
  display_name     text,
  label_id         uuid,
  is_favorite      boolean NOT NULL DEFAULT false,
  source           text NOT NULL DEFAULT 'manual' CHECK (source IN ('manual','synced','qr','suggested','imported')),
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT contacts_target_present CHECK (contact_user_id IS NOT NULL OR phone IS NOT NULL OR email IS NOT NULL)
);

-- One contact row per (owner, user) pair.
CREATE UNIQUE INDEX contacts_owner_user_unique ON contacts (owner_id, contact_user_id) WHERE contact_user_id IS NOT NULL;
CREATE UNIQUE INDEX contacts_owner_phone_unique ON contacts (owner_id, phone) WHERE phone IS NOT NULL AND contact_user_id IS NULL;
CREATE UNIQUE INDEX contacts_owner_email_unique ON contacts (owner_id, lower(email)) WHERE email IS NOT NULL AND contact_user_id IS NULL;
CREATE INDEX contacts_owner_idx   ON contacts (owner_id, created_at DESC);
CREATE INDEX contacts_favorite_idx ON contacts (owner_id) WHERE is_favorite;

CREATE TRIGGER contacts_set_updated_at
  BEFORE UPDATE ON contacts
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE contact_labels (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id   uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name       text NOT NULL,
  color      text NOT NULL DEFAULT '#888888',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (owner_id, name)
);

ALTER TABLE contacts
  ADD CONSTRAINT contacts_label_fk
  FOREIGN KEY (label_id) REFERENCES contact_labels(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- Blocking. Blocking is directional and must be checked by every read path
-- that could expose one user to another (messages, search, status, calls).
-- ---------------------------------------------------------------------------
CREATE TABLE user_blocks (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blocked_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reason      text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT user_blocks_no_self CHECK (blocker_id <> blocked_id),
  UNIQUE (blocker_id, blocked_id)
);

CREATE INDEX user_blocks_blocked_idx ON user_blocks (blocked_id);

-- ---------------------------------------------------------------------------
-- Reports (user, group, channel, community, message, status)
-- ---------------------------------------------------------------------------
CREATE TABLE reports (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id   uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  target_type   text NOT NULL CHECK (target_type IN ('user','message','group','channel','community','status','business')),
  target_id     uuid NOT NULL,
  reason        text NOT NULL CHECK (reason IN (
                  'spam','scam','harassment','hate','violence','sexual_content',
                  'child_safety','impersonation','intellectual_property','other')),
  details       text,
  status        text NOT NULL DEFAULT 'open' CHECK (status IN ('open','reviewing','actioned','dismissed','escalated')),
  priority      smallint NOT NULL DEFAULT 3 CHECK (priority BETWEEN 1 AND 5),
  reviewed_by   uuid REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at   timestamptz,
  resolution    text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX reports_status_idx  ON reports (status, priority, created_at);
CREATE INDEX reports_target_idx  ON reports (target_type, target_id);
CREATE INDEX reports_reporter_idx ON reports (reporter_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- Broadcast lists — one-to-many, recipients cannot see each other.
-- ---------------------------------------------------------------------------
CREATE TABLE broadcast_lists (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name        text NOT NULL,
  is_business boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now(),
  deleted_at  timestamptz
);

CREATE INDEX broadcast_lists_owner_idx ON broadcast_lists (owner_id) WHERE deleted_at IS NULL;

CREATE TABLE broadcast_recipients (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  broadcast_list_id  uuid NOT NULL REFERENCES broadcast_lists(id) ON DELETE CASCADE,
  recipient_user_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  added_at           timestamptz NOT NULL DEFAULT now(),
  UNIQUE (broadcast_list_id, recipient_user_id)
);

-- Outbound broadcast sends, so limits and anti-spam can be enforced.
CREATE TABLE broadcast_sends (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  broadcast_list_id  uuid NOT NULL REFERENCES broadcast_lists(id) ON DELETE CASCADE,
  sender_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message_id         uuid,
  recipient_count    integer NOT NULL DEFAULT 0,
  created_at         timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX broadcast_sends_sender_idx ON broadcast_sends (sender_id, created_at DESC);
