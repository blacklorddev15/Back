// native-buttons-patch.js
// Converts legacy raw buttonsMessage -> clickable native flow at relay time.
// Commands keep sending raw buttons; WhatsApp receives interactive quick_reply
// buttons, which are tappable on current clients (legacy buttons are not).

'use strict';

function toNativeFlow(raw) {
  if (!raw || !raw.buttonsMessage) return raw; // not a legacy-button message
  const b = raw.buttonsMessage;

  const buttons = (b.buttons || [])
    .filter((x) => x && x.buttonText && x.buttonText.displayText)
    .map((x) => {
      const display_text = x.buttonText.displayText;
      const isResponse = x.type === 1 || !x.url; // Button.Type.RESPONSE = 1
      return {
        name: isResponse ? 'quick_reply' : 'cta_url',
        buttonParamsJson: JSON.stringify(
          isResponse ? { display_text, id: x.buttonId || display_text } : { display_text, url: x.url }
        ),
      };
    });

  if (!buttons.length) return raw;

  const interactive = {
    nativeFlowMessage: {
      buttons,
      messageParamsJson: '',
      messageVersion: 1,
    },
    body: { text: b.contentText || '' },
  };

  if (b.footerText) interactive.footer = { text: b.footerText };

  // Keep optional media header (image / video / document) clickable as well.
  const media =
    b.imageMessage || b.videoMessage || b.documentMessage || b.locationMessage;
  if (media) {
    interactive.header = { hasMediaAttachment: true };
    if (b.imageMessage) interactive.header.imageMessage = b.imageMessage;
    if (b.videoMessage) interactive.header.videoMessage = b.videoMessage;
    if (b.documentMessage) interactive.header.documentMessage = b.documentMessage;
    if (b.locationMessage) interactive.header.locationMessage = b.locationMessage;
  }

  const out = { ...raw };
  delete out.buttonsMessage;
  out.interactiveMessage = interactive;
  return out;
}

function hookSocket(sock) {
  if (!sock || typeof sock.relayMessage !== 'function') return sock;
  const origRelay = sock.relayMessage.bind(sock);
  sock.relayMessage = async function (jid, message, extra) {
    const upgraded = toNativeFlow(message);
    return origRelay(jid, upgraded, extra);
  };
  return sock;
}

module.exports = { hookSocket, toNativeFlow };
