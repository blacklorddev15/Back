const fs = require('fs')
const path = require('path')

const SESSION_SETTING_FILES = [
  'welcome.json',
  'chatbot.json',
  'antilink.json',
  'antistatus.json',
  'warnings.json',
  'anticall.json',
  'autoreact.json',
  'mode.json',
  'newsletter.json'
]

function resetSessionSettings(sessionId, databaseDir = path.join(process.cwd(), 'database')) {
  if (!sessionId) throw new Error('A session ID is required')

  const results = []
  for (const filename of SESSION_SETTING_FILES) {
    const filePath = path.join(databaseDir, filename)
    if (!fs.existsSync(filePath)) continue

    let data
    try {
      data = JSON.parse(fs.readFileSync(filePath, 'utf8') || '{}')
    } catch {
      continue
    }

    let changed = false
    if (filename === 'chatbot.json' && data && data.chats && typeof data.chats === 'object') {
      changed = Object.prototype.hasOwnProperty.call(data.chats, sessionId)
      delete data.chats[sessionId]
    } else if (data && !Array.isArray(data) && typeof data === 'object') {
      changed = Object.prototype.hasOwnProperty.call(data, sessionId)
      delete data[sessionId]
    }

    if (changed) {
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2))
      results.push(filename)
    }
  }

  return results
}

function resetAllSessionSettings(sessionId, databaseDir = path.join(process.cwd(), 'database')) {
  const results = resetSessionSettings(sessionId, databaseDir)
  const safeId = String(sessionId || 'default').replace(/[^a-zA-Z0-9_.-]/g, '_') || 'default'
  const jsonPath = filename => path.join(databaseDir, filename)
  const read = filename => {
    try { return JSON.parse(fs.readFileSync(jsonPath(filename), 'utf8')) } catch { return {} }
  }
  const write = (filename, value) => {
    fs.writeFileSync(jsonPath(filename), JSON.stringify(value, null, 2))
    if (!results.includes(filename)) results.push(filename)
  }
  const prefixPath = jsonPath('prefixfree.json')
  if (fs.existsSync(prefixPath)) write('prefixfree.json', { enabled: false })
  const modes = read('display_modes.json')
  if (Object.prototype.hasOwnProperty.call(modes, safeId)) {
    delete modes[safeId]
    write('display_modes.json', modes)
  }
  const stickers = read('sticker_commands.json')
  if (Object.prototype.hasOwnProperty.call(stickers, safeId)) {
    delete stickers[safeId]
    write('sticker_commands.json', stickers)
  }
  return results
}
module.exports = { resetSessionSettings, resetAllSessionSettings, SESSION_SETTING_FILES }
