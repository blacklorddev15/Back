'use strict';
require('dotenv').config();

module.exports = {
  TELEGRAM_TOKEN:     process.env.TELEGRAM_TOKEN    || '',   // <- put YOUR OWN BotFather token here
  OWNER_TELEGRAM_ID:  process.env.OWNER_TELEGRAM_ID || '',   // <- your numeric Telegram user id
  OWNER_NAME:         process.env.OWNER_NAME        || 'varnox',
  SUDO_NUMBER:        process.env.SUDO_NUMBER       || '', // extra owner WA number
GITHUB_TOKEN:    '',   // <- your own token if you use the repo-backed database
GITHUB_USERNAME: 'blacklorddev15',
GITHUB_REPO:     'database',
GITHUB_BRANCH:   'main',
PANEL_URL:       'https://panel.bwmxmd.co.ke',   // your Pterodactyl URL for ping
WEBSITE_URL:     'https://varnox-xd.vercel.app',   // your Render/Vercel URL for ping
  BOT_NAME:    process.env.BOT_NAME || '𝑽𝑨𝑹𝑵𝑶𝑿 × 𝑿𝑫',
  BOT_VERSION: '4.0.0',
  COMPANY:     'VARNOX XD',
  CREDITS:     'varnox',

  REQUIRED_PAIR_LINK: process.env.REQUIRED_PAIR_LINK || 'https://varnox-xd.vercel.app',

  SESSION_DIR:      './sessions',
  DEFAULT_PREFIX:   '.',
  DEFAULT_MENU_IMG: process.env.MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg',

  REQUIRED_CHANNEL:      process.env.REQUIRED_CHANNEL      || '',
  REQUIRED_GROUP:        process.env.REQUIRED_GROUP        || '',
  REQUIRED_CHANNEL_LINK: process.env.REQUIRED_CHANNEL_LINK || '',
  REQUIRED_GROUP_LINK:   process.env.REQUIRED_GROUP_LINK   || '',
  REQUIRED_CHANNEL_ID:   process.env.REQUIRED_CHANNEL_ID   || '',
  REQUIRED_GROUP_ID:     process.env.REQUIRED_GROUP_ID     || '',

  AUTO_FOLLOW_NEWSLETTERS: [
  '120363426406372312@newsletter',
'120363408083191758@newsletter',

  ], // add as many as you want
  AUTO_JOIN_GROUPS:        [], // add as many as you want
};
