// ============================================================
//   helper/chatbot.js  – auto-reply chatbot for the Ultra XMD bot
// ============================================================
//
// The bot had no chatbot at all. This adds one, wired into the same
// messages.upsert pipeline as the other listeners (see index.js).
//
// Configuration lives in the normal per-number settings store, so it is
// isolated per paired WhatsApp number:
//     chatbot            on / off
//     chatbotMentionOnly in groups, only answer when tagged or replied to
//
// Providers are tried in order and the first one that answers wins, because
// free AI endpoints rate-limit (HTTP 402) when several chats fire at once.
// Calls are serialised with a minimum gap for the same reason.

'use strict';

const axios = require('axios');
const { getWaSettings } = require('./function');
const { logInfo, logError } = require('./logger');

const MAX_REPLY_CHARS = 4000;
const REQUEST_TIMEOUT_MS = Number(process.env.CHATBOT_TIMEOUT_MS || 45000);
const MIN_CALL_GAP_MS = Number(process.env.CHATBOT_MIN_INTERVAL_MS || 4000);
const MAX_PENDING = Number(process.env.CHATBOT_MAX_PENDING || 2);
const CHAT_COOLDOWN_MS = Number(process.env.CHATBOT_COOLDOWN_MS || 5000);
const CHATBOT_MODEL = process.env.CHATBOT_MODEL || 'openai';

const SYSTEM_PROMPT =
  'You are a friendly WhatsApp assistant. Keep replies short and conversational ' +
  '(usually 1-3 sentences). Never mention that you are an AI model and never use markdown headings.';

const PROVIDERS = [
  { name: 'pollinations-openai', kind: 'openai', url: process.env.CHATBOT_API_URL || 'https://text.pollinations.ai/openai' },
  { name: 'pollinations-referrer', kind: 'openai', url: 'https://text.pollinations.ai/openai?referrer=ultra-xmd' },
  { name: 'pollinations-plain', kind: 'plain', url: 'https://text.pollinations.ai/' },
  { name: 'fallback-site', kind: 'cortana', url: process.env.CHATBOT_FALLBACK_URL || 'https://mrfarai.me/cortana/api.php' }
];

const HEADERS = { 'Content-Type': 'application/json', Accept: '*/*', 'User-Agent': 'UltraXMD-Chatbot/1.0' };

const histories = new Map();        // senderKey -> [{ role, content }]
const lastChatReply = new Map();    // jid -> timestamp
const seenMessageIds = new Set();

let callChain = Promise.resolve();
let lastCallAt = 0;
let pendingCalls = 0;

/* ───────────────────────── helpers ───────────────────────── */

function normNum(jid) {
  return String(jid || '').split(':')[0].split('@')[0].replace(/\D/g, '');
}

function textOf(message) {
  if (!message) return '';
  return message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.documentMessage?.caption ||
    '';
}

function contextInfoOf(message) {
  if (!message) return null;
  const type = Object.keys(message)[0];
  return (type && message[type] && message[type].contextInfo) || null;
}

/** True when the message tags the bot or quotes one of its messages. */
function isBotAddressed(sock, m) {
  const selfId = sock?.user?.id;
  if (!selfId) return false;
  const ctx = contextInfoOf(m?.message);
  if (!ctx) return false;
  const mentioned = Array.isArray(ctx.mentionedJid) ? ctx.mentionedJid : [];
  if (mentioned.some((jid) => normNum(jid) === normNum(selfId))) return true;
  if (ctx.participant && normNum(ctx.participant) === normNum(selfId)) return true;
  return false;
}

/* ───────────────────────── providers ───────────────────────── */

async function callProvider(provider, history) {
  const messages = [{ role: 'system', content: SYSTEM_PROMPT }, ...history];

  if (provider.kind === 'openai' || provider.kind === 'plain') {
    const { data } = await axios.post(provider.url, { model: CHATBOT_MODEL, messages },
      { headers: HEADERS, timeout: REQUEST_TIMEOUT_MS });
    if (typeof data === 'string') return data;
    return data?.choices?.[0]?.message?.content;
  }

  if (provider.kind === 'cortana') {
    const transcript = history
      .map((t) => `${t.role === 'user' ? 'User' : 'Assistant'}: ${t.content}`)
      .join('\n');
    const { data } = await axios.post(provider.url, { message: transcript, history: [] },
      { headers: HEADERS, timeout: REQUEST_TIMEOUT_MS });
    return data?.reply;
  }

  throw new Error(`unknown provider kind: ${provider.kind}`);
}

function schedule(sessionId, job) {
  if (pendingCalls >= MAX_PENDING) {
    logInfo(sessionId, `chatbot skipped (backlog=${pendingCalls})`);
    return Promise.resolve(null);
  }
  pendingCalls += 1;
  const run = callChain.then(async () => {
    const wait = lastCallAt + MIN_CALL_GAP_MS - Date.now();
    if (wait > 0) await new Promise((r) => setTimeout(r, wait));
    lastCallAt = Date.now();
    return job();
  });
  callChain = run.then(() => {}, () => {});
  return run.finally(() => { pendingCalls -= 1; });
}

async function ask(sessionId, history) {
  return schedule(sessionId, async () => {
    let lastError = null;
    for (const provider of PROVIDERS) {
      const started = Date.now();
      try {
        const reply = await callProvider(provider, history);
        const text = reply && String(reply).trim();
        if (text) {
          logInfo(sessionId, `chatbot ok provider=${provider.name} ms=${Date.now() - started}`);
          return text;
        }
        logInfo(sessionId, `chatbot empty provider=${provider.name}`);
      } catch (err) {
        const status = err?.response?.status ? ` status=${err.response.status}` : '';
        logInfo(sessionId, `chatbot fail provider=${provider.name}${status} ms=${Date.now() - started}`);
        lastError = err;
      }
    }
    throw lastError || new Error('all chatbot providers failed');
  });
}

/* ───────────────────────── handler ───────────────────────── */

async function handleChatbot(sock, m) {
  try {
    if (!m?.message || !m.key) return;
    if (m.key.fromMe) return;

    const jid = m.key.remoteJid;
    if (!jid) return;
    if (jid === 'status@broadcast' || jid.endsWith('@newsletter') || jid.endsWith('@broadcast')) return;

    const waNum = sock.__waNum || (sock.user?.id ? normNum(sock.user.id) : null);
    if (!waNum) return;

    const c = getWaSettings(waNum);
    if (!c.chatbot) return;

    const isGroup = jid.endsWith('@g.us');
    if (isGroup && c.chatbotMentionOnly !== false && !isBotAddressed(sock, m)) return;

    const text = String(textOf(m.message) || '').trim();
    if (!text) return;
    const prefix = c.prefix || '.';
    if (text.startsWith(prefix)) return;   // let the command handler own it

    const msgId = `${waNum}:${jid}:${m.key.id}`;
    if (seenMessageIds.has(msgId)) return;
    seenMessageIds.add(msgId);
    setTimeout(() => seenMessageIds.delete(msgId), 60000).unref?.();

    if ((lastChatReply.get(jid) || 0) > Date.now()) return;

    const sender = m.key.participant || jid;
    const key = `${waNum}:${sender}`;
    const history = (histories.get(key) || []).slice(-20);
    history.push({ role: 'user', content: text });

    try { await sock.sendPresenceUpdate('composing', jid); } catch {}

    const started = Date.now();
    const reply = await ask(waNum, history);
    if (!reply) return;

    const updated = history.slice(-20);
    updated.push({ role: 'assistant', content: reply });
    histories.set(key, updated.slice(-20));

    try { await sock.sendPresenceUpdate('paused', jid); } catch {}
    await sock.sendMessage(jid, { text: reply.slice(0, MAX_REPLY_CHARS) }, { quoted: m });
    lastChatReply.set(jid, Date.now() + CHAT_COOLDOWN_MS);
    logInfo(waNum, `chatbot replied chat=${jid.split('@')[0]} ms=${Date.now() - started} chars=${reply.length}`);
  } catch (err) {
    logError('CHATBOT', err.message);
  }
}

module.exports = { handleChatbot };
