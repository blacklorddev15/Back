const https = require('https');
const { URL } = require('url');
const { reply, box, friendlyDownloadError } = require('./helpers');

const fetch = (url, options = {}) => globalThis.fetch(url, {
    ...options,
    signal: options.signal || AbortSignal.timeout(options.timeout || 20000)
});

const TTURL_COMMANDS = ['tiktok', 'tt', 'tkdl', 'tturl'];

const SANKA_APIKEY = 'planaai';

const VIDEO_QUALITIES = ['HD', 'No Watermark', 'Watermark'];

function isTiktokLink(text) {
    return /^https?:\/\/(www\.|vm\.|vt\.|m\.)?tiktok\.com\//i.test(text);
}

function extractUrl(str) {
    const match = (str || '').match(/https?:\/\/[^\s]+/gi);
    return match ? match[0] : null;
}

function httpGetJson(targetUrl) {
    return new Promise((resolve, reject) => {
        const parsed = new URL(targetUrl);
        const options = {
            hostname: parsed.hostname,
            path: parsed.pathname + parsed.search,
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json'
            }
        };
        const req = https.request(options, (res) => {
            const chunks = [];
            res.on('data', (chunk) => chunks.push(chunk));
            res.on('end', () => {
                try {
                    resolve(JSON.parse(Buffer.concat(chunks).toString('utf-8')));
                } catch (e) {
                    reject(new Error('Invalid response from TikTok service'));
                }
            });
        });
        req.on('error', reject);
        req.setTimeout(20000, () => {
            req.destroy();
            reject(new Error('Request timed out'));
        });
        req.end();
    });
}

function httpDownload(targetUrl, redirectCount = 0) {
    return new Promise((resolve, reject) => {
        if (redirectCount > 8) {
            reject(new Error('Too many redirects'));
            return;
        }
        const parsed = new URL(targetUrl);
        const options = {
            hostname: parsed.hostname,
            path: parsed.pathname + parsed.search,
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': 'https://www.tikwm.com/'
            }
        };
        const req = https.request(options, (res) => {
            if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
                res.resume();
                const nextUrl = new URL(res.headers.location, targetUrl).toString();
                resolve(httpDownload(nextUrl, redirectCount + 1));
                return;
            }
            const chunks = [];
            res.on('data', (chunk) => chunks.push(chunk));
            res.on('end', () => {
                resolve({ statusCode: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) });
            });
        });
        req.on('error', reject);
        req.setTimeout(30000, () => {
            req.destroy();
            reject(new Error('Download timed out'));
        });
        req.end();
    });
}

async function fetchTiktokInfoViaTikwm(url) {
    try {
        const apiUrl = 'https://www.tikwm.com/api/?url=' + encodeURIComponent(url) + '&hd=1';
        const apiResponse = await httpGetJson(apiUrl);
        if (apiResponse && apiResponse.code === 0 && apiResponse.data) {
            return apiResponse.data;
        }
    } catch (_) {}
    return null;
}

async function fetchTiktokInfoViaSankavollerei(url) {
    const endpoints = [
        'https://www.sankavollerei.web.id/download/tiktok?apikey=' + SANKA_APIKEY + '&url=',
        'https://www.sankavollerei.web.id/download/tiktok-hd?apikey=' + SANKA_APIKEY + '&url=',
        'https://www.sankavollerei.web.id/download/tiktok-v2?apikey=' + SANKA_APIKEY + '&url='
    ];

    for (const base of endpoints) {
        try {
            const r = await httpGetJson(base + encodeURIComponent(url));
            if (r && r.status === false) continue;

            const result = r?.result || r?.data;
            if (!result) continue;

            const normalized = {
                title: result.title || result.desc || result.description || result.caption || 'TikTok Video',
                author: {
                    nickname: result.author?.nickname || result.author?.name || result.author || result.username || 'Unknown'
                },
                images: Array.isArray(result.images) ? result.images
                    : (Array.isArray(result.slideshow) ? result.slideshow
                    : (Array.isArray(result.slides) ? result.slides : [])),
                music: result.music || result.audio || result.mp3,
                play: result.play || result.no_watermark || result.nowm || result.video,
                wmplay: result.wmplay || result.watermark,
                hdplay: result.hdplay || result.hd
            };

            if (normalized.play || normalized.wmplay || normalized.hdplay || normalized.images.length) {
                return normalized;
            }
        } catch (_) {}
    }

    return null;
}

async function fetchTiktokInfo(url) {
    const viaTikwm = await fetchTiktokInfoViaTikwm(url);
    if (viaTikwm) return viaTikwm;
    const viaSanka = await fetchTiktokInfoViaSankavollerei(url);
    if (viaSanka) return viaSanka;

    throw new Error('Could not fetch this TikTok post');
}

function pickVideoLink(data, quality) {
    if (quality === 'HD') return data.hdplay || data.play || data.wmplay;
    if (quality === 'No Watermark') return data.play || data.hdplay || data.wmplay;
    return data.wmplay || data.play || data.hdplay;
}

function isPendingTturlRequest() {
    return false;
}

async function handlePendingTturlReply() {
    // No audio/quality prompts are used; the requested video is sent directly.
    return false;
}

async function handleTturlCommand(sock, jid, msg, command, params) {
    if (!TTURL_COMMANDS.includes(command)) return false;
    const inputUrl = extractUrl(params[0] || '') || (params[0] || '').trim();

    if (!inputUrl) {
        await reply(sock, jid, msg, box('TIKTOK', 'Send a TikTok video link.\nExample: .tiktok https://www.tiktok.com/@user/video/...'));
        return true;
    }
    if (!isTiktokLink(inputUrl)) {
        await reply(sock, jid, msg, box('TIKTOK', 'That link does not look like a TikTok post.'));
        return true;
    }

    try {
        const data = await fetchTiktokInfo(inputUrl);
        const videoUrl = pickVideoLink(data, 'No Watermark');
        if (!videoUrl) {
            throw new Error(Array.isArray(data.images) && data.images.length
                ? 'This TikTok post is a photo slideshow, not a video.'
                : 'No downloadable video found');
        }
        const videoResult = await httpDownload(videoUrl);
        if (videoResult.statusCode !== 200) throw new Error('Video download returned status ' + videoResult.statusCode);

        await reply(sock, jid, msg, {
            video: videoResult.body,
            mimetype: 'video/mp4',
            caption: box('TIKTOK', data.title || 'Here is your TikTok video.')
        });
    } catch (error) {
        await reply(sock, jid, msg, box('TIKTOK', friendlyDownloadError(error, 'TikTok video')));
    }
    return true;
}

module.exports = {
    handleTturlCommand,
    TTURL_COMMANDS,
    isPendingTturlRequest,
    handlePendingTturlReply
};