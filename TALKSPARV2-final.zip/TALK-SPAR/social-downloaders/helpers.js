'use strict';

const { formatReply } = require('../helper/style');

const CARD_PREFIX = '\u0000TALKSPAR_CARD:';

function box(title, body) {
  return `${CARD_PREFIX}${String(title || 'SOCIAL DOWNLOAD')}\n${String(body ?? '')}`;
}

function unwrapCard(value, fallbackTitle = 'SOCIAL DOWNLOAD') {
  const text = String(value ?? '');
  if (!text.startsWith(CARD_PREFIX)) return { title: fallbackTitle, body: text };
  const splitAt = text.indexOf('\n');
  if (splitAt < 0) return { title: text.slice(CARD_PREFIX.length), body: '' };
  return {
    title: text.slice(CARD_PREFIX.length, splitAt),
    body: text.slice(splitAt + 1),
  };
}

function styledText(value, fallbackTitle) {
  const { title, body } = unwrapCard(value, fallbackTitle);
  return formatReply(body, { title, platform: 'WhatsApp' });
}

async function reply(sock, jid, msg, payload) {
  if (payload && typeof payload === 'object' && !Buffer.isBuffer(payload)) {
    const outgoing = { ...payload };
    if (typeof outgoing.caption === 'string' && outgoing.caption.trim()) {
      outgoing.caption = styledText(outgoing.caption, 'SOCIAL DOWNLOAD');
    }
    return sock.sendMessage(jid, outgoing, { quoted: msg });
  }

  const text = styledText(payload, 'SOCIAL DOWNLOAD');
  return sock.sendMessage(jid, { text }, { quoted: msg });
}

async function getBaileys() {
  return require('../helper/baileys');
}

function friendlyDownloadError(error, subject = 'social media post') {
  const raw = String(error?.message || error || '').replace(/[\r\n]+/g, ' ').trim();
  if (/private|deleted|login|not available|unavailable/i.test(raw)) {
    return `I couldn't access this ${subject}. It may be private, deleted, or require a login.`;
  }
  if (/timeout|timed out/i.test(raw)) {
    return `The ${subject} service took too long to respond. Please try again in a little while.`;
  }
  if (/too large|content.?length|413/i.test(raw)) {
    return `This ${subject} is too large to send through WhatsApp.`;
  }
  return `I couldn't download this ${subject} right now. Check that the link is public and try again.`;
}

module.exports = { reply, box, getBaileys, friendlyDownloadError };
