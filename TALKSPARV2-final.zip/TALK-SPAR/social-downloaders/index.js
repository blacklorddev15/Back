'use strict';

const {
  handleIgurlCommand,
  IGURL_COMMANDS,
  handlePendingIgurlReply,
} = require('./instagram');
const {
  handleTturlCommand,
  TTURL_COMMANDS,
  handlePendingTturlReply,
} = require('./tiktok');
const {
  handleFburlCommand,
  FBURL_COMMANDS,
  handlePendingFburlReply,
} = require('./facebook');

const SOCIAL_DOWNLOAD_COMMANDS = [
  ...IGURL_COMMANDS,
  ...TTURL_COMMANDS,
  ...FBURL_COMMANDS,
];

// A single group message may be delivered to several paired sockets handled by
// this process. Claim its WhatsApp message ID once, so only one session sends
// the resulting media/reply. Keeping the claim briefly also absorbs retries.
const handledGroupCommands = new Map();
const GROUP_COMMAND_DEDUPE_MS = 2 * 60 * 1000;

function claimGroupCommand(msg, jid) {
  if (!jid.endsWith('@g.us') || !msg?.key?.id) return true;

  const now = Date.now();
  for (const [key, claimedAt] of handledGroupCommands) {
    if (now - claimedAt >= GROUP_COMMAND_DEDUPE_MS) handledGroupCommands.delete(key);
  }

  const key = `${jid}:${msg.key.id}`;
  if (handledGroupCommands.has(key)) return false;
  handledGroupCommands.set(key, now);
  return true;
}

async function handleSocialDownloadCommand(sock, msg, command, args = [], sender, senderIsOwner) {
  const jid = msg?.key?.remoteJid;
  if (!jid) return false;
  if (!SOCIAL_DOWNLOAD_COMMANDS.includes(command)) return false;
  if (!claimGroupCommand(msg, jid)) return true;

  if (IGURL_COMMANDS.includes(command)) {
    await handleIgurlCommand(sock, jid, msg, command, args, sender, senderIsOwner);
    return true;
  }
  if (TTURL_COMMANDS.includes(command)) {
    await handleTturlCommand(sock, jid, msg, command, args, sender, senderIsOwner);
    return true;
  }
  if (FBURL_COMMANDS.includes(command)) {
    await handleFburlCommand(sock, jid, msg, command, args, sender, senderIsOwner);
    return true;
  }
  return false;
}

async function handlePendingSocialDownloadReply(sock, jid, msg, text) {
  if (await handlePendingIgurlReply(sock, jid, msg, text)) return true;
  if (await handlePendingTturlReply(sock, jid, msg, text)) return true;
  if (await handlePendingFburlReply(sock, jid, msg, text)) return true;
  return false;
}

module.exports = {
  handleSocialDownloadCommand,
  handlePendingSocialDownloadReply,
  SOCIAL_DOWNLOAD_COMMANDS,
};
