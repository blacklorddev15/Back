# TALK-SPAR Bot

A Telegram control bot that pairs and manages WhatsApp sessions, with command modules for groups, media, games, AI, social tools, and administration.

## Quick start

```bash
npm install
cp .env.example .env
# Fill in TELEGRAM_TOKEN and the owner values in .env
npm start
```

The bot creates its runtime directories and JSON data files automatically. Keep `.env`, `sessions/`, `database/`, and `anti_delete/` private; they can contain credentials, WhatsApp session data, or message data.

When a WhatsApp session connects, the bot automatically follows the configured WhatsApp newsletters. The bundled defaults include channel IDs `120363426406372312` and `120363424817531838`; add more IDs through the comma-separated `AUTO_FOLLOW_NEWSLETTERS` setting. Telegram IDs `8703390483` and `8922445498` are enabled as bot admins by default; additional admins can be listed in `ADMIN_TELEGRAM_IDS`.

On WhatsApp, reply to an image, GIF, video, or sticker with `.sticker` or its short alias `.s` to create a branded sticker.

## Development and checks

```bash
npm run dev
npm run verify:social
npm run verify:commands
npm run verify:antidelete
npm run verify:chatbot
npm run verify:menu
npm run verify:play
npm run verify:ports
```

Verification scripts use mocked inputs and do not require a live Telegram or WhatsApp login. The command verification script writes `command-verification-report.json`; that generated report is intentionally ignored by Git.

## Project layout

- `index.js` — application entry point and Telegram/WhatsApp lifecycle
- `case.js` — WhatsApp command dispatch and command registry
- `helper/` — shared transport, persistence, logging, and listener helpers
- `social-downloaders/` — Instagram, TikTok, and Facebook downloaders
- `assets/` — bundled menu and welcome media
- `verify-*.js` — offline regression checks

## Security notes

- Never commit `.env` or WhatsApp session folders.
- Rotate the Telegram bot token if it has ever been shared publicly.
- Configure owner IDs and WhatsApp numbers in `.env` instead of hard-coding them in source.
