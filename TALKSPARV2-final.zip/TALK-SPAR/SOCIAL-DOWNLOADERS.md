# Social downloaders and smart command replies

## Social video commands

| Platform | Main command | Aliases | Example |
|---|---|---|---|
| Instagram | `.instagram` | `.ig`, `.igurl` | `.instagram https://www.instagram.com/reel/...` |
| TikTok | `.tiktok` | `.tt`, `.tkdl`, `.tturl` | `.tiktok https://www.tiktok.com/@.../video/...` |
| Facebook | `.facebook` | `.fb`, `.fburl` | `.facebook https://www.facebook.com/watch/?v=...` |

Each request sends **one final video message** (or one short styled error). There are no fetching/downloading/wait notices, audio or quality prompts, or interactive buttons. Instagram carousels select one item only (preferring a video); TikTok photo-only posts are not sent as multiple images.

Group messages are deduplicated by WhatsApp message ID across paired sessions in this Node process. Separately running bot processes do not share the in-memory claim.

## Smart reply cards

Command replies use the shared framed card formatter with serif mathematical-bold headings, concise green/red/yellow/blue status indicators, smart field icons, labeled details, and a clean TALK-SPAR footer. Replies are standalone rather than blockquoted unless explicitly enabled with `REPLY_QUOTE=true`.

The status commands are:

- `.ping` — online status, latency, uptime, and speed.
- `.pong` — concise availability check.
- `.alive` — online state, mode, and uptime.
- `.speed` — response latency and speed status.
- `.uptime` — process runtime.

The Telegram `/menu` and `/help` views use the same card format and grouped sections. On startup the bot registers the slash commands with Telegram so the command picker is organized and current. The WhatsApp menu follows the supplied categorized layout; its system header fields (name, version, mode, platform, uptime, and owner) are filled dynamically.

## View-once private retrieval

Reply to a view-once message with `vv`, `vv2`, `wow`, `waaah`, `nice`, `soon`, `🥳`, `thanks`, or `😂`. These exact shortcut words work **without the configured prefix**; other commands keep their normal prefix behavior. Retrieved image/video/audio and any status/error card go **only to the paired bot account's own private chat** (`botJid`), regardless of who issued the command. The command sender and group never receive the result or a fallback response. The visible WhatsApp menu calls out the prefix-free behavior and paired-chat destination.

## WhatsApp retry messages

Outgoing retry records now serialize and restore `Buffer` and `Uint8Array` values instead of degrading protobuf media keys and hashes to plain JSON objects. Baileys can use the restored message payload when a device requests a retry, which addresses the “Waiting for this message” placeholder. Existing legacy retry records are also read with a numeric-byte compatibility path.

## Offline checks

Run from the project root:

```sh
npm run verify:social
for f in case.js index.js helper/style.js helper/command-parser.js helper/retry-codec.js social-downloaders/*.js verify-social-downloaders.js; do node --check "$f"; done
```
