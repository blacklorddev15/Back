'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const social = require('./social-downloaders');
const replyHelpers = require('./social-downloaders/helpers');
const { formatReply } = require('./helper/style');
const { getPrefixFreeViewOnceCommand, PREFIX_FREE_VIEW_ONCE_COMMANDS } = require('./helper/command-parser');
const { serializeRetryRecord, parseRetryRecord } = require('./helper/retry-codec');
const https = require('node:https');

const source = fs.readFileSync(require.resolve('./case'), 'utf8');
const menu = fs.readFileSync(require.resolve('./assets/talk-spar-whatsapp-menu.txt'), 'utf8');
const telegramSource = fs.readFileSync(require.resolve('./index'), 'utf8');
const sent = [];
const sock = { sendMessage: async (...args) => { sent.push(args); } };
const jid = '15550000000@s.whatsapp.net';
const msg = { key: { remoteJid: jid }, message: {} };
const aliases = ['instagram', 'ig', 'igurl', 'tiktok', 'tt', 'tkdl', 'tturl', 'facebook', 'fb', 'fburl'];

function mockHttpsResponse(options, callback) {
  const { EventEmitter } = require('node:events');
  const request = new EventEmitter();
  request.setTimeout = () => request;
  request.destroy = () => request;
  request.end = () => {
    let body;
    const url = `https://${options.hostname}${options.path}`;
    if (options.hostname === 'instagram.com' || options.hostname === 'www.instagram.com') {
      body = Buffer.from('<meta property="og:video" content="https://cdn.example/mock.mp4"><meta property="og:title" content="IG mock">');
    } else if (options.hostname === 'www.tikwm.com') {
      body = Buffer.from(JSON.stringify({ code: 0, data: { play: 'https://cdn.example/mock.mp4', title: 'TikTok mock' } }));
    } else if (options.hostname === 'cdn.example') {
      body = Buffer.from('mock-video-bytes');
    } else {
      request.emit('error', new Error(`Unexpected mocked request: ${url}`));
      return;
    }
    const response = new EventEmitter();
    response.statusCode = 200;
    response.headers = {};
    response.resume = () => {};
    response.destroy = () => {};
    callback(response);
    setImmediate(() => {
      response.emit('data', body);
      response.emit('end');
    });
  };
  return request;
}

(async () => {
  for (const command of aliases) {
    assert.equal(await social.handleSocialDownloadCommand(sock, msg, command, []), true, `${command} must route`);
  }
  assert.equal(await social.handleSocialDownloadCommand(sock, msg, 'not-a-social-command', []), false);
  assert.equal(sent.length, aliases.length);
  assert.ok(sent.every(([, payload]) => typeof payload.text === 'string' && /^╭─/m.test(payload.text)),
    'every missing-link response must use a styled reply card');

  const before = sent.length;
  for (const [command, invalidUrl] of [
    ['instagram', 'https://example.invalid/post/1'],
    ['tiktok', 'https://example.invalid/post/1'],
    ['facebook', 'https://example.invalid/post/1'],
  ]) {
    assert.equal(await social.handleSocialDownloadCommand(sock, msg, command, [invalidUrl]), true);
  }
  assert.equal(sent.length, before + 3);
  assert.ok(sent.slice(before).every(([, payload]) => /^╭─/m.test(payload.text)),
    'every invalid-link response must use a styled reply card');

  // Same inbound group message received by separate paired sockets should be
  // handled once, not once per paired bot number.
  const groupMsg = { key: { remoteJid: '123456789-987654@g.us', id: 'DUPLICATE_SOCIAL_1' }, message: {} };
  const groupBefore = sent.length;
  assert.equal(await social.handleSocialDownloadCommand(sock, groupMsg, 'ig', []), true);
  assert.equal(await social.handleSocialDownloadCommand({ sendMessage: async (...args) => sent.push(args) }, groupMsg, 'ig', []), true);
  assert.equal(sent.length, groupBefore + 1, 'duplicate group delivery must produce one reply across sockets');

  // A successful post should produce exactly one outbound media message, with
  // no waiting text, follow-up prompt, or quality/audio buttons.
  const originalHttpsRequest = https.request;
  const originalFetch = globalThis.fetch;
  https.request = mockHttpsResponse;
  globalThis.fetch = async (url) => ({
    ok: true,
    status: 200,
    json: async () => ({ status: true, result: { media: 'https://cdn.example/mock.mp4', title: 'Facebook mock' } }),
  });
  try {
    for (const [command, url] of [
      ['instagram', 'https://www.instagram.com/reel/mock/'],
      ['tiktok', 'https://www.tiktok.com/@mock/video/123'],
      ['facebook', 'https://www.facebook.com/watch/?v=123'],
    ]) {
      const mediaBefore = sent.length;
      await social.handleSocialDownloadCommand(sock, msg, command, [url]);
      assert.equal(sent.length, mediaBefore + 1, `${command} should send one message only`);
      const payload = sent.at(-1)[1];
      assert.ok(Buffer.isBuffer(payload.video), `${command} should send video directly`);
      assert.equal(payload.audio, undefined, `${command} should not send audio`);
      assert.equal(payload.text, undefined, `${command} should not send a progress text`);
    }
  } finally {
    https.request = originalHttpsRequest;
    globalThis.fetch = originalFetch;
  }

  for (const file of ['instagram.js', 'tiktok.js', 'facebook.js']) {
    const downloader = fs.readFileSync(require.resolve(`./social-downloaders/${file}`), 'utf8');
    assert.doesNotMatch(downloader, /sendNativeFlow|sendTypeButtons|sendQualityButtons|please wait|Fetching (?:info|media|video)/i,
      `${file} must not send button prompts or repeated progress notices`);
  }

  const mediaBefore = sent.length;
  await replyHelpers.reply(sock, jid, msg, {
    video: Buffer.from('mock-video'),
    mimetype: 'video/mp4',
    caption: replyHelpers.box('INSTAGRAM DOWNLOAD', 'A formatted caption'),
  });
  assert.equal(sent.length, mediaBefore + 1);
  assert.match(sent.at(-1)[1].caption, /^╭─/m, 'media captions must use the shared formatter');

  for (const command of ['ping', 'pong', 'alive', 'speed', 'uptime']) {
    assert.match(source, new RegExp(`case '${command}'`), `${command} must be implemented`);
  }
  for (const [command, text] of [
    ['ping', '✅ Pong! The bot is connected and ready.\nLatency: 4.2 ms\nUptime: 1h'],
    ['pong', '✅ Pong! I’m here and responding normally.'],
    ['alive', '✅ Alive and ready to help.\nMode: PUBLIC\nUptime: 1h'],
    ['speed', '✅ Response check complete.\nLatency: 4.2 ms'],
  ]) assert.match(formatReply(text, { title: command }), /^╭─[─]+╮\n│/m, `${command} must display as a success card`);
  assert.match(formatReply('ℹ️ The bot has been online and ready for 1h.', { title: 'uptime' }), /(?:🔵|ℹ️|💎)/u,
    'uptime must display as an information card');
  const pingCard = formatReply('✅ Pong! Bot is Online\nLatency: 163.0 ms\nUptime: 0d 0h 5m 18s\nSpeed: Stable', { title: 'ping' });
  assert.match(pingCard, /│\s+𝐏𝐈𝐍𝐆 𝐒𝐓𝐀𝐓𝐔𝐒\s+│/u, 'ping card should have the requested framed title');
  assert.match(pingCard, /🟢 𝐏𝐨𝐧𝐠! 𝐁𝐨𝐭 𝐢𝐬 𝐎𝐧𝐥𝐢𝐧𝐞/u, 'ping card should have a concise online status');
  assert.match(pingCard, /📡 𝐋𝐚𝐭𝐞𝐧𝐜𝐲 ▸ 163\.0 ms/u, 'latency should receive the smart field icon');
  assert.match(pingCard, /⏱️ 𝐔𝐩𝐭𝐢𝐦𝐞 ▸ 0d 0h 5m 18s/u, 'uptime should be a labeled detail');
  assert.match(pingCard, /🚀 𝐒𝐩𝐞𝐞𝐝 ▸ Stable/u, 'speed should be a labeled detail');
  assert.doesNotMatch(pingCard, /^>/m, 'standalone smart cards should not be quoted');
  for (const alias of ["case 'vv2'", "case 'wow'", "case 'nice'", "case 'soon'", "case '🥳'", "case 'thanks'"]) {
    assert.ok(source.includes(alias), `view-once shortcut ${alias} must be registered`);
  }
  for (const alias of PREFIX_FREE_VIEW_ONCE_COMMANDS) {
    assert.equal(getPrefixFreeViewOnceCommand(`  ${alias.toUpperCase()}  `), alias, `${alias} should work as a bare command`);
  }
  for (const text of ['wow nice', 'thanks!', '.wow', 'ordinary conversation']) {
    assert.equal(getPrefixFreeViewOnceCommand(text), null, `${text} should not be auto-converted to a bare view-once command`);
  }
  assert.match(source, /getPrefixFreeViewOnceCommand\(body\)/, 'case router should recognize bare view-once aliases');
  assert.match(source, /!isPrefixFree && !bareViewOnceCommand/, 'bare aliases should work without enabling global prefix-free mode');
  const vv2Block = source.slice(source.indexOf("case 'vv':"), source.indexOf("case 'botinfo':"));
  assert.match(vv2Block, /case 'vv':/, 'legacy vv should share the same paired-private handler');
  assert.match(vv2Block, /const userJid = botJid;/, 'view-once results must go only to the paired account private JID');
  assert.doesNotMatch(vv2Block, /sock\.sendMessage\(senderPn|const userJid = isGroup|userJid\s*\|\|\s*jid/, 'view-once replies must not target the caller or group as a fallback');
  assert.match(vv2Block, /sock\.sendMessage\(userJid, \{ image: mediaBuffer/u, 'view-once image must be sent to the paired account private chat');
  assert.match(source, /dlMedia\(\{ imageMessage: imgMsg \}, sourceKey\)/, 'view-once media should use the quoted message key');
  const retryInput = {
    imageMessage: {
      mediaKey: Uint8Array.from([0, 1, 128, 255]),
      fileSha256: Buffer.from([9, 8, 7]),
      nested: { iv: Uint8Array.from([5, 4, 3]) },
    },
  };
  const retryRoundTrip = parseRetryRecord(serializeRetryRecord(1234, retryInput));
  assert.equal(retryRoundTrip.ts, 1234);
  assert.deepEqual([...retryRoundTrip.message.imageMessage.mediaKey], [0, 1, 128, 255]);
  assert.ok(retryRoundTrip.message.imageMessage.mediaKey instanceof Uint8Array, 'retry cache must restore protobuf byte arrays');
  assert.ok(Buffer.isBuffer(retryRoundTrip.message.imageMessage.fileSha256), 'retry cache must restore Buffers');
  assert.deepEqual([...retryRoundTrip.message.imageMessage.nested.iv], [5, 4, 3]);
  const legacyRetry = parseRetryRecord(JSON.stringify({ ts: 1234, message: { bytes: { 0: 2, 1: 6, 2: 10 } } }));
  assert.ok(legacyRetry.message.bytes instanceof Uint8Array, 'legacy numeric byte objects should be restored');
  assert.match(telegramSource, /serializeRetryRecord/, 'WhatsApp outgoing retry records should use the binary-safe codec');
  assert.match(telegramSource, /parseRetryRecord/, 'WhatsApp retry messages should be revived before resend');
  assert.match(telegramSource, /setMyCommands\(TELEGRAM_COMMANDS\)/, 'Telegram slash menu should synchronize at startup');
  for (const command of ['menu', 'help', 'pair', 'delpair', 'listpaired', 'listsession', 'broadcast']) {
    assert.match(telegramSource, new RegExp(`command: '${command}'`), `Telegram command menu must include /${command}`);
  }
  for (const entry of [
    'instagram / ig', 'tiktok / tkdl', 'facebook / fb', 'ping / pong', 'alive / speed / uptime',
  ]) assert.ok(menu.includes(entry), `menu must include ${entry}`);
  for (const removed of ['worldtime', 'wow', 'waaah', 'nice', 'soon', '😂', '🥳', 'thanks', 'prefix-free', 'paired number']) {
    assert.ok(!menu.includes(removed), `WhatsApp menu must not contain removed item: ${removed}`);
  }
  assert.match(source, /menuRuntimeFields/, 'WhatsApp menu system information should be refreshed dynamically');

  console.log(`PASS: ${aliases.length} social aliases, bare view-once shortcuts, paired-private delivery, binary retry codec, smart menus, validation/style, and status commands.`);
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
