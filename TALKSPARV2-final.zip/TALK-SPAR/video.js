'use strict';

const crypto = require('crypto');
const axios = require('axios');

const VIDEO_COMMANDS = ['video', 'ytvideo', 'ytv'];
const INNERTUBE_KEY = 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8';
const INNERTUBE_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const SAVETUBE_KEY = Buffer.from('C5D58EF67A7584E4A29F6C35BBC4EB12', 'hex');
const HEADERS = {
  'Content-Type': 'application/json',
  Origin: 'https://yt.savetube.me',
  'User-Agent': INNERTUBE_UA,
};

function decodeSaveTube(encoded) {
  const data = Buffer.from(String(encoded), 'base64');
  const iv = data.subarray(0, 16);
  const ciphertext = data.subarray(16);
  const decipher = crypto.createDecipheriv('aes-128-cbc', SAVETUBE_KEY, iv);
  return JSON.parse(Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString());
}

function cleanTitle(raw = '') {
  const original = String(raw).trim();
  const cleaned = original
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '')
    .replace(/[\(\[\{][^\)\]\}]*[\)\]\}]/g, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
  return cleaned || original || 'YouTube Video';
}

function youtubeId(url) {
  const match = String(url).match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/|embed\/))([A-Za-z0-9_-]{11})/i);
  return match?.[1] || null;
}

async function savetube(url, format = '360') {
  const id = youtubeId(url);
  if (!id) throw new Error('Invalid YouTube URL');

  const cdnResponse = await fetch('https://media.savetube.vip/api/random-cdn', {
    headers: HEADERS,
    signal: AbortSignal.timeout(15000),
  });
  const cdnData = await cdnResponse.json().catch(() => null);
  if (!cdnData?.cdn) throw new Error('SaveTube CDN unavailable');

  const infoResponse = await fetch(`https://${cdnData.cdn}/v2/info`, {
    method: 'POST',
    headers: HEADERS,
    body: JSON.stringify({ url: `https://www.youtube.com/watch?v=${id}` }),
    signal: AbortSignal.timeout(30000),
  });
  const info = await infoResponse.json().catch(() => null);
  if (!info?.data) throw new Error('Failed to fetch video info');

  const meta = decodeSaveTube(info.data);
  const downloadResponse = await fetch(`https://${cdnData.cdn}/download`, {
    method: 'POST',
    headers: HEADERS,
    body: JSON.stringify({ downloadType: 'video', quality: format, key: meta.key }),
    signal: AbortSignal.timeout(30000),
  });
  const download = await downloadResponse.json().catch(() => null);
  if (!download?.data?.downloadUrl) throw new Error(download?.message || 'Failed to generate download link');

  return {
    title: cleanTitle(meta.title),
    url: download.data.downloadUrl,
    duration: meta.duration,
    thumbnail: meta.thumbnail || `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
  };
}

async function getDirectVideo(url, preferred = '360') {
  const formats = [preferred, '480', '720', '240', '144'].filter((value, index, values) => values.indexOf(value) === index);
  let lastError;
  for (const format of formats) {
    try {
      const result = await savetube(url, format);
      if (result?.url) return result;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error('Failed to fetch direct video URL');
}

function findVideoRenderer(node, output) {
  if (!node || typeof node !== 'object') return;
  if (node.videoRenderer?.videoId) {
    output.push(node.videoRenderer);
    return;
  }
  for (const value of Object.values(node)) findVideoRenderer(value, output);
}

async function searchYoutube(query) {
  const input = String(query).trim();
  if (/^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\//i.test(input)) return input;

  const response = await fetch(`https://www.youtube.com/youtubei/v1/search?key=${INNERTUBE_KEY}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': INNERTUBE_UA,
      'X-Youtube-Client-Name': '1',
      'X-Youtube-Client-Version': '2.20240101.00.00',
    },
    body: JSON.stringify({
      context: { client: { clientName: 'WEB', clientVersion: '2.20240101.00.00', hl: 'en', gl: 'US' } },
      query: input,
    }),
    signal: AbortSignal.timeout(20000),
  });
  if (!response.ok) throw new Error(`YouTube search failed HTTP ${response.status}`);
  const json = await response.json();
  const found = [];
  findVideoRenderer(json.contents, found);
  if (!found.length) throw new Error('No video found');
  return `https://www.youtube.com/watch?v=${found[0].videoId}`;
}

function safeFileName(value) {
  return String(value || 'video').replace(/[\\/:*?"<>|]/g, '').trim().slice(0, 80) || 'video';
}

async function downloadVideo(url) {
  const response = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 120000,
    maxContentLength: 100 * 1024 * 1024,
    maxBodyLength: 100 * 1024 * 1024,
  });
  return Buffer.from(response.data);
}

async function handleVideoCommand(sock, jid, msg, command, params) {
  const query = params.join(' ').trim();
  if (!query) {
    await sock.sendMessage(jid, { text: `Example: .${command} shape of you` }, { quoted: msg });
    return true;
  }

  const react = async (text) => {
    try { await sock.sendMessage(jid, { react: { text, key: msg.key } }); } catch {}
  };

  await react('⏳');
  try {
    const youtubeUrl = await searchYoutube(query);
    const info = await getDirectVideo(youtubeUrl, '360');
    const buffer = await downloadVideo(info.url);
    await sock.sendMessage(jid, {
      video: buffer,
      mimetype: 'video/mp4',
      fileName: `${safeFileName(info.title)}.mp4`,
      caption: `🎬 ${info.title}`,
    }, { quoted: msg });
    await react('✅');
  } catch (error) {
    console.error('[video]', error);
    await react('❌');
    await sock.sendMessage(jid, {
      text: `❌ Failed to download the video.\n> Reason: ${error?.message || 'unknown'}`,
    }, { quoted: msg });
  }
  return true;
}

module.exports = { handleVideoCommand, VIDEO_COMMANDS, searchYoutube, getDirectVideo };
