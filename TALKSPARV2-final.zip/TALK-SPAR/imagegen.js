// ============================================================
//   imagegen.js  –  AI image creation commands
// ------------------------------------------------------------
//   imagine / aiimage / flux / text2img / dalle   free-form prompt
//   animeart / realistic / logo / wallpaper /
//   pixelart / cartoon3d                          preset styles
//   imgstyles                                     help card
//
//   The image is DOWNLOADED to a buffer and validated before it is sent, so
//   a provider error page can never be delivered as a "broken image".
//   Providers are tried in order until one returns a real image:
//     1. OpenAI images   (only if OPENAI_API_KEY is set)
//     2. Pollinations    model=flux
//     3. Pollinations    model=turbo
//   Flags:  --wide (1344x768)  --tall (768x1344)  --square (default)
//           --raw  skip the GPT prompt step and send the text as typed
//
//   GPT step: before drawing, a GPT chat model rewrites the request into a
//   detailed English image prompt that keeps EVERYTHING the user asked for
//   (subjects, counts, colours, text, setting, style) and only fills in what
//   was left open (composition, lighting, quality). Order tried:
//     OpenAI chat (OPENAI_API_KEY) -> Groq (GROQ_API_KEY) -> Pollinations GPT (keyless)
//   If every GPT provider fails the original prompt is used, so a command
//   never fails just because the helper is down.
// ============================================================
'use strict';
const axios = require('axios');

const IMAGEGEN_CMDS = [
  'imagine', 'aiimage', 'flux', 'text2img', 'dalle',
  'animeart', 'realistic', 'logo', 'wallpaper', 'pixelart', 'cartoon3d',
  'imgstyles',
];

const STYLES = {
  animeart:  { icon: '🌸', label: 'Anime art',  size: 'square', prefix: 'anime style illustration, detailed, vibrant colors, studio quality, ' },
  realistic: { icon: '📸', label: 'Realistic',  size: 'square', prefix: 'ultra realistic photograph, 8k, sharp focus, natural lighting, ' },
  logo:      { icon: '🏷️', label: 'Logo',       size: 'square', prefix: 'minimalist vector logo design, clean shapes, flat colors, white background, ' },
  wallpaper: { icon: '🖼️', label: 'Wallpaper',  size: 'tall',   prefix: 'phone wallpaper, high detail, cinematic, ' },
  pixelart:  { icon: '👾', label: 'Pixel art',  size: 'square', prefix: '16-bit pixel art, retro game style, ' },
  cartoon3d: { icon: '🧸', label: '3D cartoon', size: 'square', prefix: '3D cartoon render, pixar style, soft lighting, ' },
};

// gpt-image-1 and dall-e-3 accept different sizes.
const SIZES = {
  square: { w: 1024, h: 1024, openai: '1024x1024', openaiGpt: '1024x1024' },
  wide:   { w: 1344, h: 768,  openai: '1792x1024', openaiGpt: '1536x1024' },
  tall:   { w: 768,  h: 1344, openai: '1024x1792', openaiGpt: '1024x1536' },
};

function looksLikeImage(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 5000) return false;
  const jpg  = buf[0] === 0xFF && buf[1] === 0xD8;
  const png  = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47;
  const webp = buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP';
  return jpg || png || webp;
}

async function fetchBuffer(url, opts = {}) {
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 60000,
    headers: { 'User-Agent': 'Mozilla/5.0', Accept: 'image/*,*/*' },
    ...opts,
  });
  return Buffer.from(res.data);
}

const PROVIDERS = [
  {
    name: 'OpenAI',
    enabled: () => !!process.env.OPENAI_API_KEY,
    run: async (prompt, size) => {
      const model = process.env.OPENAI_IMAGE_MODEL || 'gpt-image-1';
      const isGpt = /^gpt-image/i.test(model);
      const body = { model, prompt, n: 1, size: isGpt ? size.openaiGpt : size.openai };
      if (isGpt) body.quality = process.env.OPENAI_IMAGE_QUALITY || 'high';
      const res = await axios.post('https://api.openai.com/v1/images/generations', body,
        { headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }, timeout: 120000 });
      const d = res?.data?.data?.[0];
      if (d?.b64_json) return Buffer.from(d.b64_json, 'base64');
      if (d?.url) return fetchBuffer(d.url);
      throw new Error('no image in OpenAI response');
    },
  },
  {
    name: 'Pollinations/flux',
    enabled: () => true,
    run: (prompt, size, seed) => fetchBuffer(
      `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${size.w}&height=${size.h}&nologo=true&model=flux&seed=${seed}`),
  },
  {
    name: 'Pollinations/turbo',
    enabled: () => true,
    run: (prompt, size, seed) => fetchBuffer(
      `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${size.w}&height=${size.h}&nologo=true&model=turbo&seed=${seed}`),
  },
];


// ── GPT prompt step ──────────────────────────────────────────
const REFINE_SYSTEM =
  'You write prompts for a text-to-image model. Turn the user\'s request into ONE detailed English prompt. ' +
  'Rules: (1) keep EVERY subject, number of subjects, colour, piece of text, place, mood and style the user asked for - never drop, replace or contradict them; ' +
  '(2) translate to English if needed; (3) add visual detail only where the user left it open: composition, lighting, camera or medium, background, quality; ' +
  '(4) if the image must contain written words, repeat them exactly inside quotes; (5) do not add people, logos or text the user did not ask for; ' +
  '(6) one paragraph, at most 110 words; (7) reply with ONLY the prompt, no quotes, no explanation.';

const CHAT_PROVIDERS = [
  {
    name: 'OpenAI GPT',
    enabled: () => !!process.env.OPENAI_API_KEY,
    url: 'https://api.openai.com/v1/chat/completions',
    headers: () => ({ Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }),
    model: () => process.env.OPENAI_CHAT_MODEL || 'gpt-4o-mini',
  },
  {
    name: 'Groq',
    enabled: () => !!process.env.GROQ_API_KEY,
    url: 'https://api.groq.com/openai/v1/chat/completions',
    headers: () => ({ Authorization: `Bearer ${process.env.GROQ_API_KEY}` }),
    model: () => 'llama-3.1-8b-instant',
  },
  {
    name: 'Pollinations GPT',
    enabled: () => true,
    url: 'https://text.pollinations.ai/openai',
    headers: () => ({}),
    model: () => 'openai',
  },
];

function cleanRefined(txt) {
  let t = String(txt || '').trim().replace(/^```[a-z]*\n?|```$/gi, '').replace(/^["'`]+|["'`]+$/g, '').replace(/\s+/g, ' ').trim();
  if (t.length < 8 || t.length > 1200) return null;
  if (/^(i'?m sorry|i am sorry|sorry|i can(?:no|')t|i cannot|as an ai)/i.test(t)) return null;
  return t;
}

async function refinePrompt(userPrompt, styleHint = '') {
  const content = styleHint ? `Style: ${styleHint}\nRequest: ${userPrompt}` : userPrompt;
  for (const p of CHAT_PROVIDERS) {
    if (!p.enabled()) continue;
    try {
      const res = await axios.post(p.url, {
        model: p.model(), temperature: 0.7, max_tokens: 260,
        messages: [{ role: 'system', content: REFINE_SYSTEM }, { role: 'user', content }],
      }, { headers: p.headers(), timeout: 20000 });
      const out = cleanRefined(res?.data?.choices?.[0]?.message?.content);
      if (out) return { prompt: out, by: p.name };
    } catch { /* try the next provider */ }
  }
  return { prompt: null, by: null };
}

async function generateImage(prompt, sizeKey = 'square') {
  const size = SIZES[sizeKey] || SIZES.square;
  const seed = Math.floor(Math.random() * 1e9);
  const errors = [];
  for (const p of PROVIDERS) {
    if (!p.enabled()) continue;
    try {
      const buf = await p.run(prompt, size, seed);
      if (looksLikeImage(buf)) return { buffer: buf, provider: p.name };
      errors.push(`${p.name}: not an image`);
    } catch (e) {
      errors.push(`${p.name}: ${e.response?.status || e.message}`);
    }
  }
  const err = new Error(errors.join(' | ') || 'no provider available');
  err.providers = errors;
  throw err;
}

// Pull --wide / --tall / --square out of the prompt.
function parseArgs(args) {
  let size = null;
  let raw = false;
  const words = [];
  for (const a of args) {
    const f = String(a).toLowerCase();
    if (f === '--wide' || f === '--tall' || f === '--square') size = f.slice(2);
    else if (f === '--raw') raw = true;
    else words.push(a);
  }
  return { prompt: words.join(' ').trim(), size, raw };
}

async function imageGenHandler(sock, m, cmd, args, h) {
  if (!IMAGEGEN_CMDS.includes(cmd)) return false;
  const { reply, replyImg, reaction } = h;
  const prefix = (h.cfg && h.cfg(sock)?.prefix) || '.';

  if (cmd === 'imgstyles') {
    await reply(
      `🎨 *IMAGE CREATION*\n\n` +
      `*${prefix}imagine <prompt>*  free-form image\n` +
      `*${prefix}aiimage* · *${prefix}flux* · *${prefix}text2img* · *${prefix}dalle*  same, other names\n\n` +
      `*Styles*\n` +
      Object.entries(STYLES).map(([k, s]) => `${s.icon} *${prefix}${k} <prompt>*  ${s.label}`).join('\n') +
      `\n\n*Shape flags:* --wide · --tall · --square\n` +
      `*--raw*  skip GPT and use your words exactly\n` +
      `GPT turns your idea into a detailed prompt, keeping everything you asked for.\n` +
      `Example: ${prefix}imagine a lion on a throne --wide`
    );
    return true;
  }

  const style = STYLES[cmd];
  const { prompt: userPrompt, size: flagSize, raw } = parseArgs(args);

  // Allow replying to a text message for the prompt.
  let prompt = userPrompt;
  if (!prompt) {
    try {
      const { qMsg } = h.getQuoted ? h.getQuoted(m) : {};
      prompt = (qMsg?.conversation || qMsg?.extendedTextMessage?.text || '').trim();
    } catch {}
  }
  if (!prompt) {
    await reply(`🎨 *${prefix}${cmd} <prompt>*\n\nDescribe the image you want.\nSee *${prefix}imgstyles* for styles and shapes.`);
    return true;
  }
  if (prompt.length > 600) prompt = prompt.slice(0, 600);

  const sizeKey = flagSize || (style && style.size) || 'square';
  const styleText = style ? style.prefix.replace(/,\s*$/, '') : '';

  try { await reaction('🎨'); } catch {}
  try {
    // GPT writes a detailed prompt that keeps everything that was asked for.
    let finalPrompt = style ? style.prefix + prompt : prompt;
    let by = null;
    if (!raw) {
      const r = await refinePrompt(prompt, styleText);
      if (r.prompt) {
        // keep the style words in front so presets always look like their preset
        finalPrompt = style && !r.prompt.toLowerCase().includes(styleText.split(',')[0].toLowerCase())
          ? `${style.prefix}${r.prompt}` : r.prompt;
        by = r.by;
      }
    }
    const { buffer, provider } = await generateImage(finalPrompt.slice(0, 1500), sizeKey);
    await replyImg(buffer, `${style ? style.icon : '🎨'} *${prompt}*\n_${style ? style.label : 'AI image'} · ${provider}${by ? ` · prompt by ${by}` : ''}_`);
    try { await reaction('✅'); } catch {}
  } catch (e) {
    console.log(`[imagegen] ${cmd} failed -> ${e.message}`);
    try { await reaction('❌'); } catch {}
    await reply(`❌ *Image creation failed.*\n\nThe image services are busy or down right now. Please try again in a moment.`);
  }
  return true;
}

module.exports = { imageGenHandler, IMAGEGEN_CMDS, generateImage, looksLikeImage, refinePrompt, cleanRefined };
