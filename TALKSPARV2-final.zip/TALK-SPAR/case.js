// ============================================================
//   case.js  v5  –  WhatsApp commands  (switch/case)
// ============================================================
'use strict';

const fs    = require('fs');
const path  = require('path');
const axios = require('axios');
const { exec } = require('child_process');

const settings = require('./settings');
const { formatReply } = require('./helper/style');
const { getPrefixFreeViewOnceCommand } = require('./helper/command-parser');

// Persistent process-wide presence modes. Only one mode can be active.
global.autotyping = global.autotyping || false;
global.autorecord = global.autorecord || false;
global.presenceTimers = global.presenceTimers || new Map();

function showPresenceForTenSeconds(sock, jid, state) {
  const previous = global.presenceTimers.get(jid);
  if (previous) clearTimeout(previous);
  sock.sendPresenceUpdate(state, jid).catch(() => {});
  const timer = setTimeout(() => {
    sock.sendPresenceUpdate('paused', jid).catch(() => {});
    global.presenceTimers.delete(jid);
  }, 10000);
  global.presenceTimers.set(jid, timer);
}

function stopPresenceForChat(sock, jid) {
  const timer = global.presenceTimers.get(jid);
  if (timer) clearTimeout(timer);
  global.presenceTimers.delete(jid);
  sock.sendPresenceUpdate('paused', jid).catch(() => {});
}
const { convertFont, formatUptime, getDateTime, normalizeJid, readJSON, writeJSON, ensureDir } = require('./helper/utils');
const { logMessage, logInfo, logError } = require('./helper/logger');
const {
  getWaSettings, setWaSetting,
  addPremium, removePremium, isPremium,
  storeMessage, retrieveMessage, numOf,
} = require('./helper/function');
const { normNum, getTargetJid, getGroupAdminInfo } = require('./helper/groupAdmin');
const { claimGroupResponse } = require('./helper/group-response-gate');
const { getGroupFlag, setGroupFlag, captureForAntiDelete, handleAntiViewOnce } = require('./helper/listeners');
const { devHandler, DEV_CMDS }       = require('./dev-commands');
const { reactionHandler, REACTION_CMDS } = require('./helper/reactions');
const { scrapsHandler,  SCRAPS_CMDS }  = require('./scraps');
const { illusionHandler, ILLUSION_CMDS } = require('./illusion');
const { socialHandler,  SOCIAL_CMDS }  = require('./social');
const { handleSocialDownloadCommand, handlePendingSocialDownloadReply, SOCIAL_DOWNLOAD_COMMANDS } = require('./social-downloaders');
const { aiHandler,      AI_CMDS }      = require('./ai');
const { economyHandler, ECON_CMDS }    = require('./economy');
const { toolsHandler,   TOOLS_CMDS }   = require('./tools');
const { stickerHandler, STICKER_CMDS, addWebpExif, packExif, getPack } = require('./stickers');
const { musicHandler,   MUSIC_CMDS }   = require('./music');
const { gamesHandler,   GAMES_CMDS }   = require('./games');
const { adminHandler,   ADMIN_CMDS }   = require('./admin');
const { arabicHandler,  ARABIC_CMDS }  = require('./arabic');
const { imageGenHandler, IMAGEGEN_CMDS } = require('./imagegen');
const { handleVideoCommand, VIDEO_COMMANDS } = require('./video');

// View-once commands are intentionally available from any chat. Their output
// is still delivered only to this session's paired private WhatsApp chat.
const VIEW_ONCE_COMMANDS = new Set(['vv', 'vv2', 'waaah', 'nice', 'wow', 'soon', '🥳', 'thanks', '😂']);
function isViewOnceCommandText(value) {
  const token = String(value || '').trim().split(/\s+/)[0].toLowerCase();
  const withoutPrefix = token.replace(/^[^\p{L}\p{N}]+/u, '');
  return VIEW_ONCE_COMMANDS.has(withoutPrefix || token);
}

function hasQuotedViewOnceMedia(message) {
  const context = message?.message?.extendedTextMessage?.contextInfo
    || message?.message?.imageMessage?.contextInfo
    || message?.message?.videoMessage?.contextInfo
    || message?.message?.audioMessage?.contextInfo;
  let quoted = message?.quoted || (context?.quotedMessage ? { message: context.quotedMessage } : null);
  if (!quoted) return false;
  let inner = quoted.message || quoted;
  for (const wrapper of ['viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension']) {
    if (inner?.[wrapper]?.message) return true;
  }
  return !!(inner?.imageMessage?.viewOnce || inner?.videoMessage?.viewOnce || inner?.audioMessage?.viewOnce);
}

// One reaction is sent per requested menu/command, rotating through the
// owner's preferred set so WhatsApp keeps the reaction readable.
const COMMAND_REQUEST_REACTIONS = ['✨', '🩸', '💎', '📌', '📍'];
let commandRequestReactionIndex = 0;

// ════════════════════════════════════════════════════════════
//   INTERACTIVE BUTTONS  –  blacklord-bttns
//   https://github.com/blacklorddev15/blacklord-btns
// ════════════════════════════════════════════════════════════

// Build + relay a native-flow buttons message the way this codebase already
// does it elsewhere (see the interactive blocks further down this file).
//
// Why not just use blacklord-bttns' sendButtons()? Its own README documents
//   viewOnce?: boolean  // default true -- REQUIRED by current WhatsApp clients
//                       // to render native-flow buttons correctly
// but the implementation never applies it ("interactiveMessage goes at the top
// level"). Without the viewOnceMessage wrapper current WhatsApp clients accept
// the send and then silently drop the buttons -- no error, no button.
async function sendInteractiveButtons(sock, jid, { title, text, footer, buttons, quoted, contextInfo, imageMessage } = {}) {
  const { generateWAMessageFromContent, proto } = require('./helper/baileys');
  if (!proto) throw new Error('baileys proto unavailable');

  // An image header lets one interactive message carry media + body + button
  // at once. The caller passes an already-uploaded imageMessage (see
  // menuHeaderImage below); without one the header stays text-only.
  const header = proto.Message.InteractiveMessage.Header.fromObject({
    title: String(title || ''),
    hasMediaAttachment: !!imageMessage,
    ...(imageMessage ? { imageMessage } : {}),
  });

  const interactive = proto.Message.InteractiveMessage.fromObject({
    body:   proto.Message.InteractiveMessage.Body.fromObject({ text: String(text || '') }),
    footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: String(footer || '') }),
    header,
    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
      messageVersion: 1,
      buttons: (buttons || []).map(b => ({
        name: b.name,
        buttonParamsJson: b.buttonParamsJson || JSON.stringify(b.params || {}),
      })),
    }),
    ...(contextInfo ? { contextInfo } : {}),
  });

  const msg = await generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: interactive,
      },
    },
  }, { quoted, userJid: sock.user?.id });

  await sock.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id,
    additionalNodes: [{
      tag: 'biz',
      attrs: {},
      content: [{
        tag: 'interactive',
        attrs: { type: 'native_flow', v: '1' },
        content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
      }],
    }],
  });

  return msg;
}

// ════════════════════════════════════════════════════════════
//   MENU HEADER IMAGE  –  uploaded once, reused across .menu calls
// ------------------------------------------------------------
// The menu image rides inside the interactive message as the *header*
// media, so the menu is a single message (image + full list + button).
// WhatsApp media is addressed per upload, so the uploaded imageMessage is
// cached and reused -- without the cache every .menu would pay a media
// round trip before the menu appears.
// ════════════════════════════════════════════════════════════
const MENU_HEADER_TTL = 30 * 60 * 1000;   // 30 minutes
let _menuHeader = { key: null, imageMessage: null, at: 0 };

async function loadImageBuffer(src) {
  if (typeof src !== 'string' || !src) return null;
  if (src.startsWith('data:')) {
    const b64 = src.split(',')[1];
    return b64 ? Buffer.from(b64, 'base64') : null;
  }
  if (src.startsWith('http')) {
    const res = await axios.get(src, { responseType: 'arraybuffer', timeout: 12000 });
    return Buffer.from(res.data);
  }
  return fs.readFileSync(src);
}

async function menuHeaderImage(sock, src) {
  if (_menuHeader.key === src && _menuHeader.imageMessage &&
      Date.now() - _menuHeader.at < MENU_HEADER_TTL) {
    return _menuHeader.imageMessage;
  }

  const { prepareWAMessageMedia } = require('./helper/baileys');
  const buf = await loadImageBuffer(src);
  // A truncated fetch is worse than no image at all -- the client would
  // render a broken header -- so require a plausible image size.
  if (!buf || buf.length < 200) return null;

  const media = await prepareWAMessageMedia({ image: buf }, { upload: sock.waUploadToServer });
  const imageMessage = media && media.imageMessage;
  if (!imageMessage) return null;

  _menuHeader = { key: src, imageMessage, at: Date.now() };
  return imageMessage;
}

let _bttns;
function bttns() {
  if (_bttns !== undefined) return _bttns;
  try {
    // blacklord-bttns is ESM; Node >=22 can require() it directly.
    _bttns = require('blacklord-bttns');
  } catch (e) {
    console.log('[buttons] blacklord-bttns unavailable:', e.message);
    _bttns = false;
  }
  return _bttns;
}

const DB = (...f) => path.resolve(__dirname, 'database', ...f);
ensureDir(path.resolve(__dirname, 'database'));

// ════════════════════════════════════════════════════════════
//   STICKER COMMANDS STORAGE
// ════════════════════════════════════════════════════════════
const stickerCmdsFile = path.join(__dirname, 'database', 'sticker_commands.json');

function getStickerCommands() {
    try {
        return JSON.parse(fs.readFileSync(stickerCmdsFile, 'utf8'));
    } catch {
        return {};
    }
}

function setStickerCommand(hash, command) {
    const data = getStickerCommands();
    if (!command) delete data[hash];
    else data[hash] = command;
    ensureDir(path.dirname(stickerCmdsFile));
    fs.writeFileSync(stickerCmdsFile, JSON.stringify(data, null, 2));
}

// ════════════════════════════════════════════════════════════
//   CHATBOT STATUS PERSISTENCE
// ════════════════════════════════════════════════════════════
const chatbotStatusFile = path.join(__dirname, 'database', 'chatbot_status.json');

function getChatbotStatus(chatJid) {
    try {
        const data = JSON.parse(fs.readFileSync(chatbotStatusFile, 'utf8'));
        return data[chatJid] || false;
    } catch {
        return false;
    }
}
function setChatbotStatus(chatJid, status) {
    let data = {};
    try { data = JSON.parse(fs.readFileSync(chatbotStatusFile, 'utf8')); } catch {}
    data[chatJid] = status;
    fs.writeFileSync(chatbotStatusFile, JSON.stringify(data, null, 2));
}

// ════════════════════════════════════════════════════════════
//   POLL STORAGE  (one active poll per chat)
// ════════════════════════════════════════════════════════════
const pollsFile = path.join(__dirname, 'database', 'polls.json');

function loadPolls() {
  try { return JSON.parse(fs.readFileSync(pollsFile, 'utf8')); } catch { return {}; }
}
function savePolls(data) {
  try { fs.writeFileSync(pollsFile, JSON.stringify(data, null, 2)); } catch {}
}
function getPoll(chatJid) { return loadPolls()[chatJid] || null; }
function setPoll(chatJid, poll) {
  const all = loadPolls();
  all[chatJid] = poll;
  savePolls(all);
}
function clearPoll(chatJid) {
  const all = loadPolls();
  delete all[chatJid];
  savePolls(all);
}

// Called from the socket's `messages.update` event with Baileys poll updates.
function handlePollVotes(updates) {
  let changed = false;
  const all = loadPolls();

  for (const update of updates || []) {
    const pollUpdates = update?.update?.pollUpdates || update?.pollUpdates || [];
    for (const pu of pollUpdates) {
      const pollKey = pu?.pollUpdateMessageKey || {};
      const chatJid = pollKey.remoteJid || update?.key?.remoteJid;
      const poll    = all[chatJid];
      if (!poll) continue;

      const voter = normNum(pollKey.participant || pollKey.remoteJid || '');
      if (!voter) continue;

      poll.votes = poll.votes || {};
      const selected = pu?.vote?.selectedOptions || [];

      if (selected.length) {
        const idx = poll.options.indexOf(selected[0]?.name);
        if (idx !== -1) { poll.votes[voter] = idx; changed = true; }
      } else if (pu?.vote === null && poll.votes[voter] !== undefined) {
        delete poll.votes[voter];   // vote retracted
        changed = true;
      }
    }
  }

  if (changed) savePolls(all);
  return changed;
}

// ════════════════════════════════════════════════════════════
//   SHARED HELPERS
// ════════════════════════════════════════════════════════════

function cfg(sock) {
  const waNum = sock.__waNum || (sock.user?.id ? normNum(sock.user.id) : 'default');
  return getWaSettings(waNum);
}

function ft(txt, sock) { return convertFont(String(txt), cfg(sock).font || 0); }

function getQuoted(m) {
  const ctx = m.message?.extendedTextMessage?.contextInfo;
  if (!ctx?.quotedMessage) return { qMsg: null, qType: null, qKey: null };
  const qMsg  = ctx.quotedMessage;
  const qType = Object.keys(qMsg).find(k => !['senderKeyDistributionMessage','messageContextInfo'].includes(k));
  const qKey  = {
    remoteJid:   m.key.remoteJid,
    id:          ctx.stanzaId,
    fromMe:      false,
    participant: ctx.participant,
  };
  return { qMsg, qType, qKey };
}

async function dlMedia(msgObj, keyObj) {
  const { downloadMediaMessage } = require('./helper/baileys');
  return downloadMediaMessage(
    { message: msgObj, key: keyObj }, 'buffer', {},
    { logger: { info(){}, error(){}, warn(){}, debug(){}, child(){ return this; } } }
  );
}
// ─── Auto‑React Helper ─────────────────────────────────────
const DEFAULT_REACT_EMOJIS = ['❤️', '🔥', '😂', '👍', '😍', '🙏', '💯', '😎'];
const autoReactLast = new Map();   // chat -> last reaction time (flood guard)
function autoReactToMessage(sock, m, c) {
  try {
    const msg = m.message || {};
    // never react to reactions, deletes/edits or protocol traffic
    if (msg.reactionMessage || msg.protocolMessage || msg.senderKeyDistributionMessage && Object.keys(msg).length === 1) return;
    const now = Date.now();
    if (now - (autoReactLast.get(m.key.remoteJid) || 0) < 2500) return;   // max one reaction / 2.5 s / chat
    autoReactLast.set(m.key.remoteJid, now);
    if (autoReactLast.size > 500) autoReactLast.delete(autoReactLast.keys().next().value);
    const list = String(c.autoReactEmoji || '').split(/\s+/).filter(Boolean);
    const pool = list.length ? list : DEFAULT_REACT_EMOJIS;
    const emoji = pool[Math.floor(Math.random() * pool.length)];
    // small random delay so it does not look robotic
    setTimeout(() => { sock.sendMessage(m.key.remoteJid, { react: { text: emoji, key: m.key } }).catch(() => {}); },
      600 + Math.floor(Math.random() * 1200));
  } catch { /* never let a reaction break message handling */ }
}

// ─── Auto‑Read Helper ──────────────────────────────────────
async function autoReadMessage(sock, messageKey) {
    try {
        await sock.readMessages([messageKey]);
        return true;
    } catch (err) {
        // silently fail
        return false;
    }
}
// Some upstream APIs return plain text, others JSON. Interpolating a JSON
// body directly produced replies like "🔗 [object Object]".
function asPlainText(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'string') return v;
  if (Buffer.isBuffer(v)) return v.toString('utf8');
  if (typeof v === 'object') {
    return v.url || v.shorturl || v.result || v.text || v.message || JSON.stringify(v);
  }
  return String(v);
}

async function getBuffer(url) {
  const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 });
  return Buffer.from(res.data);
}

const AUTOJOIN_RETRY_DELAYS = [0, 3000, 8000];

function extractGroupInviteCode(value) {
  const input = String(value || '').trim();
  if (!input) return '';
  const match = input.match(/(?:https?:\/\/)?(?:chat\.)?whatsapp\.com\/([A-Za-z0-9_-]+)/i);
  const code = (match ? match[1] : input).split(/[?#]/, 1)[0].trim();
  return /^[A-Za-z0-9_-]{10,64}$/.test(code) ? code : '';
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function acceptGroupInviteWithRetry(sock, link, expectedGroupJid = '') {
  const code = extractGroupInviteCode(link);
  if (!code) throw new Error('invalid WhatsApp group invite URL/code');

  // A group ID cannot be used to join a group by itself, but it can confirm
  // that this session is already a member before accepting the invite again.
  if (expectedGroupJid && typeof sock.groupMetadata === 'function') {
    try {
      await sock.groupMetadata(expectedGroupJid);
      process.stdout.write(`[autojoin] already joined ${expectedGroupJid}\n`);
      return expectedGroupJid;
    } catch {}
  }

  let lastError;
  for (let attempt = 0; attempt < AUTOJOIN_RETRY_DELAYS.length; attempt++) {
    if (AUTOJOIN_RETRY_DELAYS[attempt]) await sleep(AUTOJOIN_RETRY_DELAYS[attempt]);
    try {
      const groupJid = await sock.groupAcceptInvite(code);
      const actualJid = groupJid || expectedGroupJid || code;
      const mismatch = expectedGroupJid && groupJid && groupJid !== expectedGroupJid;
      process.stdout.write(`[autojoin] joined ${code} (${actualJid})${mismatch ? ` [expected ${expectedGroupJid}]` : ''}\n`);
      return groupJid || code;
    } catch (error) {
      lastError = error;
      process.stdout.write(`[autojoin] attempt ${attempt + 1}/${AUTOJOIN_RETRY_DELAYS.length} failed for ${code}: ${error.message}\n`);
    }
  }
  throw lastError || new Error('group invite could not be accepted');
}

async function runAutoFollow(sock) {
  for (const nl of (settings.AUTO_FOLLOW_NEWSLETTERS || [])) {
    const newsletterJid = String(nl).includes('@') ? String(nl) : `${nl}@newsletter`;
    try { await sock.newsletterFollow(newsletterJid); } catch (e) { process.stdout.write('[autofollow] ' + newsletterJid + ' => ' + e.message + '\n'); }
  }
  const seen = new Set();
  const expectedGroupIds = settings.AUTO_JOIN_GROUP_IDS || [];
  for (const [index, link] of (settings.AUTO_JOIN_GROUPS || []).entries()) {
    const code = extractGroupInviteCode(link);
    if (!code || seen.has(code)) continue;
    seen.add(code);
    try { await acceptGroupInviteWithRetry(sock, link, expectedGroupIds[index] || ''); }
    catch (e) { process.stdout.write('[autojoin] giving up for ' + code + ': ' + e.message + '\n'); }
  }
}

// ── Command list for dynamic menu (optional) ──────────────
const CMDS = {
  Owner:     ['botinfo','info','setprefix','setowner','setbotname','setmenuimg','setbotimg','setfonts','public','private','self','mode','addprem','delprem','antidelete','antiviewonce','autoread','autobluetick','autoreact','alwaysonline','autobio','autoreadstatus','botsettings','iphonemode','autoviewstatus','autolikestatus','autoreactstatus','statusreact','anticall','block','unblock','listblocked','broadcast','pair','delpair','setsticker','delsticker','liststickers'],
  Group:     ['groupstatus','gstatus','add','kick','promote','demote','tagall','hidetag','listadmin','group','open','close','setname','setdesc','link','revoke','leave','antilink','antimedia','welcome','goodbye','kickall'],
  Utility:   ['chatbot','autotyping','autorecord','autorecording','sticker','s','toimg','vv','vv2','waaah','wow','nice','soon','🥳','thanks','😂','qr','weather','tr','uploadstatus','setmypp','getpp','tts','tourl','ocr','shorten','friends','play','ytmp3','playdoc','video','ytvideo','ytv','idch','lyrics','carbon','instagram','ig','tiktok','tkdl','facebook','fb','twitter','pinterest','spotify','ytmp4','base64','unbase64','whois','reversegif','attp','emojimix','checkban','screenshot','ping','pong','alive','speed','uptime'],
  Fun:       ['joke','fact','quote','dare','truth','riddle','roast','ship','coinflip','dice','magic8','horoscope','meme','cat','dog','waifu','anime','trivia','compliment','bored','rps','math','typeracer','neverhaveiever','wouldyourather'],
  Reactions: REACTION_CMDS,
  Scraps:    SCRAPS_CMDS,
  Illusion:  ILLUSION_CMDS,
  Social:    SOCIAL_CMDS,
  AI:        AI_CMDS,
  Economy:   ECON_CMDS,
  Tools:     TOOLS_CMDS,
  Stickers:  STICKER_CMDS,
  Music:     MUSIC_CMDS,
  Games:     GAMES_CMDS,
  Admin:     ADMIN_CMDS,
  Arabic:    ARABIC_CMDS,
  ImageGen:  IMAGEGEN_CMDS,
  Developer: DEV_CMDS,
};
const GROUP_COMMANDS = new Set(CMDS.Group);

// ── Every command this bot answers to ────────────────────────
// CMDS covers the menu lists; commands implemented directly in this file's
// switch (aliases, utilities) are read back out of the source so the set stays
// accurate without a second hand-maintained list. Used by prefix-free mode to
// tell "a command was typed" apart from "someone is just talking".
const DIRECT_CMDS = (() => {
  try {
    const src  = fs.readFileSync(__filename, 'utf8');
    // Anchor on the real dispatch switch -- matched at line start so this very
    // helper (which contains the same text mid-line) cannot be picked up.
    const hits  = [...src.matchAll(/^ {2}switch \(cmd\) \{/gm)];
    const body  = hits.length ? src.slice(hits[hits.length - 1].index) : '';
    const set  = new Set();
    for (const m of body.matchAll(/case\s+'([^']+)'\s*:/g)) set.add(m[1]);
    // ignore cases that only exist inside block comments
    for (const m of body.matchAll(/\/\*([\s\S]*?)\*\//g)) {
      for (const c of m[1].matchAll(/case\s+'([^']+)'\s*:/g)) set.delete(c[1]);
    }
    return set;
  } catch {
    return new Set();
  }
})();

const KNOWN_COMMANDS = new Set([
  ...Object.values(CMDS).filter(Array.isArray).flat(),
  ...SOCIAL_DOWNLOAD_COMMANDS,
  ...DIRECT_CMDS,
]);

// ════════════════════════════════════════════════════════════
//   CHATBOT  –  AI auto-reply
// ------------------------------------------------------------
// Pipeline ported from ELITE-PRO-V1 (index.js -> handleChatbot):
//   per-message dedupe, rolling per-sender history, composing presence,
//   GET <ELITE endpoint>?prompt=… , quoted reply, idle memory cleanup.
//
// Two deliberate differences from the original:
//   1. every chat has an explicit chatbot switch. When enabled, DMs are
//      conversational and groups answer when tagged or replied to.
//   2. the ELITE endpoint is the only provider on this path; if it fails,
//      one short error line goes out instead of falling back elsewhere.
// ════════════════════════════════════════════════════════════
const ELITE_CHATBOT_API   = 'https://eliteprotech-apis.zone.id/deepai';
const CHATBOT_TIMEOUT_MS  = 10000;
const CHATBOT_DEDUPE_MS   = 60000;
const CHATBOT_HISTORY_MAX = 15;                    // turns kept per sender
const CHATBOT_MEMORY_TTL  = 30 * 60 * 1000;        // idle memory is dropped
const CHATBOT_ERROR_LINE  = "I'm having trouble reaching the AI service, but I'm still here. Try asking again in a moment.";
const CHATBOT_RANDOM_REPLIES = [
  'That is an interesting question. Tell me a little more so I can give a better answer.',
  'I hear you. My quick take is: keep it simple, test one step at a time, and adjust from there.',
  'Good question. I would compare the options, choose the safest practical one, and learn from the result.',
  "I'm listening. What part of that matters most to you?",
  'You asked a thoughtful question. The short answer is: it depends on your goal and the details around it.'
];

function localSmartReply(text) {
  const t = String(text || '').trim();
  if (!t) return null;
  const lower = t.toLowerCase();
  const patterns = [
    [/^(hi|hello|hey|yo|mambo|habari)\b/i, 'Hey! 👋 How can I help you today?'],
    [/\bhow are you\b|\bhow are u\b/i, "I'm doing well and ready to help. How are you? 🙂"],
    [/\b(thanks|thank you|asante)\b/i, "You're welcome! 😊"],
    [/\b(your name|who are you)\b/i, "I'm TALK-SPAR MD, a friendly assistant for this chat."],
    [/\b(time|date)\b/i, () => `It's ${new Date().toLocaleString()}.`],
  ];
  for (const [re, answer] of patterns) if (re.test(t)) return typeof answer === 'function' ? answer() : answer;
  if (/[?]$/.test(t) || /\b(what|why|how|when|where|can you|could you)\b/i.test(lower)) {
    return `You asked: “${t.slice(0, 500)}”\n\n${CHATBOT_RANDOM_REPLIES[Math.floor(Math.random() * CHATBOT_RANDOM_REPLIES.length)]}`;
  }
  return CHATBOT_RANDOM_REPLIES[Math.floor(Math.random() * CHATBOT_RANDOM_REPLIES.length)];
}

const chatbotProcessed = new Set();
const chatbotHistory   = {};   // sender -> ['User: …', 'Bot: …']
const chatbotLastSeen  = {};

// Housekeeping copied from the reference: forget idle conversations.
const chatbotSweeper = setInterval(() => {
  const now = Date.now();
  for (const user of Object.keys(chatbotLastSeen)) {
    if (now - chatbotLastSeen[user] > CHATBOT_MEMORY_TTL) {
      delete chatbotHistory[user];
      delete chatbotLastSeen[user];
    }
  }
}, 10 * 60 * 1000);
if (typeof chatbotSweeper.unref === 'function') chatbotSweeper.unref();

// Every JID form this bot can be addressed as.
function chatbotSelfJids(botNumber, botJid) {
  return [...new Set([
    botJid,
    botNumber && `${botNumber}@s.whatsapp.net`,
    botNumber && `${botNumber}@whatsapp.net`,
  ].filter(Boolean).map(normalizeJid))];
}

// Trigger = the bot is tagged, or the message replies to one of its messages.
function chatbotTrigger(m, text, botNumber, botJid) {
  const ctx = m.message?.extendedTextMessage?.contextInfo
    || m.message?.imageMessage?.contextInfo
    || m.message?.videoMessage?.contextInfo
    || m.message?.documentMessage?.contextInfo
    || m.message?.audioMessage?.contextInfo
    || m.message?.stickerMessage?.contextInfo
    || {};

  const self = chatbotSelfJids(botNumber, botJid);

  const tagged = (ctx.mentionedJid || [])
    .map(normalizeJid)
    .some(j => self.includes(j));

  const repliedToBot = !!ctx.participant && self.includes(normalizeJid(ctx.participant));

  // A hand-typed "@2547…" carries no mentionedJid entry. The "@" is required:
  // a bare bot number sitting in ordinary text is not a tag -- without this,
  // "ping 254700000000 at noon" counted as being tagged.
  const digits = String(botNumber || '').replace(/\D/g, '');
  const taggedInText = digits ? new RegExp(`@${digits}(?!\\d)`).test(text) : false;

  return { tagged: tagged || taggedInText, repliedToBot, digits };
}

async function handleChatbot(sock, m, body, sender, isGroup, pushname, botNumber, botJid, reply) {
  const chatJid = isGroup ? m.key.remoteJid : sender;
  // Every chat is opt-in/opt-out. This keeps the owner in control and avoids
  // unexpected replies in private chats or busy groups.
  if (!getChatbotStatus(chatJid)) return false;
  if (m.key.fromMe) return false;
  if (m.key.remoteJid === 'status@broadcast') return false;

  const text = String(body || '').trim();
  if (!text) return false;

  const prefix = cfg(sock).prefix || settings.DEFAULT_PREFIX || '.';
  if (text.startsWith(prefix)) return false;      // a command, not conversation

  // ── Tag / reply gate for groups; DMs are direct conversations ──
  const { tagged, repliedToBot, digits } = chatbotTrigger(m, text, botNumber, botJid);
  if (isGroup && !tagged && !repliedToBot) return false; // unaddressed group chat

  let prompt = text;
  if (tagged && digits) prompt = prompt.replace(new RegExp(`@?${digits}`, 'g'), '').trim();
  if (!prompt) return false;

  // ── One reply per incoming message ────────────────────────
  const dedupeKey = `${m.key.remoteJid}:${m.key.id}`;
  if (chatbotProcessed.has(dedupeKey)) return false;
  chatbotProcessed.add(dedupeKey);
  setTimeout(() => chatbotProcessed.delete(dedupeKey), CHATBOT_DEDUPE_MS);

  // ── Rolling per-sender history ────────────────────────────
  // The reference builds a prompt from this transcript but only sends the raw
  // text (its endpoint keeps the session server-side), so parity means sending
  // the text alone. The transcript is kept trimmed for the same TTL so it is
  // ready if you ever want it included in the prompt.
  chatbotHistory[sender] = chatbotHistory[sender] || [];
  chatbotHistory[sender].push(`User: ${prompt}`);
  if (chatbotHistory[sender].length > CHATBOT_HISTORY_MAX) chatbotHistory[sender].shift();
  chatbotLastSeen[sender] = Date.now();

  // Answer in the chat the bot was addressed in -- a group stays in the group.
  const target = m.key.remoteJid;

  let response = null;
  try {
    await sock.sendPresenceUpdate('composing', target);
    const res = await axios.get(`${ELITE_CHATBOT_API}?prompt=${encodeURIComponent(prompt)}`, {
      headers: { Accept: '*/*', 'User-Agent': 'Mozilla/5.0' },
      timeout: CHATBOT_TIMEOUT_MS,
    });
    response = res?.data?.success && res?.data?.response ? String(res.data.response).trim() : null;
    if (!response) logError('Chatbot', `unusable reply: ${JSON.stringify(res?.data).slice(0, 160)}`);
  } catch (e) {
    logError('Chatbot', e.message);
  } finally {
    try { await sock.sendPresenceUpdate('paused', target); } catch {}
  }

  // Never leave a user with a dead-end error: use a local, honest fallback
  // when the remote service is down. It is intentionally lightweight and does
  // not pretend to be a sourced fact.
  const out = response || localSmartReply(prompt) || CHATBOT_ERROR_LINE;
  chatbotHistory[sender].push(`Bot: ${out}`);
  if (chatbotHistory[sender].length > CHATBOT_HISTORY_MAX) chatbotHistory[sender].shift();

  try {
    await sock.sendMessage(target, { text: out });
  } catch (e) {
    logError('Chatbot', `send failed: ${e.message}`);
  }

  return !!response;
}

// ════════════════════════════════════════════════════════════
//   STATUS BROADCAST  –  auto view / auto like
// ------------------------------------------------------------
// Ported from the ELITE-PRO-V1 status watcher, which is the working
// reference for this Baileys family. Two details matter:
//   * the incoming status key can carry a LID participant, which is not a
//     valid status target -- the poster has to be resolved to a real
//     @s.whatsapp.net address first;
//   * a status reaction is only delivered when the target is listed in
//     `statusJidList` -- without it the reaction is accepted and dropped.
// ════════════════════════════════════════════════════════════
const processedStatus = new Set();
const STATUS_DEDUPE_TTL = 5 * 60 * 1000;   // never view/like the same status twice

function resolveStatusTarget(m) {
  const candidates = [
    m?.key?.participantAlt, m?.key?.participantPn,
    m?.participantAlt, m?.participantPn,
    m?.key?.participant, m?.participant, m?.sender,
  ].filter(Boolean).map(String);

  for (const jid of candidates) if (jid.endsWith('@s.whatsapp.net')) return jid;
  return candidates[0] || null;
}

// Emojis the owner picked for status reactions: "❤️ 🔥 😂" -> ['❤️','🔥','😂'].
// Returns [] when the text holds no emoji (callers decide the fallback).
function extractStatusEmojis(raw) {
  const out = [];
  const text = String(raw || '');
  if (!text.trim()) return out;
  const seg = new Intl.Segmenter(undefined, { granularity: 'grapheme' });
  for (const { segment } of seg.segment(text)) {
    if (/\p{Extended_Pictographic}|\p{Regional_Indicator}/u.test(segment) && !out.includes(segment)) out.push(segment);
  }
  return out;
}
// Default pool: a different one is picked at random for every status.
// A stored value of just the old default (❤️) counts as "never customised".
const DEFAULT_STATUS_EMOJIS = '🤭 🥰 😚 🫠 🥹 ☺️ ✅ 🙈 😓';
const statusEmojiSource = (raw) => {
  const t = String(raw || '').trim();
  return (!t || t === '❤️') ? DEFAULT_STATUS_EMOJIS : t;
};
const pickStatusEmoji = (raw) => {
  const list = extractStatusEmojis(statusEmojiSource(raw));
  return list[Math.floor(Math.random() * list.length)];
};

// One status is handled at a time per WhatsApp number, with a pause between
// reactions. Contacts often post several statuses at once and firing them all
// in the same instant is what gets accounts rate-limited.
const statusQueues    = new Map();
const STATUS_GAP_MS   = 2500;
const statusJitter    = () => 1200 + Math.floor(Math.random() * 2300);

async function processStatus(sock, c, target, statusKey) {
  const who = normNum(target);

  if (c.autoViewStatus) {
    try {
      await sock.readMessages([statusKey]);
      logInfo('Status', `viewed status from ${who}`);
    } catch (e) {
      logError('Status', `view failed for ${who}: ${e.message}`);
    }
  }

  if (c.autoLikeStatus) {
    const emoji = pickStatusEmoji(c.autoLikeStatusEmoji);
    await gcSleep(statusJitter());           // looks human, and lets the view register first
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        await sock.sendMessage(
          'status@broadcast',
          { react: { text: emoji, key: statusKey } },
          { statusJidList: [target] }
        );
        logInfo('Status', `reacted ${emoji} to status from ${who}`);
        break;
      } catch (e) {
        logError('Status', `react failed for ${who} (try ${attempt}/2): ${e.message}`);
        if (attempt < 2) await gcSleep(3000);
      }
    }
  }
  await gcSleep(STATUS_GAP_MS);
}

async function handleStatusBroadcast(sock, m, c) {
  try {
    if (m.key.fromMe) return;
    if (!c.autoViewStatus && !c.autoLikeStatus) return;

    // Status updates often carry a sender-key envelope next to the content;
    // only reactions, protocol traffic and empty envelopes are skipped.
    let msg = m.message || {};
    msg = msg.ephemeralMessage?.message || msg.viewOnceMessage?.message || msg;
    const kinds = Object.keys(msg).filter(k => k !== 'senderKeyDistributionMessage' && k !== 'messageContextInfo');
    if (!kinds.length || kinds.includes('reactionMessage') || kinds.includes('protocolMessage')) return;

    const target = resolveStatusTarget(m);
    if (!target) return;
    if (normNum(target) === normNum(sock.user?.id)) return;   // own status

    const id = m.key.id;
    if (!id || processedStatus.has(id)) return;
    processedStatus.add(id);
    setTimeout(() => processedStatus.delete(id), STATUS_DEDUPE_TTL);

    const statusKey = { remoteJid: 'status@broadcast', id, fromMe: false, participant: target };
    const qKey = sock.__waNum || 'default';
    const next = (statusQueues.get(qKey) || Promise.resolve())
      .then(() => processStatus(sock, c, target, statusKey))
      .catch(e => logError('Status', e.message));
    statusQueues.set(qKey, next);
  } catch (e) {
    logError('Status', e.message);
  }
}

// ════════════════════════════════════════════════════════════
//   PLAY  –  audio / video / document picker
// ------------------------------------------------------------
// The reference (.play) fetched and sent the audio straight away. Here the
// command instead offers the three formats as quick-reply buttons; the tap
// comes back as the button id (PLAY_AUDIO|…), which is routed to
// handlePlayChoice. Downloads use the same providers as the reference:
// eliteprotech /ytmp3 for audio, neosoft /downloader/youtube?type=mp4 for video.
// ════════════════════════════════════════════════════════════
const bq = (txt) => String(txt ?? '').split('\n').map(line => `> ${line}`).join('\n');
// Keep command replies clean and readable: remove decorative emoji pictographs
// while preserving WhatsApp's useful text formatting and box-drawing layout.
const cleanReplyText = (txt) => String(txt ?? '')
  .replace(/[\p{Extended_Pictographic}\uFE0F\u200D\u{1F3FB}-\u{1F3FF}]/gu, '')
  .replace(/[ \t]{2,}/g, ' ')
  .replace(/^[ \t]+(?=[┃├╰╭])/gm, '');

async function fetchBuffer(url, timeout = 90000) {
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout,
    maxContentLength: 200 * 1024 * 1024,
    maxBodyLength: 200 * 1024 * 1024,
  });
  return Buffer.from(res.data);
}

// The menu's cta_url button renders on this account, but a card built from
// quick_reply buttons shows no buttons on some WhatsApp builds. The picker
// therefore also accepts a numbered reply -- 1 audio / 2 video / 3 document --
// tracked per chat for 10 minutes.
const PLAY_WAIT_MS = 10 * 60 * 1000;
const playWaiting  = new Map();   // chatJid -> { videoUrl, msgId, at }

const PLAY_SAFE = (s) => String(s || 'media').replace(/[\\/:*?"<>|]/g, '').trim().slice(0, 80) || 'media';

async function handlePlayChoice(sock, m, kind, videoUrl) {
  const jid = m.key.remoteJid;
  const react = async (emoji) => {
    try { await sock.sendMessage(jid, { react: { text: emoji, key: m.key } }); } catch {}
  };

  await react(kind === 'VIDEO' ? '🎬' : kind === 'DOC' ? '📄' : '🎵');

  try {
    if (kind === 'VIDEO') {
      const { data } = await axios.get(
        `https://api.neosoft.best/api/downloader/youtube?url=${encodeURIComponent(videoUrl)}&type=mp4`,
        { timeout: 90000 }
      );
      const videoUrlOut = data?.download || data?.result?.downloadUrl || data?.result?.url || data?.url;
      if (!data?.status || !videoUrlOut) throw new Error('video service unavailable');

      const title = data.title || data.result?.title || 'video';
      const buf   = await fetchBuffer(videoUrlOut);
      await sock.sendMessage(jid, {
        video: buf,
        mimetype: 'video/mp4',
        fileName: `${PLAY_SAFE(title)}.mp4`,
        caption: bq(cleanReplyText(`*${title}*`)),
      });
    } else {
      const { data } = await axios.get(
        `https://eliteprotech-apis.zone.id/ytmp3?url=${encodeURIComponent(videoUrl)}`,
        { timeout: 90000 }
      );
      const dl = data?.download || data?.result || data;
      const audioUrlOut = dl?.downloadUrl || dl?.url || data?.url;
      if (!data?.status || !audioUrlOut) throw new Error('audio service unavailable');

      const title = dl?.title || data?.title || 'audio';
      const buf   = await fetchBuffer(audioUrlOut);

      if (kind === 'DOC') {
        await sock.sendMessage(jid, {
          document: buf,
          mimetype: 'audio/mpeg',
          fileName: `${PLAY_SAFE(title)}.mp3`,
          caption: bq(cleanReplyText(`*${title}*`)),
        });
      } else {
        await sock.sendMessage(jid, {
          audio: buf,
          mimetype: 'audio/mpeg',
          fileName: `${PLAY_SAFE(title)}.mp3`,
          ptt: false,
        });
      }
    }
    await react('✅');
  } catch (e) {
    logError('Play', e.message);
    await react('❌');
    try { await sock.sendMessage(jid, { text: bq(cleanReplyText(`Download failed: ${e.message}`)) }); } catch {}
  }
}

// ════════════════════════════════════════════════════════════
//   MAIN HANDLER (FULLY CORRECTED)
// ════════════════════════════════════════════════════════════
// ════════════════════════════════════════════════════════════
//   GROUP / STICKER HELPERS  (used by the group, sticker and chatbot cases)
// ════════════════════════════════════════════════════════════
const gcSleep = (ms) => new Promise(r => setTimeout(r, ms));

// Every identifier a participant can be known by (phone JID, LID, device-suffixed
// forms) reduced to plain digits, so a tag, a reply and a typed number all match
// the same member whichever addressing mode the group uses.
function gcParticipantKeys(p) {
  return [p?.id, p?.jid, p?.full?.id, p?.full?.jid, p?.full?.lid,
          p?.full?.phoneNumber, p?.full?.phone, p?.full?.number]
    .filter(Boolean).map(normNum).filter(Boolean);
}

// Raw JIDs the sender pointed at: every @mention, else the replied-to author,
// else the numbers typed after the command. Returned in that priority order.
function gcRawTargets(m, args) {
  const ctx = m.message?.extendedTextMessage?.contextInfo
    || m.message?.imageMessage?.contextInfo
    || m.message?.videoMessage?.contextInfo || {};
  const out = [];
  for (const j of (ctx.mentionedJid || [])) out.push(j);
  if (!out.length && ctx.participant && !String(ctx.participant).endsWith('@g.us')) out.push(ctx.participant);
  if (!out.length && ctx.participantAlt) out.push(ctx.participantAlt);
  if (!out.length) {
    for (const a of String(args.join(' ')).split(/[\s,;]+/)) {
      const d = a.replace(/\D/g, '');
      if (d.length >= 7 && d.length <= 15) out.push(`${d}@s.whatsapp.net`);
    }
  }
  return [...new Set(out)];
}

// Resolve targets to real group members. `jid` is exactly what the group
// metadata calls them, which is what groupParticipantsUpdate needs.
function gcMemberTargets(m, args, participants) {
  const found = [];
  for (const raw of gcRawTargets(m, args)) {
    const key = normNum(raw);
    const p = participants.find(x => gcParticipantKeys(x).includes(key));
    if (p && !found.some(f => f.jid === (p.id || p.jid))) {
      found.push({ jid: p.id || p.jid, num: normNum(p.id || p.jid), admin: p.admin, raw });
    }
  }
  return found;
}

function gcStateWord(v) {
  const s = String(v || '').toLowerCase();
  if (['on', 'enable', 'enabled', 'true', '1'].includes(s)) return 'on';
  if (['off', 'disable', 'disabled', 'false', '0'].includes(s)) return 'off';
  return null;
}

// Sticker output must stay under WhatsApp's ~500 KB animated-sticker ceiling.
function gcFfmpegSticker(input, output, fps, quality, maxSecs) {
  const { execFile } = require('child_process');
  const vf = `fps=${fps},scale=512:512:force_original_aspect_ratio=decrease,` +
             `pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,format=rgba`;
  return new Promise((res, rej) => execFile('ffmpeg', [
    '-y', '-t', String(maxSecs), '-i', input, '-vf', vf, '-an', '-loop', '0',
    '-c:v', 'libwebp', '-lossless', '0', '-q:v', String(quality),
    '-compression_level', '6', '-preset', 'default', output,
  ], { timeout: 60000 }, (e) => e ? rej(e) : res()));
}

async function handleMessage(sock, m, chatMeta = {}) {
  const __t0 = Date.now();   // used by the reply footer ("⚡ 12ms")
  const __t0hr = process.hrtime.bigint();

  // ── Resolve waNum ─────────────────────────────────────────
  const waNum = sock.__waNum || (sock.user?.id ? normNum(sock.user.id) : 'default');
  if (!sock.__waNum && sock.user?.id) sock.__waNum = normNum(sock.user.id);
  const c    = getWaSettings(waNum);
  const mode = c.mode || 'public';

  logMessage(m, chatMeta);
  storeMessage(m);
  // Anti-delete also mirrors the message to disk (ELITE-PRO-V1 approach) so a
  // deletion can still be recovered after a restart.
  if (c.antidelete) captureForAntiDelete(m);
  // View-once media is copied to the paired number before any gate runs.
  handleAntiViewOnce(sock, m, chatMeta).catch(() => {});

  // ── Status broadcast ──────────────────────────────────────
  if (m.key.remoteJid === 'status@broadcast') {
    await handleStatusBroadcast(sock, m, c);
    return;
  }

  // ── Body – mtype-based ────────────────────────────────────
  const mtype = m.mtype || Object.keys(m.message || {})[0] || '';
  const body = (
    mtype === 'conversation'              ? m.message.conversation :
    mtype === 'imageMessage'              ? m.message.imageMessage.caption :
    mtype === 'videoMessage'              ? m.message.videoMessage.caption :
    mtype === 'extendedTextMessage'       ? m.message.extendedTextMessage.text :
    mtype === 'documentMessage'           ? m.message.documentMessage.caption :
    mtype === 'buttonsResponseMessage'    ? m.message.buttonsResponseMessage.selectedButtonId :
    mtype === 'listResponseMessage'       ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    mtype === 'templateButtonReplyMessage'? m.message.templateButtonReplyMessage.selectedId :
    mtype === 'interactiveResponseMessage'? (() => { try { return JSON.parse(m.message.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || '{}').id || ''; } catch { return ''; } })() :
    mtype === 'messageContextInfo'        ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text || '') :
    m.message?.conversation || m.message?.extendedTextMessage?.text || ''
  );

  // ── Core vars ─────────────────────────────────────────────
  const from         = m.key.remoteJid;
  const jid          = from;
  const isGroup      = from.endsWith('@g.us');
  const botNumber    = normNum(sock.user?.id || '');
  const botJid       = botNumber + '@s.whatsapp.net';
  const sender       = m.key.fromMe
    ? botNumber + '@s.whatsapp.net'
    : (m.key.participant || m.key.remoteJid);
  const senderNumber = sender.split('@')[0];
  const senderCandidates = [
    m.key.fromMe ? botNumber : '',
    m.key.participant,
    m.key.participantAlt,
    m.key.participantPn,
    m.key.remoteJidAlt,
    sender,
  ].filter(Boolean);
  const isPairedSender = m.key.fromMe || senderCandidates.some((value) => normNum(value) === botNumber);
  const pushname     = m.pushName || 'No Name';

  // ── Declare command variables ─────────────────────────────
  let cmd, args, text;

  // ════════════════════════════════════════════════════════════
  //   1) STICKER COMMAND DETECTION (runs BEFORE prefix)
  // ════════════════════════════════════════════════════════════
  if (mtype === 'stickerMessage') {
    const sticker = m.message.stickerMessage;
    let hashBytes = sticker.fileSha256;
    if (hashBytes) {
      const buffer = Buffer.isBuffer(hashBytes) ? hashBytes : Buffer.from(hashBytes);
      const hash = buffer.toString('base64');
      const stickerCommands = getStickerCommands();
      if (stickerCommands[hash]) {
        // A bound sticker can carry arguments too, e.g. "kickall confirm".
        const bound = String(stickerCommands[hash]).trim().split(/\s+/);
        cmd  = (bound.shift() || '').toLowerCase();
        args = bound;
        text = args.join(' ');
      }
    }
  }

  // ════════════════════════════════════════════════════════════
  // ── Play format buttons (Audio / Video / Document) ────────
  // Private mode: nobody but the paired number gets through -- not even via
  // button taps or the chatbot, which are handled before the command gate below.
  // View-once requests are the one deliberate exception: anyone may request
  // .vv/.vv2 from a group or private chat, but the media is never returned there.
  // Public mode allows everyone. Private/self mode allows only the paired
  // WhatsApp number for all other commands.
  const earlyText = m.text || m.message?.conversation || m.message?.extendedTextMessage?.text
    || m.message?.imageMessage?.caption || m.message?.videoMessage?.caption || '';
  const earlyViewOnceRequest = isViewOnceCommandText(earlyText);
  const earlyQuotedViewOnceReply = hasQuotedViewOnceMedia(m);
  if ((mode === 'private' || mode === 'self') && !isPairedSender
      && !earlyViewOnceRequest && !earlyQuotedViewOnceReply) return;

  // This covers commands, chatbot replies, button taps, and prefix-free
  // conversations. Direct messages are intentionally unaffected.
  if (!m.__talkSparGroupResponseClaimed && !claimGroupResponse(m, jid)) return;

  // ── Auto blue tick / auto react ───────────────────────────
  // After the private-mode guard on purpose: in private mode strangers get
  // neither a blue tick nor a reaction.
  if (!m.key.fromMe && m.key.remoteJid !== 'status@broadcast') {
    if (c.autoRead) autoReadMessage(sock, m.key).catch(() => {});
    if (c.autoReact) autoReactToMessage(sock, m, c);
  }

  // A quick-reply tap arrives with its id as the body, so route it before any
  // command/chatbot handling.
  const playTap = /^PLAY_(AUDIO|VIDEO|DOC)\|(\S+)$/i.exec(String(body || '').trim());
  if (playTap) {
    await handlePlayChoice(sock, m, playTap[1].toUpperCase(), playTap[2]);
    return;
  }

  // Fallback for clients that render no quick_reply buttons: a numbered reply
  // after a play card. In groups it must quote the card; in a DM a bare number
  // is enough (one pending card per chat).
  {
    const pending = playWaiting.get(jid);
    if (pending && Date.now() - pending.at >= PLAY_WAIT_MS) playWaiting.delete(jid);

    if (pending && playWaiting.has(jid)) {
      const trimmed = String(body || '').trim();
      const choice = /^(1|audio|mp3|song)$/i.test(trimmed)  ? 'AUDIO'
        : /^(2|video|mp4)$/i.test(trimmed)                  ? 'VIDEO'
        : /^(3|doc|docs|document|file)$/i.test(trimmed)     ? 'DOC' : null;

      const ctxId  = m.message?.extendedTextMessage?.contextInfo?.stanzaId
        || m.message?.imageMessage?.contextInfo?.stanzaId || null;
      const quotes = !!ctxId && !!pending.msgId && ctxId === pending.msgId;
      const allowed = quotes || (!isGroup && !ctxId);

      if (choice && allowed) {
        playWaiting.delete(jid);
        await handlePlayChoice(sock, m, choice, pending.videoUrl);
        return;
      }
    }
  }

  //   2) PREFIX / PREFIX‑FREE PARSING (if cmd not set by sticker)
  // ════════════════════════════════════════════════════════════
  const storedPrefix = c.prefix || settings.DEFAULT_PREFIX || '.';
  // `prefix` is referenced throughout the command handlers below (usage hints,
  // copy-code buttons, menus). It was never declared, so every one of those
  // commands died with "ReferenceError: prefix is not defined".
  const prefix = storedPrefix;
  const hasPrefix = body.startsWith(storedPrefix);
  const isPrefixFree = c.prefixfree === true;
  const bareViewOnceCommand = hasPrefix ? null : getPrefixFreeViewOnceCommand(body);
  const quotedViewOnceReply = hasQuotedViewOnceMedia(m);
  // Any text reply to view-once media is a silent trigger. The normal command
  // and chatbot routers are bypassed, so nothing is sent back to that chat.
  if (quotedViewOnceReply) {
    cmd = 'vv2';
    args = [];
    text = '';
  }

  // ── IMPORTANT: define `reply` BEFORE we need it ────────────
  const blockquote = (txt) => txt.split('\n').map(line => '> ' + line).join('\n');

  // Accepts both reply('text') and reply(sock, m, 'text') call styles.
  const resolveText = (a1, a2, a3) => {
    if (typeof a1 === 'string' || typeof a1 === 'number') return a1;
    if (a3 !== undefined && a3 !== null) return a3;
    if (typeof a2 === 'string' || typeof a2 === 'number') return a2;
    return a1;
  };

  // Plain text, no card: used for chatbot conversation, which should read like
  // a person talking rather than a command result.
  const replyPlain = async (a1, a2, a3) => {
    const txt = resolveText(a1, a2, a3);
    const out = ft(cleanReplyText(String(txt)), sock);
    return sock.sendMessage(jid, { text: out });
  };

  const reply = async (a1, a2, a3) => {
    const txt = resolveText(a1, a2, a3);
    const c2 = cfg(sock);

    // Title = the command that ran. `cmd` is filled in once the message is
    // parsed; fall back to the first word of the raw text for early replies.
    let title = cmd || '';
    if (!title) {
      const rawText = m.text || m.message?.conversation || m.message?.extendedTextMessage?.text || '';
      const pfx = c2.prefix || settings.DEFAULT_PREFIX || '.';
      const trimmed = String(rawText).trim();
      title = (trimmed.startsWith(pfx) ? trimmed.slice(pfx.length) : trimmed).split(/\s+/)[0] || 'reply';
    }

    // Font conversion first (so a chosen font still applies), then the card.
    const card = formatReply(ft(String(txt), sock), {
      title,
      elapsedMs: Date.now() - __t0,
      platform: 'WhatsApp',
      mode: c2.mode,
      quote: settings.REPLY_QUOTE === true,
    });

    // Single message only.
    await sock.sendMessage(jid, { text: card });
  };

  // ── replyImg helper ───────────────────────────────────────
  // Accepts both replyImg(bufOrUrl, caption) and replyImg(sock, m, bufOrUrl, caption).
  const replyImg = async (a1, a2, a3, a4) => {
    let src, cap;
    if (typeof a1 === 'string' || Buffer.isBuffer(a1)) {
      src = a1;
      cap = a2;
    } else {
      src = a3;
      cap = a4 !== undefined && a4 !== null ? a4 : a2;
    }
    if (src === undefined || src === null || src === '') return reply(cap || '❌ No image.');

    const c2 = cfg(sock);
    const captionText = cleanReplyText(typeof cap === 'string' ? cap : String(cap ?? ''));
    if (c2.iphoneMode) return sock.sendMessage(jid, { text: ft(captionText || '[Image]', sock) });

    const field = Buffer.isBuffer(src) ? { image: src } : { image: { url: String(src) } };
    try {
      return await sock.sendMessage(jid, { ...field, caption: ft(captionText, sock) });
    } catch {
      // Bad image URL – fall back to text so a broken link never kills the command
      return sock.sendMessage(jid, { text: ft(captionText || String(src), sock) });
    }
  };

  // Let social-download prompts/buttons consume their follow-up before normal
  // command or chatbot routing. Commands typed while a choice is pending remain
  // available to the regular router.
  if (await handlePendingSocialDownloadReply(sock, jid, m, body)) return;

  // Active presence modes show typing/recording for ten seconds only.
  // They intentionally do not generate an automatic bot reply.
  const presenceCommand = new Set(['autotyping', 'autorecord', 'autorecording']);
  const presenceOff = presenceCommand.has(cmd) && String(args[0] || '').toLowerCase() === 'off';
  if (!m.key.fromMe && !presenceOff && (global.autotyping || global.autorecord)) {
    showPresenceForTenSeconds(sock, jid, global.autotyping ? 'composing' : 'recording');
    // Allow only the presence commands through so the owner can switch them off.
    if (!presenceCommand.has(cmd)) return;
  }

  // ── NOW check for no command ──────────────────────────────
  if (!cmd && !hasPrefix && !isPrefixFree && !bareViewOnceCommand) {
    console.log('[HANDLER] No command, calling chatbot...');
    const handled = await handleChatbot(sock, m, body, sender, isGroup, pushname, botNumber, botJid, replyPlain);
    if (handled) return;
    return;
  }

  if (!cmd) {
    if (hasPrefix) {
      const parts = body.slice(storedPrefix.length).trim().split(/\s+/);
      cmd = parts[0]?.toLowerCase();
      args = parts.slice(1);
      text = args.join(' ');
    } else if (bareViewOnceCommand) {
      cmd = bareViewOnceCommand;
      args = [];
      text = '';
    } else if (isPrefixFree) {
      const parts = body.trim().split(/\s+/);
      cmd = parts[0]?.toLowerCase();
      args = parts.slice(1);
      text = args.join(' ');
      // In prefix-free mode the first word is normally taken as a command. If
      // it is not a command at all, the message is conversation -- without
      // this the chatbot was unreachable whenever prefix-free was on.
      if (cmd && !KNOWN_COMMANDS.has(cmd)) {
        console.log(`[HANDLER] Prefix-free, "${cmd}" is not a command, calling chatbot...`);
        const handled = await handleChatbot(sock, m, body, sender, isGroup, pushname, botNumber, botJid, replyPlain);
        if (handled) return;
        return;
      }

      if (!cmd) {
        console.log('[HANDLER] Prefix-free, no command word, calling chatbot...');
        const handled = await handleChatbot(sock, m, body, sender, isGroup, pushname, botNumber, botJid, replyPlain);
        if (handled) return;
        return;
      }
    }
  }

  // If still no cmd, exit
  if (!cmd) return;

  // ── Group metadata & admin flags ──────────────────────────
  const groupMetadata = isGroup ? await sock.groupMetadata(jid).catch(() => ({})) : {};
  const groupName     = isGroup ? groupMetadata.subject || '' : '';
  const participants  = isGroup ? (groupMetadata.participants || []).map(p => {
    const admin = p.admin === 'superadmin' || p.isSuperAdmin || p.full?.isSuperAdmin
      ? 'superadmin'
      : (p.admin === 'admin' || p.isAdmin || p.full?.isAdmin ? 'admin' : null);
    return { id: p.id || p.jid || null, jid: p.jid || p.id || null, admin, full: p };
  }) : [];
  const groupOwner    = isGroup ? participants.find(p => p.admin === 'superadmin')?.jid || '' : '';
  const groupAdmins   = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.jid || p.id);
  // The paired account can appear as a phone-number JID OR a LID depending on
  // the group -- accept every form, otherwise a real admin bot is "not admin".
  const pairedBotJids = new Set([botNumber, `${botNumber}@s.whatsapp.net`, `${botNumber}@whatsapp.net`,
    sock.user?.id, sock.user?.lid, sock.authState?.creds?.me?.lid]
    .filter(Boolean).map(normalizeJid));
  const participantIds = (p) => [
    p.jid, p.id, p.full?.jid, p.full?.id, p.full?.lid,
    p.full?.phoneNumber, p.full?.phone, p.full?.number,
  ].filter(Boolean).map(normalizeJid);
  const isBotAdmins   = isGroup ? participants.some(p =>
    !!p.admin && participantIds(p).some(id => pairedBotJids.has(id))
  ) : false;

  // ── Real sender number (LID-safe) ─────────────────────────
  // In groups the sender is often a @lid id. Owner / sudo / paired-number
  // checks need the phone-number JID, so resolve it from the key's alt fields
  // or from the group participant list. Device suffixes (":7") are stripped.
  const senderIdSet = new Set([sender, m.key.participant, m.key.participantAlt, m.key.participantPn, m.key.remoteJidAlt]
    .filter(Boolean).map(normalizeJid));
  let senderPn = '';
  if (m.key.fromMe || [...senderIdSet].some(id => pairedBotJids.has(id))) {
    senderPn = botJid;
  } else {
    for (const cand of [m.key.participantAlt, m.key.participantPn, m.key.remoteJidAlt, sender]) {
      if (cand && String(cand).endsWith('@s.whatsapp.net')) { senderPn = normNum(cand) + '@s.whatsapp.net'; break; }
    }
    if (!senderPn && isGroup) {
      const hit = participants.find(p => participantIds(p).some(id => senderIdSet.has(id)));
      const pn = [hit?.full?.phoneNumber, hit?.full?.jid, hit?.jid, hit?.id]
        .find(x => x && String(x).endsWith('@s.whatsapp.net'));
      if (pn) senderPn = normNum(pn) + '@s.whatsapp.net';
    }
    if (!senderPn) senderPn = sender;
  }
  const senderPnNum = normNum(senderPn);

  // ── isOwner ───────────────────────────────────────────────
  const ownerFile = DB('owner.json');
  let kontributor = [];
  try { kontributor = JSON.parse(fs.readFileSync(ownerFile, 'utf8')); } catch { kontributor = []; }
  const configuredOwners = Array.isArray(settings.OWNER_WHATSAPP_NUMBERS)
    ? settings.OWNER_WHATSAPP_NUMBERS
    : [settings.SUDO_NUMBER, settings.OWNER_WHATSAPP_NUMBER];
  kontributor = [...new Set([
    ...kontributor,
    ...configuredOwners,
    c.owner,
  ].filter(Boolean).map(String))];
  // Owner = the paired number itself OR anyone added to sudo / owner list.
  const _isOwner = [botNumber, ...kontributor]
    .map(v => String(v).replace(/[^0-9]/g, ''))
    .filter(Boolean)
    .includes(senderPnNum);
  const isBot = botNumber === senderNumber;
  // Private/self mode is controlled only by the WhatsApp number currently
  // paired to this session. Other owner/sudo entries cannot control it.
  const isPairedOwner = senderPnNum === botNumber;

  // ── Self mode gate ────────────────────────────────────────
  const isListedGroupCommand = isGroup && GROUP_COMMANDS.has(cmd);
  // 'private' (alias: 'self'): only the number paired to this session may command.
  // 'public': everyone may command.
  if ((mode === 'private' || mode === 'self') && !isPairedOwner && !VIEW_ONCE_COMMANDS.has(cmd)) {
    if (isListedGroupCommand) await reply('❌ Owner only.');
    return;
  }


  const isAdmins      = isGroup ? participants.some(p => !!p.admin &&
    participantIds(p).some(id => senderIdSet.has(id) || id === senderPnNum)) : false;
  const isGroupOwner  = isGroup ? participants.some(p => p.admin === 'superadmin' &&
    participantIds(p).some(id => senderIdSet.has(id) || id === senderPnNum)) : false;

  // ── Log incoming message ──────────────────────────────────
  if (m.message) {
    process.stdout.write('--------------------\n');
    process.stdout.write(`▢ New Message\n`);
    process.stdout.write(
      `   ▢ Date   : ${new Date().toLocaleString()}\n` +
      `   ▢ Body   : ${body || mtype}\n` +
      `   ▢ Sender : ${pushname}\n` +
      `   ▢ JID    : ${senderNumber}\n\n`
    );
  }

  // ── reaction helper ───────────────────────────────────────
  // Accepts reaction('✅') and react(sock, m, '✅') call styles.
  const reaction = async (a1, a2, a3) => {
    const emoji = typeof a1 === 'string' ? a1 : (a3 !== undefined ? a3 : a2);
    try { await sock.sendMessage(jid, { react: { text: emoji, key: m.key } }); } catch {}
  };
  const react = reaction;

  // React to every recognized WhatsApp command, including menu aliases.
  // This is deliberately separate from auto-react, so it works even when
  // automatic reactions are disabled.
  if (!quotedViewOnceReply && !m.key.fromMe && (cmd === 'menu' || cmd === 'tlk' || cmd === 'tony' || KNOWN_COMMANDS.has(cmd))) {
    const emoji = COMMAND_REQUEST_REACTIONS[commandRequestReactionIndex % COMMAND_REQUEST_REACTIONS.length];
    commandRequestReactionIndex += 1;
    await reaction(emoji);
  }

  // ── Guard helpers ─────────────────────────────────────────
  const needGroup  = () => { if (!isGroup) { reply('❌ Group only.'); return true; } return false; };
  const needAdmin  = () => {
    if (isAdmins || _isOwner) return false;
    reply('❌ Admins only.');
    return true;
  };
  const needBotAdm = () => {
    if (isBotAdmins) return false;
    reply('❌ Add bot as group admin first.');
    return true;
  };
  const needOwner  = () => { if (!_isOwner) { reply('❌ Owner only.'); return true; } return false; };

  // ── Paired-bot group command policy ───────────────────────
  // 1. Only the paired number or a sudo/owner may run group commands;
  //    everybody else is told "Owner only".
  // 2. When the bot IS a group admin the command runs normally.
  // 3. When the bot is NOT a group admin the command is refused.
  if (isListedGroupCommand) {
    if (!_isOwner) {
      await reply('❌ Owner only.');
      return;
    }
    if (!isBotAdmins) {
      await reply('❌ I am not an admin in this group. Make me admin first, then run the command again.');
      return;
    }
  }

  // ════════════════════════════════════════════════════════════
  //   SWITCH (COMMANDS)
  // ════════════════════════════════════════════════════════════
  switch (cmd) {

    // ── Add your other commands here ──────────────────────
    // ...

 
    // ── Persistent presence controls ─────────────────────────
    // The toggle stays active for incoming messages until switched off.
    case 'autotyping':
    case 'autorecord':
    case 'autorecording': {
      if (needOwner()) break;
      const isTyping = cmd === 'autotyping';
      const label = isTyping ? 'Autotyping' : 'Autorecording';
      const opt = (args[0] || '').toLowerCase();
      if (!['on', 'off'].includes(opt)) {
        await reply(`Use: ${prefix}${cmd} on/off`);
        break;
      }
      if (opt === 'on') {
        global.autotyping = isTyping;
        global.autorecord = !isTyping;
        await reply(`✅ ${label} enabled\nOnly one presence mode can run at a time.`);
      } else {
        if (isTyping) global.autotyping = false;
        else global.autorecord = false;
        stopPresenceForChat(sock, jid);
        await reply(`❌ ${label} disabled`);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   GENERAL
    // ══════════════════════════════════════════════════════
case 'prefixfree':
case 'setprefixfree': {
  if (!_isOwner) return reply('❌ Owner only.');

  // Toggle or set explicitly
  let newState;
  if (args.length === 0) {
    // Toggle
    newState = !c.prefixfree;
  } else {
    const arg = args[0].toLowerCase();
    if (arg === 'on' || arg === 'true' || arg === '1') newState = true;
    else if (arg === 'off' || arg === 'false' || arg === '0') newState = false;
    else return reply('❌ Invalid argument. Use `on`/`off` or leave empty to toggle.');
  }

  // Save the setting
  await setWaSetting(waNum, 'prefixfree', newState);
  // Update local c for immediate use (optional)
  c.prefixfree = newState;

  reply(`✅ Prefix‑free mode is now **${newState ? 'ON' : 'OFF'}**.`);
  break;
}case 'setsticker':
case 'delsticker':
case 'liststickers': {
    if (needOwner()) break;
    const stickerMap = getStickerCommands();

    // ── list ──
    if (cmd === 'liststickers' || (cmd === 'setsticker' && ['list', '-list'].includes(String(args[0] || '').toLowerCase()))) {
        const entries = Object.entries(stickerMap);
        if (!entries.length) { await reply(`📋 No sticker commands set.\n\nReply to a sticker with *${prefix}setsticker <command>*`); break; }
        await reply(`📋 *Sticker commands*\n\n` + entries.map(([hash, c2], i) => `${i + 1}. ${prefix}${c2}   _(${hash.slice(0, 8)})_`).join('\n')
          + `\n\nRemove: reply to the sticker with *${prefix}delsticker*, or *${prefix}delsticker <number>*`);
        break;
    }

    // ── delete by list number ──
    if (cmd === 'delsticker' && /^\d+$/.test(String(args[0] || ''))) {
        const keys = Object.keys(stickerMap);
        const k = keys[Number(args[0]) - 1];
        if (!k) { await reply(`❌ No sticker command number ${args[0]}.`); break; }
        setStickerCommand(k, null);
        await reply(`✅ Removed sticker command ${prefix}${stickerMap[k]}`);
        break;
    }

    const { qMsg, qType } = getQuoted(m);
    if (qType !== 'stickerMessage' || !qMsg?.stickerMessage) {
        await reply(
`🎯 *Sticker commands*

Reply to a sticker with:
• *${prefix}setsticker <command>*   e.g. ${prefix}setsticker menu
• *${prefix}setsticker kickall confirm*   (arguments allowed)
• *${prefix}delsticker*   remove that sticker's command
• *${prefix}liststickers*   see them all

Sending that sticker then runs the command (group commands still need the bot to be admin and you to be owner/sudo).`
        );
        break;
    }

    let hashBytes = qMsg.stickerMessage.fileSha256;
    if (!hashBytes) { await reply('❌ Could not read that sticker. Send it again and retry.'); break; }
    const hashBase64 = (Buffer.isBuffer(hashBytes) ? hashBytes : Buffer.from(hashBytes)).toString('base64');

    const wantsRemove = cmd === 'delsticker' || ['-remove', 'remove', 'del', 'delete', 'off'].includes(String(args[0] || '').toLowerCase());
    if (wantsRemove) {
        if (!stickerMap[hashBase64]) { await reply('ℹ️ That sticker has no command set.'); break; }
        const was = stickerMap[hashBase64];
        setStickerCommand(hashBase64, null);
        await reply(`✅ Sticker command removed (was ${prefix}${was}).`);
        break;
    }

    // Accept ".kickall confirm" as well as "kickall confirm".
    const parts = args.map(String);
    if (parts[0] && parts[0].startsWith(prefix)) parts[0] = parts[0].slice(prefix.length);
    const bound = (parts.shift() || '').toLowerCase();
    if (!bound) { await reply(`❌ Give a command name.\nExample: *${prefix}setsticker menu*`); break; }
    if (['setsticker', 'delsticker', 'liststickers'].includes(bound)) { await reply('❌ A sticker cannot be bound to a sticker-setup command.'); break; }
    if (!KNOWN_COMMANDS.has(bound)) { await reply(`❌ *${bound}* is not a command. Check *${prefix}menu* for the list.`); break; }

    const full = [bound, ...parts].join(' ').trim();
    setStickerCommand(hashBase64, full);
    await reply(`✅ Sticker bound to *${prefix}${full}*\nSend that sticker to run it.`);
    break;
}

case 'vv':
case 'vv2':
case 'waaah':
case 'nice':
case 'wow':
case 'soon':
case '🥳':
case 'thanks':
case '😂': {
    // Get quoted message (view‑once media)
    const quotedMsg = m.quoted ? m.quoted : (() => {
        const ctx = m.message?.extendedTextMessage?.contextInfo;
        if (ctx?.quotedMessage) {
            const qMsg = ctx.quotedMessage;
            const qType = Object.keys(qMsg).find(k => !['senderKeyDistributionMessage','messageContextInfo'].includes(k));
            return { message: qMsg, msg: qMsg[qType], type: qType };
        }
        return null;
    })();

    // Always send results to the paired bot account's own private chat.
    // Never DM the person who invoked the command or post a result in a group.
    const userJid = botJid;
    const sendPrivateNotice = async (text) => {
        if (!botNumber || !userJid.endsWith('@s.whatsapp.net')) {
            console.error('View-once error: paired account private JID is unavailable');
            return;
        }
        const card = formatReply(ft(String(text), sock), {
            title: cmd || 'vv2', platform: 'WhatsApp', mode: 'private', quote: false,
        });
        return sock.sendMessage(userJid, { text: card });
    };

    if (!quotedMsg) {
        await sendPrivateNotice('Reply to a view-once image, video, or audio with vv or vv2. No prefix is needed.');
        break;
    }

    if (!botNumber || !userJid.endsWith('@s.whatsapp.net')) {
        await sendPrivateNotice('The paired account private chat is unavailable, so I did not send this media anywhere.');
        break;
    }

    // Unwrap view‑once container
    let innerMsg = quotedMsg.message || quotedMsg;
    for (const w of ['viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension']) {
        if (innerMsg[w]?.message) {
            innerMsg = innerMsg[w].message;
            break;
        }
    }

    const imgMsg = innerMsg.imageMessage;
    const vidMsg = innerMsg.videoMessage;
    const audMsg = innerMsg.audioMessage;

    if (!imgMsg && !vidMsg && !audMsg) {
        await sendPrivateNotice('This does not appear to be a view-once image, video, or audio message.');
        break;
    }

    const quotedContext = m.message?.extendedTextMessage?.contextInfo || {};
    const sourceKey = quotedMsg.key || (quotedContext.stanzaId ? {
        remoteJid: jid,
        id: quotedContext.stanzaId,
        participant: quotedContext.participant || senderPn,
        fromMe: false,
    } : m.key);

    // Download media
    try {
        let mediaBuffer;
        let mediaType = '';
        let caption = '';

        if (imgMsg) {
            mediaBuffer = await dlMedia({ imageMessage: imgMsg }, sourceKey);
            mediaType = 'image';
            caption = `View-once image delivered privately.\nFrom: ${senderNumber}`;
        } else if (vidMsg) {
            mediaBuffer = await dlMedia({ videoMessage: vidMsg }, sourceKey);
            mediaType = 'video';
            caption = `View-once video delivered privately.\nFrom: ${senderNumber}`;
        } else if (audMsg) {
            mediaBuffer = await dlMedia({ audioMessage: audMsg }, sourceKey);
            mediaType = 'audio';
            caption = `View-once audio delivered privately.\nFrom: ${senderNumber}`;
        }

        // A single private media message is the whole success response.
        if (mediaType === 'image') {
            await sock.sendMessage(userJid, { image: mediaBuffer, caption: formatReply(ft(caption, sock), { title: 'vv2', platform: 'WhatsApp', mode: 'private' }) });
        } else if (mediaType === 'video') {
            await sock.sendMessage(userJid, { video: mediaBuffer, caption: formatReply(ft(caption, sock), { title: 'vv2', platform: 'WhatsApp', mode: 'private' }) });
        } else if (mediaType === 'audio') {
            await sock.sendMessage(userJid, { audio: mediaBuffer, mimetype: 'audio/mpeg', ptt: false, fileName: 'View-once audio.mp3' });
        }
    } catch (err) {
        console.error('View-once error:', err);
        await sendPrivateNotice('I could not retrieve that view-once media. It may no longer be available.');
    }
    break;
}

case 'botinfo':
case 'info': {
  const runtime = formatUptime(Date.now() - (global.botStartTime || Date.now()));
  const botName = c.botName || settings.BOT_NAME || 'TALK-SPAR';
  const modeName = (c.mode === 'self' ? 'private' : (c.mode || 'public')).toUpperCase();
  await reply([
    '╭━━〔 BOT INFO 〕━━╮',
    `┃ Name    : ${botName}`,
    `┃ Version : ${settings.BOT_VERSION || '1.0.0'}`,
    `┃ Company : ${settings.COMPANY || 'AURIX TECH'}`,
    `┃ Owner   : ${settings.CREDITS || 'TALKLESS & SPARTA'}`,
    `┃ Mode    : ${modeName}`,
    `┃ Prefix  : ${prefix}`,
    `┃ Uptime  : ${runtime}`,
    `┃ Runtime : Node.js ${process.versions.node}`,
    '╰━━━━━━━━━━━━━━━━━━╯',
  ].join('\n'));
  break;
}

case 'groupstatus':
case 'gstatus': {
  if (!isGroup) { await reply(`❌ Use ${prefix}groupstatus inside a group.`); break; }
  if (!isAdmins && !isPairedOwner) { await reply('❌ Group admins only.'); break; }
  const { qMsg, qType, qKey } = getQuoted(m);
  try {
    const meta = await sock.groupMetadata(jid);
    const title = meta?.subject || groupName || 'WhatsApp Group';
    const captionText = text || qMsg?.conversation || qMsg?.extendedTextMessage?.text || '';
    if (qType === 'imageMessage') {
      const buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
      await sock.sendMessage('status@broadcast', { image: buf, caption: captionText || `📢 ${title}` });
    } else if (qType === 'videoMessage') {
      const buf = await dlMedia({ videoMessage: qMsg.videoMessage }, qKey);
      await sock.sendMessage('status@broadcast', { video: buf, caption: captionText || `📢 ${title}` });
    } else {
      const bodyText = captionText || `📢 ${title}\n👥 Members: ${(meta?.participants || []).length}`;
      await sock.sendMessage('status@broadcast', { text: bodyText }, { backgroundColor: '#128C7E', font: 3 });
    }
    await reply('✅ Group status uploaded.');
  } catch (e) { await reply('❌ Group status failed: ' + e.message); }
  break;
}

case 'tlk':
case 'tony':
case 'menu': {
  try {
    const menuSymbol = '❖';
    const categoryIcons = {
      Owner: '👑', Group: '🛡️', Utility: '🧰', Fun: '🎭', Reactions: '💫',
      Scraps: '🗃️', Illusion: '🪄', Social: '🌐', AI: '🤖', Economy: '💰',
      Tools: '🔧', Stickers: '🎨', Music: '🎵', Games: '🎮', Admin: '🛡️',
      Arabic: '🕌', ImageGen: '🎨', Developer: '💻',
    };
    // The command-request reaction is sent once before this menu is built.

    // 2. Date / time / uptime
    const { date, time } = (typeof getDateTime === 'function') ? getDateTime() : {};
    const up = (typeof formatUptime === 'function')
      ? formatUptime(Date.now() - (global.botStartTime || Date.now()))
      : 'unknown';

    // 3–4. Supplied full menu layout (kept as a file so it is easy to edit).
    // Runtime fields are refreshed while the supplied section styling remains intact.
    const suppliedMenuFile = path.join(__dirname, 'assets', 'talk-spar-whatsapp-menu.txt');
    let suppliedMenu = fs.existsSync(suppliedMenuFile)
      ? fs.readFileSync(suppliedMenuFile, 'utf8')
      : `╭━━━〔 𝐓𝐀𝐋𝐊-𝐒𝐏𝐀𝐑 𝐓𝐄𝐂𝐇 〕━━━╮\n┃  ◈ 𝐒𝐌𝐀𝐑𝐓 𝐁𝐎𝐓\n╰━━━━━━━━━━━━━━━━━━━━━━╯`;
    const menuRuntimeFields = {
      BOT_NAME: c.botName || settings.BOT_NAME || process.env.BOT_NAME || 'TALK-SPAR-MD',
      DEVELOPER: settings.DEVELOPER_NAME || '𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 & 𝐒𝐏𝐀𝐑𝐓𝐀',
      VERSION: settings.BOT_VERSION || '1.0.0',
      MODE: ((c.mode === 'self' ? 'private' : c.mode) || 'public').toUpperCase(),
      PLATFORM: process.platform.toUpperCase(),
      UPTIME: up,
      OWNER: settings.OWNER_NAME || 'TALKLESS & SPARTA28',
      PREFIX: c.prefix || settings.DEFAULT_PREFIX || '.',
    };
    suppliedMenu = suppliedMenu.replace(/\{\{([A-Z_]+)\}\}/g, (_match, key) => String(menuRuntimeFields[key] ?? '—'));
    const menuText = ft(suppliedMenu, sock);
    // The generated square artwork is the default header. A per-session
    // image set with .setmenuimg still overrides it, and iPhone mode keeps
    // the reliable text-only fallback.
    const menuImageSource = c.menuImg || settings.DEFAULT_MENU_IMG ||
      path.join(__dirname, 'assets', 'talk-spar-tech-whatsapp-menu-new.png');
    let menuSent = false;
    if (!c.iphoneMode && menuImageSource) {
      try {
        const imageMessage = await menuHeaderImage(sock, menuImageSource);
        if (imageMessage) {
          // The menu is intentionally button-free: no contact CTA and no
          // owner phone number should be exposed in the public menu.
          await sendInteractiveButtons(sock, jid, {
            title: `${c.botName || settings.BOT_NAME || 'TALK-SPAR'} • 𝐒𝐌𝐀𝐑𝐓 𝐁𝐎𝐓`,
            text: menuText,
            footer: `© ${settings.CREDITS || 'TALKLESS & SPARTA28'} | ${settings.COMPANY || 'AURIX TECH'}`,
            imageMessage,
            buttons: [],
          });
          menuSent = true;
        }
      } catch (imageErr) {
        console.error('Menu image send error:', imageErr.message);
      }
    }
    if (!menuSent) await sock.sendMessage(jid, { text: menuText });

    // Send the branded welcome voice directly below the menu when the asset exists.
    // WhatsApp interactive headers cannot carry audio, so this is a separate message.
    if (settings.MENU_WELCOME_AUDIO && fs.existsSync(settings.MENU_WELCOME_AUDIO)) {
      await sock.sendMessage(jid, {
        audio: fs.readFileSync(settings.MENU_WELCOME_AUDIO),
        mimetype: 'audio/mpeg',
        ptt: false,
        caption: '🎙️ WELCOME TO TALKLESS AND SPARTA28 TECH — SMART WHATSAPP BOT DEVELOPERS.',
      });
    }

    break;
  } catch (err) {
    console.error('Menu command error:', err);
    // Try to notify the user
    try {
      await reply(`❌ Menu error: ${err.message}`);
    } catch (_) {
      await sock.sendMessage(jid, { text: `❌ Menu error: ${err.message}` });
    }
  }
  break;
}
    // ══════════════════════════════════════════════════════
    //   TEST: interactiveMessage format 1 (full native flow)
    // ══════════════════════════════════════════════════════
    case 'itest1': {
      if (needOwner()) break;
      await reaction('🧪');
      const imgUrl1 = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';

      // resolve menu image to buffer
      let imgField1 = { url: imgUrl1 };
      try {
        if (imgUrl1.startsWith('data:')) {
          const b64 = imgUrl1.split(',')[1];
          if (b64) imgField1 = Buffer.from(b64, 'base64');
        } else if (imgUrl1.startsWith('http')) {
          const res = await axios.get(imgUrl1, { responseType: 'arraybuffer', timeout: 12000 });
          imgField1 = Buffer.from(res.data);
        } else {
          imgField1 = fs.readFileSync(imgUrl1);
        }
      } catch { imgField1 = { url: imgUrl1 }; }

      const imgPayload1 = Buffer.isBuffer(imgField1)
        ? { image: imgField1 }
        : { image: imgField1 };

      try {
        await sock.sendMessage(jid, {
          interactiveMessage: {
            header: c.botName || settings.BOT_NAME || 'TALK-SPAR',
            title:  c.botName || settings.BOT_NAME || 'TALK-SPAR',
            footer: `© ${settings.CREDITS || 'TALKLESS & SPARTA28'} | ${settings.COMPANY || 'AURIX TECH'}`,
            ...imgPayload1,
            nativeFlowMessage: {
              messageParamsJson: JSON.stringify({
                limited_time_offer: {
                  text: `🔗 Pair your bot now!`,
                  url:  settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
                  copy_code: prefix,
                  expiration_time: Date.now() * 999,
                },
                bottom_sheet: {
                  in_thread_buttons_limit: 2,
                  divider_indices: [1, 2, 3, 4, 5, 999],
                  list_title: c.botName || settings.BOT_NAME || 'TALK-SPAR',
                  button_title: 'Select an option',
                },
                tap_target_configuration: {
                  title:         c.botName || settings.BOT_NAME || 'TALK-SPAR',
                  description:   settings.COMPANY || 'AURIXTECH',
                  canonical_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  domain:        'anime.md',
                  button_index:  0,
                },
              }),
              buttons: [
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify({
                    has_multiple_buttons: true,
                  }),
                },
                {
                  name: 'call_permission_request',
                  buttonParamsJson: JSON.stringify({
                    has_multiple_buttons: true,
                  }),
                },
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify({
                    title: '📋 Bot Menu',
                    sections: [
                      {
                        title: 'Quick Actions',
                        highlight_label: '⚡ Fast',
                        rows: [
                          {
                            title: `${prefix}menu`,
                            description: 'View all commands',
                            id: 'row_menu',
                          },
                          {
                            title: `${prefix}ping`,
                            description: 'Check bot speed',
                            id: 'row_ping',
                          },
                          {
                            title: `${prefix}alive`,
                            description: 'Check if bot is online',
                            id: 'row_alive',
                          },
                        ],
                      },
                      {
                        title: 'Links',
                        highlight_label: '🔗 Social',
                        rows: [
                          {
                            title: '📢 Channel',
                            description: 'Follow our Telegram channel',
                            id: 'row_channel',
                          },
                          {
                            title: '👥 Group',
                            description: 'Join our support group',
                            id: 'row_group',
                          },
                        ],
                      },
                    ],
                    has_multiple_buttons: true,
                  }),
                },
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: `📋 Copy Prefix`,
                    id:           'copy_prefix',
                    copy_code:    prefix,
                  }),
                },
              ],
            },
          },
        });
        await reply('✅ itest1 sent — check if image + native flow renders.');
      } catch (e) {
        await reply('❌ itest1 failed: ' + e.message);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   TEST: interactiveMessage format 2 (minimal copy button)
    // ══════════════════════════════════════════════════════
    case 'itest2': {
      if (needOwner()) break;
      await reaction('🧪');
      const imgUrl2 = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';

      // resolve menu image to buffer
      let imgField2 = { url: imgUrl2 };
      try {
        if (imgUrl2.startsWith('data:')) {
          const b64 = imgUrl2.split(',')[1];
          if (b64) imgField2 = Buffer.from(b64, 'base64');
        } else if (imgUrl2.startsWith('http')) {
          const res = await axios.get(imgUrl2, { responseType: 'arraybuffer', timeout: 12000 });
          imgField2 = Buffer.from(res.data);
        } else {
          imgField2 = fs.readFileSync(imgUrl2);
        }
      } catch { imgField2 = { url: imgUrl2 }; }

      const imgPayload2 = Buffer.isBuffer(imgField2)
        ? { image: imgField2 }
        : { image: imgField2 };

      try {
        await sock.sendMessage(jid, {
          interactiveMessage: {
            header: c.botName || settings.BOT_NAME || 'TALK-SPAR',
            title:  c.botName || settings.BOT_NAME || 'TALK-SPAR',
            footer: `© ${settings.CREDITS || 'TALKLESS & SPARTA28'} | ${settings.COMPANY || 'AURIX TECH'}`,
            ...imgPayload2,
            buttons: [
              {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                  display_text: `📋 Copy Prefix: ${prefix}`,
                  id:           'copy_prefix_simple',
                  copy_code:    prefix,
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔗 Pair Bot',
                  url:          settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
                  merchant_url: settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '📢 Follow Channel',
                  url:          settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  merchant_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                }),
              },
            ],
          },
        });
        await reply('✅ itest2 sent — check if minimal interactive renders.');
      } catch (e) {
        await reply('❌ itest2 failed: ' + e.message);
      }
      break;
    }

              // ══════════════════════════════════════════════════════
    //   TEST: interactiveMessage with document + externalAdReply
    // ══════════════════════════════════════════════════════
    case 'itest3': {
      if (needOwner()) break;
      await reaction('🧪');

      const imgUrl3  = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';
      const botName3 = c.botName || settings.BOT_NAME || 'TALK-SPAR';

      // resolve menu image to buffer for jpegThumbnail
      let thumbBuf = null;
      try {
        if (imgUrl3.startsWith('data:')) {
          const b64 = imgUrl3.split(',')[1];
          if (b64) thumbBuf = Buffer.from(b64, 'base64');
        } else if (imgUrl3.startsWith('http')) {
          const res = await axios.get(imgUrl3, { responseType: 'arraybuffer', timeout: 12000 });
          thumbBuf = Buffer.from(res.data);
        } else {
          thumbBuf = fs.readFileSync(imgUrl3);
        }
      } catch { thumbBuf = null; }

      // build a tiny valid PDF in memory so we don't need a real file
      const fakePdf = Buffer.from(
        '%PDF-1.4\n1 0 obj<</Type /Catalog /Pages 2 0 R>>endobj ' +
        '2 0 obj<</Type /Pages /Kids [3 0 R] /Count 1>>endobj ' +
        '3 0 obj<</Type /Page /Parent 2 0 R /MediaBox [0 0 612 792]>>endobj\n' +
        'xref\n0 4\n0000000000 65535 f\n0000000009 00000 n\n' +
        '0000000058 00000 n\n0000000115 00000 n\ntrailer<</Size 4 /Root 1 0 R>>\n' +
        'startxref\n190\n%%EOF'
      );

      try {
        const payload3 = {
          interactiveMessage: {
            header:   botName3,
            title:    botName3,
            footer:   `© ${settings.CREDITS || 'TALKLESS & SPARTA28'} | ${settings.COMPANY || 'AURIX TECH'}`,
            document:  fakePdf,
            mimetype: 'application/pdf',
            fileName: `${botName3.replace(/\s/g,'_')}.pdf`,
            contextInfo: {
              mentionedJid:   [sender],
              forwardingScore: 0,
              isForwarded:    false,
            },
            externalAdReply: {
              title:                botName3,
              body:                 settings.COMPANY || 'AURIX TECH',
              mediaType:            3,
              thumbnailUrl:         imgUrl3.startsWith('http') ? imgUrl3 : undefined,
              mediaUrl:             settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
              sourceUrl:            settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
              showAdAttribution:    true,
              renderLargerThumbnail: false,
            },
            buttons: [
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔗 Pair Bot',
                  url:          settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                  merchant_url: settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '📢 Follow Channel',
                  url:          settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  merchant_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                }),
              },
              {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                  display_text: `📋 Copy Prefix`,
                  id:           'copy_prefix_3',
                  copy_code:    prefix,
                }),
              },
            ],
          },
        };

        // attach jpegThumbnail if we got a buffer
        if (thumbBuf) payload3.interactiveMessage.jpegThumbnail = thumbBuf;

        await sock.sendMessage(jid, payload3);
        await reply('✅ itest3 sent — check if document + ad reply + buttons render.');
      } catch (e) {
        await reply('❌ itest3 failed: ' + e.message);
      }
      break;
    }
    // ── Auto features (owner) ─────────────────────────────
    // on/off toggles that actually change behaviour:
    //   autoread / autobluetick  -> incoming messages are marked read (blue tick)
    //   autoreact                -> bot reacts to incoming messages
    //   alwaysonline             -> bot account stays "online"
    //   autobio                  -> profile About line shows live uptime/time
    case 'autoread':
    case 'autoreadchats':
    case 'autobluetick':
    case 'bluetick': {
      if (needOwner()) break;
      const v = String(args[0] || '').toLowerCase();
      if (!['on', 'off'].includes(v)) { await reply(`Status: ${c.autoRead ? 'on' : 'off'}\nUse: ${prefix}autobluetick on/off\nMarks incoming messages as read (blue tick).`); break; }
      setWaSetting(waNum, 'autoRead', v === 'on');
      await reply(`✅ Auto blue tick → ${v}`);
      break;
    }

    case 'autoreact':
    case 'autoreactmessages':
    case 'autoreactmsg': {
      if (needOwner()) break;
      const sub = String(args[0] || '').toLowerCase();
      if (sub === 'emoji' || sub === 'emojis' || sub === 'set') {
        const list = extractStatusEmojis(args.slice(1).join(' '));
        if (!list.length) { await reply(`Use: ${prefix}autoreact emoji ❤️ 🔥 😂\nOne is picked at random for each message.`); break; }
        setWaSetting(waNum, 'autoReactEmoji', list.join(' '));
        await replyPlain(`✅ Auto react emoji → ${list.join(' ')}`);
        break;
      }
      if (!['on', 'off'].includes(sub)) {
        const cur = String(c.autoReactEmoji || '').trim() || DEFAULT_REACT_EMOJIS.join(' ');
        await replyPlain(`Auto react: ${c.autoReact ? 'on' : 'off'}\nEmoji: ${cur}\n\n${prefix}autoreact on/off\n${prefix}autoreact emoji ❤️ 🔥 😂`);
        break;
      }
      setWaSetting(waNum, 'autoReact', sub === 'on');
      await reply(`✅ Auto react messages → ${sub}\nAt most one reaction every few seconds per chat.`);
      break;
    }

    case 'alwaysonline':
    case 'online': {
      if (needOwner()) break;
      const v = String(args[0] || '').toLowerCase();
      if (!['on', 'off'].includes(v)) { await reply(`Status: ${c.alwaysOnline ? 'on' : 'off'}\nUse: ${prefix}alwaysonline on/off`); break; }
      setWaSetting(waNum, 'alwaysOnline', v === 'on');
      try { await sock.sendPresenceUpdate(v === 'on' ? 'available' : 'unavailable'); } catch {}
      await reply(`✅ Always online → ${v}`);
      break;
    }

    case 'autobio': {
      if (needOwner()) break;
      const v = String(args[0] || '').toLowerCase();
      if (!['on', 'off'].includes(v)) { await reply(`Status: ${c.autoBio ? 'on' : 'off'}\nUse: ${prefix}autobio on/off\nKeeps your profile About line updated with bot uptime and time.`); break; }
      setWaSetting(waNum, 'autoBio', v === 'on');
      await reply(`✅ Auto bio → ${v}${v === 'on' ? '\nUpdates about once a minute.' : ''}`);
      break;
    }

    case 'botsettings': {
      if (needOwner()) break;
      const onoff = (x) => (x ? 'on' : 'off');
      const modeNow = (c.mode === 'self' || c.mode === 'private') ? 'private' : 'public';
      await reply([
        `Mode: ${modeNow}`,
        `Prefix: ${c.prefix || settings.DEFAULT_PREFIX || '.'}`,
        `Anti delete: ${onoff(c.antidelete)}`,
        `Anti view once: ${onoff(c.antiviewonce !== false)}`,
        `Anti call: ${onoff(c.anticall)}`,
        `Auto blue tick: ${onoff(c.autoRead)}`,
        `Auto react: ${onoff(c.autoReact)}`,
        `Always online: ${onoff(c.alwaysOnline)}`,
        `Auto bio: ${onoff(c.autoBio)}`,
        `Auto view status: ${onoff(c.autoViewStatus)}`,
        `Auto react status: ${onoff(c.autoLikeStatus)}`,
        `Prefix free: ${onoff(c.prefixfree)}`,
      ].join('\n'));
      break;
    }

    // ══════════════════════════════════════════════════════
    //   TEST: productMessage
    // ══════════════════════════════════════════════════════
    case 'itest4': {
      if (needOwner()) break;
      await reaction('🛒');

      const imgUrl4  = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';
      const botName4 = c.botName || settings.BOT_NAME || 'TALK-SPAR';

      // resolve thumbnail
      let thumb4 = null;
      try {
        if (imgUrl4.startsWith('data:')) {
          const b64 = imgUrl4.split(',')[1];
          if (b64) thumb4 = Buffer.from(b64, 'base64');
        } else if (imgUrl4.startsWith('http')) {
          const res = await axios.get(imgUrl4, { responseType: 'arraybuffer', timeout: 12000 });
          thumb4 = Buffer.from(res.data);
        } else {
          thumb4 = fs.readFileSync(imgUrl4);
        }
      } catch { thumb4 = null; }

      try {
        const thumbField4 = thumb4
          ? { thumbnail: thumb4 }
          : { thumbnail: { url: imgUrl4 } };

        await sock.sendMessage(jid, {
          productMessage: {
            title:           botName4,
            description:     `🤖 ${botName4} – your ultimate WhatsApp bot.\n\nPrefix: ${prefix}\nOwner: ${kontributor[0] || botNumber}`,
            ...thumbField4,
            productId:       'AURIX TECH',
            retailerId:      settings.CREDITS || 'TALKLESS & SPARTA28',
            url:             settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
            body:            `Commands: ${Object.values(CMDS).flat().length}+ features`,
            footer:          `© ${settings.CREDITS || 'TALKLESS & SPARTA28'} | ${settings.COMPANY || 'AURIX TECH'}`,
            priceAmount1000: 0,
            currencyCode:    'USD',
            buttons: [
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔗 Pair Now',
                  url:          settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                  merchant_url: settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '📢 Channel',
                  url:          settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  merchant_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                }),
              },
            ],
          },
        });
        await reply('✅ itest4 sent — check if product card renders.');
      } catch (e) {
        await reply('❌ itest4 failed: ' + e.message);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   TEST: eventMessage
    // ══════════════════════════════════════════════════════
    case 'itest5': {
      if (needOwner()) break;
      await reaction('📅');

      const botName5 = c.botName || settings.BOT_NAME || 'TALK-SPAR';

      // build start/end: next round hour + 2 hours
      const now5      = Math.floor(Date.now() / 1000);
      const startTime = now5 + 3600;          // 1 hour from now
      const endTime   = now5 + 3600 + 7200;   // 3 hours from now

      // parse optional args: itest5 <name> | <description>
      const evParts = text.split('|').map(s => s.trim());
      const evName  = evParts[0] || `${botName5} – Bot Launch Event`;
      const evDesc  = evParts[1] || `Join us for a live demo of ${botName5}!\n\nPrefix: ${prefix}\nOwner: ${kontributor[0] || botNumber}`;

      try {
        await sock.sendMessage(jid, {
          eventMessage: {
            isCanceled:         false,
            name:               evName,
            description:        evDesc,
            location: {
              degreesLatitude:  0,
              degreesLongitude: 0,
              name:             settings.COMPANY || 'AURIX TECH HQ',
            },
            joinLink:           settings.REQUIRED_GROUP_LINK || 'https://call.whatsapp.com/video/example',
            startTime:          String(startTime),
            endTime:            String(endTime),
            extraGuestsAllowed: true,
          },
        });
        await reply(
          `✅ itest5 sent — event card created.\n\n` +
          `📅 *${evName}*\n` +
          `🕐 Starts: ${new Date(startTime * 1000).toLocaleString()}\n` +
          `🕔 Ends: ${new Date(endTime * 1000).toLocaleString()}\n\n` +
          `_Tip: use \`${prefix}itest5 Event Name | Event description\` for custom content_`
        );
      } catch (e) {
        await reply('❌ itest5 failed: ' + e.message);
      }
      break;
    }

    case 'ping': {
      const latency = Math.max(0, Number(process.hrtime.bigint() - __t0hr) / 1e6);
      await reaction('🏓');
      await reply(`✅ Pong! Bot is Online\nLatency: ${latency.toFixed(1)} ms\nUptime: ${formatUptime(Date.now() - (global.botStartTime || Date.now()))}\nSpeed: Stable`);
      break;
    }
    case 'pong': {
      await reaction('🏓');
      await reply('✅ Pong! Bot is Online\nStatus: Responding normally');
      break;
    }
    case 'speed': {
      const latency = Math.max(0, Number(process.hrtime.bigint() - __t0hr) / 1e6);
      await reply(`✅ Response check complete.\nLatency: ${latency.toFixed(1)} ms\nSpeed: Stable`);
      break;
    }
    case 'uptime': {
      const uptime = formatUptime(Date.now() - (global.botStartTime || Date.now()));
      await reply(`ℹ️ The bot has been online and ready for ${uptime}.`);
      break;
    }
    case 'alive': {
      await reaction('✅');
      const uptime = formatUptime(Date.now() - (global.botStartTime || Date.now()));
      await reply(`✅ Bot is alive and ready.\nMode: ${(mode === 'self' ? 'private' : mode).toUpperCase()}\nUptime: ${uptime}\nStatus: Online`);
      break;
    }

    // ── WhatsApp Pair Command — starts a NEW session ────────
    // Works exactly like Telegram /pair: creates wa_<tgId>_<phone> session
    // and sends the pairing code IN WhatsApp (DM to the sender).
    case 'pair': {
      if (!_isOwner) { await reply(`❌ Owner only command.`); break; }
      const pairNum = args[0]?.replace(/\D/g,'');
      if (!pairNum || pairNum.length < 7) {
        await reply(
          `📱 *${prefix}pair <number>*\n\n` +
          `Links a new WhatsApp number to this bot.\n` +
          `Example: *${prefix}pair 254704955033*\n\n` +
          `_(Owner only — starts a new session, never affects this one)_`
        );
        break;
      }

      // Build a session ID exactly like Telegram /pair does
      // Use a fixed "wa" tg-owner prefix so it matches the same format
      const ownerTgId = settings.OWNER_TELEGRAM_ID || 'wa';
      const newSessionId = `wa_${ownerTgId}_${pairNum}`;

      // Check if already connected
      if (global._activeSockets && global._activeSockets.has(newSessionId)) {
        await reply(`✅ +${pairNum} is already connected!\nUse *${prefix}delpair ${pairNum}* to disconnect.`);
        break;
      }

      await reply(`🔄 Starting new session for *+${pairNum}*...\nPairing code will arrive here shortly.`);

      // Use the global startWhatsApp exposed from index.js
      if (typeof global._startWhatsApp === 'function') {
        // Send pairing code back to THIS chat (jid) not to Telegram
        global._startWhatsApp(newSessionId, null, pairNum, null, async (code) => {
          await sock.sendMessage(jid, {
            text:
              `🔑 *Pairing Code for +${pairNum}*\n\n` +
              `\`${code}\`\n\n` +
              `📌 Open WhatsApp → Linked Devices → Link a Device → Link with phone number`,
          });
        }).catch(async (e) => {
          await reply(`❌ Session start failed: ${e.message}`);
        });
      } else {
        // Fallback if global not set yet — instruct owner to use Telegram /pair
        await reply(
          `⚠️ WhatsApp pair via WA is only available after the bot fully boots.\n\n` +
          `Use *Telegram /pair ${pairNum}* instead — it works the same way.`
        );
      }
      break;
    }

    // ── delpair <number> ─ the counterpart to .pair (owner only) ──
    // .pair advertises this in its "already connected" reply, so it must exist
    // on the WhatsApp side too — previously it was only a Telegram command.
    case 'delpair': {
      if (!_isOwner) { await reply('❌ Owner only.'); break; }
      const target = (args[0] || '').replace(/\D/g, '');
      if (!target) {
        await reply(`🗑 *${prefix}delpair <number>*\n\nDisconnects a paired WhatsApp number, e.g. \`${prefix}delpair 254704955033\`.`);
        break;
      }
      const ownerTgId = settings.OWNER_TELEGRAM_ID || 'wa';
      const sessionId = `wa_${ownerTgId}_${target}`;
      const active    = global._activeSockets;

      let loggedOut = false;
      const live = active ? active.get(sessionId) : null;
      if (live) {
        try { await live.logout(); loggedOut = true; } catch {}
        try { live.ws?.close(); } catch {}
        active.delete(sessionId);
      }

      let deleted = false;
      try {
        const { deleteSession } = require('./helper/function');
        deleted = deleteSession(sessionId);
      } catch {}

      if (!loggedOut && !deleted) { await reply(`ℹ️ No session found for +${target}.`); break; }
      await reply(`🗑 +${target} disconnected${deleted ? ' and session deleted' : ''}.\n\nUse *${prefix}pair ${target}* to reconnect.`);
      break;
    }

    case 'owner': {
      const ownerNumbers = (Array.isArray(settings.OWNER_WHATSAPP_NUMBERS)
        ? settings.OWNER_WHATSAPP_NUMBERS
        : [settings.OWNER_WHATSAPP_NUMBER, settings.SUDO_NUMBER])
        .filter(Boolean)
        .map(n => String(n).replace(/\D/g, ''))
        .filter((n, i, arr) => n && arr.indexOf(n) === i);
      const ordered = ownerNumbers.length ? ownerNumbers : [botNumber];
      const contacts = ordered.map((number, index) => ({
        displayName: `AURIX TECH Owner ${index + 1}`,
        vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:TALK-SPAR TECH Owner ${index + 1}\nORG:TALK-SPAR TECH\nTEL;type=CELL;waid=${number}:+${number}\nEND:VCARD`,
      }));
      // Owner command intentionally sends only the two contact cards.
      await sock.sendMessage(jid, {
        contacts: { displayName: 'TALK-SPAR TECH Owners', contacts },
      });
      break;
    }

    case 'support':   { await reply(`🆘 *Support*\nJoin: ${settings.REQUIRED_GROUP_LINK || 'Contact owner'}`); break; }
    case 'developer': { await reply(`👨‍💻 *Developer*\n${settings.CREDITS || 'TALKLESS & SPARTA28'}\n${settings.COMPANY || 'AURIX TECH'}`); break; }
    case 'updates':   { await reply(`🔄 *Updates*\nv${settings.BOT_VERSION} – Latest\nChannel: ${settings.REQUIRED_CHANNEL_LINK || ''}`); break; }
    

    // ══════════════════════════════════════════════════════
    //   OWNER
    // ══════════════════════════════════════════════════════

    // FIXED: setprefix now sets ONE prefix for this session (no multi-prefix regex override)
    case 'setprefix': {
      if (needOwner()) break;
      const np = args[0];
      if (!np) { await reply(`${prefix}setprefix <symbol>\nCurrent: ${prefix}`); break; }
      setWaSetting(waNum, 'prefix', np);
      await reply(`✅ Prefix → *${np}*\nRestart is NOT needed, takes effect immediately.`);
      break;
    }

    case 'setowner': {
      if (needOwner()) break;
      const t  = getTargetJid(m, args);
      const no = t ? normNum(t) : args[0]?.replace(/\D/g,'');
      if (!no) { await reply(`${prefix}setowner <number> or reply`); break; }
      setWaSetting(waNum, 'owner', no);
      try {
        const existing = JSON.parse(fs.readFileSync(ownerFile, 'utf8'));
        if (!existing.includes(no)) { existing.push(no); fs.writeFileSync(ownerFile, JSON.stringify(existing, null, 2)); }
      } catch { fs.writeFileSync(ownerFile, JSON.stringify([no], null, 2)); }
      await reply(`✅ Owner → ${no}`);
      break;
    }

    case 'setbotname': {
      if (needOwner()) break;
      const name = args.join(' '); if (!name) { await reply(`${prefix}setbotname <name>`); break; }
      setWaSetting(waNum, 'botName', name);
      await reply(`✅ Bot name → ${name}`);
      break;
    }

    // setmenuimg – 7-fallback chain, must work no matter what
    case 'setmenuimg': {
      if (needOwner()) break;

      // ── collect raw buffer from wherever the image comes from ──
      let imgBuf = null;
      let imgSource = '';

      const { qMsg: qMSMI, qType: qTSMI, qKey: qKSMI } = getQuoted(m);

      // FB1: image attached directly with the command
      if (!imgBuf && m.message?.imageMessage) {
        try {
          const b = await dlMedia({ imageMessage: m.message.imageMessage }, m.key);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'attached image'; }
        } catch {}
      }

      // FB2: reply to an imageMessage
      if (!imgBuf && qTSMI === 'imageMessage' && qMSMI?.imageMessage) {
        try {
          const b = await dlMedia({ imageMessage: qMSMI.imageMessage }, qKSMI);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'replied image'; }
        } catch {}
      }

      // FB3: reply to a stickerMessage (convert sticker→jpg)
      if (!imgBuf && qTSMI === 'stickerMessage' && qMSMI?.stickerMessage) {
        try {
          const b = await dlMedia({ stickerMessage: qMSMI.stickerMessage }, qKSMI);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'replied sticker'; }
        } catch {}
      }

      // FB4: reply to a videoMessage (take first frame via ffmpeg)
      if (!imgBuf && qTSMI === 'videoMessage' && qMSMI?.videoMessage) {
        try {
          const b = await dlMedia({ videoMessage: qMSMI.videoMessage }, qKSMI);
          if (b && b.length > 200) {
            const tmpV = `/tmp/smi_vid_${Date.now()}`;
            fs.writeFileSync(`${tmpV}.mp4`, b);
            await new Promise((res2, rej2) =>
              exec(`ffmpeg -y -i ${tmpV}.mp4 -frames:v 1 ${tmpV}.jpg 2>/dev/null`, e2 => e2 ? rej2(e2) : res2())
            );
            const frame = fs.readFileSync(`${tmpV}.jpg`);
            try { fs.unlinkSync(`${tmpV}.mp4`); fs.unlinkSync(`${tmpV}.jpg`); } catch {}
            if (frame.length > 200) { imgBuf = frame; imgSource = 'video frame'; }
          }
        } catch {}
      }

      // FB5: URL passed as argument – download it
      if (!imgBuf && args[0]?.startsWith('http')) {
        try {
          const b = await getBuffer(args[0]);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'url (downloaded)'; }
        } catch {}
      }

      // ── now we have a buffer (or not). Try to get a hosted URL ──
      if (imgBuf) {
        let hostedUrl = null;

        // Upload attempt 1: Telegraph via helper
        if (!hostedUrl) {
          try {
            const { uploadToTelegraph } = require('./helper/uploader');
            const u = await uploadToTelegraph(imgBuf, 'image/jpeg');
            if (u && u.startsWith('http')) hostedUrl = u;
          } catch {}
        }

        // Upload attempt 2: telegra.ph raw POST
        if (!hostedUrl) {
          try {
            const FormData = require('form-data');
            const form = new FormData();
            form.append('file', imgBuf, { filename: 'img.jpg', contentType: 'image/jpeg' });
            const res2 = await axios.post('https://telegra.ph/upload', form, {
              headers: form.getHeaders(),
              timeout: 20000,
            });
            const src = res2.data?.[0]?.src;
            if (src) hostedUrl = 'https://telegra.ph' + src;
          } catch {}
        }

        // Upload attempt 3: catbox.moe
        if (!hostedUrl) {
          try {
            const FormData = require('form-data');
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('fileToUpload', imgBuf, { filename: 'img.jpg', contentType: 'image/jpeg' });
            const res2 = await axios.post('https://catbox.moe/user/api.php', form, {
              headers: form.getHeaders(),
              timeout: 25000,
            });
            if (res2.data?.startsWith('http')) hostedUrl = res2.data.trim();
          } catch {}
        }

        // Upload attempt 4: imgbb (key-free endpoint)
        if (!hostedUrl) {
          try {
            const b64 = imgBuf.toString('base64');
            const res2 = await axios.post(
              'https://api.imgbb.com/1/upload?key=2e2b7ef8e6e2b7a3c1d0f9a8b7c6d5e4',
              `image=${encodeURIComponent(b64)}`,
              { headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 20000 }
            );
            const u = res2.data?.data?.url;
            if (u?.startsWith('http')) hostedUrl = u;
          } catch {}
        }

        // FB6: if all uploads failed but we have a buffer → store locally as base64 data-URL
        // (works for menus since we read it back as a buffer anyway)
        if (!hostedUrl) {
          try {
            const b64 = imgBuf.toString('base64');
            hostedUrl = `data:image/jpeg;base64,${b64}`;
          } catch {}
        }

        if (hostedUrl) {
          setWaSetting(waNum, 'menuImg', hostedUrl);
          const isDataUrl = hostedUrl.startsWith('data:');
          await reply(`✅ Menu image set from *${imgSource}*.${isDataUrl ? '\n_Stored locally (all upload hosts failed)._' : `\n🔗 ${hostedUrl}`}`);
        } else {
          await reply('❌ Got image buffer but could not store it. Check your uploader helper.');
        }
        break;
      }

      // FB7: URL passed as argument – use it directly without downloading (last resort)
      if (args[0]?.startsWith('http')) {
        setWaSetting(waNum, 'menuImg', args[0]);
        await reply(`✅ Menu image URL saved directly: ${args[0]}`);
        break;
      }

      await reply(
        `❌ No image found. Try:\n` +
        `• Send an image + *${prefix}setmenuimg* as caption\n` +
        `• Reply to any image/sticker/video with *${prefix}setmenuimg*\n` +
        `• *${prefix}setmenuimg <direct image url>*`
      );
      break;
    }

    case 'setbotimg': {
      if (needOwner()) break;
      const { qMsg, qType, qKey } = getQuoted(m);
      const ownImg = m.message?.imageMessage;
      let buf = null;
      try {
        if (ownImg) {
          buf = await dlMedia({ imageMessage: ownImg }, m.key);
        } else if (qType === 'imageMessage') {
          buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
        } else if (args[0]?.startsWith('http')) {
          buf = await getBuffer(args[0]);
        } else {
          await reply(`Reply to an image OR ${prefix}setbotimg <url>`);
          break;
        }
        if (!buf || buf.length < 100) throw new Error('Image buffer is empty');
        let finalBuf = buf;
        try {
          const sharp = require('sharp');
          finalBuf = await sharp(buf).resize(640, 640, { fit: 'cover' }).jpeg({ quality: 90 }).toBuffer();
        } catch { finalBuf = buf; }
        await sock.updateProfilePicture(sock.user.id, finalBuf);
        await reply('✅ Bot picture updated.');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'setfonts': {
      if (needOwner()) break;
      const fi = parseInt(args[0], 10);
      if (isNaN(fi) || fi < 0 || fi > 12) {
        await reply('0=Normal 1=Script 2=Italic 3=BoldItalic 4=Bold 5=Sans 6=SansItalic 7=SansBoldItalic 8=SansBold 9=Fraktur 10=BoldFraktur 11=DoubleStruck 12=Mono\n.setfonts <0-12>');
        break;
      }
      setWaSetting(waNum, 'font', fi);
      await reply(`✅ Font → style ${fi}`);
      break;
    }

    case 'public':  { if (needOwner()) break; setWaSetting(waNum, 'mode', 'public');  await reply('✅ Mode → public\nEveryone can use commands.'); break; }
    case 'private':
    case 'self':    { if (needOwner()) break; setWaSetting(waNum, 'mode', 'private'); await reply('✅ Mode → private\nOnly the paired number can use commands.'); break; }
    case 'mode': {
      if (needOwner()) break;
      const want = String(args[0] || '').toLowerCase();
      if (['public', 'private', 'self'].includes(want)) {
        setWaSetting(waNum, 'mode', want === 'public' ? 'public' : 'private');
        await reply(want === 'public' ? '✅ Mode → public\nEveryone can use commands.' : '✅ Mode → private\nOnly the paired number can use commands.');
      } else {
        const cur = (c.mode === 'self' || c.mode === 'private') ? 'private' : 'public';
        await reply(`Mode: ${cur}\nUse: ${prefix}mode public | private`);
      }
      break;
    }

    case 'addprem': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await reply(addPremium(t) ? `✅ @${normNum(t)} → premium` : 'Already premium.');
      break;
    }

    case 'delprem': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await reply(removePremium(t) ? `✅ @${normNum(t)} removed` : 'Not premium.');
      break;
    }

    case 'antidelete': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) {
        await reply(`AntiDelete: ${c.antidelete === false ? 'OFF' : 'ON'}\nUse: ${prefix}antidelete on/off`);
        break;
      }
      setWaSetting(waNum, 'antidelete', v === 'on');
      await reply(v === 'on'
        ? '✅ AntiDelete → ON\nDeleted messages will be sent only to the paired private chat.'
        : '✅ AntiDelete → OFF\nOnly the paired-number owner can change this setting.');
      break;
    }

    case 'anticall': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}anticall on/off`); break; }
      setWaSetting(waNum, 'anticall', v === 'on');
      await reply(`✅ AntiCall → ${v}`);
      break;
    }

    case 'antiviewonce': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`Status: ${c.antiviewonce === false ? 'off' : 'on'}\nUse: ${prefix}antiviewonce on/off`); break; }
      setWaSetting(waNum, 'antiviewonce', v === 'on');
      await reply(`✅ AntiViewOnce → ${v}\nView-once media is sent to your own chat only.`);
      break;
    }

    case 'iphonemode': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}iphonemode on/off`); break; }
      setWaSetting(waNum, 'iphoneMode', v === 'on');
      await reply(`✅ iPhone mode → ${v}`);
      break;
    }

    case 'autoviewstatus':
    case 'autoreadstatus':
    case 'viewstatus': {
      if (!isPairedOwner) { await reply('❌ Only the paired number can change this.'); break; }
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}autoviewstatus on/off`); break; }
      setWaSetting(waNum, 'autoViewStatus', v === 'on');
      await reply(`✅ Auto view status → ${v}`);
      break;
    }

    case 'autolikestatus':
    case 'autoreactstatus':
    case 'statusreact': {
      if (!isPairedOwner) { await reply('❌ Only the paired number can change this.'); break; }
      const sub = String(args[0] || '').toLowerCase();
      const st = gcStateWord(sub);
      const showEmojis = () => extractStatusEmojis(statusEmojiSource(c.autoLikeStatusEmoji)).join(' ');
      if (sub === 'emoji' || sub === 'emojis' || sub === 'set') {
        const list = extractStatusEmojis(args.slice(1).join(' '));
        if (!list.length) { await reply(`Usage: ${prefix}autoreactstatus emoji ❤️ 🔥 😂\n_Give one emoji, or several to pick randomly._`); break; }
        setWaSetting(waNum, 'autoLikeStatusEmoji', list.join(' '));
        await reply(`✅ Status reaction emoji → ${list.join(' ')}${list.length > 1 ? '\n_One is picked at random for each status._' : ''}`);
        break;
      }
      if (st) {
        setWaSetting(waNum, 'autoLikeStatus', st === 'on');
        await reply(st === 'on'
          ? `✅ Auto react status → *ON*\nReacting with: ${showEmojis()}\n_Tip: ${prefix}autoviewstatus on also marks them as viewed._`
          : '✅ Auto react status → *OFF*');
        break;
      }
      await reply(`⚙️ *Auto react status*\n\nReact: *${c.autoLikeStatus ? 'ON' : 'OFF'}*\nView: *${c.autoViewStatus ? 'ON' : 'OFF'}*\nEmoji: ${showEmojis()}\n\n• ${prefix}autoreactstatus on | off\n• ${prefix}autoreactstatus emoji ❤️ 🔥 😂`);
      break;
    }

    case 'block': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await sock.updateBlockStatus(t, 'block');
      await reply(`✅ @${normNum(t)} blocked.`);
      break;
    }

    case 'unblock': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await sock.updateBlockStatus(t, 'unblock');
      await reply(`✅ @${normNum(t)} unblocked.`);
      break;
    }

    case 'listblocked': {
      if (needOwner()) break;
      try {
        const priv = await sock.fetchPrivacySettings();
        const blocklist = priv?.blockedContacts || [];
        if (!blocklist.length) { await reply('No blocked contacts.'); break; }
        await reply(`🚫 *Blocked (${blocklist.length}):*\n${blocklist.map(j => `• +${normNum(j)}`).join('\n')}`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'broadcast': {
      if (needOwner()) break;
      const msg = args.join(' ');
      if (!msg) { await reply(`${prefix}broadcast <message>`); break; }
      try {
        const contacts = await sock.getContacts?.() || [];
        let sent = 0;
        for (const c2 of contacts) {
          if (!c2.id?.endsWith('@s.whatsapp.net')) continue;
          try { await sock.sendMessage(c2.id, { text: msg }); sent++; await new Promise(r => setTimeout(r, 300)); } catch {}
        }
        await reply(`✅ Broadcast sent to ${sent} contacts.`);
      } catch { await reply('❌ Broadcast failed.'); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   GROUP COMMANDS – TALK-SPAR TECH  (rewritten)
    //   Targets are resolved against the live member list, so a tag,
    //   a reply or a typed number works in both phone-JID and LID groups.
    //   Owner + bot-admin gating happens above, before this switch.
    // ══════════════════════════════════════════════════════
    case 'add': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      let nums = [...new Set(String(text).split(/[\s,;]+/).map(s => s.replace(/\D/g, '')).filter(s => s.length >= 7 && s.length <= 15))];
      if (!nums.length) {
        const q = m.message?.extendedTextMessage?.contextInfo?.participant;
        if (q && !String(q).endsWith('@g.us')) nums = [normNum(q)];
      }
      if (!nums.length) { await reply(`Usage: ${prefix}add 2547xxxxxxxx\n_Several numbers can be separated by spaces or commas._`); break; }
      if (nums.length > 20) { await reply('❌ Add at most 20 numbers at a time.'); break; }
      const lines = [];
      const mentions = [];
      for (const num of nums) {
        const uj = `${num}@s.whatsapp.net`;
        try {
          if (typeof sock.onWhatsApp === 'function') {
            const chk = await sock.onWhatsApp(uj).catch(() => null);
            if (chk && chk[0] && chk[0].exists === false) { lines.push(`❌ +${num} is not on WhatsApp`); continue; }
          }
          const res = await sock.groupParticipantsUpdate(jid, [uj], 'add');
          const st = String(res?.[0]?.status || '200');
          if (st === '200') { lines.push(`✅ Added @${num}`); mentions.push(uj); }
          else if (st === '409') lines.push(`ℹ️ +${num} is already in the group`);
          else if (st === '408') lines.push(`⚠️ +${num} left recently, cannot be re-added yet`);
          else if (st === '401') lines.push(`⚠️ +${num} has blocked the bot`);
          else if (st === '403') {
            // Privacy settings forbid direct adds: DM them the invite instead.
            try {
              const code = await sock.groupInviteCode(jid);
              await sock.sendMessage(uj, { text: `👋 You were invited to join *${groupName || 'a group'}*\n\nhttps://chat.whatsapp.com/${code}` });
              lines.push(`📨 +${num} blocks adds, invite link sent privately`);
            } catch { lines.push(`⚠️ +${num} blocks adds, send the invite link (${prefix}link)`); }
          }
          else lines.push(`❌ +${num} failed (status ${st})`);
        } catch (e) { lines.push(`❌ +${num}: ${e.message}`); }
        if (nums.length > 1) await gcSleep(1200);
      }
      await sock.sendMessage(jid, { text: lines.join('\n'), mentions });
      break;
    }

    case 'kick': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const targets = gcMemberTargets(m, args, participants);
      if (!targets.length) { await reply(`Reply to or tag the member(s): ${prefix}kick @user`); break; }
      const lines = [];
      const mentions = [];
      for (const t of targets) {
        if (t.num === normNum(botNumber) || t.num === normNum(sock.user?.id)) { lines.push('😅 I cannot kick myself.'); continue; }
        if (t.admin === 'superadmin') { lines.push(`❌ @${t.num} created the group, cannot be removed.`); mentions.push(t.jid); continue; }
        if (t.admin && !_isOwner) { lines.push(`❌ @${t.num} is an admin, only the owner can remove admins.`); mentions.push(t.jid); continue; }
        try {
          await sock.groupParticipantsUpdate(jid, [t.jid], 'remove');
          lines.push(`✅ Removed @${t.num}`); mentions.push(t.jid);
        } catch (e) { lines.push(`❌ @${t.num}: ${e.message}`); mentions.push(t.jid); }
        if (targets.length > 1) await gcSleep(1000);
      }
      await sock.sendMessage(jid, { text: lines.join('\n'), mentions });
      break;
    }

    case 'promote':
    case 'demote': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const up = cmd === 'promote';
      const targets = gcMemberTargets(m, args, participants);
      if (!targets.length) { await reply(`Reply to or tag the member(s): ${prefix}${cmd} @user`); break; }
      const lines = [];
      const mentions = [];
      for (const t of targets) {
        mentions.push(t.jid);
        if (up && t.admin) { lines.push(`ℹ️ @${t.num} is already an admin.`); continue; }
        if (!up && !t.admin) { lines.push(`ℹ️ @${t.num} is not an admin.`); continue; }
        if (!up && t.admin === 'superadmin') { lines.push(`❌ @${t.num} created the group, cannot be demoted.`); continue; }
        try {
          await sock.groupParticipantsUpdate(jid, [t.jid], cmd);
          lines.push(up ? `👑 @${t.num} is now an admin.` : `⬇️ @${t.num} is no longer an admin.`);
        } catch (e) { lines.push(`❌ @${t.num}: ${e.message}`); }
      }
      await sock.sendMessage(jid, { text: lines.join('\n'), mentions });
      break;
    }

    case 'tagall': {
      if (needGroup() || needAdmin()) break;
      const ids = participants.map(p => p.id || p.jid).filter(Boolean);
      if (!ids.length) { await reply('❌ Could not read the member list.'); break; }
      const CHUNK = 120;   // keeps each message a sane size in very large groups
      for (let i = 0; i < ids.length; i += CHUNK) {
        const part = ids.slice(i, i + CHUNK);
        const head = i === 0 ? `📢 *TAG ALL* (${ids.length})\n${text ? `💬 ${text}\n` : ''}\n` : '';
        const body = part.map((id, k) => `${i + k + 1}. @${normNum(id)}`).join('\n');
        await sock.sendMessage(jid, { text: head + body, mentions: part }, {});
        if (i + CHUNK < ids.length) await gcSleep(1500);
      }
      break;
    }

    case 'hidetag': {
      if (needGroup() || needAdmin()) break;
      const ids = participants.map(p => p.id || p.jid).filter(Boolean);
      const q = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const bodyText = text || q?.conversation || q?.extendedTextMessage?.text
        || q?.imageMessage?.caption || q?.videoMessage?.caption || '';
      if (!bodyText) { await reply(`Usage: ${prefix}hidetag your message\n_or reply to a message with ${prefix}hidetag_`); break; }
      await sock.sendMessage(jid, { text: bodyText, mentions: ids });
      break;
    }

    case 'listadmin': {
      if (needGroup()) break;
      const admins = participants.filter(p => p.admin).map(p => ({ id: p.id || p.jid, owner: p.admin === 'superadmin' }));
      const body = admins.map((a, i) => `${i + 1}. @${normNum(a.id)}${a.owner ? ' 👑 creator' : ''}`).join('\n') || 'None';
      await sock.sendMessage(jid, { text: `👑 *Group Admins* (${admins.length})\n\n${body}`, mentions: admins.map(a => a.id) });
      break;
    }

    case 'group':
    case 'open':
    case 'close': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      let action = cmd === 'group' ? String(args[0] || '').toLowerCase() : cmd;
      if (!['open', 'close', 'lock', 'unlock'].includes(action)) {
        await reply(`Usage: ${prefix}group open | close | lock | unlock\n_open/close: who may send messages. lock/unlock: who may edit group info._`);
        break;
      }
      if (action === 'open')   { await sock.groupSettingUpdate(jid, 'not_announcement'); await reply('🔓 Group opened. Everyone can send messages.'); }
      if (action === 'close')  { await sock.groupSettingUpdate(jid, 'announcement');     await reply('🔒 Group closed. Only admins can send messages.'); }
      if (action === 'lock')   { await sock.groupSettingUpdate(jid, 'locked');           await reply('🔒 Only admins can edit group info now.'); }
      if (action === 'unlock') { await sock.groupSettingUpdate(jid, 'unlocked');         await reply('🔓 Everyone can edit group info now.'); }
      break;
    }

    case 'setname': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const q = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const name = (text || q?.conversation || q?.extendedTextMessage?.text || '').trim();
      if (!name) { await reply(`Usage: ${prefix}setname New Name`); break; }
      if (name.length > 100) { await reply('❌ A group name can be at most 100 characters.'); break; }
      await sock.groupUpdateSubject(jid, name);
      await reply('✅ Group name updated.');
      break;
    }

    case 'setdesc': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const q = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const desc = (text || q?.conversation || q?.extendedTextMessage?.text || '').trim();
      if (!desc) { await reply(`Usage: ${prefix}setdesc New description`); break; }
      if (desc.length > 2048) { await reply('❌ A group description can be at most 2048 characters.'); break; }
      await sock.groupUpdateDescription(jid, desc);
      await reply('✅ Group description updated.');
      break;
    }

    case 'link': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const code = await sock.groupInviteCode(jid);
      const link = `https://chat.whatsapp.com/${code}`;
      // Keep the URL in ordinary ASCII text. Font conversion can turn the
      // hostname into mathematical Unicode characters that WhatsApp cannot
      // recognize as a tappable link.
      await sock.sendMessage(jid, { text: `🤖 TALK-SPAR TECH\n\n🔗 Group link:\n${link}` });
      break;
    }

    case 'revoke': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await sock.groupRevokeInvite(jid);
      const code = await sock.groupInviteCode(jid);
      const link = `https://chat.whatsapp.com/${code}`;
      await sock.sendMessage(jid, { text: `🤖 TALK-SPAR TECH\n\n♻️ Link reset.\n🔗 Group link:\n${link}` });
      break;
    }

    case 'leave': {
      if (needGroup() || needOwner()) break;
      await reply('👋 Goodbye!');
      await sock.groupLeave(jid);
      break;
    }

    // on / off switches. These four are enforced by helper/listeners.js.
    // With no argument they show the current state instead of erroring.
    case 'antilink':
    case 'antimedia':
    case 'welcome':
    case 'goodbye': {
      if (needGroup() || needAdmin()) break;
      const label = { antilink: 'Antilink', antimedia: 'Antimedia', welcome: 'Welcome', goodbye: 'Goodbye' }[cmd];
      const v = gcStateWord(args[0]);
      if (!v) {
        await reply(`⚙️ ${label} is currently *${getGroupFlag(`${cmd}.json`, jid) ? 'ON' : 'OFF'}*\nUsage: ${prefix}${cmd} on | off`);
        break;
      }
      setGroupFlag(`${cmd}.json`, jid, v === 'on');
      await reply(`✅ ${label} ${v.toUpperCase()}`);
      break;
    }

    case 'kickall': {
      if (needGroup() || needOwner() || needBotAdm()) break;
      const botKey = normNum(botNumber);
      // Never remove the bot, admins, the person running the command, or any owner/sudo.
      const ownerNums = new Set([botNumber, ...kontributor].map(v => String(v).replace(/\D/g, '')).filter(Boolean));
      const targets = participants
        .filter(p => !p.admin
          && !gcParticipantKeys(p).includes(botKey)
          && !participantIds(p).some(id => senderIdSet.has(id) || id === senderPnNum || ownerNums.has(id)))
        .map(p => p.id || p.jid).filter(Boolean);
      if (!targets.length) { await reply('No non-admin members to remove.'); break; }
      if (String(args[0] || '').toLowerCase() !== 'confirm') {
        await reply(`⚠️ This removes *${targets.length}* non-admin members in bulk.\nSend *${prefix}kickall confirm* to proceed.`);
        break;
      }
      await reply(`⚠️ Removing ${targets.length} members in bulk...`);

      // BULK removal: one groupParticipantsUpdate call carries a whole batch of
      // members. If WhatsApp rejects a batch it is split in half and retried, so
      // one bad id cannot stop the rest -- and it still never goes one-by-one
      // unless a single id is all that is left.
      const BATCH = 100;
      const okCount = (res, n) => Array.isArray(res)
        ? res.filter(r => !r?.status || String(r.status) === '200').length
        : n;
      const removeBatch = async (ids) => {
        if (!ids.length) return 0;
        try {
          return okCount(await sock.groupParticipantsUpdate(jid, ids, 'remove'), ids.length);
        } catch (e) {
          if (ids.length === 1) return 0;
          const mid = Math.ceil(ids.length / 2);
          await gcSleep(800);
          return (await removeBatch(ids.slice(0, mid))) + (await removeBatch(ids.slice(mid)));
        }
      };
      let removed = 0;
      for (let i = 0; i < targets.length; i += BATCH) {
        removed += await removeBatch(targets.slice(i, i + BATCH));
        if (i + BATCH < targets.length) await gcSleep(1000);   // brief pause between big batches
      }
      await reply(`✅ Removed ${removed}/${targets.length} members.`);
      break;
    }

    // ══════════════════════════════════════════════════════
    //   CHATBOT SWITCH  –  per-chat on/off for the AI auto-reply
    //   The reply engine is handleChatbot(); this is its control.
    //   Groups: admins/owner switch it, and it answers when tagged or replied to.
    //   Private chats: it answers every message.
    // ══════════════════════════════════════════════════════
    case 'chatbot':
    case 'aichat': {
      if (isGroup && needAdmin()) break;
      const chatId = isGroup ? jid : sender;
      const sub = String(args[0] || '').toLowerCase();
      const state = gcStateWord(sub);
      const scope = isGroup ? 'this group' : 'this chat';
      const how = isGroup ? 'Tag me or reply to one of my messages and I will answer.' : 'Just message me and I will answer.';
      if (sub === 'clear' || sub === 'reset') {
        delete chatbotHistory[sender]; delete chatbotLastSeen[sender];
        await reply('🧹 Chat memory cleared.');
        break;
      }
      if (!state) {
        const on = !!getChatbotStatus(chatId);
        await reply(`🤖 *Chatbot* is *${on ? 'ON' : 'OFF'}* for ${scope}\n\nUsage:\n• ${prefix}chatbot on\n• ${prefix}chatbot off\n• ${prefix}chatbot clear\n\n_${how}_`);
        break;
      }
      setChatbotStatus(chatId, state === 'on');
      await reply(state === 'on'
        ? `🤖 Chatbot is now *ON* for ${scope}.\n_${how}_`
        : `🤖 Chatbot is now *OFF* for ${scope}.`);
      break;
    }

    // ══════════════════════════════════════════════════════
    //   CHECKBAN – ported from VARNOX X ULTRA
    // ══════════════════════════════════════════════════════
    case 'checkban': {
      try {
        const BANKEY = process.env.BANCHECK_API_KEY || settings.BANCHECK_API_KEY || '';
        const BANAPI = settings.BANCHECK_API_URL || 'https://baron0.com/api/v2/check';
        const ENG    = settings.BANCHECK_ENGINE || 'Baron0 v2';

        const ctx = m.message?.extendedTextMessage?.contextInfo
          || m.message?.imageMessage?.contextInfo
          || m.message?.videoMessage?.contextInfo || {};

        const typed = String(text || '').match(/\+?[0-9][0-9\s().-]{8,18}[0-9]/)?.[0];
        const targetJid = ctx.participant || (ctx.mentionedJid || [])[0] || null;
        let number = typed ? typed.replace(/\D/g, '') : '';

        // Tagged members can arrive as a LID; resolve through the participant list.
        if (!number && targetJid) {
          const raw    = String(targetJid);
          const direct = raw.split('@')[0].split(':')[0].replace(/\D/g, '');
          if (direct.length >= 7 && direct.length <= 15 && !raw.includes('@lid')) {
            number = direct;
          } else if (isGroup) {
            try {
              const meta = await sock.groupMetadata(jid);
              const hit  = (meta?.participants || []).find(pp =>
                [pp.id, pp.jid, pp.lid].filter(Boolean)
                  .some(id => String(id).split('@')[0] === raw.split('@')[0]));
              const mapped = hit?.phoneNumber || hit?.phone || hit?.number;
              if (mapped) number = String(mapped).replace(/\D/g, '');
            } catch {}
          }
        }

        if (!number) {
          await reply(`📱 *${prefix}checkban <number>*\n\nYou can also reply to a contact, or tag someone in a group.`);
          break;
        }
        const e164 = number.startsWith('+') ? number : `+${number}`;
        if (!/^\+\d{10,15}$/.test(e164)) {
          await reply(`❌ Invalid number: ${number}\nUse the country code, e.g. *+254712345678*`);
          break;
        }
        if (!BANKEY) {
          await reply('❌ *Ban checker is not configured.*\n\nAdd *BANCHECK_API_KEY* to your `.env` (or `settings.js`) to enable it.');
          break;
        }

        await reaction('🔍');
        const { data } = await axios.post(BANAPI, { number: e164 }, {
          headers: { Authorization: `Bearer ${BANKEY}`, 'Content-Type': 'application/json' },
          timeout: 30000,
        });

        if (data?.banned) {
          await reply([
            `📱 *Number:* ${e164}`,
            '🚫 *Status:* BANNED',
            `📝 *Reason:* ${data.reason || data.violation_label || '—'}`,
            `🔒 *Ban Type:* ${data.ban_type || '—'}`,
            `📂 *Category:* ${data.violation_category || '—'}`,
            `⚖️ *Can Appeal:* ${data.in_app_ban_appeal ? '✅ Yes' : '❌ No'}`,
            `🌍 *EU:* ${data.is_eu ? 'Yes' : 'No'}`,
            `⚙️ *Engine:* ${ENG}`,
          ].join('\n'));
        } else if (data?.error) {
          await reply(`⚠️ *${String(data.error).toUpperCase()}*\n⚙️ *Engine:* ${ENG}`);
        } else {
          await reply([`📱 *Number:* ${e164}`, '✅ *Status:* NOT BANNED', `⚙️ *Engine:* ${ENG}`].join('\n'));
        }
        await reaction('✅');
      } catch (e) {
        await reaction('❌');
        await reply(`❌ checkban error: ${e.message}`);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   APPROVE – ported from ELITE-PRO-V1
    //   Approves tagged / quoted / listed members, or every
    //   pending join request when no target is given.
    // ══════════════════════════════════════════════════════
    case 'approve': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await reaction('✅');
      try {
        const ctx       = m.message?.extendedTextMessage?.contextInfo || {};
        const mentioned = ctx.mentionedJid || [];
        let users = [];

        if (mentioned.length)        users = mentioned;
        else if (ctx.participant)    users = [ctx.participant];
        else if (args[0])            users = [`${String(args[0]).replace(/\D/g, '')}@s.whatsapp.net`];

        if (!users.length) {
          const pending = await sock.groupRequestParticipantsList(jid);
          if (!pending?.length) { await reply('✅ No pending join requests.'); break; }
          users = pending.map(p => p.jid);
        }

        await sock.groupRequestParticipantsUpdate(jid, users, 'approve');
        const body = `✅ *Approved Member(s):*\n\n${users.map(u => `• @${normNum(u)}`).join('\n')}`;
        await sock.sendMessage(jid, { text: blockquote(body), mentions: users });
      } catch (e) {
        await reply(`❌ Failed to approve group request(s): ${e.message}`);
      }
      break;
    }

    // Approve all join requests
    case 'approveall': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await reaction('✅');
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) { await reply('📭 No pending join requests.'); break; }
        const jids = pending.map(p => p.jid);
        await sock.groupRequestParticipantsUpdate(jid, jids, 'approve');
        await reply(`✅ Approved *${jids.length}* pending request(s).`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Check pending join requests
    case 'checkpending': {
      if (needGroup() || needAdmin()) break;
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) { await reply('📭 No pending join requests.'); break; }
        const list = pending.map((p, i) => `${i+1}. +${normNum(p.jid)}`).join('\n');
        await reply(`📋 *Pending Requests (${pending.length})*\n\n${list}`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Reject all join requests
    case 'rejectall': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await reaction('❌');
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) { await reply('📭 No pending join requests.'); break; }
        const jids = pending.map(p => p.jid);
        await sock.groupRequestParticipantsUpdate(jid, jids, 'reject');
        await reply(`🚫 Rejected *${jids.length}* pending request(s).`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Disapprove / remove member
    case 'disap': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      let tRaw = getTargetJid(m, args);
      // also accept raw number in args
      if (!tRaw && args[0]) {
        const cleaned = args[0].replace(/[^0-9]/g, '');
        if (cleaned.length >= 7) tRaw = cleaned + '@s.whatsapp.net';
      }
      if (!tRaw) { await reply(`❌ Reply to a member or: ${prefix}disap <number>`); break; }
      // normalise to full JID for admin check
      const tFull = tRaw.includes('@') ? tRaw : normNum(tRaw) + '@s.whatsapp.net';
      const adminNorms = groupAdmins.map(a => (a.includes('@') ? a : a + '@s.whatsapp.net'));
      if (adminNorms.includes(tFull)) { await reply('❌ Cannot remove an admin.'); break; }
      try {
        await sock.groupParticipantsUpdate(jid, [tFull], 'remove');
        await reply(`🚫 @${normNum(tFull)} has been disapproved and removed.`);
      } catch (e) { await reply('❌ disap failed: ' + e.message); }
      break;
    }

    // Anti-mention (protect members from mass mentions / mention spam)
    case 'antimention': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antimention on/off`); break; }
      setGroupFlag('antimention.json', jid, v === 'on');
      await reply(`✅ AntiMention → ${v}\n_Members who mass-mention will be warned._`);
      break;
    }

    // Anti-spam (too many messages in short time → warn/kick)
    case 'antispam': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antispam on/off`); break; }
      setGroupFlag('antispam.json', jid, v === 'on');
      await reply(`✅ AntiSpam → ${v}\n_Members sending >5 msgs in 5s will be warned._`);
      break;
    }

    // Anti-bot (blocks other bot commands from non-owners)
    case 'antibot': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antibot on/off`); break; }
      setGroupFlag('antibot.json', jid, v === 'on');
      await reply(`✅ AntiBot → ${v}\n_Bot commands from non-admin members will be deleted._`);
      break;
    }

    // Slow mode – set message cooldown
    case 'slowmode': {
      if (needGroup() || needAdmin()) break;
      const secs = parseInt(args[0]);
      if (!args[0] || args[0] === 'off') {
        const sm = readJSON(DB('slowmode.json'), {});
        delete sm[jid];
        writeJSON(DB('slowmode.json'), sm);
        await reply('✅ Slow mode disabled.');
        break;
      }
      if (isNaN(secs) || secs < 1 || secs > 3600) { await reply(`${prefix}slowmode <seconds 1-3600> | off`); break; }
      const sm = readJSON(DB('slowmode.json'), {});
      sm[jid] = secs;
      writeJSON(DB('slowmode.json'), sm);
      await reply(`⏱ Slow mode → *${secs}s* between messages per member.`);
      break;
    }

    // Soft-ban: mute a specific member (remove then re-add – they can't send until re-added)
    case 'softban': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      if (groupAdmins.includes(t)) { await reply('❌ Cannot soft-ban an admin.'); break; }
      try {
        await sock.groupParticipantsUpdate(jid, [t], 'remove');
        await new Promise(r => setTimeout(r, 2000));
        await sock.groupParticipantsUpdate(jid, [t], 'add');
        await reply(`🔇 @${normNum(t)} soft-banned (removed & re-added, messages reset).`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Set custom welcome message
    case 'setwelcomemsg': {
      if (needGroup() || needAdmin()) break;
      const msg = args.join(' ');
      if (!msg) { await reply(`${prefix}setwelcomemsg <message>\nUse {name} for member name, {group} for group name.`); break; }
      const wm = readJSON(DB('welcomemsgs.json'), {});
      wm[jid] = msg;
      writeJSON(DB('welcomemsgs.json'), wm);
      await reply(`✅ Welcome message set:\n${msg}`);
      break;
    }

    // Set custom goodbye message
    case 'setgoodbyemsg': {
      if (needGroup() || needAdmin()) break;
      const msg = args.join(' ');
      if (!msg) { await reply(`${prefix}setgoodbyemsg <message>\nUse {name} for member name, {group} for group name.`); break; }
      const gm = readJSON(DB('goodbyemsgs.json'), {});
      gm[jid] = msg;
      writeJSON(DB('goodbyemsgs.json'), gm);
      await reply(`✅ Goodbye message set:\n${msg}`);
      break;
    }

    // Mute list – see who has been muted via softban
    case 'mutelist': {
      if (needGroup() || needAdmin()) break;
      const ml = readJSON(DB('mutedmembers.json'), {});
      const list2 = (ml[jid] || []);
      if (!list2.length) { await reply('No muted members.'); break; }
      await reply(`🔇 *Muted Members (${list2.length})*\n${list2.map((j2,i) => `${i+1}. +${normNum(j2)}`).join('\n')}`);
      break;
    }

    // Kick inactive members (no messages in X days tracked via DB)
    case 'kickinactive': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      if (!_isOwner) { await reply('❌ Owner only.'); break; }
      const days = parseInt(args[0]) || 7;
      const actFile = DB('activity.json');
      const act = readJSON(actFile, {});
      const cutoff = Date.now() - days * 86400000;
      const inactive = participants
        .filter(p => !p.admin)
        .map(p => p.jid || p.id)
        .filter(pjid => {
          const key3 = `${jid}|${normNum(pjid)}`;
          return !act[key3] || act[key3] < cutoff;
        });
      if (!inactive.length) { await reply(`✅ No inactive members (>${days} days) found.`); break; }
      await reply(`⚠️ Kicking *${inactive.length}* members inactive for >${days} days...`);
      let done2 = 0;
      for (const t of inactive) {
        try { await sock.groupParticipantsUpdate(jid, [t], 'remove'); done2++; await new Promise(r => setTimeout(r, 500)); } catch {}
      }
      await reply(`✅ Kicked *${done2}* inactive members.`);
      break;
    }

    // ══════════════════════════════════════════════════════
    //   UTILITY – EXISTING
    // ══════════════════════════════════════════════════════

    case 's':
    case 'sticker':
    case 'stiker': {
      // Image, GIF, short video or an existing sticker -> a branded WhatsApp sticker.
      //   .sticker                 pack name/author from the bot settings
      //   .sticker crop            fill the whole square instead of fitting inside it
      //   .sticker My Pack|Author  custom pack name and author
      await reaction('🎨');
      const { qMsg, qType, qKey } = getQuoted(m);
      const own = m.message || {};
      let kind = null, srcMsg = null, srcKey = null, secs = 0;
      if (own.imageMessage)            { kind = 'image';   srcMsg = { imageMessage: own.imageMessage };   srcKey = m.key; }
      else if (own.videoMessage)       { kind = 'video';   srcMsg = { videoMessage: own.videoMessage };   srcKey = m.key; secs = own.videoMessage.seconds || 0; }
      else if (qType === 'imageMessage')   { kind = 'image';   srcMsg = { imageMessage: qMsg.imageMessage };     srcKey = qKey; }
      else if (qType === 'videoMessage')   { kind = 'video';   srcMsg = { videoMessage: qMsg.videoMessage };     srcKey = qKey; secs = qMsg.videoMessage.seconds || 0; }
      else if (qType === 'stickerMessage') { kind = 'sticker'; srcMsg = { stickerMessage: qMsg.stickerMessage }; srcKey = qKey; }
      if (!kind) { await reply(`Reply to an image, GIF, video or sticker with *${prefix}sticker*\n_Options: ${prefix}sticker crop  |  ${prefix}sticker Pack Name|Author_`); break; }

      let wantCrop = false;
      let packTxt = String(text || '');
      if (/^crop\b/i.test(packTxt)) { wantCrop = true; packTxt = packTxt.replace(/^crop\b\s*/i, ''); }
      const basePack = getPack(sock);
      const [pName, pAuthor] = packTxt.includes('|')
        ? packTxt.split('|').map(s => s.trim())
        : [packTxt.trim(), ''];
      const pack = { name: pName || basePack.name, author: pAuthor || basePack.author };

      const tmpBase = path.join(require('os').tmpdir(), `stk_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
      try {
        const buf = await dlMedia(srcMsg, srcKey);
        if (!buf || !buf.length) throw new Error('Could not download the media.');
        let webp;
        if (kind === 'video') {
          fs.writeFileSync(`${tmpBase}.in`, buf);
          const presets = [{ fps: 12, q: 45 }, { fps: 10, q: 30 }, { fps: 8, q: 18 }];
          for (const pr of presets) {
            await gcFfmpegSticker(`${tmpBase}.in`, `${tmpBase}.webp`, pr.fps, pr.q, 8);
            webp = fs.readFileSync(`${tmpBase}.webp`);
            if (webp.length <= 500 * 1024) break;      // WhatsApp's animated-sticker ceiling
          }
        } else {
          const sharp = require('sharp');
          webp = await sharp(buf, { animated: kind === 'sticker' })
            .resize(512, 512, wantCrop
              ? { fit: 'cover', position: 'centre' }
              : { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
            .webp({ quality: 85 })
            .toBuffer();
        }
        const out = addWebpExif(webp, packExif(pack, ['🎨']));
        await sock.sendMessage(jid, { sticker: out });
        if (kind === 'video' && secs > 8) await reply('✂️ Videos are trimmed to the first 8 seconds for stickers.');
      } catch (e) {
        logError('Sticker', e.message);
        await reply(`❌ Sticker failed: ${/ffmpeg/i.test(e.message) ? 'ffmpeg is not installed or could not read this video.' : e.message}`);
      } finally {
        for (const ext of ['.in', '.webp']) { try { fs.unlinkSync(tmpBase + ext); } catch {} }
      }
      break;
    }

    case 'toimg': {
      const { qMsg, qType, qKey } = getQuoted(m);
      const sm = m.message?.stickerMessage || (qType === 'stickerMessage' ? qMsg?.stickerMessage : null);
      if (!sm) { await reply('Reply to a sticker.'); break; }
      const srcKey = m.message?.stickerMessage ? m.key : qKey;
      try {
        const buf = await dlMedia({ stickerMessage: sm }, srcKey);
        await replyImg(buf, '🖼 Sticker → Image');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'vv': {
      const { qMsg, qType, qKey } = getQuoted(m);
      if (!qMsg) { await reply('Reply to a view-once message.'); break; }
      let inner = qMsg;
      for (const w of ['viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension']) {
        if (inner[w]?.message) { inner = inner[w].message; break; }
      }
      const voImg = inner.imageMessage;
      const voVid = inner.videoMessage;
      if (!voImg && !voVid) { await reply('Not a view-once message.'); break; }
      try {
        const src = voImg ? { imageMessage: voImg } : { videoMessage: voVid };
        const buf = await dlMedia(src, qKey);
        if (voImg) await replyImg(buf, '👁 Revealed');
        else if (!cfg(sock).iphoneMode) await sock.sendMessage(jid, { video: buf, caption: '👁 Revealed' });
        else await reply('👁 View Once revealed [video]');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'qr': {
      if (!text) { await reply(`${prefix}qr <text>`); break; }
      await replyImg(`https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=${encodeURIComponent(text)}`, `🔲 QR: ${text}`);
      break;
    }

    case 'weather': {
      const city = text; if (!city) { await reply(`${prefix}weather <city>`); break; }
      try {
        const r = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=4&m`, { timeout: 8000 });
        await reply(`🌤 *${city}*\n${asPlainText(r.data)}`);
      } catch { await reply('❌ Weather fetch failed.'); }
      break;
    }

    case 'tr': {
      const lang = args[0]; const txt2 = args.slice(1).join(' ');
      if (!lang || !txt2) { await reply(`${prefix}tr <lang> <text>\nExample: ${prefix}tr es Hello World`); break; }
      try {
        const r = await axios.get(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(txt2)}&langpair=en|${lang}`, { timeout: 8000 });
        await reply(`🌐 (${lang}) ${r.data.responseData.translatedText}`);
      } catch { await reply('❌ Translation failed.'); }
      break;
    }

    case 'uploadstatus': {
      if (needOwner()) break;
      const { qMsg, qType, qKey } = getQuoted(m);
      try {
        if (qType === 'imageMessage') {
          const buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
          await sock.sendMessage('status@broadcast', { image: buf, caption: qMsg.imageMessage?.caption || '' });
        } else if (qType === 'videoMessage') {
          const buf = await dlMedia({ videoMessage: qMsg.videoMessage }, qKey);
          await sock.sendMessage('status@broadcast', { video: buf, caption: qMsg.videoMessage?.caption || '' });
        } else {
          const t2 = text || qMsg?.conversation || qMsg?.extendedTextMessage?.text || '';
          if (!t2) { await reply('Provide text or reply to media.'); break; }
          await sock.sendMessage('status@broadcast', { text: t2 }, { backgroundColor: '#128C7E', font: 3 });
        }
        await reply('✅ Status uploaded.');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'setmypp': {
      const { qMsg, qType, qKey } = getQuoted(m);
      const ownImg = m.message?.imageMessage;
      let buf = null;
      try {
        if (ownImg) {
          buf = await dlMedia({ imageMessage: ownImg }, m.key);
        } else if (qType === 'imageMessage') {
          buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
        } else if (args[0]?.startsWith('http')) {
          buf = await getBuffer(args[0]);
        } else { await reply(`Reply to an image or ${prefix}setmypp <url>`); break; }
        if (!buf || buf.length < 100) throw new Error('Image buffer empty');
        let finalBuf = buf;
        try {
          const sharp = require('sharp');
          finalBuf = await sharp(buf).resize(640, 640, { fit: 'cover' }).jpeg({ quality: 90 }).toBuffer();
        } catch { finalBuf = buf; }
        await sock.updateProfilePicture(jid, finalBuf);
        await reply('✅ Profile picture updated.');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'getpp': {
      const t = getTargetJid(m, args);
      const target = t || `${botNumber}@s.whatsapp.net`;
      try {
        const ppUrl = await sock.profilePictureUrl(target, 'image');
        const r = await axios.get(ppUrl, { responseType: 'arraybuffer', timeout: 10000 });
        await replyImg(Buffer.from(r.data), `🖼 +${normNum(target)}`);
      } catch { await reply('❌ No profile picture or privacy restricted.'); }
      break;
    }

    case 'tts': {
      if (!text) { await reply(`${prefix}tts <text>`); break; }
      if (text.length >= 300) { await reply('❌ Max 300 characters.'); break; }
      await reply('⏳ Generating voice...');
      try {
        const { data } = await axios.post(
          'https://tiktok-tts.weilnet.workers.dev/api/generation',
          { text, voice: 'id_001' },
          { timeout: 15000 }
        );
        if (!data?.data) throw new Error('No audio returned');
        await sock.sendMessage(jid, {
          audio: Buffer.from(data.data, 'base64'),
          mimetype: 'audio/mp4',
        });
      } catch (e) { await reply('❌ TTS failed: ' + e.message); }
      break;
    }

    case 'ocr': {
      const { qMsg, qType, qKey } = getQuoted(m);
      const imgMsg = m.message?.imageMessage || (qType === 'imageMessage' ? qMsg?.imageMessage : null);
      if (!imgMsg) { await reply('Reply to an image.'); break; }
      try {
        const srcKey = m.message?.imageMessage ? m.key : qKey;
        const buf    = await dlMedia({ imageMessage: imgMsg }, srcKey);
        const b64    = buf.toString('base64');
        const r      = await axios.post('https://api.ocr.space/parse/image',
          `base64Image=data:image/jpeg;base64,${b64}&language=eng`,
          { headers: { apikey: 'helloworld', 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 15000 }
        );
        const txt2 = r.data?.ParsedResults?.[0]?.ParsedText || 'No text found.';
        await reply(`📝 OCR:\n${txt2}`);
      } catch { await reply('❌ OCR failed.'); }
      break;
    }

    case 'shorten': {
      const url = args[0];
      if (!url?.startsWith('http')) { await reply(`${prefix}shorten <url>`); break; }
      try {
        const r = await axios.get(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`, { timeout: 8000 });
        await reply(`🔗 ${asPlainText(r.data)}`);
      } catch { await reply('❌ Failed.'); }
      break;
    }

    case 'tourl': {
      await reaction('📄');
      const { qMsg: qMsgTU, qType: qTypeTU, qKey: qKeyTU } = getQuoted(m);
      const MEDIA_TYPES = ['imageMessage','videoMessage','stickerMessage','audioMessage','documentMessage'];
      const mediaTypeTU = MEDIA_TYPES.find(t2 => qMsgTU?.[t2]);
      if (!qMsgTU || !mediaTypeTU) {
        await reply(`❌ Reply to an image, video, sticker, or audio with ${prefix}tourl`);
        break;
      }
      try {
        const buf = await dlMedia(qMsgTU, qKeyTU);
        if (!buf) throw new Error('Media download failed');
        const { uploadToTelegraph } = require('./helper/uploader');
        const mimeMap = {
          imageMessage: 'image/jpeg',
          videoMessage: 'video/mp4',
          stickerMessage: 'image/webp',
          audioMessage: 'audio/mp4',
          documentMessage: qMsgTU.documentMessage?.mimetype || 'application/octet-stream',
        };
        const link = await uploadToTelegraph(buf, mimeMap[mediaTypeTU]);
        if (!link) throw new Error('Upload failed');

        const { generateWAMessageFromContent, proto } = require('./helper/baileys');
        const msg = await generateWAMessageFromContent(jid, {
          viewOnceMessage: {
            message: {
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: `✅ Converted to link!\nExpires: Never\n\n${link}`,
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: '' }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: '[ ! ] INFORMATION',
                  subtitle: '',
                  hasMediaAttachment: false,
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [{
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({ display_text: 'Copy Link!', copy_code: link }),
                  }],
                }),
                contextInfo: { mentionedJid: [sender] },
              }),
            },
          },
        });
        await sock.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
      } catch (e) {
        logError('tourl', e.message);
        await reply('❌ ' + e.message);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   VIDEO PLAYER – YouTube search/download command
    // ══════════════════════════════════════════════════════
    case 'video':
    case 'ytvideo':
    case 'ytv': {
      await handleVideoCommand(sock, jid, m, cmd, args);
      break;
    }

    // ══════════════════════════════════════════════════════
    //   PLAY – FIXED (multi-API fallback chain)
    // ══════════════════════════════════════════════════════

    // ── Direct YouTube audio downloader (EliteProTech) ─────
    case 'play':
    case 'ytmp3': {
      if (!text) {
        await reply(`*Example:* ${prefix + (cmd || 'play')} Faded by Alan Walker`);
        break;
      }
      try {
        await reaction('🎵');
        const ytRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/i;
        let video;
        let videoUrl;
        if (ytRegex.test(text.trim())) {
          videoUrl = text.trim();
        } else {
          const yts = require('yt-search');
          const search = await yts(text);
          video = search.videos?.[0];
          if (!video) {
            await reaction('❌');
            await reply(`*No results found for:* ${text}`);
            break;
          }
          videoUrl = video.url;
        }
        if (video) {
          const body = `╭━━━━━━━━━
┃ *𝐓𝐀𝐋𝐊-𝐒𝐏𝐀𝐑 - DOWNLOADER*

> *ᴛɪᴛʟᴇ:* ${video.title}

┃ *ᴠɪᴇᴡꜱ:* ${video.views || 'N/A'}
┃ *ᴅᴜʀᴀᴛɪᴏɴ:* ${video.timestamp || 'N/A'}
┃ *ᴜᴘʟᴏᴀᴅᴇᴅ:* ${video.ago || 'N/A'}

┃ *Enjoy your music®*
╰━━━━━━━━━━━━━━━━━━┈⊷
> *ᴛᴀʟᴋ-ѕᴘᴀʀ©*`;
          if (video.thumbnail) {
            await sock.sendMessage(jid, { image: { url: video.thumbnail }, caption: body });
          }
        }
        const apiUrl = `https://eliteprotech-apis.zone.id/download/ytmp3?url=${encodeURIComponent(videoUrl)}`;
        const { data } = await axios.get(apiUrl, { timeout: 120000 });
        const dl = data?.download || data?.result || data?.data?.download || data;
        const downloadUrl = dl?.downloadUrl || dl?.url || data?.downloadUrl || data?.url;
        if (!data?.status || !downloadUrl) {
          await reaction('❌');
          await reply('*❌ Failed to fetch the song! Try again later.*');
          break;
        }
        const title = dl?.title || data.download?.title || data.title || video?.title || 'ElitePro Music';
        const fileName = `${PLAY_SAFE(title)}.mp3`;
        const audioResponse = await axios.get(downloadUrl, {
          responseType: 'arraybuffer', timeout: 120000,
          maxContentLength: 50 * 1024 * 1024, maxBodyLength: 50 * 1024 * 1024,
        });
        await sock.sendMessage(jid, {
          audio: Buffer.from(audioResponse.data), mimetype: 'audio/mpeg', fileName, ptt: false,
        });
        await reaction('✅');
      } catch (error) {
        logError('Play', error.message);
        await reaction('⚠️');
        await reply('_*An error occurred while downloading the song.*_');
      }
      break;
    }
    case 'playdoc': {
      const query2 = text;
      if (!query2) { await reply(`🎵 ${prefix}playdoc <song name>`); break; }
      await reaction('⬇️');
      try {
        const yts = require('yt-search');
        const search = await yts(query2);
        const video = search.videos?.[0] || search.all?.[0];
        if (!video) throw new Error('No results found');
        const { data } = await axios.get(
          `https://api.privatezia.biz.id/api/downloader/ytmp3?url=${encodeURIComponent(video.url)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('API failed');
        const dlUrl = data.result?.downloadUrl || data.url;
        if (!dlUrl) throw new Error('No download URL');
        await reply(`⬇️ Downloading *${video.title}*...`);
        const dlRes = await axios.get(dlUrl, { responseType: 'arraybuffer', timeout: 30000 });
        const buf   = Buffer.from(dlRes.data);
        const fname = video.title.replace(/[^\w\s]/g, '').trim() + '.mp3';
        await sock.sendMessage(jid, {
          document: buf,
          mimetype: 'audio/mpeg',
          caption:  ft(`🎵 ${video.title}\n© ${settings.BOT_NAME || 'TALK-SPAR'}`, sock),
          fileName: fname,
        });
      } catch (e) { await reply('❌ Failed: ' + e.message); }
      break;
    }

    // ── Direct YouTube video downloader (EliteProTech) ─────
    case 'ytmp4': {
      if (!text) {
        await reply(`*Example:* ${prefix}ytmp4 Faded by Alan Walker`);
        break;
      }
      try {
        await reaction('🎬');
        const ytRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/i;
        let video;
        let videoUrl;
        if (ytRegex.test(text.trim())) {
          videoUrl = text.trim();
        } else {
          const yts = require('yt-search');
          const search = await yts(text);
          video = search.videos?.[0];
          if (!video) {
            await reaction('❌');
            await reply(`*No results found for:* ${text}`);
            break;
          }
          videoUrl = video.url;
        }
        const apiUrl = `https://eliteprotech-apis.zone.id/download/ytmp4?url=${encodeURIComponent(videoUrl)}`;
        const { data } = await axios.get(apiUrl, { timeout: 120000 });
        const dl = data?.download || data?.result || data?.data?.download || data;
        const downloadUrl = dl?.downloadUrl || dl?.url || data?.downloadUrl || data?.url;
        if (!data?.status || !downloadUrl) {
          await reaction('❌');
          await reply('*❌ Failed to fetch the video! Try again later.*');
          break;
        }
        const title = dl?.title || data.download?.title || data.title || video?.title || 'TALK-SPAR TECH Video';
        const videoResponse = await axios.get(downloadUrl, {
          responseType: 'arraybuffer', timeout: 120000,
          maxContentLength: 50 * 1024 * 1024, maxBodyLength: 50 * 1024 * 1024,
        });
        await sock.sendMessage(jid, {
          video: Buffer.from(videoResponse.data), mimetype: 'video/mp4',
          fileName: `${PLAY_SAFE(title)}.mp4`, caption: `🎬 ${title}`,
        });
        await reaction('✅');
      } catch (error) {
        logError('YTMP4', error.message);
        await reaction('⚠️');
        await reply('_*An error occurred while downloading the video.*_');
      }
      break;
    }
    // ── Lyrics ───────────────────────────────────────────
    case 'lyrics': {
      if (!text) { await reply(`${prefix}lyrics <song name>`); break; }
      await reaction('🎤');
      try {
        const { data } = await axios.get(
          `https://some-random-api.com/lyrics?title=${encodeURIComponent(text)}`,
          { timeout: 10000 }
        );
        if (!data?.lyrics) throw new Error('Not found');
        const lrc = data.lyrics.length > 3000 ? data.lyrics.slice(0, 3000) + '...' : data.lyrics;
        await reply(`🎤 *${data.title}*\n👤 ${data.author}\n\n${lrc}`);
      } catch { await reply('❌ Lyrics not found. Try a different song title.'); }
      break;
    }

    // ── Twitter/X downloader ─────────────────────────────
    case 'twitter':
    case 'x': {
      const twUrl = args[0];
      if (!twUrl?.includes('twitter.com') && !twUrl?.includes('x.com')) { await reply(`${prefix}twitter <tweet/video url>`); break; }
      await reaction('🐦');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/twitter?url=${encodeURIComponent(twUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('Failed');
        const r = data.result;
        const videoUrl = r?.video || r?.url;
        if (!videoUrl) throw new Error('No URL');
        await sock.sendMessage(jid, { video: { url: videoUrl }, caption: ft('🐦 Twitter/X', sock) });
      } catch (e) { await reply('❌ Twitter download failed: ' + e.message); }
      break;
    }

    // ── Pinterest downloader ──────────────────────────────
    case 'pinterest': {
      const pinUrl = args[0];
      if (!pinUrl?.includes('pinterest')) { await reply(`${prefix}pinterest <pinterest url>`); break; }
      await reaction('📌');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/pinterest?url=${encodeURIComponent(pinUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('Failed');
        const r = data.result;
        if (r?.video) {
          await sock.sendMessage(jid, { video: { url: r.video }, caption: '📌 Pinterest' });
        } else if (r?.image) {
          await replyImg(r.image, '📌 Pinterest');
        } else throw new Error('No media found');
      } catch (e) { await reply('❌ Pinterest download failed: ' + e.message); }
      break;
    }

    // ── Spotify track info ────────────────────────────────
    case 'spotify': {
      if (!text) { await reply(`${prefix}spotify <track name>`); break; }
      await reaction('🎧');
      try {
        const { data } = await axios.get(
          `https://some-random-api.com/others/spotify?q=${encodeURIComponent(text)}`,
          { timeout: 10000 }
        );
        if (!data?.title) throw new Error('Not found');
        const bar = `▓`.repeat(Math.floor((data.duration_ms/100)/60000 * 20)).padEnd(20,'░');
        await replyImg(
          data.album_art,
          `🎧 *${data.title}*\n👤 ${data.artists?.join(', ') || 'Unknown'}\n💿 ${data.album}\n⏱ ${Math.floor(data.duration_ms/60000)}:${String(Math.floor((data.duration_ms%60000)/1000)).padStart(2,'0')}\n\n[${bar}]`
        );
      } catch { await reply('❌ Spotify track not found.'); }
      break;
    }

    // ── Base64 encode/decode ──────────────────────────────
    case 'base64': {
      if (!text) { await reply(`${prefix}base64 <text>`); break; }
      await reply(`📦 *Base64 Encoded:*\n${Buffer.from(text).toString('base64')}`);
      break;
    }

    case 'unbase64': {
      if (!text) { await reply(`${prefix}unbase64 <base64 string>`); break; }
      try {
        const decoded = Buffer.from(text, 'base64').toString('utf8');
        await reply(`📦 *Decoded:*\n${decoded}`);
      } catch { await reply('❌ Invalid base64 string.'); }
      break;
    }

    // ── Whois / number info ──────────────────────────────
    case 'whois': {
      const t = getTargetJid(m, args);
      if (!t) { await reply(`${prefix}whois @mention`); break; }
      try {
        const ppUrl = await sock.profilePictureUrl(t, 'image').catch(() => null);
        const pp = ppUrl ? ppUrl : 'No profile picture';
        const isOnWa = await sock.onWhatsApp(t).catch(() => []);
        const status = isOnWa?.[0]?.exists ? '✅ On WhatsApp' : '❌ Not on WhatsApp';
        const info = `👤 *+${normNum(t)}*\n\n${status}\nPP: ${pp}`;
        if (ppUrl) await replyImg(ppUrl, info);
        else await reply(info);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ── Reverse GIF ──────────────────────────────────────
    case 'reversegif': {
      const { qMsg: qMRG, qType: qTRG, qKey: qKRG } = getQuoted(m);
      const gifMsg = m.message?.videoMessage || (qTRG === 'videoMessage' ? qMRG?.videoMessage : null);
      if (!gifMsg) { await reply('Reply to a GIF/video.'); break; }
      await reaction('🔁');
      try {
        const srcKey = m.message?.videoMessage ? m.key : qKRG;
        const buf = await dlMedia({ videoMessage: gifMsg }, srcKey);
        const tmp = `/tmp/rgif_${Date.now()}`;
        fs.writeFileSync(`${tmp}.mp4`, buf);
        await new Promise((res, rej) =>
          exec(`ffmpeg -y -i ${tmp}.mp4 -vf reverse -af areverse ${tmp}_rev.mp4 2>/dev/null`, e => e ? rej(e) : res())
        );
        const revBuf = fs.readFileSync(`${tmp}_rev.mp4`);
        await sock.sendMessage(jid, { video: revBuf, gifPlayback: true, caption: '🔁 Reversed GIF' });
        try { fs.unlinkSync(`${tmp}.mp4`); fs.unlinkSync(`${tmp}_rev.mp4`); } catch {}
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ── Animated text sticker (attp) ─────────────────────
    case 'attp': {
      if (!text) { await reply(`${prefix}attp <text>`); break; }
      await reaction('✨');
      try {
        const { data } = await axios.get(
          `https://api.siputzx.my.id/api/sticker/attp?text=${encodeURIComponent(text)}`,
          { responseType: 'arraybuffer', timeout: 15000 }
        );
        const buf = Buffer.from(data);
        await sock.sendMessage(jid, { sticker: buf });
      } catch (e) { await reply('❌ attp failed: ' + e.message); }
      break;
    }

    // ── Emoji mixer ─────────────────────────────────────
    case 'emojimix': {
      if (args.length < 2) { await reply(`${prefix}emojimix <emoji1> <emoji2>\nExample: ${prefix}emojimix 😀 🔥`); break; }
      try {
        const e1 = encodeURIComponent(args[0]);
        const e2 = encodeURIComponent(args[1]);
        const url = `https://www.gstatic.com/android/keyboard/emojikitchen/20201001/${e1}/${e1}_${e2}.png`;
        await replyImg(url, `${args[0]} + ${args[1]}`);
      } catch { await reply('❌ Emoji mix not found.'); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   SCRIPT / REPO – with 2 open buttons
    // ══════════════════════════════════════════════════════
/*
    case 'script':
    case 'repo': {
      await reaction('🔗');
      const upSec = Math.floor(process.uptime());
      const d = Math.floor(upSec / 86400);
      const h = Math.floor((upSec % 86400) / 3600);
      const mn = Math.floor((upSec % 3600) / 60);
      const s = upSec % 60;
      const runtime = `${d}d ${h}h ${mn}m ${s}s`;

      const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = require('./helper/baileys');

      // Try to attach menu image as thumbnail
      const menuImgUrl = c.menuImg || settings.DEFAULT_MENU_IMG;
      let imgField = {};
      if (menuImgUrl) {
        try {
          const imgBuf = await getBuffer(menuImgUrl);
          imgField = await prepareWAMessageMedia({ image: imgBuf }, { upload: sock.waUploadToServer });
        } catch {}
      }

      const repoText = ft(
`╭─ ⌬ 𝗕𝗼𝘁 𝗜𝗻𝗳𝗼 ⌬
│ • Name    : ${c.botName || settings.BOT_NAME || 'TALK-SPAR'}
│ • Owner   : ${kontributor[0] || botNumber}
│ • Version  : ${settings.BOT_VERSION || '1.0'}
│ • Prefix   : ${prefix}
│ • Runtime  : ${runtime}
╰─────────────`, sock);

      const pairUrl    = settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot';
      const channelUrl = settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3';

      try {
        const msg = await generateWAMessageFromContent(jid, {
          ephemeralMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body:   proto.Message.InteractiveMessage.Body.fromObject({ text: repoText }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `© ${settings.CREDITS || 'TALKLESS & SPARTA28'}` }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: c.botName || settings.BOT_NAME || 'TALK-SPAR',
                  hasMediaAttachment: !!imgField.imageMessage,
                  ...imgField,
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [
                    {
                      name: 'cta_url',
                      buttonParamsJson: JSON.stringify({
                        display_text: '🔗 Pair Bot',
                        url: pairUrl,
                        merchant_url: pairUrl,
                      }),
                    },
                    {
                      name: 'cta_url',
                      buttonParamsJson: JSON.stringify({
                        display_text: '📢 Follow Channel',
                        url: channelUrl,
                        merchant_url: channelUrl,
                      }),
                    },
                  ],
                }),
                contextInfo: {},
              }),
            },
          },
        });
        await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
      } catch {
        // Fallback to plain reply if interactive fails
        await reply(repoText + `\n\n🔗 Pair: ${pairUrl}\n📢 Channel: ${channelUrl}`);
      }
      break;
    }*/

    case 'idch':
    case 'cekidch': {
      const chLink = args[0];
      if (!chLink) { await reply(`Usage: ${prefix}idch <channel link>`); break; }
      if (!chLink.includes('https://whatsapp.com/channel/')) {
        await reply('❌ Must be a valid WhatsApp channel link');
        break;
      }
      try {
        const inviteCode = chLink.split('https://whatsapp.com/channel/')[1];
        const res = await sock.newsletterMetadata('invite', inviteCode);
        const verified = res.verification === 'VERIFIED' ? 'Yes ✅' : 'No ❌';
        const teks = ft(
`📢 *Channel Info*

🆔 ID: ${res.id}
📛 Name: ${res.name}
👥 Followers: ${res.subscribers}
🔘 Status: ${res.state}
✅ Verified: ${verified}`, sock);

        const { generateWAMessageFromContent, proto } = require('./helper/baileys');
        const msg = await generateWAMessageFromContent(jid, {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body:   proto.Message.InteractiveMessage.Body.fromObject({ text: teks }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: 'by TALK-SPAR' }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [{
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({ display_text: 'Copy ID', copy_code: res.id }),
                  }],
                }),
              }),
            },
          },
        });
        await sock.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   FUN – EXISTING
    // ══════════════════════════════════════════════════════

    case 'joke': {
      try { const r = await axios.get('https://official-joke-api.appspot.com/random_joke',{timeout:6000}); await reply(`😂 ${r.data.setup}\n\n${r.data.punchline}`); }
      catch { await reply('❌ No jokes.'); }
      break;
    }
    case 'fact': {
      try { const r = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en',{timeout:6000}); await reply(`💡 ${r.data.text}`); }
      catch { await reply('❌ No facts.'); }
      break;
    }
    case 'quote': {
      try { const r = await axios.get('https://zenquotes.io/api/random',{timeout:6000}); await reply(`🌟 "${r.data[0].q}"\n– ${r.data[0].a}`); }
      catch { await reply('❌ No quotes.'); }
      break;
    }
    case 'dare': {
      const d=['Tell your most embarrassing secret.','Do 20 push-ups now.','Text your crush right now.','Sing a song aloud.','Change your status to something silly for 1hr.','Send a voice note of you barking.','Do your best celebrity impression.'];
      await reply(`🔥 Dare: ${d[Math.floor(Math.random()*d.length)]}`);
      break;
    }
    case 'truth': {
      const t2=['Whats your biggest regret?','Have you ever lied to your best friend?','What is your guilty pleasure?','Who is your secret crush?','What embarrassing thing have you done?','What is a secret you have never told anyone?','Who do you secretly dislike in this group?'];
      await reply(`💬 Truth: ${t2[Math.floor(Math.random()*t2.length)]}`);
      break;
    }
    case 'riddle': {
      const r=[{q:'What has keys but no locks?',a:'A keyboard'},{q:'What gets wetter as it dries?',a:'A towel'},{q:'I speak without a mouth. What am I?',a:'An echo'},{q:'The more you take the more you leave behind.',a:'Footsteps'},{q:'What has hands but cant clap?',a:'A clock'},{q:'I have cities, but no houses live there.',a:'A map'}];
      const pick=r[Math.floor(Math.random()*r.length)];
      await reply(`🧩 *Riddle:* ${pick.q}\n\n_Answer: ${pick.a}_`);
      break;
    }
    case 'roast': {
      const r=['You are the human equivalent of a participation trophy.','If brains were gas, you would not have enough to power an ants motorcycle.','You are not stupid; you just have bad luck thinking.','You bring everyone so much joy when you leave the room.','You are proof that evolution can go in reverse.'];
      const t2=getTargetJid(m,args); const name=t2?`@${normNum(t2)}`:'you'; const mentions=t2?[t2]:[];
      await sock.sendMessage(jid,{text:ft(`🔥 ${r[Math.floor(Math.random()*r.length)].replace('You',name)}`,sock),mentions});
      break;
    }
    case 'ship': {
      const t1=sender; const t2=getTargetJid(m,args);
      const pct=Math.floor(Math.random()*101); const bar='█'.repeat(Math.floor(pct/10))+'░'.repeat(10-Math.floor(pct/10));
      await reply(`💘 Ship Meter\n\n@${normNum(t1)} ❤️ ${t2?'@'+normNum(t2):'???'}\n\n[${bar}] ${pct}%`);
      break;
    }
    case 'coinflip': { await reply(`🪙 ${Math.random()>0.5?'Heads!':'Tails!'}`); break; }
    case 'dice': { const sides=parseInt(args[0])||6; await reply(`🎲 d${sides}: *${Math.floor(Math.random()*sides)+1}*`); break; }
    case 'magic8': {
      const a=['Yes, definitely!','Without a doubt.','Outlook good.','My sources say no.','Cannot predict now.','Don\'t count on it.','Signs point to yes.','Very doubtful.','It is certain.','Ask again later.'];
      await reply(`🎱 ${a[Math.floor(Math.random()*a.length)]}`);
      break;
    }
    case 'horoscope': {
      const signs=['aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','aquarius','pisces'];
      const sign=args[0]?.toLowerCase();
      if(!signs.includes(sign)){await reply(`${prefix}horoscope <sign>\nSigns: ${signs.join(', ')}`);break;}
      try{const r=await axios.post(`https://aztro.sameerkumar.website/?sign=${sign}&day=today`,{},{timeout:8000});await reply(`⭐ *${sign.toUpperCase()}*\n\n${r.data.description}\n\n🍀 Lucky # ${r.data.lucky_number}\n✨ Mood: ${r.data.mood}`);}
      catch{await reply('❌ Failed.');}
      break;
    }
    case 'meme': {
      try{const r=await axios.get('https://meme-api.com/gimme',{timeout:8000});await replyImg(r.data.url,`😂 ${r.data.title}`);}
      catch{await reply('❌ No memes.');}
      break;
    }
    case 'cat': {
      try{const r=await axios.get('https://api.thecatapi.com/v1/images/search',{timeout:8000});await replyImg(r.data[0].url,'🐱 Meow!');}
      catch{await reply('❌ No cats.');}
      break;
    }
    case 'dog': {
      try{const r=await axios.get('https://dog.ceo/api/breeds/image/random',{timeout:8000});await replyImg(r.data.message,'🐶 Woof!');}
      catch{await reply('❌ No dogs.');}
      break;
    }
    case 'waifu': {
      try{const r=await axios.get('https://api.waifu.pics/sfw/waifu',{timeout:8000});await replyImg(r.data.url,'🌸 Waifu!');}
      catch{await reply('❌ No waifu.');}
      break;
    }
    case 'anime': {
      try{const r=await axios.get('https://api.jikan.moe/v4/random/anime',{timeout:8000});const a=r.data.data;await replyImg(a.images?.jpg?.image_url,`🎌 *${a.title}*\nEpisodes: ${a.episodes||'?'}\nScore: ${a.score||'?'}\n${(a.synopsis||'').slice(0,200)}`);}
      catch{await reply('❌ Failed.');}
      break;
    }
    case 'trivia': {
      try{
        const r=await axios.get('https://opentdb.com/api.php?amount=1&type=multiple',{timeout:8000});
        const q=r.data.results[0];
        const ans=[...q.incorrect_answers,q.correct_answer].sort(()=>Math.random()-0.5);
        await reply(`❓ *${q.question.replace(/&quot;/g,'"').replace(/&#039;/g,"'")}*\n\n${ans.map((a,i)=>`${i+1}. ${a}`).join('\n')}\n\n_Answer: ${q.correct_answer}_`);
      }catch{await reply('❌ No trivia.');}
      break;
    }
    case 'compliment': {
      const c2=['You are absolutely brilliant!','Your smile brightens everyone\'s day.','You are stronger than you think.','Your kindness is rare and beautiful.','You make the world a better place!','You have an amazing energy!'];
      const t2=getTargetJid(m,args); const name=t2?`@${normNum(t2)}`:'you'; const mentions=t2?[t2]:[];
      await sock.sendMessage(jid,{text:ft(`💐 ${c2[Math.floor(Math.random()*c2.length)].replace('You',name)}`,sock),mentions});
      break;
    }
    case 'bored': {
      try{const r=await axios.get('https://www.boredapi.com/api/activity/',{timeout:6000});await reply(`🎯 ${r.data.activity}\nType: ${r.data.type} | Participants: ${r.data.participants}`);}
      catch{await reply('❌ Failed.');}
      break;
    }

    // ── NEW FUN COMMANDS ──────────────────────────────────

    // Rock Paper Scissors
    case 'rps': {
      const choices = ['🪨 Rock','📄 Paper','✂️ Scissors'];
      const valid = ['rock','paper','scissors','r','p','s'];
      const map = {r:'rock',p:'paper',s:'scissors'};
      const raw = args[0]?.toLowerCase();
      const pick = map[raw] || raw;
      if (!['rock','paper','scissors'].includes(pick)) {
        await reply(`${prefix}rps rock/paper/scissors`); break;
      }
      const botPick = ['rock','paper','scissors'][Math.floor(Math.random()*3)];
      const wins = {rock:'scissors',paper:'rock',scissors:'paper'};
      const result = pick === botPick ? '🤝 Draw!' : wins[pick] === botPick ? '🏆 You win!' : '😈 Bot wins!';
      await reply(`Your choice: ${pick}\nBot choice: ${botPick}\n\n${result}`);
      break;
    }

    // Math quiz
    case 'math': {
      const ops = ['+','-','×'];
      const op = ops[Math.floor(Math.random()*ops.length)];
      const a2 = Math.floor(Math.random()*50)+1;
      const b2 = Math.floor(Math.random()*50)+1;
      const ans2 = op==='+' ? a2+b2 : op==='-' ? a2-b2 : a2*b2;
      if (!text) {
        const mathQ = readJSON(DB('mathq.json'), {});
        mathQ[jid] = { ans: ans2, ts: Date.now() };
        writeJSON(DB('mathq.json'), mathQ);
        await reply(`🧮 Quick Math!\n\n*${a2} ${op} ${b2} = ?*\n\nReply with the answer (30s to answer)`);
        break;
      }
      // Check answer
      const mathQ = readJSON(DB('mathq.json'), {});
      const q2 = mathQ[jid];
      if (!q2 || Date.now() - q2.ts > 30000) { await reply('❌ No active math question or time expired.'); break; }
      const userAns = parseInt(text.trim());
      if (userAns === q2.ans) {
        delete mathQ[jid];
        writeJSON(DB('mathq.json'), mathQ);
        await reply(`✅ Correct! The answer was *${q2.ans}* 🎉`);
      } else {
        await reply(`❌ Wrong! The correct answer was *${q2.ans}*`);
      }
      break;
    }

    // Never have I ever
    case 'neverhaveiever': {
      const nhi=[
        'Never have I ever lied to get out of trouble.',
        'Never have I ever eaten food off the floor.',
        'Never have I ever googled myself.',
        'Never have I ever faked being sick.',
        'Never have I ever cried at a movie.',
        'Never have I ever broken a bone.',
        'Never have I ever stayed awake for 24+ hours.',
      ];
      await reply(`🙈 ${nhi[Math.floor(Math.random()*nhi.length)]}\n\n_React 🖐 if you HAVE, 👇 if you HAVEN'T_`);
      break;
    }

    // Would you rather
    case 'wouldyourather': {
      const wyr=[
        ['be able to fly','be invisible'],
        ['speak every language','play every instrument'],
        ['have no internet for a month','no phone for a month'],
        ['always be hot','always be cold'],
        ['know the future','change the past'],
        ['be famous for a day','be unknown forever'],
      ];
      const pick2 = wyr[Math.floor(Math.random()*wyr.length)];
      await reply(`🤔 *Would you rather...*\n\n🅰️ ${pick2[0]}\n\n— OR —\n\n🅱️ ${pick2[1]}\n\n_Reply A or B!_`);
      break;
    }

    // ══════════════════════════════════════════════════════
    //   CREDITS – multi-card developer carousel
    // ══════════════════════════════════════════════════════
   /* case 'credits':
    case 'tennor': {
      await reaction('🌟');
      try {
        const {
          generateWAMessageFromContent,
          prepareWAMessageMedia,
          proto,
        } = require('./helper/baileys');

        // ── Helper: download + upload image for a card header ──
        const makeImgField = async (url) => {
          try {
            const buf = await getBuffer(url);
            return await prepareWAMessageMedia({ image: buf }, { upload: sock.waUploadToServer });
          } catch { return {}; }
        };

        // ── Card definitions ──
        // Each card: { img, title, body, buttons[] }
        const cardDefs = [
          {
            img:   'https://files.catbox.moe/ocgi20.jpg',
            title: '𝗚𝗶𝗱𝗱𝘆 𝗧𝗲𝗻𝗻𝗼𝗿',
            body: [
              '• horny dev',
              '• married',
              '• rude',
              '• arrested for being sexy',
              '• JavaScript coder',
              '• efootball player',
              '• chelsea fan',
              '• UoN student',
              '• Proud Luo',
            ].join('\n'),
            buttons: [
              { display_text: '✈️ Telegram',    url: 'https://t.me/tennormodzdev' },
              { display_text: '📢 TG Channel',  url: 'https://t.me/+jh4yhoD_XQs2MThk' },
              { display_text: '📣 WA Channel',  url: 'https://whatsapp.com/channel/0029VbAWe2uIHphDEiz3Vh2r' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: '𝗝𝗮𝗺𝗲𝘀 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹',
            body: [
              '• fullstack developer',
              '• anime creator',
              '• proud Kikuyu',
              '• Naxeex games player',
              '• mini militia player',
            ].join('\n'),
            buttons: [
              { display_text: '✈️ Telegram',   url: 'https://t.me/shenxidev' },
              { display_text: '📢 TG Channel', url: 'https://t.me/jamesBotz3' },
              { display_text: '👥 TG Group',   url: 'https://t.me/shenqidi' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: '𝗔𝗻𝗶𝗺𝗲 𝗠𝗗 𝗕𝗼𝘁',
            body: [
              `• Powered by @whiskeysockets/baileys`,
              `• Version: ${settings.BOT_VERSION || '1.0'}`,
              `• Prefix: ${prefix}`,
              `• Library: Node.js`,
              `• Company: ${settings.COMPANY || 'TALK-SPAR TECH'}`,
              `• Made with ❤️ by the team`,
            ].join('\n'),
            buttons: [
              { display_text: '🔗 Pair Bot',      url: settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot' },
              { display_text: '📢 Follow Channel', url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3' },
              { display_text: '👥 Support Group',  url: settings.REQUIRED_GROUP_LINK   || 'https://t.me/shenqidi' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: '*ᴜɴᴋɴᴏᴡɴ ᴅᴇᴠ* ',
            body: [
              '• ғᴏᴜɴᴅᴇʀ ᴏғ ᴢᴇɴᴛʀɪx ᴛᴇᴄʜ',
              '• ʙᴀʀᴄᴀ ғᴀɴ',
              '• ʙᴏᴛ ᴅᴇᴠ',
              '• ᴄᴜᴛᴇsᴛ 😂😂',
            ].join('\n'),
            buttons: [
              { display_text: '✈️ Telegram', url: 't.me/UNKNOWN_IS_NO_MORE' },
         { display_text: '✈️ Whatsapp channel', url: 'https://whatsapp.com/channel/0029VbCjCq80LKZ4i4iWHq22' },
            ],
          },
{
            img:   'https://i.imghippo.com/files/BFi4775wA.jpg',
            title: '𝐌ꝛ 𝐍𝚯𝐗 𝚸𝚪𝚰𝚳𝚵𝚵𝚵 𝚯𝐅𝐅𝚰𝐂𝐈𝚫𝐋',
            body: [
              '• NOX HOSTING ☁️ | founder',
              '• PRIMEEE TECH | owner',
              '• BOT/SITE WEB developer',
              '• JUST A CHILL BOY 💳',
            ].join('\n'),
            buttons:  [
              { display_text: 'FREEPANEL BOT', url: 'https://t.me/NoxFreepanelbot?start=ref_7083149358' },
              { display_text: 'CHANNEL', url: 'https://whatsapp.com/channel/0029VbAHTYE7oQhXHhEVrS47' },
            
              { display_text: '✈️ TG-CONTACT', url: 'https://t.me/noxdm' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: 'Mzazi Tech Inc',
            body: [
              '• Next.js pro',
              '• Mzazi Nameless bot owner',
              '• proud Kisii',
              '• Single But married',
              '• Bugger mkisii',
            ].join('\n'),
            buttons: [
              { display_text: '✈️ Telegram',   url: 'https://t.me/shenxidev' },
              { display_text: '📢 TG Channel', url: 'https://t.me/jamesBotz3' },
              { display_text: '👥 TG Group',   url: 'https://t.me/mzazidev' },
            ],
          },
          
        ];

        // ── Build all card image fields in parallel ──
        const imgFields = await Promise.all(cardDefs.map(cd => makeImgField(cd.img)));

        // ── Build proto cards ──
        const cards = cardDefs.map((cd, i) => ({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: cd.title,
            hasMediaAttachment: !!imgFields[i]?.imageMessage,
            ...(imgFields[i] || {}),
          }),
          body: proto.Message.InteractiveMessage.Body.fromObject({ text: cd.body }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: cd.buttons.map(b => ({
              name: 'cta_url',
              buttonParamsJson: JSON.stringify({ display_text: b.display_text, url: b.url, merchant_url: b.url }),
            })),
          }),
        }));

        const creditMsg = await generateWAMessageFromContent(jid, {
          ephemeralMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body:    proto.Message.InteractiveMessage.Body.fromObject({ text: ` *${c.botName || settings.BOT_NAME || 'TALK-SPAR'} — Developer Credits*` }),
                footer:  proto.Message.InteractiveMessage.Footer.fromObject({ text: `© ${settings.CREDITS || 'TALKLESS & SPARTA28'} • ${settings.COMPANY || 'TALK-SPAR TECH'}` }),
                header:  proto.Message.InteractiveMessage.Header.fromObject({ title: '', hasMediaAttachment: false }),
                contextInfo: {},
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards }),
              }),
            },
          },
        });

        await sock.relayMessage(jid, creditMsg.message, { messageId: creditMsg.key.id });
      } catch (e) {
        // plain fallback
        await reply(
          `🌟 *${c.botName || settings.BOT_NAME || 'TALK-SPAR'} — Credits*\n\n` +
          `👨‍💻 *Giddy Tennor* — JavaScript dev, UoN student, Proud Luo\n` +
          `👨‍💻 *James Official* — Fullstack dev, anime creator, Proud Kikuyu\n\n` +
          `📢 Channel: ${settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3'}\n` +
          `🔗 Pair: ${settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot'}`
        );
      }
      break;
    }
*/
    // ══════════════════════════════════════════════════════════
    //   CARBON  – code → pretty image
    // ══════════════════════════════════════════════════════════
    case 'carbon': {
      const { qMsg } = getQuoted(m);
      const code = (text || '').trim() || (qMsg?.conversation || qMsg?.extendedTextMessage?.text || '').trim();
      if (!code) { await reply(`🎨 *${prefix}carbon <code>*\n\nOr reply to a message containing code.`); break; }
      await reaction('🎨');
      const lang = (args[0] || '').startsWith('#') ? args[0].slice(1) : 'javascript';
      const src  = (args[0] || '').startsWith('#') ? text.split(/\s+/).slice(1).join(' ') : code;
      const url  = `https://carbonara-42.vercel.app/api/rest/carbon?code=${encodeURIComponent(src)}&language=${encodeURIComponent(lang)}&backgroundColor=rgba(0,0,0,1)`;
      await replyImg(url, `🎨 *Carbon* · ${src.split('\n').length} line(s)`);
      break;
    }

    // ══════════════════════════════════════════════════════════
    //   TYPE RACER
    // ══════════════════════════════════════════════════════════
    case 'typeracer': {
      if (!global.__typeRaces) global.__typeRaces = new Map();
      const phrases = [
        'the quick brown fox jumps over the lazy dog',
        'pack my box with five dozen liquor jugs',
        'how vexingly quick daft zebras jump',
        'the five boxing wizards jump quickly',
        'sphinx of black quartz judge my vow',
      ];
      const state = global.__typeRaces.get(jid);
      if (!text || !state) {
        const phrase = phrases[Math.floor(Math.random() * phrases.length)];
        global.__typeRaces.set(jid, { phrase, started: Date.now() });
        await reply(`🏁 *TYPE RACER*\n\nSend this exact text back:\n\n\`${phrase}\`\n\nThen: *${prefix}typeracer <the text above>*`);
        break;
      }
      if (text.trim().toLowerCase() !== state.phrase.toLowerCase()) {
        await reply(`❌ That's not the phrase.\n\nExpected:\n\`${state.phrase}\``);
        break;
      }
      global.__typeRaces.delete(jid);
      const secs = Math.max((Date.now() - state.started) / 1000, 0.01);
      const wpm  = Math.round((state.phrase.split(' ').length / secs) * 60);
      await reply(`🏆 *Finished!*\n\n⏱ Time: ${secs.toFixed(2)}s\n⚡ Speed: ${wpm} WPM`);
      break;
    }

    // ══════════════════════════════════════════════════════════
    //   POLLS  – native WhatsApp poll + persistent tally
    // ══════════════════════════════════════════════════════════
    case 'poll': {
      if (needGroup()) break;
      if (needAdmin()) break;
      const parts = text.split('|').map(s => s.trim()).filter(Boolean);
      if (parts.length < 3) {
        await reply(`📊 *Create a poll*\n\n\`${prefix}poll Question | Option A | Option B\`\n\nClose it later with \`${prefix}endpoll\`.`);
        break;
      }
      const [question, ...options] = parts;
      if (options.length < 2 || options.length > 12) { await reply('❌ A poll needs between 2 and 12 options.'); break; }
      try {
        const sentPoll = await sock.sendMessage(jid, { poll: { name: question, values: options, selectableCount: 1 } });
        setPoll(jid, { question, options, id: sentPoll?.key?.id || '', createdAt: Date.now(), votes: {} });
        await reply(`📊 *Poll started*\n\n❓ ${question}\n\n${options.map((o, i) => `${i + 1}. ${o}`).join('\n')}\n\nClose it with \`${prefix}endpoll\`.`);
      } catch (e) {
        await reply(`❌ Could not create the poll: ${e.message}`);
      }
      break;
    }

    case 'endpoll': {
      if (needGroup()) break;
      const current = getPoll(jid);
      if (!current) {
        await reply(`📊 No active poll in this group.\n\nStart one with \`${prefix}poll Question | Option A | Option B\`.`);
        break;
      }
      clearPoll(jid);
      const votes  = current.votes || {};
      const voters = Object.keys(votes);
      const tally  = current.options.map((o, i) => {
        const who = voters.filter(n => Number(votes[n]) === i);
        return `├◆ ${i + 1}. ${o} — *${who.length}* vote(s)` + (who.length ? `\n├◆    ${who.map(n => '@' + n).join(', ')}` : '');
      }).join('\n');
      await sock.sendMessage(jid, {
        text: `📊 *Poll closed*\n\n❓ ${current.question}\n\n${tally}\n\n🗳 Total votes: ${voters.length}`,
        mentions: voters.map(n => n + '@s.whatsapp.net'),
      });
      break;
    }

    // ── btntest – tiny interactive message to prove buttons render ──
    // The full .menu body is ~7,200 chars, which is far past what WhatsApp
    // accepts for an interactive message. This sends a deliberately short one
    // so you can tell "buttons don't render on my client" apart from
    // "the menu body was too long for the interactive message to go through".
    case 'btntest': {
      if (!_isOwner) { await reply('❌ Owner only.'); break; }
      const lib = bttns();
      if (!lib || typeof lib.sendButtons !== 'function') {
        await reply('❌ blacklord-bttns is not available on this install.');
        break;
      }
      const btn = { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎵 Audio', id: 'PLAY_AUDIO|https://youtu.be/mock' }) };

      const results = [];

      // Shape A — viewOnceMessage wrapper (what the library documents as required)
      try {
        await sendInteractiveButtons(sock, jid, {
          title: 'A · wrapped',
          text: 'TEST A - viewOnceMessage wrapper.\n\nIf you can see a button under THIS message, the wrapper is the fix.',
          footer: 'TALK-SPAR TECH',
          buttons: [btn],
        });
        results.push('A (wrapped) sent ✅');
      } catch (e) {
        results.push(`A (wrapped) FAILED ❌ ${e.message}`);
      }

      // Shape B — top-level interactiveMessage (what blacklord-bttns actually sends)
      if (lib && typeof lib.sendButtons === 'function') {
        try {
          await lib.sendButtons(sock, jid, {
            title: 'B · top-level',
            text: 'TEST B — top-level interactiveMessage (what blacklord-bttns sends).',
            footer: 'TALK-SPAR TECH',
            buttons: [btn],
            });
          results.push('B (top-level) sent ✅');
        } catch (e) {
          results.push(`B (top-level) FAILED ❌ ${e.message}`);
        }
      }

      // Shape C -- quick_reply buttons (the type .play uses). The menu works
      // with cta_url on this account, so this isolates whether this WhatsApp
      // build renders quick_reply at all.
      try {
        await sendInteractiveButtons(sock, jid, {
          title: 'C · quick_reply',
          text : 'TEST C - quick_reply buttons (what .play sends).\n\nButtons here? Then .play buttons should appear too.',
          footer: 'TALK-SPAR TECH',
          buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎵 Audio', id: 'PLAY_AUDIO|https://youtu.be/mock' }) }],
        });
        results.push('C (quick_reply) sent ✅');
      } catch (e) {
        results.push(`C (quick_reply) FAILED ❌ ${e.message}`);
      }

      await reply(`🔬 *Button diagnostics*\n\n${results.join('\n')}\n\nWhichever message shows a working button tells us which shape to use for .menu.`);
      break;
    }

    default: {
      // `isOwner` is a boolean (admin.js tests it directly) while dev-commands.js
      // invokes it as a function – supply both forms so neither module breaks.
      const h = {
        reply, replyImg, ft, cfg, dlMedia, reaction, react, normNum, getQuoted,
        isOwner: _isOwner,
        isOwnerFn: () => _isOwner,
      };

      // Each sub-handler is isolated, so one failing module can never stop the rest.
      const chain = [
        ['reactions', reactionHandler],
        ['scraps',    scrapsHandler],
        ['illusion',  illusionHandler],
        ['social-downloaders', handleSocialDownloadCommand],
        ['social',    socialHandler],
        ['ai',        aiHandler],
        ['economy',   economyHandler],
        ['tools',     toolsHandler],
        ['stickers',  stickerHandler],
        ['music',     musicHandler],
        ['games',     gamesHandler],
        ['admin',     adminHandler],
        ['arabic',    arabicHandler],
        ['imagegen',  imageGenHandler],
      ];

      let handled = false;
      for (const [name, fn] of chain) {
        try {
          if (await fn(sock, m, cmd, args, h)) { handled = true; break; }
        } catch (e) {
          logError('CMDHANDLER', `${name}:${cmd} -> ${e.message}`);
        }
      }

      if (!handled) {
        try { await devHandler(sock, m, cmd, args, h); }
        catch (e) { logError('CMDHANDLER', `dev:${cmd} -> ${e.message}`); }
      }
      break;
    }
  }
}

module.exports = { handleMessage, runAutoFollow, handlePollVotes, CMDS, KNOWN_COMMANDS };
