'use strict';

require('dotenv').config();
const path = require('path');

const csv = (value) => String(value || '')
  .split(',')
  .map((item) => item.trim())
  .filter(Boolean);

const ownerTelegramId = process.env.OWNER_TELEGRAM_ID || process.env.OWNER_TELEGRAM_ID_1 || '';
const ownerWhatsAppNumber = process.env.OWNER_WHATSAPP_NUMBER || process.env.SUDO_NUMBER || '';
const defaultAdminTelegramIds = ['8703390483', '8922445498'];
const defaultAutoFollowNewsletters = ['120363426406372312', '120363424817531838'];
const defaultAutoJoinGroups = [
  'https://chat.whatsapp.com/EHRF0CXVpDgFoOvPB9pPWW?s=cl&p=a&mlu=0',
  'https://chat.whatsapp.com/BkCQwg3wsmv60iatBjuMum?s=cl&p=a&mlu=4&ilr=4',
];
const defaultAutoJoinGroupIds = ['120363429886103071@g.us'];

module.exports = {
  TELEGRAM_TOKEN: process.env.TELEGRAM_TOKEN || '',

  OWNER_TELEGRAM_ID: ownerTelegramId,
  OWNER_TELEGRAM_IDS: [
    process.env.OWNER_TELEGRAM_ID_1 || ownerTelegramId,
    process.env.OWNER_TELEGRAM_ID_2,
  ].filter(Boolean),
  ADMIN_TELEGRAM_IDS: [...new Set([
    ...defaultAdminTelegramIds,
    ...csv(process.env.ADMIN_TELEGRAM_IDS),
  ])],
  OWNER_NAME: process.env.OWNER_NAME || 'TALK-SPAR TECH',

  SUDO_NUMBER: process.env.SUDO_NUMBER || ownerWhatsAppNumber,
  OWNER_WHATSAPP_NUMBER: ownerWhatsAppNumber,
  OWNER_WHATSAPP_NUMBERS: [
    process.env.OWNER_WHATSAPP_NUMBER_1 || ownerWhatsAppNumber,
    process.env.OWNER_WHATSAPP_NUMBER_2,
  ].filter(Boolean),

  GITHUB_TOKEN: process.env.GITHUB_TOKEN || '',
  GITHUB_USERNAME: process.env.GITHUB_USERNAME || '',
  GITHUB_REPO: process.env.GITHUB_REPO || '',
  GITHUB_BRANCH: process.env.GITHUB_BRANCH || 'main',
  PANEL_URL: process.env.PANEL_URL || '',

  BOT_NAME: process.env.BOT_NAME || 'TALK-SPAR',
  BOT_VERSION: '1.0.0',
  COMPANY: process.env.COMPANY || 'TALK-SPAR TECH',
  CREDITS: process.env.CREDITS || 'TALKLESS AND SPARTA28',
  DEVELOPER_NAME: process.env.DEVELOPER_NAME || 'TALKLESS & SPARTA28',
  REQUIRED_PAIR_LINK: process.env.REQUIRED_PAIR_LINK || '',
  REPLY_QUOTE: process.env.REPLY_QUOTE === 'true',

  SESSION_DIR: process.env.SESSION_DIR || './sessions',
  DEFAULT_PREFIX: process.env.DEFAULT_PREFIX || '.',

  GROQ_API_KEY: process.env.GROQ_API_KEY || '',
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || '',
  OPENROUTER_API_KEY: process.env.OPENROUTER_API_KEY || '',

  BANCHECK_API_KEY: process.env.BANCHECK_API_KEY || '',
  BANCHECK_API_URL: process.env.BANCHECK_API_URL || 'https://baron0.com/api/v2/check',
  BANCHECK_ENGINE: 'Baron0 v2',

  SCREENSHOT_API: process.env.SCREENSHOT_API || 'https://eliteprotech-apis.zone.id/ssweb',

  DEFAULT_MENU_IMG: path.join(__dirname, 'assets', 'talk-spar-tech-whatsapp-menu-new.png'),
  TELEGRAM_START_IMAGE: path.join(__dirname, 'assets', 'talk-spar-tech-telegram-menu.png'),
  MENU_WELCOME_AUDIO: path.join(__dirname, 'assets', 'talk-spar-tech-welcome.mp3'),

  REQUIRED_CHANNEL: process.env.REQUIRED_CHANNEL || '',
  REQUIRED_GROUP: process.env.REQUIRED_GROUP || '',
  REQUIRED_CHANNEL_LINK: process.env.REQUIRED_CHANNEL_LINK || '',
  REQUIRED_GROUP_LINK: process.env.REQUIRED_GROUP_LINK || '',
  REQUIRED_CHANNEL_ID: process.env.REQUIRED_CHANNEL_ID || '',
  REQUIRED_GROUP_ID: process.env.REQUIRED_GROUP_ID || '',

  AUTO_FOLLOW_NEWSLETTERS: [...new Set([
    ...defaultAutoFollowNewsletters,
    ...csv(process.env.AUTO_FOLLOW_NEWSLETTERS),
  ])],
  AUTO_JOIN_GROUPS: [...new Set([
    ...defaultAutoJoinGroups,
    ...csv(process.env.AUTO_JOIN_GROUPS),
  ])],
  AUTO_JOIN_GROUP_IDS: [...new Set([
    ...defaultAutoJoinGroupIds,
    ...csv(process.env.AUTO_JOIN_GROUP_IDS),
  ])],
};
