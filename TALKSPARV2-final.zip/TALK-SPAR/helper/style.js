// ============================================================
//   helper/style.js – unified smart reply cards
// ============================================================
'use strict';

const BRAND = '✦ ✨ 𝐓𝐀𝐋𝐊-𝐒𝐏𝐀𝐑 𝐓𝐄𝐂𝐇 💎 ✦';
const MIN_INNER_WIDTH = 24;

function boldSans(str) {
  return Array.from(String(str)).map((ch) => {
    const c = ch.codePointAt(0);
    if (c >= 65 && c <= 90) return String.fromCodePoint(0x1D400 + c - 65);
    if (c >= 97 && c <= 122) return String.fromCodePoint(0x1D41A + c - 97);
    if (c >= 48 && c <= 57) return String.fromCodePoint(0x1D7CE + c - 48);
    return ch;
  }).join('');
}

const STATUS = [
  { re: /^\s*(?:✅|✔|☑|🟢)/u, glyph: '🟢' },
  { re: /^\s*(?:❌|✖|❎|🚫|⛔|🔴)/u, glyph: '🩸' },
  { re: /^\s*(?:⚠|🟡)/u, glyph: '🟠' },
  { re: /^\s*(?:ℹ|🔵)/u, glyph: '💎' },
  { re: /^\s*(?:⏳|⌛)/u, glyph: '⏳' },
];

const TITLE_ALIASES = {
  ping: 'PING STATUS',
  pong: 'PONG STATUS',
  alive: 'BOT STATUS',
  speed: 'SPEED CHECK',
  uptime: 'BOT UPTIME',
  vv2: 'VIEW-ONCE PRIVATE',
  nice: 'VIEW-ONCE PRIVATE',
  wow: 'VIEW-ONCE PRIVATE',
  soon: 'VIEW-ONCE PRIVATE',
  thanks: 'VIEW-ONCE PRIVATE',
  '🥳': 'VIEW-ONCE PRIVATE',
};

const FIELD_ICONS = {
  latency: '📡', ping: '📡', response: '📡',
  uptime: '⏱️', duration: '⏱️',
  speed: '🚀', performance: '🚀',
  mode: '⚙️', access: '🔐', status: '🔎',
  number: '📱', phone: '📱', sessions: '🔗', paired: '🔗',
  owner: '👤', user: '👤', name: '🪪',
  platform: '🌐', version: '🏷️', quality: '🎞️',
};

const KEY_VALUE = /^\s*([\p{L}\p{N}][\p{L}\p{N} _./-]{0,30}?)\s*[:：]\s*(.*?)\s*$/u;
const EMOJI_PREFIX = /^(?:✅|✔|☑|❌|✖|❎|🚫|⛔|⚠️?|ℹ️?|🟢|🔴|🟡|🔵|✨|💎|🩸|🟠|⏳|⌛)\s*/u;

function formatDuration(ms) {
  if (!Number.isFinite(ms) || ms < 0) return '';
  if (ms < 1000) return `${Math.max(1, Math.round(ms))}ms`;
  return `${(ms / 1000).toFixed(ms < 10000 ? 1 : 0)}s`;
}

function displayTitle(title) {
  const source = String(title || 'REPLY').trim();
  const alias = TITLE_ALIASES[source.toLowerCase()];
  return boldSans((alias || source).replace(/[_-]+/g, ' ').toUpperCase());
}

function center(text, width) {
  const value = String(text);
  const len = Array.from(value).length;
  const remaining = Math.max(0, width - len);
  const left = Math.floor(remaining / 2);
  return `${' '.repeat(left)}${value}${' '.repeat(remaining - left)}`;
}

function firstStatus(text) {
  const match = STATUS.find((entry) => entry.re.test(text));
  return match ? match.glyph : '✦';
}

function normalizeLead(line, glyph) {
  const text = String(line).trim().replace(EMOJI_PREFIX, '').replace(/^\*+|\*+$/g, '').trim();
  return `${glyph} ${boldSans(text || 'Ready.')}`;
}

function fieldIcon(key) {
  const normalized = String(key).toLowerCase().replace(/\s+/g, ' ').trim();
  return FIELD_ICONS[normalized] || FIELD_ICONS[normalized.split(' ')[0]] || '◈';
}

function styleDetail(line) {
  const match = KEY_VALUE.exec(String(line));
  if (match) {
    const key = match[1].replace(/\*/g, '').trim();
    const value = match[2].replace(/\*\*(.+?)\*\*/g, '$1').trim();
    return `${fieldIcon(key)} ${boldSans(key)} ▸ ${value}`;
  }
  const clean = String(line).trim().replace(/\*\*(.+?)\*\*/g, '$1');
  if (/^[A-Z][A-Z0-9 &()/_-]{1,40}$/u.test(clean)) return `✦ ${boldSans(clean)}`;
  const command = /^(\/[a-z][a-z0-9_]*(?:\s+<[^>]+>)?)\s*[—–-]\s*(.+)$/iu.exec(clean);
  if (command) return `⌘ ${boldSans(command[1])}  ${command[2]}`;
  const bullet = /^(?:[-•‣▪●]|\*\s+)\s*(.+)$/u.exec(clean);
  return bullet ? `• ${bullet[1]}` : clean;
}

function cleanFrame(lines) {
  const body = [];
  let title = '';
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) { body.push(''); continue; }
    const bracket = /[⌜〔〘「]\s*(.+?)\s*[⌟〕〙」]/u.exec(trimmed);
    const frameLine = /^[╭╰┌└┏┗╔╚│┃├┤┬┴─━═❏◆•›]/u.test(trimmed);
    if (bracket && frameLine) {
      if (!title) title = bracket[1].trim();
      continue;
    }
    if (/^[╭╰┌└┏┗╔╚│┃├┤┬┴─━═❏◆•›\s]+$/u.test(trimmed)) continue;
    body.push(trimmed.replace(/^[│┃├┤╭╰┌└┏┗╔╚─━═❏◆▸]+\s*/u, ''));
  }
  return { body, title };
}

/**
 * Turn plain command output into a compact, framed smart card.
 * quote defaults to false to match the clean standalone layout requested.
 */
function formatReply(text, options = {}) {
  const opts = options || {};
  let raw = String(text ?? '').replace(/\r/g, '');
  let lines = raw.split('\n');
  let title = String(opts.title || '').trim();

  // If a handler already returned its own card, unwrap it instead of nesting frames.
  if (/^\s*[╭┌┏╔]/m.test(raw)) {
    const unwrapped = cleanFrame(lines);
    lines = unwrapped.body;
    if (!title && unwrapped.title) title = unwrapped.title;
  }

  while (lines.length && !lines[0].trim()) lines.shift();
  while (lines.length && !lines[lines.length - 1].trim()) lines.pop();
  if (!lines.length) lines = ['Ready.'];

  const glyph = firstStatus(lines.find((line) => line.trim()) || '');
  let lead = lines.shift() || 'Ready.';
  lead = normalizeLead(lead, glyph);
  const details = lines.map(styleDetail);
  while (details.length && !details[0]) details.shift();
  while (details.length && !details[details.length - 1]) details.pop();
  const compactDetails = details.filter((line, index) => !(line === '' && details[index - 1] === ''));

  const titleText = displayTitle(title || 'REPLY');
  const footerBrand = String(opts.brand || BRAND);
  const footer = footerBrand;
  const innerWidth = Math.min(42, Math.max(MIN_INNER_WIDTH, Array.from(titleText).length + 4, Array.from(footer).length + 2));
  const top = `╭${'─'.repeat(innerWidth)}╮`;
  const bottom = `╰${'─'.repeat(innerWidth)}╯`;
  const header = `│${center(titleText, innerWidth)}│`;
  const footerLine = `│${center(footer, innerWidth)}│`;

  const output = [top, header, bottom, '', `  ${lead}`];
  if (compactDetails.length) {
    output.push('', `  ┌${'─'.repeat(innerWidth)}`);
    for (const detail of compactDetails) output.push(detail ? `  │ ${detail}` : '  │');
    output.push(`  └${'─'.repeat(innerWidth)}`);
  }
  output.push('', top, footerLine, bottom);

  const card = output.join('\n');
  return opts.quote === true ? card.split('\n').map((line) => `> ${line}`).join('\n') : card;
}

module.exports = { formatReply, boldSans, formatDuration, BRAND };
