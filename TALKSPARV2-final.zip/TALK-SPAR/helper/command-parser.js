'use strict';

const PREFIX_FREE_VIEW_ONCE_COMMANDS = new Set([
  'vv', 'vv2', 'waaah', 'nice', 'wow', 'soon', '🥳', 'thanks', '😂',
]);

/** Return a supported bare view-once alias, or null for ordinary text. */
function getPrefixFreeViewOnceCommand(body) {
  // Only exact standalone shortcuts are prefix-free; matching the first word
  // would hijack ordinary messages such as "wow nice" or "thanks!".
  const candidate = String(body ?? '').trim().toLowerCase();
  return PREFIX_FREE_VIEW_ONCE_COMMANDS.has(candidate) ? candidate : null;
}

module.exports = { PREFIX_FREE_VIEW_ONCE_COMMANDS, getPrefixFreeViewOnceCommand };
