'use strict';

// A single Node process can host many paired WhatsApp sessions. All of them
// may receive the same group message, so claim each inbound group message once
// before any bot-generated group response is sent.
const CLAIM_TTL = 45 * 1000;
const claims = global.__talkSparGroupResponseClaims || new Map();
global.__talkSparGroupResponseClaims = claims;

function claimGroupResponse(message, jid) {
  if (!jid?.endsWith('@g.us') || message?.key?.fromMe || !message?.key?.id) return true;
  const now = Date.now();
  for (const [key, at] of claims) {
    if (now - at > CLAIM_TTL) claims.delete(key);
  }
  const key = `${jid}:${message.key.id}`;
  if (claims.has(key)) return false;
  claims.set(key, now);
  return true;
}

module.exports = { claimGroupResponse };
