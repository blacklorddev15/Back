'use strict';

const BINARY_TAG = '__talksparRetryBinary';

function retryJsonReplacer(_key, value) {
  // Buffer.toJSON() runs before the replacer; preserve and tag its JSON form.
  if (value && value.type === 'Buffer' && Array.isArray(value.data)) {
    return { [BINARY_TAG]: 'Buffer', data: value.data };
  }
  if (value instanceof Uint8Array) {
    return { [BINARY_TAG]: 'Uint8Array', data: Array.from(value) };
  }
  if (value instanceof ArrayBuffer) {
    return { [BINARY_TAG]: 'Uint8Array', data: Array.from(new Uint8Array(value)) };
  }
  return value;
}

function reviveRetryValue(value) {
  if (Array.isArray(value)) return value.map(reviveRetryValue);
  if (!value || typeof value !== 'object') return value;

  const bytesType = value[BINARY_TAG];
  if (bytesType === 'Buffer') return Buffer.from(value.data || []);
  if (bytesType === 'Uint8Array') return Uint8Array.from(value.data || []);
  // Support older retry files written with plain JSON.stringify(Buffer).
  if (value.type === 'Buffer' && Array.isArray(value.data)) return Buffer.from(value.data);

  // Older plain JSON.stringify(Uint8Array) output is an object of numeric keys.
  // Restore that shape for retry files written before the tagged codec existed.
  const entries = Object.entries(value);
  if (entries.length && entries.every(([key, child]) => /^\d+$/.test(key) && Number.isInteger(child) && child >= 0 && child <= 255)) {
    const bytes = new Uint8Array(entries.length);
    for (const [key, child] of entries) bytes[Number(key)] = child;
    return bytes;
  }

  const out = {};
  for (const [key, child] of Object.entries(value)) out[key] = reviveRetryValue(child);
  return out;
}

function serializeRetryRecord(ts, message) {
  return JSON.stringify({ ts: Number(ts) || Date.now(), message }, retryJsonReplacer);
}

function parseRetryRecord(serialized) {
  const record = JSON.parse(String(serialized));
  if (!record || typeof record !== 'object') return null;
  return { ...record, message: reviveRetryValue(record.message) };
}

module.exports = { serializeRetryRecord, parseRetryRecord, reviveRetryValue };
