// ============================================================
//   index.js  v4  –   |  Telegram × WhatsApp
// ============================================================
'use strict';
require('dotenv').config();

const fs    = require('fs');
const path  = require('path');
const chalk = require('chalk');
const pino  = require('pino');
const https = require('https');
const http  = require('http');
const { Telegraf, Markup } = require('telegraf');

const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  DisconnectReason,
} = require('blacklord-baileys');

const settings  = require('./settings');
const { formatReply: formatSmartReply } = require('./helper/style');
const { serializeRetryRecord, parseRetryRecord } = require('./helper/retry-codec');
const { handleMessage, runAutoFollow, handlePollVotes }  = require('./case');
const { handleAntiDelete, revokedKeysFromUpdates, captureForAntiDelete, checkAntilink, checkAntiMedia, handleAntiCall, handleGroupParticipantsUpdate } = require('./helper/listeners');
const {
  sessionExists, listSessions, deleteSession, sessionDir,
  getWaSettings, setWaSetting, getAllPairs, getUserPairs,
  addPair, removePair, getAllPairedSessions,
  registerUser, getAllUsers, numOf, retrieveMessage,
} = require('./helper/function');
const { normalizeJid, ensureDir, formatUptime } = require('./helper/utils');
const { claimGroupResponse } = require('./helper/group-response-gate');
const { logInfo, logSuccess, logWarn, logError, logSession } = require('./helper/logger');

global.botStartTime = Date.now();
ensureDir(settings.SESSION_DIR);
ensureDir('./database');

// ═══════════════════════════════════════════════════════════
//   PERSISTENT PENDING REPLIES  (survives restarts)
// ═══════════════════════════════════════════════════════════
const PENDING_FILE  = './database/pendingReplies.json';
const PREMIUM_FILE  = './database/prem_data.json';

function loadJSON(file, def) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return def; }
}
function saveJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// pendingReplies: ownerMsgId (string) → { userId, chatId }
let pendingRepliesData = loadJSON(PENDING_FILE, {});
const pendingReplies   = new Map(Object.entries(pendingRepliesData));

function savePendingReplies() {
  saveJSON(PENDING_FILE, Object.fromEntries(pendingReplies));
}

// ═══════════════════════════════════════════════════════════
//   PREMIUM SYSTEM
// ═══════════════════════════════════════════════════════════
// Structure: { premOnly: false, owners: ["id",...], premUsers: ["id",...] }
const _rp = loadJSON(PREMIUM_FILE, {});
let premData = { premOnly: !!_rp.premOnly, owners: Array.isArray(_rp.owners) ? _rp.owners : [], premUsers: Array.isArray(_rp.premUsers) ? _rp.premUsers : [] };

function savePrem() { saveJSON(PREMIUM_FILE, premData); }

function isOwner(id) {
  const configured = Array.isArray(settings.OWNER_TELEGRAM_IDS)
    ? settings.OWNER_TELEGRAM_IDS
    : [settings.OWNER_TELEGRAM_ID];
  const admins = Array.isArray(settings.ADMIN_TELEGRAM_IDS) ? settings.ADMIN_TELEGRAM_IDS : [];
  return [...configured, ...admins].map(String).includes(String(id)) || premData.owners.includes(String(id));
}
function isPremium(id) {
  return isOwner(id) || premData.premUsers.includes(String(id));
}
function canUseBot(id) {
  if (!premData.premOnly) return true; // open to all
  return isPremium(id);
}

// ─────────────────────────────────────────────────────────────
const activeSockets      = new Map();
const notifiedConnected  = new Set();

// Expose activeSockets immediately; _startWhatsApp set in launch() after function is defined
global._activeSockets  = activeSockets;

// ═══════════════════════════════════════════════════════════
//   GITHUB SESSION SYNC
// ═══════════════════════════════════════════════════════════
const GH_TOKEN  = settings.GITHUB_TOKEN  || process.env.GITHUB_TOKEN;
const GH_USER   = settings.GITHUB_USERNAME || process.env.GITHUB_USERNAME;
const GH_REPO   = settings.GITHUB_REPO   || process.env.GITHUB_REPO;
const GH_BRANCH = settings.GITHUB_BRANCH || process.env.GITHUB_BRANCH || 'main';
const GH_BASE   = `/repos/${GH_USER}/${GH_REPO}/contents`;

function ghRequest(method, urlPath, body = null) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const opts = {
      hostname: 'api.github.com',
      path: urlPath,
      method,
      headers: {
        'Authorization': `Bearer ${GH_TOKEN}`,
        'User-Agent': 'Animemd-Bot',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        ...(data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}),
      },
    };
    const req = https.request(opts, (res) => {
      let raw = '';
      res.on('data', c => raw += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(raw) }); }
        catch { resolve({ status: res.statusCode, body: raw }); }
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function ghListDir(remotePath) {
  const { status, body } = await ghRequest('GET', `${GH_BASE}/${remotePath}?ref=${GH_BRANCH}`);
  if (status !== 200 || !Array.isArray(body)) return [];
  return body;
}

async function ghGetFile(remotePath) {
  const { status, body } = await ghRequest('GET', `${GH_BASE}/${remotePath}?ref=${GH_BRANCH}`);
  if (status !== 200 || !body.content) return null;
  return { content: Buffer.from(body.content.replace(/\n/g, ''), 'base64'), sha: body.sha };
}

async function ghDeleteFile(remotePath, sha, message) {
  return ghRequest('DELETE', `${GH_BASE}/${remotePath}`, { message, sha, branch: GH_BRANCH });
}

async function downloadSessionFromGitHub(sessionId) {
  try {
    const remotePath = `sessions/${sessionId}`;
    const files = await ghListDir(remotePath);
    if (!files.length) return false;
    const localDir = sessionDir(sessionId);
    ensureDir(localDir);
    for (const f of files) {
      if (f.type !== 'file') continue;
      const fileData = await ghGetFile(`${remotePath}/${f.name}`);
      if (!fileData) continue;
      fs.writeFileSync(path.join(localDir, f.name), fileData.content);
      logInfo('GH-SYNC', `Downloaded: ${sessionId}/${f.name}`);
    }
    return true;
  } catch (e) {
    logError('GH-SYNC', `Download failed for ${sessionId}: ${e.message}`);
    return false;
  }
}

async function deleteSessionFromGitHub(sessionId) {
  try {
    const files = await ghListDir(`sessions/${sessionId}`);
    for (const f of files) {
      if (f.type === 'file') await ghDeleteFile(`sessions/${sessionId}/${f.name}`, f.sha, `Logout cleanup: ${sessionId}`);
    }
    logInfo('GH-SYNC', `Deleted from GitHub: ${sessionId}`);
  } catch (e) {
    logError('GH-SYNC', `GH delete failed for ${sessionId}: ${e.message}`);
  }
}

async function syncSessionsFromGitHub() {
  try {
    // Use git trees API – more reliable than contents API for nested dirs
    const { status, body } = await ghRequest('GET', `/repos/${GH_USER}/${GH_REPO}/git/trees/${GH_BRANCH}?recursive=1`);
    if (status !== 200 || !Array.isArray(body.tree)) { logInfo('GH-SYNC', 'No tree data'); return; }

    // Find unique session folder names: paths like sessions/<sessionId>/creds.json
    const sessionIds = new Set();
    for (const item of body.tree) {
      const m = item.path.match(/^sessions\/([^\/]+)\/creds\.json$/);
      if (m) sessionIds.add(m[1]);
    }

    if (!sessionIds.size) { logInfo('GH-SYNC', 'No remote sessions'); return; }

    for (const sid of sessionIds) {
      if (!sessionExists(sid)) {
        logInfo('GH-SYNC', `Downloading: ${sid}`);
        await downloadSessionFromGitHub(sid);
      } else {
        logInfo('GH-SYNC', `Already local: ${sid}`);
      }
    }
  } catch (e) {
    logError('GH-SYNC', `Sync error: ${e.message}`);
  }
}

// ═══════════════════════════════════════════════════════════
//   LIVE SESSION WATCHER  – picks up new web_ sessions from
//   GitHub every 30s without needing a panel restart
// ═══════════════════════════════════════════════════════════
function startSessionWatcher() {
  setInterval(async () => {
    try {
      const { status, body } = await ghRequest('GET', `/repos/${GH_USER}/${GH_REPO}/git/trees/${GH_BRANCH}?recursive=1`);
      if (status !== 200 || !Array.isArray(body.tree)) return;

      const sessionIds = new Set();
      for (const item of body.tree) {
        const m = item.path.match(/^sessions\/([^\/]+)\/creds\.json$/);
        if (m) sessionIds.add(m[1]);
      }

      for (const sid of sessionIds) {
        if (activeSockets.has(sid)) continue;       // already running
        if (!sessionExists(sid)) {
          logInfo('WATCHER', `New session detected: ${sid}`);
          await downloadSessionFromGitHub(sid);
        }
        if (sessionExists(sid) && !activeSockets.has(sid)) {
          logInfo('WATCHER', `Starting: ${sid}`);
          // find tgUserId from pairs
          let tgUserId = null;
          const allPairs = getAllPairs();
          for (const [uid, pairs] of Object.entries(allPairs)) {
            if (pairs.find(p => p.sessionId === sid)) { tgUserId = uid; break; }
          }
          notifiedConnected.add(sid); // suppress connect notification
          startWhatsApp(sid, null, null, tgUserId).catch(e => logError('WATCHER', e.message));
        }
      }
    } catch {}
  }, 1000);
  logSuccess('WATCHER', 'Live session watcher started (30s interval)');
}

// ═══════════════════════════════════════════════════════════
//   SELF-PING
// ═══════════════════════════════════════════════════════════
function startPingLoop() {
  const urls = [settings.PANEL_URL].filter(Boolean);

  // tiny health server so Render/external monitors can hit it
  http.createServer((req, res) => {
    const uptime = formatUptime(Date.now() - global.botStartTime);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'alive', uptime, sessions: activeSockets.size }));
  }).listen(process.env.PORT || 3001, () => {
    logSuccess('PING', `Health server :${process.env.PORT || 3001}`);
  });

  setInterval(() => {
    const uptime = formatUptime(Date.now() - global.botStartTime);
    process.stdout.write(chalk.gray(`[UPTIME] ${uptime}\n`));
    for (const url of urls) {
      try {
        const parsed = new URL(url);
        const mod = parsed.protocol === 'https:' ? https : http;
        const req = mod.get(url, res => logInfo('PING', `${url} → ${res.statusCode}`));
        req.on('error', () => {});
        req.setTimeout(8000, () => req.destroy());
      } catch {}
    }
  }, 4 * 60 * 1000);
}

// ═══════════════════════════════════════════════════════════
//   TELEGRAM BOT
// ═══════════════════════════════════════════════════════════
const bot = new Telegraf(settings.TELEGRAM_TOKEN);
// Telegram and WhatsApp command replies share the same compact smart-card layout.
const tgSmartBox = (title, rows = []) => formatSmartReply(rows.join('\n'), {
  title,
  platform: 'Telegram',
  quote: false,
});
const tgPairStatus = (phone, online) => tgSmartBox('PAIRING STATUS', [
  `Number     : +${phone}`,
  `Status     : ${online ? 'Connected' : 'Paired / Offline'}`,
  `Next action: ${online ? `/delpair ${phone} to disconnect` : `/pair ${phone} to reconnect`}`,
]);
const tgReply = (ctx, title, rows = []) => ctx.reply(tgSmartBox(title, rows));
const telegramCommandMenu = () => tgSmartBox('TELEGRAM COMMANDS', [
  'START HERE',
  '/start — Open the control center',
  '/menu — Browse this organized command guide',
  '/help — Show the command guide',
  '',
  'WHATSAPP PAIRING',
  '/pair <number> — Connect a WhatsApp number',
  '/delpair <number> — Disconnect one of your paired numbers',
  '/listpaired — View your paired numbers',
  '',
  'PROFILE AND SUPPORT',
  '/owner — View the Telegram bot owners',
  '/reportissue <text> — Send a report to the owner',
  '/cancel — Cancel a pending broadcast action',
  '',
  'OWNER COMMANDS · RESTRICTED',
  '/listsession — View active WhatsApp sessions',
  '/premonly — Toggle premium-only access',
  '/addprem <id> — Grant premium access',
  '/delprem <id> — Remove premium access',
  '/listprem — Review owners and premium users',
  '/addowner <id> — Add a Telegram sub-owner',
  '/broadcast <text> — Start an owner announcement',
  '',
  'Use /pair with your full international number, without the + sign.',
]);
const TELEGRAM_COMMANDS = [
  { command: 'start', description: 'Open the TALK-SPAR control center' },
  { command: 'menu', description: 'Browse organized bot commands' },
  { command: 'help', description: 'Show command usage and help' },
  { command: 'pair', description: 'Pair a WhatsApp number' },
  { command: 'delpair', description: 'Disconnect one of your paired numbers' },
  { command: 'listpaired', description: 'View your WhatsApp sessions' },
  { command: 'owner', description: 'View Telegram bot owners' },
  { command: 'reportissue', description: 'Send a report to the owner' },
  { command: 'cancel', description: 'Cancel a pending action' },
  { command: 'listsession', description: 'Owner: view active sessions' },
  { command: 'premonly', description: 'Owner: toggle premium-only access' },
  { command: 'addprem', description: 'Owner: grant premium access' },
  { command: 'delprem', description: 'Owner: remove premium access' },
  { command: 'listprem', description: 'Owner: review premium status' },
  { command: 'addowner', description: 'Owner: add a Telegram sub-owner' },
  { command: 'broadcast', description: 'Owner: send an announcement' },
];
bot.command('menu', async (ctx) => {
  registerUser(ctx.from.id, ctx.from.first_name);
  return ctx.reply(telegramCommandMenu(), {
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔗 Pair WhatsApp', 'pair_help'), Markup.button.callback('📋 My Pairs', 'my_sessions')],
      [Markup.button.callback('👤 My Profile', 'back_start')],
    ]),
  });
});
bot.command('help', async (ctx) => ctx.reply(telegramCommandMenu()));

// ── /start ────────────────────────────────────────────────────
bot.start(async (ctx) => {
  registerUser(ctx.from.id, ctx.from.first_name);
  const myPairs    = getUserPairs(ctx.from.id);
  const activeMine = myPairs.filter(p => activeSockets.has(p.sessionId)).length;
  const uptime     = formatUptime(Date.now() - global.botStartTime);
  const mode       = premData.premOnly ? 'Premium only' : 'Public access';
  const firstName  = ctx.from.first_name || 'there';
  const text = tgSmartBox(`WELCOME, ${firstName.toUpperCase()}`, [
    'TALK-SPAR smart WhatsApp pairing assistant ready.',
    'Developers : TALKLESS AND SPARTA28',
    '',
    'QUICK ACTIONS',
    '/pair <number>       Connect WhatsApp',
    '/delpair <number>    Remove a session',
    '/listpaired          View your numbers',
    '/listsession         View all sessions (owner)',
    '/owner               View Telegram owners',
    '/reportissue <text>  Contact support',
    '',
    `Access     : ${mode}`,
    `Sessions   : ${activeMine}/${myPairs.length}`,
    `Uptime     : ${uptime}`,
    '',
    'Use /pair with the full country-code number.',
    'Use /menu for the organized Telegram command directory.',
  ]);
  const kb = Markup.keyboard([
    ['🔗 PAIR WHATSAPP'],
    ['🗑️ DELETE PAIR', '📂 PAIRING HELP'],
    ['🆔 TELEGRAM ID', '👑 OWNER'],
    ['👤 MY PROFILE', '📋 MY PAIRS'],
  ]).resize();
  // Send the branded start photo when the local asset is available; keep a text fallback.
  if (settings.TELEGRAM_START_IMAGE && fs.existsSync(settings.TELEGRAM_START_IMAGE)) {
    return ctx.replyWithPhoto(
      { source: settings.TELEGRAM_START_IMAGE },
      { caption: text, reply_markup: kb.reply_markup }
    );
  }
  return ctx.reply(text, { reply_markup: kb.reply_markup });
});

// ── /owner – Telegram owners only (never WhatsApp contacts) ───
bot.command('owner', async (ctx) => {
  const owners = (Array.isArray(settings.OWNER_TELEGRAM_IDS)
    ? settings.OWNER_TELEGRAM_IDS
    : [settings.OWNER_TELEGRAM_ID])
    .filter(Boolean)
    .map(String)
    .filter((id, i, arr) => arr.indexOf(id) === i);
  return tgReply(ctx, 'TELEGRAM OWNERS', [
    `Owner 1 ID : ${owners[0] || 'Not configured'}`,
    `Owner 2 ID : ${owners[1] || 'Not configured'}`,
  ]);
});

// ── Reply keyboard handlers (VARNOX-style) ───────────────────
const localStates = new Map();

bot.on('text', async (ctx, next) => {
  const uid = String(ctx.from.id);
  const text = (ctx.message.text || '').trim();
  const pending = localStates.get(uid);

  // 1) pending number input (pair / delpair flows)
  if (pending) {
    localStates.delete(uid);
    const phone = text.replace(/\D/g, '');
    if (phone.length < 7) {
      return ctx.reply(tgSmartBox('INVALID NUMBER', ['Send digits with country code.', 'Example: 254704955033']));
    }
    if (pending.action === 'pair') {
      if (!canUseBot(ctx.from.id)) {
        return tgReply(ctx, 'ACCESS RESTRICTED', ['Premium-only mode is enabled.', 'Contact the owner to request access.']);
      }
      const sessionId = `wa_${uid}_${phone}`;
      const paired = getUserPairs(uid).some(p => p.sessionId === sessionId || String(p.waNum) === phone);
      if (activeSockets.has(sessionId) || paired) {
        return ctx.reply(tgPairStatus(phone, activeSockets.has(sessionId)));
      }
      try {
        await ctx.reply(tgSmartBox('PAIRING REQUEST ACCEPTED', [
          `Number     : +${phone}`,
          'Code style : TALKSPAR',
          'Status     : Preparing pairing code...',
        ]));
        if (sessionExists(sessionId)) {
          await startWhatsApp(sessionId, ctx.chat.id, null, uid);
          return;
        }
        await startWhatsApp(sessionId, ctx.chat.id, phone, uid);
      } catch (err) {
        await ctx.reply(tgSmartBox('PAIRING FAILED', [String(err.message || err).slice(0, 300)])).catch(() => {});
      }
      return;
    }
    if (pending.action === 'delpair') {
      const sessionId = `wa_${uid}_${phone}`;
      const sock = activeSockets.get(sessionId);
      if (sock) {
        try { await sock.logout(); } catch {}
        try { sock.ws?.close(); }   catch {}
        activeSockets.delete(sessionId);
      }
      notifiedConnected.delete(sessionId);
      removePair(uid, sessionId);
      const ok = deleteSession(sessionId);
      deleteSessionFromGitHub(sessionId).catch(() => {});
      return tgReply(ctx, ok ? 'PAIR REMOVED' : 'NO SESSION FOUND', ok ? [`Number : +${phone}`, 'Status : Disconnected', `Next  : /pair ${phone}`] : [`Number : +${phone}`]);
    }
  }

  // 2) button presses
  if (text === '🔗 PAIR WHATSAPP') {
    localStates.set(uid, { action: 'pair' });
    return tgReply(ctx, 'PAIR WHATSAPP', ['Send the number with country code.', 'Example: 254799984735', 'Pairing code style: TALKSPAR']);
  }
  if (text === '🗑️ DELETE PAIR') {
    localStates.set(uid, { action: 'delpair' });
    return tgReply(ctx, 'DELETE PAIR', ['Send the WhatsApp number to disconnect.', 'Example: 254799984735']);
  }
  if (text === '📂 PAIRING HELP') {
    return tgReply(ctx, 'PAIRING GUIDE', ['Use: /pair 254704955033', 'Include country code and omit +.', 'Kenya: 254XXXXXXXXX', 'Nigeria: 234XXXXXXXXX', 'USA: 1XXXXXXXXXX']);
  }
  if (text === '🆔 TELEGRAM ID') {
    return tgReply(ctx, 'TELEGRAM PROFILE', [`ID       : ${ctx.from.id}`, `Username : @${ctx.from.username || '—'}`, `Name     : ${(ctx.from.first_name || '')} ${(ctx.from.last_name || '')}`]);
  }
  if (text === '👑 OWNER') {
    const owners = (Array.isArray(settings.OWNER_TELEGRAM_IDS)
      ? settings.OWNER_TELEGRAM_IDS
      : [settings.OWNER_TELEGRAM_ID]).filter(Boolean).map(String);
    return tgReply(ctx, 'TELEGRAM OWNERS', [
      `Owner 1 ID : ${owners[0] || 'Not configured'}`,
      `Owner 2 ID : ${owners[1] || 'Not configured'}`,
    ]);
  }
  if (text === '🛒 𝑩𝑼𝒀 𝑷𝑨𝑵𝑬𝑳') {
    return tgReply(ctx, 'PANEL INFORMATION', [
      'Contact the owner to ask about the panel.',
      `Owner: ${settings.OWNER_NAME} (ID ${settings.OWNER_TELEGRAM_ID})`,
    ]);
  }
  if (text === '👑 𝑨𝑫𝑴𝑰𝑵 𝑷𝑨𝑵𝑬𝑳') {
    if (!isOwner(ctx.from.id)) return tgReply(ctx, 'ACCESS DENIED', ['This command is available to the owner only.']);
    return tgReply(ctx, 'OWNER COMMANDS', [
      '/broadcast — Start an announcement',
      '/listsession — Review active sessions',
      '/premonly — Toggle premium-only access',
      '/addprem <id> — Grant premium access',
      '/delprem <id> — Remove premium access',
      '/listprem — Review premium status',
      '/addowner <id> — Add a Telegram sub-owner',
    ]);
  }
  if (text === '👤 MY PROFILE') {
    const pairs = getUserPairs(uid);
    return tgReply(ctx, 'MY PROFILE', [`ID       : ${uid}`, `Name     : ${ctx.from.first_name || '—'}`, `Premium  : ${isPremium(ctx.from.id) ? 'YES' : 'NO'}`, `Paired   : ${pairs.length}`]);
  }
  if (text === '📋 MY PAIRS') {
    const pairs = getUserPairs(uid);
    if (!pairs.length) return tgReply(ctx, 'MY PAIRS', ['No WhatsApp numbers paired yet.', 'Tap PAIR WHATSAPP to begin.']);
    const list = pairs.map((p, i) => `${i + 1}. +${p.waNum} ${activeSockets.has(p.sessionId) ? '🟢 Online' : '🔴 Offline'}`).join('\n');
    return tgReply(ctx, `MY PAIRS (${pairs.length})`, list.split('\n'));
  }

  // not a keyboard message – let other handlers process it
  return next();
});

bot.action('pair_help', async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.reply(
    tgSmartBox('PAIRING GUIDE', [
      'Use /pair 254704955033 with your international number and omit +.',
      'Kenya: 254XXXXXXXXX',
      'Nigeria: 234XXXXXXXXX',
      'USA: 1XXXXXXXXXX',
    ]),
    {
      ...Markup.inlineKeyboard([[Markup.button.callback('◀️ Back', 'back_start')]]),
    }
  );
});

bot.action('my_sessions', async (ctx) => {
  await ctx.answerCbQuery();
  const pairs = getUserPairs(String(ctx.from.id));
  if (!pairs.length) {
    return tgReply(ctx, 'MY SESSIONS', ['No sessions yet.', 'Use /pair <number> to link a WhatsApp number.']);
  }
  const list = pairs.map((p, i) =>
    `${i+1}. +${p.waNum} ${activeSockets.has(p.sessionId) ? '🟢 Online' : '🔴 Offline'}`
  ).join('\n');
  await tgReply(ctx, `MY SESSIONS (${pairs.length})`, list.split('\n'));
});

bot.action('back_start', async (ctx) => {
  await ctx.answerCbQuery();
  await tgReply(ctx, 'TALK-SPAR TECH', ['Use /start to open the smart control center.']);
});

// ═══════════════════════════════════════════════════════════
//   PREMIUM COMMANDS  (owner / addowner only)
// ═══════════════════════════════════════════════════════════

// /premonly  – toggle premium-only mode
bot.command('premonly', async (ctx) => {
  if (!isOwner(ctx.from.id)) return tgReply(ctx, 'ACCESS DENIED', ['This command is available to the owner only.']);
  premData.premOnly = !premData.premOnly;
  savePrem();
  await tgReply(ctx, 'ACCESS MODE UPDATED', [
    `Premium-only: ${premData.premOnly ? 'ON' : 'OFF'}`,
    premData.premOnly ? 'Only premium users and owners can pair.' : 'All users can pair.',
  ]);
});

// /addprem <telegram_id>  – grant premium
bot.command('addprem', async (ctx) => {
  if (!isOwner(ctx.from.id)) return tgReply(ctx, 'ACCESS DENIED', ['This command is available to the owner only.']);
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) return tgReply(ctx, 'ADD PREMIUM', ['Usage: /addprem <telegram_id>']);
  if (premData.premUsers.includes(target)) return tgReply(ctx, 'PREMIUM STATUS', [`${target} already has premium access.`]);
  premData.premUsers.push(target);
  savePrem();
  await tgReply(ctx, 'PREMIUM ACCESS ADDED', [`User ID: ${target}`, 'Status: Active']);
});

// /delprem <telegram_id>  – revoke premium
bot.command('delprem', async (ctx) => {
  if (!isOwner(ctx.from.id)) return tgReply(ctx, 'ACCESS DENIED', ['This command is available to the owner only.']);
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) return tgReply(ctx, 'REMOVE PREMIUM', ['Usage: /delprem <telegram_id>']);
  const idx = premData.premUsers.indexOf(target);
  if (idx === -1) return tgReply(ctx, 'PREMIUM STATUS', [`${target} does not have premium access.`]);
  premData.premUsers.splice(idx, 1);
  savePrem();
  await tgReply(ctx, 'PREMIUM ACCESS REMOVED', [`User ID: ${target}`, 'Status: Removed']);
});

// /listprem  – list premium users & owners
bot.command('listprem', async (ctx) => {
  if (!isOwner(ctx.from.id)) return tgReply(ctx, 'ACCESS DENIED', ['This command is available to the owner only.']);
  const mode    = premData.premOnly ? '🔒 Premium-only ON' : '🌐 Premium-only OFF';
  const owners  = [String(settings.OWNER_TELEGRAM_ID), ...premData.owners].join('\n') || 'none';
  const prems   = premData.premUsers.join('\n') || 'none';
  await tgReply(ctx, 'PREMIUM STATUS', [
    `Access mode: ${mode}`,
    'OWNERS',
    ...owners.split('\n'),
    'PREMIUM USERS',
    ...prems.split('\n'),
  ]);
});

// /addowner <telegram_id>  – promote to sub-owner (main owner only)
bot.command('addowner', async (ctx) => {
  if (String(ctx.from.id) !== String(settings.OWNER_TELEGRAM_ID)) return tgReply(ctx, 'ACCESS DENIED', ['Only the main owner can add Telegram owners.']);
  const target = ctx.message.text.split(/\s+/)[1];
  if (!target) return tgReply(ctx, 'ADD OWNER', ['Usage: /addowner <telegram_id>']);
  if (premData.owners.includes(target)) return tgReply(ctx, 'OWNER STATUS', [`${target} is already an owner.`]);
  premData.owners.push(target);
  savePrem();
  await tgReply(ctx, 'OWNER ACCESS UPDATED', [`User ID: ${target}`, 'Status: Added as a sub-owner']);
});

// ── /pair <number> – unlimited per user ──────────────────────
bot.command('pair', async (ctx) => {
  registerUser(ctx.from.id, ctx.from.first_name);
  if (!canUseBot(ctx.from.id)) {
    return tgReply(ctx, 'PREMIUM ACCESS REQUIRED', ['Pairing is currently limited to premium users.', 'Contact the owner to request access.']);
  }
  const phone = ctx.message.text.split(/\s+/)[1]?.replace(/\D/g, '');
  if (!phone || phone.length < 7) {
    return ctx.reply(tgSmartBox('PAIRING FORMAT', [
      'Use: /pair 254799984735',
      'Include the country code and omit the + sign.',
    ]));
  }
  const uid       = String(ctx.from.id);
  const sessionId = `wa_${uid}_${phone}`;
  const paired = getUserPairs(uid).some(p => p.sessionId === sessionId || String(p.waNum) === phone);
  if (activeSockets.has(sessionId) || paired) {
    return ctx.reply(tgPairStatus(phone, activeSockets.has(sessionId)));
  }
  // Acknowledge first so Telegram never appears frozen while WhatsApp starts.
  try {
    await ctx.reply(tgSmartBox('PAIRING REQUEST ACCEPTED', [
      `Number     : +${phone}`,
      'Code style : TALKSPAR',
      'Status     : Preparing pairing code...',
    ]));
    if (sessionExists(sessionId)) {
      await startWhatsApp(sessionId, ctx.chat.id, null, uid);
      return;
    }
    await startWhatsApp(sessionId, ctx.chat.id, phone, uid);
  } catch (err) {
    await ctx.reply(tgSmartBox('PAIRING FAILED', [String(err.message || err).slice(0, 300)])).catch(() => {});
  }
});
// ── /delpair <number> – instant no confirmation ───────────────
bot.command('delpair', async (ctx) => {
  const phone = ctx.message.text.split(/\s+/)[1]?.replace(/\D/g, '');
  if (!phone) return tgReply(ctx, 'DELETE FORMAT', ['Use: /delpair 254799984735', 'Include the country code and omit +.']);

  const uid       = String(ctx.from.id);
  const sessionId = `wa_${uid}_${phone}`;

  const sock = activeSockets.get(sessionId);
  if (sock) {
    try { await sock.logout(); } catch {}
    try { sock.ws?.close(); }   catch {}
    activeSockets.delete(sessionId);
  }

  notifiedConnected.delete(sessionId);
  removePair(uid, sessionId);
  const ok = deleteSession(sessionId);
  deleteSessionFromGitHub(sessionId).catch(() => {});
  await ctx.reply(ok
    ? tgSmartBox('PAIR REMOVED', [
        `Number : +${phone}`,
        'Status : Disconnected',
        `Next  : /pair ${phone} to connect again`,
      ])
    : tgSmartBox('NO SESSION FOUND', [`Number : +${phone}`])
  );
});

// ── /listpaired ───────────────────────────────────────────────
bot.command('listpaired', async (ctx) => {
  const pairs = getUserPairs(String(ctx.from.id));
  if (!pairs.length) return ctx.reply(tgSmartBox('PAIRED NUMBERS', [
    'No numbers are paired yet.',
    'Use /pair <number> to connect WhatsApp.',
  ]));
  const list = pairs.map((p, i) => `${i + 1}. +${p.waNum} — ${activeSockets.has(p.sessionId) ? 'Online' : 'Offline'}`);
  await ctx.reply(tgSmartBox(`PAIRED NUMBERS (${pairs.length})`, list));
});

// ── /listsession (owner) ──────────────────────────────────────
bot.command('listsession', async (ctx) => {
  if (!isOwner(ctx.from.id)) return tgReply(ctx, 'ACCESS DENIED', ['This command is available to the owner only.']);
  const list = listSessions();
  if (!list.length) return tgReply(ctx, 'ACTIVE SESSIONS', ['No active sessions are running.']);
  const text = list.map((s, i) => `${i+1}. \`${s}\` ${activeSockets.has(s) ? '🟢' : '🔴'}`).join('\n');
  await tgReply(ctx, `ACTIVE SESSIONS (${list.length})`, text.split('\n'));
});

// ═══════════════════════════════════════════════════════════
//   BROADCAST  –  supports text, photo, video, audio,
//                 document, sticker, animation, voice,
//                 inline buttons (via | syntax in caption)
//
//   Flow:
//     1. Owner sends /broadcast
//     2. Bot asks "Send your broadcast message now"
//     3. Owner sends ANY message type (optionally with caption)
//     4. Bot forwards it to all users
//
//   Inline button syntax (add to caption/text):
//     [Button Label | https://link.com]
//     [Btn1 | url1] [Btn2 | url2]   ← same row
//     [Btn3 | url3]                  ← new row
//
// ═══════════════════════════════════════════════════════════

// Tracks owners waiting to send their broadcast message
const broadcastPending = new Set();

// Parse [Label | URL] button syntax from text/caption
function parseBroadcastButtons(text) {
  if (!text) return { clean: text || '', markup: null };
  const btnRegex = /\[([^\]|]+)\|([^\]]+)\]/g;
  const rows = [];
  let currentRow = [];
  let lastIndex = 0;
  let clean = text;
  let match;

  // Collect all button matches
  const matches = [];
  while ((match = btnRegex.exec(text)) !== null) matches.push(match);

  if (!matches.length) return { clean: text, markup: null };

  // Build rows – buttons on the same line go in same row
  // We detect same-line by checking if there's a newline between consecutive matches
  for (let i = 0; i < matches.length; i++) {
    const m      = matches[i];
    const label  = m[1].trim();
    const url    = m[2].trim();
    const before = i === 0 ? text.slice(0, m.index) : text.slice(matches[i-1].index + matches[i-1][0].length, m.index);
    if (i > 0 && before.includes('\n')) { if (currentRow.length) rows.push(currentRow); currentRow = []; }
    currentRow.push(Markup.button.url(label, url));
  }
  if (currentRow.length) rows.push(currentRow);

  // Strip button syntax from clean text
  clean = text.replace(/\[([^\]|]+)\|([^\]]+)\]/g, '').replace(/\n{3,}/g, '\n\n').trim();

  return { clean, markup: rows.length ? Markup.inlineKeyboard(rows) : null };
}

// Send one broadcast unit to a single uid
async function sendBroadcastToUser(uid, msg) {
  const tg      = bot.telegram;
  const rawText = msg.text || msg.caption || '';
  const { clean, markup } = parseBroadcastButtons(rawText);
  const extra   = { parse_mode: 'Markdown', ...(markup || {}) };

  if (msg.sticker)    return tg.sendSticker(uid, msg.sticker.file_id, markup ? { reply_markup: markup.reply_markup } : {});
  if (msg.animation)  return tg.sendAnimation(uid, msg.animation.file_id, { caption: clean, ...extra });
  if (msg.video_note) return tg.sendVideoNote(uid, msg.video_note.file_id);
  if (msg.voice)      return tg.sendVoice(uid, msg.voice.file_id, { caption: clean, ...extra });
  if (msg.photo) {
    const photo = msg.photo[msg.photo.length - 1];
    return tg.sendPhoto(uid, photo.file_id, { caption: clean, ...extra });
  }
  if (msg.video)    return tg.sendVideo(uid, msg.video.file_id, { caption: clean, ...extra });
  if (msg.audio)    return tg.sendAudio(uid, msg.audio.file_id, { caption: clean, ...extra });
  if (msg.document) return tg.sendDocument(uid, msg.document.file_id, { caption: clean, ...extra });
  if (msg.text)     return tg.sendMessage(uid, clean || msg.text, extra);
  // Fallback: forward as-is
  return tg.forwardMessage(uid, msg.chat.id, msg.message_id);
}

bot.command('broadcast', async (ctx) => {
  if (!isOwner(ctx.from.id)) return tgReply(ctx, 'ACCESS DENIED', ['This command is available to the owner only.']);
  broadcastPending.add(String(ctx.from.id));
  await tgReply(ctx, 'BROADCAST SETUP', [
    'Send the message to broadcast.',
    'Supported: text, photo, video, audio, document, sticker, voice, animation.',
    'Optional button format: [Button Label | https://url.com]',
    'Send /cancel to abort.',
  ]);
});

bot.command('cancel', async (ctx) => {
  if (broadcastPending.has(String(ctx.from.id))) {
    broadcastPending.delete(String(ctx.from.id));
    return tgReply(ctx, 'BROADCAST', ['Broadcast cancelled.']);
  }
  return tgReply(ctx, 'BROADCAST', ['There is no pending broadcast to cancel.']);
});

// Intercept the actual broadcast message from owner
bot.on('message', async (ctx, next) => {
  const oid = String(ctx.from?.id);
  if (!broadcastPending.has(oid)) return next();
  broadcastPending.delete(oid);

  const users    = getAllUsers();
  const uids     = Object.keys(users);
  const progress = await ctx.reply(tgSmartBox('BROADCAST IN PROGRESS', [`Recipients: ${uids.length}`, 'Status: Sending']));
  let sent = 0, failed = 0;

  for (const uid of uids) {
    try {
      await sendBroadcastToUser(uid, ctx.message);
      sent++;
    } catch { failed++; }
    await new Promise(r => setTimeout(r, 80)); // ~12/sec, safe for Telegram limits
  }

  await bot.telegram.editMessageText(
    ctx.chat.id, progress.message_id, null,
    tgSmartBox('BROADCAST COMPLETE', [`Sent: ${sent}`, `Failed: ${failed}`, `Recipients: ${uids.length}`])
  );
});

// ── /reportissue ──────────────────────────────────────────────
bot.command('reportissue', async (ctx) => {
  const report = ctx.message.text.replace(/^\/reportissue\s*/, '').trim();
  if (!report) return tgReply(ctx, 'REPORT ISSUE', ['Usage: /reportissue <problem>']);
  try {
    const sent = await bot.telegram.sendMessage(
      settings.OWNER_TELEGRAM_ID,
      `📢 *Issue*\nFrom: ${ctx.from.first_name} (ID: \`${ctx.from.id}\`)\n\n${report}`,
      { parse_mode: 'Markdown' }
    );
    // Persist to disk so late replies after restart still work
    pendingReplies.set(String(sent.message_id), { userId: ctx.from.id, chatId: ctx.chat.id });
    savePendingReplies();
    await tgReply(ctx, 'REPORT SENT', ['Your report was delivered.', 'The owner will reply here.']);
  } catch { await tgReply(ctx, 'REPORT FAILED', ['The report could not be sent.']); }
});

// ── Owner replies → forward to reporter (supports media) ─────
// Works even if bot restarted before owner replied — loaded from disk on startup
bot.on('message', async (ctx, next) => {
  if (String(ctx.from?.id) !== String(settings.OWNER_TELEGRAM_ID)) return next();
  const replyToId = ctx.message?.reply_to_message?.message_id;
  if (!replyToId) return next();
  const pending = pendingReplies.get(String(replyToId));
  if (!pending) return next();
  try {
    const tg  = bot.telegram;
    const uid = pending.userId;
    const m   = ctx.message;
    const cap = m.caption || m.text || '';
    const extra = { caption: `💬 *Reply from owner:*\n\n${cap}`, parse_mode: 'Markdown' };

    if (m.sticker)    await tg.sendSticker(uid, m.sticker.file_id);
    else if (m.animation)  await tg.sendAnimation(uid, m.animation.file_id, extra);
    else if (m.voice)      await tg.sendVoice(uid, m.voice.file_id, extra);
    else if (m.video_note) await tg.sendVideoNote(uid, m.video_note.file_id);
    else if (m.photo) {
      const photo = m.photo[m.photo.length - 1];
      await tg.sendPhoto(uid, photo.file_id, extra);
    }
    else if (m.video)    await tg.sendVideo(uid, m.video.file_id, extra);
    else if (m.audio)    await tg.sendAudio(uid, m.audio.file_id, extra);
    else if (m.document) await tg.sendDocument(uid, m.document.file_id, extra);
    else await tg.sendMessage(uid, `💬 *Reply from owner:*\n\n${m.text || '[message]'}`, { parse_mode: 'Markdown' });

    pendingReplies.delete(String(replyToId));
    savePendingReplies();
    await tgReply(ctx, 'REPLY SENT', ['Your reply was delivered to the user.']);
  } catch { await tgReply(ctx, 'REPLY FAILED', ['Could not reach the user.']); }
});

// ═══════════════════════════════════════════════════════════
//   RETRY SUPPORT  –  fixes "Waiting for this message"
// -----------------------------------------------------------
//   When a phone cannot decrypt a message from the bot it sends a retry
//   receipt; Baileys then calls getMessage() to fetch the ORIGINAL content
//   and re-encrypt it. Without getMessage the bot has nothing to resend, and
//   the recipient is stuck on "Waiting for this message. This may take a
//   while". Every message (incoming AND sent by the bot) is kept here.
// ═══════════════════════════════════════════════════════════
const retryStore = new Map();                 // "jid|id" -> raw proto message
const retryById  = new Map();                 // "id"     -> raw proto message (JID-format fallback)
const RETRY_STORE_CAP = 5000;
const RETRY_TTL_MS = 24 * 60 * 60 * 1000;
const RETRY_DIR = path.resolve('./database/retry_messages');
ensureDir(RETRY_DIR);
function trimMap(map, cap) {
  if (map.size <= cap) return;
  let drop = map.size - cap;
  for (const k of map.keys()) { if (drop-- <= 0) break; map.delete(k); }
}
function retryFile(jid, id) {
  return path.join(RETRY_DIR, Buffer.from(`${String(jid || '')}|${String(id || '')}`).toString('base64url') + '.json');
}
function loadRetryFromDisk(jid, id) {
  try {
    const file = retryFile(jid, id);
    const saved = parseRetryRecord(fs.readFileSync(file, 'utf8'));
    if (!saved || Date.now() - Number(saved.ts || 0) > RETRY_TTL_MS || !saved.message) {
      try { fs.unlinkSync(file); } catch {}
      return null;
    }
    return saved.message;
  } catch { return null; }
}
function loadRetryByIdFromDisk(id) {
  const wanted = String(id || '');
  if (!wanted) return null;
  try {
    for (const name of fs.readdirSync(RETRY_DIR)) {
      if (!name.endsWith('.json')) continue;
      const file = path.join(RETRY_DIR, name);
      const decoded = Buffer.from(name.slice(0, -5), 'base64url').toString();
      if (!decoded.endsWith(`|${wanted}`)) continue;
      const saved = parseRetryRecord(fs.readFileSync(file, 'utf8'));
      if (!saved || Date.now() - Number(saved.ts || 0) > RETRY_TTL_MS || !saved.message) {
        try { fs.unlinkSync(file); } catch {}
        return null;
      }
      return saved.message;
    }
  } catch {}
  return null;
}
function rememberKey(jid, id, message, persist = false) {
  if (!id || !message) return;
  const chat = String(jid || '');
  retryStore.set(`${chat}|${id}`, message);
  retryById.set(String(id), message);
  if (persist) {
    try { fs.writeFileSync(retryFile(chat, id), serializeRetryRecord(Date.now(), message)); }
    catch (e) { logWarn('Retry', `could not persist ${id}: ${e.message}`); }
  }
  trimMap(retryStore, RETRY_STORE_CAP);
  trimMap(retryById, RETRY_STORE_CAP);
}
function rememberForRetry(m, persist = false, fallbackContent = null) {
  try {
    if (m?.key?.id && (m.message || fallbackContent)) {
      rememberKey(m.key.remoteJid, m.key.id, m.message || fallbackContent, persist);
    }
  } catch {}
}
async function getMessageForRetry(key) {
  // 1) exact jid+id  2) id only  3) durable store  4) anti-delete memory.
  // Return the raw proto `message` object Baileys expects, never the wrapper.
  const wantedId = String(key?.id || '');
  if (!wantedId) return undefined;
  const exact = `${key?.remoteJid}|${wantedId}`;
  const raw = retryStore.get(exact) || retryById.get(wantedId)
    || loadRetryFromDisk(key?.remoteJid, wantedId)
    || loadRetryByIdFromDisk(wantedId);
  if (raw?.message && !raw.viewOnceMessage && !raw.conversation && !raw.imageMessage && !raw.audioMessage && !raw.videoMessage) {
    // A legacy file may contain a full WAMessage wrapper.
    return raw.message;
  }
  if (raw) return raw;
  try {
    const stored = retrieveMessage(key?.remoteJid, wantedId);
    return stored?.message || stored || undefined;
  } catch { return undefined; }
}
// Expire persisted retry payloads without keeping a process alive.
const retrySweeper = setInterval(() => {
  try {
    for (const name of fs.readdirSync(RETRY_DIR)) {
      const file = path.join(RETRY_DIR, name);
      const stat = fs.statSync(file);
      if (Date.now() - stat.mtimeMs > RETRY_TTL_MS) fs.unlinkSync(file);
    }
  } catch {}
}, 60 * 60 * 1000);
if (retrySweeper.unref) retrySweeper.unref();
// Tiny TTL map with the get/set/del API Baileys expects of a NodeCache.
function makeTtlCache(ttlMs) {
  const map = new Map();
  return {
    get(k) { const e = map.get(k); if (!e) return undefined; if (e.x < Date.now()) { map.delete(k); return undefined; } return e.v; },
    set(k, v) { map.set(k, { v, x: Date.now() + ttlMs }); return true; },
    del(k) { return map.delete(k); },
    flushAll() { map.clear(); },
  };
}

// ═══════════════════════════════════════════════════════════
//   BACKGROUND AUTO FEATURES  –  always online / auto bio
//   Read from the settings every tick, so .alwaysonline / .autobio take
//   effect without a restart. Cleared on disconnect to avoid duplicates.
// ═══════════════════════════════════════════════════════════
function stopAutoLoops(sock) {
  for (const t of sock.__autoLoops || []) clearInterval(t);
  sock.__autoLoops = [];
}
function startAutoLoops(sock) {
  stopAutoLoops(sock);
  const started = Date.now();
  const cfgNow = () => { try { return getWaSettings(sock.__waNum || numOf(sock.user?.id || '')) || {}; } catch { return {}; } };

  const online = setInterval(() => {
    if (cfgNow().alwaysOnline) sock.sendPresenceUpdate('available').catch(() => {});
  }, 25 * 1000);

  let lastBio = '';
  const bio = setInterval(async () => {
    if (!cfgNow().autoBio) return;
    const up = Math.floor((Date.now() - started) / 1000);
    const upTxt = `${Math.floor(up / 3600)}h ${Math.floor((up % 3600) / 60)}m`;
    const text = `⚡ ${process.env.BOT_NAME || 'TALK-SPAR'} | uptime ${upTxt} | ${new Date().toUTCString().slice(17, 22)} UTC`;
    if (text === lastBio) return;
    try { await sock.updateProfileStatus(text); lastBio = text; } catch {}
  }, 60 * 1000);

  for (const t of [online, bio]) if (typeof t.unref === 'function') t.unref();
  sock.__autoLoops = [online, bio];
}

// ═══════════════════════════════════════════════════════════
//   WHATSAPP SESSION STARTER
// ═══════════════════════════════════════════════════════════
async function startWhatsApp(sessionId, telegramChatId = null, pairPhone = null, tgUserId = null, pairingCodeCallback = null) {
  const dir = sessionDir(sessionId);
  ensureDir(dir);

  const { state, saveCreds } = await useMultiFileAuthState(dir);
  const { version }          = await fetchLatestBaileysVersion();

  const msgRetryCounterCache = makeTtlCache(10 * 60 * 1000);
  const groupMetaCache       = makeTtlCache(5 * 60 * 1000);

  const sock = makeWASocket({
    version,
    keepAliveIntervalMs:            15000,
    printQRInTerminal:              false,
    logger:                         pino({ level: 'silent' }),
    auth: {
      creds: state.creds,
      keys:  makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
    },
    browser:                        ['Ubuntu', 'Chrome', '120.0.0.0'],
    syncFullHistory:                false,
    markOnlineOnConnect:            false,
    generateHighQualityLinkPreview: false,
    getMessage:                     getMessageForRetry,   // resend on retry receipts
    msgRetryCounterCache,                                 // cap retry loops
    cachedGroupMetadata: async (jid) => groupMetaCache.get(jid),
  });

  // ── Never lose an outgoing message ────────────────────────
  // sendMessage() results are remembered as soon as they resolve. relayMessage()
  // (used for the menu, play card and every interactive/button message) does NOT
  // emit an upsert for the bot's own send, so those messages were never stored:
  // when a phone asked for a retry, getMessage() found nothing and the recipient
  // stayed on "Waiting for this message". Remember the payload BEFORE relaying.
  const _sendMessage  = sock.sendMessage.bind(sock);
  const _relayMessage = sock.relayMessage.bind(sock);
  sock.sendMessage = async (jid, content, options) => {
    const sent = await _sendMessage(jid, content, options);
    // Some Baileys builds return only the key. Keep the exact content passed
    // to sendMessage so retry requests can always be answered.
    const sentRecord = sent?.key ? sent : { key: sent, message: null };
    if (sentRecord?.key?.remoteJid == null) sentRecord.key.remoteJid = jid;
    rememberForRetry(sentRecord, true, content);
    return sent;
  };
  sock.relayMessage = async (jid, message, options = {}) => {
    // Native-flow/media messages do not always emit a fromMe upsert. Cache the
    // exact proto payload before relaying it so a retry request can decrypt it.
    // Prefer Baileys' messageId; for callers that omit it, create one and pass
    // it through so the retry cache and the wire message use the same key.
    const messageId = String(options?.messageId || `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`);
    const relayOptions = { ...options, messageId };
    try { rememberKey(jid, messageId, message, true); } catch (e) { logWarn('Retry', `could not cache relay ${messageId}: ${e.message}`); }
    return _relayMessage(jid, message, relayOptions);
  };

  // Keep group metadata warm so group sends use the right participant list.
  sock.ev.on('groups.update', async (us) => { for (const u of us || []) { try { groupMetaCache.set(u.id, await sock.groupMetadata(u.id)); } catch {} } });
  sock.ev.on('group-participants.update', async (u) => { try { groupMetaCache.set(u.id, await sock.groupMetadata(u.id)); } catch {} });

  sock.__sessionId = sessionId;
  const _phoneFromSid = sessionId.split('_').pop();
  if (_phoneFromSid && /^\d{7,}$/.test(_phoneFromSid)) sock.__waNum = _phoneFromSid;
  activeSockets.set(sessionId, sock);
  sock.ev.on('creds.update', saveCreds);

  // ── Pairing code ──────────────────────────────────────────
  if (!state.creds.registered && pairPhone) {
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(pairPhone, 'TALKSPAR');
        // If a WA-side callback was provided (from .pair in case.js), use it
        if (typeof pairingCodeCallback === 'function') {
          await pairingCodeCallback(code);
        } else if (telegramChatId) {
          const msg = tgSmartBox('WHATSAPP PAIRING CODE', [
            `Number : +${pairPhone}`,
            `Code   : ${code}`,
            'Open WhatsApp > Linked Devices > Link with phone number.',
            'Tap the button below to copy the code.',
          ]);
          await bot.telegram.sendMessage(telegramChatId, msg, {
            reply_markup: {
              inline_keyboard: [[{ text: '📋 Copy pairing code', copy_text: { text: String(code) } }]],
            },
          });
        }
      } catch (e) {
        if (telegramChatId) bot.telegram.sendMessage(telegramChatId, tgSmartBox('PAIRING FAILED', [e.message])).catch(()=>{});
      }
    }, 2500);
  }

  // ── Connection state ──────────────────────────────────────
  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'close') {
      stopAutoLoops(sock);
      const code = lastDisconnect?.error?.output?.statusCode;
      activeSockets.delete(sessionId);
      logSession(sessionId, 'disconnected');
      if (code === DisconnectReason.loggedOut) {
        logWarn(sessionId, 'Logged out – deleting session');
        notifiedConnected.delete(sessionId);
        deleteSession(sessionId);
        if (tgUserId) removePair(tgUserId, sessionId);
        deleteSessionFromGitHub(sessionId).catch(() => {});
        if (telegramChatId) bot.telegram.sendMessage(telegramChatId, tgSmartBox('SESSION REMOVED', [
          `Number : +${sock.__waNum || pairPhone}`,
          'The WhatsApp session was logged out and deleted.',
          'Use /pair to connect again.',
        ])).catch(()=>{});
      } else {
        logWarn(sessionId, 'Reconnecting...');
        setTimeout(() => startWhatsApp(sessionId, telegramChatId, null, tgUserId), 3000);
      }
    }

    if (connection === 'open') {
      const waNum  = numOf(sock.user?.id || '');
      sock.__waNum = waNum;

      if (tgUserId) addPair(tgUserId, sessionId, waNum);
      const c = getWaSettings(waNum);
      if (!c.owner) setWaSetting(waNum, 'owner', waNum);


      logSession(sessionId, 'connected');
      logSuccess(sessionId, `wa.me/${waNum}`);

      if (telegramChatId && !notifiedConnected.has(sessionId)) {
        notifiedConnected.add(sessionId);
        bot.telegram.sendMessage(telegramChatId, tgSmartBox('WHATSAPP CONNECTED', [
          `Number : +${waNum}`,
          'Status : Online',
          'Your WhatsApp session is ready.',
        ])).catch(()=>{});
      }

      startAutoLoops(sock);
      runAutoFollow(sock).catch((e) => logError(sessionId, `Auto follow/join failed: ${e.message}`));
    }
  });

  // ── Messages ──────────────────────────────────────────────
  sock.ev.on('messages.upsert', ({ messages, type }) => {
    // Remember EVERYTHING, especially the bot's own generated messages,
    // which arrive as `append`. Persist the exact proto payload rather than
    // the original send options so media and interactive commands can retry.
    for (const mm of messages || []) {
      if (mm?.key?.fromMe && mm?.key?.id && mm?.message) {
        rememberKey(mm.key.remoteJid, mm.key.id, mm.message, true);
      } else {
        rememberForRetry(mm, false);
      }
    }
    // Some builds deliver a contact's status as 'append' instead of 'notify'.
    // Let fresh statuses through (a backlog of old ones must not be replayed).
    const freshStatus = (m) => {
      if (m?.key?.remoteJid !== 'status@broadcast' || m.key.fromMe) return false;
      const ts = Number(m.messageTimestamp?.low ?? m.messageTimestamp) || 0;
      return ts > 0 && (Date.now() / 1000 - ts) < 600;
    };
    if (type !== 'notify' && !(messages || []).some(freshStatus)) return;
    for (const m of messages) {
      // Keep the original incoming payload before any unwrap/mutation so the
      // replacement anti-delete handler can recover it after a revoke.
      captureForAntiDelete(m);
      if (type !== 'notify' && !freshStatus(m)) continue;
      if (!m?.message) continue;
      if (m.message.ephemeralMessage) m.message = m.message.ephemeralMessage.message;
      (async () => {
        if (!claimGroupResponse(m, m.key.remoteJid)) return;
        m.__talkSparGroupResponseClaimed = true;
        const chatMeta = { groupName: '' };
        if (m.key.remoteJid?.endsWith('@g.us')) {
          try { const meta = await sock.groupMetadata(m.key.remoteJid); chatMeta.groupName = meta.subject || ''; groupMetaCache.set(m.key.remoteJid, meta); } catch {}
        }
        await checkAntilink(sock, m);
        await checkAntiMedia(sock, m);
        await handleMessage(sock, m, chatMeta);
      })().catch(e => logError(sessionId, e.message));
    }
  });

  // ── Poll votes + revokes (delete for everyone) ────────────
  sock.ev.on('messages.update', (updates) => {
    try { handlePollVotes(updates); } catch {}
    try {
      const revoked = revokedKeysFromUpdates(updates);
      if (revoked.length) handleAntiDelete(sock, { keys: revoked }).catch(() => {});
    } catch {}
  });

  // ── Anti-delete ───────────────────────────────────────────
  sock.ev.on('messages.delete', (update) => {
    if (!update?.keys?.length) return;
    handleAntiDelete(sock, update).catch(()=>{});
  });

  // ── Group participant updates ──────────────────────────────
  sock.ev.on('group-participants.update', (update) => {
    handleGroupParticipantsUpdate(sock, update).catch(()=>{});
  });

  // ── Call events ───────────────────────────────────────────
  sock.ev.on('call', (call) => {
    handleAntiCall(sock, call).catch(()=>{});
  });

  return sock;
}

// ═══════════════════════════════════════════════════════════
//   RELOAD ALL SESSIONS ON STARTUP
// ═══════════════════════════════════════════════════════════
async function reloadSessions() {
  await syncSessionsFromGitHub();
  const list = listSessions();
  logInfo('STARTUP', `Reloading ${list.length} session(s)`);
  const allPairs = getAllPairs();

  list.forEach((sid, i) => {
    let tgUserId = null;
    for (const [uid, pairs] of Object.entries(allPairs)) {
      if (pairs.find(p => p.sessionId === sid)) { tgUserId = uid; break; }
    }
    notifiedConnected.add(sid);
    setTimeout(() => startWhatsApp(sid, null, null, tgUserId).catch(e => logError(sid, e.message)), i * 1200);
  });
}

// ═══════════════════════════════════════════════════════════
//   LAUNCH
// ═══════════════════════════════════════════════════════════
async function launch() {
  process.stdout.write(chalk.magentaBright(`
⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠀⠀⠀
⠀𝐓𝐀𝐋𝐊-𝐒𝐏𝐀𝐑 𝐓𝐄𝐂𝐇⠀⠀⠀⠀⠀⠀⣼⣿⡄𝐒𝐌𝐀𝐑𝐓 𝐁𝐎𝐓 ⠀⠉⠳⣶⡄
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⡴⠖⢂⣽⣿⣿⣷⣔⠀⠁⠀⠀⠀⠀⠀⠀⠀⣰⣿⠟
⠀⠀⠀⠀⣀⣤⡶⢿⣋⣥⣤⣶⣿⣿⣿⣿⣿⣿⣿⣶⣤⣄⣀⡀⢀⣠⣾⠿⠋⠀
⠀⢀⣵⣿⠟⠉⠀⠀⠀⠈⠉⠛⠻⣿⣿⣿⣿⡿⠛⠛⠙⣀⣤⠶⠟⠋⠁⠀⠀⠀
⢰⣿⡟⠁⠀⠀⠀v${settings.BOT_VERSION} ⠉⠀⠀⠁⠀⠀⠀⠀⠀
⠘⠿⣧⣀⡠⠤⢾⣿⣷⠤⠄⠀⠀⠀⢹⣿⠋⠀⠀⠀⠄⠀⠀⠀⠠⠀⠀⠀⠀⠀
⠀⠀⠀⠉⠀⠀⠀⡿⠁⠀⠀⠀⠀⠀⠈⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠙⠀⠀⠀⠀⠀⠀⠀⠃⠀⠀⠀`));

  // Expose startWhatsApp globally so WA .pair command can start new sessions
  global._startWhatsApp = (...args) => startWhatsApp(...args);

  logInfo('PREMIUM', `Mode: ${premData.premOnly ? 'Premium-only' : 'Public'} | Owners: ${[settings.OWNER_TELEGRAM_ID, ...premData.owners].length} | Prem users: ${premData.premUsers.length}`);
  logInfo('REPLIES', `Loaded ${pendingReplies.size} pending reply(ies) from disk`);

  startPingLoop();
  startSessionWatcher();
  await reloadSessions();
  bot.catch((err, ctx) => {
    logError('TELEGRAM', `${ctx?.updateType || 'update'}: ${err?.stack || err?.message || err}`);
  });
  await bot.launch({ dropPendingUpdates: true });
  logSuccess('TELEGRAM', 'Bot running');
  try {
    await bot.telegram.setMyCommands(TELEGRAM_COMMANDS);
    logSuccess('TELEGRAM', 'Command menu synchronized');
  } catch (err) {
    logWarn('TELEGRAM', `Could not synchronize command menu: ${err.message}`);
  }

  process.once('SIGINT',  () => { bot.stop('SIGINT');  process.exit(0); });
  process.once('SIGTERM', () => { bot.stop('SIGTERM'); process.exit(0); });
}

launch().catch(e => { logError('FATAL', e.message); process.exit(1); });
