#!/usr/bin/env node
"use strict";
/**
 * Pairing helper, spawned by the supervisor as:
 *
 *   node pair.js <phone-number> <instance-dir>
 *
 * Prints machine-readable lines the supervisor greps:
 *   PAIR_CODE:ABCD1234
 *   PAIRED:2547xxxxxxxx@s.whatsapp.net
 *   FAILED:<reason>
 *
 * Credentials land in <instance-dir>/session via useMultiFileAuthState, which is
 * exactly where the per-instance bot process looks for them.
 */

const path = require("path");
const fs = require("fs");

const number = String(process.argv[2] || "").replace(/\D/g, "");
const instDir = process.argv[3];

if (!number || !instDir) {
  console.log("FAILED:usage: node pair.js <number> <instance-dir>");
  process.exit(2);
}

const sessionDir = path.join(instDir, "session");
fs.mkdirSync(sessionDir, { recursive: true });

let baileys;
try {
  baileys = require("baileys");
} catch (e) {
  console.log("FAILED:baileys not installed — run npm install");
  process.exit(2);
}

const makeWASocket = baileys.default || baileys.makeWASocket;
const { useMultiFileAuthState, fetchLatestBaileysVersion, Browsers, delay, DisconnectReason } =
  baileys;

const HARD_TIMEOUT = 4 * 60 * 1000;
const timer = setTimeout(() => {
  console.log("FAILED:pairing timed out (4 min) — code expired");
  process.exit(1);
}, HARD_TIMEOUT);

(async () => {
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  let version;
  try {
    ({ version } = await fetchLatestBaileysVersion());
  } catch {
    version = undefined;
  }

  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    browser: Browsers ? Browsers.ubuntu("Chrome") : ["Ubuntu", "Chrome", "120.0.0"],
    markOnlineOnConnect: false,
    syncFullHistory: false,
  });

  sock.ev.on("creds.update", saveCreds);

  if (!sock.authState.creds.registered) {
    try {
      const code = await sock.requestPairingCode(number);
      console.log("PAIR_CODE:" + code);
    } catch (err) {
      console.log("FAILED:" + err.message);
      clearTimeout(timer);
      process.exit(1);
    }
  }

  sock.ev.on("connection.update", async (u) => {
    const { connection, lastDisconnect } = u;
    if (connection === "open") {
      await delay(1200);
      console.log("PAIRED:" + (sock.user?.id || ""));
      clearTimeout(timer);
      process.exit(0);
    }
    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code === DisconnectReason.loggedOut) {
        console.log("FAILED:logged out");
        clearTimeout(timer);
        process.exit(1);
      }
      // otherwise let baileys reconnect while the code is still valid
    }
  });
})().catch((e) => {
  console.log("FAILED:" + (e && e.message));
  clearTimeout(timer);
  process.exit(1);
});
