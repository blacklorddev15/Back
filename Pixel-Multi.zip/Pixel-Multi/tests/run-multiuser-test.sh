#!/usr/bin/env bash
# End-to-end test of the multi-user panel without WhatsApp or baileys:
# real server.js, real store + supervisor, fake pairer and fake bot children.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
SB="${TMPDIR:-/tmp}/px-mu-test-$$"
mkdir -p "$SB/template"
cp -r "$ROOT/server.js" "$ROOT/pair.js" "$ROOT/multiuser" "$SB/"
cp -r "$ROOT/template/database" "$SB/template/database"
node -e '
const fs=require("fs");
fs.writeFileSync(process.argv[1]+"/template/database/settings.json",JSON.stringify({mode:"public",prefix:"."},null,2));
' "$SB"

PORT=3999 PANEL_KEY=t3st BOT_ENTRY="$HERE/fake-bot.js" PAIR_ENTRY="$HERE/fake-pairer.js" MAX_SESSIONS=2 \
  node "$SB/server.js" > "$SB/panel.log" 2>&1 &
PANEL=$!
trap 'kill $PANEL 2>/dev/null' EXIT
for _ in $(seq 1 40); do curl -sf "http://127.0.0.1:3999/healthz" >/dev/null && break; sleep 0.25; done

H=(-H "x-panel-key: t3st" -H "Content-Type: application/json")
echo "--- unauthorised request (no key)"
curl -s "http://127.0.0.1:3999/api/sessions"; echo

echo "--- pair 254700000001"
curl -s "${H[@]}" -X POST -d '{"number":"254700000001"}' http://127.0.0.1:3999/api/pair; echo
echo "--- pair 254700000002"
curl -s "${H[@]}" -X POST -d '{"number":"254700000002"}' http://127.0.0.1:3999/api/pair; echo
echo "--- third number must hit the limit"
curl -s "${H[@]}" -X POST -d '{"number":"254700000003"}' http://127.0.0.1:3999/api/pair; echo

sleep 2
echo "--- sessions"
curl -s "${H[@]}" http://127.0.0.1:3999/api/sessions | node -e '
let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{
  for(const x of JSON.parse(s).sessions) console.log(x.id,"+"+x.number,"status="+x.status,"running="+x.running,"port="+x.port);
});'

echo "--- each instance has its own settings.json (different inode + content)"
for d in "$SB"/instances/*/; do
  echo "$(basename "$d") prefix=$(node -p "require('$d/database/settings.json').prefix") inode=$(stat -c %i "$d/database/settings.json")"
done

echo "--- write different settings into each instance and confirm no bleed"
i=0
for d in "$SB"/instances/*/; do
  i=$((i+1))
  node -e '
    const fs=require("fs");const f=process.argv[1]+"/database/settings.json";
    const j=JSON.parse(fs.readFileSync(f,"utf8")); j.prefix=".p"+process.argv[2]; j.antilink=true;
    fs.writeFileSync(f,JSON.stringify(j,null,2));
  ' "$d" "$i"
done
for d in "$SB"/instances/*/; do
  echo "$(basename "$d") -> $(node -p "require('$d/database/settings.json').prefix")"
done

echo "--- child cwd markers"
for f in "$SB"/instances/*/boot.txt; do cat "$f"; echo; done

echo "--- stop one, the other must keep running"
FIRST=$(basename "$(ls -d "$SB"/instances/*/ | head -1)")
curl -s "${H[@]}" -X POST "http://127.0.0.1:3999/api/sessions/$FIRST/stop" >/dev/null
sleep 0.8
curl -s "${H[@]}" http://127.0.0.1:3999/api/sessions | node -e '
let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{
  for(const x of JSON.parse(s).sessions) console.log(x.id,"running="+x.running,"status="+x.status);
});'

echo "--- logs endpoint"
curl -s "${H[@]}" "http://127.0.0.1:3999/api/sessions/$FIRST/logs" | head -c 220; echo

echo "--- delete first session"
curl -s "${H[@]}" -X DELETE "http://127.0.0.1:3999/api/sessions/$FIRST" >/dev/null
if [ -d "$SB/instances/$FIRST" ]; then echo "dir still present (FAIL)"; else echo "dir removed (ok)"; fi

echo "--- panel log"
tail -4 "$SB/panel.log"
