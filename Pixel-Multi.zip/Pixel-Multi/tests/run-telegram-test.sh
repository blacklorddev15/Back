#!/usr/bin/env bash
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
SB="${TMPDIR:-/tmp}/px-tg-test-$$"
mkdir -p "$SB/template"
cp -r "$ROOT/server.js" "$ROOT/pair.js" "$ROOT/multiuser" "$ROOT/tests" "$SB/"
cp -r "$ROOT/template/database" "$SB/template/database"
cd "$SB"
BOT_ENTRY="$HERE/fake-bot.js" PAIR_ENTRY="$HERE/fake-pairer.js" node tests/telegram-test.js
