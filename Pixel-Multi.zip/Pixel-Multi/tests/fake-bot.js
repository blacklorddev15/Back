// Stand-in for index.js: proves cwd isolation, then behaves per FAKE_MODE.
const fs = require("fs");
const path = require("path");
const dir = process.cwd();
const settings = (() => {
  try { return JSON.parse(fs.readFileSync("./database/settings.json", "utf8")); }
  catch { return null; }
})();
fs.writeFileSync(path.join(dir, "boot.txt"), JSON.stringify({ dir, prefix: settings && settings.prefix }));
console.log("[fake] booted in", dir, "prefix=", settings && settings.prefix, "port=", process.env.PORT);
if (process.env.FAKE_MODE === "crash") process.exit(7);
if (process.env.FAKE_MODE === "crash-later") setTimeout(() => process.exit(9), 600);
setInterval(() => {}, 1000);
