#!/usr/bin/env node
"use strict";
/**
 * Telegram surface test — real control layer, real store, fake pairer/bot.
 * Run from a sandbox root that already has multiuser/, template/ and the fakes.
 */
const assert = require("assert");
const control = require("../multiuser/control");
const { createHandlers } = require("../multiuser/telegram");

const replies = [];
const mkCtx = (id) => ({
  from: { id },
  reply: async (text) => {
    replies.push(text);
    return { message_id: replies.length };
  },
});
const last = () => replies[replies.length - 1] || "";

const user = mkCtx(111);
const stranger = mkCtx(222);
const admin = mkCtx(999);

const h = createHandlers({ control, adminIds: ["999"] });

(async () => {
  let pass = 0;
  const ok = (label, cond, extra = "") => {
    if (!cond) {
      console.error("FAIL:", label, extra ? "\n  " + extra : "");
      process.exitCode = 1;
    } else {
      pass++;
      console.log("ok  ", label);
    }
  };

  // ── help ──────────────────────────────────────────────────────────────
  await h.help(user);
  ok("help lists /pair and /sessions", /\/pair/.test(last()) && /\/sessions/.test(last()));

  // ── bad input ────────────────────────────────────────────────────────
  await h.pair(user, "hello");
  ok("rejects a non-number", /international format/.test(last()), last());

  // ── real pairing through the fake pairer ─────────────────────────────
  await h.pair(user, "254700000101");
  const codeMsg = replies[replies.length - 2] || "";
  const answer = last();
  ok("returns a pairing code", /TEST0101/.test(codeMsg + answer), codeMsg + " | " + answer);

  await new Promise((r) => setTimeout(r, 1600));

  // ── listing shows it, running ────────────────────────────────────────
  await h.sessions(user);
  ok("user sees own number", /254700000101/.test(last()) && /running/.test(last()), last());

  // ── another telegram account sees nothing of it ──────────────────────
  await h.sessions(stranger);
  ok("stranger sees no sessions", /no numbers paired/i.test(last()), last());

  const mine = control.listFor("tg:111");
  const short = mine[0].id.split("_").pop();

  await h.stop(stranger, short);
  ok("stranger cannot stop it", /No session of yours/.test(last()), last());

  await h.stop(user, short);
  ok("owner stops it", /stopped .*254700000101/i.test(last()), last());

  await h.resume(user, short);
  ok("owner starts it", /started .*254700000101/i.test(last()), last());

  await h.logs(user, short);
  ok("logs come back fenced", /```/.test(last()), last().slice(0, 80));

  // ── admin surface ────────────────────────────────────────────────────
  await h.all(user);
  ok("non-admin cannot list everything", /Owner only/.test(last()), last());
  await h.all(admin);
  ok("admin lists everything", /254700000101/.test(last()), last());
  await h.stats(admin);
  ok("stats reports running count", /Sessions: 1/.test(last()), last());

  // ── delete wipes the instance ────────────────────────────────────────
  await h.del(user, short);
  ok("owner deletes", /Removed/.test(last()), last());
  ok("no sessions afterwards", control.listFor("tg:111").length === 0);

  console.log(`\n${pass} checks passed`);
  process.exit(process.exitCode || 0);
})().catch((e) => {
  console.error("ERROR", e);
  process.exit(1);
});
