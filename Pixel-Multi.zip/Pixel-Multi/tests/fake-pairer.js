// Stand-in for pair.js: emits a code, writes fake creds, then reports PAIRED.
const fs = require("fs");
const path = require("path");
const [, , number, instDir] = process.argv;
console.log("PAIR_CODE:TEST" + String(number).slice(-4));
setTimeout(() => {
  const dir = path.join(instDir, "session");
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(
    path.join(dir, "creds.json"),
    JSON.stringify({ me: { id: number + ":1@s.whatsapp.net" }, registered: true }),
  );
  console.log("PAIRED:" + number + "@s.whatsapp.net");
  process.exit(0);
}, 400);
