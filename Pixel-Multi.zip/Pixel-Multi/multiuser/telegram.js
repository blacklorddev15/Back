"use strict";
/**
 * Telegram front end — the surface users pair from.
 *
 * A Telegram user sends their WhatsApp number to the bot, receives an
 * 8-character pairing code, types it into WhatsApp, and gets a confirmation the
 * moment the instance goes live. Everything is keyed by `tg:<telegram id>`, so
 * one Telegram account only ever sees the numbers it paired itself.
 *
 * Handlers are plain functions so they can be tested without a live bot.
 */

const control = require("./control");

const STATUS_ICON = {
  running: "🟢",
  stopped: "⚪️",
  restarting: "🟡",
  crashed: "🔴",
  pairing: "🔵",
  "awaiting-pairing": "🔵",
  "pairing-failed": "🔴",
};

function ownerKeyOf(ctx) {
  return `tg:${ctx.from.id}`;
}

function isAdmin(ctx, adminIds) {
  return adminIds.includes(String(ctx.from.id));
}

function shortId(rec) {
  return rec.id.split("_").slice(-1)[0];
}

function statusLine(rec) {
  const icon = STATUS_ICON[rec.status] || (rec.running ? "🟢" : "⚪️");
  const state = rec.running ? "running" : rec.status || "stopped";
  return `${icon} +${rec.number} · ${state}${rec.running && rec.uptime ? ` · ${rec.uptime}s` : ""} · \`${shortId(rec)}\``;
}

function createHandlers({ controlApi = control, adminIds = [], maxPerUser }) {
  const limit = maxPerUser || controlApi.MAX_PER_USER;

  const help = async (ctx) => {
    await ctx.reply(
      [
        "*Pixel — pair your number*",
        "",
        "1️⃣ Send your WhatsApp number in international format, digits only:",
        "`254712345678`",
        "2️⃣ I reply with an 8-character code.",
        "3️⃣ WhatsApp → Settings → Linked devices → Link with phone number → type the code.",
        "",
        "*Commands*",
        "/pair <number> — start pairing",
        "/sessions — your numbers and their state",
        "/stop <id> — pause one",
        "/start <id> — resume one",
        "/restart <id> — restart one",
        "/logs <id> — last lines of its console",
        "/delete <id> — remove it and its data",
        "",
        `Up to ${limit} numbers per Telegram account.`,
      ].join("\n"),
      { parse_mode: "Markdown" },
    );
  };

  const start = async (ctx) => help(ctx);

  const pair = async (ctx, rawNumber) => {
    const owner = ownerKeyOf(ctx);
    const text = String(rawNumber || "").trim();
    if (!text) {
      return ctx.reply("Send the number like: `/pair 254712345678`", { parse_mode: "Markdown" });
    }
    await ctx.reply("⏳ Requesting a pairing code…");
    const res = await controlApi.pair(text, owner);
    if (!res.ok) {
      return ctx.reply(`❌ ${res.error}`);
    }
    if (res.code) {
      return ctx.reply(
        [
          "*Your pairing code*",
          "",
          `\`${res.code}\``,
          "",
          "WhatsApp → Settings → Linked devices → Link with phone number",
          "Type the 8 characters exactly. The code expires in about 90 seconds.",
          "",
          "I'll confirm here as soon as the bot is online.",
        ].join("\n"),
        { parse_mode: "Markdown" },
      );
    }
    if (res.paired) return ctx.reply("✅ Paired and running.");
    return ctx.reply("⏳ Waiting for WhatsApp to confirm the code…");
  };

  const sessions = async (ctx) => {
    const mine = controlApi.listFor(ownerKeyOf(ctx));
    if (!mine.length) {
      return ctx.reply("You have no numbers paired yet. Send your number to start.");
    }
    const lines = mine.map(statusLine);
    await ctx.reply(["*Your sessions*", "", ...lines].join("\n"), { parse_mode: "Markdown" });
  };

  const withTarget = (fn, verb) => async (ctx, arg) => {
    const owner = ownerKeyOf(ctx);
    const token = String(arg || "").trim();
    if (!token) return ctx.reply("Which one? Use /sessions to see the 4-character id.");
    const rec = controlApi.findByShort(owner, token);
    if (!rec) return ctx.reply("❌ No session of yours matches that id.");
    const res = fn(rec.id, owner);
    if (!res || res.ok === false) return ctx.reply(`❌ ${(res && res.error) || "failed"}`);
    return ctx.reply(`✅ ${verb} +${rec.number}`);
  };

  const stop = async (ctx, arg) => withTarget(controlApi.stop, "stopped")(ctx, arg);
  const resume = async (ctx, arg) => withTarget(controlApi.start, "started")(ctx, arg);
  const restart = async (ctx, arg) => withTarget(controlApi.restart, "restarting")(ctx, arg);

  const del = async (ctx, arg) => {
    const owner = ownerKeyOf(ctx);
    const token = String(arg || "").trim();
    if (!token) return ctx.reply("Which one? Use /sessions to see the 4-character id.");
    const rec = controlApi.findByShort(owner, token);
    if (!rec) return ctx.reply("❌ No session of yours matches that id.");
    const res = controlApi.remove(rec.id, owner);
    if (!res.ok) return ctx.reply(`❌ ${res.error}`);
    return ctx.reply(`🗑 Removed +${rec.number} and its data.`);
  };

  const logs = async (ctx, arg) => {
    const owner = ownerKeyOf(ctx);
    const rec = controlApi.findByShort(owner, String(arg || "").trim());
    if (!rec) return ctx.reply("❌ No session of yours matches that id.");
    const res = controlApi.logs(rec.id, owner, 2500);
    if (!res.ok) return ctx.reply(`❌ ${res.error}`);
    const body = (res.log || "(no output yet)").slice(-2500);
    return ctx.reply(`\`\`\`\n${body}\n\`\`\``, { parse_mode: "Markdown" });
  };

  const all = async (ctx) => {
    if (!isAdmin(ctx, adminIds)) return ctx.reply("Owner only.");
    const list = controlApi.listAll();
    if (!list.length) return ctx.reply("No sessions on this server.");
    const lines = list.map((r) => `${statusLine(r)} · ${r.ownerKey || "—"}`);
    return ctx.reply(
      [`*All sessions* (${list.length}/${controlApi.MAX_GLOBAL})`, "", ...lines].join("\n"),
      { parse_mode: "Markdown" },
    );
  };

  const stats = async (ctx) => {
    if (!isAdmin(ctx, adminIds)) return ctx.reply("Owner only.");
    const list = controlApi.listAll();
    const running = list.filter((r) => r.running).length;
    return ctx.reply(
      `Sessions: ${list.length}/${controlApi.MAX_GLOBAL}\nRunning: ${running}\nIdle: ${list.length - running}`,
    );
  };

  return { help, start, pair, sessions, stop, resume, restart, del, logs, all, stats };
}

/** Wire the handlers to a Telegraf bot and start polling. */
function launch({ token, adminIds = [] }) {
  const { Telegraf } = require("telegraf");
  const bot = new Telegraf(token);
  const h = createHandlers({ control, adminIds });

  bot.start((ctx) => h.start(ctx));
  bot.help((ctx) => h.help(ctx));
  bot.command("pair", (ctx) => h.pair(ctx, ctx.message.text.split(/\s+/).slice(1).join(" ")));
  bot.command("sessions", (ctx) => h.sessions(ctx));
  bot.command("mine", (ctx) => h.sessions(ctx));
  bot.command("stop", (ctx) => h.stop(ctx, ctx.message.text.split(/\s+/)[1]));
  bot.command("start", (ctx) => h.resume(ctx, ctx.message.text.split(/\s+/)[1]));
  bot.command("restart", (ctx) => h.restart(ctx, ctx.message.text.split(/\s+/)[1]));
  bot.command("delete", (ctx) => h.del(ctx, ctx.message.text.split(/\s+/)[1]));
  bot.command("logs", (ctx) => h.logs(ctx, ctx.message.text.split(/\s+/)[1]));
  bot.command("all", (ctx) => h.all(ctx));
  bot.command("stats", (ctx) => h.stats(ctx));

  // Bare phone number = pair it, the way most people will actually use this.
  bot.on("text", async (ctx) => {
    const text = String(ctx.message.text || "").trim();
    // Commands are handled above; Telegraf runs every matching middleware, so
    // without this guard /pair would also get the fallback reply.
    if (text.startsWith("/")) return;
    if (/^\+?\d{8,15}$/.test(text)) return h.pair(ctx, text);
    return ctx.reply("Send a WhatsApp number to pair, or /help for the command list.");
  });

  // Tell the user the moment their bot comes online, however long pairing took.
  control.events.on("paired", async (rec) => {
    const chatId = String(rec.ownerKey || "").replace(/^tg:/, "");
    if (!chatId) return;
    try {
      await bot.telegram.sendMessage(chatId, `✅ +${rec.number} is paired and online.`);
    } catch {}
  });
  control.events.on("pair-failed", async (rec, error) => {
    const chatId = String(rec.ownerKey || "").replace(/^tg:/, "");
    if (!chatId) return;
    try {
      await bot.telegram.sendMessage(chatId, `❌ Pairing +${rec.number} failed: ${error}`);
    } catch {}
  });

  bot.launch().then(() => console.log("[telegram] polling started"));
  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
  return bot;
}

module.exports = { createHandlers, launch };
