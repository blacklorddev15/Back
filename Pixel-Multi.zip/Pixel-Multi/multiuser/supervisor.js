"use strict";
/**
 * Process supervisor — one independent bot process per paired number.
 *
 * Why processes and not one socket per session inside a single process: Pixel's
 * handler keeps its settings in module-level globals (22 `global.*` reads) and
 * its state in ./database JSON files. Two sessions sharing that process would
 * share the anti-link and auto-* values. A child process per session, started
 * with its own cwd, makes the isolation physical instead of a refactor promise.
 *
 * Isolation also buys crash isolation and per-user restarts.
 */

const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const store = require("./store");

const LOG_CAP = 200 * 1024;
const MAX_RESTARTS = 5;
const RESTART_WINDOW_MS = 10 * 60 * 1000;

const children = new Map(); // id -> { proc, startedAt, restarts: [ts] }

function tailFile(file, bytes = 8000) {
  try {
    const st = fs.statSync(file);
    const start = Math.max(0, st.size - bytes);
    const fd = fs.openSync(file, "r");
    const buf = Buffer.alloc(Math.min(bytes, st.size));
    fs.readSync(fd, buf, 0, buf.length, start);
    fs.closeSync(fd);
    return buf.toString("utf8");
  } catch {
    return "";
  }
}

function appendLog(id, chunk) {
  const file = store.logPath(id);
  try {
    const st = fs.existsSync(file) ? fs.statSync(file) : { size: 0 };
    if (st.size > LOG_CAP) fs.writeFileSync(file, "");
    fs.appendFileSync(file, chunk);
  } catch {}
}

function isRunning(id) {
  const c = children.get(id);
  return !!(c && c.proc && c.proc.exitCode === null && !c.proc.killed);
}

function start(id) {
  const rec = store.get(id);
  if (!rec) return { ok: false, error: "unknown session" };
  if (isRunning(id)) return { ok: true, already: true };

  if (!store.hasCreds(id)) {
    store.update(id, { status: "awaiting-pairing" });
    return { ok: false, error: "no credentials yet — pair the number first" };
  }

  const dir = store.instanceDir(id);
  fs.mkdirSync(dir, { recursive: true });
  const logFile = store.logPath(id);
  const out = fs.openSync(logFile, "a");

  const entry = process.env.BOT_ENTRY || path.join(store.ROOT, "index.js");
  const proc = spawn(process.execPath, [entry], {
    cwd: dir,
    env: {
      ...process.env,
      PORT: String(rec.port),
      INSTANCE_ID: id,
      BOT_NAME: "Pixel",
      SESSION_DIR: path.join(dir, "session"),
    },
    stdio: ["ignore", out, out],
  });

  children.set(id, { proc, startedAt: Date.now(), restarts: children.get(id)?.restarts || [] });
  store.update(id, { status: "running", pid: proc.pid, startedAt: new Date().toISOString() });

  proc.on("exit", (code, signal) => {
    appendLog(id, `\n[supervisor] exited code=${code} signal=${signal}\n`);
    const entry = children.get(id);
    if (entry) entry.proc = null;

    if (entry && entry.stopping) {
      store.update(id, { status: "stopped", pid: null });
      return;
    }

    const now = Date.now();
    entry.restarts = (entry.restarts || []).filter((t) => now - t < RESTART_WINDOW_MS);
    if (entry.restarts.length >= MAX_RESTARTS) {
      store.update(id, { status: "crashed", pid: null, lastExit: code });
      appendLog(id, `[supervisor] giving up after ${MAX_RESTARTS} restarts in 10 min\n`);
      return;
    }
    entry.restarts.push(now);
    store.update(id, { status: "restarting", pid: null, restarts: entry.restarts.length });
    const wait = Math.min(15000, 2000 * entry.restarts.length);
    setTimeout(() => {
      if (store.get(id)?.status === "restarting") start(id);
    }, wait);
  });

  proc.on("error", (err) => {
    appendLog(id, `\n[supervisor] spawn error: ${err.message}\n`);
    store.update(id, { status: "crashed" });
  });

  return { ok: true, pid: proc.pid };
}

function stop(id) {
  const entry = children.get(id);
  if (!entry || !entry.proc) {
    store.update(id, { status: "stopped", pid: null });
    return { ok: true, already: true };
  }
  entry.stopping = true;
  try {
    entry.proc.kill("SIGTERM");
  } catch {}
  setTimeout(() => {
    try {
      if (entry.proc && entry.proc.exitCode === null) entry.proc.kill("SIGKILL");
    } catch {}
  }, 5000);
  return { ok: true };
}

function restart(id) {
  stop(id);
  setTimeout(() => start(id), 1500);
  return { ok: true };
}

/** Boot every session that has credentials. Called once at startup. */
function bootAll() {
  const started = [];
  for (const rec of store.list()) {
    if (rec.status === "deleted") continue;
    if (!store.hasCreds(rec.id)) {
      store.update(rec.id, { status: "awaiting-pairing" });
      continue;
    }
    const res = start(rec.id);
    if (res.ok) started.push(rec.id);
  }
  return started;
}

function statusOf(id) {
  const rec = store.get(id);
  const running = isRunning(id);
  return {
    ...rec,
    running,
    uptime: running ? Math.round((Date.now() - children.get(id).startedAt) / 1000) : 0,
  };
}

module.exports = { start, stop, restart, bootAll, isRunning, statusOf, tailFile, appendLog };
