"use strict";
/**
 * Session store for the multi-user supervisor.
 *
 * Every paired number gets its own directory:
 *
 *   instances/<id>/
 *     database/   copy of template/database — settings, anti-*, auto-*, welcome
 *     session/    baileys creds (written by pair.js)
 *     .env        per-instance env (PORT, BOT_NAME)
 *     run.log     capped stdout/stderr of that instance
 *
 * Because each bot process is started with cwd = instances/<id>, every
 * `fs.readFileSync("./database/...")` inside Pixel.js lands in that instance's
 * own database. That is what keeps one user's anti-link / auto-* values from
 * ever touching another's — there is no shared in-memory state at all.
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const ROOT = path.join(__dirname, "..");
const DATA_DIR = path.join(ROOT, "data");
const INSTANCES = path.join(ROOT, "instances");
const STORE = path.join(DATA_DIR, "sessions.json");
const TEMPLATE_DB = path.join(ROOT, "template", "database");

function ensureDirs() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(INSTANCES, { recursive: true });
}

function readAll() {
  try {
    const raw = JSON.parse(fs.readFileSync(STORE, "utf8"));
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

function writeAll(list) {
  ensureDirs();
  const tmp = STORE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(list, null, 2));
  fs.renameSync(tmp, STORE);
}

function newId(number) {
  const tail = String(number).replace(/\D/g, "").slice(-4) || "0000";
  return `px_${tail}_${crypto.randomBytes(3).toString("hex")}`;
}

function instanceDir(id) {
  return path.join(INSTANCES, id);
}

function sessionDir(id) {
  return path.join(instanceDir(id), "session");
}

function hasCreds(id) {
  const f = path.join(sessionDir(id), "creds.json");
  try {
    const j = JSON.parse(fs.readFileSync(f, "utf8"));
    return !!(j && j.me && j.me.id);
  } catch {
    return false;
  }
}

/** Pristine per-instance filesystem: template database + empty session dir. */
function materialise(id, port) {
  const dir = instanceDir(id);
  const db = path.join(dir, "database");
  fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(db)) {
    if (!fs.existsSync(TEMPLATE_DB)) {
      throw new Error("template/database is missing from the build");
    }
    fs.cpSync(TEMPLATE_DB, db, { recursive: true });
  }
  fs.mkdirSync(path.join(dir, "session"), { recursive: true });
  const envPath = path.join(dir, ".env");
  if (!fs.existsSync(envPath)) {
    fs.writeFileSync(
      envPath,
      [
        "BOT_NAME=Pixel",
        "OWNER_NAME=Pixel",
        `PORT=${port}`,
        "TZ=Africa/Nairobi",
        "",
      ].join("\n"),
    );
  }
  return dir;
}

function list() {
  return readAll();
}

function get(id) {
  return readAll().find((s) => s.id === id) || null;
}

function create({ number, port, ownerKey = "" }) {
  ensureDirs();
  const clean = String(number).replace(/\D/g, "");
  if (!clean) throw new Error("phone number required");
  const all = readAll();
  if (all.some((s) => s.number === clean && s.status !== "deleted")) {
    throw new Error(`${clean} is already paired`);
  }
  const max = Number(process.env.MAX_SESSIONS || 10);
  if (all.filter((s) => s.status !== "deleted").length >= max) {
    throw new Error(`session limit reached (${max})`);
  }
  const rec = {
    id: newId(clean),
    number: clean,
    ownerKey: String(ownerKey || ""),
    createdAt: new Date().toISOString(),
    status: "pairing",
    port,
    restarts: 0,
  };
  materialise(rec.id, port);
  all.push(rec);
  writeAll(all);
  return rec;
}

function update(id, patch) {
  const all = readAll();
  const i = all.findIndex((s) => s.id === id);
  if (i < 0) return null;
  all[i] = { ...all[i], ...patch };
  writeAll(all);
  return all[i];
}

function remove(id, { keepFiles = false } = {}) {
  const all = readAll().filter((s) => s.id !== id);
  writeAll(all);
  if (!keepFiles) {
    try {
      fs.rmSync(instanceDir(id), { recursive: true, force: true });
    } catch {}
  }
}

function logPath(id) {
  return path.join(instanceDir(id), "run.log");
}

function clearLog(id) {
  try {
    fs.writeFileSync(logPath(id), "");
  } catch {}
}

module.exports = {
  ROOT,
  INSTANCES,
  list,
  get,
  create,
  update,
  remove,
  materialise,
  instanceDir,
  sessionDir,
  hasCreds,
  logPath,
  clearLog,
};
