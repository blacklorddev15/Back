"use strict";
/**
 * Control surface shared by Telegram and the HTTP panel.
 *
 * Everything that mutates a session lives here so both front ends enforce the
 * same rules: the per-user cap, the global cap, ownership checks, port
 * allocation, and the pairing lifecycle. The front ends only format replies.
 */

const { spawn } = require("child_process");
const path = require("path");
const { EventEmitter } = require("events");
const store = require("./store");
const supervisor = require("./supervisor");

const events = new EventEmitter();
const pairers = new Map(); // id -> child process

const BASE_PORT = Number(process.env.INSTANCE_PORT_BASE || 3100);
const MAX_GLOBAL = Number(process.env.MAX_SESSIONS || 10);
const MAX_PER_USER = Number(process.env.MAX_SESSIONS_PER_USER || 3);

function nextPort() {
  const used = new Set(store.list().map((s) => s.port));
  let p = BASE_PORT;
  while (used.has(p)) p += 1;
  return p;
}

function ownedBy(rec, ownerKey) {
  return !!rec && (rec.ownerKey || "") === String(ownerKey || "");
}

/**
 * Spawn pair.js and resolve as soon as a code (or a failure) is printed. The
 * child keeps running until the phone confirms, then the instance is started.
 */
function beginPairing(rec) {
  return new Promise((resolve) => {
    const pairEntry = process.env.PAIR_ENTRY || path.join(store.ROOT, "pair.js");
    const child = spawn(process.execPath, [pairEntry, rec.number, store.instanceDir(rec.id)], {
      cwd: store.ROOT,
      stdio: ["ignore", "pipe", "pipe"],
    });
    pairers.set(rec.id, child);
    let settled = false;
    let buffer = "";

    const finish = (payload) => {
      if (settled) return;
      settled = true;
      resolve(payload);
    };

    const onData = (chunk) => {
      buffer += chunk.toString();
      supervisor.appendLog(rec.id, chunk.toString());
      const codeLine = buffer.match(/PAIR_CODE:([A-Z0-9]{4,12})/);
      if (codeLine) finish({ ok: true, code: codeLine[1] });
      const fail = buffer.match(/FAILED:(.+)/);
      if (fail) finish({ ok: false, error: fail[1].trim() });
    };

    child.stdout.on("data", onData);
    child.stderr.on("data", onData);

    child.on("exit", (code) => {
      pairers.delete(rec.id);
      const failed = /FAILED:(.+)/.exec(buffer);
      if (/PAIRED:/.test(buffer)) {
        store.update(rec.id, { status: "stopped", pairedAt: new Date().toISOString() });
        const started = supervisor.start(rec.id);
        events.emit("paired", store.get(rec.id), started);
        finish({ ok: true, code: null, paired: true });
      } else if (code !== 0 || failed) {
        store.update(rec.id, { status: "pairing-failed" });
        events.emit("pair-failed", store.get(rec.id), failed ? failed[1].trim() : `exit ${code}`);
        finish({ ok: false, error: failed ? failed[1].trim() : `pairing exited ${code}` });
      }
    });

    child.on("error", (err) => {
      events.emit("pair-failed", rec, err.message);
      finish({ ok: false, error: err.message });
    });

    // code is delivered within seconds; don't block the caller longer than that
    setTimeout(() => finish({ ok: true, code: null, pending: true }), 20000);
  });
}

function countFor(ownerKey) {
  return store
    .list()
    .filter((s) => s.status !== "deleted" && ownedBy(s, ownerKey)).length;
}

/** Validate and create a session, then request its pairing code. */
async function pair(number, ownerKey) {
  const clean = String(number || "").replace(/\D/g, "");
  if (clean.length < 8 || clean.length > 15) {
    return { ok: false, error: "Send the number in international format, digits only — e.g. 254712345678" };
  }
  if (countFor(ownerKey) >= MAX_PER_USER) {
    return { ok: false, error: `You already have ${MAX_PER_USER} numbers paired. Remove one with /delete first.` };
  }
  if (store.list().filter((s) => s.status !== "deleted").length >= MAX_GLOBAL) {
    return { ok: false, error: "The server is full. Try again later." };
  }
  let rec;
  try {
    rec = store.create({ number: clean, port: nextPort(), ownerKey });
  } catch (e) {
    return { ok: false, error: e.message };
  }
  const res = await beginPairing(rec);
  return { ...res, id: rec.id, number: clean };
}

function listFor(ownerKey) {
  return store
    .list()
    .filter((s) => s.status !== "deleted" && ownedBy(s, ownerKey))
    .map((s) => supervisor.statusOf(s.id));
}

function listAll() {
  return store.list().map((s) => supervisor.statusOf(s.id));
}

function getOwned(id, ownerKey) {
  const rec = store.get(id);
  if (!rec) return { ok: false, error: "Unknown session" };
  if (!ownedBy(rec, ownerKey)) return { ok: false, error: "Not yours" };
  return { ok: true, rec };
}

function start(id, ownerKey) {
  const g = getOwned(id, ownerKey);
  if (!g.ok) return g;
  return supervisor.start(id);
}

function stop(id, ownerKey) {
  const g = getOwned(id, ownerKey);
  if (!g.ok) return g;
  return supervisor.stop(id);
}

function restart(id, ownerKey) {
  const g = getOwned(id, ownerKey);
  if (!g.ok) return g;
  return supervisor.restart(id);
}

function remove(id, ownerKey) {
  const g = getOwned(id, ownerKey);
  if (!g.ok) return g;
  const p = pairers.get(id);
  if (p) p.kill("SIGKILL");
  supervisor.stop(id);
  store.remove(id);
  return { ok: true, removed: id };
}

function logs(id, ownerKey, bytes = 3000) {
  const g = getOwned(id, ownerKey);
  if (!g.ok) return g;
  return { ok: true, log: supervisor.tailFile(store.logPath(id), bytes) };
}

/** Resolve a user-typed reference: full id, or the 4-digit tail they see. */
function findByShort(ownerKey, token) {
  const mine = store
    .list()
    .filter((s) => s.status !== "deleted" && ownedBy(s, ownerKey));
  const t = String(token || "").trim().toLowerCase();
  return (
    mine.find((s) => s.id === t) ||
    mine.find((s) => s.id.endsWith(t)) ||
    mine.find((s) => s.number.endsWith(t)) ||
    null
  );
}

module.exports = {
  events,
  pair,
  listFor,
  listAll,
  start,
  stop,
  restart,
  remove,
  logs,
  findByShort,
  ownedBy,
  countFor,
  MAX_PER_USER,
  MAX_GLOBAL,
};
