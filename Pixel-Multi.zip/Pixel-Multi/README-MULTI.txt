PIXEL — MULTI-USER BUILD (Telegram pairing)
===========================================

Users pair from Telegram. The web panel is optional, for the operator.

1. CREATE THE TELEGRAM BOT
   Message @BotFather → /newbot → copy the token.
   Message @userinfobot → copy your numeric id (that is the admin id).

2. CONFIGURE
   npm install
   cp .env.example .env
   edit .env:
     TELEGRAM_BOT_TOKEN=123456:ABC...
     TELEGRAM_ADMIN_ID=123456789

3. RUN
   npm start

4. HOW A USER PAIRS
   They open your Telegram bot and send their WhatsApp number, digits only:
       254712345678
   The bot replies with an 8-character code.
   WhatsApp → Settings → Linked devices → Link with phone number → type it.
   The bot confirms in Telegram the moment that number is online.

   Their Telegram id is the owner key, so they only ever see their own
   numbers: /sessions /stop /start /restart /logs /delete.

5. WHAT IS ISOLATED
   Each paired number is its own node process with its own folder:
     instances/<id>/database/   antilink, antistatus, settings, welcome, auto-*
     instances/<id>/session/    credentials
   One user changing .antilink or .autotyping can never touch another's data.

6. PANEL (OPTIONAL)
   http://<host>:3000 — same operations, gated by PANEL_KEY.
   PANEL=0 disables it entirely if you want Telegram only.

READ
  MULTIUSER.md — architecture, routes, capacity, deploy notes
