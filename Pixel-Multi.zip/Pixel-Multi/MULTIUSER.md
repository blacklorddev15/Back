# Pixel — Multi-User

One bot per paired number. **Users pair from Telegram**; the web panel is the
operator surface.

```
TELEGRAM_BOT_TOKEN=...  TELEGRAM_ADMIN_ID=...   npm start
```

## Telegram (the user surface)

| Command | What it does |
|---|---|
| *(bare number)* or `/pair 254712345678` | requests an 8-character pairing code |
| `/sessions` | that Telegram user's numbers, each with status and a 4-char id |
| `/stop <id>` / `/start <id>` / `/restart <id>` | pause, resume, restart |
| `/logs <id>` | last lines of that instance's console |
| `/delete <id>` | stop it and delete its data |
| `/all` · `/stats` | admin only — every session on the box |

A Telegram id is the owner key (`tg:<id>`). One account can never see, stop or
delete a number it did not pair — that is enforced in the control layer, not in
the message formatting, so the panel obeys the same rule.

Pairing flow:

1. User sends `254712345678` to the bot.
2. Bot spawns `pair.js`, replies with `PAIR_CODE:XXXXXXXX` rendered as a code.
3. User enters it in WhatsApp → Linked devices → Link with phone number.
4. `pair.js` writes that instance's `session/creds.json`, exits, supervisor starts
   the bot, and the user gets "✅ +2547… is paired and online" in Telegram.

A bare number is accepted on purpose — that is how people actually use it.

## Panel (operator)

Optional; `PANEL=0` turns it off for a Telegram-only box.

| Route | What it does |
|---|---|
| `GET /` | dashboard — pair, start, stop, restart, delete, read logs |
| `GET /healthz` | liveness for the host |
| `GET /api/sessions` | JSON list with live `running` / `uptime` |
| `POST /api/pair` `{number}` | returns a pairing code; the bot starts itself once the phone confirms |
| `POST /api/sessions/:id/start` | start an instance |
| `POST /api/sessions/:id/stop` | stop an instance |
| `POST /api/sessions/:id/restart` | stop then start |
| `GET /api/sessions/:id/logs` | last 12 KB of that instance's log |
| `DELETE /api/sessions/:id` | stop + delete the session **and its data** |

Set `PANEL_KEY` to require `?key=…` on the dashboard and `x-panel-key: …` on the
API. Leave it empty only on a private box.

## Pairing flow

1. Panel `POST /api/pair` with a phone number.
2. Supervisor spawns `pair.js <number> instances/<id>`, which prints
   `PAIR_CODE:XXXXXXXX`.
3. The user enters that code in WhatsApp → **Linked devices → Link with phone
   number** (8 characters, expires in ~90 seconds).
4. `pair.js` writes `creds.json` into the instance's `session/` folder and exits.
5. Supervisor sees the fresh credentials and starts `index.js` in that folder.

The paired number becomes the owner of that bot automatically — `index.js` seeds
`database/owner.json` with it on connect, so no config is needed per user.

## Limits and capacity

- `MAX_SESSIONS` (default 10) caps how many numbers can be paired overall.
- `MAX_SESSIONS_PER_USER` (default 3) caps one Telegram account. Raise it only
  with the RAM to match.
- Each bot process idles at roughly 150–250 MB, so a 2 GB box comfortably runs
  8–10 sessions; 4 GB ≈ 18–20.
- Each instance also binds its own HTTP port from `INSTANCE_PORT_BASE` (3100+).
  That is why the panel needs a contiguous free port range, not just one port.

## Operations

- **Restart policy** — an instance that dies unexpectedly is restarted with
  backoff (2s, 4s, 6s …); after 5 restarts inside 10 minutes it is marked
  `crashed` and left alone so it stops hammering WhatsApp.
- **Boot** — `server.js` starts every session that already has credentials, so a
  host reboot needs nothing but `npm start`.
- **Logs** — per instance in `instances/<id>/run.log`, capped at 200 KB.
- **State** — `data/sessions.json` is the only shared file; it holds ids, numbers
  and ports, never settings.

## Deploy notes

**Pterodactyl / VPS** — `npm install && npm start`, open the panel port, keep the
volume covering `instances/` and `data/`.

**Render** — same start command, but the free tier sleeps and has an ephemeral
disk: sessions vanish on redeploy unless you attach a persistent disk mounted at
the repo root. Pairing also needs the instance awake for the full 90-second code
window — on a sleeping free instance the code dies before the user can type it.

**One bot per process means one CPU core per busy bot is not true** — WhatsApp
traffic is mostly idle; ten instances on 2 vCPU is fine. RAM is the real limit.

## Testing without WhatsApp

`tests/run-multiuser-test.sh` drives the real panel, store and supervisor with a
fake pairer and a fake bot child. It proves: auth gate, code issuing, session
limit, distinct ports, distinct `settings.json` inodes, no settings bleed when
each instance is edited, crash isolation (stopping one leaves the other running),
log endpoint, and deletion of the instance directory.

```
npm run test:multi      # panel: pairing, caps, ports, isolation, crash policy
npm run test:telegram   # Telegram handlers: code delivery, ownership, admin gate
```

The Telegram test drives the real control layer with a fake pairer and fake bot,
so ownership rules are exercised for real: a stranger's `/stop` and `/delete` are
refused, `/all` is admin-only, and a bare number is turned into a code.
