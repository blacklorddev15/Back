#!/usr/bin/env node
"use strict";
/**
 * PIXEL MULTI-USER — supervisor boot
 *
 * Two front ends, one runtime:
 *   Telegram  — where users pair and manage their own numbers (TELEGRAM_BOT_TOKEN)
 *   HTTP      — operator panel + API (optional, PORT)
 *
 * Both call the same control layer, so caps, ownership and pairing behave
 * identically whichever surface is used.
 */

const http = require("http");
const fs = require("fs");
const path = require("path");
const store = require("./multiuser/store");
const supervisor = require("./multiuser/supervisor");
const control = require("./multiuser/control");
const telegram = require("./multiuser/telegram");

const PORT = Number(process.env.PORT || 3000);
const KEY = process.env.PANEL_KEY || "";
const TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
const ADMIN_IDS = String(process.env.TELEGRAM_ADMIN_ID || "")
  .split(/[,\s]+/)
  .filter(Boolean);
const PANEL_ENABLED = String(process.env.PANEL || "1") !== "0";

function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json", "Cache-Control": "no-store" });
  res.end(body);
}

function authorised(req, url) {
  if (!KEY) return true;
  const given = req.headers["x-panel-key"] || url.searchParams.get("key") || "";
  return given === KEY;
}

function readBody(req) {
  return new Promise((resolve) => {
    let raw = "";
    req.on("data", (c) => {
      raw += c;
      if (raw.length > 1e6) req.destroy();
    });
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        resolve({});
      }
    });
  });
}

const PANEL_HTML = fs.readFileSync(path.join(__dirname, "multiuser", "panel.html"), "utf8");

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (url.pathname === "/healthz") {
    return json(res, 200, { ok: true, sessions: store.list().length });
  }

  if (url.pathname === "/" || url.pathname === "/panel") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
    return res.end(PANEL_HTML);
  }

  if (!url.pathname.startsWith("/api/")) {
    res.writeHead(404, { "Content-Type": "text/plain" });
    return res.end("not found");
  }

  if (!authorised(req, url)) return json(res, 401, { ok: false, error: "unauthorised" });

  try {
    if (url.pathname === "/api/sessions" && req.method === "GET") {
      return json(res, 200, { ok: true, sessions: control.listAll() });
    }

    if (url.pathname === "/api/pair" && req.method === "POST") {
      const body = await readBody(req);
      const number = String(body.number || "").replace(/\D/g, "");
      const ownerKey = String(body.ownerKey || "panel");
      if (number.length < 8) return json(res, 400, { ok: false, error: "invalid number" });
      const result = await control.pair(number, ownerKey);
      return json(res, result.ok ? 200 : 400, { ...result, number });
    }

    const m = url.pathname.match(/^\/api\/sessions\/([^/]+)(?:\/(start|stop|restart|logs))?$/);
    if (m) {
      const id = decodeURIComponent(m[1]);
      const action = m[2];
      const rec = store.get(id);
      if (!rec) return json(res, 404, { ok: false, error: "unknown session" });
      const owner = rec.ownerKey || "";

      if (!action && req.method === "DELETE") {
        return json(res, 200, control.remove(id, owner));
      }
      if (action === "start") return json(res, 200, control.start(id, owner));
      if (action === "stop") return json(res, 200, control.stop(id, owner));
      if (action === "restart") return json(res, 200, control.restart(id, owner));
      if (action === "logs") return json(res, 200, control.logs(id, owner, 12000));
      return json(res, 200, { ok: true, session: supervisor.statusOf(id) });
    }

    return json(res, 404, { ok: false, error: "unknown route" });
  } catch (err) {
    return json(res, 500, { ok: false, error: err.message });
  }
});

if (TOKEN) {
  telegram.launch({ token: TOKEN, adminIds: ADMIN_IDS });
} else {
  console.log("[telegram] TELEGRAM_BOT_TOKEN not set — Telegram front end disabled");
}

if (PANEL_ENABLED) {
  server.listen(PORT, "0.0.0.0", () => {
    const booted = supervisor.bootAll();
    console.log(`[panel] listening on :${PORT}${KEY ? " (keyed)" : " (open)"}`);
    console.log(`[panel] resumed ${booted.length} session(s)`);
  });
} else {
  const booted = supervisor.bootAll();
  console.log(`[panel] disabled by PANEL=0 — resumed ${booted.length} session(s)`);
}
