module.exports = {
    name: "help",
    description: "List available commands",
    async execute(bot, msg, commands) {
        const chatId = msg.chat.id;
        const lines = [...commands.values()]
            .map((c) => `/${c.name} — ${c.description}`)
            .join("\n");

        await bot.sendMessage(chatId, `📖 *Available commands*\n\n${lines}`, {
            parse_mode: "Markdown",
        });
    },
};
