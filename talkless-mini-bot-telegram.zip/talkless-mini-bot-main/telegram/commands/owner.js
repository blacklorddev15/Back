const config = require("../../config");

module.exports = {
    name: "owner",
    description: "Show bot owner info (or confirm you are the owner)",
    async execute(bot, msg) {
        const chatId = msg.chat.id;
        const userId = String(msg.from?.id || "");
        const ownerId = String(config.OWNER_ID || "");

        if (ownerId && userId === ownerId) {
            await bot.sendMessage(chatId, "✅ You are the bot owner.");
            return;
        }

        await bot.sendMessage(
            chatId,
            ownerId
                ? `👤 This bot is managed by Telegram user ID \`${ownerId}\`.`
                : "👤 No owner ID has been configured yet (set OWNER_ID in .env).",
            { parse_mode: "Markdown" }
        );
    },
};
