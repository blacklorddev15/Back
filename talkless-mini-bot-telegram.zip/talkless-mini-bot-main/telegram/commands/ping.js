module.exports = {
    name: "ping",
    description: "Check that the bot is alive and see response latency",
    async execute(bot, msg) {
        const chatId = msg.chat.id;
        const start = Date.now();
        const sent = await bot.sendMessage(chatId, "🏓 Pinging...");
        const latency = Date.now() - start;
        await bot.editMessageText(`🏓 Pong! \`${latency}ms\``, {
            chat_id: chatId,
            message_id: sent.message_id,
            parse_mode: "Markdown",
        });
    },
};
