module.exports = {
    name: "start",
    description: "Greet the user and show a quick intro",
    async execute(bot, msg) {
        const chatId = msg.chat.id;
        const firstName = msg.from?.first_name || "there";
        await bot.sendMessage(
            chatId,
            `👋 Hey ${firstName}, welcome to *Talkless Mini Bot*!\n\n` +
                `This bot is being rebuilt on Telegram. Try /help to see what's available so far.`,
            { parse_mode: "Markdown" }
        );
    },
};
