const fs = require("fs");
const path = require("path");

/**
 * Loads every command module in ./commands into a Map keyed by command name.
 * Each module must export { name, description, execute(bot, msg, commands) }.
 */
function loadCommands() {
    const commands = new Map();
    const dir = path.join(__dirname, "commands");

    for (const file of fs.readdirSync(dir)) {
        if (!file.endsWith(".js")) continue;
        const cmd = require(path.join(dir, file));
        if (!cmd?.name || typeof cmd.execute !== "function") continue;
        commands.set(cmd.name, cmd);
    }

    return commands;
}

module.exports = { loadCommands };
