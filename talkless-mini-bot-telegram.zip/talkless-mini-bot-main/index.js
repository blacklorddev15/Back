const config = require("./config");
const express = require("express");
const path = require("path");
const TelegramBot = require("node-telegram-bot-api");
const { loadCommands } = require("./telegram/loadCommands");

const PORT = process.env.PORT || 5000;

if (!config.BOT_TOKEN) {
    console.error("❌ Missing BOT_TOKEN. Add it to your .env file and restart.");
    process.exit(1);
}

// ─── Health check server (kept for hosting platforms that expect an open port) ──
const app = express();
app.get("/", (_req, res) => res.status(200).send("Talkless Mini Bot (Telegram) is running."));
app.get("/health", (_req, res) => res.status(200).json({ status: "alive", uptime: process.uptime() }));
app.listen(PORT, () => console.log(`✅ Health server running on port ${PORT}`));

// ─── Telegram bot ────────────────────────────────────────────────────────────
const bot = new TelegramBot(config.BOT_TOKEN, { polling: true });
const commands = loadCommands();

bot.on("polling_error", (err) => console.error("Polling error:", err.message));

bot.onText(/^\/(\w+)(?:@\S+)?(?:\s+(.*))?$/, async (msg, match) => {
    const commandName = match[1].toLowerCase();
    const cmd = commands.get(commandName);
    if (!cmd) return;

    try {
        await cmd.execute(bot, msg, commands);
    } catch (error) {
        console.error(`Command error [${commandName}]:`, error);
        try {
            await bot.sendMessage(msg.chat.id, `🚨 Command failed: ${error.message}`);
        } catch (_) {}
    }
});

console.log(`💜 Talkless Mini Bot starting on Telegram, ${commands.size} command(s) loaded: ${[...commands.keys()].join(", ")}`);
