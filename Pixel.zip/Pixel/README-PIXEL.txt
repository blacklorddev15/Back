PIXEL — single-user build (factory state, nothing pre-set)
=========================================================

SETUP
  .env  -> SESSION_ID = your session string (Pixel~eyJ... or plain base64)
           PREFIX can stay .  (bot also reads prefix from database/settings.json)
  npm install
  npm start

FIRST RUN
  The number that pairs is automatically the owner (no owner.json entry needed).
  Nothing else has to be configured — every feature is available on demand:
    .menu            command list
    .setprefix <x>   change prefix (digit, emoji, symbol or word)
    .setmenu 1|2|3   menu style
    .settings        shows live state of every toggle

DEFAULTS SHIPPED (fresh, as if never used)
  prefix .            mode public          menu style 1 (code default)
  bot name Pixel
  ALL auto-* OFF: autoviewstatus, autoreact, autolikestatus, autoread,
                  autotyping, autorecording, autorecordtype, autobio
  welcome OFF         antilink empty       antistatus empty     chatbot empty
  anticall OFF        owner list empty     warnings empty       activity empty

WHAT GETS SAVED WHEN THE NEW USER CHANGES SOMETHING
  database/settings.json      prefix, mode, autoviewstatus, autoreact, autolikestatus
                              + emoji, autoread, autotyping, autorecording,
                              autorecordtype, autobio, antidelete, autoOffline
  database/bot-settings.json  menu style, bot name, prefix-free
  database/antilink.json      per-group anti-link (on/off, action, warnings)
  database/antistatus.json    per-group anti-status
  database/anticall.json      anti-call
  database/chatbot.json       chatbot scope
  database/welcome.json       per-group welcome
  database/groups.json        per-group welcome/goodbye text (read by the listener)
  database/warnings.json      warn counts
  database/owner.json         owner + sudo list

No session, no owner number and no group data from a previous deployment is
included in this build.
