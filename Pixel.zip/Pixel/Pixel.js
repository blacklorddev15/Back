const {
  default: makeWaSocket,
  useMultiFileAuthState,
  BufferJSON,
  WA_DEFAULT_EPHEMERAL,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsEliteProTecheUser,
  getContentType,
} = require("baileys");
const os = require("os");
const fs = require("fs");
const fsx = require("fs-extra");
const path = require("path");
const util = require("util");
const chalk = require("chalk");
const moment = require("moment-timezone");
const speed = require("performance-now");
const ms = (toMs = require("ms"));
const axios = require("axios");
const FormData = require("form-data");
const fetch = require("node-fetch");
const yts = require("yt-search");
const { sendButtons, sendInteractiveMessage } = require("gifted-btns");
const menu421 = require("./lib/menu421");

/* 421-command menu, driven by database/menu_list.json (same list as server one). */
let _menuSectionsCache = null;
function eliteMenuSections() {
  if (_menuSectionsCache) return _menuSectionsCache;
  try {
    const raw = JSON.parse(fs.readFileSync("./database/menu_list.json", "utf8"));
    _menuSectionsCache = (raw.sections || []).filter(
      (s) => s && Array.isArray(s.commands) && s.commands.length,
    );
  } catch (err) {
    console.log("[menu421] could not read database/menu_list.json: " + err.message);
    _menuSectionsCache = [];
  }
  return _menuSectionsCache;
}
const pino = require("pino");
const { exec, spawn, execSync } = require("child_process");
const { translate } = require("@vitalets/google-translate-api");
const googleTTS = require("google-tts-api");
const { performance } = require("perf_hooks");
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const { webp2mp4File } = require("./lib/uploader");
const {
  toAudio,
  toPTT,
  toVideo,
  ffmpeg,
  addExifAvatar,
} = require("./lib/converter");
const {
  uploadToEliteProTechUrl,
  uploadToCatbox,
  uploadToEliteTempUrl,
} = require("./lib/urlclouds");
const {
  smsg,
  getGroupAdmins,
  formatp,
  jam,
  formatDate,
  getTime,
  isUrl,
  await,
  sleep,
  clockString,
  msToDate,
  sort,
  toNumber,
  enumGetKey,
  runtime,
  fetchJson,
  getBuffer,
  json,
  delay,
  format,
  logic,
  generateProfilePicture,
  parseMention,
  getRandom,
  pickRandom,
  reSize,
} = require("./lib/myfunc");
const { checkPremiumUser } = require("./lib/premium");
const { fetchBuffer, buffergif } = require("./lib/myfunc2");

//database
let _owner = JSON.parse(fs.readFileSync("./database/owner.json"));
let owner = JSON.parse(fs.readFileSync("./database/owner.json"));
let elitepropic = fs.readFileSync("./database/elitepropic.jpg");
const settingsFile = "./database/settings.json";

// ── Owner-changeable identity: .setbotname / .setmenu (persists across restarts)
const botSettingsFile = "./database/bot-settings.json";
function readBotSettings() {
  try {
    return JSON.parse(fs.readFileSync(botSettingsFile, "utf8")) || {};
  } catch {
    return {};
  }
}
function writeBotSettings(patch) {
  const next = Object.assign({}, readBotSettings(), patch);
  fs.writeFileSync(botSettingsFile, JSON.stringify(next, null, 2));
  return next;
}
function eliteMenuStyle() {
  const st = readBotSettings();
  return ["1", "2", "3"].includes(String(st.menuStyle)) ? String(st.menuStyle) : "1";
}
// ── Fake status quote ────────────────────────────────────────────────────────
// Ported from ASTRO X ULTRA's utils/quotes.js: outgoing replies are sent with a
// `quoted` payload faked to look like a WhatsApp status. The thumbnail is not a
// bundled image — it is the profile picture of the number this session is paired
// to, so the status preview shows the bot's real avatar.
let _statusThumb = null;
let _statusThumbAt = 0;
const STATUS_THUMB_TTL = 30 * 60 * 1000;

async function warmStatusQuote(sock, jid) {
  if (_statusThumb && Date.now() - _statusThumbAt < STATUS_THUMB_TTL) return;
  _statusThumbAt = Date.now();

  const digits = String((sock.user && sock.user.id) || jid || "")
    .split("@")[0]
    .split(":")[0]
    .replace(/\D/g, "");
  const candidates = [
    [jid, "image"],
    [digits ? `${digits}@s.whatsapp.net` : "", "image"],
    [(sock.user && sock.user.lid) || "", "image"],
    [digits ? `${digits}@s.whatsapp.net` : "", "preview"],
    [jid, "preview"],
  ];

  let raw = null;
  for (const [j, t] of candidates) {
    if (!j) continue;
    try {
      const url = await sock.profilePictureUrl(j, t);
      if (!url) continue;
      const buf = await fetchBuffer(url);
      if (buf && buf.length) {
        raw = buf;
        console.log("[status-quote] paired-number avatar via " + t + " " + j);
        break;
      }
    } catch (e) {
      /* try the next variant */
    }
  }

  // WhatsApp refuses its own profile picture on some sessions — fall back to the
  // bot's configured picture so a reply still renders as a faked status.
  if (!raw || !raw.length) {
    try {
      raw = fs.readFileSync("./database/elitepropic.jpg");
      console.log("[status-quote] avatar unavailable, using bundled picture");
    } catch (e) {}
  }
  if (!raw || !raw.length) return;

  try {
    const JimpModule = require("jimp");
    const Jimp = JimpModule.Jimp || JimpModule;
    let img = await Jimp.read(raw);
    if (img.bitmap.width > 160 || img.bitmap.height > 160) {
      img = img.cover(140, 140) || img;
      if (img.bitmap.width > 160) img.resize(140, Jimp.AUTO);
    }
    img.quality(40);
    let buf = await img.getBufferAsync(Jimp.MIME_JPEG);
    if (buf.length > 12000) {
      img.quality(22);
      buf = await img.getBufferAsync(Jimp.MIME_JPEG);
    }
    _statusThumb = buf;
    console.log(
      "[status-quote] thumbnail ready (" + img.bitmap.width + "x" + img.bitmap.height + ", " + _statusThumb.length + " b)",
    );
  } catch (e) {
    console.log("[status-quote] " + (e && e.message));
  }
}

function resetStatusQuote() {
  _statusThumb = null;
  _statusThumbAt = 0;
}

function statusQuote(m) {
  const name = (typeof botname !== "undefined" && botname) || "Pixel";

  // The quote must point at a stanza that really exists, otherwise WhatsApp
  // renders "Waiting for this message" instead of the preview. We keep the
  // faked status look by quoting the real incoming message's key but embedding
  // our own preview (bot-name status thumbnail) as the quoted content.
  let key;
  if (m && m.key && m.key.id && m.key.remoteJid) {
    key = {
      remoteJid: m.key.remoteJid,
      fromMe: !!m.key.fromMe,
      id: m.key.id,
      participant: m.key.participant || m.sender || undefined,
    };
  } else {
    key = {
      remoteJid: "status@broadcast",
      fromMe: false,
      id: "3EB0" + Math.random().toString(36).slice(2, 10).toUpperCase(),
      participant: "0@s.whatsapp.net",
    };
  }

  const message = _statusThumb
    ? {
        imageMessage: {
          mimetype: "image/jpeg",
          jpegThumbnail: _statusThumb,
          width: 140,
          height: 140,
          fileLength: _statusThumb.length,
          caption: name,
        },
      }
    : { conversation: name };

  return { key, message };
}

(function applySavedIdentity() {
  const st = readBotSettings();
  if (st.botName && String(st.botName).trim()) {
    global.botname = String(st.botName).trim();
    console.log("[identity] bot name = " + global.botname);
  }
  if (st.menuStyle) console.log("[identity] menu style = " + eliteMenuStyle());
  if (st.ownername) global.ownername = String(st.ownername).trim();
  if (st.timezone) {
    process.env.TZ = String(st.timezone).trim();
    console.log("[identity] timezone = " + process.env.TZ);
  }
  if (st.alwaysonline && !global.__alwaysOnlineTimer) {
    global.__alwaysOnlineTimer = setInterval(() => {
      try {
        if (global.__sock) global.__sock.sendPresenceUpdate("available").catch(() => {});
      } catch {}
    }, 60000);
  }
})();

// ── Owner helpers: prefix-free gate, anti-edit watcher, anti-bug filter ─────
// Ported from ASTRO X ULTRA (handler.js prefix gate, commands/owner/antiedit.js,
// commands/owner/antibug.js). Settings live in database/bot-settings.json.
const BARE_COMMANDS = new Set(
  ["8ballpool", "add", "addall", "addmetaai", "addowner", "addpdf", "addsudo", "adminlist", "admins", "ai", "aimusic", "aio", "aisong", "aivoice", "alive", "alwaysonline", "analyze", "anime", "animeavatar", "animeblush", "animebonk", "animebully", "animepoke", "animesmile", "animewave", "animewink", "anticall", "antidelete", "antilink", "antistatus", "apk", "apkdl", "approve", "audiospeed", "auto_react", "autobio", "autolikestatus", "autoreact", "autoread", "autorecording", "autorecordtype", "autostatusview", "autotyping", "autoviewlike", "autoviewstatus", "av", "backup", "bc", "bcgc", "bcgroup", "bet", "bible", "block", "blocklist", "bot", "botname", "brat", "broadcast", "carbon", "catbox", "channel-id", "channelid", "chatbot", "chatgpt", "clearchat", "clearpdf", "clearsession", "clearwarn", "closetime", "cloud", "colorize", "contacttag", "contag", "copilot", "copy", "countries", "country", "create", "dana", "day", "deepfake", "define", "del", "delete", "deletenote", "deleteowner", "deletesession", "deletesudo", "delmetaai", "delowner", "delpaypoint", "delsession", "demote", "demoteall", "detik", "disable", "edit", "editinfo", "elevenlab", "emojimix", "emptychat", "enhance", "ephoto", "ephotolist", "ev", "eval", "everyone", "facebook", "fact", "fakech", "fakechannel", "fakedana", "fakeigstory", "fb", "fdana", "fdroid", "fetch", "fetchaud", "fetchaudio", "fetchimg", "fetchvid", "fetchvideo", "firelogo", "fliptext", "flirt", "flux", "forward", "freebot", "gc", "gcalert", "gclink", "gcstatus", "gdesc", "gemini", "get", "getcase", "getgroupdesc", "getgrouppp", "getgroupprofile", "getpp", "getsession", "ggp", "gitclone", "google", "gpt", "group", "group-id", "group-jid", "groupdesc", "groupid", "groupjid", "grouplink", "grouplist", "grouppp", "groupprofile", "groupsettings", "groupstatus", "hari", "hd", "hdwallpaper", "here", "hidetag", "hour", "ig", "igstory", "image2pdf", "imagine", "img", "img2pdf", "img2txt", "imgbb", "instagram", "insult", "invite", "jam", "jid", "join", "joingc", "kick", "kickall", "knackvideo", "leave", "left", "lid", "listgroup", "listgroups", "listnote", "listonline", "listowner", "listsudo", "loli", "lyrics", "mediafire", "menit", "menu", "menuset", "menustyle", "minute", "mode", "musicgen", "mygroups", "neko", "note", "npm", "npmdl", "npmdownload", "npmdownloader", "nsfw", "ocr", "opentime", "owner", "pair", "panel", "paypoint", "pickupline", "ping", "pinterest", "play", "poll", "prefix", "profile", "promote", "promoteall", "qr", "qrscan", "quotes", "quran", "rate", "readmore", "reject", "remini", "removebg", "removemetaai", "ren", "rename", "repo", "report", "reportcmd", "reportcommand", "resetlink", "resetpdf", "resetwarn", "restart", "reveal", "revoke", "roast", "runtime", "rv", "save", "savecontact", "sc", "scanqr", "screenshot", "script", "search", "second", "sencontact", "sendcontact", "session", "setbot", "setbotimage", "setbotname", "setbotpp", "setdesc", "setdesk", "setexif", "setfullpp", "setfullprofilepicture", "setgrouppicture", "setgrouppp", "setgroupprofile", "setlikestatus", "setmenu", "setmenuimage", "setname", "setown", "setownername", "setownernumber", "setpaypoint", "setpp", "setppbot", "setppgc", "setprefix", "setsubject", "settimezone", "settings", "settz", "shazam", "shell", "shorturl", "smeme", "song", "sp", "splay", "spotify", "spotifysearch", "sps", "ssweb", "staff", "statusd", "steal", "stickerpack", "stickerwm", "stickkill", "stiker", "story", "sudolist", "svcontact", "swm", "tag", "tagadmin", "tagall", "take", "telegramsticker", "tempemail", "tempinbox", "tempmail", "tempurl", "test", "tgpack", "tictactoe", "tiktok", "tiktoksearch", "tiktokstalk", "tiny", "toanime", "toaud", "toaudio", "togif", "togroupstatus", "toimage", "toimg", "tomp3", "tomp4", "toonce", "toptt", "toqr", "tostatus", "totag", "tourl", "tovideo", "tovideonote", "toviewonce", "tovn", "translate", "trt", "truth", "tts", "ttt", "twit", "twitter", "unblock", "unwarn", "update", "upscale", "uptime", "url", "vcf", "videonote", "vocalremover", "vv", "vvdm", "waifu", "wallpaper", "warn", "warnings", "wasted", "welcome", "xdl", "xo", "ytmp3", "ytmp4", "yts", "ytsearch", "zipsearch"]
);
function prefixFreeOn() {
  return !!readBotSettings().prefixfree;
}
// Owner recovery: these always run bare, even with a weird prefix set,
// so you can never lock yourself out of changing the prefix.
const ALWAYS_BARE = new Set([
  "setprefix",
  "prefix",
  "setprefixfree",
  "prefixfree",
  "pfree",
]);

// anti-edit: remember the text of every incoming message so an edit can be diffed
const EDIT_STORE = new Map();
function storeForAntiedit(m) {
  try {
    if (!m?.key?.id || !m.message) return;
    const chatId = m.key.remoteJid;
    const inner = m.message;
    const text =
      inner.conversation ||
      inner.extendedTextMessage?.text ||
      inner.ephemeralMessage?.message?.conversation ||
      inner.ephemeralMessage?.message?.extendedTextMessage?.text ||
      null;
    if (!text) return;
    if (!EDIT_STORE.has(chatId)) EDIT_STORE.set(chatId, new Map());
    const chatMap = EDIT_STORE.get(chatId);
    chatMap.set(m.key.id, {
      sender: m.key.participant || chatId,
      timestamp: m.messageTimestamp,
      text,
      pushName: m.pushName || null,
    });
    if (chatMap.size > 300) chatMap.delete(chatMap.keys().next().value);
  } catch (_) {}
}

function attachAntiedit(sock) {
  if (!sock || global.__antieditSock === sock) return;
  global.__antieditSock = sock;
  sock.ev.on("messages.update", async (updates) => {
    try {
      const mode = String(readBotSettings().antiedit || "off").toLowerCase();
      if (mode !== "chat" && mode !== "pm") return;
      const selfJid = sock.user?.id
        ? sock.user.id.split(":")[0] + "@s.whatsapp.net"
        : null;
      for (const { key, update } of updates || []) {
        try {
          const proto = update?.message?.protocolMessage;
          const newMsg =
            proto?.editedMessage || update?.message?.editedMessage?.message;
          if (!newMsg) continue;
          const chatId = key.remoteJid;
          const targetJid = mode === "pm" && selfJid ? selfJid : chatId;
          const originalId = proto?.key?.id || key.id;
          const original = EDIT_STORE.get(chatId)?.get(originalId);
          const editedText =
            newMsg.conversation || newMsg.extendedTextMessage?.text || null;
          if (!editedText) continue;
          if (original?.text && original.text === editedText) continue;
          const rawSender =
            original?.sender || key.participant || key.remoteJid || "";
          const sender = rawSender.includes(":")
            ? rawSender.split(":")[0] + "@s.whatsapp.net"
            : rawSender;
          const stamp = original?.timestamp
            ? new Date(Number(original.timestamp) * 1000).toLocaleString("en-GB", {
                hour12: false,
                timeZone: process.env.TZ || "Africa/Nairobi",
              })
            : new Date().toLocaleString();
          await sock.sendMessage(targetJid, {
            text:
              `✏️ *Edited message*\n` +
              `👤 @${String(sender).split("@")[0]}\n` +
              `🕐 ${stamp}\n\n` +
              `📝 *Original:*\n${original?.text || "_not cached_"}\n\n` +
              `📝 *Edited:*\n${editedText}`,
            mentions: sender ? [sender] : [],
          });
          if (original) original.text = editedText;
        } catch (_) {}
      }
    } catch (e) {
      console.log("[antiedit] " + e.message);
    }
  });
  console.log("[antiedit] watcher attached");
}

// anti-bug: crash-pattern filter (Unicode exploits / huge repeats)
const BUG_PATTERNS = [
  /\u0000/,
  /\u202E{2,}/,
  /[\u200B-\u200D\uFEFF]{10,}/,
  /[\u0300-\u036f]{8,}/,
  /(.)\1{500,}/,
  /[\u{E0000}-\u{E007F}]/u,
];
function isBugText(text) {
  if (!text || typeof text !== "string") return false;
  for (const p of BUG_PATTERNS) {
    try {
      if (p.test(text)) return true;
    } catch (_) {}
  }
  return false;
}

function readWarnBook() {
  try {
    return JSON.parse(fs.readFileSync("./database/warnings.json", "utf8")) || {};
  } catch {
    return {};
  }
}
function saveWarnBook(book) {
  try {
    fs.writeFileSync("./database/warnings.json", JSON.stringify(book, null, 2));
  } catch {}
}

// Returns true when the message was handled (caller should stop processing).
async function runAntibug(sock, m, ctx) {
  try {
    const st = readBotSettings();
    if (!st.antibug || m.key.fromMe) return false;
    const inner = m.message || {};
    const text =
      inner.conversation ||
      inner.extendedTextMessage?.text ||
      inner.imageMessage?.caption ||
      inner.videoMessage?.caption ||
      inner.documentMessage?.caption ||
      "";
    if (!isBugText(text)) return false;
    if (ctx.isGroup && (ctx.isAdmins || ctx.isCreator)) return false;
    const action = st.antibugAction || "delete";
    const num = String(ctx.sender || "").split("@")[0].split(":")[0];
    if (ctx.isGroup && !ctx.isBotAdmins) {
      await sock.groupLeave(ctx.chat).catch(() => {});
      await sock
        .sendMessage(ctx.self, {
          text: `🛡️ *AntiBug* — left ${ctx.groupName || ctx.chat}, crash message from *${num}* and bot is not admin.`,
        })
        .catch(() => {});
      return true;
    }
    if (ctx.isGroup) await sock.sendMessage(ctx.chat, { delete: m.key }).catch(() => {});
    if (action === "kick") {
      await sock.groupParticipantsUpdate(ctx.chat, [ctx.sender], "remove").catch(() => {});
      await sock.sendMessage(ctx.chat, {
        text: `🛡️ *AntiBug* — @${num} removed · crash message.`,
        mentions: [ctx.sender],
      });
    } else if (action === "warn") {
      const book = readWarnBook();
      if (!book[ctx.chat]) book[ctx.chat] = {};
      book[ctx.chat][ctx.sender] = (book[ctx.chat][ctx.sender] || 0) + 1;
      const n = book[ctx.chat][ctx.sender];
      saveWarnBook(book);
      if (n >= 3) {
        await sock.groupParticipantsUpdate(ctx.chat, [ctx.sender], "remove").catch(() => {});
        delete book[ctx.chat][ctx.sender];
        saveWarnBook(book);
        await sock.sendMessage(ctx.chat, {
          text: `🛡️ *AntiBug* — @${num} removed · 3/3 warnings.`,
          mentions: [ctx.sender],
        });
      } else {
        await sock.sendMessage(ctx.chat, {
          text: `⚠️ *AntiBug* — @${num} warned · ${n}/3`,
          mentions: [ctx.sender],
        });
      }
    } else {
      await sock.sendMessage(ctx.chat, { text: `🛡️ *AntiBug* — crash message removed.` });
    }
    return true;
  } catch (e) {
    console.log("[antibug] " + e.message);
    return false;
  }
}


// ─── GROUP SETTINGS STORE (mute list, welcome, goodbye) ────────────────
const GROUPS_FILE = "./database/groups.json";

function readGroups() {
  try {
    return JSON.parse(fs.readFileSync(GROUPS_FILE, "utf8")) || {};
  } catch {
    return {};
  }
}

function writeGroups(data) {
  try {
    fs.writeFileSync(GROUPS_FILE, JSON.stringify(data, null, 2));
  } catch (e) {
    console.log("[groups] write failed: " + e.message);
  }
}

function groupCfg(jid) {
  const all = readGroups();
  if (!all[jid]) all[jid] = {};
  const g = all[jid];
  if (!Array.isArray(g.muted)) g.muted = [];
  if (!g.welcome) g.welcome = { on: false, text: "" };
  if (g.welcome.on === undefined) g.welcome.on = false; // default OFF
  if (!g.goodbye) g.goodbye = { on: false, text: "" };
  return { all, g };
}

function isMutedMember(jid, sender) {
  const g = readGroups()[jid];
  return !!(g && Array.isArray(g.muted) && g.muted.includes(sender));
}

// welcome / goodbye listener – attaches once per socket
function attachGroupListener(sock) {
  if (!sock || global.__pixelGroupSock === sock) return;
  global.__pixelGroupSock = sock;
  sock.ev.on("group-participants.update", async (ev) => {
    try {
      const { id, participants, action } = ev || {};
      if (!id || !Array.isArray(participants) || !participants.length) return;
      const cfg = readGroups()[id];
      if (!cfg) return;
      const meta = await sock.groupMetadata(id).catch(() => null);
      const gname = meta?.subject || "this group";
      if (action === "promote" || action === "demote") {
        const anti = readAnti()[id] || {};
        const key = action === "demote" ? "antidemote" : "antipromote";
        if (anti[key] && anti[key].on) {
          const revert = action === "demote" ? "promote" : "demote";
          for (const jid of participants) {
            await sock.groupParticipantsUpdate(id, [jid], revert).catch(() => {});
          }
        }
        return;
      }
      for (const jid of participants) {
        const num = String(jid).split("@")[0].split(":")[0];
        const block = action === "add" ? cfg.welcome : action === "remove" ? cfg.goodbye : null;
        if (!block || !block.on || !block.text) continue;
        const text = block.text
          .replace(/\{name\}/gi, `@${num}`)
          .replace(/\{group\}/gi, gname)
          .replace(/\{count\}/gi, String(meta?.participants?.length || ""));
        await sock.sendMessage(id, { text, mentions: [jid] }).catch(() => {});
      }
    } catch (e) {
      console.log("[group-listener] " + e.message);
    }
  });
}


// ─── ANTI-* ENGINE ─────────────────────────────────────────────────────
const ANTI_FILE = "./database/anti.json";
const ANTI_TYPES = [
  "antilink", "antimedia", "antiimage", "antivideo", "antiaudio", "antisticker",
  "antigif", "anticontact", "antitag", "antigroupmention", "antibadword",
  "antispam", "antibot", "antiforward", "antidemote", "antipromote",
  "antitagadmins", "antiviewonce",
];
const ANTI_BADWORDS = ["fuck", "shit", "bitch", "asshole", "dick", "pussy", "bastard", "slut", "whore"];

function readAnti() {
  try { return JSON.parse(fs.readFileSync(ANTI_FILE, "utf8")) || {}; } catch { return {}; }
}
function saveAnti(d) {
  try { fs.writeFileSync(ANTI_FILE, JSON.stringify(d, null, 2)); } catch (e) { console.log("[anti] " + e.message); }
}
function antiCfg(chat, type) {
  const c = readAnti()[chat] || {};
  return c[type] || { on: false, action: "delete" };
}

const ACTIVITY = new Map(); // `${chat}|${jid}` -> timestamp
const SPAM = new Map();     // `${chat}|${jid}` -> [timestamps]

function antiHit(type, m, text, mtype, ctx) {
  const inner = m.message || {};
  switch (type) {
    case "al":
    case "nolink":
    case "antilink":
      return /(chat\.whatsapp\.com|wa\.me\/|https?:\/\/\S+)/i.test(text);
    case "antimedia":
      return /^(imageMessage|videoMessage|audioMessage|documentMessage|stickerMessage)$/.test(mtype);
    case "antiimage": return mtype === "imageMessage";
    case "antivideo": return mtype === "videoMessage";
    case "antiaudio": return mtype === "audioMessage";
    case "antisticker": return mtype === "stickerMessage";
    case "antigif": return !!(inner.videoMessage && inner.videoMessage.gifPlayback);
    case "anticontact": return /contactMessage|contactsArrayMessage/.test(mtype);
    case "antitag": return (m.mentionedJid || []).length > 5;
    case "antigroupmention": return /groupMentioned|statusMention/i.test(mtype);
    case "antibadword": {
      const low = String(text).toLowerCase();
      return ANTI_BADWORDS.some((w) => new RegExp(`\\b${w}\\b`, "i").test(low));
    }
    case "antispam": {
      const key = `${m.chat}|${m.sender}`;
      const now = Date.now();
      const arr = (SPAM.get(key) || []).filter((t) => now - t < 5000);
      arr.push(now);
      SPAM.set(key, arr);
      return arr.length >= 9;
    }
    case "antibot": return String(m.id || "").startsWith("BAE5");
    case "antiforward": return !!(inner.extendedTextMessage?.contextInfo?.isForwarded || inner.contextInfo?.isForwarded);
    case "antiviewonce": return /viewOnce/i.test(mtype);
    case "antitagadmins": {
      const admins = (ctx.groupMetadata?.participants || [])
        .filter((p) => p.admin)
        .map((p) => p.id);
      return (m.mentionedJid || []).some((j) => admins.includes(j));
    }
    default:
      return false;
  }
}

async function runAnti(sock, m, ctx) {
  try {
    if (!ctx.isGroup || m.key.fromMe || ctx.isAdmins || ctx.isCreator) return false;
    const cfgAll = readAnti()[m.chat];
    if (!cfgAll) return false;
    const enabled = Object.keys(cfgAll).filter((k) => cfgAll[k] && cfgAll[k].on);
    if (!enabled.length) return false;
    const text = m.text || m.body || "";
    const mtype = m.mtype || "";
    for (const type of enabled) {
      if (type === "antidemote" || type === "antipromote") continue; // handled by the participants listener
      if (!antiHit(type, m, text, mtype, ctx)) continue;
      const action = cfgAll[type].action || "delete";
      if (!ctx.isBotAdmins) return true;
      try { await sock.sendMessage(m.chat, { delete: m.key }); } catch {}
      if (action === "warn") {
        const book = readWarnBook();
        book[m.chat] = book[m.chat] || {};
        book[m.chat][m.sender] = (book[m.chat][m.sender] || 0) + 1;
        const n = book[m.chat][m.sender];
        saveWarnBook(book);
        await sock.sendMessage(m.chat, { text: `⚠️ @${m.sender.split("@")[0]} ${type} · warning ${n}/3`, mentions: [m.sender] }).catch(() => {});
        if (n >= 3) {
          await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove").catch(() => {});
          delete book[m.chat][m.sender];
          saveWarnBook(book);
        }
      } else if (action === "kick") {
        await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove").catch(() => {});
      }
      return true;
    }
    return false;
  } catch (e) {
    console.log("[anti] " + e.message);
    return false;
  }
}

// ─── REPLY FONT ────────────────────────────────────────────────────────
const FONT_MAPS = {
  small: { a: "ᴀ", b: "ʙ", c: "ᴄ", d: "ᴅ", e: "ᴇ", f: "ғ", g: "ɢ", h: "ʜ", i: "ɪ", j: "ᴊ", k: "ᴋ", l: "ʟ", m: "ᴍ", n: "ɴ", o: "ᴏ", p: "ᴘ", q: "ǫ", r: "ʀ", s: "s", t: "ᴛ", u: "ᴜ", v: "ᴠ", w: "ᴡ", x: "x", y: "ʏ", z: "ᴢ" },
  script: (() => { const o = {}; const base = 0x1d4ea; for (let i = 0; i < 26; i++) o[String.fromCharCode(97 + i)] = String.fromCodePoint(base + i); return o; })(),
  bold: (() => { const o = {}; const base = 0x1d41a; for (let i = 0; i < 26; i++) o[String.fromCharCode(97 + i)] = String.fromCodePoint(base + i); return o; })(),
};
function applyFont(t) {
  const mode = global.__pixelFont || "none";
  const map = FONT_MAPS[mode];
  if (!map) return t;
  return String(t).replace(/[a-z]/g, (ch) => map[ch] || ch);
}



// ─── STATUS WATCHER (auto-react + anti-delete-status) ──────────────────
const STATUS_STORE = new Map();
const ACTIVITY_FILE = "./database/activity.json";

function ownerJids() {
  try { return JSON.parse(fs.readFileSync("./database/owner.json", "utf8")) || []; } catch { return []; }
}

async function handleIncomingStatus(sock, m) {
  try {
    const st = readBotSettings();
    const id = m.key && m.key.id;
    const sender = m.key?.participant || m.sender || "";
    if (!id || !sender) return;

    if (st.autostatusreact) {
      const list = String(st.statusemoji || "❤️").split(",").map((x) => x.trim()).filter(Boolean);
      const emoji = list[Math.floor(Math.random() * list.length)] || "❤️";
      await sock.sendMessage("status@broadcast", { react: { text: emoji, key: m.key } }, { statusJidList: [sender] }).catch(() => {});
    }

    if (st.antideletestatus) {
      let file = null;
      try {
        if (/imageMessage|videoMessage/.test(m.mtype || "")) {
          const buf = await sock.downloadMediaMessage(m);
          fs.mkdirSync("./database/status", { recursive: true });
          file = `./database/status/${id}.${/videoMessage/.test(m.mtype) ? "mp4" : "jpg"}`;
          fs.writeFileSync(file, buf);
        }
      } catch (e) { /* media unavailable – text copy still works */ }
      STATUS_STORE.set(id, { sender, mtype: m.mtype || "", text: m.text || m.body || "", file, at: Date.now() });
      if (STATUS_STORE.size > 300) STATUS_STORE.delete(STATUS_STORE.keys().next().value);
    }
  } catch (e) {
    console.log("[status] " + e.message);
  }
}

function attachStatusWatch(sock) {
  if (!sock || global.__statusWatchSock === sock) return;
  global.__statusWatchSock = sock;
  sock.ev.on("messages.update", async (ups) => {
    try {
      const st = readBotSettings();
      if (!st.antideletestatus) return;
      const owner = (ownerJids()[0] || "").split("@")[0];
      if (!owner) return;
      for (const item of ups || []) {
        const key = item.key || {};
        if (key.remoteJid !== "status@broadcast") continue;
        const update = item.update || {};
        const revoked = update.messageStubType === 1 || update.message === null;
        if (!revoked) continue;
        const rec = STATUS_STORE.get(key.id);
        if (!rec) continue;
        const to = owner + "@s.whatsapp.net";
        const num = String(rec.sender).split("@")[0];
        const cap = `🚫 *Status deleted*\nFrom: @${num}`;
        if (rec.file && fs.existsSync(rec.file)) {
          const buf = fs.readFileSync(rec.file);
          const payload = /\.mp4$/.test(rec.file) ? { video: buf, caption: cap, mentions: [rec.sender] } : { image: buf, caption: cap, mentions: [rec.sender] };
          await sock.sendMessage(to, payload).catch(() => {});
        } else {
          await sock.sendMessage(to, { text: `${cap}\n\n${rec.text || "(no text)"}`, mentions: [rec.sender] }).catch(() => {});
        }
        STATUS_STORE.delete(key.id);
      }
    } catch (e) {
      console.log("[status-watch] " + e.message);
    }
  });
}

// persist the activity map so kickinactive / listoffline survive restarts
function loadActivity() {
  try {
    const raw = JSON.parse(fs.readFileSync(ACTIVITY_FILE, "utf8")) || {};
    for (const [k, v] of Object.entries(raw)) ACTIVITY.set(k, v);
  } catch {}
}
function saveActivity() {
  try {
    const out = {};
    for (const [k, v] of ACTIVITY) if (Date.now() - v < 30 * 24 * 3600 * 1000) out[k] = v;
    fs.writeFileSync(ACTIVITY_FILE, JSON.stringify(out));
  } catch {}
}
loadActivity();
if (!global.__activityTimer) {
  global.__activityTimer = setInterval(saveActivity, 60000);
  global.__activityTimer.unref?.();
}

// Single source of truth for every owner toggle. Anything changed in WhatsApp is
// written here immediately, so a restart restores the exact same state.
function saveSettings() {
  try {
    let settings = {};
    try {
      settings = JSON.parse(fs.readFileSync(settingsFile, "utf8")) || {};
    } catch {}

    const put = (key, val) => {
      if (val !== undefined) settings[key] = val;
    };
    put("autoviewstatus", global.autoviewstatus);
    put("autolikestatus", global.autolikestatus);
    put("autolikestatusEmoji", global.autolikestatusEmoji);
    put("autoread", global.autoread);
    put("autoTyping", global.autoTyping);
    put("autoRecording", global.autoRecording);
    put("autorecordtype", global.autorecordtype);
    put("autobio", global.autobio);
    put("autoreact", global.autoreact);
    put("autoOffline", global.autoOffline);
    put("prefix", global.prefix);
    put("mode", global.botMode || settings.mode || "private");

    // antiDelete lives in index.js; keep whatever is already stored if the
    // helper is not mounted yet instead of throwing and losing the whole save.
    try {
      if (typeof getAntiDeleteStatus === "function") {
        settings.antiDelete = !!getAntiDeleteStatus();
      }
    } catch {}

    fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2));
    return settings;
  } catch (err) {
    console.log("[settings] save failed: " + (err && err.message));
    return null;
  }
}

function normalizeOwnerId(value) {
  const id = String(value || "")
    .trim()
    .toLowerCase();
  if (id.endsWith("@lid")) return id.replace(/:\d+(?=@lid$)/, "");
  const digits = id.replace(/\D/g, "");
  return digits ? `${digits}@s.whatsapp.net` : "";
}

module.exports = async (EliteProTech, m, chatUpdate, store) => {
  try {
    const { type, quotedMsg, mentioned, now, fromMe } = m;
    var body =
      m.mtype === "conversation"
        ? m.message.conversation
        : m.mtype == "imageMessage"
          ? m.message.imageMessage.caption
          : m.mtype == "videoMessage"
            ? m.message.videoMessage.caption
            : m.mtype == "extendedTextMessage"
              ? m.message.extendedTextMessage.text
              : m.mtype == "buttonsResponseMessage"
                ? m.message.buttonsResponseMessage.selectedButtonId
                : m.mtype == "listResponseMessage"
                  ? m.message.listResponseMessage.singleSelectReply
                      ?.selectedRowId
                  : m.mtype == "templateButtonReplyMessage"
                    ? m.message.templateButtonReplyMessage.selectedId
                    : m.mtype == "interactiveResponseMessage"
                      ? (() => {
                          try {
                            return JSON.parse(
                              m.message.interactiveResponseMessage
                                .nativeFlowResponseMessage.paramsJson,
                            ).id;
                          } catch {
                            return "";
                          }
                        })()
                      : m.mtype === "messageContextInfo"
                        ? m.message.buttonsResponseMessage?.selectedButtonId ||
                          m.message.listResponseMessage?.singleSelectReply
                            ?.selectedRowId ||
                          m.text
                        : "";
    var budy = typeof m.text === "string" ? m.text : "";
    const safeBody = typeof body === "string" && body.length ? body : budy;
    const prefix = global.prefix !== undefined ? global.prefix : ".";
    let isCmd;
    let command;
    if (prefix === "") {
      isCmd = safeBody.trim().length > 0;
      command = isCmd ? safeBody.trim().split(/\s+/).shift().toLowerCase() : "";
    } else {
      // Any prefix works: emoji, digit, symbol or a whole word (multi-char).
      const _pstr = String(prefix);
      const _head = safeBody.slice(0, _pstr.length);
      // A letter/digit/emoji prefix also accepts a space after it, so
      // "pixel menu", "1 menu" and "🔥 menu" work the way people type them.
      // Punctuation prefixes ( . / ! ) stay strict.
      const _wordPrefix = /[\p{L}\p{N}\p{Extended_Pictographic}]/u.test(_pstr);
      isCmd =
        _head.length === _pstr.length &&
        _head.toLowerCase() === _pstr.toLowerCase() &&
        (safeBody[_pstr.length] !== " " || _wordPrefix);
      command = isCmd
        ? safeBody
            .slice(prefix.length)
            .trim()
            .split(/\s+/)
            .shift()
            .toLowerCase()
        : "";
    }
    // Prefix-free mode: a bare known command still runs (ASTRO parity).
    let bareCmd = false;
    if (!isCmd && prefix !== "" && safeBody) {
      const firstWord = safeBody.trim().split(/\s+/).shift().toLowerCase();
      if (
        firstWord &&
        ((prefixFreeOn() && BARE_COMMANDS.has(firstWord)) ||
          ALWAYS_BARE.has(firstWord))
      ) {
        isCmd = true;
        bareCmd = true;
        command = firstWord;
      }
    }
    const args = bareCmd
      ? safeBody.trim().split(/\s+/).slice(1)
      : safeBody.trim().split(/\s+/).slice(1);
    const full_args = isCmd
      ? bareCmd
        ? safeBody.trim().slice(command.length).trim()
        : prefix === ""
          ? safeBody.trim().slice(command.length).trim()
          : safeBody.slice(prefix.length).trim().slice(command.length).trim()
      : "";
    const pushname = m.pushName || "user";
    const botNumber = await EliteProTech.decodeJid(EliteProTech.user.id);
    const itsMe = m.sender == botNumber ? true : false;
    const sender = m.sender;
    const text = args.join(" ");
    const q = text;
    const from = m.key.remoteJid;
    const fatkuns = m.quoted || m;
    const quoted =
      fatkuns.mtype == "buttonsMessage"
        ? fatkuns[Object.keys(fatkuns)[1]]
        : fatkuns.mtype == "templateMessage"
          ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]]
          : fatkuns.mtype == "product"
            ? fatkuns[Object.keys(fatkuns)[0]]
            : m.quoted
              ? m.quoted
              : m;
    const mime = (quoted.msg || quoted).mimetype || "";
    const qmsg = quoted.msg || quoted;
    const isMedia = /image|video|sticker|audio/.test(mime);
    const isImage = type == "imageMessage";
    const isVideo = type == "videoMessage";
    const isAudio = type == "audioMessage";
    const isText = type == "textMessage";
    const isSticker = type == "stickerMessage";
    const isQuotedText =
      type === "extendexTextMessage" && content.includes("textMessage");
    const isQuotedImage =
      type === "extendedTextMessage" && content.includes("imageMessage");
    const isQuotedLocation =
      type === "extendedTextMessage" && content.includes("locationMessage");
    const isQuotedVideo =
      type === "extendedTextMessage" && content.includes("videoMessage");
    const isQuotedSticker =
      type === "extendedTextMessage" && content.includes("stickerMessage");
    const isQuotedAudio =
      type === "extendedTextMessage" && content.includes("audioMessage");
    const isQuotedContact =
      type === "extendedTextMessage" && content.includes("contactMessage");
    const isQuotedDocument =
      type === "extendedTextMessage" && content.includes("documentMessage");
    const isGroup = m.key.remoteJid.endsWith("@g.us");
    // ── GROUP ADMIN DETECTION (LID + PN safe, multi-device safe) ──────────
    // WhatsApp now returns participants under @lid for some accounts while the
    // bot identifies itself under @s.whatsapp.net (or vice versa), so string
    // equality on the full JID reports "not admin" for a real admin. We compare
    // the numeric core across every identifier a participant carries.
    const _jidCore = (j) =>
      String(j || "").split("@")[0].split(":")[0].replace(/\D/g, "");
    const _coresOf = (p) => {
      if (!p) return [];
      const raw = [p.id, p.jid, p.pn, p.lid, p.phoneNumber, p.phone, p.participant];
      const out = [];
      for (const v of raw) {
        const c = _jidCore(v);
        if (c) out.push(c);
      }
      return out;
    };
    let groupMetadata = m.isGroup
      ? await EliteProTech.groupMetadata(m.chat).catch(() => null)
      : null;
    if (m.isGroup && (!groupMetadata || !Array.isArray(groupMetadata.participants))) {
      groupMetadata = await EliteProTech.groupMetadata(m.chat).catch(() => null);
    }
    const groupName = groupMetadata?.subject || "";
    const participants = Array.isArray(groupMetadata?.participants)
      ? groupMetadata.participants
      : [];
    const _adminCores = new Set();
    const groupAdmins = [];
    for (const p of participants) {
      if (p && (p.admin === "admin" || p.admin === "superadmin")) {
        const cores = _coresOf(p);
        for (const c of cores) { _adminCores.add(c); groupAdmins.push(c); }
      }
    }
    const _botCores = Array.from(
      new Set(
        [
          _jidCore(botNumber),
          _jidCore(EliteProTech.user?.id),
          _jidCore(EliteProTech.user?.lid),
          _jidCore(EliteProTech.user?.phoneNumber),
        ].filter(Boolean),
      ),
    );
    const _senderCores = Array.from(
      new Set(
        [
          _jidCore(m.sender),
          _jidCore(m.key?.participantPn),
          _jidCore(m.key?.participant),
          _jidCore(m.participant),
        ].filter(Boolean),
      ),
    );
    const isBotAdmins = m.isGroup
      ? _botCores.some((c) => _adminCores.has(c))
      : false;
    const isAdmins = m.isGroup
      ? _senderCores.some((c) => _adminCores.has(c))
      : false;
    const groupOwner = groupMetadata?.owner || "";
    const _ownerCores = groupOwner
      ? [_jidCore(groupOwner)].filter(Boolean)
      : Array.from(_adminCores);
    const isGroupOwner = m.isGroup
      ? _senderCores.some((c) => _ownerCores.includes(c))
      : false;
    const cleanLid = EliteProTech.user?.lid
      ? EliteProTech.user.lid.replace(/:\d+/, "")
      : "";
    const cleanId = EliteProTech.user?.id
      ? EliteProTech.user.id.replace(/:\d+/, "")
      : "";
    const ownerIds = [..._owner, cleanLid, cleanId]
      .map(normalizeOwnerId)
      .filter(Boolean);
    const isCreator = ownerIds.includes(normalizeOwnerId(m.sender));

    const reply = (teks) => {
      // Quote the real incoming message. Quoting a synthetic status stanza made
      // the recipient render "Waiting for this message. This may take a while."
      EliteProTech.sendMessage(m.chat, { text: applyFont(teks) }, { quoted: statusQuote(m) });
    };

    // keep the fake-status thumbnail pointing at the paired number's avatar
    warmStatusQuote(EliteProTech, botNumber).catch(() => {});

    // anti-edit cache + watcher, anti-bug crash filter
    storeForAntiedit(m);
    attachAntiedit(EliteProTech);
    attachStatusWatch(EliteProTech);
    if (autoread) {
      await EliteProTech.readMessages([m.key]).catch(() => {});
    }

    if (m.chat === "status@broadcast" || m.key?.remoteJid === "status@broadcast") {
      handleIncomingStatus(EliteProTech, m).catch(() => {});
    }

    if (global.autoTyping) {
      await EliteProTech.sendPresenceUpdate("composing", from).catch(() => {});
    }

    if (global.autoRecording) {
      await EliteProTech.sendPresenceUpdate("recording", from).catch(() => {});
    }

    /*
// bot number online status, available = online, unavailable = offline
if (autoOffline) {
    await EliteProTech.sendPresenceUpdate('unavailable', from).catch(() => {})
}
*/

    if (global.autorecordtype) {
      let eliterecordin = ["recording", "composing"];
      let eliterecordinfinal =
        eliterecordin[Math.floor(Math.random() * eliterecordin.length)];
      await EliteProTech.sendPresenceUpdate(eliterecordinfinal, from).catch(
        () => {},
      );
    }

    if (!EliteProTech.public) {
      if (!isCreator && !m.key.fromMe) return;
    }

    attachGroupListener(EliteProTech);

    // muted members: delete their messages in groups where the bot is admin
    if (m.isGroup && !isAdmins && !m.key.fromMe && isMutedMember(m.chat, m.sender)) {
      if (isBotAdmins) {
        try {
          await EliteProTech.sendMessage(m.chat, { delete: m.key });
          return;
        } catch (e) {
          console.log("[mute] delete failed: " + e.message);
        }
      }
    }

    // activity record (used by listoffline / kickinactive / kickactive)
    if (m.isGroup && !m.key.fromMe) ACTIVITY.set(`${m.chat}|${m.sender}`, Date.now());

    // auto-sticker: turn members' images into stickers when the group flag is on
    if (m.isGroup && !isAdmins && !isCreator && !m.key.fromMe && isBotAdmins && /imageMessage/.test(m.mtype || "")) {
      const gc = readGroups()[m.chat];
      if (gc && gc.autosticker) {
        try {
          const buf = await EliteProTech.downloadMediaMessage(m);
          await EliteProTech.sendImageAsSticker(m.chat, buf, m, { packname: global.packname, author: global.author });
          await EliteProTech.sendMessage(m.chat, { delete: m.key }).catch(() => {});
          return;
        } catch (e) {
          console.log("[autosticker] " + e.message);
        }
      }
    }

    if (
      await runAnti(EliteProTech, m, {
        chat: m.chat,
        sender: m.sender,
        isGroup: m.isGroup,
        isAdmins,
        isBotAdmins,
        isCreator,
        groupMetadata,
      })
    )
      return;

    if (
      await runAntibug(EliteProTech, m, {
        chat: m.chat,
        sender: m.sender,
        isGroup: m.isGroup,
        isAdmins,
        isBotAdmins,
        isCreator,
        groupName,
        self: botNumber.split("@")[0] + "@s.whatsapp.net",
      })
    )
      return;

    if (autobio) {
      EliteProTech.updateProfileStatus(
        `ᴘɪxᴇʟ x ᴜʟᴛʀᴀ ɪꜱ ɴᴏᴡ ᴀᴄᴛɪᴠᴇ ❯ ϙᴜᴏᴛᴇꜱ: ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴛᴏ ʙᴇ ɢʀᴇᴀᴛ ᴛᴏ ꜱᴛᴀʀᴛ, ʙᴜᴛ ʏᴏᴜ ʜᴀᴠᴇ ᴛᴏ ꜱᴛᴀʀᴛ ᴛᴏ ʙᴇ ɢʀᴇᴀᴛ. 🚀`,
      ).catch(() => {});
    }

    //CHAT COUNTER COUNSEL (CONSOLE LOG)//
    if (isCmd) {
      console.log(
        chalk.cyan(
          `\n< ================================================== >\n`,
        ),
      );
      console.log(
        chalk.green(m.message && m.isGroup ? `Group Chat:` : `Private Chat:`),
      );
      console.log(
        chalk.black(chalk.bgWhite("[ MESSAGE ]")),
        chalk.black(chalk.bgGreen(new Date())),
        chalk.black(chalk.bgBlue(budy || m.mtype)) +
          "\n" +
          chalk.magenta("=> From"),
        chalk.green(pushname),
        chalk.yellow(m.sender) +
          (m.message && m.isGroup
            ? "\n" +
              chalk.blueBright("=> In") +
              " " +
              chalk.green(groupName, m.chat)
            : ""),
      );
    }

    switch (command) {
      case "pong":
      case "p":
      case "ping":
        {
          const sharp = require("sharp");
          const start = performance.now();
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⚙️", key: m.key },
          });
          function formatUptime(seconds) {
            const d = Math.floor(seconds / 86400);
            seconds %= 86400;
            const h = Math.floor(seconds / 3600);
            seconds %= 3600;
            const m = Math.floor(seconds / 60);
            const s = Math.floor(seconds % 60);
            return `${d > 0 ? d + "d " : ""}${h}h ${m}m ${s}s`;
          }
          let profilepuser = elitepropic;
          try {
            const ppUrl = await EliteProTech.profilePictureUrl(
              m.sender,
              "image",
            );
            const { data } = await axios.get(ppUrl, {
              responseType: "arraybuffer",
              timeout: 5000,
            });
            profilepuser = Buffer.from(data);
          } catch {}
          const thumb = await sharp(profilepuser)
            .resize(200, 200)
            .jpeg({ quality: 40 })
            .toBuffer();
          const fakeQuoted = {
            key: {
              remoteJid: m.chat,
              fromMe: false,
              participant: m.sender,
              id: "fakereplyids",
            },
            message: {
              imageMessage: {
                mimetype: "image/jpeg",
                jpegThumbnail: thumb,
                caption: `⏱️ Uptime: ${formatUptime(process.uptime())}`,
              },
            },
          };
          const latency = Math.floor(performance.now() - start);
          await EliteProTech.sendMessage(
            m.chat,
            { text: `*🌩️ 𝐁𝐨𝐭 𝐏๏፝֟ƞ̽g ${latency} 𝐌ʂ*` },
            { quoted: fakeQuoted },
          );
        }
        break;
      case "botcheck":
      case "status":
      case "alive":
      case "test":
        {
          try {
            const packageJson = JSON.parse(
              fs.readFileSync("./package.json", "utf8"),
            );
            const botVersion = packageJson.version || "Unknown";

            const start = performance.now();

            const contactMessage = {
              key: {
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
              },
              message: {
                contactMessage: {
                  displayName: author,
                  vcard: `BEGIN:VCARD
VERSION:3.0
N:;${author};;;;
FN:${author}
item1.TEL;waid=${m.sender.split("@")[0]}:${m.sender.split("@")[0]}
item1.X-ABLabel:Ponsel
END:VCARD`,
                },
              },
            };

            const end = performance.now();
            const speed = (end - start).toFixed(4);

            const runtime = process.uptime();
            const hours = Math.floor(runtime / 3600);
            const minutes = Math.floor((runtime % 3600) / 60);
            const seconds = Math.floor(runtime % 60);
            const uptime = `${hours} H ${minutes} M ${seconds} S`;

            const usedMemory = process.memoryUsage();
            const ramUsed = (usedMemory.rss / 1024 / 1024).toFixed(2);
            const heapUsed = (usedMemory.heapUsed / 1024 / 1024).toFixed(2);
            const heapTotal = (usedMemory.heapTotal / 1024 / 1024).toFixed(2);
            const totalRam = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
            const freeRam = (os.freemem() / 1024 / 1024 / 1024).toFixed(2);

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: `🤖 *${botname} is Alive!*
*⌜ System Info ⌟*

*▧ Speed :* ${speed} ms
*▧ Bot Version :* v${botVersion}
*▧ Uptime :* ${uptime}
*▧ RAM :* ${freeRam}GB / ${totalRam}GB Free
*▧ Memory :* ${ramUsed}MB RSS
*▧ Heap :* ${heapUsed}MB / ${heapTotal}MB`,
                contextInfo: {
                  forwardingScore: 999,
                  isForwarded: true,
                  forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363287352245413@newsletter",
                    newsletterName: `ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ`,
                    serverMessageId: 1,
                  },
                },
              },
              { quoted: contactMessage },
            );
          } catch (err) {
            console.log("Alive error:", err);
            reply("❌ Error checking bot status");
          }
        }
        break;
      case "readmore":
        {
          let [l, r] = text.split`|`;
          if (!l) l = "";
          if (!r) r = "";
          EliteProTech.sendMessage(
            m.chat,
            { text: l + readmore + r },
            { quoted: m },
          );
        }
        break;
      case "define":
        if (!q) return reply(`What do you want to define?`);
        try {
          targetfine = await axios.get(
            `http://api.urbandictionary.com/v0/define?term=${q}`,
          );
          if (!targetfine) return reply(mess.error);
          const reply = `Word:* ${q}
Definition:* ${targetfine.data.list[0].definition
            .replace(/\[/g, "")
            .replace(/\]/g, "")}
Example:* ${targetfine.data.list[0].example
            .replace(/\[/g, "")
            .replace(/\]/g, "")}`;
          EliteProTech.sendMessage(m.chat, { text: reply }, { quoted: m });
        } catch (err) {
          console.log(err);
          return reply(`*${q}* isn't a valid text`);
        }
        //Savecontacts in group
        break;
      case "savecontact":
      case "svcontact":
      case "vcard":
      case "contacts":
      case "exportcontacts":
      case "vcf":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply(mess.admin);
          if (!isBotAdmins) return reply(mess.botAdmin);

          const meta = await EliteProTech.groupMetadata(m.chat);
          const participants = meta.participants;

          let vcard = "";
          let index = 1;

          for (let p of participants) {
            let rawJid = p.jid || p.id || p.lid;
            if (!rawJid) continue;
            let number = rawJid.split("@")[0];
            let waName;
            try {
              waName = await EliteProTech.getName(rawJid);
            } catch {
              waName = number;
            }

            // Build VCF
            vcard += `BEGIN:VCARD
VERSION:3.0
FN:${waName}
N:${waName};;;;
TEL;type=CELL;type=VOICE;waid=${number}:+${number}
END:VCARD
`;
            index++;
          }
          const filePath = "./contacts.vcf";
          fs.writeFileSync(filePath, vcard.trim());

          await sleep(1500);
          await EliteProTech.sendMessage(
            m.chat,
            {
              document: fs.readFileSync(filePath),
              mimetype: "text/vcard",
              fileName: "Group-Contacts.vcf",
              caption: `*Group:* ${meta.subject}\n*Contacts:* ${participants.length}`,
            },
            { quoted: m },
          );
          fs.unlinkSync(filePath);
        }
        //Send contacts in group
        break;
      case "sendcontact":
      case "sencontact":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!m.mentionedJid[0])
            return reply("\nUse like this\n Example:.sendcontact @tag|name");
          let snTak = text.split(" ")[1] ? text.split(" ")[1] : "Contact";
          let snContact = {
            displayName: "Contact",
            contacts: [
              {
                displayName: snTak,
                vcard:
                  "BEGIN:VCARD\nVERSION:3.0\nN:;" +
                  snTak +
                  ";;;\nFN:" +
                  snTak +
                  "\nitem1.TEL;waid=" +
                  m.mentionedJid[0].split("@")[0] +
                  ":" +
                  m.mentionedJid[0].split("@")[0] +
                  "\nitem1.X-ABLabel:Mobile\nEND:VCARD",
              },
            ],
          };
          EliteProTech.sendMessage(
            m.chat,
            { contacts: snContact },
            { ephemeralExpiration: 86400 },
          );
        }
        //Contact tag
        break;
      case "contacttag":
      case "contag":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply(mess.admin);
          if (!isBotAdmins) return reply(mess.botAdmin);
          if (!m.mentionedJid[0])
            return reply("\nUse like this\n Example:.contacttag @tag|name");
          let sngTak = text.split(" ")[1] ? text.split(" ")[1] : "Contact";
          let sngContact = {
            displayName: "Contact",
            contacts: [
              {
                displayName: sngTak,
                vcard:
                  "BEGIN:VCARD\nVERSION:3.0\nN:;" +
                  sngTak +
                  ";;;\nFN:" +
                  sngTak +
                  "\nitem1.TEL;waid=" +
                  m.mentionedJid[0].split("@")[0] +
                  ":" +
                  m.mentionedJid[0].split("@")[0] +
                  "\nitem1.X-ABLabel:Mobile\nEND:VCARD",
              },
            ],
          };
          EliteProTech.sendMessage(
            m.chat,
            { contacts: sngContact, mentions: participants.map((a) => a.id) },
            { ephemeralExpiration: 86400 },
          );
        }
        break;
      case "flux":
        {
          try {
            if (!q) return reply(`⚠️ Example: *${prefix + command} car*`);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🎨", key: m.key },
            });

            const apiUrl = `https://omegatech-api.dixonomega.tech/api/ai/magicstudio?prompt=${encodeURIComponent(q)}`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: apiUrl },
                caption: `✅ *Flux Image for:* ${q}`,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (e) {
            console.error("Error generating flux image");

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            reply("❌ Error generating flux image, please try again.");
          }
        }
        break;
      case "tt":
      case "tiktokdl":
      case "tiktok": {
        if (!text) {
          return reply(
            `Send a TikTok URL or search keywords.\n\n*Example:*\n${prefix + command} https://vt.tiktok.com/ZSUMvWufM/\n${prefix + command} Dax`,
          );
        }
        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "📥", key: m.key },
          });

          if (text.startsWith("http")) {
            const apiUrl = `https://eliteprotech-apis.zone.id/download/tiktok2?url=${encodeURIComponent(text)}`;
            const { data } = await axios.get(apiUrl);

            if (!data.success || !data.data) {
              return reply("⚠️ Failed to fetch TikTok video.");
            }

            const video = data.data;
            const videoUrl = video.play || video.wmplay;

            if (!videoUrl) {
              return reply("⚠️ No downloadable video found.");
            }

            const caption = `🎬 *TikTok Video*

📝 *Title:* ${video.title || "No title"}
👤 *Author:* ${video.author?.nickname || "Unknown"}
⏱️ *Duration:* ${video.duration || 0}s
❤️ *Likes:* ${Number(video.stats?.digg_count || 0).toLocaleString()}
💬 *Comments:* ${Number(video.stats?.comment_count || 0).toLocaleString()}
🔄 *Shares:* ${Number(video.stats?.share_count || 0).toLocaleString()}
▶️ *Views:* ${Number(video.stats?.play_count || 0).toLocaleString()}

> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`;

            return await EliteProTech.sendMessage(
              m.chat,
              {
                video: { url: videoUrl },
                mimetype: "video/mp4",
                caption,
              },
              { quoted: m },
            );
          }
          const searchUrl = `https://eliteprotech-apis.zone.id/search/tiktoksearch?q=${encodeURIComponent(text)}`;
          const { data } = await axios.get(searchUrl);

          if (data?.error || !data?.results?.length) {
            return reply("❌ No TikTok videos found.");
          }

          const first = data.results[0];

          const caption = `🔎 *TikTok Search Result*

🎬 *Title:* ${first.title || "No title"}
🕒 *Duration:* ${first.duration || "N/A"}s

> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`;

          await EliteProTech.sendMessage(
            m.chat,
            {
              video: { url: first.play },
              mimetype: "video/mp4",
              caption,
            },
            { quoted: m },
          );
        } catch (err) {
          console.error("TikTok Error:", err);
          reply("❌ An error occurred.");
        }
        break;
      }
      case "tiktokstalk":
      case "tiktoksearch": {
        if (!text) return reply(`*Example:* ${prefix + command} username`);

        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "🔍", key: m.key },
          });

          const apiUrl = `https://eliteprotech-apis.zone.id/search/tiktokstalk?username=${encodeURIComponent(text)}`;
          const { data } = await axios.get(apiUrl);

          if (!data || data.status !== "success" || !data.data) {
            return reply(
              "⚠️ User not found. Please check the TikTok username.",
            );
          }

          const user = data.data;

          const userInfo = `
🎯 *TikTok User Info*
👤 Username: ${user.uniqueId}
📝 Nickname: ${user.nickname}
💬 Bio: ${user.bio || "No bio"}
✅ Verified: ${user.verified ? "Yes" : "No"}
🔒 Private: ${user.private ? "Yes" : "No"}
👥 Followers: ${user.followers}
👣 Following: ${user.following}
❤️ Hearts: ${user.hearts}
🎥 Videos: ${user.videos}
🔗 Profile: ${user.profileUrl}
> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*
`;

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: user.avatar },
              caption: userInfo,
            },
            { quoted: m },
          );
        } catch (error) {
          console.error("Error during TikTok search:", error);
          reply("❌ An error occurred while searching TikTok user.");
        }
        break;
      }
      case "mediafire": {
        if (!text)
          return reply(
            `*Example:* ${prefix + command} https://www.mediafire.com/file/rmpx6iv7kiboki3/ELITEPRO-master+(2).zip/file`,
          );

        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: `📥`, key: m?.key },
          });

          const apiUrl = `https://eliteprotech-apis.zone.id/download/mediafire?url=${encodeURIComponent(text)}`;
          const { data } = await axios.get(apiUrl);

          if (data?.status && data?.download) {
            const { name, filename, mimetype, size, download } = data;

            await EliteProTech.sendMessage(
              m.chat,
              {
                document: { url: download },
                mimetype: mimetype || "application/octet-stream",
                fileName: filename || name || "file",
                caption: `📦 *File Name:* ${name}\n📁 *Size:* ${size}\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
              },
              { quoted: m },
            );
          } else {
            reply(
              `❌ *Failed to fetch file details!*\nPlease check the MediaFire URL and try again.`,
            );
          }
        } catch (error) {
          console.error("Error during MediaFire command:", error);
          reply(
            `⚠️ *An error occurred while processing your request.*\nPlease try again later.`,
          );
        }
        break;
      }
      case "wallpaper": {
        if (!text) {
          return reply(`*𝙿𝚛𝚎𝚏𝚒𝚡:* ${command} Naruto`);
        }

        function getRandomIndexes(max, count) {
          const indexes = [];
          while (indexes.length < count && indexes.length < max) {
            const rand = Math.floor(Math.random() * max);
            if (!indexes.includes(rand)) indexes.push(rand);
          }
          return indexes;
        }

        try {
          const apiUrl = `https://weeb-api.vercel.app/wallpaper?query=${encodeURIComponent(text)}`;
          const response = await fetch(apiUrl);

          if (!response.ok) {
            return reply(
              `*ERROR!!*\n\n> Failed to fetch wallpapers. Status: ${response.status}`,
            );
          }

          const imageUrls = await response.json();

          if (!imageUrls.length) {
            return reply(
              `No wallpapers found for "${text}". Try a different keyword.`,
            );
          }

          const maxResults = Math.min(imageUrls.length, 5); // send up to 5 wallpapers
          const randomIndexes = getRandomIndexes(imageUrls.length, maxResults);
          const selectedImages = randomIndexes.map((i) => imageUrls[i]);

          for (let i = 0; i < selectedImages.length; i++) {
            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: selectedImages[i] },
                caption: `🎨 *Wallpaper Search*\n\n📄 Search: "${text}"\n🖼 Wallpaper ${i + 1}/${maxResults}\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
              },
              { quoted: m },
            );
          }
        } catch (error) {
          console.error("Wallpaper Error:", error);
          reply(`*AN ERROR OCCURRED!!*\n\n> ${error.message || error}`);
        }
        break;
      }
      case "profilepic":
      case "pp":
      case "pfp":
      case "gp":
      case "getpic":
      case "getdp":
      case "getpp":
        {
          let target = m.sender;
          const defaultPP =
            "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png";

          if (m.quoted && m.quoted.sender) {
            target = m.quoted.sender;
          } else if (m.mentionedJid && m.mentionedJid.length > 0) {
            target = m.mentionedJid[0];
          } else if (args[0]) {
            let number = args[0].replace(/[^0-9]/g, "");
            if (!number) return reply("Provide a valid number.");
            target = number + "@s.whatsapp.net";
          } else if (!m.isGroup) {
            target = m.key.fromMe ? m.chat : m.sender;
          } else if (m.isGroup) {
            let groupPP;
            try {
              groupPP = await EliteProTech.profilePictureUrl(m.chat, "image");
            } catch {
              groupPP = defaultPP;
            }

            return await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: groupPP },
                caption: `*Group Profile Picture*`,
              },
              { quoted: m },
            );
          }

          let pp;
          try {
            pp = await EliteProTech.profilePictureUrl(target, "image");
          } catch {
            pp = defaultPP;
          }

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: pp },
              caption: `*@${target.split("@")[0]} profile picture*`,
              mentions: [target],
            },
            { quoted: m },
          );
        }
        break;
      case "getgrouppp":
      case "groupprofile":
        {
          if (!args[0])
            return reply("Provide a group invite link or group JID.");

          const defaultPP =
            "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png";
          let groupJid;

          const input = args[0];

          if (input.includes("chat.whatsapp.com/")) {
            const inviteCode = input.split("chat.whatsapp.com/")[1];
            try {
              const groupInfo =
                await EliteProTech.groupGetInviteInfo(inviteCode);
              groupJid = groupInfo.id;
            } catch {
              return reply("Invalid or expired group link.");
            }
          } else if (input.endsWith("@g.us")) {
            groupJid = input;
          } else {
            return reply("Invalid input. Provide a valid group link or JID.");
          }

          let groupPP;
          try {
            groupPP = await EliteProTech.profilePictureUrl(groupJid, "image");
          } catch {
            groupPP = defaultPP;
          }

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: groupPP },
              caption: `*Group Profile Picture*`,
            },
            { quoted: m },
          );
        }
        break;
      case "randomfact":
      case "quotes":
        const quoteelitey = await axios.get(`https://favqs.com/api/qotd`);
        const textquotes = `*Quote:* ${quoteelitey.data.quote.body}\n\nAuthor:* ${quoteelitey.data.quote.author}`;
        return reply(textquotes);
        break;
      case "quote":
      case "fact":
        {
          const { data } = await axios.get(`https://nekos.life/api/v2/fact`);
          return reply(`*Fact:* ${data.fact}\n`);
        }
        break;
      case "yta":
      case "play":
      case "ytmp3":
        {
          if (!text)
            return reply(`*Example:* ${prefix + command} Faded by Alan Walker`);
          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🎵", key: m.key },
            });
            const ytRegex =
              /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/i;
            let video;
            let videoUrl;
            if (ytRegex.test(text)) {
              videoUrl = text;
            } else {
              const search = await yts(text);
              video = search.videos[0];
              if (!video) {
                await EliteProTech.sendMessage(m.chat, {
                  react: { text: "❌", key: m.key },
                });
                return reply(`*No results found for:* ${text}`);
              }
              videoUrl = video.url;
            }
            if (video) {
              const body = `╭━━━━━━━━━
┃ *PIXEL MUSIC - DOWNLOADER*

> *ᴛɪᴛʟᴇ:* ${video.title}

┃ *ᴠɪᴇᴡꜱ:* ${video.views}
┃ *ᴅᴜʀᴀᴛɪᴏɴ:* ${video.timestamp}
┃ *ᴜᴘʟᴏᴀᴅᴇᴅ:* ${video.ago}

> *ᴜʀʟ:* ${videoUrl}

┃ *Enjoy your music®*
╰━━━━━━━━━━━━━━━━━━┈⊷
> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`;
              await EliteProTech.sendMessage(
                m.chat,
                {
                  image: { url: video.thumbnail },
                  caption: body,
                },
                { quoted: m },
              );
            }
            const apiUrl = `https://eliteprotech-apis.zone.id/download/ytmp3?url=${encodeURIComponent(videoUrl)}`;
            const { data } = await axios.get(apiUrl, {
              timeout: 120000,
            });
            if (!data?.status || !data?.download?.downloadUrl) {
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "❌", key: m.key },
              });
              return reply("*❌ Failed to fetch the song! Try again later.*");
            }
            const title =
              data.download.title || video?.title || "Pixel Music";
            const fileName = `${title.replace(/[\\/:*?"<>|]/g, "")}.mp3`;
            const audioResponse = await axios.get(data.download.downloadUrl, {
              responseType: "arraybuffer",
              timeout: 120000,
              maxContentLength: 50 * 1024 * 1024,
              maxBodyLength: 50 * 1024 * 1024,
            });
            const audioBuffer = Buffer.from(audioResponse.data);
            await EliteProTech.sendMessage(
              m.chat,
              {
                audio: audioBuffer,
                mimetype: "audio/mpeg",
                fileName,
                ptt: false,
              },
              { quoted: m },
            );
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (error) {
            console.error("Play command error:", error);
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "⚠️", key: m.key },
            });
            return reply("_*An error occurred while downloading the song.*_");
          }
        }
        break;
      case "video":
      case "ytmp4": {
        if (!text)
          return reply(`*Example:* ${prefix + command} Faded by Alan Walker`);

        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: `📽️`, key: m.key },
          });

          const ytRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\//i;

          let video;
          let videoUrl;
          let videoTitle = "";
          let videoThumb = "";

          if (ytRegex.test(text)) {
            videoUrl = text;
            videoTitle = "Requested YouTube Video";

            const match = videoUrl.match(/(?:v=|\/)([0-9A-Za-z_-]{11})/);
            if (match) {
              videoThumb = `https://i.ytimg.com/vi/${match[1]}/hqdefault.jpg`;
            }
          } else {
            const search = await yts(text);
            video = search.videos[0];

            if (!video) return reply(`❌ No results found for: ${text}`);

            videoUrl = video.url;
            videoTitle = video.title;
            videoThumb = video.thumbnail;

            const info =
              `╭━━━━━━━━━\n` +
              `┃ *PIXEL VIDEO - DOWNLOADER*\n\n` +
              `> *ᴛɪᴛʟᴇ:* ${video.title}\n\n` +
              `┃ *ᴠɪᴇᴡꜱ:* ${video.views}\n` +
              `┃ *ᴅᴜʀᴀᴛɪᴏɴ:* ${video.timestamp}\n` +
              `┃ *ᴜᴘʟᴏᴀᴅᴇᴅ:* ${video.ago}\n\n` +
              `> *ᴜʀʟ:* ${video.url}\n\n` +
              `┃ *Enjoy your video®*\n` +
              `╰━━━━━━━━━━━━━━━━━━┈⊷\n` +
              `> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: video.thumbnail },
                caption: info,
              },
              { quoted: m },
            );
          }

          const apiUrl = `https://api.neosoft.best/api/downloader/youtube?url=${encodeURIComponent(videoUrl)}&type=mp4`;

          const { data } = await axios.get(apiUrl);

          if (!data?.status || !data?.download) {
            return reply(
              "❌ No download link.",
            );
          }

          await EliteProTech.sendMessage(
            m.chat,
            {
              video: { url: data.download },
              mimetype: "video/mp4",
              caption: `🎬 *${data.title || videoTitle || "YouTube Video"}*\n> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ`,
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: `✅`, key: m.key },
          });
        } catch (error) {
          console.error(error);

          await EliteProTech.sendMessage(m.chat, {
            react: { text: `❌`, key: m.key },
          });

          reply("❌ Error. Try again.");
        }
        break;
      }
      case "anime": {
        if (!text) return reply(`*Example*: ${prefix + command} Anime`);

        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: `🎨`, key: m.key },
          });

          const apiUrlForImages = `https://img.hazex.workers.dev/?prompt=${encodeURIComponent(text)}`;

          // Generate and send 5 images
          const footer = "\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*";
          for (let i = 0; i < 5; i++) {
            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: apiUrlForImages }, // URL is already constructed
                caption: footer,
              },
              { quoted: m },
            );
          }
        } catch (error) {
          console.error("Error fetching images:", error);
          reply(
            `*An error occurred while fetching images.*`,
          );
        }
        break;
      }
      case "gpt":
      case "keithai":
      case "supremeai":
      case "ai":
      case "chatgpt": {
        try {
          let quotedText = "";
          if (m.quoted) {
            quotedText =
              m.quoted.text ||
              m.quoted.caption ||
              m.quoted.message?.conversation ||
              m.quoted.message?.extendedTextMessage?.text ||
              "";
          }
          let userMessage = text?.trim();
          if (!userMessage && quotedText) {
            userMessage = quotedText;
          } else if (userMessage && quotedText) {
            userMessage = `${userMessage}\n\nContext:\n${quotedText}`;
          }
          if (!userMessage) {
            return reply(
              `Hi ${pushname || "there"} 👋\nReply to a message or type a question.`,
            );
          }
          const sender = m.sender;
          const msg = await EliteProTech.sendMessage(
            m.chat,
            {
              text: `✦ Generating response @${sender.split("@")[0]}...`,
              mentions: [sender],
            },
            { quoted: m },
          );
          const apiUrl = `https://eliteprotech-apis.zone.id/ai/notegpt?prompt=${encodeURIComponent(userMessage)}`;
          const { data } = await axios.get(apiUrl, {
            timeout: 60000,
          });
          if (!data?.success || !data?.text) {
            return await EliteProTech.sendMessage(m.chat, {
              text: "❌ AI failed to generate a response.",
              edit: msg.key,
            });
          }
          const finalText = data.text;
          await EliteProTech.sendMessage(m.chat, {
            text: finalText,
            edit: msg.key,
          });
        } catch (err) {
          console.error("GPT Error:", err);
          reply("❌ AI failed to respond.");
        }
        break;
      }
      case "lyric":
      case "lirik":
      case "lyrics":
        {
          if (!q)
            return reply(
              "Send a song name. Usage: .lyrics <song name>",
            );

          try {
            const url = `https://eliteprotech-apis.zone.id/search/lyrics?query=${encodeURIComponent(q)}`;
            const { data } = await axios.get(url);

            if (!data.success || !data.result || data.result.length === 0) {
              return reply("No lyrics found for that song.");
            }

            const song = data.result[0];
            const caption = `🎵 *${song.trackName || song.name}*\n👤 Artist: ${song.artistName}\n💿 Album: ${song.albumName}\n\n📜 *Lyrics:*\n${song.plainLyrics}`;
            await EliteProTech.sendMessage(from, {
              text: caption,
            });
          } catch (err) {
            console.error("Lyrics command error:", err);
            reply("❌ Error fetching lyrics.");
          }
        }
        break;
      case "truth": {
        try {
          const apiUrl = "https://apis.davidcyriltech.my.id/truth";
          const imagePath =
            "https://i.ibb.co/gLNc5SGK/ce5871f200bb421678c982f5af52d7fd.jpg"; //
          const userTag = `@${m.sender.split("@")[0]}`;

          const response = await axios.get(apiUrl);

          if (response.data.status === 200 && response.data.success) {
            const truthQuestion = response.data.question;

            EliteProTech.sendMessage(
              from,
              {
                image: { url: imagePath },
                caption: `${userTag}, you chose *TRUTH*!\n\n*Question:* ${truthQuestion}\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
                mentions: [m.sender],
              },
              { quoted: m },
            );
          } else {
            reply("Failed to fetch a truth question.");
          }
        } catch (error) {
          if (error.response) {
            reply(
              `API Error: ${error.response.data.message || "Unknown API error."}`,
            );
          } else if (error.request) {
            reply("No response received from the API.");
          } else {
            reply(`An error occurred: ${error.message}`);
          }
        }
        break;
      }
      case "yts":
      case "youtubesearch":
      case "ytsearch": {
        if (!text)
          return reply(`❌ Example: ${prefix + command} Alan Walker Alone`);
        await EliteProTech.sendMessage(m.chat, {
          react: { text: "⏳", key: m.key },
        });
        try {
          const search = await yts(text);
          if (!search.videos || !search.videos.length) {
            return reply("❌ No results found.");
          }
          const results = search.videos.slice(0, 10);
          let caption = `*YouTube Search*\n\n`;
          caption += `◆ Query: ${text}\n`;
          caption += `◆ Results: ${results.length}\n\n`;
          for (const vid of results) {
            caption += `◆ Title: ${vid.title}
◇ Author: ${vid.author?.name || "Unknown"}
◇ Duration: ${vid.timestamp}
◇ Views: ${Number(vid.views || 0).toLocaleString()}
◇ URL: ${vid.url}

`;
          }
          await EliteProTech.sendMessage(
            m.chat,
            {
              image: {
                url: results[0].thumbnail,
              },
              caption,
            },
            {
              quoted: m,
            },
          );
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (err) {
          console.error("YTS Error:", err);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply(`❌ Error fetching results:\n${err.message}`);
        }
        break;
      }
      case "tiny":
      case "shorturl": {
        try {
          if (!text) {
            return reply(
              `Send a URL to shorten.\n*Usage:*\n.tiny https://example.com`,
            );
          }

          const urlToShorten = text.trim();

          if (!urlToShorten) {
            return reply("Send a valid URL to shorten.");
          }

          // Construct the API URL for TinyURL
          const apiUrl = `https://tinyurl.com/api-create.php?url=${encodeURIComponent(urlToShorten)}`;

          // Fetch the shortened URL
          const response = await axios.get(apiUrl);

          console.log("API Response:", response.data);

          // Send the shortened URL as a message
          await EliteProTech.sendMessage(
            from,
            {
              text: `Here is your shortened URL: ${response.data}`,
            },
            { quoted: m },
          );
        } catch (error) {
          console.error("Error shortening URL:", error.message);
          await EliteProTech.sendMessage(
            from,
            {
              text: "Error shortening URL.",
            },
            { quoted: m },
          );
        }
        break;
      }
      case "g":
      case "gsearch":
      case "google": {
        try {
          if (!text) {
            return reply("Provide a search term!\nEg: .Google What is treason");
          }

          const axios = require("axios");
          const { data } = await axios.get(
            `https://www.googleapis.com/customsearch/v1?q=${text}&key=AIzaSyDMbI3nvmQUrfjoCJYLS69Lej1hSXQjnWI&cx=baf9bdb0c631236e5`,
          );

          if (data.items.length === 0) {
            return reply("❌ Unable to find a result");
          }

          let tex = `*GOOGLE SEARCH*\n🔍 *Term:* ${text}\n\n`;
          for (let i = 0; i < data.items.length; i++) {
            tex += `🪧 *Title:* ${data.items[i].title}\n🖥 *Description:* ${data.items[i].snippet}\n🌐 *Link:* ${data.items[i].link}\n\n`;
          }

          await EliteProTech.sendMessage(
            from,
            {
              text: tex.trim(),
            },
            { quoted: m },
          );
        } catch (error) {
          console.error("Error occurred:", error);
          await EliteProTech.sendMessage(
            from,
            {
              text: "❌ Something went wrong with the Google search.",
            },
            { quoted: m },
          );
        }
        break;
      }
      case "gitclone":
        {
          if (!args[0])
            return reply(
              `*Usage:* ${prefix}${command} https://github.com/EliteProTech/ELITE-PRO-V1`,
            );
          if (!isUrl(args[0]) || !args[0].includes("github.com"))
            return reply(`Invalid GitHub link.`);

          try {
            const regex = /github\.com\/([^\/]+)\/([^\/]+)(?:\.git)?/i;
            const match = args[0].match(regex);

            if (!match)
              return reply(
                `❌ Failed to extract user/repo. Make sure the link is correct.`,
              );

            const user = match[1];
            const repo = match[2].replace(/(\.git|\/)$/i, "");

            const zipUrl = `https://api.github.com/repos/${user}/${repo}/zipball`;

            // Fallback filename in case HEAD fails
            const filename = `${repo}.zip`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                document: { url: zipUrl },
                fileName: filename,
                mimetype: "application/zip",
              },
              { quoted: m },
            );
          } catch (err) {
            console.error(err);
            reply(`❌ Error cloning repo.\n${err.message || err}`);
          }
        }
        break;
      case "welcomeon":
      case "welcomeoff":
      case "welcome":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply(mess.admin);

          let data = {};
          const welcomeDBPath = "./database/welcome.json";
          try {
            data = JSON.parse(fs.readFileSync(welcomeDBPath, "utf-8"));
          } catch {}

          const chatId = m.chat;

          if (!args[0]) {
            return reply(`*ꕤ Group Welcome Settings*

*This group:* ${data[chatId]?.enabled ? "✅ Enabled" : "❌ Disabled"}
*All groups:* ${Object.keys(data).filter((k) => data[k]?.enabled).length} enabled

*✎ Use the command below:*
*${prefix}welcome here* → enable for this group
*${prefix}welcome all* → enable for all groups
*${prefix}welcome disable here* → disable for this group
*${prefix}welcome disable all* → disable for all groups`);
          }

          const option = args[0].toLowerCase();

          switch (option) {
            case "here":
              data[chatId] = { enabled: true };
              reply(`✅ Welcome messages enabled for this group`);
              break;

            case "tag-all":
            case "alltag":
            case "all":
              for (let key of Object.keys(data)) data[key].enabled = true;
              if (!data[chatId]) data[chatId] = { enabled: true };
              reply(`✅ Welcome messages enabled for all groups`);
              break;

            case "disable":
              if (args[1]?.toLowerCase() === "here") {
                if (!data[chatId]) data[chatId] = { enabled: false };
                else data[chatId].enabled = false;
                reply(`❌ Welcome messages disabled for this group`);
              } else if (args[1]?.toLowerCase() === "all") {
                for (let key of Object.keys(data)) data[key].enabled = false;
                reply(`❌ Welcome messages disabled for all groups`);
              } else {
                reply("❌ Use: disable here / disable all");
              }
              break;

            default:
              reply(
                "❌ Use: here / all / disable here / disable all",
              );
              break;
          }

          fs.writeFileSync(welcomeDBPath, JSON.stringify(data, null, 2));

          // Mirror into groups.json — the live group-participants listener reads THAT file.
          try {
            const gAll = readGroups();
            const setW = (cid, on) => {
              if (!gAll[cid]) gAll[cid] = {};
              if (!gAll[cid].welcome) gAll[cid].welcome = { on: false, text: "" };
              gAll[cid].welcome.on = !!on;
              if (on && !gAll[cid].welcome.text)
                gAll[cid].welcome.text = "👋 Welcome @{name} to {group}!";
            };
            const sub = String(args[1] || "").toLowerCase();
            if (["here", "on", "enable"].includes(option)) {
              setW(chatId, true);
            } else if (["all", "tag-all", "alltag"].includes(option)) {
              setW(chatId, true);
              for (const k of Object.keys(gAll)) setW(k, true);
            } else if (option === "off" || option === "disable") {
              if (sub === "all") for (const k of Object.keys(gAll)) setW(k, false);
              else setW(chatId, false);
            }
            writeGroups(gAll);
          } catch (e) {
            console.log("[welcome-sync] " + e.message);
          }
        }
        break;
      case "insultme":
      case "burn":
      case "insult": {
        try {
          const res = await fetch(
            "https://eliteprotech-apis.zone.id/fun/insult",
          );

          if (!res.ok) {
            throw new Error(`API request failed with status ${res.status}`);
          }

          const json = await res.json();

          if (!json.success) {
            return reply("❌ Failed to get an insult.");
          }

          const insult = json.insult;
          await reply(insult);
        } catch (error) {
          console.error(error);
          reply("❌ Failed to fetch an insult. Try again later.");
        }
        break;
      }
      case "rizz":
      case "pickupline": {
        try {
          const res = await fetch("https://api.popcat.xyz/pickuplines");

          if (!res.ok) {
            throw new Error(`API request failed with status ${res.status}`);
          }

          const json = await res.json();
          const pickupLine = `*Here's a pickup line for you:*\n\n${json.pickupline}`;

          await reply(pickupLine);
        } catch (error) {
          console.error(error);
          reply("❌ Failed to fetch a pickup line. Try again later.");
        }
        break;
      }
      case "loli":
        {
          let baseUrl = "https://weeb-api.vercel.app/";
          const response = await fetch(baseUrl + command);
          const imageBuffer = await response.buffer(); // Get the image data as a buffer
          EliteProTech.sendMessage(
            m.chat,
            { image: imageBuffer, caption: `Random ${command} for you!✨` },
            { quoted: m },
          );
        }
        break;
      case "randomwaifu":
      case "waifu":
        {
          let baseUrl = "https://weeb-api.vercel.app/";
          const response = await fetch(baseUrl + command);
          const imageBuffer = await response.buffer(); // Get the image data as a buffer
          EliteProTech.sendMessage(
            m.chat,
            { image: imageBuffer, caption: `Random ${command} for you!✨` },
            { quoted: m },
          );
        }
        break;
      case "neko":
        {
          let baseUrl = "https://weeb-api.vercel.app/";
          const response = await fetch(baseUrl + command);
          const imageBuffer = await response.buffer(); // Get the image data as a buffer
          EliteProTech.sendMessage(
            m.chat,
            { image: imageBuffer, caption: `Random ${command} for you!✨` },
            { quoted: m },
          );
        }
        break;
      case "ss":
      case "webss":
      case "ssweb":
      case "screenshot":
        {
          if (!text)
            return reply(
              `📸 Send a link!\n\n*Example:* ${prefix + command} https://example.com`,
            );

          let url = text.trim();

          if (!/^https?:\/\//i.test(url)) {
            url = "https://" + url;
          }

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "🖼️", key: m.key },
          });

          try {
            const apiUrl = `https://eliteprotech-apis.zone.id/tools/ssweb?url=${encodeURIComponent(url)}`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: apiUrl },
                caption: `*Screenshot captured successfully.*\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ*`,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (error) {
            console.log("SSWeb error:", error.message);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            reply(
              "❌ Screenshot failed.\nPlease try again later.",
            );
          }
        }
        break;
      case "vv":
      case "vv2":
      case "rvo":
      case "readvo":
      case "readviewonce":
      case "viewonce":
        {
          if (!m.quoted)
            return reply(`Reply to a *view-once* image, video, or audio.`);

          try {
            // Extract actual view-once message
            let quotedMsg = m.quoted;

            // Access the underlying message if it's a view-once
            if (quotedMsg.message?.viewOnceMessageV2Extension) {
              quotedMsg.message = quotedMsg.message.viewOnceMessageV2Extension.message;
            } else if (quotedMsg.message?.viewOnceMessageV2) {
              quotedMsg.message = quotedMsg.message.viewOnceMessageV2.message;
            } else if (quotedMsg.message?.viewOnceMessage) {
              quotedMsg.message = quotedMsg.message.viewOnceMessage.message;
            }

            const mime = quotedMsg?.mimetype || quotedMsg?.msg?.mimetype || "";
            const media = await quotedMsg.download();
            const caption = quotedMsg.text || quotedMsg.caption || "";

            if (/image/.test(mime)) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  image: media,
                  caption: `${caption}`,
                },
                { quoted: m },
              );
            } else if (/video/.test(mime)) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  video: media,
                  caption: `${caption}`,
                },
                { quoted: m },
              );
            } else if (/audio/.test(mime)) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  audio: media,
                  mimetype: "audio/mp4",
                },
                { quoted: m },
              );
            } else {
              return reply(
                `Please reply to a valid *view-once* image, video, or audio.`,
              );
            }
          } catch (error) {
            console.error("Error opening view-once message:", error);
            return reply("❌ Failed to process view-once media.");
          }
        }
        break;
      case "vvdm":
        {
          if (!m.quoted)
            return reply(
              `⚠️ Please reply to a *view-once* image, video, or audio.`,
            );

          try {
            const ownerNumber =
              EliteProTech.user.id.split(":")[0] + "@s.whatsapp.net";

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "👄", key: m.key },
            });

            let quotedMsg = m.quoted;

            if (quotedMsg.message?.viewOnceMessageV2) {
              quotedMsg.message = quotedMsg.message.viewOnceMessageV2.message;
            } else if (quotedMsg.message?.viewOnceMessage) {
              quotedMsg.message = quotedMsg.message.viewOnceMessage.message;
            }

            const mime = quotedMsg?.mimetype || quotedMsg?.msg?.mimetype || "";
            const media = await quotedMsg.download();
            const caption = quotedMsg.text || quotedMsg.caption || "";

            // Send media directly to OWNER’s DM instead of user
            if (/image/.test(mime)) {
              await EliteProTech.sendMessage(
                ownerNumber,
                {
                  image: media,
                  caption: `${caption}`,
                },
                { quoted: m },
              );
            } else if (/video/.test(mime)) {
              await EliteProTech.sendMessage(
                ownerNumber,
                {
                  video: media,
                  caption: `${caption}`,
                },
                { quoted: m },
              );
            } else if (/audio/.test(mime)) {
              await EliteProTech.sendMessage(
                ownerNumber,
                {
                  audio: media,
                  mimetype: "audio/mp4",
                  ptt: false,
                  caption: `${caption}`,
                },
                { quoted: m },
              );
            } else {
              return reply(
                `⚠️ Please reply to a valid *view-once* image, video, or audio.`,
              );
            }

            // React ✅ after success
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (error) {
            console.error("Error opening view-once message:", error);
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
          }
        }
        break;
      case "song": {
        if (!text)
          return reply(
            `*Example*: ${prefix + command} Faded by Alan Walker or YouTube URL`,
          );
        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: `🎶`, key: m.key },
          });
          let videoUrl;
          let videoTitle;
          let video;
          const urlRegex =
            /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/;
          if (urlRegex.test(text)) {
            const search = await yts(text);
            video = search.videos[0];
            if (!video)
              return reply(`❌ Could not retrieve video info from URL.`);
            videoUrl = text;
          } else {
            const search = await yts(text);
            video = search.videos[0];
            if (!video) return reply(`❌ No results found for: ${text}`);
            videoUrl = video.url;
          }
          videoTitle = video.title;
          const apiUrl = `https://eliteprotech-apis.zone.id/download/ytmp3?url=${encodeURIComponent(videoUrl)}`;
          const { data } = await axios.get(apiUrl);
          if (data?.status && data?.download?.downloadUrl) {
            const downloadUrl = data.download.downloadUrl;
            const filename = `${data.download.title || videoTitle}.mp3`;
            const response = await axios.get(downloadUrl, {
              responseType: "arraybuffer",
              headers: {
                "User-Agent": "Mozilla/5.0",
                Accept: "audio/mpeg,*/*",
              },
            });
            const audioBuffer = Buffer.from(response.data);
            await EliteProTech.sendMessage(
              m.chat,
              {
                document: audioBuffer,
                fileName: filename,
                mimetype: "audio/mpeg",
                caption: `*🎶 Here you go*`,
                contextInfo: {
                  forwardingScore: 999,
                  isForwarded: true,
                },
              },
              { quoted: m },
            );
            await EliteProTech.sendMessage(m.chat, {
              react: { text: `✅`, key: m.key },
            });
          } else {
            reply(`❌ Failed to fetch the song from API.`);
          }
        } catch (error) {
          console.error("Song Downloader Error:", error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: `❌`, key: m.key },
          });
          reply(`❌ An error occurred while downloading.`);
        }
        break;
      }
      case "animeavatar":
        {
          waifudd = await axios.get(`https://nekos.life/api/v2/img/avatar`);
          await EliteProTech.sendMessage(
            m.chat,
            { image: { url: waifudd.data.url }, caption: mess.success },
            { quoted: m },
          ).catch((err) => {
            return "Error!";
          });
        }
        break;
      case "8ballpool":
        {
          waifudd = await axios.get(`https://nekos.life/api/v2/img/8ball`);
          await EliteProTech.sendMessage(
            m.chat,
            { image: { url: waifudd.data.url }, caption: mess.success },
            { quoted: m },
          ).catch((err) => {
            return "Error!";
          });
        }
        break;
      case "stickkill":
        {
          axios.get(`https://api.waifu.pics/sfw/kill`).then(({ data }) => {
            EliteProTech.sendImageAsSticker(from, data.url, m, {
              packname: global.packname,
              author: global.author,
            });
          });
        }
        break;
      case "animeblush":
        {
          waifudd = await axios.get(`https://waifu.pics/api/sfw/blush`);
          await EliteProTech.sendMessage(
            m.chat,
            { image: { url: waifudd.data.url }, caption: mess.success },
            { quoted: m },
          ).catch((err) => {
            return "Error!";
          });
        }
        break;
      case "animewave":
        {
          waifudd = await axios.get(`https://waifu.pics/api/sfw/wave`);
          await EliteProTech.sendMessage(
            m.chat,
            { image: { url: waifudd.data.url }, caption: mess.success },
            { quoted: m },
          ).catch((err) => {
            return "Error!";
          });
        }
        break;
      case "animesmile":
        {
          waifudd = await axios.get(`https://waifu.pics/api/sfw/smile`);
          await EliteProTech.sendMessage(
            m.chat,
            { image: { url: waifudd.data.url }, caption: mess.success },
            { quoted: m },
          ).catch((err) => {
            return "Error!";
          });
        }
        break;
      case "animepoke":
        {
          waifudd = await axios.get(`https://waifu.pics/api/sfw/poke`);
          await EliteProTech.sendMessage(
            m.chat,
            { image: { url: waifudd.data.url }, caption: mess.success },
            { quoted: m },
          ).catch((err) => {
            return "Error!";
          });
        }
        break;
      case "animewink":
        {
          waifudd = await axios.get(`https://waifu.pics/api/sfw/wink`);
          await EliteProTech.sendMessage(
            m.chat,
            { image: { url: waifudd.data.url }, caption: mess.success },
            { quoted: m },
          ).catch((err) => {
            return "Error!";
          });
        }
        break;
      case "animebonk":
        {
          waifudd = await axios.get(`https://waifu.pics/api/sfw/bonk`);
          await EliteProTech.sendMessage(
            m.chat,
            { image: { url: waifudd.data.url }, caption: mess.success },
            { quoted: m },
          ).catch((err) => {
            return "Error!";
          });
        }
        break;
      case "animebully":
        {
          waifudd = await axios.get(`https://waifu.pics/api/sfw/bully`);
          await EliteProTech.sendMessage(
            m.chat,
            { image: { url: waifudd.data.url }, caption: mess.success },
            { quoted: m },
          ).catch((err) => {
            return "Error!";
          });
        }
        break;
      case "verse":
      case "scripture":
      case "bibleverse":
      case "bible":
        {
          try {
            if (!text) {
              return reply(
                `Please specify the chapter number or name. Example: ${prefix + command} john 3:16`,
              );
            }

            const query = encodeURIComponent(text);
            const url = `https://eliteprotech-apis.zone.id/search/bible?q=${query}`;

            const { data } = await axios.get(url);

            if (!data || !data.success) {
              return reply("❌ Verse not found. Check your reference.");
            }

            let message = `📖 *${data.title}*\n\n`;
            message += `*Reference:* ${data.reference}\n`;
            message += `*Version:* ${data.version}\n\n`;
            message += `${data.text.trim()}`;

            reply(message);
          } catch (err) {
            console.error("Bible Error:", err);
            reply("❌ Failed to fetch Bible verse.");
          }
        }
        break;
      case "tr":
      case "trans":
      case "translate":
      case "trt":
        {
          if (!q)
            return reply(
              `*Where is the text*\n\n*𝙴xample usage*\n*${prefix + command} language id text*\n*${prefix + command} Hello dear how are you?*`,
            );
          const defaultLang = "en";
          const tld = "cn";
          let err = `
 *Example:*

*${prefix + command}* id text
*${prefix + command}* en Hello World

≡ *List of supported languages:* 
https://cloud.google.com/translate/docs/languages
`.trim();
          let lang = args[0];
          let text = args.slice(1).join(" ");
          if ((args[0] || "").length !== 2) {
            lang = defaultLang;
            text = args.join(" ");
          }
          if (!text && m.quoted && m.quoted.text) text = m.quoted.text;
          try {
            let result = await translate(text, {
              to: lang,
              autoCorrect: true,
            }).catch((_) => null);
            reply(result.text);
          } catch (e) {
            return reply(err);
          }
        }
        break;
      case "quran":
        {
          if (!text)
            return reply(
              `🕌 Please enter surah number or name.\n\nExample: ${prefix + command} 1`,
            );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "🕌", key: m.key },
          });

          try {
            const surahInput = text.trim().toLowerCase();

            const surahListRes = await fetch(
              "https://quran-endpoint.vercel.app/quran",
            );
            const surahList = await surahListRes.json();

            const surahData = surahList.data.find(
              (surah) =>
                surah.number === Number(surahInput) ||
                surah.asma?.ar?.short?.toLowerCase() === surahInput ||
                surah.asma?.en?.short?.toLowerCase() === surahInput ||
                surah.asma?.en?.long?.toLowerCase() === surahInput,
            );

            if (!surahData) return reply(`❌ Couldn't find surah: ${text}`);

            const res = await fetch(
              `https://quran-endpoint.vercel.app/quran/${surahData.number}`,
            );
            const json = await res.json();

            if (!res.ok || !json?.data) {
              return reply("❌ Failed to fetch surah details.");
            }

            const tafsir = json.data.tafsir?.id || "No tafsir available.";

            let translatedTafsirEnglish = { text: tafsir };
            try {
              translatedTafsirEnglish = await translate(tafsir, {
                to: "en",
                autoCorrect: true,
              });
            } catch {}

            const quranSurah = `🕌 *Quran Surah Info*

📜 *Surah ${json.data.number}: ${json.data.asma.ar.long} (${json.data.asma.en.long})*
📌 *Type:* ${json.data.type.en}
🔢 *Verses:* ${json.data.ayahCount}

📖 *Explanation:*
${translatedTafsirEnglish.text}`;

            await reply(quranSurah);

            if (json.data.recitation?.full) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  audio: { url: json.data.recitation.full },
                  mimetype: "audio/mpeg",
                  ptt: false,
                  fileName: `Surah-${json.data.number}.mp3`,
                },
                { quoted: m },
              );
            }

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (error) {
            console.log("Quran error:", error.message);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            reply("❌ Error fetching Quran surah.");
          }
        }
        break;
      case "tagadmin":
        {
          if (!m.isGroup) return reply("This command is for group use only.");
          const groupAdmins = participants.filter((p) => p.admin);
          const listAdmin = groupAdmins
            .map((v, i) => `${i + 1}. @${v.id.split("@")[0]}`)
            .join("\n");
          const owner =
            groupMetadata.owner ||
            groupAdmins.find((p) => p.admin === "superadmin")?.id ||
            m.chat.split`-`[0] + "@s.whatsapp.net";
          let text = `   
*Group Admins:*
${listAdmin}
`.trim();
          EliteProTech.sendMessage(
            m.chat,
            { text: text, mentions: [...groupAdmins.map((v) => v.id), owner] },
            { quoted: m },
          );
        }
        break;
      case "statusd":
      case "save":
        {
          try {
            if (!m.quoted)
              return reply(
                `⚠️ Reply to a WhatsApp status (image, video, audio, or text) you want to save.`,
              );

            let mime = (m.quoted.msg || m.quoted).mimetype || "";
            let caption = m.quoted.text || m.quoted.caption || "";

            // React ⏳ (processing started)
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "💱", key: m.key },
            });

            if (mime) {
              // Handle media statuses
              let media = await m.quoted.download();

              if (/image/.test(mime)) {
                await EliteProTech.sendMessage(
                  m.sender,
                  {
                    image: media,
                    caption: `${caption}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
                  },
                  { quoted: m },
                );
              } else if (/video/.test(mime)) {
                await EliteProTech.sendMessage(
                  m.sender,
                  {
                    video: media,
                    caption: `${caption}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
                  },
                  { quoted: m },
                );
              } else if (/audio/.test(mime)) {
                await EliteProTech.sendMessage(
                  m.sender,
                  {
                    audio: media,
                    mimetype: "audio/mp4",
                    ptt: false,
                    caption: `${caption}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
                  },
                  { quoted: m },
                );
              } else {
                return reply(`⚠️ Unsupported status type.`);
              }
            } else if (caption) {
              // Handle text-only status
              await EliteProTech.sendMessage(
                m.sender,
                {
                  text: `${caption}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
                },
                { quoted: m },
              );
            } else {
              return reply(`⚠️ This status has no media or text.`);
            }

            // React ✅ (success)
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (error) {
            console.error("Error processing status:", error);

            // React ❌ (failure)
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
          }
        }
        break;
      case "speak":
      case "say":
      case "tts":
        {
          if (!text) return reply("Provide text: Hello world");

          try {
            const axios = require("axios");
            const googleTTS = require("google-tts-api");
            const { toPTT } = require("./lib/converter");

            const url = googleTTS.getAudioUrl(text, {
              lang: "en",
              slow: false,
              host: "https://translate.google.com",
            });

            const res = await axios.get(url, {
              responseType: "arraybuffer",
            });

            const voice = await toPTT(Buffer.from(res.data), "mp3");

            await EliteProTech.sendMessage(
              m.chat,
              {
                audio: voice,
                mimetype: "audio/ogg; codecs=opus",
                ptt: true,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error(err);
            reply("TTS failed.");
          }
        }
        break;
      case "spotifysearch":
      case "sps":
        {
          if (!text)
            return reply(
              "❌ Send a song name.",
            );

          try {
            const res = await axios.get(
              `https://kazztzyy.my.id/api/search/spotify?q=${encodeURIComponent(text)}`,
            );

            if (!res.data.status) return reply("❌ Failed to fetch results.");

            let results = res.data.result;
            if (!results.length) return reply("❌ No results found.");

            let teks = `🎵 *SPOTIFY SEARCH*\n\n🔎 Query: ${text}\n\n`;

            results.slice(0, 10).forEach((item, i) => {
              teks += `*${i + 1}.* ${item.title}\n`;
              teks += `   👤 Artist: ${item.artist}\n`;
              teks += `   💿 Album: ${item.album}\n`;
              teks += `   ⏱ Duration: ${item.duration}\n`;
              teks += `   ⭐ Popularity: ${item.popularity}\n`;
              teks += `   📅 Release: ${item.releaseDate}\n`;
              teks += `   🔗 Link: ${item.trackUrl}\n\n`;
            });

            // send with thumbnail of first result
            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: results[0].imageUrl },
                caption: teks,
              },
              { quoted: m },
            );
          } catch (e) {
            console.log(e);
            reply("❌ Error fetching Spotify results.");
          }
        }
        break;
      case "spdl":
      case "spplay":
      case "spotify":
      case "splay":
        {
          try {
            if (!text) {
              return reply(
                `⚠️ Example:\n${prefix + command} alan walker alone\n${prefix + command} https://open.spotify.com/track/...`,
              );
            }

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🎧", key: m.key },
            });

            let spotifyUrl = text;

            if (!text.includes("open.spotify.com")) {
              const searchApi = `https://kazztzyy.my.id/api/search/spotify?q=${encodeURIComponent(text)}`;
              const searchRes = await axios.get(searchApi);

              if (
                !searchRes.data ||
                !searchRes.data.status ||
                !searchRes.data.result.length
              ) {
                return reply("❌ Song not found.");
              }

              const first = searchRes.data.result[0];
              spotifyUrl = first.trackUrl;
            }

            const apiUrl = `https://eliteprotech-apis.zone.id/download/spotify?url=${encodeURIComponent(spotifyUrl)}`;
            const { data } = await axios.get(apiUrl);

            if (!data || !data.success) {
              return reply("❌ Failed to fetch Spotify track.");
            }

            const meta = data.data.metadata;
            const downloadUrl = data.data.download;

            await EliteProTech.sendMessage(
              m.chat,
              {
                audio: { url: downloadUrl },
                mimetype: "audio/mpeg",
                fileName: `${meta.title}.mp3`,
                ptt: false,
                contextInfo: {
                  externalAdReply: {
                    title: meta.title,
                    body: `${meta.artist} : ${meta.duration}`,
                    thumbnailUrl: meta.images,
                    mediaType: 1,
                    renderLargerThumbnail: false,
                  },
                },
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.error("Spotify Error:", err);
            reply("❌ Error downloading Spotify track.");
          }
        }
        break;
      case "ar":
      case "autoreact":
      case "auto_react":
        {
          if (!isCreator) return reply(mess.owner);
          if (args.length < 1) return reply("on/off?");
          if (args[0] === "on") {
            global.autoreact = true;
            saveSettings();
            reply(`✅ ${command} is enabled`);
          } else if (args[0] === "off") {
            global.autoreact = false;
            saveSettings();
            reply(`🌀 ${command} is disabled`);
          } else {
            return reply(`ℹ️ ${prefix + command} on|off`);
          }
        }
        break;
      case "chatbot":
        {
          if (!isCreator) return reply(mess.owner);
          const file = "./database/chatbot.json";
          let chatbotData = {
            global: false,
            dm: false,
            group: false,
            chats: {},
          };
          try {
            chatbotData = JSON.parse(fs.readFileSync(file, "utf8"));
          } catch {}
          chatbotData.chats = chatbotData.chats || {};
          const type = (args[0] || "").toLowerCase();
          const action = (args[1] || "").toLowerCase();
          const chatId = m.chat;
          if (!type || type === "help") {
            return reply(`🤖 *CHATBOT SETTINGS*

*${prefix}chatbot dm on*
Enable chatbot for all DMs

*${prefix}chatbot dm off*
Disable chatbot for all DMs

*${prefix}chatbot group on*
Enable chatbot for all groups

*${prefix}chatbot group off*
Disable chatbot for all groups

*${prefix}chatbot chat on*
Enable chatbot for this chat only

*${prefix}chatbot chat off*
Disable chatbot for this chat only

*${prefix}chatbot all on*
Enable chatbot everywhere

*${prefix}chatbot all off*
Disable chatbot everywhere

*${prefix}chatbot status*
Show chatbot status`);
          }
          if (type === "status") {
            return reply(`🤖 *CHATBOT STATUS*

🌍 All: ${chatbotData.global ? "✅ ON" : "❌ OFF"}
💬 DMs: ${chatbotData.dm ? "✅ ON" : "❌ OFF"}
👥 Groups: ${chatbotData.group ? "✅ ON" : "❌ OFF"}
📌 Current chat: ${chatbotData.chats[chatId] ? "✅ ON" : "❌ OFF"}`);
          }
          if (type === "dm") {
            if (action === "on") {
              chatbotData.dm = true;
              fs.writeFileSync(file, JSON.stringify(chatbotData, null, 2));
              return reply("✅ Chatbot enabled for all DMs");
            }
            if (action === "off") {
              chatbotData.dm = false;
              fs.writeFileSync(file, JSON.stringify(chatbotData, null, 2));
              return reply("❌ Chatbot disabled for all DMs");
            }
          }
          if (type === "group") {
            if (action === "on") {
              chatbotData.group = true;
              fs.writeFileSync(file, JSON.stringify(chatbotData, null, 2));
              return reply("✅ Chatbot enabled for all groups");
            }
            if (action === "off") {
              chatbotData.group = false;
              fs.writeFileSync(file, JSON.stringify(chatbotData, null, 2));
              return reply("❌ Chatbot disabled for all groups");
            }
          }
          if (type === "chat") {
            if (action === "on") {
              chatbotData.chats[chatId] = true;
              fs.writeFileSync(file, JSON.stringify(chatbotData, null, 2));
              return reply("✅ Chatbot enabled for this chat only");
            }
            if (action === "off") {
              delete chatbotData.chats[chatId];
              fs.writeFileSync(file, JSON.stringify(chatbotData, null, 2));
              return reply("❌ Chatbot disabled for this chat");
            }
          }
          if (type === "all") {
            if (action === "on") {
              chatbotData.global = true;
              fs.writeFileSync(file, JSON.stringify(chatbotData, null, 2));
              return reply("🌍 Chatbot enabled for all DMs and groups");
            }
            if (action === "off") {
              chatbotData.global = false;
              chatbotData.dm = false;
              chatbotData.group = false;
              chatbotData.chats = {};
              fs.writeFileSync(file, JSON.stringify(chatbotData, null, 2));
              return reply("⛔ Chatbot disabled everywhere");
            }
          }
          return reply(`❌ Bad option.

Use:
${prefix}chatbot dm on
${prefix}chatbot dm off
${prefix}chatbot group on
${prefix}chatbot group off
${prefix}chatbot chat on
${prefix}chatbot chat off
${prefix}chatbot all on
${prefix}chatbot all off
${prefix}chatbot status`);
        }
        break;
      case "al":
      case "nolink":
      case "antilink":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply(mess.admin);
          if (!isBotAdmins) return reply(mess.botAdmin);

          let antilinkData = {};
          try {
            antilinkData = JSON.parse(
              fs.readFileSync("./database/antilink.json"),
            );
          } catch (err) {
            console.error("Error loading antilink.json:", err);
          }

          if (!antilinkData[m.chat]) {
            antilinkData[m.chat] = {
              enabled: false,
              action: "warn",
              warnings: {},
            };
          }

          if (!args[0]) {
            return EliteProTech.sendMessage(
              m.chat,
              {
                image: elitepropic,
                caption: `⿻ *ANTILINK SETTINGS*

🔘 Status: *${antilinkData[m.chat].enabled ? "ON" : "OFF"}*
⚙️ Action: *${antilinkData[m.chat].action.toUpperCase()}*

╭───────────────━⊷
┃ .antilink on
┃ .antilink off
┃ .antilink action warn
┃ .antilink action delete
┃ .antilink action kick
╰───────────────━⊷`,
              },
              { quoted: m },
            );
          }

          if (args[0].toLowerCase() === "on") {
            antilinkData[m.chat].enabled = true;
            antilinkData[m.chat].warnings = {};

            fs.writeFileSync(
              "./database/antilink.json",
              JSON.stringify(antilinkData, null, 2),
            );

            return EliteProTech.sendMessage(
              m.chat,
              {
                image: elitepropic,
                caption: `✅ *ANTILINK ENABLED*

╭───────────────━⊷
┃ delete → Delete link only
┃ warn → 4 warnings then kick
┃ kick → Instant removal
╰───────────────━⊷

⚙️ Current Action: *${antilinkData[m.chat].action.toUpperCase()}*`,
              },
              { quoted: m },
            );
          }

          if (args[0].toLowerCase() === "off") {
            antilinkData[m.chat].enabled = false;
            antilinkData[m.chat].warnings = {};

            fs.writeFileSync(
              "./database/antilink.json",
              JSON.stringify(antilinkData, null, 2),
            );

            return EliteProTech.sendMessage(
              m.chat,
              {
                image: elitepropic,
                caption:
                  "🔄 *ANTILINK DISABLED!*\n\nLinks are now allowed in this group.",
              },
              { quoted: m },
            );
          }

          if (args[0].toLowerCase() === "action" && args[1]) {
            const action = args[1].toLowerCase();

            if (!["delete", "warn", "kick"].includes(action)) {
              return reply("❌ Invalid action. Use: delete, warn, or kick");
            }

            antilinkData[m.chat].action = action;

            fs.writeFileSync(
              "./database/antilink.json",
              JSON.stringify(antilinkData, null, 2),
            );

            return EliteProTech.sendMessage(
              m.chat,
              {
                image: elitepropic,
                caption: `⚙️ *ANTILINK ACTION UPDATED*

New Action: *${action.toUpperCase()}*`,
              },
              { quoted: m },
            );
          }

          return reply(`❌ Bad option.

Example:
.antilink on
.antilink off
.antilink action warn
.antilink action delete
.antilink action kick`);
        }
        break;
      case "autolikestatus":
        {
          if (!isCreator) return reply(mess.owner);
          const option = args[0]?.toLowerCase();
          if (!option)
            return reply(
              `Usage:\n${prefix}autolikestatus on [emoji]\n${prefix}autolikestatus off\n${prefix}autolikestatus default`,
            );
          if (option === "on") {
            global.autolikestatus = true;
            if (args.slice(1).join(" ").trim())
              global.autolikestatusEmoji = args.slice(1).join(" ").trim();
            saveSettings();
            return reply(
              `✅ Auto status like enabled with ${global.autolikestatusEmoji || "💚"}`,
            );
          }
          if (option === "off") {
            global.autolikestatus = false;
            saveSettings();
            return reply("❌ Auto status like disabled");
          }
          if (option === "default") {
            global.autolikestatusEmoji = "💚";
            saveSettings();
            return reply("✅ Auto status like emoji reset to 💚");
          }
          return reply(
            `Usage:\n${prefix}autolikestatus on [emoji]\n${prefix}autolikestatus off\n${prefix}autolikestatus default`,
          );
        }
        break;
      case "autoviewlike":
        {
          if (!isCreator) return reply(mess.owner);
          const option = args[0]?.toLowerCase();
          if (!option)
            return reply(
              `Usage:\n${prefix}autoviewlike on [emoji]\n${prefix}autoviewlike off`,
            );
          if (option === "on") {
            global.autoviewstatus = true;
            global.autolikestatus = true;
            if (args.slice(1).join(" ").trim())
              global.autolikestatusEmoji = args.slice(1).join(" ").trim();
            saveSettings();
            return reply(
              `✅ Auto view and like enabled with ${global.autolikestatusEmoji || "💚"}`,
            );
          }
          if (option === "off") {
            global.autoviewstatus = false;
            global.autolikestatus = false;
            saveSettings();
            return reply("❌ Auto view and like disabled");
          }
          return reply(
            `Usage:\n${prefix}autoviewlike on [emoji]\n${prefix}autoviewlike off`,
          );
        }
        break;
      case "setlikestatus":
        {
          if (!isCreator) return reply(mess.owner);
          const emoji = text.trim();
          if (!emoji) return reply(`Usage: ${prefix}setlikestatus 🔥`);
          global.autolikestatusEmoji = emoji;
          saveSettings();
          return reply(`✅ Auto status-like emoji changed to ${emoji}`);
        }
        break;
      case "groupsettings":
        {
          if (!m.isGroup) return reply(mess.group);
          let welcomeData = {};
          let antilinkData = {};
          let chatbotData = { global: false, group: false, chats: {} };
          let antistatusData = {};
          try {
            welcomeData = JSON.parse(
              fs.readFileSync("./database/welcome.json", "utf8"),
            );
          } catch {}
          try {
            antilinkData = JSON.parse(
              fs.readFileSync("./database/antilink.json", "utf8"),
            );
          } catch {}
          try {
            chatbotData = {
              ...chatbotData,
              ...JSON.parse(fs.readFileSync("./database/chatbot.json", "utf8")),
            };
          } catch {}
          try {
            antistatusData = JSON.parse(
              fs.readFileSync("./database/antistatus.json", "utf8"),
            );
          } catch {}
          const antiLink = antilinkData[m.chat] || {
            enabled: false,
            action: "warn",
          };
          const antiStatus = antistatusData[m.chat] || {
            enabled: false,
            mode: "warn",
          };
          const chatbotEnabled =
            chatbotData.global ||
            chatbotData.group ||
            chatbotData.chats?.[m.chat];
          return reply(
            `⚙️ *GROUP SETTINGS*\n\nWelcome: ${welcomeData[m.chat]?.enabled ? "✅ ON" : "❌ OFF"}\nAnti-link: ${antiLink.enabled ? `✅ ON (${antiLink.action})` : "❌ OFF"}\nAnti-status: ${antiStatus.enabled ? `✅ ON (${antiStatus.mode || "warn"})` : "❌ OFF"}\nChatbot: ${chatbotEnabled ? "✅ ON" : "❌ OFF"}\n\n*Commands*\n${prefix}welcome here\n${prefix}welcome disable here\n${prefix}antilink on/off\n${prefix}antilink action warn/delete/kick\n${prefix}chatbot chat on/off\n${prefix}antistatus on/off`,
          );
        }
        break;
      case "gcalert":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);

        let message = args.join(" "); // The broadcast message
        if (!message) return reply("Send a message to broadcast.");

        // Fetch group participants
        let groupParticipants = groupMetadata.participants.map((p) => p.id);

        // Notify user about the process
        await reply(
          `📢 Sending message to ${groupParticipants.length} members. Please wait...`,
        );

        try {
          // Loop through participants in batches of 5 with a 2-second delay
          const batchSize = 5;
          for (let i = 0; i < groupParticipants.length; i += batchSize) {
            let batch = groupParticipants.slice(i, i + batchSize);

            // Send messages to the current batch
            await Promise.all(
              batch.map((participant) =>
                EliteProTech.sendMessage(participant, {
                  text: `*GROUP BROADCAST*\n*Message:* ${message}\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
                }),
              ),
            );

            // Add a delay before the next batch
            if (i + batchSize < groupParticipants.length) {
              await new Promise((resolve) => setTimeout(resolve, 2000)); // 2-second delay
            }
          }

          // Send final confirmation message
          reply(
            `✅ Successfully sent the message to all ${groupParticipants.length} members.`,
          );
        } catch (err) {
          reply("❌ An error occurred while broadcasting: " + json(err));
        }
        break;
      case "removeadmins":
      case "demoteadmins":
      case "demoteall":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);

        // Fetch group participants and filter out bot and group owner
        let adminParticipants = groupMetadata.participants
          .filter((p) => p.admin === "admin") // Select only admins
          .map((p) => p.id)
          .filter((id) => id !== botNumber && id !== m.sender); // Exclude bot and group owner

        if (adminParticipants.length === 0) {
          return reply(`There's is no admin to demote just you.`);
        }

        // Notify the user about the demotion process
        reply(
          `🔄 Demoting ${adminParticipants.length} admin members. Please wait...`,
        );

        try {
          let demotedCount = 0;
          // Demote admin participants with a delay
          for (let i = 0; i < adminParticipants.length; i++) {
            let participant = adminParticipants[i];
            await EliteProTech.groupParticipantsUpdate(
              m.chat,
              [participant],
              "demote",
            );
            demotedCount++;

            // Add a 1-second delay before the next demotion
            await new Promise((resolve) => setTimeout(resolve, 1000));
          }

          // Send final confirmation message
          reply(`✅ Successfully demoted ${demotedCount} admin members!`);
        } catch (err) {
          reply("An error occurred while demoting members: " + json(err));
        }
        break;
      case "promoteall":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);

        // Filter non-admin members from group participants
        let nonAdmins = groupMetadata.participants
          .filter((p) => !p.admin)
          .map((p) => p.id);

        if (nonAdmins.length === 0)
          return reply("All participants are already admins.");

        // Notify the user about the promotion
        reply(`Promoting ${nonAdmins.length} members to admin. Please wait...`);

        try {
          // Promote non-admin members to admin with a 1-second delay
          let successCount = 0;
          for (let i = 0; i < nonAdmins.length; i++) {
            let participant = nonAdmins[i];
            await EliteProTech.groupParticipantsUpdate(
              m.chat,
              [participant],
              "promote",
            );
            successCount++;

            // Add a 1-second delay before the next promotion
            await new Promise((resolve) => setTimeout(resolve, 1000));
          }

          // Send final confirmation message
          reply(`✅ Successfully promoted ${successCount} members to admin!`);
        } catch (err) {
          reply("An error occurred while promoting members: " + json(err));
        }
        break;
      case "kickall":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply(mess.admin);
          if (!isBotAdmins) return reply(mess.botAdmin);

          const botJid = EliteProTech.user.id.split(":")[0] + "@s.whatsapp.net";
          const senderJid = m.sender;

          let participantsToRemove = groupMetadata.participants
            .map((p) => p.jid)
            .filter((jid) => jid !== botJid && jid !== senderJid);

          if (participantsToRemove.length === 0) {
            return reply(
              "❌ No eligible members.",
            );
          }

          reply(
            `🔄 Removing ${participantsToRemove.length} members from the group. Please wait...`,
          );

          try {
            let removedCount = 0;

            for (let jid of participantsToRemove) {
              await EliteProTech.groupParticipantsUpdate(
                m.chat,
                [jid],
                "remove",
              );
              removedCount++;
              await new Promise((resolve) => setTimeout(resolve, 1000));
            }

            reply(
              `✅ Successfully removed ${removedCount} members from the group!`,
            );
          } catch (err) {
            reply(
              "❌ Error while removing members:\n" +
                JSON.stringify(err, null, 2),
            );
          }
        }
        break;
      case "addall":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        if (!text)
          return reply(
            "Send numbers to add, separated by commas.\nExample: addall 2347047504860,2347047504861",
          );

        let numbers = text.match(/\d{10,}/g) || [];
        if (numbers.length === 0) return reply("No valid numbers found.");

        let addedCount = 0;
        let failed = [];

        reply(`🔄 Adding ${numbers.length} members to the group...`);

        for (let number of numbers) {
          let jid = number + "@s.whatsapp.net";
          try {
            await EliteProTech.groupParticipantsUpdate(m.chat, [jid], "add");
            addedCount++;
            await new Promise((resolve) => setTimeout(resolve, 1000)); // 1s delay
          } catch (err) {
            failed.push(number);
          }
        }

        reply(
          `✅ Added: ${addedCount}\n❌ Failed: ${failed.length > 0 ? failed.join(", ") : "None"}`,
        );
        break;
      case "pin":
      case "pindl":
      case "pinterestdl":
      case "pinterest": {
        await EliteProTech.sendMessage(m.chat, {
          react: { text: "📌", key: m.key },
        });

        if (!text) {
          return reply(`📌 Example:
• Download: ${prefix + command} https://pin.it/1YSo1okSW
• Search: ${prefix + command} A guy in hoodie`);
        }
        try {
          if (text.includes("pinterest.com") || text.includes("pin.it")) {
            let apiUrl = `https://eliteprotech-apis.zone.id/download/pinterest?url=${encodeURIComponent(text)}`;
            let res = await fetchJson(apiUrl);

            if (!res || !res.status || !res.media) {
              return reply(
                "❌ Pinterest failed.",
              );
            }
            const media = res.media;
            if (media.video) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  video: { url: media.video },
                  mimetype: "video/mp4",
                  caption:
                    `🎬 *Pinterest Video Downloaded!*\n` +
                    `📺 *Resolution:* ${media.resolution || "Original"}\n` +
                    `> *Powered by ᴘɪxᴇʟ ᴛᴇᴄʜ*`,
                },
                { quoted: m },
              );
            } else if (media.thumbnail) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  image: { url: media.thumbnail },
                  caption:
                    `🖼️ *Pinterest Image Downloaded!*\n` +
                    `📺 *Resolution:* ${media.resolution || "Original"}\n` +
                    `> *Powered by ᴘɪxᴇʟ ᴛᴇᴄʜ*`,
                },
                { quoted: m },
              );
            } else {
              return reply(
                "⚠️ No downloadable media found in this Pinterest link.",
              );
            }
          } else {
            let searchUrl = `https://ab-pinetrest.abrahamdw882.workers.dev/?query=${encodeURIComponent(text)}`;
            let result = await fetchJson(searchUrl);
            if (
              !result ||
              !result.status ||
              !result.data ||
              result.data.length === 0
            ) {
              return reply(`⚠️ No results found for: *${text}*`);
            }
            const pins = result.data.slice(0, 5);
            const cards = await Promise.all(
              pins.map(async (pin, index) => {
                if (!pin.image) return null;

                const response = await axios.get(pin.image, {
                  responseType: "arraybuffer",
                  timeout: 15000,
                });
                const imageMessage = (
                  await generateWAMessageContent(
                    {
                      image: Buffer.from(response.data),
                    },
                    {
                      upload: EliteProTech.waUploadToServer,
                    },
                  )
                ).imageMessage;
                return {
                  header: {
                    title: `📌 Pin ${index + 1}`,
                    subtitle: pin.uploader?.full_name || "Unknown",
                    imageMessage,
                    hasMediaAttachment: true,
                  },
                  body: {
                    text:
                      `*${pin.title || "No title"}*\n` +
                      `👤 ${pin.uploader?.full_name || "Unknown"}`,
                  },
                  footer: {
                    text: "ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ",
                  },
                  nativeFlowMessage: {
                    buttons: [
                      {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                          display_text: "Open Pin",
                          url: pin.pin_url,
                        }),
                      },
                    ],
                    messageParamsJson: "{}",
                  },
                };
              }),
            );
            const validCards = cards.filter(Boolean);
            if (!validCards.length) {
              return reply("⚠️ Failed to load Pinterest images.");
            }
            const msg = generateWAMessageFromContent(
              m.chat,
              {
                interactiveMessage: {
                  header: {
                    hasMediaAttachment: false,
                  },
                  body: {
                    text: `📌 Pinterest Results for: *${text}*`,
                  },
                  footer: {
                    text: `📂 ${validCards.length} results`,
                  },
                  carouselMessage: {
                    cards: validCards,
                  },
                  contextInfo: {
                    stanzaId: m.key.id,
                    participant: m.sender,
                    quotedMessage: {
                      conversation: m.text || m.body || `.${command} ${text}`,
                    },
                  },
                },
              },
              {
                userJid: EliteProTech.user.id,
                quoted: m,
              },
            );
            await EliteProTech.relayMessage(m.chat, msg.message, {
              messageId: msg.key.id,
              additionalNodes: [
                {
                  tag: "biz",
                  attrs: {},
                  content: [
                    {
                      tag: "interactive",
                      attrs: {
                        type: "native_flow",
                        v: "1",
                      },
                      content: [
                        {
                          tag: "native_flow",
                          attrs: {
                            v: "9",
                            name: "mixed",
                          },
                        },
                      ],
                    },
                  ],
                },
              ],
            });
          }
        } catch (err) {
          console.error("Pinterest error:", err);
          reply(
            "❌ Pinterest failed.",
          );
        }
        break;
      }
      case "pickup":
      case "flirt":
        {
          try {
            let apiUrl = `https://api.giftedtech.web.id/api/fun/flirt?apikey=gifted`;
            let res = await fetchJson(apiUrl);

            if (!res || !res.success || !res.result) {
              return reply("❌ Failed to fetch a flirt line. Try again later.");
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: `💘 *Flirty Line:*\n\n${res.result}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ*`,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error("Flirt API error:", err);
            reply("❌ Error occurred while getting flirt line.");
          }
        }
        break;
      case "hdwallpaper":
        {
          if (!text) {
            return reply(`Example: ${prefix + command} Mountains`);
          }

          try {
            let apiUrl = `https://api.giftedtech.web.id/api/search/wallpaper?apikey=gifted&query=${encodeURIComponent(text)}`;
            let res = await fetchJson(apiUrl);

            if (
              !res ||
              !res.success ||
              !res.results ||
              res.results.length === 0
            ) {
              return reply("❌ No wallpaper results found.");
            }

            // Shuffle and pick 5 random wallpapers
            let shuffled = res.results.sort(() => 0.5 - Math.random());
            let selected = shuffled.slice(0, 5);

            for (let i = 0; i < selected.length; i++) {
              let img = selected[i];
              let imageUrl = img.image[0] || img.image;
              let type = img.type || "Wallpaper";

              let imgRes = await fetch(imageUrl);
              let buffer = await imgRes.buffer();

              await EliteProTech.sendMessage(
                m.chat,
                {
                  image: buffer,
                  caption: `🖼️ *Wallpaper Result ${i + 1}/5*\n\n📌 *Type:* ${type}\n🔍 *Query:* ${text}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ*`,
                },
                { quoted: m },
              );
            }
          } catch (err) {
            console.error("Wallpaper API error:", err);
            reply("❌ Error occurred while fetching wallpapers.");
          }
        }
        break;
      case "lyrics":
        {
          if (!text) {
            return reply(`Example: ${prefix + command} Faded Alan Walker`);
          }

          try {
            let apiUrl = `https://api.nexoracle.com/search/lyrics?apikey=34e93682c3603be0f9&q=${encodeURIComponent(text)}`;
            let res = await fetchJson(apiUrl);

            if (
              !res ||
              res.status !== 200 ||
              !res.result ||
              !res.result.lyrics
            ) {
              return reply(
                `Send both song title and artist, e.g.:* ${prefix + command} faded | Alan Walker`,
              );
            }

            let { title, lyrics } = res.result;

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: `🎶 *Lyrics Found!*\n\n🎤 *Title:* ${title}\n\n📝 *Lyrics:*\n${lyrics}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ*`,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error("NexOracle Lyrics API error:", err);
            reply("❌ Error occurred while fetching lyrics.");
          }
        }
        break;
      case "clearchat":
        {
          if (!isCreator) return reply(mess.owner);

          try {
            await EliteProTech.chatModify(
              {
                delete: true,
                lastMessages: [
                  {
                    key: m.key,
                    messageTimestamp: m.messageTimestamp,
                  },
                ],
              },
              m.chat,
            );

            reply(`✅ Chat cleared.`);
          } catch (err) {
            reply(`❌ Failed to clear chat: ${err.message}`);
          }
        }
        break;
      case "image":
      case "images":
      case "imgsearch":
      case "img": {
        if (!text) {
          return reply(
            "📸 Please enter a search term!\n\n" + "Example:\n.img cat",
          );
        }
        await EliteProTech.sendMessage(m.chat, {
          react: { text: "⏳", key: m.key },
        });
        const res = await axios.get(
          `https://eliteprotech-apis.zone.id/image/bingimg?q=${encodeURIComponent(text)}`,
        );
        if (
          !res.data?.status ||
          !Array.isArray(res.data.results) ||
          !res.data.results.length
        ) {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          return reply("❌ No images found.");
        }
        const selected = res.data.results
          .sort(() => 0.5 - Math.random())
          .slice(0, 5);
        const cards = await Promise.all(
          selected.map(async (item, index) => {
            const response = await axios.get(item.image, {
              responseType: "arraybuffer",
              timeout: 15000,
            });
            const imageMessage = (
              await generateWAMessageContent(
                {
                  image: Buffer.from(response.data),
                },
                {
                  upload: EliteProTech.waUploadToServer,
                },
              )
            ).imageMessage;
            return {
              header: {
                title: `🖼️ Image ${index + 1}`,
                subtitle: "",
                imageMessage,
                hasMediaAttachment: true,
              },

              body: {
                text: `*${text}*\n${item.title || ""}`,
              },

              footer: {
                text: "ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ",
              },

              nativeFlowMessage: {
                buttons: [
                  {
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                      display_text: "Open",
                      url: item.image,
                    }),
                  },
                ],
                messageParamsJson: "{}",
              },
            };
          }),
        );

        const validCards = cards.filter(Boolean);

        if (!validCards.length) {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          return reply("❌ Failed to process images.");
        }
        const msg = generateWAMessageFromContent(
          m.chat,
          {
            interactiveMessage: {
              header: {
                hasMediaAttachment: false,
              },
              body: {
                text: `🖼️ Results for: *${text}*`,
              },
              footer: {
                text: `📂 ${validCards.length}/${res.data.total || validCards.length} images`,
              },
              carouselMessage: {
                cards: validCards,
              },
              contextInfo: {
                stanzaId: m.key.id,
                participant: m.sender,
                quotedMessage: {
                  conversation: m.text || m.body || `.${command} ${text}`,
                },
              },
            },
          },
          {
            userJid: EliteProTech.user.id,
            quoted: m,
          },
        );
        await EliteProTech.relayMessage(m.chat, msg.message, {
          messageId: msg.key.id,
          additionalNodes: [
            {
              tag: "biz",
              attrs: {},
              content: [
                {
                  tag: "interactive",
                  attrs: {
                    type: "native_flow",
                    v: "1",
                  },
                  content: [
                    {
                      tag: "native_flow",
                      attrs: {
                        v: "9",
                        name: "mixed",
                      },
                    },
                  ],
                },
              ],
            },
          ],
        });
        await EliteProTech.sendMessage(m.chat, {
          react: {
            text: "✅",
            key: m.key,
          },
        });
        break;
      }
      case "removebg": {
        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          let imgUrl = text;

          if (!imgUrl && m.quoted) {
            const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
            const mime = quotedMsg?.mimetype || "";

            if (/image/.test(mime)) {
              const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
                m.quoted,
              );
              imgUrl = await uploadToEliteTempUrl(mediaPath);
              fs.unlinkSync(mediaPath);
            } else {
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "❌", key: m.key },
              });
              return reply(
                `❌ Please reply to an image or provide an image URL.\n\nExample:\n${prefix}removebg https://example.com/image.jpg`,
              );
            }
          }

          if (!imgUrl) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply(
              `❌ Please reply to an image or provide an image URL.\n\nExample:\n${prefix}removebg https://example.com/image.jpg`,
            );
          }

          const apiUrl = `https://eliteprotech-apis.zone.id/tools/removebg?url=${encodeURIComponent(imgUrl)}`;
          const response = await axios.get(apiUrl);
          const data = response.data;

          if (!data?.success || !data?.result) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply("❌ Failed to remove background.");
          }

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: data.result },
              caption: "✅ Background removed!",
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error(error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply("❌ Error occurred while removing background.");
        }
        break;
      }
      case "ocr":
      case "img2txt": {
        try {
          let imgUrl = text;

          if (!imgUrl && m.quoted) {
            const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
            const mime = quotedMsg?.mimetype || "";
            if (/image/.test(mime)) {
              const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
                m.quoted,
              );
              imgUrl = await uploadToEliteTempUrl(mediaPath);
              fs.unlinkSync(mediaPath);
            } else {
              return reply(
                `❌ Please reply to an image or provide an image URL.\n\nExample:\n${prefix + command} https://example.com/image.jpg`,
              );
            }
          }

          if (!imgUrl) {
            return reply(
              `❌ Please reply to an image or provide an image URL.\n\nExample:\n${prefix + command} https://example.com/image.jpg`,
            );
          }

          const apiUrl = `https://eliteprotech-apis.zone.id/tools/ocr?url=${encodeURIComponent(imgUrl)}`;
          const res = await axios.get(apiUrl);
          const json = res.data;

          if (!json.success || !json.text) {
            return reply("❌ OCR failed or no text found.");
          }

          const ocrText = json.text;

          await sendInteractiveMessage(
            EliteProTech,
            m.chat,
            {
              text: `✅ *OCR Result:*\n\n${ocrText}`,
              interactiveButtons: [
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Copy Text",
                    copy_code: ocrText,
                  }),
                },
              ],
            },
            { quoted: m },
          );
        } catch (err) {
          console.error(err);
          reply("❌ Error occurred while performing OCR.");
        }
        break;
      }
      case "waste":
      case "rip":
      case "wasted": {
        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          let imgUrl = text;

          if (!imgUrl && m.quoted) {
            const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
            const mime = quotedMsg?.mimetype || "";

            if (/image/.test(mime)) {
              const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
                m.quoted,
              );
              imgUrl = await uploadToEliteTempUrl(mediaPath);
              fs.unlinkSync(mediaPath);
            } else {
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "❌", key: m.key },
              });
              return reply(
                `❌ Please reply to an image or provide an image URL.\n\nExample:\n${prefix}wasted https://example.com/image.jpg`,
              );
            }
          }

          if (!imgUrl) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply(
              `❌ Please reply to an image or provide an image URL.\n\nExample:\n${prefix}wasted https://example.com/image.jpg`,
            );
          }

          const apiUrl = `https://eliteprotech-apis.zone.id/fun/wasted?url=${encodeURIComponent(imgUrl)}`;
          const response = await axios.get(apiUrl);
          const data = response.data;

          if (!data?.success || !data?.url) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply("❌ Failed to generate wasted image.");
          }

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: data.url },
              caption: "💀 WASTED",
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error(error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply("❌ Error occurred while generating wasted image.");
        }
        break;
      }
      case "hd":
      case "remini":
      case "enhance":
      case "upscale": {
        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          let imgUrl = text;

          if (!imgUrl && m.quoted) {
            const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
            const mime = quotedMsg?.mimetype || "";

            if (/image/.test(mime)) {
              const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
                m.quoted,
              );
              imgUrl = await uploadToEliteTempUrl(mediaPath);
              fs.unlinkSync(mediaPath);
            } else {
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "❌", key: m.key },
              });
              return reply(
                `❌ Please reply to an image or provide an image URL.\n\nExample:\n${prefix + command} https://example.com/image.jpg`,
              );
            }
          }

          if (!imgUrl) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply(
              `❌ Please reply to an image or provide an image URL.\n\nExample:\n${prefix + command} https://example.com/image.jpg`,
            );
          }

          const apiUrl = `https://eliteprotech-apis.zone.id/tools/upscaler?url=${encodeURIComponent(imgUrl)}`;

          // 🔥 IMPORTANT FIX: get image as buffer
          const response = await axios.get(apiUrl, {
            responseType: "arraybuffer",
          });

          const imageBuffer = Buffer.from(response.data);

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: imageBuffer,
              caption: "✅ Image upscaled!",
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error(error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply("❌ Error occurred while upscaling image.");
        }
        break;
      }
      case "update": {
        if (!isCreator) {
          return reply(mess.owner);
        }
        const user = "EliteProTech";
        const repo = "ELITE-PRO-V1";
        const branch = "main";
        const foldersToUpdate = ["lib"];
        const filesToUpdate = ["package.json"];
        const localBasePath = __dirname;
        async function downloadFolder(folderPath, localPath) {
          const url = `https://api.github.com/repos/${user}/${repo}/contents/${folderPath}?ref=${branch}`;
          try {
            const { data } = await axios.get(url, {
              headers: {
                "User-Agent": "EliteProTech",
              },
            });
            for (const item of data) {
              const localFilePath = path.join(localPath, item.path);
              if (item.type === "file") {
                fs.mkdirSync(path.dirname(localFilePath), { recursive: true });
                const { data: fileData } = await axios.get(item.download_url, {
                  responseType: "text",
                });
                fs.writeFileSync(localFilePath, fileData, "utf8");
                console.log(`✅ Updated: ${item.path}`);
              } else if (item.type === "dir") {
                if (!fs.existsSync(localFilePath)) {
                  fs.mkdirSync(localFilePath, { recursive: true });
                }
                await downloadFolder(item.path, localPath);
              }
            }
          } catch (err) {
            console.error(
              `❌ Error reading folder ${folderPath}:`,
              err.message,
            );
            throw err;
          }
        }
        async function downloadFile(filePath) {
          const fileUrl = `https://raw.githubusercontent.com/${user}/${repo}/${branch}/${filePath}`;
          try {
            const { data } = await axios.get(fileUrl, {
              responseType: "text",
            });
            const localFilePath = path.join(localBasePath, filePath);
            fs.mkdirSync(path.dirname(localFilePath), { recursive: true });
            fs.writeFileSync(localFilePath, data, "utf8");
            console.log(`✅ Updated: ${filePath}`);
          } catch (err) {
            console.error(`❌ Error updating file ${filePath}:`, err.message);
            throw err;
          }
        }
        async function installDependencies() {
          const { exec } = await import("child_process");
          return new Promise((resolve, reject) => {
            console.log("📦 Running npm install...");
            exec(
              "npm install",
              { cwd: localBasePath },
              (error, stdout, stderr) => {
                if (stdout) console.log(stdout);
                if (stderr) console.log(stderr);
                if (error) {
                  console.error("❌ npm install failed:", error.message);
                  reject(error);
                  return;
                }
                console.log("✅ Dependencies installed.");
                resolve();
              },
            );
          });
        }
        try {
          await reply(
            "*📥 Updating and restarting the bot to apply changes...*",
          );
          for (const folder of foldersToUpdate) {
            const folderPath = path.join(localBasePath, folder);
            if (fs.existsSync(folderPath)) {
              fs.rmSync(folderPath, {
                recursive: true,
                force: true,
              });
            }
            await downloadFolder(folder, localBasePath);
          }
          for (const file of filesToUpdate) {
            await downloadFile(file);
          }
          await installDependencies();
          console.log("✅ Update completed.");
          setTimeout(() => {
            process.exit(0);
          }, 2000);
        } catch (err) {
          console.error("❌ Update failed:", err);
          return reply("❌ Update failed:\n" + (err.message || err));
        }
        break;
      }
      case "antidel":
      case "antidelete":
        {
          if (!isCreator) return reply(mess.owner);
          const arg = (args[0] || "").toLowerCase();
          if (!["on", "off", "enable", "disable"].includes(arg)) {
            const status = getAntiDeleteStatus();
            return reply(
              `⚙️ *ANTI-DELETE SETTINGS*\n\n` +
                `Status: ${status ? "✅ Enabled" : "❌ Disabled"}\n\n` +
                `Use:\n` +
                `${prefix}antidelete on\n` +
                `${prefix}antidelete off`,
            );
          }
          const enabled = ["on", "enable"].includes(arg);
          setAntiDeleteStatus(enabled);
          return reply(
            `✅ Anti-Delete is now *${enabled ? "enabled" : "disabled"}*.`,
          );
        }
        break;
      case "fbdl":
      case "facebookdl":
      case "facebook":
      case "fb": {
        if (!text)
          return reply(
            `Give Me A Facebook Video Link \n\n*Example:* ${prefix + command} https://www.facebook.com/share/v/15PtWTGvW9/`,
          );

        await EliteProTech.sendMessage(m.chat, {
          react: { text: `📥`, key: m.key },
        });

        try {
          const apiUrl = `https://eliteprotech-apis.zone.id/download/facebook2?url=${encodeURIComponent(text)}`;
          const { data } = await axios.get(apiUrl);

          if (data?.status === true && data?.video) {
            const title = data.title || "Facebook Video";

            await EliteProTech.sendMessage(
              m.chat,
              {
                video: { url: data.video },
                mimetype: "video/mp4",
                fileName: `${title.replace(/[\\/:*?"<>|]/g, "")}.mp4`,
                caption: `*✅ Video downloaded*`,
                jpegThumbnail: data.thumbnail
                  ? Buffer.from(
                      (
                        await axios.get(data.thumbnail, {
                          responseType: "arraybuffer",
                        })
                      ).data,
                    )
                  : undefined,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: `✅`, key: m.key },
            });
          } else {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: `❌`, key: m.key },
            });

            reply(
              "❌ Facebook fetch failed.",
            );
          }
        } catch (error) {
          console.error("Error in Facebook Downloader:", error.message);

          await EliteProTech.sendMessage(m.chat, {
            react: { text: `⚠️`, key: m.key },
          });

          reply(
            "❌ Error. Try again.",
          );
        }

        break;
      }
      case "fakeigstory":
      case "igstory": {
        if (!text) {
          return reply(`*Example:* ${prefix + command} Hello World`);
        }

        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: `🎨`, key: m.key },
          });

          const storyText = text;
          const name = pushname || "EliteProTech";

          let ppUrl;

          try {
            const ppBuffer = await getBuffer(profilepuser);

            const tempPath = `./temp_${Date.now()}.jpg`;
            fs.writeFileSync(tempPath, ppBuffer);

            ppUrl = await uploadToEliteTempUrl(tempPath);

            fs.unlinkSync(tempPath);
          } catch {
            ppUrl =
              "https://raw.githubusercontent.com/uploader762/dat4/main/uploads/e0f993-1777126212302.jpg";
          }

          const apiUrl = `https://eliteprotech-apis.zone.id/fun/fakeigstory?text=${encodeURIComponent(storyText)}&name=${encodeURIComponent(name)}&pp=${encodeURIComponent(ppUrl)}`;

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: apiUrl },
              caption: `*✅ Fake Instagram Story Generated*`,
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: `✅`, key: m.key },
          });
        } catch (error) {
          console.error("Fake IG Story Error:", error);

          await EliteProTech.sendMessage(m.chat, {
            react: { text: `❌`, key: m.key },
          });

          reply(`❌ Failed to generate fake Instagram story.`);
        }

        break;
      }
      case "insta":
      case "igdl":
      case "reels":
      case "instagram":
      case "ig": {
        if (!text) {
          return reply(
            `Give Me An Instagram Reel/Post Link\n\n*Example:* ${prefix + command} https://www.instagram.com/reel/C9bjQfRprHK`,
          );
        }
        await EliteProTech.sendMessage(m.chat, {
          react: { text: "📥", key: m.key },
        });
        try {
          const apiUrl = `https://eliteprotech-apis.zone.id/download/instagram?url=${encodeURIComponent(text)}`;
          const { data } = await axios.get(apiUrl, {
            timeout: 30000,
          });
          if (!data?.success || !data?.data?.media?.url) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply(
              "❌ Instagram fetch failed.",
            );
          }
          const media = data.data.media;
          const author = data.data.author;
          const caption = data.data.caption;
          if (media.type === "video") {
            await EliteProTech.sendMessage(
              m.chat,
              {
                video: { url: media.url },
                mimetype: "video/mp4",
                caption:
                  `*Instagram Download*\n\n` +
                  `👤 *Author:* ${author?.fullname || author?.username || "Unknown"}\n` +
                  `❤️ *Likes:* ${data.data.stats?.likes || 0}\n\n` +
                  `${caption || ""}`,
              },
              { quoted: m },
            );
          } else if (media.type === "image") {
            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: media.url },
                caption:
                  `*Instagram Download*\n\n` +
                  `👤 *Author:* ${author?.fullname || author?.username || "Unknown"}\n` +
                  `${caption || ""}`,
              },
              { quoted: m },
            );
          }
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error("Instagram Downloader:", error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          return reply(
            `❌ Failed to download the Instagram media.\n\n${error.message}`,
          );
        }
        break;
      }
      case "get":
        {
          if (!text)
            return reply(
              `Example: ${prefix + command} https://api.example.com/data`,
            );

          try {
            const headers = {
              "User-Agent": "EliteProTech-Bot/1.0",
              Accept: "*/*",
            };
            const res = await axios.get(text, {
              responseType: "arraybuffer",
              headers,
            });
            const contentType = (
              res.headers["content-type"] || ""
            ).toLowerCase();
            const rawData = Buffer.from(res.data);
            let isJson = false;
            let parsedJson = null;
            try {
              const preview = rawData.slice(0, 200).toString();
              if (
                preview.trim().startsWith("{") ||
                preview.trim().startsWith("[")
              ) {
                parsedJson = JSON.parse(rawData.toString());
                isJson = true;
              }
            } catch {
              /* not JSON */
            }

            // ✅ If JSON (by header OR detected structure)
            if (contentType.includes("application/json") || isJson) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  text: JSON.stringify(
                    parsedJson || JSON.parse(rawData.toString()),
                    null,
                    2,
                  ),
                },
                { quoted: m },
              );
            }

            // ✅ If image
            else if (contentType.startsWith("image/")) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  image: rawData,
                  caption: `📷 *Image from API*`,
                },
                { quoted: m },
              );
            }

            // ✅ If audio
            else if (contentType.startsWith("audio/")) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  audio: rawData,
                  mimetype: contentType || "audio/mpeg",
                },
                { quoted: m },
              );
            }

            // ✅ If video
            else if (contentType.startsWith("video/")) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  video: rawData,
                  mimetype: contentType || "video/mp4",
                  caption: `🎥 *Video from API*`,
                },
                { quoted: m },
              );
            }

            // ✅ Otherwise → send as document (fallback)
            else {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  document: rawData,
                  mimetype: contentType || "application/octet-stream",
                  fileName: "response.bin",
                },
                { quoted: m },
              );
            }
          } catch (err) {
            console.error("❌ API Error:", err.message);

            let errorMessage = {
              success: false,
              message: "❌ Unknown error occurred.",
            };
            if (err.response) {
              try {
                const type = err.response.headers["content-type"] || "";
                const dataBuf = Buffer.from(err.response.data);
                if (type.includes("application/json")) {
                  errorMessage = JSON.parse(dataBuf.toString());
                } else {
                  const preview = dataBuf.slice(0, 100).toString();
                  if (
                    preview.trim().startsWith("{") ||
                    preview.trim().startsWith("[")
                  ) {
                    errorMessage = JSON.parse(preview);
                  } else {
                    errorMessage.message = `❌ Server responded with status ${err.response.status}`;
                  }
                }
              } catch {
                errorMessage.message = `❌ Server error: ${err.response.statusText || "Unknown"}`;
              }
            } else if (err.request) {
              errorMessage.message =
                "⚠️ No response received from the API server.";
            } else {
              errorMessage.message = `❌ ${err.message}`;
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: JSON.stringify(errorMessage, null, 2),
              },
              { quoted: m },
            );
          }
        }
        break;
      case "jid":
        {
          try {
            let targetJid;

            // If mentioned
            if (m.mentionedJid && m.mentionedJid.length > 0) {
              targetJid = m.mentionedJid[0];
            }
            // If quoted
            else if (m.quoted) {
              targetJid = m.quoted.sender;
            }
            // Otherwise, group or private
            else {
              targetJid = m.chat;
            }

            // If it's a group, get real JID from metadata
            if (m.isGroup) {
              const meta = await EliteProTech.groupMetadata(m.chat);
              const found = meta.participants.find(
                (p) =>
                  p.id === targetJid ||
                  p.lid === targetJid ||
                  p.jid === targetJid,
              );

              if (found && found.jid) targetJid = found.jid;
              else targetJid = meta.id; // group JID fallback
            }

            // Decode if LID
            const realJid = await EliteProTech.decodeJid(targetJid);

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: realJid,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error(err);
            reply(`❌ Failed to get JID.`);
          }
        }
        break;
      case "lid":
        {
          try {
            let targetLid;

            // If mentioned
            if (m.mentionedJid && m.mentionedJid.length > 0) {
              targetLid = m.mentionedJid[0];
            }
            // If quoted
            else if (m.quoted) {
              targetLid = m.quoted.sender;
            }
            // Otherwise group or private
            else {
              targetLid = m.chat;
            }

            if (m.isGroup) {
              const meta = await EliteProTech.groupMetadata(m.chat);
              const found = meta.participants.find(
                (p) =>
                  p.id === targetLid ||
                  p.lid === targetLid ||
                  p.jid === targetLid,
              );

              if (found && found.lid) targetLid = found.lid;
              else targetLid = meta.id.replace("@g.us", "@lid"); // group lid fallback
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: targetLid,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error(err);
            reply(`❌ Failed to get LID.`);
          }
        }
        break;
      case "eval":
      case "ev":
        {
          if (!isCreator) return;

          let code = full_args;
          if (!code) return reply("⚠️ Provide some code to eval");

          try {
            let evaled;

            try {
              evaled = await eval(`(async () => (${code}))()`);
            } catch {
              evaled = await eval(`(async () => {
                ${code}
            })()`);
            }

            let output = require("util").inspect(evaled, {
              depth: 5,
            });

            if (output.length > 90000) {
              console.log(output);
              reply("✅ Result too long, check console.");
            } else {
              reply(output);
            }
          } catch (e) {
            reply("❌ Error:\n" + String(e));
          }
        }
        break;
      case "npmdownloader":
      case "npmdownload":
      case "npmdl":
      case "npm": {
        if (!text)
          return reply(
            `⛔ Please enter an NPM package name and version (optional).\n\n📌 Example:\n${prefix + command} express,latest`,
          );

        async function npmdownloader(pkg, pkgver) {
          try {
            const filePath = await new Promise((resolve, reject) => {
              exec(`npm pack ${pkg}@${pkgver}`, (error, stdout) => {
                if (error) {
                  reply("❌ Error while fetching package.");
                  console.error(`exec error: ${error}`);
                  reject(error);
                  return;
                }
                resolve(stdout.trim());
              });
            });

            const fileName = filePath.split("/").pop();
            const data = await fs.promises.readFile(filePath);

            let Link;
            if (pkgver === "latest") {
              Link = `https://www.npmjs.com/package/${pkg}`;
            } else {
              Link = `https://www.npmjs.com/package/${pkg}/v/${pkgver}`;
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                document: data,
                mimetype: "application/zip",
                fileName: fileName,
                caption: `📦 *NPM Package Downloader*\n\n- \`Name\`: ${fileName}\n- \`Version\`: ${pkgver}\n- \`Link\`: ${Link}`,
              },
              { quoted: m },
            );

            // remove temp file after sending
            await fs.promises.unlink(filePath);
          } catch (err) {
            console.error(`Error: ${err}`);
            reply(
              "❌ Package not found.",
            );
          }
        }

        await EliteProTech.sendMessage(m.chat, {
          react: { text: "⏱", key: m.key },
        });

        try {
          const [pkgName, ver] = text.split(",");
          await npmdownloader(pkgName.trim(), (ver || "latest").trim());
        } catch (error) {
          reply("⚠️ Package not found.");
        }
        break;
      }
      case "gemini":
        {
          if (!text)
            return reply(`Please enter a prompt for Gemini to respond.`);

          try {
            let apii = await fetch(
              `https://apis-starlights-team.koyeb.app/starlight/gemini?text=${encodeURIComponent(text)}`,
            );
            let res = await apii.json();

            reply(res.result);
          } catch (err) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            reply(`Gemini cannot answer that question.`);
          }
        }
        break;
      case "aio": {
        if (!text)
          return reply(
            `Give Me A Video URL (Facebook, TikTok, etc.)\n\n*Example:* ${prefix + command} https://www.facebook.com/share/v/15PtWTGvW9/`,
          );

        await EliteProTech.sendMessage(m.chat, {
          react: { text: `📥`, key: m?.key },
        });

        try {
          const apiUrl = `https://eliteprotech-apis.zone.id/download/aio?url=${encodeURIComponent(text)}`;
          const { data } = await axios.get(apiUrl);

          if (data.success && data.download_links?.length) {
            for (let i = 0; i < data.download_links.length; i++) {
              const videoUrl = data.download_links[i];
              await EliteProTech.sendMessage(
                m.chat,
                {
                  video: { url: videoUrl },
                  mimetype: "video/mp4",
                  fileName: `AIO_Video_${i + 1}.mp4`,
                  caption: `🎥 *Video ${i + 1}*\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ*`,
                },
                { quoted: m },
              );
            }
          } else {
            reply(
              data.error_message ||
                "❌ Unable to fetch video(s).",
            );
          }
        } catch (error) {
          console.error("Error in AIO Downloader:", error.message);
          reply(
            "❌ Error. Try again.",
          );
        }

        break;
      }
      case "firelogo":
        {
          if (!text)
            return reply(
              `Send text to generate the fire logo.\n\n*Example:* ${prefix + command} EliteProTech users`,
            );

          try {
            const axios = require("axios");
            let res = await axios.get(
              `https://eliteprotech-apis.zone.id/fun/firelogo?text=${encodeURIComponent(text)}`,
            );

            if (!res.data || !res.data.success) {
              return reply(
                "Failed to generate fire logo.",
              );
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: res.data.image },
                caption: `🔥 *Fire Logo Generated*\n*Text:* ${res.data.text}`,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error(err);
            reply("An error occurred while generating the fire logo.");
          }
        }
        break;
      case "create": {
        try {
          if (!q) {
            return reply(
              `⚠️ Example: *${prefix + command} a man walking home*`,
            );
          }
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "🖼️", key: m.key },
          });
          const imageUrl = `https://eliteprotech-apis.zone.id/ai/zonerai?prompt=${encodeURIComponent(q)}`;
          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: imageUrl },
              caption: `*AI Image Generated*`,
            },
            { quoted: m },
          );
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error("Create Error:", error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply("❌ Failed to generate the image.");
        }
        break;
      }
      case "toanime":
        {
          const isPremium = await checkPremiumUser(m.sender);
          if (!isPremium) return reply(mess.prem);
          if (!text) {
            return reply(`Example: ${prefix + command} make him cute`);
          }

          if (!quoted || !/image/.test(mime)) {
            return reply("Reply to an image with a prompt");
          }

          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🎨", key: m.key },
            });

            const media = await quoted.download();
            const tempDir = path.join(__dirname, "temp");

            if (!fs.existsSync(tempDir)) {
              fs.mkdirSync(tempDir, { recursive: true });
            }

            const filePath = path.join(tempDir, `${Date.now()}.jpg`);
            fs.writeFileSync(filePath, media);

            const imageUrl = await uploadToEliteProTechUrl(filePath);

            const apiUrl = `https://eliteprotech-apis.zone.id/toanime?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(text)}`;
            const { data } = await axios.get(apiUrl);

            if (!data || !data.url) {
              if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
              return reply("Failed to generate anime image");
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: data.url },
                caption: `*✅ Image Successfully Generated*`,
              },
              { quoted: m },
            );

            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (error) {
            console.log(error);
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            reply("Error processing anime conversion");
          }
        }
        break;
      case "ac":
      case "anticall":
        {
          if (!isCreator) return reply(mess.owner);

          // Load anticall settings
          let anticallData = {};
          try {
            anticallData = JSON.parse(
              fs.readFileSync("./database/anticall.json"),
            );
          } catch {
            anticallData = { enabled: false, mode: "decline" };
          }

          if (!args[0]) {
            return reply(`
⿻ *ANTICALL SETTINGS*
╭───────────────━⊷
║ .anticall decline → Reject call & warn
║ .anticall block   → Reject call & block
║ .anticall off     → Disable anticall
╰───────────────━⊷
_*Current:* ${anticallData.enabled ? `✅ ENABLED (${anticallData.mode.toUpperCase()})` : "❌ DISABLED"}_`);
          }

          if (args[0].toLowerCase() === "decline") {
            anticallData.enabled = true;
            anticallData.mode = "decline";
            fs.writeFileSync(
              "./database/anticall.json",
              JSON.stringify(anticallData, null, 2),
            );
            return reply("✅ *ANTICALL ENABLED:* Mode → DECLINE");
          }

          if (args[0].toLowerCase() === "block") {
            anticallData.enabled = true;
            anticallData.mode = "block";
            fs.writeFileSync(
              "./database/anticall.json",
              JSON.stringify(anticallData, null, 2),
            );
            return reply("✅ *ANTICALL ENABLED:* Mode → BLOCK");
          }

          if (args[0].toLowerCase() === "off") {
            anticallData.enabled = false;
            fs.writeFileSync(
              "./database/anticall.json",
              JSON.stringify(anticallData, null, 2),
            );
            return reply("❌ *ANTICALL DISABLED* → Calls are now allowed.");
          }

          return reply(
            "⚠️ Invalid command! Use: .anticall decline / block / off",
          );
        }
        break;
      case "elevenlab":
        {
          if (!q) {
            return reply(
              `⚠️ Send name + text.

*Example:*
${prefix}elevenlab mrbeast hello world

*Tip:* Use "${prefix}elevenlab list" to view all available voices.`,
            );
          }

          // Handle "list" command
          if (q.trim().toLowerCase() === "list") {
            try {
              const res = await fetch(
                "https://eliteprotech-apis.zone.id/tools/elevenlab?list=true",
              );
              const data = await res.json();
              if (!data.success) return reply("❌ Failed to load voice list.");
              const voices = data.voices.join(", ");
              return reply(`🎙️ *Available Voices:*\n${voices}`);
            } catch (err) {
              return reply(`⚠️ Error loading voices: ${err.message}`);
            }
          }

          // Parse input
          let [voice, ...textArr] = q.split(" ");
          if (!voice || !textArr.length) {
            return reply(
              `⚠️ Send name + text.

*Example:*
${prefix}elevenlab mrbeast hello world`,
            );
          }

          let text = textArr.join(" ").trim();

          try {
            // ⏳ React while generating
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "⏳", key: m.key },
            });

            const apiUrl = `https://eliteprotech-apis.zone.id/tools/elevenlab?q=${encodeURIComponent(text)}&voicename=${encodeURIComponent(voice)}`;
            const res = await fetch(apiUrl);
            const data = await res.json();

            if (data.success && data.url) {
              // ✅ Success reaction
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "✅", key: m.key },
              });

              const audioRes = await fetch(data.url);
              const buffer = await audioRes.arrayBuffer();

              await EliteProTech.sendMessage(
                m.chat,
                {
                  audio: Buffer.from(buffer),
                  mimetype: "audio/mpeg",
                  ptt: false,
                },
                { quoted: m },
              );
            } else {
              // ❌ Failed reaction
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "❌", key: m.key },
              });
              reply(data.error || "❌ Failed to generate audio.");
            }
          } catch (e) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "⚠️", key: m.key },
            });
            reply(`⚠️ Error: ${e.message}`);
          }
        }
        break;
      case "fetch":
        {
          const fetch = require("node-fetch");
          const { format } = require("util");

          if (!q)
            return reply(
              `⚠️ Example: *${prefix + command} https://example.com*`,
            );

          if (!/^https?:\/\//.test(q))
            return reply("⚠️ URL must start with http:// or https://");

          try {
            let res = await fetch(q);

            // Prevent huge files (limit 100MB)
            if (res.headers.get("content-length") > 100 * 1024 * 1024) {
              return reply(
                `❌ File too large. Content-Length: ${res.headers.get("content-length")}`,
              );
            }

            let contentType = res.headers.get("content-type") || "";
            let fileName = q.split("/").pop() || "file";

            if (/audio/.test(contentType)) {
              return EliteProTech.sendMessage(
                m.chat,
                {
                  audio: { url: q },
                  mimetype: contentType,
                  fileName: fileName,
                },
                { quoted: m },
              );
            } else if (/video/.test(contentType)) {
              return EliteProTech.sendMessage(
                m.chat,
                {
                  video: { url: q },
                  mimetype: contentType,
                  fileName: fileName,
                },
                { quoted: m },
              );
            } else if (/image/.test(contentType)) {
              return EliteProTech.sendMessage(
                m.chat,
                {
                  image: { url: q },
                  mimetype: contentType,
                  fileName: fileName,
                },
                { quoted: m },
              );
            } else if (/text|json/.test(contentType)) {
              let txt = await res.buffer();
              try {
                txt = format(JSON.parse(txt.toString()));
              } catch (e) {
                txt = txt.toString();
              } finally {
                return reply(txt.slice(0, 65536));
              }
            } else {
              // fallback to document if unknown type
              return EliteProTech.sendMessage(
                m.chat,
                {
                  document: { url: q },
                  mimetype: contentType,
                  fileName: fileName,
                },
                { quoted: m },
              );
            }
          } catch (e) {
            reply(`❌ Error fetching URL:\n${e.message}`);
          }
        }
        break;
      case "channel-id":
      case "channelid":
        {
          if (!text) return reply("Send the channel link.");

          if (!text.includes("https://whatsapp.com/channel/")) {
            return reply("Invalid channel link.");
          }

          const channelCode = text
            .split("https://whatsapp.com/channel/")[1]
            .trim();

          try {
            const res = await EliteProTech.newsletterMetadata(
              "invite",
              channelCode,
            );

            const msgText = `📢 *Whatsapp Channel Info:*

📌 *Channel Code:*
${channelCode}

🆔 *Channel ID:*
${res.id}

🔗 *Link:*
${text}`;

            await sendInteractiveMessage(
              EliteProTech,
              m.chat,
              {
                text: msgText,
                footer: "> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*",
                interactiveButtons: [
                  {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                      display_text: "Copy Channel ID 📋",
                      copy_code: res.id,
                    }),
                  },
                ],
              },
              { quoted: m },
            );
          } catch (err) {
            console.error(err);
            reply("❌ Failed to resolve channel ID.");
          }
        }
        break;
      case "fetchimg":
        {
          const path = require("path");

          if (!q)
            return reply(
              `⚠️ Example: *${prefix + command} https://example.com/image.png*`,
            );
          if (!/^https?:\/\//.test(q))
            return reply("⚠️ URL must start with http:// or https://");

          try {
            let fileName = q.split("/").pop() || "image";
            let ext = path.extname(fileName).toLowerCase();
            if (!ext) fileName += ".jpg"; // fallback to jpg if no extension

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: q },
                mimetype: `image/${ext.replace(".", "") || "jpeg"}`,
                fileName: fileName,
              },
              { quoted: m },
            );
          } catch (e) {
            reply(`❌ Error sending image:\n${e.message}`);
          }
        }
        break;
      case "fetchvid":
      case "fetchvideo":
        {
          const path = require("path");

          if (!q)
            return reply(
              `⚠️ Example: *${prefix + command} https://example.com/video.mp4*`,
            );
          if (!/^https?:\/\//.test(q))
            return reply("⚠️ URL must start with http:// or https://");

          try {
            let fileName = q.split("/").pop() || "video";
            let ext = path.extname(fileName).toLowerCase();
            if (!ext) fileName += ".mp4"; // fallback to mp4 if no extension

            await EliteProTech.sendMessage(
              m.chat,
              {
                video: { url: q },
                mimetype: `video/${ext.replace(".", "") || "mp4"}`,
                fileName: fileName,
              },
              { quoted: m },
            );
          } catch (e) {
            reply(`❌ Error sending video:\n${e.message}`);
          }
        }
        break;
      case "fetchaud":
      case "fetchaudio":
        {
          const path = require("path");

          if (!q)
            return reply(
              `⚠️ Example: *${prefix + command} https://example.com/audio*`,
            );
          if (!/^https?:\/\//.test(q))
            return reply("⚠️ URL must start with http:// or https://");

          try {
            let fileName = q.split("/").pop() || "audio";
            let ext = path.extname(fileName).toLowerCase();
            if (!ext) fileName += ".mp3"; // fallback if no extension

            await EliteProTech.sendMessage(
              m.chat,
              {
                audio: { url: q },
                mimetype: "audio/mpeg", // always treat link as audio
                fileName: fileName,
                ptt: false, // set true to send as voice note
              },
              { quoted: m },
            );
          } catch (e) {
            reply(`❌ Error sending audio:\n${e.message}`);
          }
        }
        break;
      case "shazam": {
        try {
          let audioUrl = q;
          if (!audioUrl && m.quoted) {
            const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
            const mime = quotedMsg?.mimetype || "";
            if (/audio|video/.test(mime)) {
              const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
                m.quoted,
              );
              try {
                audioUrl = await uploadToEliteTempUrl(mediaPath);
              } finally {
                if (fs.existsSync(mediaPath)) {
                  fs.unlinkSync(mediaPath);
                }
              }
            } else {
              return reply(
                `❌ Please reply to an *audio or video* or provide a direct URL.\n\n*Example:*\n${prefix}shazam (reply to an audio or video)`,
              );
            }
          }
          if (!audioUrl) {
            return reply(
              `❌ Please reply to an *audio or video* or provide a direct URL.\n\n*Example:*\n${prefix}shazam (reply to an audio or video)`,
            );
          }
          const { data } = await axios.get(
            `https://eliteprotech-apis.zone.id/tools/shazam?url=${encodeURIComponent(audioUrl)}`,
          );
          if (!data?.success || !data?.data) {
            return reply("❌ Could not identify the song.");
          }
          const song = data.data;
          const caption = `🎵 *${song.title || "Unknown"}*
👤 *Artist:* ${song.artist || "Unknown"}
💿 *Album:* ${song.album || "Unknown"}
📅 *Release Date:* ${song.release_date || "Unknown"}
🏷️ *Label:* ${song.label || "Unknown"}
🎼 *Genre:* ${song.genres?.join(", ") || "Unknown"}
🎯 *Match:* ${song.score ?? "Unknown"}%

> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`;
          await EliteProTech.sendMessage(
            m.chat,
            {
              text: caption,
            },
            {
              quoted: m,
            },
          );
        } catch (err) {
          console.error("Shazam Error:", err);
          return reply(
            `❌ An error occurred while identifying the song.\n${err.message || err}`,
          );
        }
        break;
      }
      case "cloud":
      case "tourl": {
        try {
          if (!m.quoted)
            return reply("📎 Reply to an image, video, or document to upload.");

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "☁️", key: m.key },
          });

          const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
            m.quoted,
          );

          const stats = fs.statSync(mediaPath);
          const fileSizeInBytes = stats.size;
          const humanFileSize = (bytes) => {
            if (bytes < 1024) return bytes + " B";
            else if (bytes < 1024 * 1024)
              return (bytes / 1024).toFixed(2) + " KB";
            else return (bytes / (1024 * 1024)).toFixed(2) + " MB";
          };
          const size = humanFileSize(fileSizeInBytes);

          const fileUrl = await uploadToEliteProTechUrl(mediaPath);

          await sendInteractiveMessage(
            EliteProTech,
            m.chat,
            {
              text: `*Media Uploaded Successfully ✅*\n*Media Link:*\n\n${fileUrl}\n\n💾 *Size:* ${size}`,
              footer: "> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*",
              interactiveButtons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Open Link",
                    url: fileUrl,
                  }),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Copy Link",
                    copy_code: fileUrl,
                  }),
                },
              ],
            },
            { quoted: m },
          );

          fs.unlinkSync(mediaPath);
        } catch (err) {
          console.error("EliteProTech Cloud Upload Error:", err);
          reply("❌ Failed to upload file to EliteProTech Cloud.");
        }
        break;
      }
      case "tempurl": {
        try {
          if (!m.quoted)
            return reply(
              "📎 Reply to a file.",
            );

          const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
            m.quoted,
          );
          const tempUrl = await uploadToEliteTempUrl(mediaPath);

          reply(`🕒 *Temporary URL Created*\n📎 *URL:* ${tempUrl}`);
          fs.unlinkSync(mediaPath);
        } catch (err) {
          console.error("TempURL Error:", err);
          reply("❌ Failed to create temporary URL.");
        }
        break;
      }
      case "catbox":
      case "url": {
        try {
          if (!m.quoted)
            return reply(
              "📎 Reply to a file.",
            );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "📤", key: m.key },
          });

          const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
            m.quoted,
          );

          const stats = fs.statSync(mediaPath);
          const fileSizeBytes = stats.size;

          const formatSize = (bytes) => {
            if (bytes >= 1024 * 1024)
              return (bytes / (1024 * 1024)).toFixed(2) + " MB";
            else if (bytes >= 1024) return (bytes / 1024).toFixed(2) + " KB";
            else return bytes + " B";
          };

          const readableSize = formatSize(fileSizeBytes);

          const catboxUrl = await uploadToCatbox(mediaPath);

          await sendInteractiveMessage(
            EliteProTech,
            m.chat,
            {
              text: `🙀 *Media Uploaded Successfully*\n*Media Link:*\n${catboxUrl}\n\n📦 *File Size:* ${readableSize}`,
              interactiveButtons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Open Link",
                    url: catboxUrl,
                  }),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Copy Link",
                    copy_code: catboxUrl,
                  }),
                },
              ],
            },
            { quoted: m },
          );

          fs.unlinkSync(mediaPath);
        } catch (err) {
          console.error("Catbox Upload Error:", err);
          reply(
            `🙀 Catbox is currently offline. Kindly use \`${prefix}tourl\` instead.`,
          );
        }
        break;
      }
      case "imgbb": {
        try {
          if (!m.quoted)
            return reply("📎 Reply to an *image* to upload to ImgBB.");

          const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
            m.quoted,
          );

          const ext = path.extname(mediaPath) || ".jpg";
          const randomName = `img_${Math.random().toString(36).slice(2, 10)}${ext}`;

          const form = new FormData();
          form.append("image", fs.createReadStream(mediaPath), {
            filename: randomName,
          });

          reply("⏳ Uploading image to ImgBB...");

          const response = await axios.post(
            "https://api.imgbb.com/1/upload?key=bbc0c59714520ebcd0af58caf995bd08",
            form,
            { headers: form.getHeaders() },
          );

          const imgbbUrl = response.data.data.url;

          await sendInteractiveMessage(
            EliteProTech,
            m.chat,
            {
              text: `📤 *Image Uploaded Successfully!*\n\n🌍 *ImgBB Link:* ${imgbbUrl}`,
              interactiveButtons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Open Link",
                    url: imgbbUrl,
                  }),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Copy Link",
                    copy_code: imgbbUrl,
                  }),
                },
              ],
            },
            { quoted: m },
          );

          fs.unlinkSync(mediaPath);
        } catch (err) {
          console.error("ImgBB Upload Error:", err);
          reply("❌ Failed to upload file to ImgBB.");
        }
        break;
      }
      case "story": {
        if (!text)
          return reply(
            `*Example:* ${prefix + command} A lonely hacker discovers an AI hidden deep inside the internet.`,
          );
        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "📖", key: m.key },
          });
          const apiUrl = `https://eliteprotech-apis.zone.id/ai/story?text=${encodeURIComponent(text)}`;
          const response = await axios.get(apiUrl);
          if (!response.data || !response.data.success) {
            return reply("❌ Failed to generate story. Try again later.");
          }
          const story = response.data.story;
          const title = text.length > 50 ? text.substring(0, 50) + "..." : text;
          await EliteProTech.sendMessage(
            m.chat,
            {
              image: {
                url: "https://eliteprotech-url.zone.id/1772353737772kdu79f.jpg",
              },
              caption: `📚 *Story Generated Successfully!*

🖋 *Prompt:* ${title}

✨ *Story:*
${story}
> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
              mentions: [sender],
            },
            { quoted: m },
          );
        } catch (error) {
          console.error(error);
          reply(`❌ Error generating story.\n> ${error.message}`);
        }
        break;
      }
      // 📝 SAVE NOTE
      case "note": {
        if (!m.quoted)
          return reply("❌ Reply to a message to save it as a note!");
        const repliedText = m.quoted.text || m.quoted.caption || "";
        if (!repliedText)
          return reply("❌ No text found in the replied message!");
        const title = text.trim() ? text.trim() : null;

        try {
          const { data } = await axios.post(
            "https://notepad-cyan.vercel.app/",
            {
              userId: m.sender,
              action: "save",
              title,
              text: repliedText,
            },
          );

          reply(data.message || "✅ Note saved!");
        } catch (err) {
          console.error("Note Save Error:", err.message);
          reply("❌ Failed to save note.");
        }
        break;
      }

      // 📚 LIST NOTE(S)
      case "listnote": {
        try {
          const apiUrl = "https://notepad-cyan.vercel.app/";
          if (!text) {
            const { data } = await axios.post(apiUrl, {
              userId: m.sender,
              action: "get",
            });
            if (!data.all_notes || Object.keys(data.all_notes).length === 0)
              return reply("📭 You have no saved notes.");

            const msg = `🗒️ *Your Notes:*\n\n${Object.entries(data.all_notes)
              .map(([t, v]) => `• *${t}*: ${v.text}`)
              .join("\n\n")}`;
            reply(msg);
          } else {
            const { data } = await axios.post(apiUrl, {
              userId: m.sender,
              action: "get",
              title: text,
            });
            if (data.error) return reply(`❌ ${data.error}`);
            reply(`📘 *${data.title}:*\n${data.text}`);
          }
        } catch (err) {
          console.error("List Note Error:", err.message);
          reply("❌ Failed to fetch notes.");
        }
        break;
      }

      // ❌ DELETE NOTE
      case "deletenote": {
        if (!isCreator) return reply("❌ Only the bot owner can delete notes.");
        if (!text) return reply("❌ Provide the note title to delete.");

        try {
          const apiUrl = "https://notepad-cyan.vercel.app/";
          const { data } = await axios.post(apiUrl, {
            userId: m.sender,
            action: "get",
          });

          const notes = data.all_notes || {};
          if (!notes[text])
            return reply(`❌ No note found with title '${text}'`);

          delete notes[text];
          await axios.post(apiUrl, {
            userId: m.sender,
            action: "update",
            data: notes,
          });

          reply(`✅ Note '${text}' deleted.`);
        } catch (err) {
          console.error("Delete Note Error:", err.message);
          reply("❌ Failed to delete note.");
        }
        break;
      }
      case "musicgen":
      case "aisong":
      case "aimusic": {
        if (!text) {
          return reply(
            `🎵 Send a prompt!\n\nExample:\n${prefix + command} Lost in the noise, but I still hear my heartbeat — chasing dreams no one else can see.`,
          );
        }

        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "🎶", key: m.key },
          });

          await EliteProTech.sendMessage(
            m.chat,
            {
              text: "*🎧 Generating Ai Music . . . . .*",
            },
            { quoted: m },
          );

          const apiUrl = `https://eliteprotech-apis.zone.id/musicgen?prompt=${encodeURIComponent(text)}`;
          const { data } = await axios.get(apiUrl);

          if (
            !data?.results ||
            !Array.isArray(data.results) ||
            data.results.length === 0
          ) {
            return reply(
              "❌ Failed to generate music.",
            );
          }

          for (const track of data.results) {
            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: track.cover },
                caption:
                  track.caption || `*🎶 Music Generated*\nPrompt: ${text}`,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(
              m.chat,
              {
                audio: { url: track.audio },
                mimetype: "audio/mp4",
                fileName: track.fileName || "music.mp3",
                ptt: false,
              },
              { quoted: m },
            );
          }

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error("AI MusicGen Error:", error);
          reply(
            `❌ An error occurred while generating music.\n> ${error.message || "Please try again later."}`,
          );
        }
        break;
      }
      case "nsfw":
        {
          try {
            let apiURL;

            if (!text) {
              apiURL =
                "https://eliteprotech-apis.zone.id/download/nsfw?random=true";
            } else {
              apiURL = `https://eliteprotech-apis.zone.id/download/nsfw?s=${encodeURIComponent(text)}`;
            }

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🎥", key: m.key },
            });

            const res = await axios.get(apiURL);

            if (!res.data?.success || !Array.isArray(res.data.results)) {
              return reply("❌ Failed to fetch videos.");
            }

            // filter valid mp4 only
            const valid = res.data.results.filter(
              (v) => v.mp4 && v.mp4.endsWith(".mp4"),
            );
            if (valid.length === 0) {
              return reply(
                text
                  ? `❌ No video found for "${text}"`
                  : "❌ No random videos found.",
              );
            }

            // pick 1 or 2
            let selected =
              valid.length === 1
                ? [valid[0]]
                : valid.sort(() => Math.random() - 0.5).slice(0, 2);

            for (let i = 0; i < selected.length; i++) {
              let item = selected[i];

              let caption =
                `🎬 *${item.title}*\n` +
                `📁 Category: ${item.category || "Unknown"}\n` +
                `👁 Views: ${item.views_count}\n` +
                `🔁 Shares: ${item.share_count}`;

              await EliteProTech.sendMessage(
                m.chat,
                {
                  video: { url: item.mp4 },
                  mimetype: "video/mp4",
                  caption,
                },
                { quoted: m },
              );
            }
          } catch (err) {
            console.log("WATCHANIME ERROR:", err);
            reply("❌ Error fetching video.");
          }
        }
        break;
      case "session":
      case "paircode":
      case "linkdevice":
      case "pair": {
        if (m.isGroup) return;
        if (!text)
          return reply(
            `⚠️ Send a phone number!\n\nExample: ${prefix + command} 2347084893193`,
          );

        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          const apiUrl = `https://eliteprotech-apis.zone.id/tools/pair?number=${encodeURIComponent(text)}`;
          const response = await axios.get(apiUrl);

          if (response.data && response.data.code) {
            const code = response.data.code;

            await sendInteractiveMessage(
              EliteProTech,
              m.chat,
              {
                text: `✅ *Code Generated Successfully!*
╭━━━━━━━━
┃ 📞 *Number:* ${text}
┃ 🔢 *Code:* ${code}
╰━━━━━━━━
> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
                interactiveButtons: [
                  {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                      display_text: "Copy Code 📋",
                      copy_code: code,
                    }),
                  },
                ],
              },
              { quoted: m },
            );
          } else {
            reply(`❌ Failed to generate code for: ${text}`);
          }
        } catch (error) {
          console.error(error);
          reply(
            `❌ An error occurred while fetching the code.\n> ${error.message}`,
          );
        }
        break;
      }
      case "x":
      case "tw":
      case "twdl":
      case "xdown":
      case "twitter":
      case "xdl":
      case "twit":
        {
          if (!text)
            return reply(
              `⚠️ *Send X/Twitter link*\n\nExample:\n${prefix + command} https://x.com/...`,
            );

          let url = text.trim();

          if (!/https?:\/\/(x|twitter)\.com\//i.test(url)) {
            return reply(`❌ Invalid URL\nPlease send a valid X/Twitter link.`);
          }

          try {
            const axios = require("axios");
            const api = `https://eliteprotech-apis.zone.id/download/x?url=${url}`;

            const { data } = await axios.get(api);

            if (data.status !== "success")
              return reply(`❌ Failed to fetch media.`);

            // Thumbnail
            let thumb = data.thumbnail;

            // MP3 audio
            const mp3 = data.mp3?.url;

            // Videos array (we will pick ONLY the first one)
            const videos = data.videos;
            const video = videos?.[0]; // pick highest quality (index 0)

            // --- SEND THUMBNAIL FIRST ---
            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: thumb },
                caption: `✨ *X / Twitter Downloader*\nSending your media...`,
              },
              { quoted: m },
            );

            // --- SEND VIDEO FIRST ---
            if (video) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  video: { url: video.url },
                  caption: `*🎥 twitter video downloader*`,
                },
                { quoted: m },
              );
            }

            // --- SEND AUDIO AFTER VIDEO ---
            if (mp3) {
              await EliteProTech.sendMessage(
                m.chat,
                {
                  audio: { url: mp3 },
                  mimetype: "audio/mpeg",
                  fileName: "twitter_audio.mp3",
                },
                { quoted: m },
              );
            }
          } catch (e) {
            console.log(e);
            reply(`❌ Error fetching media.`);
          }
        }
        break;
      case "apkdl":
      case "apksearch":
      case "apk":
        {
          if (!text)
            return reply(
              `📦 Enter app name!\n\nExample: ${prefix + command} gemini`,
            );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          try {
            const { data } = await axios.get(
              `https://eliteprotech-apis.zone.id/download/apk?q=${encodeURIComponent(text)}`,
            );

            if (
              !data?.status ||
              !Array.isArray(data.results) ||
              !data.results.length
            ) {
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "❌", key: m.key },
              });
              return reply("❌ No APK found.");
            }

            const app = data.results[0];
            const apkUrl = app.file?.path || app.file?.path_alt;

            if (!apkUrl) {
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "❌", key: m.key },
              });
              return reply("❌ Download link not found.");
            }

            const sizeMB = app.file?.filesize
              ? (app.file.filesize / 1024 / 1024).toFixed(2) + " MB"
              : app.size
                ? (app.size / 1024 / 1024).toFixed(2) + " MB"
                : "Unknown";

            const caption = `📦 *APK Downloader*

📱 *Name:* ${app.name}
📦 *Package:* ${app.package || "N/A"}
👨‍💻 *Developer:* ${app.developer?.name || "Unknown"}
📁 *Size:* ${sizeMB}
⭐ *Rating:* ${app.stats?.rating?.avg || "N/A"}

> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                document: { url: apkUrl },
                mimetype: "application/vnd.android.package-archive",
                fileName: `${app.name || "app"}.apk`,
                caption,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.log("APK error:", err.message);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            reply("❌ Error downloading APK.");
          }
        }
        break;
      case "poll": {
        try {
          if (!q)
            return reply(
              `*Usage:* ${prefix}poll PollName;Option1;Option2;Option3`,
            );

          const data = q.trim();
          const parts = data.split(";").map((x) => x.trim());

          const pollName = parts.shift();
          if (!pollName || parts.length < 2) {
            return reply("❌ Need a poll name and at least 2 options!");
          }

          const pollMessage = {
            poll: {
              name: pollName,
              values: parts,
              selectableCount: 1,
            },
          };

          await EliteProTech.sendMessage(m.chat, pollMessage, { quoted: m });
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "🗳️", key: m.key },
          });
        } catch (err) {
          console.error("Poll command error:", err);
          reply("❌ Failed to create poll.");
        }
        break;
      }
      case "panel": {
        const coinMenu = `🪙 *EliteProTech Bot Hosting — Coin Purchase Menu* 
🌐 *eliteprotech-host.zone.id*

Purchase hosting coins at *affordable prices*.  
*Require 30 coins to deploy*

---
💳 *Coin Pricing List*  
🪙 *1 Coin* — ₦100  
🪙 *5 Coins* — ₦500  
🪙 *10 Coins* — ₦1,000  
🪙 *30 Coins* ⭐ *Best Value* — ₦3,000

---
ℹ️ *Important Info*
- 30 coins = deploy your bot
- Hosting lasts 30 days if not deleted
- Service pauses when coins reach *0*`;
        await sendInteractiveMessage(
          EliteProTech,
          m.chat,
          {
            text: coinMenu,
            footer: "💳 Purchase coins now",
            interactiveButtons: [
              {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                  display_text: "Open Link",
                  url: "https://wa.me/message/HIA4EOURLFE4K1",
                }),
              },
              {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                  display_text: "Copy Link",
                  copy_code: "https://wa.me/message/HIA4EOURLFE4K1",
                }),
              },
              {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                  display_text: "💳 Bot Site",
                  id: `${global.prefix}bot`,
                }),
              },
            ],
          },
          { quoted: m },
        );

        break;
      }
      case "bot":
      case "freebot":
        {
          const userName = pushname || "there";

          const msg = `👋 Hello *${userName},*

You can deploy your bot on any of the hosting sites below:

*MiniBot - Free*
https://eliteprotech.zone.id/minibot

*AdvanceBot - Paid*
https://eliteprotech-host.zone.id`;

          reply(msg);
        }
        break;
      case "setprefix":
      case "prefix":
        {
          if (!isCreator) return reply(mess.owner);

          if (!text) {
            return reply(
              `ℹ️ ${prefix}${command} <any prefix>\n` +
                `digit · emoji · symbol · word\n` +
                `${prefix}${command} none → no prefix`,
            );
          }

          const newPrefix = text.replace(/[\r\n\t]/g, " ").trim();

          if (["none", "off", "clear", "reset"].includes(newPrefix.toLowerCase())) {
            global.prefix = "";
            saveSettings();
            return reply("✅ Prefix off · commands run bare");
          }

          if (newPrefix.length > 24) {
            return reply("❌ Prefix too long (max 24)");
          }

          global.prefix = newPrefix;
          saveSettings();

          return reply(`✅ Prefix · ${newPrefix}`);
        }
        break;
      case "copy":
        {
          try {
            if (!m.quoted) {
              return reply("📋 Reply to a message to copy its text");
            }

            let copiedText = "";

            // ✅ Safely extract text from quoted message
            if (m.quoted.text) {
              copiedText = m.quoted.text;
            } else if (m.quoted.caption) {
              copiedText = m.quoted.caption;
            } else if (m.quoted.message?.conversation) {
              copiedText = m.quoted.message.conversation;
            } else if (m.quoted.message?.extendedTextMessage?.text) {
              copiedText = m.quoted.message.extendedTextMessage.text;
            }

            if (!copiedText) {
              return reply("❌ No text found in the replied message");
            }

            const preview =
              copiedText.length > 60
                ? copiedText.slice(0, 60) + "..."
                : copiedText;

            await sendInteractiveMessage(
              EliteProTech,
              m.chat,
              {
                text: `✅ *Text Copied to Clipboard*\n\n📝 *Preview:* ${preview}`,
                footer: "Choose an action",
                interactiveButtons: [
                  {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                      display_text: "📋 Copy Full Text",
                      copy_code: copiedText,
                    }),
                  },
                ],
              },
              { quoted: m },
            );
          } catch (err) {
            console.error("Copy Error:", err);
            reply("❌ Failed to copy message text");
          }
        }
        break;
      case "bet":
        {
          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "⚽", key: m.key },
            });

            const apiUrl = "https://apiskeith.top/bet";
            const { data } = await axios.get(apiUrl);

            if (!data.status || !data.result || data.result.length === 0) {
              return reply("❌ No betting predictions available right now.");
            }

            let betText = `⚽ *FOOTBALL BET PREDICTIONS*\n\n`;

            for (let i = 0; i < data.result.length; i++) {
              const mth = data.result[i];

              betText += `━━━━━━━━━━━━━━━━━━
🏟 *Match:* ${mth.match}
🏆 *League:* ${mth.league}
⏰ *Time:* ${mth.time}

📊 *Full Time Odds*
• Home: ${mth.predictions.fulltime.home}%
• Draw: ${mth.predictions.fulltime.draw}%
• Away: ${mth.predictions.fulltime.away}%

⚽ *Over 2.5 Goals*
• Yes: ${mth.predictions.over_2_5.yes}%
• No: ${mth.predictions.over_2_5.no}%

🔥 *Both Teams To Score*
• Yes: ${mth.predictions.bothTeamToScore.yes}%
`;
            }

            betText += `> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`;

            await EliteProTech.sendMessage(
              m.chat,
              { text: betText },
              { quoted: m },
            );
          } catch (error) {
            console.error("Bet Error:", error);
            reply("❌ Failed to fetch betting predictions.");
          }
        }
        break;
      case "vocalremover": {
        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          let audioUrl = text;

          // If no URL, check quoted audio
          if (!audioUrl && m.quoted) {
            const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
            const mime = quotedMsg?.mimetype || "";

            if (/audio/.test(mime)) {
              const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
                m.quoted,
              );
              audioUrl = await uploadToEliteTempUrl(mediaPath);
              fs.unlinkSync(mediaPath);
            } else {
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "❌", key: m.key },
              });
              return reply(
                `❌ Please reply to an audio file or provide an audio URL.\n\nExample:\n${prefix}vocalremove https://example.com/song.mp3`,
              );
            }
          }

          if (!audioUrl) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply(
              `❌ Please reply to an audio file or provide an audio URL.\n\nExample:\n${prefix}vocalremove https://example.com/song.mp3`,
            );
          }

          const apiUrl =
            `https://eliteprotech-apis.zone.id/tools/vocalremove` +
            `?url=${encodeURIComponent(audioUrl)}`;

          const { data } = await axios.get(apiUrl);

          if (!data?.success || !data?.instrumental || !data?.vocal) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply("❌ Failed to remove vocals from audio.");
          }

          // Send Instrumental
          await EliteProTech.sendMessage(
            m.chat,
            {
              audio: { url: data.instrumental },
              mimetype: "audio/mpeg",
              caption: "🎵 Instrumental (No Vocals)",
            },
            { quoted: m },
          );

          // Send Vocal
          await EliteProTech.sendMessage(
            m.chat,
            {
              audio: { url: data.vocal },
              mimetype: "audio/mpeg",
              caption: "🎤 Vocals Only",
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error(error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply("❌ Error occurred while removing vocals.");
        }
        break;
      }
      case "colorize": {
        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          // Default sharp enhancement prompt
          let prompt = "enhanced colors";
          let imgUrl;

          // If user typed a prompt (e.g. "colorize sunny")
          if (text) {
            prompt = text.trim();
          }

          // If user replied to an image
          if (m.quoted) {
            const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
            const mime = quotedMsg?.mimetype || "";

            if (/image/.test(mime)) {
              const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
                m.quoted,
              );
              imgUrl = await uploadToEliteTempUrl(mediaPath);
              fs.unlinkSync(mediaPath);
            }
          }

          // If no quoted image, check if first arg is URL
          if (!imgUrl && text?.startsWith("http")) {
            imgUrl = text.trim();
            // reset prompt to default if text was actually a URL
            prompt =
              "highly detailed, sharp focus, enhanced colors, realistic lighting";
          }

          if (!imgUrl) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply(
              `❌ Please reply to an image or provide an image URL.\n\n` +
                `Example:\n` +
                `${prefix}colorize sunny\n` +
                `${prefix}colorize (reply to image)`,
            );
          }

          const apiUrl =
            `https://eliteprotech-apis.zone.id/image/colorize` +
            `?url=${encodeURIComponent(imgUrl)}` +
            `&prompt=${encodeURIComponent(prompt)}`;

          const { data } = await axios.get(apiUrl);

          if (!data?.success || !data?.result) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply("❌ Failed to colorize image.");
          }

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: data.result },
              caption:
                `✅ Image colorized!\n` + `🎨 Prompt: *${prompt}*`,
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error(error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply("❌ Error occurred while colorizing image.");
        }
        break;
      }
      case "deepfake": {
        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          let prompt = "Change my image";
          let imgUrl;

          if (text && !text.startsWith("http")) {
            prompt = text.trim();
          }

          if (m.quoted) {
            const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
            const mime = quotedMsg?.mimetype || "";

            if (/image/.test(mime)) {
              const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
                m.quoted,
              );
              imgUrl = await uploadToEliteTempUrl(mediaPath);
              fs.unlinkSync(mediaPath);
            }
          }

          if (!imgUrl && text?.startsWith("http")) {
            imgUrl = text.trim();
          }

          if (!imgUrl) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply(
              `❌ Please reply to an image or provide an image URL.\n\n` +
                `Example:\n` +
                `${prefix}deepfake Change my image\n` +
                `${prefix}deepfake (reply to image)`,
            );
          }

          const apiUrl =
            `https://eliteprotech-apis.zone.id/image/deepfake` +
            `?prompt=${encodeURIComponent(prompt)}` +
            `&imageUrl=${encodeURIComponent(imgUrl)}`;

          const { data } = await axios.get(apiUrl);

          if (!data?.success || !data?.result?.generate_url) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            return reply("❌ Deepfake generation failed.");
          }

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: data.result.generate_url },
              caption:
                `✅ Deepfake generated!\n` +
                `🎭 Prompt: *${prompt}*`,
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error(error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply("❌ Error occurred while generating deepfake image.");
        }
        break;
      }
      case "deletesession":
      case "delsession":
      case "clearsession":
        {
          if (!isCreator) return reply(mess.owner);
          fs.readdir("./session", async function (err, files) {
            if (err) {
              console.log("Unable to scan directory: " + err);
              return reply("Unable to scan directory: " + err);
            }
            let filteredArray = await files.filter(
              (item) =>
                item.startsWith("pre-key") ||
                item.startsWith("sender-key") ||
                item.startsWith("session-") ||
                item.startsWith("app-state"),
            );
            console.log(filteredArray.length);
            let teks = `Detected ${filteredArray.length} junk files\n\n`;
            if (filteredArray.length == 0) return reply(teks);
            filteredArray.map(function (e, i) {
              teks += i + 1 + `. ${e}\n`;
            });
            reply(teks);
            await sleep(2000);
            reply("Deleting junk files...");
            await filteredArray.forEach(function (file) {
              fs.unlinkSync(`./session/${file}`);
            });
            await sleep(2000);
            reply("Successfully deleted all the trash in the session folder");
          });
        }
        break;
      case "fdroid": {
        if (!text)
          return reply(
            `❌ Send a search query.\n\nExample:\n${prefix + command} chrome`,
          );

        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "🔍", key: m.key },
          });

          const apiUrl = `https://eliteprotech-apis.zone.id/download/fdriod?q=${encodeURIComponent(text)}`;
          const { data } = await axios.get(apiUrl);

          if (!data?.success || !data.result) {
            return reply(`❌ No results found for: ${text}`);
          }

          const app = data.result;

          const caption = `📱 *F-Droid App Info*

*Name:* ${app.name}
*Summary:* ${app.summary}
*Version:* ${app.version}
*Website:* ${app.website}
*Source:* ${app.source}

*Description:*
${app.description}

📦 *Sending APK...*`;
          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: app.icon },
              caption,
            },
            { quoted: m },
          );
          await EliteProTech.sendMessage(
            m.chat,
            {
              document: { url: app.apkUrl },
              mimetype: "application/vnd.android.package-archive",
              fileName: `${app.name.replace(/[^a-zA-Z0-9]/g, "_")}_${app.version}.apk`,
            },
            { quoted: m },
          );
        } catch (err) {
          console.error(err);
          reply("❌ Error fetching F-Droid app info.");
        }
        break;
      }
      case "stickerpack":
      case "sp":
        {
          if (!global.stickerPackQueue) {
            global.stickerPackQueue = new Map();
          }
          const args = (text || "").trim().split(/\s+/).filter(Boolean);
          const action = (args.shift() || "").toLowerCase();
          if (!action) {
            return reply(
              `Sticker Pack\n\n` +
                `${prefix + command} add\n` +
                `Reply to an image to add it\n\n` +
                `${prefix + command} create Pack Name|Description\n` +
                `Create the sticker pack\n\n` +
                `${prefix + command} count\n` +
                `Show collected stickers\n\n` +
                `${prefix + command} clear\n` +
                `Clear collected stickers`,
            );
          }
          if (action === "add") {
            if (!m.quoted) {
              return reply("❌ Reply to an image to add it.");
            }
            const mime = m.quoted.mimetype || m.quoted.msg?.mimetype || "";
            if (!mime.startsWith("image/")) {
              return reply("❌ You can only add images.");
            }
            try {
              const image = await m.quoted.download();
              if (!image || !Buffer.isBuffer(image)) {
                return reply("❌ Failed to download the image.");
              }
              const images = global.stickerPackQueue.get(m.chat) || [];
              if (images.length >= 60) {
                return reply("❌ Maximum of 60 stickers per pack.");
              }
              images.push(image);
              global.stickerPackQueue.set(m.chat, images);
              return reply(
                `✅ Image added\n\n🖼️ Stickers collected: ${images.length}`,
              );
            } catch (err) {
              return reply(`❌ Failed to add image.\n${err.message || err}`);
            }
          }
          if (action === "count") {
            const images = global.stickerPackQueue.get(m.chat) || [];
            return reply(
              images.length
                ? `📦 Sticker pack queue\n\n🖼️ Stickers: ${images.length}`
                : "📦 Sticker pack queue is empty.",
            );
          }
          if (action === "clear") {
            global.stickerPackQueue.delete(m.chat);
            return reply("✅ Sticker pack queue cleared.");
          }
          if (action === "create") {
            const images = global.stickerPackQueue.get(m.chat) || [];
            if (!images.length) {
              return reply(
                "❌ No stickers collected.\n\nReply to images with `.stickerpack add` first.",
              );
            }
            const packInfo = args.join(" ").trim();
            if (!packInfo.includes("|")) {
              return reply(
                `❌ Invalid format.\n\n` +
                  `Use:\n` +
                  `${prefix + command} create Pack Name|Description`,
              );
            }
            const [name, description] = packInfo
              .split("|")
              .map((v) => v.trim());
            if (!name || !description) {
              return reply(
                `❌ Pack name and description are required.\n\n` +
                  `Example:\n` +
                  `${prefix + command} create EliteProTech|My Sticker Pack`,
              );
            }
            await EliteProTech.sendMessage(m.chat, {
              react: {
                text: "⏳",
                key: m.key,
              },
            });
            try {
              await EliteProTech.sendStickerPack(
                m.chat,
                images,
                {
                  name,
                  publisher: "EliteProTech",
                  description,
                },
                {
                  quoted: m,
                },
              );
              global.stickerPackQueue.delete(m.chat);
              await EliteProTech.sendMessage(m.chat, {
                react: {
                  text: "✅",
                  key: m.key,
                },
              });
              return;
            } catch (err) {
              console.log("StickerPack error:", err);
              await EliteProTech.sendMessage(m.chat, {
                react: {
                  text: "❌",
                  key: m.key,
                },
              });
              return reply(
                `❌ Failed to create sticker pack.\n\n${err.message || err}`,
              );
            }
          }
          return reply(
            "❌ Unknown action.\n\nUse `add`, `create`, `count`, or `clear`.",
          );
        }
        break;
      case "zipsearch":
        {
          if (!m.quoted) return reply("Reply to the ZIP file.");
          const fs = require("fs");
          const path = require("path");
          const os = require("os");
          const { execFile } = require("child_process");
          const { promisify } = require("util");
          const execFileAsync = promisify(execFile);
          const query = (text || "").trim();
          if (!query) {
            return reply(
              `Usage:\n${prefix + command} <search term>\n\n` +
                `Example:\n${prefix + command} groupstatus`,
            );
          }
          const buffer = await EliteProTech.downloadMediaMessage(
            m.quoted,
            "buffer",
            {},
            {},
          );
          const zipPath = path.join(os.tmpdir(), `zipsearch-${Date.now()}.zip`);
          fs.writeFileSync(zipPath, buffer);
          try {
            const { stdout } = await execFileAsync("unzip", ["-Z1", zipPath], {
              maxBuffer: 50 * 1024 * 1024,
            });
            const files = stdout
              .split("\n")
              .map((x) => x.trim())
              .filter(Boolean)
              .filter((file) =>
                /\.(js|mjs|cjs|json|txt|ts|tsx|jsx|html|css|xml|yaml|yml)$/i.test(
                  file,
                ),
              );
            const results = [];
            const search = query.toLowerCase();
            for (const file of files) {
              try {
                const { stdout: content } = await execFileAsync(
                  "unzip",
                  ["-p", zipPath, file],
                  {
                    maxBuffer: 20 * 1024 * 1024,
                  },
                );
                const lines = content.split(/\r?\n/);
                for (let i = 0; i < lines.length; i++) {
                  if (lines[i].toLowerCase().includes(search)) {
                    results.push(
                      `📄 ${file}:${i + 1}\n` + `${lines[i].trim()}`,
                    );
                  }
                }
              } catch {}
            }
            if (!results.length) {
              return reply(`❌ No matches found for:\n\`${query}\``);
            }
            const output = results.join("\n\n");
            await m.reply(
              `🔎 ZIP SEARCH\n\n` +
                `Query: \`${query}\`\n` +
                `Matches: ${results.length}\n\n` +
                output.slice(0, 60000),
            );
          } catch (error) {
            await m.reply(`❌ ZIP search failed:\n\n${error.message || error}`);
          } finally {
            try {
              fs.unlinkSync(zipPath);
            } catch {}
          }
        }
        break;
      case "rename":
      case "ren":
        {
          if (!m.quoted) {
            return reply("❌ Reply to a document/file.");
          }
          const newName = (text || "").trim();
          if (!newName) {
            return reply(
              `❌ Provide a new filename.\n\n` +
                `Example:\n${prefix + command} EliteProTech.pdf`,
            );
          }
          if (newName.includes("/") || newName.includes("\\")) {
            return reply("❌ Invalid filename.");
          }
          try {
            const mime = m.quoted.mimetype || m.quoted.msg?.mimetype || "";
            if (!mime) {
              return reply("❌ The quoted message is not a supported file.");
            }
            const buffer = await m.quoted.download();
            if (!buffer) {
              return reply("❌ Failed to download the file.");
            }
            await EliteProTech.sendMessage(
              m.chat,
              {
                document: buffer,
                mimetype: mime,
                fileName: newName,
              },
              {
                quoted: m,
              },
            );
          } catch (err) {
            console.log("Rename error:", err);
            return reply(`❌ Failed to rename file.\n\n${err.message || err}`);
          }
        }
        break;
      case "togroupstatus":
      case "togstatus":
      case "swgc":
      case "gs":
      case "gstatus":
      case "groupstatus":
      case "gcstatus":
        {
          if (!isCreator) return reply(mess.owner);
          const colors = {
            red: "#FF0000",
            green: "#25D366",
            blue: "#3498DB",
            purple: "#6C5CE7",
            yellow: "#F1C40F",
            orange: "#E67E22",
            pink: "#FF69B4",
            cyan: "#00BCD4",
            black: "#000000",
            white: "#FFFFFF",
          };
          const colorValues = Object.values(colors);
          const args = (text || "").trim().split(/\s+/).filter(Boolean);
          let groupId = "";
          let backgroundColor =
            colorValues[Math.floor(Math.random() * colorValues.length)];
          let textColor = "#FFFFFF";
          let font = Math.floor(Math.random() * 5) + 1;
          let msgText = "";
          if (args[0]?.endsWith("@g.us")) {
            groupId = args.shift();
          } else if (m.isGroup) {
            groupId = m.chat;
          } else {
            return reply(
              `Usage:\n` +
                `.gcstatus [JID] message\n\n` +
                `Custom format:\n` +
                `.gcstatus [JID] -background-textcolor-font message\n\n` +
                `Examples:\n` +
                `.gcstatus 1203630xxxx@g.us Hello group\n` +
                `.gcstatus 1203630xxxx@g.us -red-white-3 Hello group\n` +
                `.gcstatus 1203630xxxx@g.us -white-black-2 Hello group\n` +
                `.gcstatus 1203630xxxx@g.us -#FF0000-#FFFFFF-3 Hello group`,
            );
          }
          if (args[0]?.startsWith("-")) {
            const format = args.shift();
            const parts = format.slice(1).split("-");
            if (parts.length !== 3) {
              return reply(
                `Invalid custom format.\n\n` +
                  `Use:\n` +
                  `.gcstatus -background-textcolor-font message\n\n` +
                  `Example:\n` +
                  `.gcstatus -red-white-3 Hello group`,
              );
            }
            const [bgArg, textArg, fontArg] = parts;
            if (/^#[0-9a-f]{6}$/i.test(bgArg)) {
              backgroundColor = bgArg;
            } else if (colors[bgArg.toLowerCase()]) {
              backgroundColor = colors[bgArg.toLowerCase()];
            } else {
              return reply(`Invalid background color: ${bgArg}`);
            }
            if (/^#[0-9a-f]{6}$/i.test(textArg)) {
              textColor = textArg;
            } else if (colors[textArg.toLowerCase()]) {
              textColor = colors[textArg.toLowerCase()];
            } else {
              return reply(`Invalid text color: ${textArg}`);
            }
            if (!/^[1-5]$/.test(fontArg)) {
              return reply("Invalid font. Choose a font from 1 to 5.");
            }
            font = Number(fontArg);
          }
          if (backgroundColor.toUpperCase() === "#FFFFFF") {
            textColor = "#000000";
          }
          msgText = args.join(" ").trim();
          if (!groupId || !groupId.endsWith("@g.us")) {
            return reply("Group JID not found or invalid.");
          }
          let targetGroupName = groupId;
          try {
            const meta = await EliteProTech.groupMetadata(groupId);
            targetGroupName = meta?.subject || groupId;
          } catch {}
          await EliteProTech.sendMessage(m.chat, {
            react: {
              text: "⏳",
              key: m.key,
            },
          });
          try {
            if (!m.quoted) {
              if (!msgText) {
                await EliteProTech.sendMessage(m.chat, {
                  react: {
                    text: "❌",
                    key: m.key,
                  },
                });
                return reply(
                  `Usage:\n` +
                    `Provide a text, image, video or audio, or reply to one.\n\n` +
                    `Custom format:\n` +
                    `.gcstatus -background-textcolor-font message\n\n` +
                    `Examples:\n` +
                    `.gcstatus Hello group\n` +
                    `.gcstatus -red-white-3 Hello group\n` +
                    `.gcstatus -white-black-2 Hello group\n` +
                    `.gcstatus -#FF0000-#FFFFFF-3 Hello group`,
                );
              }
              await EliteProTech.sendMessage(groupId, {
                groupStatusMessage: {
                  text: msgText,
                  backgroundColor,
                  textColor,
                  font,
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                react: {
                  text: "✅",
                  key: m.key,
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                text: `Group status text sent to ${targetGroupName}`,
              });
              return;
            }
            const quoted = m.quoted;
            const mime = quoted.mimetype || quoted.msg?.mimetype || "";
            const caption = msgText || quoted.caption || "";
            if (!mime) {
              const textMessage =
                quoted.text ||
                quoted.body ||
                quoted.message?.conversation ||
                quoted.msg?.text ||
                caption;
              if (!textMessage) {
                return reply("Quoted message contains no text.");
              }
              await EliteProTech.sendMessage(groupId, {
                groupStatusMessage: {
                  text: textMessage,
                  backgroundColor,
                  textColor,
                  font,
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                react: {
                  text: "✅",
                  key: m.key,
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                text: `Group status text sent to ${targetGroupName}`,
              });
              return;
            }
            if (/image/.test(mime)) {
              const buffer = await quoted.download();
              await EliteProTech.sendMessage(groupId, {
                groupStatusMessage: {
                  image: buffer,
                  caption,
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                react: {
                  text: "✅",
                  key: m.key,
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                text: `Group status image sent to ${targetGroupName}`,
              });
              return;
            }
            if (/video/.test(mime)) {
              const buffer = await quoted.download();
              await EliteProTech.sendMessage(groupId, {
                groupStatusMessage: {
                  video: buffer,
                  caption,
                  mimetype: "video/mp4",
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                react: {
                  text: "✅",
                  key: m.key,
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                text: `Group status video sent to ${targetGroupName}`,
              });
              return;
            }
            if (/audio/.test(mime)) {
              const buffer = await quoted.download();
              await EliteProTech.sendMessage(groupId, {
                groupStatusMessage: {
                  audio: buffer,
                  mimetype: mime || "audio/mp4",
                  ptt: true,
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                react: {
                  text: "✅",
                  key: m.key,
                },
              });
              await EliteProTech.sendMessage(m.chat, {
                text: `Group status audio sent to ${targetGroupName}`,
              });
              return;
            }
            await EliteProTech.sendMessage(m.chat, {
              react: {
                text: "❌",
                key: m.key,
              },
            });
            return reply(
              "Unsupported message type. Use text, image, video, or audio.",
            );
          } catch (err) {
            console.log("GroupStatus error:", err);
            await EliteProTech.sendMessage(m.chat, {
              react: {
                text: "❌",
                key: m.key,
              },
            });
            return reply(`Failed to send group status.\n${err.message || err}`);
          }
        }
        break;
      case "tempemail":
      case "tempmail":
        {
          try {
            const { data } = await axios.get(
              "https://eliteprotech-apis.zone.id/tools/tempemail",
            );

            if (!data?.success || !data.email) {
              return reply("❌ Failed to generate temporary email.");
            }

            reply(
              `
📩 *TEMP EMAIL CREATED*

📧 Email:
${data.email}

📥 Check inbox using:
.tempinbox ${data.email}

⚠️ This email is temporary.
        `.trim(),
            );
          } catch (err) {
            console.error(err);
            reply("❌ Error generating temp email.");
          }
        }
        break;
      case "tempinbox":
        {
          try {
            if (!text) {
              return reply(
                `⚠️ Provide the email address\n\nExample:\n.tempinbox test@gmail.com`,
              );
            }

            const { data } = await axios.get(
              `https://eliteprotech-apis.zone.id/tools/tempemail?email=${encodeURIComponent(text)}`,
            );

            if (!data?.success) {
              return reply("❌ Failed to fetch inbox.");
            }

            if (!data.inbox) {
              return reply("📭 Inbox is empty.");
            }

            const inbox = data.inbox;
            const message = inbox.html
              ? inbox.html.replace(/<[^>]*>/g, "").trim()
              : "No message content";

            reply(
              `
📥 *TEMP EMAIL INBOX*

📧 Email:
${data.email}

👤 From: ${inbox.from}
📝 Subject: ${inbox.subject}
⏰ Time: ${inbox.time}

📨 Message:
${message}
        `.trim(),
            );
          } catch (err) {
            console.error(err);
            reply("❌ Error fetching inbox.");
          }
        }
        break;
      case "listowner":
      case "modlist":
      case "sudos":
      case "sudolist":
      case "listsudo":
        {
          try {
            if (!isCreator) {
              return reply(mess.owner);
            }
            const userId =
              EliteProTech.user?.id?.split(":")[0] || "Not defined";
            const owners = owner;
            let msg = `*List of owners:*\n\n` + `*Default:*\n- ${userId}`;
            if (owners.length) {
              msg += `\n\n*Current:*\n${owners.map((o) => `- ${o}`).join("\n")}`;
            }
            reply(msg);
          } catch (err) {
            console.error(err);
            reply("❌ Failed to fetch owner numbers.");
          }
        }
        break;
      case "search":
      case "copilot":
        {
          if (!text)
            return reply(
              `Example:\n${prefix + command} who is the owner of EliteProTech`,
            );

          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🔍", key: m.key },
            });

            const apiUrl = `https://eliteprotech-apis.zone.id/ai/copilot?q=${encodeURIComponent(text)}`;
            const { data } = await axios.get(apiUrl);

            if (!data || !data.success) {
              return reply("❌ Search failed.");
            }

            let resultText = `🔎 *Search Results:*\n\n${data.text}\n`;

            if (data.citations && data.citations.length > 0) {
              resultText += `\n📚 *Sources:*\n`;
              data.citations.forEach((c, i) => {
                resultText += `${i + 1}. ${c.title}\n${c.url}\n\n`;
              });
            }

            resultText += `> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: resultText,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error("Search Error:", err);
            reply("❌ An error occurred while performing the search.");
          }
        }
        break;
      case "acceptjoin":
      case "approvejoin":
      case "approve":
        {
          if (!m.isGroup) return reply("❌ This command is for groups only.");
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply("❌ Admin only command.");
          if (!isBotAdmins) return reply("❌ I must be admin to do that.");

          try {
            let users = [];

            if (m.mentionedJid.length > 0) {
              users = m.mentionedJid;
            } else if (m.quoted?.sender) {
              users = [m.quoted.sender];
            } else if (args[0]) {
              users = [args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net"];
            } else {
              const requests = await EliteProTech.groupRequestParticipantsList(
                m.chat,
              );
              if (!requests || requests.length === 0) {
                return reply("✅ No pending join requests.");
              }
              users = requests.map((v) => v.jid);
            }

            await EliteProTech.groupRequestParticipantsUpdate(
              m.chat,
              users,
              "approve",
            );

            let approvedText = `✅ *Approved Member(s):*\n\n`;

            for (let jid of users) {
              const number = jid.split("@")[0];
              approvedText += `• @${number}\n`;
            }

            approvedText += `\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: approvedText,
                mentions: users,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error("Approve Error:", err);
            reply("❌ Failed to approve group request(s).");
          }
        }
        break;
      case "rejectjoin":
      case "declinejoin":
      case "decline":
      case "reject":
        {
          if (!m.isGroup) return reply("❌ This command is for groups only.");
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply("❌ Admin only command.");
          if (!isBotAdmins) return reply("❌ I must be admin to do that.");

          try {
            let users = [];

            if (m.mentionedJid.length > 0) {
              users = m.mentionedJid;
            } else if (m.quoted?.sender) {
              users = [m.quoted.sender];
            } else if (args[0]) {
              users = [args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net"];
            } else {
              const requests = await EliteProTech.groupRequestParticipantsList(
                m.chat,
              );
              if (!requests || requests.length === 0) {
                return reply("✅ No pending join requests.");
              }
              users = requests.map((v) => v.jid);
            }

            await EliteProTech.groupRequestParticipantsUpdate(
              m.chat,
              users,
              "reject",
            );

            let rejectText = `❌ *Rejected Member(s):*\n\n`;

            for (let jid of users) {
              const number = jid.split("@")[0];
              rejectText += `• @${number}\n`;
            }

            rejectText += `\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: rejectText,
                mentions: users,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error("Reject Error:", err);
            reply("❌ Failed to reject group request(s).");
          }
        }
        break;
      case "groupjid":
      case "group-jid":
      case "groupid":
      case "group-id":
        {
          if (!text) return reply("Send the group invite link.");

          if (!text.includes("chat.whatsapp.com/")) {
            return reply("Invalid group invite link.");
          }

          const match = text.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
          if (!match) return reply("Invalid group invite link.");

          const inviteCode = match[1];

          try {
            const res = await EliteProTech.groupGetInviteInfo(inviteCode);

            const msgText = `👥 *Whatsapp Group Info:*
📝 *Group Name:*
${res.subject}

📌 *Invite Code:*
${inviteCode}

🆔 *Group ID:*
${res.id}

🔗 *Link:*
${text}`;

            await sendInteractiveMessage(
              EliteProTech,
              m.chat,
              {
                text: msgText,
                footer: "> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*",
                interactiveButtons: [
                  {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                      display_text: "Copy Group ID 📋",
                      copy_code: res.id,
                    }),
                  },
                ],
              },
              { quoted: m },
            );
          } catch (err) {
            console.error(err);
            reply(
              "❌ Bad invite link.",
            );
          }
        }
        break;
      case "imagine":
        {
          if (!q)
            return reply(
              `⚠️ Example: *${prefix + command} a man walking on the moon*`,
            );

          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🎨", key: m.key },
            });

            const { data } = await axios.get(
              `https://eliteprotech-apis.zone.id/ai/imagine?prompt=${encodeURIComponent(q)}`,
              { responseType: "arraybuffer" },
            );

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: data,
                caption: `*Image Generated Successfully ✅*`,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.error("Imagine Error:", err);
            reply("❌ Failed to generate image.");
          }
        }
        break;
      case "analyze":
        {
          try {
            if (!m.quoted || !/image/.test(mime)) {
              return reply(
                `⚠️ Reply to an image.\n\nExample:\nReply image → ${prefix + command} what's this about`,
              );
            }

            if (!q) {
              return reply(
                `⚠️ Provide a question.\nExample:\n${prefix + command} what's this about`,
              );
            }

            const buffer = await quoted.download();
            const tempPath = `./temp_${Date.now()}.jpg`;

            fs.writeFileSync(tempPath, buffer);

            const imageUrl = await uploadToEliteTempUrl(tempPath);

            fs.unlinkSync(tempPath);

            const apiUrl = `https://eliteprotech-apis.zone.id/ai/analyze?url=${encodeURIComponent(imageUrl)}&question=${encodeURIComponent(q)}`;
            const { data } = await axios.get(apiUrl);

            if (!data.status) {
              return reply("❌ Failed to analyze image.");
            }

            const resultText = `🧠 *Image Analysis*

📌 *Question:* ${data.question}
🌍 *Language:* ${data.language}

${data.result}`;

            reply(resultText);
          } catch (err) {
            console.error("Analyze Error:", err);
            reply("❌ Failed to analyze image.");
          }
        }
        break;
      case "fakech":
      case "fakechannel":
        {
          if (!text)
            return reply(`Usage Example:

${prefix + command} Pixel | 35K | Welcome To My Channel | 06/04/20`);

          let parts = text.split("|").map((v) => v.trim());

          let name = parts[0];
          let followers = parts[1];
          let desc = parts[2];
          let date = parts[3];

          if (!name || !followers || !desc || !date) {
            return reply(`Wrong format!

Example:
${prefix + command} Pixel | 35K | Welcome To My Channel | 06/04/20`);
          }

          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "📢", key: m.key },
            });

            let avatar;

            if (quoted && /image/.test(mime)) {
              let media = await quoted.download();
              let upload = await uploadToEliteTempUrl(media);
              avatar = upload.url;
            } else {
              avatar = await EliteProTech.profilePictureUrl(
                m.sender,
                "image",
              ).catch(() => "https://files.catbox.moe/5x0h7n.jpg");
            }

            let api = `https://api.zenzxz.my.id/maker/fakechannel?url=${encodeURIComponent(avatar)}&name=${encodeURIComponent(name)}&followers=${encodeURIComponent(followers)}&desc=${encodeURIComponent(desc)}&date=${encodeURIComponent(date)}`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: api },
                caption: `📢 *Fake Channel Generated*

👤 Name : ${name}
👥 Followers : ${followers}
📅 Date : ${date}
📝 Description : ${desc}
> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.log(err);
            reply("❌ Error creating fake channel image.");
          }
        }
        break;
      case "fakedana":
      case "dana":
      case "fdana":
        {
          try {
            if (!text)
              return reply(`⚠️ Usage Example :

${prefix + command} 5.000`);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "💳", key: m.key },
            });

            let nominal = text.trim();

            let api = `https://api.zenzxz.my.id/maker/fakedanav2?nominal=${encodeURIComponent(nominal)}`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: api },
                caption: `💳 *Fake Dana Generated*
💰 Nominal : ${nominal}
> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ©*`,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.log("FakeDana Error:", err);

            reply(`❌ Failed to create Fake Dana image.`);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
          }
        }
        break;
      case "country":
      case "countries":
        {
          if (!q) return reply(`⚠️ Example: *${prefix + command} nigeria*`);

          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🌍", key: m.key },
            });

            const { data } = await axios.get(
              `https://eliteprotech-apis.zone.id/search/countries?q=${encodeURIComponent(q)}`,
            );

            if (!data.status || !data.result) {
              return reply(
                "❌ Country not found. Please check the name and try again.",
              );
            }

            const country = data.result;
            const currencies = country.currencies
              .map((c) => `${c.name} (${c.symbol})`)
              .join(", ");
            const languages = country.languages.join(", ");

            const caption = `
*Country:* ${country.name}
*Official Name:* ${country.officialName}
*Capital:* ${country.capital}
*Region:* ${country.region} - ${country.subregion}
*Population:* ${country.population.toLocaleString()}
*Area:* ${country.area}
*Currencies:* ${currencies}
*Languages:* ${languages}
        `;

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: country.flag.image },
                caption: caption,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.error("Country Command Error:", err);
            reply("❌ Failed to fetch country information.");
          }
        }
        break;
      case "edit":
        {
          if (!isCreator) return reply(mess.owner);

          if (!m.quoted) return reply("Reply to a bot message");

          if (!q) return reply("Send a message you want to edit to.");

          let key = m.quoted;

          await EliteProTech.sendMessage(m.chat, {
            edit: key,
            text: q,
          });
        }
        break;
      case "blocklist":
        {
          if (!isCreator) return reply(mess.owner);

          let block = await EliteProTech.fetchBlocklist();

          if (!block || block.length === 0) {
            return reply("No users are blocked.");
          }

          let teks = `*📛 Blocked Users List*\n\nTotal: ${block.length}\n\n`;

          for (let i of block) {
            teks += `• @${i.split("@")[0]}\n`;
          }

          EliteProTech.sendMessage(
            m.chat,
            {
              text: teks,
              mentions: block,
            },
            { quoted: m },
          );
        }
        break;
      case "tgpack":
      case "tgs":
      case "tgms":
      case "tgsticker":
      case "telegramsticker":
        {
          if (!q)
            return reply(
              `⚠️ Example:\n${prefix + command} https://t.me/addstickers/packname`,
            );

          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "📦", key: m.key },
            });

            let link = q.includes("t.me") ? q : `https://t.me/addstickers/${q}`;

            const api = `https://apis.davidcyril.name.ng/telegram-sticker?url=${encodeURIComponent(link)}`;
            const { data } = await axios.get(api);

            if (!data.status)
              return reply("❌ Cannot view sticker information.");

            const pack = data.result;
            const stickers = pack.sticker;

            let text = `*📦 TELEGRAM STICKER PACK*
📛 Name: ${pack.name}
🏷 Title: ${pack.title}
🎭 Type: ${pack.sticker_type}
🧩 Total Stickers: ${stickers.length}
━━━━━━━━━━━━━━━━⬣
⏳ Sending stickers...
> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ`;

            await EliteProTech.sendMessage(m.chat, { text }, { quoted: m });

            let sent = 0;

            for (let s of stickers) {
              if (sent >= 20) break;
              if (!s.url.endsWith(".webp")) continue;

              try {
                await EliteProTech.sendImageAsSticker(m.chat, s.url, m, {
                  packname: global.packname,
                  author: global.author,
                });

                sent++;
              } catch (e) {
                console.log("Sticker error:", e);
              }
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: `*✅ STICKERS SENT*
📦 Pack: ${pack.title}
📤 Sent: ${sent} stickers
> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ`,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.error("tgpack error:", err);
            reply("❌ Failed to download sticker pack.");
          }
        }
        break;
      case "settings":
        {
          if (!isCreator) return reply(mess.owner);
          let txt = `⚙️ *PIXEL BOT SETTINGS*\n`;
          txt += `📊 Auto Status View : ${autoviewstatus ? "✅ ON" : "❌ OFF"}\n`;
          txt += `💚 Auto Status Like : ${autolikestatus ? `✅ ON (${global.autolikestatusEmoji || "💚"})` : "❌ OFF"}\n`;
          txt += `👀💚 Auto View Like : ${autoviewstatus && autolikestatus ? "✅ ON" : "❌ OFF"}\n`;
          txt += `📖 Auto Read        : ${autoread ? "✅ ON" : "❌ OFF"}\n`;
          txt += `⌨️ Auto Typing      : ${autoTyping ? "✅ ON" : "❌ OFF"}\n`;
          txt += `🎙️ Auto Recording   : ${autoRecording ? "✅ ON" : "❌ OFF"}\n`;
          txt += `🎧 Auto RecordType  : ${autorecordtype ? "✅ ON" : "❌ OFF"}\n`;
          txt += `📝 Auto Bio         : ${autobio ? "✅ ON" : "❌ OFF"}\n`;
          txt += `✨ Auto React       : ${autoreact ? "✅ ON" : "❌ OFF"}\n`;
          txt += `🤖 Bot Mode         : ${EliteProTech.public ? "PUBLIC" : "PRIVATE"}\n`;
          txt += `🔤 Prefix           : ${prefix || "None"}\n\n`;
          txt += `📌 *Available Commands*\n`;
          txt += `${prefix}autoviewstatus on/off\n`;
          txt += `${prefix}autolikestatus on [emoji]\n`;
          txt += `${prefix}autolikestatus default\n`;
          txt += `${prefix}setlikestatus [emoji]\n`;
          txt += `${prefix}autoviewlike on/off [emoji]\n`;
          txt += `${prefix}autoread on/off\n`;
          txt += `${prefix}autotyping on/off\n`;
          txt += `${prefix}autorecording on/off\n`;
          txt += `${prefix}autorecordtype on/off\n`;
          txt += `${prefix}autobio on/off\n`;
          txt += `${prefix}autoreact on/off\n`;
          txt += `${prefix}mode public/private\n`;
          txt += `${prefix}setprefix <prefix/none>\n`;
          txt += `${prefix}groupsettings\n`;
          txt += `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ`;

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: elitepropic,
              caption: txt,
            },
            { quoted: m },
          );
        }
        break;
      case "profile":
        {
          let target = m.sender;
          const defaultPP =
            "https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png";

          if (m.quoted && m.quoted.sender) {
            target = m.quoted.sender;
          } else if (m.mentionedJid && m.mentionedJid.length > 0) {
            target = m.mentionedJid[0];
          } else if (text) {
            let number = text.replace(/[^0-9]/g, "");
            if (!number) return reply("Provide a valid number.");
            target = number + "@s.whatsapp.net";
          }

          let pp;
          try {
            pp = await EliteProTech.profilePictureUrl(target, "image");
          } catch {
            pp = defaultPP;
          }

          let about = "No status";
          let setAt = "";

          try {
            const statusData = await EliteProTech.fetchStatus(target);
            if (statusData && statusData[0] && statusData[0].status) {
              about = statusData[0].status.status || "No status";
              setAt = statusData[0].status.setAt
                ? `\n• Last Updated: ${new Date(statusData[0].status.setAt).toLocaleString()}`
                : "";
            }
          } catch {}

          let businessText = "";

          try {
            const biz = await EliteProTech.getBusinessProfile(target);
            if (biz) {
              let hours = "";
              if (biz.business_hours?.business_config) {
                hours = biz.business_hours.business_config
                  .map(
                    (d) =>
                      `• ${d.day_of_week.charAt(0).toUpperCase() + d.day_of_week.slice(1)}: ${d.mode.replace("_", " ")}`,
                  )
                  .join("\n");
              }

              businessText = `

*Business Profile*
• WhatsApp ID: ${biz.wid || "N/A"}
• Category: ${biz.category || "N/A"}
• Description: ${biz.description || "N/A"}
• Website: ${biz.website?.join(", ") || "N/A"}
• Email: ${biz.email || "N/A"}
• Address: ${biz.address || "N/A"}
• Timezone: ${biz.business_hours?.timezone || "N/A"}
• Business Hours:
${hours}`;
            }
          } catch {}

          const caption = `*User Profile*
• Number: @${target.split("@")[0]}
• About: ${about}${setAt}
${businessText}`;

          await EliteProTech.sendMessage(
            m.chat,
            {
              image: { url: pp },
              caption: caption,
              mentions: [target],
            },
            { quoted: m },
          );
        }
        break;
      case "antistatus":
        {
          if (!m.isGroup) return reply("❌ Group only command");
          if (!isAdmins && !isCreator) return reply(mess.admin);

          let data = {};
          try {
            data = JSON.parse(fs.readFileSync("./database/antistatus.json"));
          } catch {}

          if (!data[m.chat])
            data[m.chat] = {
              enabled: false,
              mode: "warn",
              limit: 3,
              users: {},
            };

          const settings = data[m.chat];

          if (!args[0]) {
            if (!settings.enabled) {
              return reply(`⚙️ AntiStatus Settings

Status: ❌ Disabled

Use:
${prefix + command} enable`);
            }

            return reply(`⚙️ AntiStatus Settings

Status: ✅ Enabled
Mode: ${settings.mode}
Limit: ${settings.limit}

Options:
${prefix + command} delete
${prefix + command} warn
${prefix + command} warnkick
${prefix + command} kick
${prefix + command} 3

Disable:
${prefix + command} disable`);
          }

          if (args[0] === "enable") {
            settings.enabled = true;
            settings.mode = "warn";
            settings.limit = 3;
            reply(
              `✅ AntiStatus has been enabled for this chat.\nFor settings use: ${prefix}antistatus`,
            );
          } else if (args[0] === "disable") {
            settings.enabled = false;
            reply("❌ AntiStatus has been disabled.");
          } else if (!settings.enabled) {
            return reply(
              `❌ AntiStatus is disabled.\nUse ${prefix + command} enable first.`,
            );
          } else if (args[0] === "delete") {
            settings.mode = "delete";
            reply("🗑️ Action set to delete only.");
          } else if (args[0] === "warn") {
            settings.mode = "warn";
            reply("⚠️ Action set to warn system.");
          } else if (args[0] === "warnkick") {
            settings.mode = "warnkick";
            reply("🚫 Action set to warn then kick.");
          } else if (args[0] === "kick") {
            settings.mode = "kick";
            reply("🚫 Action set to instant kick.");
          } else if (!isNaN(args[0])) {
            settings.limit = parseInt(args[0]);
            reply(`🔢 Warn limit set to ${args[0]}`);
          } else {
            reply("❌ Bad option");
          }

          fs.writeFileSync(
            "./database/antistatus.json",
            JSON.stringify(data, null, 2),
          );
        }
        break;
      case "av":
      case "aivoice":
        {
          try {
            let query = q || "";
            if (m.quoted && m.quoted.text) {
              query = query ? query + " " + m.quoted.text : m.quoted.text;
            }
            if (!query)
              return reply(`Example: .aivoice Hello or reply to a message`);
            await EliteProTech.sendPresenceUpdate("recording", m.chat);
            const aiRes = await axios.get(
              `https://api.bk9.dev/ai/copilot?q=${encodeURIComponent(query)}`,
            );
            if (!aiRes.data?.status || !aiRes.data?.BK9?.response) {
              return reply("❌ Failed to generate AI response.");
            }
            let text = aiRes.data.BK9.response.slice(0, 1000);
            text = text
              .replace(/```[\s\S]*?```/g, "")
              .replace(/^\s*#{1,6}\s*/gm, "")
              .replace(/^\s*\/\/\s?/gm, "")
              .replace(/\*\*(.*?)\*\*/g, "$1")
              .replace(/\*(.*?)\*/g, "$1")
              .replace(/__(.*?)__/g, "$1")
              .replace(/_(.*?)_/g, "$1")
              .replace(/`([^`]+)`/g, "$1")
              .replace(/\n{3,}/g, "\n\n")
              .trim();
            if (!text) return reply("❌ No readable text was generated.");
            const voiceRes = await axios.get(
              `https://ab-text-voice.abrahamdw882.workers.dev/?q=${encodeURIComponent(text)}&voicename=jane`,
            );
            if (!voiceRes.data?.url)
              return reply("❌ Failed to generate voice.");
            const res = await axios.get(voiceRes.data.url, {
              responseType: "arraybuffer",
            });
            const voice = await toPTT(Buffer.from(res.data), "mp3");
            await EliteProTech.sendMessage(
              m.chat,
              {
                audio: voice,
                mimetype: "audio/ogg; codecs=opus",
                ptt: true,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error("AIVoice Error:", err);
            reply("❌ Error occurred while generating aivoice.");
          }
        }
        break;
      case "knackvideo":
        {
          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🎬", key: m.key },
            });

            const apiUrl = `https://apis.davidcyril.name.ng/knackvideos`;
            const { data } = await axios.get(apiUrl);

            if (!data || !data.downloadUrl) {
              return reply("❌ Failed to fetch video.");
            }

            const caption = `🎥 *Random knacking Video*`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                video: { url: data.downloadUrl },
                mimetype: "video/mp4",
                caption,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.error("Video Error:", err);
            reply("❌ Error fetching video.");
          }
        }
        break;
      /* ── Ported from ASTRO X ULTRA (owner + admin) ───────────────────────── */
      case "join":
        {
          if (!isCreator) return reply(mess.owner);
          const hit = String(q || "").trim().match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/);
          if (!hit) return reply(`ℹ️ ${prefix}join <invite-link>`);
          try {
            const gid = await EliteProTech.groupAcceptInvite(hit[1]);
            reply(`✅ Joined · ${String(gid).split("@")[0]}`);
          } catch (e) {
            reply("❌ Invalid or expired link");
          }
        }
        break;
      case "broadcast":
      case "bc":
        {
          if (!isCreator) return reply(mess.owner);
          if (!q) return reply(`ℹ️ ${prefix}broadcast <message>`);
          let sent = 0;
          let failed = 0;
          try {
            const all = await EliteProTech.groupFetchAllParticipating();
            for (const id of Object.keys(all || {})) {
              try {
                await EliteProTech.sendMessage(id, { text: q });
                sent++;
              } catch {
                failed++;
              }
            }
            reply(`✅ ${sent} sent · ${failed} failed`);
          } catch (e) {
            reply("❌ Broadcast failed");
          }
        }
        break;
      case "staff":
      case "admins":
      case "adminlist":
        {
          if (!m.isGroup) return reply(mess.group);
          try {
            const meta = groupMetadata || (await EliteProTech.groupMetadata(m.chat));
            const admins = (meta.participants || []).filter((pp) => pp.admin);
            const lines = admins.map((ad, i) => `${i + 1}. @${String(ad.id).split("@")[0]}`);
            const owner = meta.owner || (admins.find((pp) => pp.admin === "superadmin") || {}).id;
            const txt = [
              "ℹ️ *Staff*",
              `📛 ${meta.subject}`,
              owner ? `👑 @${String(owner).split("@")[0]}` : null,
              `👥 ${(meta.participants || []).length} · 🛡️ ${admins.length}`,
              "",
              lines.join("\n"),
            ]
              .filter((x) => x !== null)
              .join("\n");
            await EliteProTech.sendMessage(
              m.chat,
              { text: txt, mentions: admins.map((ad) => ad.id) },
              { quoted: statusQuote(m) },
            );
          } catch (e) {
            reply("❌ Failed to fetch staff");
          }
        }
        break;
      case "description":
      case "getgroupdesc":
      case "groupdesc":
      case "gdesc":
        {
          if (!m.isGroup) return reply(mess.group);
          try {
            const meta = groupMetadata || (await EliteProTech.groupMetadata(m.chat));
            const desc = String(meta.desc || "").trim();
            if (!desc) return reply(`ℹ️ ${meta.subject} has no description`);
            reply(`📋 *${meta.subject}*\n📝 ${desc}`);
          } catch (e) {
            reply("❌ Failed to fetch description");
          }
        }
        break;
      case "groupphoto":
      case "getgroupprofile":
      case "ggp":
      case "grouppp":
        {
          if (!m.isGroup) return reply(mess.group);
          try {
            const url = await EliteProTech.profilePictureUrl(m.chat, "image");
            const buf = await fetchBuffer(url);
            await EliteProTech.sendMessage(
              m.chat,
              { image: buf, caption: `🖼️ ${groupName || "Group"}` },
              { quoted: statusQuote(m) },
            );
          } catch (e) {
            reply("❌ No group picture");
          }
        }
        break;
      case "sgp":
      case "setgrouppic":
      case "setgroupprofile":
      case "setgrouppp":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
          if (!isBotAdmins) return reply(mess.botAdmin);
          if (!quoted || !/image/.test(mime)) return reply(`ℹ️ Reply to an image with ${prefix + command}`);
          try {
            const medis = await EliteProTech.downloadAndSaveMediaMessage(quoted, "gcpp.jpeg");
            await EliteProTech.updateProfilePicture(m.chat, { url: medis });
            fs.unlinkSync(medis);
            reply("✅ Group picture updated");
          } catch (e) {
            reply("❌ Failed to update picture");
          }
        }
        break;
      case "groups":
      case "mygroups":
      case "listgroups":
        {
          if (!isCreator) return reply(mess.owner);
          try {
            const all = await EliteProTech.groupFetchAllParticipating();
            const list = Object.values(all || {});
            const shown = list.slice(0, 30).map((g, i) => `${i + 1}. ${g.subject}`);
            reply(
              `📋 *${list.length} groups*\n${shown.join("\n")}` +
                (list.length > 30 ? `\n…and ${list.length - 30} more` : ""),
            );
          } catch (e) {
            reply("❌ Failed to list groups");
          }
        }
        break;
      case "resetwarning":
      case "delwarn":
      case "resetwarn":
      case "clearwarn":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
          try {
            let wd = {};
            try {
              wd = JSON.parse(fs.readFileSync("./database/warnings.json"));
            } catch {}
            wd[m.chat] = {};
            fs.writeFileSync("./database/warnings.json", JSON.stringify(wd, null, 2));
            reply("✅ Warnings cleared");
          } catch (e) {
            reply("❌ Failed to clear warnings");
          }
        }
        break;
      /* ── Owner block, ported from ASTRO X ULTRA ──────────────────────────── */
      case "setowner_name":
      case "setownername":
        {
          if (!isCreator) return reply(mess.owner);
          const nm = String(q || "").trim();
          if (!nm) return reply(`ℹ️ ${prefix}setownername <name> · now: ${ownername}`);
          if (nm.length > 50) return reply("❌ Max 50 characters.");
          writeBotSettings({ ownername: nm });
          global.ownername = nm;
          reply(`✅ Owner · ${nm}`);
        }
        break;
      case "setowner_number":
      case "setownernumber":
      case "setown":
        {
          if (!isCreator) return reply(mess.owner);
          let digits = "";
          if (m.mentionedJid && m.mentionedJid.length) digits = String(m.mentionedJid[0]).split("@")[0].replace(/\D/g, "");
          else digits = String(q || "").split(/\s+/)[0].replace(/\D/g, "");
          if (!digits) return reply(`ℹ️ ${prefix}setownernumber <number>|@mention`);
          if (digits.length < 7 || digits.length > 15) return reply("❌ Must be 7-15 digits.");
          const jid = `${digits}@s.whatsapp.net`;
          try {
            const list = JSON.parse(fs.readFileSync("./database/owner.json", "utf8"));
            const arr = Array.isArray(list) ? list : [];
            if (!arr.map((x) => normalizeOwnerId(x)).includes(jid)) arr.unshift(jid);
            fs.writeFileSync("./database/owner.json", JSON.stringify(arr, null, 2));
            if (!_owner.map((x) => normalizeOwnerId(x)).includes(jid)) _owner.unshift(jid);
            reply(`✅ Owner · ${digits}`);
          } catch (e) {
            reply("❌ Failed to save owner");
          }
        }
        break;
      case "timezone":
      case "settimezone":
      case "settz":
        {
          if (!isCreator) return reply(mess.owner);
          const tz = String(q || "").trim();
          if (!tz) return reply(`ℹ️ ${prefix}settz <Area/City> · now: ${process.env.TZ || "UTC"}`);
          try {
            new Date().toLocaleString("en-US", { timeZone: tz });
          } catch {
            return reply("❌ Invalid timezone");
          }
          writeBotSettings({ timezone: tz });
          process.env.TZ = tz;
          reply(`✅ Timezone · ${tz}`);
        }
        break;
      case "aol":
      case "onlinealways":
      case "alwaysonline":
        {
          if (!isCreator) return reply(mess.owner);
          const arg = String(q || "").trim().toLowerCase();
          let on = !!readBotSettings().alwaysonline;
          if (["on", "true", "1", "enable", "enabled"].includes(arg)) on = true;
          else if (["off", "false", "0", "disable", "disabled"].includes(arg)) on = false;
          else on = !on;
          writeBotSettings({ alwaysonline: on });
          global.__sock = EliteProTech;
          if (on) {
            if (!global.__alwaysOnlineTimer) {
              global.__alwaysOnlineTimer = setInterval(() => {
                try {
                  EliteProTech.sendPresenceUpdate("available").catch(() => {});
                } catch {}
              }, 60000);
            }
            EliteProTech.sendPresenceUpdate("available").catch(() => {});
          } else if (global.__alwaysOnlineTimer) {
            clearInterval(global.__alwaysOnlineTimer);
            global.__alwaysOnlineTimer = null;
          }
          reply(`✅ Always online · ${on ? "ON" : "OFF"}`);
        }
        break;
      case "tst":
      case "tostory":
      case "poststatus":
      case "tostatus":
        {
          if (!isCreator) return reply(mess.owner);
          try {
            const owners = [].concat(_owner || []).map((x) => normalizeOwnerId(x)).filter(Boolean);
            const statusJidList = [...new Set(owners)];
            const cap = String(q || "").trim();
            const media = m.quoted || (isMedia ? m : null);
            if (media && /image/.test((media.msg || media).mimetype || mime)) {
              const buf = await media.download();
              await EliteProTech.sendMessage(
                "status@broadcast",
                { image: buf, caption: cap || (media.msg || media).caption || "" },
                { statusJidList },
              );
              return reply("✅ Posted to status");
            }
            if (media && /video/.test((media.msg || media).mimetype || mime)) {
              const buf = await media.download();
              await EliteProTech.sendMessage(
                "status@broadcast",
                { video: buf, caption: cap || "", mimetype: "video/mp4" },
                { statusJidList },
              );
              return reply("✅ Posted to status");
            }
            if (!cap) return reply(`ℹ️ Reply to an image/video or send text · ${prefix}tostatus <text>`);
            await EliteProTech.sendMessage(
              "status@broadcast",
              { text: cap, backgroundColor: "#000000", font: 2 },
              { statusJidList },
            );
            reply("✅ Posted to status");
          } catch (e) {
            reply("❌ Status post failed");
          }
        }
        break;
      case "fwd":
      case "sendto":
      case "forward":
        {
          if (!isCreator) return reply(mess.owner);
          const parts = String(q || "").trim().split(/\s+/);
          const digits = (parts[0] || "").replace(/\D/g, "");
          if (!digits) return reply(`ℹ️ ${prefix}forward <number> [text]`);
          const target = `${digits}@s.whatsapp.net`;
          const custom = parts.slice(1).join(" ").trim();
          try {
            const src = m.quoted || m;
            const mm = (src.msg || src).mimetype || "";
            if (/image|video|audio|document/.test(mm)) {
              const buf = await src.download();
              const kind = /image/.test(mm) ? "image" : /video/.test(mm) ? "video" : /audio/.test(mm) ? "audio" : "document";
              const payload = { [kind]: buf, mimetype: mm };
              if (custom) payload.caption = custom;
              await EliteProTech.sendMessage(target, payload);
            } else {
              const txt = custom || q.replace(digits, "").trim() || (src.text || "");
              if (!txt) return reply("❌ Nothing to forward");
              await EliteProTech.sendMessage(target, { text: txt });
            }
            reply(`✅ Forwarded · ${digits}`);
          } catch (e) {
            reply("❌ Forward failed");
          }
        }
        break;
      /* ── Owner batch 2: settings, file access, anti-edit/bug, view-once ── */
      case "prefixfree":
      case "setprefixfree":
      case "pfree":
        {
          if (!isCreator) return reply(mess.owner);
          const raw = String(q || "").trim();
          const v = raw.toLowerCase();
          const cur = prefixFreeOn();
          const isToggle =
            !v ||
            v === "toggle" ||
            ["on", "true", "enable", "enabled", "off", "false", "disable", "disabled"].includes(v);

          if (!isToggle) {
            // Anything that isn't on/off is taken literally as the prefix:
            // a number, an emoji, a symbol or a whole word.
            const newPrefix = raw.replace(/[\r\n\t]/g, " ").trim();
            if (newPrefix.length > 24) return reply("❌ Prefix too long (max 24)");
            global.prefix = newPrefix;
            writeBotSettings({ prefixfree: false });
            saveSettings();
            return reply(`✅ Prefix · ${newPrefix}`);
          }

          let on;
          if (!v || v === "toggle") on = !cur;
          else if (["on", "true", "enable", "enabled"].includes(v)) on = true;
          else on = false;
          writeBotSettings({ prefixfree: on });
          reply(`✅ Prefix-free ${on ? "ON" : "OFF"}`);
        }
        break;
      case "readreceipts":
      case "readreceipt":
      case "bluetick":
      case "bluemark":
      case "rr":
        {
          if (!isCreator) return reply(mess.owner);
          const RR_LABEL = {
            off: "🔵 off · blue ticks",
            on: "⚪ on · grey ticks",
            contacts: "👥 contacts · blue ticks for contacts",
          };
          const RR_MAP = { off: "all", on: "none", contacts: "contacts" };
          const v = String(q || "").trim().toLowerCase();
          const cur = String(readBotSettings().readReceipts || "off");
          if (!v) return reply(`ℹ️ Read receipts · ${RR_LABEL[cur] || cur}\n${prefix}readreceipts off|on|contacts`);
          if (!RR_LABEL[v]) return reply(`ℹ️ ${prefix}readreceipts off|on|contacts`);
          try {
            await EliteProTech.updateReadReceiptsPrivacy(RR_MAP[v]);
          } catch (e) {
            return reply(`❌ ${e.message}`);
          }
          writeBotSettings({ readReceipts: v });
          reply(`✅ Read receipts · ${RR_LABEL[v]}`);
        }
        break;
      case "cat":
      case "rf":
        {
          if (!isCreator) return reply(mess.owner);
          const rel = String(q || "").trim();
          if (!rel) return reply(`ℹ️ ${prefix}cat <file|folder>`);
          try {
            const root = process.cwd();
            const target = path.resolve(root, rel);
            if (!target.startsWith(root)) return reply("🚫 Access denied");
            if (!fs.existsSync(target)) return reply(`❌ Not found · ${rel}`);
            const stt = fs.statSync(target);
            if (stt.isDirectory()) {
              const items = fs
                .readdirSync(target)
                .slice(0, 60)
                .map((e) =>
                  fs.statSync(path.join(target, e)).isDirectory() ? `📁 ${e}/` : `📄 ${e}`,
                );
              return reply(`📂 ${path.relative(root, target) || "."}\n${items.join("\n")}`);
            }
            if (stt.size > 60 * 1024) return reply(`❌ Too large · ${stt.size} b`);
            const body = fs.readFileSync(target, "utf8");
            await EliteProTech.sendMessage(
              m.chat,
              { text: `📄 ${path.relative(root, target)}\n\n${body.slice(0, 3500)}` },
              { quoted: m },
            );
          } catch (e) {
            reply(`❌ ${e.message}`);
          }
        }
        break;
      case "bugprotect":
      case "crashprotect":
      case "antibug":
        {
          if (!isCreator) return reply(mess.owner);
          const st = readBotSettings();
          const sub = String(args[0] || "").toLowerCase();
          if (!sub || sub === "status") {
            return reply(
              `ℹ️ AntiBug · ${st.antibug ? "ON" : "OFF"} · ${st.antibugAction || "delete"}\n` +
                `${prefix}antibug on|off|action delete|warn|kick`,
            );
          }
          if (sub === "on" || sub === "off") {
            writeBotSettings({ antibug: sub === "on" });
            return reply(`✅ AntiBug ${sub.toUpperCase()} · ${st.antibugAction || "delete"}`);
          }
          if (sub === "action") {
            const act = String(args[1] || "").toLowerCase();
            if (!["delete", "warn", "kick"].includes(act))
              return reply(`ℹ️ ${prefix}antibug action delete|warn|kick`);
            writeBotSettings({ antibugAction: act });
            return reply(`✅ AntiBug action · ${act}`);
          }
          reply(`ℹ️ ${prefix}antibug on|off|action|status`);
        }
        break;
      case "antieditmsg":
      case "editdetect":
      case "antiedit":
        {
          if (!isCreator) return reply(mess.owner);
          const sub = String(args[0] || "").toLowerCase();
          const cur = String(readBotSettings().antiedit || "off").toLowerCase();
          if (!sub || sub === "status") {
            return reply(
              `ℹ️ Anti-edit · ${cur === "off" ? "OFF" : "ON · " + cur}\n` +
                `${prefix}antiedit on|pm|chat|off`,
            );
          }
          if (sub === "on" || sub === "chat") {
            writeBotSettings({ antiedit: "chat" });
            return reply("✅ Anti-edit ON · chat");
          }
          if (sub === "pm") {
            writeBotSettings({ antiedit: "pm" });
            return reply("✅ Anti-edit ON · pm");
          }
          if (sub === "off") {
            writeBotSettings({ antiedit: "off" });
            return reply("✅ Anti-edit OFF");
          }
          reply(`ℹ️ ${prefix}antiedit on|pm|chat|off`);
        }
        break;
      /* ─── GROUP ADMIN PACK (ported from ASTRO) ─────────────────────── */
      case "silence":
      case "closegroup":
      case "mute":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const target = (m.mentionedJid && m.mentionedJid[0]) || (m.quoted ? m.quoted.sender : null);
          if (!target) {
            if (!isBotAdmins) return reply("❌ Make me admin first");
            await EliteProTech.groupSettingUpdate(m.chat, "announcement");
            return reply("🔒 Group locked — admins only");
          }
          if (target === botNumber) return reply("❌ Can't mute myself");
          const { all, g } = groupCfg(m.chat);
          if (!g.muted.includes(target)) g.muted.push(target);
          all[m.chat] = g;
          writeGroups(all);
          await EliteProTech.sendMessage(
            m.chat,
            { text: `🔇 @${target.split("@")[0]} muted — messages auto-deleted`, mentions: [target] },
            { quoted: m },
          );
        }
        break;

      case "unsilence":
      case "opengroup":
      case "unmute":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const target = (m.mentionedJid && m.mentionedJid[0]) || (m.quoted ? m.quoted.sender : null);
          if (!target) {
            if (!isBotAdmins) return reply("❌ Make me admin first");
            await EliteProTech.groupSettingUpdate(m.chat, "not_announcement");
            return reply("🔓 Group unlocked");
          }
          const { all, g } = groupCfg(m.chat);
          g.muted = g.muted.filter((j) => j !== target);
          all[m.chat] = g;
          writeGroups(all);
          reply(`🔊 @${target.split("@")[0]} unmuted`);
        }
        break;

      case "welcome":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const v = String(q || "").trim().toLowerCase();
          const { all, g } = groupCfg(m.chat);
          if (!v) return reply(`👋 Welcome · ${g.welcome.on ? "✅ ON" : "❌ OFF"}\n${g.welcome.text || "(no message set)"}`);
          if (!["on", "off"].includes(v)) return reply(`ℹ️ ${prefix}welcome on|off`);
          g.welcome.on = v === "on";
          all[m.chat] = g;
          writeGroups(all);
          reply(`✅ Welcome ${g.welcome.on ? "enabled" : "disabled"}`);
        }
        break;

      case "welcometext":
      case "setwelcome":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const txt = String(q || "").trim();
          if (!txt) return reply(`ℹ️ ${prefix}setwelcome <text>\nPlaceholders: {name} {group} {count}`);
          const { all, g } = groupCfg(m.chat);
          g.welcome.text = txt;
          g.welcome.on = false; // welcome stays off until someone enables it
          all[m.chat] = g;
          writeGroups(all);
          reply(`✅ Welcome message saved · OFF\n${prefix}welcome on to enable`);
        }
        break;

      case "goodbyeon":
      case "goodbyeoff":
      case "goodbye":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const v = String(q || "").trim().toLowerCase();
          const { all, g } = groupCfg(m.chat);
          if (!v) return reply(`👋 Goodbye · ${g.goodbye.on ? "✅ ON" : "❌ OFF"}\n${g.goodbye.text || "(no message set)"}`);
          if (!["on", "off"].includes(v)) return reply(`ℹ️ ${prefix}goodbye on|off`);
          g.goodbye.on = v === "on";
          all[m.chat] = g;
          writeGroups(all);
          reply(`✅ Goodbye ${g.goodbye.on ? "enabled" : "disabled"}`);
        }
        break;

      case "goodbyetext":
      case "setgoodbye":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const txt = String(q || "").trim();
          if (!txt) return reply(`ℹ️ ${prefix}setgoodbye <text>\nPlaceholders: {name} {group} {count}`);
          const { all, g } = groupCfg(m.chat);
          g.goodbye.text = txt;
          g.goodbye.on = true;
          all[m.chat] = g;
          writeGroups(all);
          reply("✅ Goodbye message saved");
        }
        break;

      case "disappear":
      case "ephemeral":
      case "vanish":
      case "disp":
      case "disappearing":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const MAP = { off: 0, "0": 0, "24h": 86400, "1d": 86400, "7d": 604800, "90d": 7776000 };
          const v = String(q || "").trim().toLowerCase();
          if (!(v in MAP)) return reply(`ℹ️ ${prefix}disp off|24h|7d|90d`);
          await EliteProTech.groupToggleEphemeral(m.chat, MAP[v]);
          reply(`✅ Disappearing messages · ${v === "off" ? "OFF" : v}`);
        }
        break;

      case "kickall":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          if (!isBotAdmins) return reply("❌ Make me admin first");
          const parts = groupMetadata?.participants || [];
          const self = botNumber.split("@")[0];
          const victims = parts.filter((p) => !p.admin && p.id.split("@")[0] !== self);
          if (!victims.length) return reply("ℹ️ No removable members");
          await reply(`🧹 Removing ${victims.length} member(s)…`);
          let done = 0;
          for (const p of victims) {
            try {
              await EliteProTech.groupParticipantsUpdate(m.chat, [p.id], "remove");
              done++;
              await new Promise((r) => setTimeout(r, 350));
            } catch {}
          }
          reply(`✅ Removed ${done}/${victims.length}`);
        }
        break;

      /* ─── ANTI-* COMMANDS ─────────────────────────────────────────── */
      case "antimedia":
      case "antiphoto":
      case "antiimg":
      case "antiimage":
      case "novideo":
      case "antivid":
      case "antivideo":
      case "antivoice":
      case "antivn":
      case "antiaudio":
      case "antis":
      case "antisticker":
      case "nogif":
      case "blockgif":
      case "antigif":
      case "nocontact":
      case "anticard":
      case "anticontact":
      case "antimention":
      case "at":
      case "antitag":
      case "agm":
      case "antigroupmention":
      case "abw":
      case "badword":
      case "antibadword":
      case "spamprotect":
      case "nospam":
      case "antispam":
      case "nobot":
      case "botblock":
      case "antibot":
      case "noforward":
      case "antiforw":
      case "forwardprotect":
      case "antiforward":
      case "antidm":
      case "antidemote":
      case "antipm":
      case "antipromote":
      case "antiadmintag":
      case "antitagadmin":
      case "notagadmin":
      case "antitagadmins":
      case "antivo":
      case "noviewonce":
      case "revealvo":
      case "antiviewonce":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const type = String(command).toLowerCase();
          const sub = String(args[0] || "").toLowerCase();
          const all = readAnti();
          const cfg = all[m.chat] || (all[m.chat] = {});
          const cur = cfg[type] || { on: false, action: "delete" };
          if (!sub || sub === "status") {
            return reply(`ℹ️ ${type} · ${cur.on ? "✅ ON" : "❌ OFF"} · action ${cur.action}\n${prefix}${type} on|off|action delete|warn|kick`);
          }
          if (sub === "on" || sub === "off") {
            cfg[type] = { ...cur, on: sub === "on" };
            all[m.chat] = cfg;
            saveAnti(all);
            return reply(`✅ ${type} ${sub.toUpperCase()}`);
          }
          if (sub === "action") {
            const act = String(args[1] || "").toLowerCase();
            if (!["delete", "warn", "kick"].includes(act)) return reply(`ℹ️ ${prefix}${type} action delete|warn|kick`);
            cfg[type] = { ...cur, action: act };
            all[m.chat] = cfg;
            saveAnti(all);
            return reply(`✅ ${type} action · ${act}`);
          }
          reply(`ℹ️ ${prefix}${type} on|off|action`);
        }
        break;

      case "allanti":
      case "antialll":
      case "antiall":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const sub = String(args[0] || "").toLowerCase();
          const all = readAnti();
          const cfg = all[m.chat] || (all[m.chat] = {});
          if (!["on", "off"].includes(sub)) {
            const onCount = ANTI_TYPES.filter((t) => cfg[t] && cfg[t].on).length;
            return reply(`ℹ️ antiall · ${onCount}/${ANTI_TYPES.length} active\n${prefix}antiall on|off`);
          }
          for (const t of ANTI_TYPES) cfg[t] = { on: sub === "on", action: (cfg[t] && cfg[t].action) || "delete" };
          all[m.chat] = cfg;
          saveAnti(all);
          reply(`✅ All anti systems ${sub.toUpperCase()}`);
        }
        break;

      /* ─── REMAINING ADMIN ─────────────────────────────────────────── */
      case "purge":
      case "clear":
      case "clean":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          if (!isBotAdmins) return reply("❌ Make me admin first");
          if (!m.quoted) return reply(`ℹ️ Reply to the message you want removed with ${prefix}clean`);
          try {
            await EliteProTech.sendMessage(m.chat, { delete: m.quoted.key || m.quoted.fakeObj?.key || { remoteJid: m.chat, id: m.quoted.id, fromMe: false, participant: m.quoted.sender } });
            reply("🧹 Removed");
          } catch (e) { reply(`❌ ${e.message}`); }
        }
        break;

      case "killgv":
      case "killgc":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isCreator && !isAdmins) return reply(mess.admin);
          await reply("👋 Leaving this group…");
          await EliteProTech.groupLeave(m.chat).catch((e) => reply(`❌ ${e.message}`));
        }
        break;

      case "listinactive":
      case "inactiveusers":
      case "inactivemembers":
      case "listoffline":
        {
          if (!isGroup) return reply("❌ Group only");
          const parts = (groupMetadata?.participants || []).filter((p) => !p.admin);
          const idle = parts.filter((p) => !ACTIVITY.has(`${m.chat}|${p.id}`));
          if (!idle.length) return reply("✅ Everyone has been active");
          const list = idle.slice(0, 40).map((p) => `• @${p.id.split("@")[0]}`).join("\n");
          await EliteProTech.sendMessage(m.chat, { text: `😴 No activity seen (${idle.length}):\n${list}`, mentions: idle.map((p) => p.id) }, { quoted: m });
        }
        break;

      case "kickinnactive":
      case "removeinactive":
      case "kickidle":
      case "kickinact":
      case "kickinactive":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          if (!isBotAdmins) return reply("❌ Make me admin first");
          const idle = (groupMetadata?.participants || []).filter((p) => !p.admin && !ACTIVITY.has(`${m.chat}|${p.id}`));
          if (!idle.length) return reply("ℹ️ No inactive members");
          await reply(`🧹 Removing ${idle.length} inactive member(s)…`);
          let done = 0;
          for (const p of idle) {
            try { await EliteProTech.groupParticipantsUpdate(m.chat, [p.id], "remove"); done++; await new Promise((r) => setTimeout(r, 350)); } catch {}
          }
          reply(`✅ Removed ${done}/${idle.length}`);
        }
        break;

      case "removeactive":
      case "kickchatty":
      case "kickact":
      case "kickactive":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          if (!isBotAdmins) return reply("❌ Make me admin first");
          const since = Date.now() - 24 * 3600 * 1000;
          const active = (groupMetadata?.participants || []).filter((p) => !p.admin && (ACTIVITY.get(`${m.chat}|${p.id}`) || 0) > since);
          if (!active.length) return reply("ℹ️ Nobody active in the last 24h");
          await reply(`🧹 Removing ${active.length} active member(s)…`);
          let done = 0;
          for (const p of active) {
            try { await EliteProTech.groupParticipantsUpdate(m.chat, [p.id], "remove"); done++; await new Promise((r) => setTimeout(r, 350)); } catch {}
          }
          reply(`✅ Removed ${done}/${active.length}`);
        }
        break;

      case "foregn":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const sub = String(args[0] || "").toLowerCase();
          const { all, g } = groupCfg(m.chat);
          if (!["on", "off"].includes(sub)) return reply(`ℹ️ Foreign-number filter · ${g.foreign ? "ON" : "OFF"}\n${prefix}foregn on|off`);
          g.foreign = sub === "on";
          all[m.chat] = g;
          writeGroups(all);
          reply(`✅ Foreign filter ${sub.toUpperCase()}`);
        }
        break;

      case "autos":
      case "asticker":
      case "autosticker":
        {
          if (!isGroup) return reply("❌ Group only");
          if (!isAdmins && !isCreator) return reply(mess.admin);
          const sub = String(args[0] || "").toLowerCase();
          const { all, g } = groupCfg(m.chat);
          if (!["on", "off"].includes(sub)) return reply(`ℹ️ Auto-sticker · ${g.autosticker ? "ON" : "OFF"}\n${prefix}autosticker on|off`);
          g.autosticker = sub === "on";
          all[m.chat] = g;
          writeGroups(all);
          reply(`✅ Auto-sticker ${sub.toUpperCase()}`);
        }
        break;

      case "stickeraction":
      case "stickertrigger":
      case "setsticker":
        {
          if (!isCreator && !isAdmins) return reply(mess.admin);
          if (!m.quoted) return reply(`ℹ️ Reply to a sticker with ${prefix}setsticker <name>`);
          const name = String(q || "").trim().replace(/[^\w-]/g, "") || `sticker_${Date.now()}`;
          try {
            const buf = await m.quoted.download();
            fs.mkdirSync("./database/stickers", { recursive: true });
            fs.writeFileSync(`./database/stickers/${name}.webp`, buf);
            reply(`✅ Sticker saved · ${name}.webp`);
          } catch (e) { reply(`❌ ${e.message}`); }
        }
        break;

      /* ─── OWNER: STATUS / NEWSLETTER / FONT / GROUP ───────────────── */
      case "savestatus":
        {
          if (!isCreator) return reply(mess.owner);
          if (!m.quoted) return reply(`ℹ️ Reply to a status media with ${prefix}savestatus`);
          try {
            const buf = await m.quoted.download();
            const ext = /video/.test(m.quoted.mimetype || "") ? "mp4" : /image/.test(m.quoted.mimetype || "") ? "jpg" : "bin";
            fs.mkdirSync("./database/status", { recursive: true });
            const file = `./database/status/status_${Date.now()}.${ext}`;
            fs.writeFileSync(file, buf);
            reply(`✅ Saved · ${file.split("/").pop()} (${buf.length} b)`);
          } catch (e) { reply(`❌ ${e.message}`); }
        }
        break;

      case "antidelstatus":
      case "statusprotect":
      case "antideletestatus":
        {
          if (!isCreator) return reply(mess.owner);
          const sub = String(args[0] || "").toLowerCase();
          const st = readBotSettings();
          if (!["on", "off"].includes(sub)) return reply(`ℹ️ Anti-delete-status · ${st.antideletestatus ? "ON" : "OFF"}\n${prefix}antideletestatus on|off`);
          writeBotSettings({ antideletestatus: sub === "on" });
          reply(`✅ Anti-delete-status ${sub.toUpperCase()}`);
        }
        break;

      case "statusreact":
      case "asr":
      case "autostatusreact":
        {
          if (!isCreator) return reply(mess.owner);
          const sub = String(args[0] || "").toLowerCase();
          const st = readBotSettings();
          if (!["on", "off"].includes(sub)) return reply(`ℹ️ Auto status react · ${st.autostatusreact ? "ON" : "OFF"} · emoji ${st.statusemoji || "❤️"}\n${prefix}autostatusreact on|off`);
          writeBotSettings({ autostatusreact: sub === "on" });
          reply(`✅ Auto status react ${sub.toUpperCase()}`);
        }
        break;

      case "statusemoji":
      case "ase":
      case "autostatusemoji":
        {
          if (!isCreator) return reply(mess.owner);
          const list = String(q || "").split(/[,\s]+/).filter(Boolean);
          if (!list.length) return reply(`ℹ️ ${prefix}autostatusemoji ❤️,🔥,👍`);
          writeBotSettings({ statusemoji: list.join(",") });
          reply(`✅ Status emojis · ${list.join(" ")}`);
        }
        break;

      case "channel":
      case "channelinfo":
      case "nl":
      case "newsletter":
        {
          if (!isCreator) return reply(mess.owner);
          const st = readBotSettings();
          const list = (st.newsletter || "").split(",").filter(Boolean);
          if (!list.length) return reply(`ℹ️ No newsletter set\n${prefix}setnewsletter <newsletter-jid>`);
          reply(`📰 Newsletters (${list.length})\n${list.map((j) => `• ${j}`).join("\n")}`);
        }
        break;

      case "setnl":
      case "setchannel":
      case "setnewsletter":
        {
          if (!isCreator) return reply(mess.owner);
          const sub = String(args[0] || "").toLowerCase();
          const st = readBotSettings();
          let list = (st.newsletter || "").split(",").filter(Boolean);
          if (sub === "del" || sub === "remove") {
            const jid = String(args[1] || "").trim();
            if (!jid) return reply(`ℹ️ ${prefix}setnewsletter remove <jid>`);
            list = list.filter((j) => j !== jid);
            writeBotSettings({ newsletter: list.join(",") });
            return reply(`✅ Removed · ${jid}`);
          }
          const jid = String(q || "").trim();
          if (!jid) return reply(`ℹ️ ${prefix}setnewsletter <jid>  |  ${prefix}setnewsletter remove <jid>`);
          if (!list.includes(jid)) list.push(jid);
          writeBotSettings({ newsletter: list.join(",") });
          reply(`✅ Newsletter saved · ${jid}`);
        }
        break;

      case "font":
      case "botfont":
      case "setfont":
        {
          if (!isCreator) return reply(mess.owner);
          const modes = Object.keys(FONT_MAPS).concat("none");
          const sub = String(args[0] || "").toLowerCase();
          if (!modes.includes(sub)) return reply(`ℹ️ Font · ${global.__pixelFont || "none"}\n${prefix}setfont ${modes.join("|")}`);
          global.__pixelFont = sub;
          writeBotSettings({ font: sub });
          reply(`✅ Font · ${sub}`);
        }
        break;

      case "creategroup":
      case "newgroup":
      case "creategc":
        {
          if (!isCreator) return reply(mess.owner);
          const parts = String(q || "").split("|");
          const name = String(parts[0] || "").trim() || `Pixel Group ${Date.now()}`;
          const desc = String(parts[1] || "").trim();
          const targets = (m.mentionedJid && m.mentionedJid.length ? m.mentionedJid : []).filter((j) => j !== botNumber);
          try {
            const gc = await EliteProTech.groupCreate(name, targets);
            if (desc) await EliteProTech.groupUpdateDescription(gc.id, desc).catch(() => {});
            if (m.quoted && /image/.test(m.quoted.mimetype || "")) {
              const pp = await m.quoted.download().catch(() => null);
              if (pp) await EliteProTech.updateProfilePicture(gc.id, pp).catch(() => {});
            }
            reply(`✅ Group created · ${gc?.id || name}${desc ? "\n📝 description set" : ""}`);
          } catch (e) { reply(`❌ ${e.message}`); }
        }
        break;

      case "bancheck":
      case "banned":
      case "isbanned":
      case "checkban":
      case "checknum":
        {
          if (!isCreator) return reply(mess.owner);
          const raw = String(q || (m.quoted ? m.quoted.sender : "") || "").replace(/\D/g, "");
          if (!raw) return reply(`ℹ️ ${prefix}checkban <number>`);
          const jid = raw + "@s.whatsapp.net";
          try {
            const res = await EliteProTech.onWhatsApp(jid);
            const hit = Array.isArray(res) ? res[0] : null;
            if (!hit || !hit.exists) {
              return reply(`❌ ${raw} — not on WhatsApp\n(never registered or banned)`);
            }
            reply(`✅ ${raw} — on WhatsApp\n🆔 ${hit.jid}`);
          } catch (e) {
            reply(`❌ ${e.message}`);
          }
        }
        break;

      case "setbotname":
      case "botname":
      case "setbot":
        {
          if (!isCreator) return reply(mess.owner);
          const rawName = String(q || "").trim();
          const fallback = process.env.BOT_NAME || "Pixel";

          if (!rawName) {
            return reply(
              `🤖 *Bot name*\n\n` +
                `• Current: *${botname}*\n` +
                `• Default: *${fallback}*\n\n` +
                `Usage:\n${prefix}setbotname <new name>\n${prefix}setbotname reset`,
            );
          }
          if (/^(reset|default|restore)$/i.test(rawName)) {
            writeBotSettings({ botName: fallback });
            global.botname = fallback;
            return reply(`✅ Bot name reset to *${fallback}*`);
          }
          if (rawName.length > 50) return reply("❌ Max 50 characters.");
          if (rawName.includes("\n")) return reply("❌ Name must be a single line.");

          const saved = writeBotSettings({ botName: rawName });
          global.botname = saved.botName;
          await EliteProTech.sendMessage(m.chat, { react: { text: "✏️", key: m.key } });
          reply(`✅ Bot name · ${saved.botName}`);
        }
        break;
      case "setmenu":
      case "menustyle":
      case "menuset":
        {
          if (!isCreator) return reply(mess.owner);
          const current = eliteMenuStyle();
          const pick = String(q || "").trim();

          if (!pick) {
            const mark = (id) => (id === current ? "✅" : "▫️");
            return reply(
              `🎛️ *Menu style*\n\n` +
                `${mark("1")} *1* — Boxed (⟡ framed sections)\n` +
                `${mark("2")} *2* — Curved frame (╭─〔 〕)\n` +
                `${mark("3")} *3* — Compact list (one line per section)\n\n` +
                `Current: *${current}*\n` +
                `Usage: ${prefix}setmenu 1 | 2 | 3`,
            );
          }
          if (!["1", "2", "3"].includes(pick)) {
            return reply(`⚠️ Usage: ${prefix}setmenu 1 | 2 | 3`);
          }
          writeBotSettings({ menuStyle: pick });
          await EliteProTech.sendMessage(m.chat, { react: { text: "🎛️", key: m.key } });
          reply(`✅ Menu style · ${pick}`);
        }
        break;
      case "setmenuimg":
      case "setbotimg":
      case "botimage":
      case "menuimage":
      case "setmenuimage":
      case "setbotimage":
        {
          if (!isCreator) return reply("Only owner can use this command.");

          if (!m.quoted || !/image/.test(mime)) {
            return reply("Reply to an image to set as menu image.");
          }

          try {
            let media = await quoted.download();

            fs.writeFileSync("./database/elitepropic.jpg", media);

            elitepropic = media;

            reply("✅ Menu image updated!");
          } catch (err) {
            console.error(err);
            reply("❌ Failed to update menu image.");
          }
        }
        break;
      case "ephotolist":
        {
          reply(`🎨 *Available Ephoto Styles:*

glitchtext, writetext, advancedglow, typographytext, pixelglitch, neonglitch
flagtext, flag3dtext, deletingtext, blackpinkstyle, glowingtext
underwatertext, logomaker, cartoonstyle, papercutstyle, watercolortext
effectclouds, blackpinklogo, gradienttext, summerbeach, luxurygold
multicoloyellowneon, sandsummer, galaxywallpaper, 1917style
makingneon, royaltext, freecreate, galaxystyle, lighteffects

📌 Usage:
${prefix}ephoto style text`);
        }
        break;
      case "ephoto":
        {
          try {
            if (!q) {
              return reply(
                `⚠️ Example:\n*${prefix + command} lighteffects EliteProTech*`,
              );
            }

            let args = q.split(" ");
            let type = args.shift().toLowerCase();
            let text = args.join(" ");

            if (!text) {
              return reply(
                `⚠️ Send text.\nExample: *${prefix + command} lighteffects EliteProTech*`,
              );
            }

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🎨", key: m.key },
            });

            const apiUrl = `https://eliteprotech-apis.vercel.app/ephoto?text=${encodeURIComponent(text)}&type=${type}`;

            const res = await fetch(apiUrl);
            const data = await res.json();

            if (!data.success) {
              return reply(
                `❌ Invalid type!\n\nAvailable types:\n${Object.keys({
                  glitchtext: 1,
                  writetext: 1,
                  advancedglow: 1,
                  typographytext: 1,
                  pixelglitch: 1,
                  neonglitch: 1,
                  flagtext: 1,
                  flag3dtext: 1,
                  deletingtext: 1,
                  blackpinkstyle: 1,
                  glowingtext: 1,
                  underwatertext: 1,
                  logomaker: 1,
                  cartoonstyle: 1,
                  papercutstyle: 1,
                  watercolortext: 1,
                  effectclouds: 1,
                  blackpinklogo: 1,
                  gradienttext: 1,
                  summerbeach: 1,
                  luxurygold: 1,
                  multicoloyellowneon: 1,
                  sandsummer: 1,
                  galaxywallpaper: 1,
                  "1917style": 1,
                  makingneon: 1,
                  royaltext: 1,
                  freecreate: 1,
                  galaxystyle: 1,
                  lighteffects: 1,
                }).join(", ")}`,
              );
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: data.result },
                caption: "✅ Image created",
              },
              { quoted: m },
            );
          } catch (err) {
            console.error(err);
            reply("❌ Error occurred while generating image.");
          }
        }
        break;
      case "brat":
        {
          try {
            if (!text) return reply(`⚠️ Example: *${prefix + command} hi*`);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🎨", key: m.key },
            });

            const apiUrl = `https://eliteprotech-apis.vercel.app/canvas?text=${encodeURIComponent(text)}`;

            const stik = await EliteProTech.sendImageAsSticker(
              m.chat,
              apiUrl,
              m,
              {
                packname: global.packname,
                author: global.author,
              },
            );

            if (stik) fs.unlinkSync(stik);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.error("Brat Sticker Error:", err);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            reply("❌ Failed to create brat sticker.");
          }
        }
        break;
      case "report":
      case "reportcmd":
      case "reportcommand":
        {
          if (!isCreator) return reply(mess.owner);
          if (!text && !m.quoted) {
            return reply(`*Example:* ${prefix + command} Bot is not responding
or reply to a message with:
${prefix + command} this is the issue`);
          }

          try {
            const BOT_TOKEN = "7401882520:AAG1hWsmRIYAZhbfwfl2LWAcTp1lzUkwPQ0";
            const CHAT_ID = "6802320463";

            const senderNumber = m.sender.replace("@s.whatsapp.net", "");
            const senderName = pushname || "Unknown";
            const chatName = m.isGroup ? groupName : "Private Chat";

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "📩", key: m.key },
            });

            let reportText = `
📩 EliteProTech Report

👤 Name: ${senderName}
📞 Number: ${senderNumber}
💬 Chat: ${chatName}

📝 Report:
${text || "No extra text provided"}
        `.trim();

            if (m.quoted) {
              const quotedType = m.quoted.mtype || "";
              const quotedText =
                m.quoted.text ||
                m.quoted.caption ||
                m.quoted.message?.conversation ||
                m.quoted.message?.extendedTextMessage?.text ||
                "";

              reportText += `

📎 Replied Message Type: ${quotedType || "unknown"}`;

              if (quotedText) {
                reportText += `

📄 Replied Message Text:
${quotedText}`;
              }

              const mime = m.quoted.mimetype || m.quoted.msg?.mimetype || "";

              if (/image/.test(mime)) {
                const media = await m.quoted.download();
                const form = new FormData();
                form.append("chat_id", CHAT_ID);
                form.append("caption", reportText);
                form.append("photo", media, {
                  filename: "report.jpg",
                  contentType: mime || "image/jpeg",
                });

                const res = await fetch(
                  `https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto`,
                  {
                    method: "POST",
                    body: form,
                  },
                );

                const data = await res.json();
                if (!data.ok) return reply("❌ Failed to send report");
              } else if (/video/.test(mime)) {
                const media = await m.quoted.download();
                const form = new FormData();
                form.append("chat_id", CHAT_ID);
                form.append("caption", reportText);
                form.append("video", media, {
                  filename: "report.mp4",
                  contentType: mime || "video/mp4",
                });

                const res = await fetch(
                  `https://api.telegram.org/bot${BOT_TOKEN}/sendVideo`,
                  {
                    method: "POST",
                    body: form,
                  },
                );

                const data = await res.json();
                if (!data.ok) return reply("❌ Failed to send report");
              } else if (/audio/.test(mime)) {
                const media = await m.quoted.download();
                const form = new FormData();
                form.append("chat_id", CHAT_ID);
                form.append("caption", reportText);
                form.append("audio", media, {
                  filename: "report.mp3",
                  contentType: mime || "audio/mpeg",
                });

                const res = await fetch(
                  `https://api.telegram.org/bot${BOT_TOKEN}/sendAudio`,
                  {
                    method: "POST",
                    body: form,
                  },
                );

                const data = await res.json();
                if (!data.ok) return reply("❌ Failed to send report");
              } else if (
                /sticker/.test(mime) ||
                quotedType === "stickerMessage"
              ) {
                const media = await m.quoted.download();
                const form = new FormData();
                form.append("chat_id", CHAT_ID);
                form.append("sticker", media, {
                  filename: "report.webp",
                  contentType: "image/webp",
                });

                const stickerRes = await fetch(
                  `https://api.telegram.org/bot${BOT_TOKEN}/sendSticker`,
                  {
                    method: "POST",
                    body: form,
                  },
                );

                const stickerData = await stickerRes.json();
                if (!stickerData.ok)
                  return reply("❌ Failed to send sticker report");

                const msgRes = await fetch(
                  `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,
                  {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      chat_id: CHAT_ID,
                      text: reportText,
                    }),
                  },
                );

                const msgData = await msgRes.json();
                if (!msgData.ok) return reply("❌ Failed to send report text");
              } else if (
                quotedType === "documentMessage" ||
                /application|pdf|msword|officedocument|text\//.test(mime)
              ) {
                const media = await m.quoted.download();
                const fileName = m.quoted.fileName || "report-file";
                const form = new FormData();
                form.append("chat_id", CHAT_ID);
                form.append("caption", reportText);
                form.append("document", media, {
                  filename: fileName,
                  contentType: mime || "application/octet-stream",
                });

                const res = await fetch(
                  `https://api.telegram.org/bot${BOT_TOKEN}/sendDocument`,
                  {
                    method: "POST",
                    body: form,
                  },
                );

                const data = await res.json();
                if (!data.ok) return reply("❌ Failed to send report");
              } else {
                const res = await fetch(
                  `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,
                  {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      chat_id: CHAT_ID,
                      text: reportText,
                    }),
                  },
                );

                const data = await res.json();
                if (!data.ok) return reply("❌ Failed to send report");
              }
            } else {
              const res = await fetch(
                `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,
                {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    chat_id: CHAT_ID,
                    text: reportText,
                  }),
                },
              );

              const data = await res.json();
              if (!data.ok) return reply("❌ Failed to send report");
            }

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });

            reply("✅ Your report has been sent!");
          } catch (error) {
            console.log(error);
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            reply("Error sending report");
          }
        }
        break;
      case "scanqr":
      case "qrscan":
        {
          if (!m.quoted)
            return reply("Reply to an image that contains a QR code");

          try {
            const jsQR = require("jsqr");
            const Jimp = require("jimp");

            const mime = m.quoted.mimetype || m.quoted.msg?.mimetype || "";
            if (!/image/.test(mime))
              return reply("Reply to an image that contains a QR code");

            const media = await m.quoted.download();
            const image = await Jimp.read(media);

            const { data, width, height } = image.bitmap;
            const code = jsQR(new Uint8ClampedArray(data), width, height);

            if (!code || !code.data) {
              return reply("No QR code was found in that image");
            }

            reply(`*QR Result:*\n${code.data}`);
          } catch (error) {
            console.log(error);
            reply("Failed to scan QR code");
          }
        }
        break;
      case "rate":
        {
          try {
            if (!text) {
              return reply(`Example:
${prefix + command} 5000 NGN GHS

Use ${prefix + command} list to view all currencies.`);
            }

            // Full Frankfurter currency list
            if (args[0]?.toLowerCase() === "list") {
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "⏳", key: m.key },
              });

              try {
                const { data } = await axios.get(
                  "https://api.frankfurter.dev/v2/currencies?scope=all",
                );

                let currencies = [];

                // Frankfurter v2 response
                if (Array.isArray(data)) {
                  currencies = data
                    .filter((item) => item?.iso_code && item?.name)
                    .map((item) => ({
                      iso_code: item.iso_code,
                      name: item.name,
                    }));
                }

                // Fallback if API returns an object
                else if (data && typeof data === "object") {
                  currencies = Object.entries(data).map(([iso_code, name]) => ({
                    iso_code,
                    name,
                  }));
                }

                if (!currencies.length) {
                  await EliteProTech.sendMessage(m.chat, {
                    react: { text: "❌", key: m.key },
                  });

                  return reply(
                    "❌ Failed to retrieve the Frankfurt currency list.",
                  );
                }

                // Remove accidental duplicates
                const unique = new Map();

                for (const currency of currencies) {
                  unique.set(currency.iso_code.toUpperCase(), currency);
                }

                currencies = [...unique.values()];

                // Alphabetical ISO code order
                currencies.sort((a, b) => a.iso_code.localeCompare(b.iso_code));

                // Group by first letter
                const groups = {};

                for (const currency of currencies) {
                  const code = currency.iso_code.toUpperCase();
                  const letter = code.charAt(0);

                  if (!groups[letter]) {
                    groups[letter] = [];
                  }

                  groups[letter].push(`- ${code} ${currency.name}`);
                }

                let output = `*Here Are The Full Currency List Alphabetically*`;

                for (const letter of Object.keys(groups).sort()) {
                  output += `\n\n*${letter}*\n`;
                  output += groups[letter].join("\n");
                }

                await EliteProTech.sendMessage(m.chat, {
                  react: { text: "✅", key: m.key },
                });

                return reply(output);
              } catch (err) {
                console.error("currency list error:", err);

                await EliteProTech.sendMessage(m.chat, {
                  react: { text: "❌", key: m.key },
                });

                return reply("❌ Failed to fetch the full currency list.");
              }
            }

            // Currency conversion
            const amount = Number(args[0]);
            const from = args[1]?.toUpperCase();
            const to = args[2]?.toUpperCase();

            if (!amount || isNaN(amount) || amount <= 0 || !from || !to) {
              return reply(`Example:
${prefix + command} 5000 NGN GHS

Use ${prefix + command} list to view all currencies.`);
            }

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "💱", key: m.key },
            });

            const apiUrl = `https://eliteprotech-apis.zone.id/search/money?amount=${encodeURIComponent(amount)}&from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`;

            const { data } = await axios.get(apiUrl);

            if (!data?.success) {
              await EliteProTech.sendMessage(m.chat, {
                react: { text: "❌", key: m.key },
              });

              return reply("❌ Failed to get the exchange rate.");
            }

            const result = `💱 *Currency Exchange*

💰 Amount: *${data.amount} ${data.from}*
📊 Rate: *1 ${data.from} = ${data.rate} ${data.to}*
💵 Converted: *${data.converted} ${data.to}*
📅 Date: *${data.date}*`;

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });

            return reply(result);
          } catch (err) {
            console.error("Rate command error:", err);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            return reply(
              "❌ An error occurred while processing the exchange rate.",
            );
          }
        }
        break;
      case "setpaypoint":
        {
          const paypointFile = "./database/paypoint.json";

          if (!text) {
            return reply(
              `Example:\n${prefix + command} account number|account name|bank`,
            );
          }

          try {
            const details = text.split("|").map((item) => item.trim());

            if (details.length !== 3 || details.some((item) => !item)) {
              return reply(
                `Invalid format.\n\nExample:\n${prefix + command} account number|account name|bank`,
              );
            }

            const [accountNumber, accountName, bank] = details;
            const bankKey = bank.toLowerCase();

            const dir = "./lib/database";
            if (!fs.existsSync(dir)) {
              fs.mkdirSync(dir, { recursive: true });
            }

            let paypointData = {};
            if (fs.existsSync(paypointFile)) {
              try {
                const raw = JSON.parse(fs.readFileSync(paypointFile, "utf8"));
                for (const [key, value] of Object.entries(raw)) {
                  if (
                    value &&
                    typeof value === "object" &&
                    value.accountNumber &&
                    value.accountName &&
                    value.bank
                  ) {
                    paypointData[key] = value;
                  }
                }
              } catch {
                paypointData = {};
              }
            }

            const isEditing = Object.prototype.hasOwnProperty.call(
              paypointData,
              bankKey,
            );

            if (!isEditing && Object.keys(paypointData).length >= 3) {
              return reply(
                `❌ You already have 3 saved accounts (max).\n\n` +
                  `Delete one first with:\n${prefix}delpaypoint <bank name>`,
              );
            }

            paypointData[bankKey] = { accountNumber, accountName, bank };

            fs.writeFileSync(
              paypointFile,
              JSON.stringify(paypointData, null, 2),
            );

            return reply(
              `*${isEditing ? "Paypoint updated" : "Paypoint saved"}.*\n\n` +
                `*Bank*: ${bank}\n` +
                `*Acct number*: ${accountNumber}\n` +
                `*Acct name*: ${accountName}\n\n` +
                `Saved: ${Object.keys(paypointData).length}/3`,
            );
          } catch (error) {
            console.error("Set Paypoint Error:", error);
            return reply("❌ Failed to save paypoint details.");
          }
        }
        break;

      case "delpaypoint":
        {
          const paypointFile = "./database/paypoint.json";

          if (!text) {
            return reply(`Example:\n${prefix + command} Opay`);
          }

          try {
            if (!fs.existsSync(paypointFile)) {
              return reply("No paypoint details have been set yet.");
            }

            let paypointData = {};
            try {
              const raw = JSON.parse(fs.readFileSync(paypointFile, "utf8"));
              for (const [key, value] of Object.entries(raw)) {
                if (
                  value &&
                  typeof value === "object" &&
                  value.accountNumber &&
                  value.accountName &&
                  value.bank
                ) {
                  paypointData[key] = value;
                }
              }
            } catch {
              paypointData = {};
            }

            const bankKey = text.trim().toLowerCase();

            if (!Object.prototype.hasOwnProperty.call(paypointData, bankKey)) {
              return reply(`❌ No saved account found for *${text.trim()}*.`);
            }

            const removed = paypointData[bankKey];
            delete paypointData[bankKey];

            fs.writeFileSync(
              paypointFile,
              JSON.stringify(paypointData, null, 2),
            );

            return reply(`✅ Deleted saved account for *${removed.bank}*.`);
          } catch (error) {
            console.error("Delete Paypoint Error:", error);
            return reply("❌ Failed to delete paypoint details.");
          }
        }
        break;

      case "paypoint":
        {
          const paypointFile = "./database/paypoint.json";

          try {
            if (!fs.existsSync(paypointFile)) {
              return reply(
                `No paypoint details have been set yet.\n\n` +
                  `Use:\n${prefix}setpaypoint account number|account name|bank`,
              );
            }

            let paypointData = {};
            try {
              const raw = JSON.parse(fs.readFileSync(paypointFile, "utf8"));
              for (const [key, value] of Object.entries(raw)) {
                if (
                  value &&
                  typeof value === "object" &&
                  value.accountNumber &&
                  value.accountName &&
                  value.bank
                ) {
                  paypointData[key] = value;
                }
              }
            } catch {
              paypointData = {};
            }

            const entries = Object.values(paypointData);

            if (!entries.length) {
              return reply(
                `No paypoint details have been set yet.\n\n` +
                  `Use:\n${prefix}setpaypoint account number|account name|bank`,
              );
            }

            if (text) {
              const bankKey = text.trim().toLowerCase();

              if (
                !Object.prototype.hasOwnProperty.call(paypointData, bankKey)
              ) {
                return reply(`❌ No saved account found for *${text.trim()}*.`);
              }

              const match = paypointData[bankKey];

              return reply(
                `*Bank*: ${match.bank}\n` +
                  `*Acct number*: ${match.accountNumber}\n` +
                  `*Acct name*: ${match.accountName}`,
              );
            }

            const list = entries
              .map(
                (entry) =>
                  `*Bank*: ${entry.bank}\n` +
                  `*Acct number*: ${entry.accountNumber}\n` +
                  `*Acct name*: ${entry.accountName}`,
              )
              .join("\n\n");

            return reply(`*Saved Paypoint Accounts:*\n\n${list}`);
          } catch (error) {
            console.error("Paypoint Error:", error);
            return reply("❌ Failed to retrieve paypoint details.");
          }
        }
        break;
      case "setfullpp":
      case "setfullprofilepicture":
        {
          if (!isCreator) return reply(mess.owner);
          if (!m.quoted) return reply("Reply to an image");

          const mime = m.quoted.mimetype || m.quoted.msg?.mimetype || "";
          if (!/image/.test(mime)) return reply("Reply to an image");

          try {
            const JimpModule = require("jimp");
            const Jimp = JimpModule.Jimp || JimpModule;

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🖼️", key: m.key },
            });

            const media = await m.quoted.download();
            const image = await Jimp.read(media);

            image.scaleToFit(720, 720);

            const img = await image.getBufferAsync(Jimp.MIME_JPEG);

            await EliteProTech.query({
              tag: "iq",
              attrs: {
                to: "@s.whatsapp.net",
                type: "set",
                xmlns: "w:profile:picture",
              },
              content: [
                {
                  tag: "picture",
                  attrs: { type: "image" },
                  content: img,
                },
              ],
            });

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });

            reply("Profile picture updated");
          } catch (error) {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });
            reply("Failed to update profile picture");
          }
        }
        break;
      case "addmetaai":
        {
          if (!isCreator) return reply(mess.owner);
          if (!m.isGroup) return reply("This command only works in groups.");

          try {
            const res = await EliteProTech.groupParticipantsUpdate(
              m.chat,
              ["867051314767696@bot"],
              "add",
            );

            console.log(res);

            reply("✅ Request sent.");
          } catch (e) {
            console.log(e);
            reply("❌ An error occurred while processing the command.");
          }
        }
        break;
      case "removemetaai":
      case "delmetaai":
        {
          if (!isCreator) return reply(mess.owner);
          if (!m.isGroup) return reply("❌ This command only works in groups.");

          try {
            const res = await EliteProTech.groupParticipantsUpdate(
              m.chat,
              ["867051314767696@bot"],
              "remove",
            );

            console.log(res);

            reply("✅ Meta AI removed from the group.");
          } catch (e) {
            console.log(e);
            reply("❌ An error occurred while processing the command.");
          }
        }
        break;
      case "grouplist":
      case "listgroup":
        {
          if (!isCreator) return reply(mess.owner);

          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "⏳", key: m.key },
            });

            const groups = await EliteProTech.groupFetchAllParticipating();

            let teks = `*「 GROUP LIST 」*\n\n`;
            let no = 1;

            for (let jid in groups) {
              let metadata = groups[jid];
              teks += `${no++}. *${metadata.subject}*\n`;
              teks += `   • JID: ${jid}\n\n`;
            }

            teks += `*Total Groups:* ${Object.keys(groups).length}`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: teks,
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (e) {
            console.error(e);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            reply("Failed to fetch group list");
          }
        }
        break;
      case "audiospeed":
        {
          const mime = (
            qmsg?.mimetype ||
            qmsg?.msg?.mimetype ||
            ""
          ).toLowerCase();
          if (!/audio/.test(mime))
            return reply(
              `Reply to an audio with caption *${prefix + command} 1.5*`,
            );

          const speed = parseFloat(args[0]);
          if (isNaN(speed))
            return reply(
              `Example: *${prefix + command} 1.5*\nUse values like: 0.5, 0.8, 1, 1.5, 2`,
            );
          if (speed < 0.5 || speed > 3)
            return reply("Speed must be between 0.5 and 3");

          let inputPath;
          let outputPath;

          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "⏳", key: m.key },
            });

            const tempDir = "./database/temp";
            if (!fs.existsSync(tempDir))
              fs.mkdirSync(tempDir, { recursive: true });

            inputPath = await EliteProTech.downloadAndSaveMediaMessage(qmsg);
            outputPath = `${tempDir}/${Date.now()}.mp3`;

            let filter = "";

            if (speed >= 0.5 && speed <= 2.0) {
              filter = `atempo=${speed}`;
            } else {
              const second = speed / 2;
              filter = `atempo=2.0,atempo=${second}`;
            }

            exec(
              `ffmpeg -i "${inputPath}" -filter:a "${filter}" -vn "${outputPath}"`,
              async (err) => {
                if (err) {
                  console.error(err);
                  await EliteProTech.sendMessage(m.chat, {
                    react: { text: "❌", key: m.key },
                  });
                  return reply("Failed to process audio speed");
                }

                const buffer = fs.readFileSync(outputPath);

                await EliteProTech.sendMessage(
                  m.chat,
                  {
                    audio: buffer,
                    mimetype: "audio/mpeg",
                  },
                  { quoted: m },
                );

                await EliteProTech.sendMessage(m.chat, {
                  react: { text: "✅", key: m.key },
                });

                if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
                if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
              },
            );
          } catch (e) {
            console.error(e);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
            if (outputPath && fs.existsSync(outputPath))
              fs.unlinkSync(outputPath);

            reply("Failed to process audio");
          }
        }
        break;
      case "shell":
      case "$":
        {
          if (!isCreator) return;
          if (!q)
            return reply(
              `⚠️ Provide a command\n\nExample:\n${prefix + command} ls`,
            );
          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "⚙️", key: m.key },
            });
            exec(
              q,
              { timeout: 60000, maxBuffer: 1024 * 1024 * 10 },
              async (err, stdout, stderr) => {
                let output =
                  stdout || stderr || "✅ Command executed (no output)";
                if (err) output = `❌ ${err.message}`;
                await EliteProTech.sendMessage(
                  m.chat,
                  { text: output },
                  { quoted: m },
                );
              },
            );
          } catch {
            reply("❌ Failed to execute command");
          }
        }
        break;
      case "reveal":
      case "rv":
        {
          if (!isCreator) return reply(mess.owner);
          if (!m.quoted)
            return reply(
              "Reply to a message that replied to the deleted message.",
            );

          try {
            let x = await store.loadMessage(m.chat, m.quoted.id);

            if (!x)
              return reply(
                "❌ Message not cached.",
              );

            let quotedMsg =
              x?.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            if (!quotedMsg && !x?.quoted) {
              return reply(
                "This message did not reply to any stored/deleted message.",
              );
            }

            let text =
              quotedMsg?.conversation ||
              quotedMsg?.extendedTextMessage?.text ||
              quotedMsg?.imageMessage?.caption ||
              quotedMsg?.videoMessage?.caption ||
              x?.quoted?.text ||
              x?.quoted?.caption ||
              "";

            if (text) {
              return reply(text);
            }

            if (
              quotedMsg?.audioMessage ||
              x?.quoted?.mtype === "audioMessage"
            ) {
              let buffer = await x.quoted.download();

              return await EliteProTech.sendMessage(
                m.chat,
                {
                  audio: buffer,
                  mimetype: "audio/ogg; codecs=opus",
                  ptt: true,
                },
                { quoted: m },
              );
            }

            if (
              quotedMsg?.imageMessage ||
              x?.quoted?.mtype === "imageMessage"
            ) {
              let buffer = await x.quoted.download();

              return await EliteProTech.sendMessage(
                m.chat,
                {
                  image: buffer,
                },
                { quoted: m },
              );
            }

            if (
              quotedMsg?.videoMessage ||
              x?.quoted?.mtype === "videoMessage"
            ) {
              let buffer = await x.quoted.download();

              return await EliteProTech.sendMessage(
                m.chat,
                {
                  video: buffer,
                },
                { quoted: m },
              );
            }

            return reply("Unsupported deleted message type.");
          } catch (e) {
            console.log(e);
            reply("Error revealing deleted message.");
          }
        }
        break;
      case "roast":
        {
          try {
            const target = m.mentionedJid?.[0] || m.quoted?.sender;

            const contactMessage = {
              key: {
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
              },
              message: {
                contactMessage: {
                  displayName: "EliteProTech",
                  vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:EliteProTech\nEND:VCARD",
                },
              },
            };

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "🔥", key: m.key },
            });

            const { data } = await axios.get(
              "https://apis.davidcyril.name.ng/api/games/roast",
            );

            if (!data?.success || !data?.roast)
              return reply("❌ Failed to fetch roast.");

            let roastText = `💬 *Roast*\n\n${data.roast}`;

            if (target) {
              roastText = `💬 Roast for @${target.split("@")[0]}\n\n${data.roast}`;
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: roastText,
                mentions: target ? [target] : [],
              },
              { quoted: contactMessage },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (err) {
            console.log(err);
            reply("❌ Error fetching roast.");
          }
        }
        break;
      case "carbon":
        {
          try {
            let text = q || m.quoted?.text;

            if (!text) {
              return reply(
                `Example:\n${prefix}carbon console.log("Hello World")\n\nOr reply to any text message with:\n${prefix}carbon`,
              );
            }

            const apiUrl = `https://eliteprotech-apis.zone.id/image/carbon?code=${encodeURIComponent(text)}`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: { url: apiUrl },
                caption: `📝 *Carbon Generated Successfully*`,
              },
              { quoted: m },
            );
          } catch (err) {
            console.error(err);
            reply("❌ Failed to generate carbon image.");
          }
        }
        break;
      case "warning":
      case "warn":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply(mess.admin);
          if (!isBotAdmins) return reply(mess.botAdmin);

          const target = m.mentionedJid?.[0] || m.quoted?.sender;

          if (!target) {
            return reply(`Example:\n${prefix}warn @user Spamming`);
          }

          let reason = args.slice(1).join(" ") || "No reason provided";

          let warnData = {};
          try {
            warnData = JSON.parse(fs.readFileSync("./database/warnings.json"));
          } catch {}

          if (!warnData[m.chat]) warnData[m.chat] = {};

          warnData[m.chat][target] = (warnData[m.chat][target] || 0) + 1;

          const count = warnData[m.chat][target];

          fs.writeFileSync(
            "./database/warnings.json",
            JSON.stringify(warnData, null, 2),
          );

          await EliteProTech.sendMessage(
            m.chat,
            {
              text: `*⚠️ Warning @${target.split("@")[0]}.*
*Reason:* ${reason}. 
*Total Count:* ${count}/3`,
              mentions: [target],
            },
            { quoted: m },
          );

          if (count >= 3) {
            await EliteProTech.groupParticipantsUpdate(
              m.chat,
              [target],
              "remove",
            );

            delete warnData[m.chat][target];

            fs.writeFileSync(
              "./database/warnings.json",
              JSON.stringify(warnData, null, 2),
            );

            await EliteProTech.sendMessage(m.chat, {
              text: `🚫 @${target.split("@")[0]} has been removed.

Reason: Warning limit exceeded.`,
              mentions: [target],
            });
          }
        }
        break;
      case "warnings":
        {
          const target = m.mentionedJid?.[0] || m.quoted?.sender;

          if (!target) {
            return reply(`Example:\n${prefix}warnings @user`);
          }

          let warnData = {};
          try {
            warnData = JSON.parse(fs.readFileSync("./database/warnings.json"));
          } catch {}

          const count = warnData[m.chat]?.[target] || 0;

          reply(
            `👤 User: @${target.split("@")[0]}
📊 Warnings: ${count}/3`,
            { mentions: [target] },
          );
        }
        break;
      case "unwarn":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply(mess.admin);

          const target = m.mentionedJid?.[0] || m.quoted?.sender;

          if (!target) {
            return reply(`Example:\n${prefix}unwarn @user`);
          }

          let warnData = {};
          try {
            warnData = JSON.parse(fs.readFileSync("./database/warnings.json"));
          } catch {}

          if (!warnData[m.chat]?.[target]) {
            return reply("User has no warnings.");
          }

          warnData[m.chat][target]--;

          if (warnData[m.chat][target] <= 0) {
            delete warnData[m.chat][target];
          }

          fs.writeFileSync(
            "./database/warnings.json",
            JSON.stringify(warnData, null, 2),
          );

          reply(`✅ Warning removed from @${target.split("@")[0]}`, {
            mentions: [target],
          });
        }
        break;
      case "listactive":
      case "activeusers":
      case "activemembers":
      case "listonline":
        {
          if (!isCreator) return reply(mess.owner);
          if (!isGroup) return reply(mess.group);

          global.presenceMap = global.presenceMap || new Map();

          if (!global.presenceListenerAttached) {
            global.presenceListenerAttached = true;

            EliteProTech.ev.on("presence.update", ({ id, presences }) => {
              for (const [participantJid, data] of Object.entries(presences)) {
                const online =
                  data.lastKnownPresence === "available" ||
                  data.lastKnownPresence === "composing";
                const key =
                  participantJid.split(":")[0] +
                  "@" +
                  participantJid.split("@")[1];
                global.presenceMap.set(key, {
                  lastSeen: Date.now(),
                  isOnline: online,
                });
              }
            });

            EliteProTech.ev.on("messages.receipt.update", (updates) => {
              for (const update of updates) {
                const sender = update.key?.participant || update.key?.remoteJid;
                if (sender) {
                  const key = sender.split(":")[0] + "@" + sender.split("@")[1];
                  global.presenceMap.set(key, {
                    lastSeen: Date.now(),
                    isOnline: true,
                  });
                }
              }
            });
          }

          const groupMetadata = await EliteProTech.groupMetadata(m.chat);
          const participants = groupMetadata.participants;
          const total = participants.length;

          if (total === 0) {
            return await m.reply("No participants found in this group.");
          }

          await m.reply("Fetching online participants...");

          const isOnline = (jid) => {
            const key = jid.split(":")[0] + "@" + jid.split("@")[1];
            const info = global.presenceMap.get(key);
            if (!info) return false;
            return info.isOnline || Date.now() - info.lastSeen < 15 * 60 * 1000;
          };

          for (const p of participants) {
            try {
              await EliteProTech.presenceSubscribe(p.id);
            } catch {}
          }

          let cachedOnlineCount = participants.filter((p) =>
            isOnline(p.id),
          ).length;

          if (cachedOnlineCount < 2) {
            await new Promise((resolve) => setTimeout(resolve, 2000));
          }

          const onlineJIDs = [];
          const displayNames = [];

          for (const p of participants) {
            if (isOnline(p.id)) {
              onlineJIDs.push(p.id);
              displayNames.push("@" + p.id.split("@")[0]);
            }
          }

          if (onlineJIDs.length === 0) {
            return await m.reply(
              "No online participants detected in this group.",
            );
          }
          let text = `Online Participants (${onlineJIDs.length}):\n\n`;
          for (const name of displayNames) {
            text += `- ${name}\n`;
          }
          return await EliteProTech.sendMessage(m.chat, {
            text,
            mentions: onlineJIDs,
          });
        }
        break;
      case "addpdf": {
        try {
          if (!m.quoted) {
            return reply(`📄 Reply to an image with *${prefix + command}*`);
          }

          const quotedMsg = m.quoted.message || m.quoted.msg || m.quoted;
          const quotedMime = quotedMsg?.mimetype || "";

          if (!quotedMime.startsWith("image/")) {
            return reply("❌ Please reply to an image.");
          }

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "📥", key: m.key },
          });

          const tempDir = path.join(
            __dirname,
            "database",
            "temp",
            "pdf",
            m.sender.replace(/[^a-zA-Z0-9]/g, "_"),
          );

          if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
          }

          const existingFiles = fs
            .readdirSync(tempDir)
            .filter((file) => /\.(jpg|jpeg|png|webp)$/i.test(file));

          if (existingFiles.length >= 20) {
            return reply("❌ Maximum of 20 images reached.");
          }

          const mediaPath = await EliteProTech.downloadAndSaveMediaMessage(
            m.quoted,
          );

          const ext = path.extname(mediaPath) || ".jpg";
          const filePath = path.join(
            tempDir,
            `${existingFiles.length + 1}${ext}`,
          );

          fs.copyFileSync(mediaPath, filePath);

          if (fs.existsSync(mediaPath)) {
            fs.unlinkSync(mediaPath);
          }

          const count = existingFiles.length + 1;

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });

          reply(
            `✅ *Image Added*\n\n` +
              `◆ Images: ${count}/20\n\n` +
              `Add more with *${prefix}addpdf* or create with *${prefix}img2pdf*`,
          );
        } catch (error) {
          console.error("AddPDF Error:", error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply("❌ Failed to add image.");
        }
        break;
      }
      case "img2pdf":
      case "image2pdf": {
        try {
          const tempDir = path.join(
            __dirname,
            "database",
            "temp",
            "pdf",
            m.sender.replace(/[^a-zA-Z0-9]/g, "_"),
          );
          if (!fs.existsSync(tempDir)) {
            return reply(
              `📄 No images found.\n\nReply to an image with *${prefix}addpdf* first.`,
            );
          }
          const imageFiles = fs
            .readdirSync(tempDir)
            .filter((file) => /\.(jpg|jpeg|png|webp)$/i.test(file))
            .sort((a, b) => {
              const numA = parseInt(a);
              const numB = parseInt(b);
              return numA - numB;
            });
          if (!imageFiles.length) {
            return reply(
              `📄 No images found.\n\nReply to an image with *${prefix}addpdf* first.`,
            );
          }
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "📄", key: m.key },
          });
          const urls = [];
          for (const file of imageFiles) {
            const filePath = path.join(tempDir, file);
            const tempUrl = await uploadToEliteTempUrl(filePath);
            urls.push(tempUrl);
          }
          const query = urls
            .map((url) => `url=${encodeURIComponent(url)}`)
            .join("&");
          const apiUrl = `https://eliteprotech-apis.zone.id/tools/img2pdf?${query}`;
          const response = await axios.get(apiUrl, {
            responseType: "arraybuffer",
            timeout: 120000,
          });
          const fileName = text?.trim()
            ? text.trim().replace(/\.pdf$/i, "")
            : "Image";
          await EliteProTech.sendMessage(
            m.chat,
            {
              document: Buffer.from(response.data),
              mimetype: "application/pdf",
              fileName: `${fileName}.pdf`,
              caption:
                `📄 *PDF Created Successfully*\n\n` +
                `◆ File: ${fileName}.pdf\n` +
                `◆ Pages: ${imageFiles.length}`,
            },
            { quoted: m },
          );
          fs.rmSync(tempDir, {
            recursive: true,
            force: true,
          });
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (error) {
          console.error("IMG2PDF Error:", error);
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });
          reply("❌ Failed to create PDF.");
        }
        break;
      }
      case "clearpdf":
      case "resetpdf": {
        try {
          const tempDir = path.join(
            __dirname,
            "database",
            "temp",
            "pdf",
            m.sender.replace(/[^a-zA-Z0-9]/g, "_"),
          );
          if (!fs.existsSync(tempDir)) {
            return reply("📄 Your PDF collection is already empty.");
          }
          fs.rmSync(tempDir, {
            recursive: true,
            force: true,
          });
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "🗑️", key: m.key },
          });
          reply("✅ PDF image collection cleared.");
        } catch (error) {
          console.error("ClearPDF Error:", error);
          reply("❌ Failed to clear PDF collection.");
        }
        break;
      }
      case "xo":
      case "ttt":
      case "tictactoe":
        {
          try {
            if (!m.isGroup)
              return reply("❌ X AND O can only be played in groups.");
            global.xoGames = global.xoGames || new Map();
            const chat = m.chat;
            if (global.xoGames.has(chat)) {
              const oldGame = global.xoGames.get(chat);
              if (oldGame.listener)
                EliteProTech.ev.off("messages.upsert", oldGame.listener);
              if (oldGame.timeout) clearTimeout(oldGame.timeout);
              global.xoGames.delete(chat);
            }
            let metadata = await EliteProTech.groupMetadata(chat);
            const resolveUser = async (raw) => {
              if (!raw) return null;
              let participant = metadata.participants?.find(
                (p) =>
                  p.id === raw ||
                  p.lid === raw ||
                  p.jid === raw ||
                  p.pn === raw,
              );
              if (!participant) {
                try {
                  metadata = await EliteProTech.groupMetadata(chat);
                  participant = metadata.participants?.find(
                    (p) =>
                      p.id === raw ||
                      p.lid === raw ||
                      p.jid === raw ||
                      p.pn === raw,
                  );
                } catch {}
              }
              return (
                participant?.jid || participant?.pn || participant?.id || raw
              );
            };
            const firstPlayer = await resolveUser(m.sender);
            if (!firstPlayer) return reply("❌ Could not identify the player.");
            const game = {
              players: [firstPlayer],
              symbols: { [firstPlayer]: "❌" },
              board: Array(9).fill(""),
              turn: firstPlayer,
              messageId: null,
              listener: null,
              timeout: null,
              active: true,
            };
            global.xoGames.set(chat, game);
            const numbers = [
              "1️⃣",
              "2️⃣",
              "3️⃣",
              "4️⃣",
              "5️⃣",
              "6️⃣",
              "7️⃣",
              "8️⃣",
              "9️⃣",
            ];
            const wins = [
              [0, 1, 2],
              [3, 4, 5],
              [6, 7, 8],
              [0, 3, 6],
              [1, 4, 7],
              [2, 5, 8],
              [0, 4, 8],
              [2, 4, 6],
            ];
            const board =
              () => `${game.board[0] || numbers[0]} ${game.board[1] || numbers[1]} ${game.board[2] || numbers[2]}
${game.board[3] || numbers[3]} ${game.board[4] || numbers[4]} ${game.board[5] || numbers[5]}
${game.board[6] || numbers[6]} ${game.board[7] || numbers[7]} ${game.board[8] || numbers[8]}`;
            const getName = async (jid) => {
              const participant = metadata.participants?.find(
                (p) =>
                  p.jid === jid ||
                  p.pn === jid ||
                  p.id === jid ||
                  p.lid === jid,
              );
              return (participant?.pn || participant?.jid || jid).split("@")[0];
            };
            const sendBoard = async (quoted, text) => {
              const sent = await EliteProTech.sendMessage(
                chat,
                { text, mentions: game.players },
                { quoted },
              );
              if (sent?.key?.id) game.messageId = sent.key.id;
              return sent;
            };
            const cleanup = () => {
              game.active = false;
              if (game.listener)
                EliteProTech.ev.off("messages.upsert", game.listener);
              if (game.timeout) clearTimeout(game.timeout);
              global.xoGames.delete(chat);
            };
            const firstName = await getName(firstPlayer);
            const firstMessage = await EliteProTech.sendMessage(
              chat,
              {
                text: `🎮 *X AND O*
❌ @${firstPlayer.split("@")[0]}
⭕ Waiting for player...
${board()}
🎮 @${firstName} started the game.
↪️ *Reply to this message to join.*`,
                mentions: [firstPlayer],
              },
              { quoted: m },
            );
            game.messageId = firstMessage.key.id;
            const listener = async (update) => {
              try {
                if (!game.active) return;
                const msg = update.messages?.[0];
                if (!msg?.message) return;
                if (msg.key?.remoteJid !== chat) return;
                if (msg.key?.fromMe) return;
                const contextInfo =
                  msg.message.extendedTextMessage?.contextInfo ||
                  msg.message.imageMessage?.contextInfo ||
                  msg.message.videoMessage?.contextInfo ||
                  msg.message.documentMessage?.contextInfo ||
                  msg.message.audioMessage?.contextInfo;
                if (!contextInfo?.stanzaId) return;
                if (contextInfo.stanzaId !== game.messageId) return;
                const replyText =
                  msg.message.conversation ||
                  msg.message.extendedTextMessage?.text ||
                  msg.message.imageMessage?.caption ||
                  msg.message.videoMessage?.caption ||
                  msg.message.documentMessage?.caption ||
                  "";
                const rawSender = msg.key.participant || msg.key.participantAlt;
                if (!rawSender) return;
                const sender = await resolveUser(rawSender);
                if (!sender) return;
                if (game.players.length === 1) {
                  if (sender === game.players[0]) return;
                  game.players.push(sender);
                  game.symbols[sender] = "⭕";
                  const playerOne = await getName(game.players[0]);
                  await sendBoard(
                    msg,
                    `🎮 *X AND O*
❌ @${game.players[0].split("@")[0]}
⭕ @${game.players[1].split("@")[0]}
${board()}
🎮 *Game started!*
❌ @${playerOne}'s turn.
↪️ *Reply to this message with 1-9.*`,
                  );
                  return;
                }
                if (!game.players.includes(sender)) return;
                if (sender !== game.turn) {
                  const turnName = await getName(game.turn);
                  await EliteProTech.sendMessage(
                    chat,
                    {
                      text: `⏳ It's @${turnName}'s turn.`,
                      mentions: [game.turn],
                    },
                    { quoted: msg },
                  );
                  return;
                }
                const position = parseInt(replyText.trim(), 10) - 1;
                if (
                  !Number.isInteger(position) ||
                  position < 0 ||
                  position > 8
                ) {
                  await EliteProTech.sendMessage(
                    chat,
                    {
                      text: "❌ Invalid move.\n\n↪️ Reply to a number from 1-9.",
                    },
                    { quoted: msg },
                  );
                  return;
                }
                if (game.board[position]) {
                  await EliteProTech.sendMessage(
                    chat,
                    { text: "❌ That position is already occupied." },
                    { quoted: msg },
                  );
                  return;
                }
                const symbol = game.symbols[sender];
                game.board[position] = symbol;
                const won = wins.some(
                  ([a, b, c]) =>
                    game.board[a] === symbol &&
                    game.board[b] === symbol &&
                    game.board[c] === symbol,
                );
                if (won) {
                  const winner = await getName(sender);
                  await EliteProTech.sendMessage(
                    chat,
                    {
                      text: `🎮 *X AND O*
${board()}
🏆 ${symbol} @${winner} *WINS!*`,
                      mentions: [sender],
                    },
                    { quoted: msg },
                  );
                  cleanup();
                  return;
                }
                if (game.board.every(Boolean)) {
                  await EliteProTech.sendMessage(
                    chat,
                    {
                      text: `🎮 *X AND O*
${board()}
🤝 *DRAW!*`,
                    },
                    { quoted: msg },
                  );
                  cleanup();
                  return;
                }
                game.turn = game.players.find((player) => player !== sender);
                const playerName = await getName(sender);
                const nextName = await getName(game.turn);
                await sendBoard(
                  msg,
                  `🎮 *X AND O*
${board()}
${symbol} @${playerName} played.
➡️ Turn: ${game.symbols[game.turn]} @${nextName}
↪️ *Reply to this message with 1-9.*`,
                );
              } catch (err) {
                console.error("XO REPLY ERROR:", err);
              }
            };
            game.listener = listener;
            EliteProTech.ev.on("messages.upsert", listener);
            game.timeout = setTimeout(
              () => {
                if (!game.active) return;
                cleanup();
                EliteProTech.sendMessage(chat, {
                  text: "⌛ *X AND O*\n\nThe game has ended because there were no moves for 10 minutes.",
                }).catch(() => {});
              },
              10 * 60 * 1000,
            );
          } catch (err) {
            console.error("XO ERROR:", err);
            reply(`❌ ${err.message}`);
          }
        }
        break;
      case "joingc":
        try {
          if (!isCreator) return reply(mess.owner);
          if (!text) return reply("Enter Group Link!");
          if (!isUrl(args[0]) && !args[0].includes("whatsapp.com"))
            return reply("Link Invalid!");
          reply(mess.wait);
          let result = args[0].split("https://chat.whatsapp.com/")[1];
          await EliteProTech.groupAcceptInvite(result)
            .then((res) => reply(json(res)))
            .catch((err) => reply(json(err)));
        } catch {
          reply("Failed to join the Group");
        }
        break;
      case "sessionid":
      case "mysession":
      case "getsession":
        if (!isCreator) return reply(mess.owner);
        reply("Wait a moment, currently retrieving your session file");
        let sesi = await fs.readFileSync("./session/creds.json");
        EliteProTech.sendMessage(
          m.chat,
          {
            document: sesi,
            mimetype: "application/json",
            fileName: "creds.json",
          },
          {
            quoted: m,
          },
        );
        break;
      case "reboot":
      case "reload":
      case "restart":
        if (!isCreator) return reply(mess.owner);
        reply(`*Restarting will be completed in a few seconds.*`);
        await sleep(3000);
        process.exit();
        break;
      case "autobluetick":
      case "autobt":
      case "autotick":
      case "autoread":
        if (!isCreator) return reply(mess.owner);
        if (args.length < 1) return reply(`Example ${prefix + command} on/off`);
        if (q === "on") {
          autoread = true;
          reply(`Successfully changed autoread to ${q}`);
        } else if (q === "off") {
          autoread = false;
          reply(`Successfully changed autoread to ${q}`);
        }
        break;
      case "autotext":
      case "faketyping":
      case "autotyping":
        if (!isCreator) return reply(mess.owner);
        if (args.length < 1) return reply(`Example ${prefix + command} on/off`);
        if (q === "on") {
          global.autoTyping = true;
          saveSettings();
          reply(`Successfully changed auto-typing to ${q}`);
        } else if (q === "off") {
          global.autoTyping = false;
          saveSettings();
          reply(`Successfully changed auto-typing to ${q}`);
        } else {
          return reply(`ℹ️ ${prefix + command} on|off`);
        }
        break;
      case "autorecord":
      case "record":
      case "autorecording":
        if (!isCreator) return reply(mess.owner);
        if (args.length < 1) return reply(`Example ${prefix + command} on/off`);
        if (q === "on") {
          global.autoRecording = true;
          saveSettings();
          reply(`Successfully changed auto-recording to ${q}`);
        } else if (q === "off") {
          global.autoRecording = false;
          saveSettings();
          reply(`Successfully changed auto-recording to ${q}`);
        } else {
          return reply(`ℹ️ ${prefix + command} on|off`);
        }
        break;
      case "recordtype":
      case "fakerecordtype":
      case "autorecordtype":
        if (!isCreator) return reply(mess.owner);
        if (args.length < 1) return reply(`Example ${prefix + command} on/off`);
        if (q === "on") {
          global.autorecordtype = true;
          saveSettings();
          reply(`Successfully changed auto recording and typing to ${q}`);
        } else if (q === "off") {
          global.autorecordtype = false;
          saveSettings();
          reply(`Successfully changed auto recording and typing to ${q}`);
        } else {
          return reply(`ℹ️ ${prefix + command} on|off`);
        }
        break;
      case "autoviewstatus":
      case "asv":
      case "viewstatus":
      case "statusview":
      case "autostatusview":
        {
          if (!isCreator) return reply(mess.owner);
          if (args.length < 1)
            return reply(`Example ${prefix + command} on/off`);
          if (args[0] === "on") {
            global.autoviewstatus = true;
            saveSettings();
            reply(`📊 Autostatusview has been enabled.`);
          } else if (args[0] === "off") {
            global.autoviewstatus = false;
            saveSettings();
            reply(`📛 Autostatusview has been disabled.`);
          } else {
            return reply(`ℹ️ ${prefix + command} on|off`);
          }
        }
        break;
      case "autobio":
        if (!isCreator) return reply(mess.owner);
        if (args.length < 1) return reply(`Example ${prefix + command} on/off`);
        if (q == "on") {
          global.autobio = true;
          saveSettings();
          reply(`Successfully Changed AutoBio To ${q}`);
        } else if (q == "off") {
          global.autobio = false;
          saveSettings();
          reply(`Successfully Changed AutoBio To ${q}`);
        } else {
          return reply(`ℹ️ ${prefix + command} on|off`);
        }
        break;
      case "botmode":
      case "setmode":
      case "mode":
        {
          if (!isCreator) return reply(mess.owner);

          if (!text)
            return reply(
              `Mode: ${EliteProTech.public ? "public" : "private"} | Options: ${prefix}mode private → PRIVATE, ${prefix}mode public → PUBLIC`,
            );

          let input = text.toLowerCase();

          if (!["public", "private"].includes(input)) {
            return reply(`Use:\n${prefix}mode public\n${prefix}mode private`);
          }

          EliteProTech.public = input === "public";

          global.botMode = input;
          saveSettings();

          await EliteProTech.sendMessage(from, {
            react: {
              text: "✅",
              key: m.key,
            },
          });

          return reply(`Mode changed to ${input}`);
        }
        break;
      case "setexif":
        if (!isCreator) return reply(mess.owner);
        if (!text)
          return reply(`Example : ${prefix + command} packname|author`);
        global.packname = text.split("|")[0];
        global.author = text.split("|")[1];
        reply(
          `Exif changed to\n\n• Packname : ${global.packname}\n• Author : ${global.author}`,
        );
        break;
      case "setpp":
      case "setppbot":
      case "setbotpp":
        {
          if (!isCreator) return reply(mess.owner);
          if (!quoted)
            return reply(`Send/Reply image with caption ${prefix + command}`);
          if (!/image/.test(mime))
            return reply(`Send/Reply image with caption ${prefix + command}`);
          if (/webp/.test(mime))
            return reply(`Send/Reply image with caption ${prefix + command}`);

          const medis = await EliteProTech.downloadAndSaveMediaMessage(
            quoted,
            "ppbot.jpeg",
          );

          if (args[0] === "full") {
            const { img } = await generateProfilePicture(medis);

            await EliteProTech.query({
              tag: "iq",
              attrs: {
                to: botNumber,
                type: "set",
                xmlns: "w:profile:picture",
              },
              content: [
                {
                  tag: "picture",
                  attrs: { type: "image" },
                  content: img,
                },
              ],
            });

            fs.unlinkSync(medis);
            resetStatusQuote();
            warmStatusQuote(EliteProTech, botNumber).catch(() => {});
            reply(mess.done);
          } else {
            await EliteProTech.updateProfilePicture(botNumber, { url: medis });
            fs.unlinkSync(medis);
            resetStatusQuote();
            warmStatusQuote(EliteProTech, botNumber).catch(() => {});
            reply(mess.done);
          }
        }
        break;
      case "blockuser":
      case "block":
        {
          if (!isCreator) return reply(mess.owner);

          let target = m.mentionedJid[0]
            ? m.mentionedJid[0]
            : m.quoted
              ? m.quoted.sender
              : text && text.match(/[0-9]+/)
                ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
                : !m.isGroup
                  ? m.chat
                  : null;

          if (!target) return reply(`_Unable to identify user to block._`);

          try {
            await EliteProTech.updateBlockStatus(target, "block");
            reply(`✅ Blocked: @${target.split("@")[0]}`, {
              mentions: [target],
            });
          } catch (err) {
            reply(`❌ Failed to block: ${err.message}`);
          }
        }
        break;
      case "unblockuser":
      case "unblock":
        {
          if (!isCreator) return reply(mess.owner);

          let target = m.mentionedJid[0]
            ? m.mentionedJid[0]
            : m.quoted
              ? m.quoted.sender
              : text && text.match(/[0-9]+/)
                ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
                : !m.isGroup
                  ? m.chat
                  : null;

          if (!target) return reply(`_Unable to identify user to unblock._`);

          try {
            await EliteProTech.updateBlockStatus(target, "unblock");
            reply(`✅ Unblocked: @${target.split("@")[0]}`, {
              mentions: [target],
            });
          } catch (err) {
            reply(`❌ Failed to unblock: ${err.message}`);
          }
        }
        break;
      case "left":
      case "bye":
      case "admincheck":
      case "checkadmin":
        {
          if (!isCreator) return reply(mess.owner);
          if (!m.isGroup) return reply(mess.group);
          const adminList = [];
          for (const p of participants) {
            if (p && (p.admin === "admin" || p.admin === "superadmin"))
              adminList.push(`${p.admin} · ${p.id || p.jid || p.pn || "?"}`);
          }
          reply(
            `*🔍 Admin check*\n\n` +
              `*Group:* ${groupName}\n` +
              `*Participants:* ${participants.length}\n` +
              `*Admins found:* ${adminList.length}\n` +
              `${adminList.map((a) => "• " + a).join("\n") || "• (none)"}\n\n` +
              `*Bot me:* ${isBotAdmins ? "✅ ADMIN" : "❌ not admin"}\n` +
              `*Bot ids:* ${_botCores.join(", ") || "-"}\n` +
              `*You:* ${isAdmins ? "✅ ADMIN" : "❌ not admin"}${isCreator ? " (owner)" : ""}\n` +
              `*Your ids:* ${_senderCores.join(", ") || "-"}`,
          );
        }
        break;
      case "leave":
        if (!isCreator) return reply(mess.owner);
        if (!m.isGroup) return reply(mess.group);
        await EliteProTech.groupLeave(m.chat);
        break;
      case "backup":
        if (!isCreator) return reply(mess.owner);
        if (m.isGroup) return reply(mess.private);
        reply(mess.wait);
        exec("zip backup.zip *");
        let malas = await fs.readFileSync("./backup.zip");
        await EliteProTech.sendMessage(
          m.chat,
          {
            document: malas,
            mimetype: "application/zip",
            fileName: "backup.zip",
          },
          {
            quoted: m,
          },
        );
        break;
      case "bcgc":
      case "bcgroup":
        {
          if (!isCreator) return reply(mess.owner);
          if (!text)
            return reply(
              `Which text?\n\nExample : ${prefix + command} It's holiday tomorrow `,
            );
          let getGroups = await EliteProTech.groupFetchAllParticipating();
          let groups = Object.entries(getGroups)
            .slice(0)
            .map((entry) => entry[1]);
          let anu = groups.map((v) => v.id);
          reply(
            `Send Broadcast To ${anu.length} Group Chat, End Time ${anu.length * 1.5} second`,
          );
          for (let i of anu) {
            await sleep(1500);
            let a = "```" + `\n\n${text}\n\n` + "```" + "\n\n\nʙʀᴏᴀᴅᴄᴀsᴛ";
            EliteProTech.sendMessage(i, {
              text: a,
              contextInfo: {
                externalAdReply: {
                  showAdAttribution: true,
                  title: "Broadcast By Pixel",
                  body: `Sent ${i.length} Group`,
                  thumbnailUrl:
                    "https://graph.org/file/3e81c19e2e4424a41eca2.jpg",
                  sourceUrl: global.link,
                  mediaType: 1,
                  renderLargerThumbnail: true,
                },
              },
            });
          }
          reply(`Successfully Sent Broadcast To ${anu.length} Group`);
        }
        break;
      case "getcase":
        {
          if (!isCreator) return reply(mess.owner);
          if (!q) return reply("❌ Provide a case name.");
          try {
            const data = fs.readFileSync("./Pixel.js", "utf8");
            const result = data.split(`case '${q}'`);
            if (result.length < 2) return reply("❌ Case not found.");
            const caseCode =
              "case '" + q + "'" + result[1].split("break")[0] + "break";
            reply(caseCode);
          } catch (err) {
            console.error(err);
            reply("❌ Failed to get case.");
          }
        }
        break;
      case "delmsg":
      case "delete":
      case "del":
        {
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply("This features can only be used by me or admins");
          if (!m.quoted) return reply("Reply to a message you want to delete.");

          let key = {
            remoteJid: m.chat,
            fromMe: m.quoted.fromMe,
            id: m.quoted.id,
            participant: m.isGroup ? m.quoted.sender : undefined,
          };

          await EliteProTech.sendMessage(m.chat, { delete: key });
        }
        break;
      case "closetime":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);

        let timerClose;
        const amountClose = Number(args[0]);
        const unitClose = args[1]?.toLowerCase();

        if (!amountClose || !unitClose) {
          return reply("*Usage:*\n10 second / minute / hour / day");
        }

        switch (unitClose) {
          case "second":
          case "detik":
            timerClose = amountClose * 1000;
            break;
          case "minute":
          case "menit":
            timerClose = amountClose * 60000;
            break;
          case "hour":
          case "jam":
            timerClose = amountClose * 3600000;
            break;
          case "day":
          case "hari":
            timerClose = amountClose * 86400000;
            break;
          default:
            return reply(
              "*Choose:*\nsecond\nminute\nhour\nday\n\n*Example:*\n10 second",
            );
        }

        reply(`Close time ${amountClose} ${unitClose} starting from now`);
        setTimeout(async () => {
          await EliteProTech.groupSettingUpdate(m.chat, "announcement");
          reply(
            "*Closed* — admins only.",
          );
        }, timerClose);
        break;
      case "opentime":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);

        let timerOpen;
        const amountOpen = Number(args[0]);
        const unitOpen = args[1]?.toLowerCase();

        if (!amountOpen || !unitOpen) {
          return reply("*Usage:*\n10 second / minute / hour / day");
        }

        switch (unitOpen) {
          case "second":
            timerOpen = amountOpen * 1000;
            break;
          case "minute":
            timerOpen = amountOpen * 60000;
            break;
          case "hour":
            timerOpen = amountOpen * 3600000;
            break;
          case "day":
            timerOpen = amountOpen * 86400000;
            break;
          default:
            return reply(
              "*Choose:*\nsecond\nminute\nhour\nday\n\n*Example:*\n10 second",
            );
        }

        reply(`Open time ${amountOpen} ${unitOpen} starting from now`);
        setTimeout(async () => {
          await EliteProTech.groupSettingUpdate(m.chat, "not_announcement");
          reply(
            "*Opened* — everyone can send.",
          );
        }, timerOpen);
        break;
      case "remove":
      case "out":
      case "kick": {
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        if (!text && !m.quoted && !m.mentionedJid.length) {
          return reply(
            "❌ Please mention or reply to the user you want to *kick*!",
          );
        }

        let target;

        if (m.mentionedJid[0]) {
          target = m.mentionedJid[0];
        } else if (m.quoted) {
          target = m.quoted.sender;
        } else {
          let number = text.replace(/[^0-9]/g, "");
          target = number + "@s.whatsapp.net";
        }

        const metadata = await EliteProTech.groupMetadata(m.chat);
        const participants = metadata.participants || [];

        let realJid = target;

        for (let p of participants) {
          if (p.id === target || p.lid === target || p.jid === target) {
            realJid = p.jid || p.pn;
            break;
          }
        }

        if (realJid.endsWith("@lid")) {
          let found = participants.find((p) => p.id === realJid);
          if (found) realJid = found.jid || found.pn;
        }

        let number = realJid.split("@")[0];

        try {
          await EliteProTech.groupParticipantsUpdate(
            m.chat,
            [realJid],
            "remove",
          );
          reply(`✅ ${number} has been removed!`);
        } catch (e) {
          console.error(e);
          reply(
            "❌ Remove failed.",
          );
        }
        break;
      }
      case "add": {
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);

        let target;
        let number = "";

        if (m.quoted) {
          target = m.quoted.sender;
          number = target.split("@")[0];
        } else if (text) {
          let num = text.replace(/[^0-9]/g, "");
          if (num.length < 8) return reply("❌ Invalid number");
          target = num + "@s.whatsapp.net";
          number = num;
        } else {
          return reply(
            "➕ Send a number or reply to the user you want to *add*!",
          );
        }

        try {
          await EliteProTech.groupParticipantsUpdate(m.chat, [target], "add");
          reply(`✅ ${number} has been added!`);
        } catch (e) {
          console.error(e);
          reply(
            "❌ Add failed.",
          );
        }
        break;
      }
      case "makeadmin":
      case "promote":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        if (!text && !m.quoted && !m.mentionedJid.length) {
          return reply(
            "⬆️ Mention who to promote.",
          );
        }

        let blockwwwww = m.mentionedJid[0]
          ? m.mentionedJid[0]
          : m.quoted
            ? m.quoted.sender
            : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

        await EliteProTech.groupParticipantsUpdate(
          m.chat,
          [blockwwwww],
          "promote",
        );

        await EliteProTech.sendMessage(m.chat, {
          react: {
            text: "✅",
            key: m.key,
          },
        });
        break;
      case "removeadmin":
      case "demote":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);

        if (!text && !m.quoted && !m.mentionedJid.length)
          return reply(
            "⬇️ Mention who to demote.",
          );

        let user = m.mentionedJid[0]
          ? m.mentionedJid[0]
          : m.quoted
            ? m.quoted.sender
            : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

        await EliteProTech.groupParticipantsUpdate(m.chat, [user], "demote");

        await EliteProTech.sendMessage(m.chat, {
          react: {
            text: "✅",
            key: m.key,
          },
        });
        break;
      case "setname":
      case "setsubject":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        if (!text) return reply("✏️ Send the new *group name*!");
        await EliteProTech.groupUpdateSubject(m.chat, text)
          .then(() => reply(mess.success))
          .catch((err) => reply(json(err)));
        break;
      case "setdesc":
      case "setdesk":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply(mess.admin);
          if (!isBotAdmins) return reply(mess.botAdmin);
          if (!q)
            return reply("📝 Send the new *group description*!");

          try {
            await EliteProTech.groupUpdateDescription(m.chat, q);
            reply("✅ Done changed the group description");
          } catch (err) {
            reply(JSON.stringify(err));
          }
        }
        break;
      case "setgrouppicture":
      case "setgrouppp":
      case "setppgc":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        if (!quoted)
          return reply(`Send/Reply Image With Caption ${prefix + command}`);
        if (!/image/.test(mime))
          return reply(`Send/Reply Image With Caption ${prefix + command}`);
        if (/webp/.test(mime))
          return reply(`Send/Reply Image With Caption ${prefix + command}`);
        var medis = await EliteProTech.downloadAndSaveMediaMessage(
          quoted,
          "ppbot.jpeg",
        );
        if (args[0] == "full") {
          var { img } = await generateProfilePicture(medis);
          await EliteProTech.query({
            tag: "iq",
            attrs: {
              to: m.chat,
              type: "set",
              xmlns: "w:profile:picture",
            },
            content: [
              {
                tag: "picture",
                attrs: {
                  type: "image",
                },
                content: img,
              },
            ],
          });
          fs.unlinkSync(medis);
          reply(mess.done);
        } else {
          var memeg = await EliteProTech.updateProfilePicture(m.chat, {
            url: medis,
          });
          fs.unlinkSync(medis);
          reply(mess.done);
        }
        break;
      case "tag":
      case "mentionall":
      case "tagall": {
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        const adminName = pushname || "Admin";
        const message = q || "Hello everyone 👋";
        const mentions = [];
        let teks = `👤 *BY:* ${adminName}
💬 *MSG:* ${message}

`;
        for (const mem of participants) {
          teks += `➤ @${mem.id.split("@")[0]}\n`;
          mentions.push(mem.id);
        }
        await EliteProTech.sendMessage(
          m.chat,
          {
            text: teks.trim(),
            mentions,
          },
          { quoted: m },
        );
        break;
      }
      case "tag-all":
      case "alltag":
      case "all":
      case "everyone": {
        if (!m.isGroup) return reply(mess.group);
        if (!isCreator) return reply(mess.owner);

        const subject = q ? q : "Hello everyone 👋";

        await EliteProTech.sendMessage(
          m.chat,
          {
            text: "@" + m.chat,
            contextInfo: {
              mentionedJid: participants.map((x) => x.id),
              groupMentions: [
                {
                  groupJid: m.chat,
                  groupSubject: subject,
                },
              ],
            },
          },
          { quoted: m },
        );

        break;
      }
      case "hidetag":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        EliteProTech.sendMessage(
          m.chat,
          {
            text: q ? q : "",
            mentions: participants.map((a) => a.id),
          },
          {
            quoted: m,
          },
        );
        break;
      case "totag":
        if (!m.isGroup) return reply(mess.group);
        if (!isBotAdmins) return reply(mess.botAdmin);
        if (!isAdmins) return reply(mess.admin);
        if (!m.quoted)
          return reply(`Reply messages with captions ${prefix + command}`);
        EliteProTech.sendMessage(m.chat, {
          forward: m.quoted.fakeObj,
          mentions: participants.map((a) => a.id),
        });
        break;
      case "gc":
      case "group":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        if (args[0] === "close") {
          await EliteProTech.groupSettingUpdate(m.chat, "announcement")
            .then((res) =>
              reply(
                `🔒 Group has been *closed* — only admins can send messages.`,
              ),
            )
            .catch((err) => reply(json(err)));
        } else if (args[0] === "open") {
          await EliteProTech.groupSettingUpdate(m.chat, "not_announcement")
            .then((res) =>
              reply(
                `✅ Group has been *opened* — members can now send messages.`,
              ),
            )
            .catch((err) => reply(json(err)));
        } else {
          reply(
            `⚙️ Usage: - *${prefix + command} open - ${prefix + command} close*`,
          );
        }
        break;
      case "editinfo":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        if (args[0] === "open") {
          await EliteProTech.groupSettingUpdate(m.chat, "unlocked")
            .then((res) => reply(`Successfully Opened Group Edit Info🧑‍💻️`))
            .catch((err) => reply(json(err)));
        } else if (args[0] === "close") {
          await EliteProTech.groupSettingUpdate(m.chat, "locked")
            .then((res) => reply(`Successfully Closed Group Edit Info🕊️`))
            .catch((err) => reply(json(err)));
        } else {
          reply(`Mode ${command}\n\n\nType ${prefix + command}on/off`);
        }
        break;
      case "gclink":
      case "link":
      case "grouplink":
      case "invitelink":
      case "sendinvite":
      case "invite":
        {
          if (!m.isGroup) return reply(mess.group);
          if (!isAdmins && !isGroupOwner && !isCreator)
            return reply(mess.admin);
          if (!isBotAdmins) return reply(mess.botAdmin);
          const inviteCode = await EliteProTech.groupInviteCode(m.chat);
          const groupLink = `https://chat.whatsapp.com/${inviteCode}`;
          let groupPic;
          try {
            groupPic = await EliteProTech.profilePictureUrl(m.chat, "image");
          } catch {
            groupPic =
              "https://eliteprotech-url.zone.id/1766280889140k1p5o0.jpg";
          }
          await sendButtons(
            EliteProTech,
            m.chat,
            {
              image: { url: groupPic },
              text: `👥 *${groupMetadata.subject}*

Invite your friends using the link below.

🔗 ${groupLink}

👇 Tap the *Join Group* button below to join instantly or copy the invite link to share with others.`,
              footer: "ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ",
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Join Group 👥",
                    url: groupLink,
                    merchant_url: groupLink,
                  }),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Copy Link 📋",
                    copy_code: groupLink,
                  }),
                },
              ],
            },
            { quoted: m },
          );
          break;
        }
        break;
      case "revoke":
      case "resetlink":
        if (!m.isGroup) return reply(mess.group);
        if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin);
        if (!isBotAdmins) return reply(mess.botAdmin);
        await EliteProTech.groupRevokeInvite(m.chat)
          .then((res) => {
            reply(
              `Successful Reset, Group Invite Link ${groupMetadata.subject}`,
            );
          })
          .catch((err) => reply(json(err)));
        break;
      case "runtime":
      case "botuptime":
      case "up":
      case "uptime": {
        await EliteProTech.sendMessage(m.chat, {
          react: { text: "⚙️", key: m.key },
        });
        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);
        const msg = generateWAMessageFromContent(
          m.chat,
          {
            pollResultSnapshotMessage: {
              name: "Runtime Info",
              pollVotes: [
                {
                  optionName: "Runtime (Hours)",
                  optionVoteCount: String(hours),
                },
                {
                  optionName: "Runtime (Minutes)",
                  optionVoteCount: String(minutes),
                },
                {
                  optionName: "Runtime (Seconds)",
                  optionVoteCount: String(seconds),
                },
              ],
            },
          },
          {
            userJid: EliteProTech.user.id,
            quoted: m,
          },
        );
        await EliteProTech.relayMessage(m.chat, msg.message, {
          messageId: msg.key.id,
        });
        break;
      }
      case "sc":
      case "script":
      case "repo":
        {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          try {
            const repoOwner = "EliteProTech";
            const repoName = "ELITE-PRO-V1";
            const apiUrl = `https://api.github.com/repos/${repoOwner}/${repoName}`;

            const { data: repo } = await axios.get(apiUrl);
            const repoMessage = `*ELITE-PRO-V1 Repository*

${repo.description || "No description provided"}.

- *Repository:* ${repo.name}
- *Owner:* ${repo.owner.login}
- *Stars:* ${repo.stargazers_count}
- *Forks:* ${repo.forks_count}

Community: https://t.me/eliteprotechs

*Repository:* ${repo.html_url}`;

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: {
                  url: `https://opengraph.githubassets.com/1/${repoOwner}/${repoName}`,
                },
                caption: repoMessage,
                contextInfo: {
                  forwardingScore: 5,
                  isForwarded: true,
                  forwardedNewsletterMessageInfo: {
                    newsletterName: "ᴘɪxᴇʟ-ᴛᴇᴄʜ-ꜱᴜᴘᴘᴏʀᴛ",
                    newsletterJid: "120363287352245413@newsletter",
                  },
                },
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });
          } catch (error) {
            console.log("Repo error:", error.message);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            await EliteProTech.sendMessage(
              m.chat,
              {
                text: `*BOT INFORMATION*

⭐ Fork & Star:
https://github.com/EliteProTech/ELITE-PRO-V1/fork

🎥 YouTube:
https://www.youtube.com/@eliteprotechs`,
              },
              { quoted: m },
            );
          }
        }
        break;
      case "creator":
      case "dev":
      case "botowner":
      case "owner": {
        try {
          const ownerNumber = EliteProTech.user.id.split("@")[0].split(":")[0];
          const displayNumber = `+${ownerNumber}`;
          const ownerName = EliteProTech.user.name || displayNumber;
          const vcard = `BEGIN:VCARD
VERSION:3.0
N:;${ownerName};;;
FN:${ownerName}
TEL;type=CELL;type=VOICE;waid=${ownerNumber}:${displayNumber}
X-WA-BIZ-NAME:${ownerName}
X-WA-BIZ-DESCRIPTION:Yo here's my contact
END:VCARD`;
          await EliteProTech.sendMessage(
            m.chat,
            {
              contacts: {
                displayName: ownerName,
                contacts: [
                  {
                    displayName: ownerName,
                    vcard,
                  },
                ],
              },
            },
            { quoted: m },
          );
        } catch (err) {
          console.error("Owner Contact Error:", err);
          reply("❌ Failed to send creator contact.");
        }
        break;
      }
      case "sticker":
      case "stiker":
      case "s":
        {
          try {
            const ffmpegPath = require("@ffmpeg-installer/ffmpeg").path;
            const ffmpeg = require("fluent-ffmpeg");
            ffmpeg.setFfmpegPath(ffmpegPath);

            if (!m.quoted)
              return reply(
                `Reply to an image or video with the caption ${prefix + command}`,
              );

            let mime = (m.quoted.msg || m.quoted).mimetype || "";

            if (/image/.test(mime)) {
              let media = await m.quoted.download();
              let encmedia = await EliteProTech.sendImageAsSticker(
                m.chat,
                media,
                m,
                {
                  packname: packname,
                  author: author,
                },
              );
              await fs.unlinkSync(encmedia);
            } else if (/video/.test(mime)) {
              if (((m.quoted.msg || m.quoted).seconds || 0) > 11)
                return reply("Maximum video length for sticker is 10 seconds!");

              let media = await m.quoted.download();
              let encmedia = await EliteProTech.sendVideoAsSticker(
                m.chat,
                media,
                m,
                {
                  packname: packname,
                  author: author,
                },
              );
              await fs.unlinkSync(encmedia);
            } else {
              return reply(
                `Send or reply to an image/video with the caption ${prefix + command}\n(Video must be 1–9 seconds)`,
              );
            }
          } catch (err) {
            console.error(err);
            reply(`❌ Error creating sticker: ${err.message}`);
          }
        }
        break;
      case "smeme":
        {
          let respond = `Send/Reply image/sticker with caption ${prefix + command} text1|text2`;
          if (!/image/.test(mime)) return reply(respond);
          if (!text) return reply(respond);
          reply(mess.wait);
          atas = text.split("|")[0] ? text.split("|")[0] : "-";
          bawah = text.split("|")[1] ? text.split("|")[1] : "-";
          let dwnld = await EliteProTech.downloadAndSaveMediaMessage(qmsg);
          let fatGans = await TelegraPh(dwnld);
          let smeme = `https://api.memegen.link/images/custom/${encodeURIComponent(bawah)}/${encodeURIComponent(atas)}.png?background=${fatGans}`;
          let pop = await EliteProTech.sendImageAsSticker(m.chat, smeme, m, {
            packname: packname,
            author: author,
          });
          fs.unlinkSync(pop);
        }
        break;
      case "swm":
      case "steal":
      case "stickerwm":
      case "take":
        {
          if (!quoted) return reply(`Reply to an image/video`);

          const swn = args.join(" ").trim();
          const [pack, author] = swn.split("|");

          const pcknm = pack || global.packname;
          const atnm = author || global.author;

          if (quoted.isAnimated) {
            const media = await EliteProTech.downloadAndSaveMediaMessage(
              quoted,
              "./database/temp/gifee",
            );

            await EliteProTech.sendMessage(
              from,
              { sticker: fs.readFileSync(media) },
              { quoted: m },
            );

            fs.unlinkSync(media);
          } else if (/image/.test(mime)) {
            const media = await quoted.download();

            await EliteProTech.sendImageAsSticker(m.chat, media, m, {
              packname: pcknm,
              author: atnm,
            });
          } else if (/video/.test(mime)) {
            if ((quoted.msg || quoted).seconds > 10)
              return reply("Maximum 10 Seconds!");

            const media = await EliteProTech.downloadAndSaveMediaMessage(
              quoted,
              "./database/temp/sticker_video",
            );

            await EliteProTech.sendVideoAsSticker(m.chat, media, m, {
              packname: pcknm,
              author: atnm,
            });

            fs.unlinkSync(media);
          } else {
            reply(`Reply to an image/video`);
          }
        }
        break;
      case "toimage":
      case "toimg":
        {
          try {
            const msg = `✳️ Reply to a *sticker* with:\n\n*${prefix + command}*`;

            if (!m.quoted) return reply(msg);

            const q = m.quoted;
            const mime = q.mimetype || q.mediaType || "";

            if (!/webp/.test(mime)) {
              return reply(msg);
            }

            const media = await q.download().catch(() => null);
            if (!media) {
              return reply("❌ Failed to download the sticker.");
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                image: media,
                caption: "✅ Done converting",
              },
              { quoted: m },
            );
          } catch (err) {
            console.error("toimg Error:", err);
            reply("❌ Failed to convert sticker to image.");
          }
        }
        break;
      case "tomp4":
      case "tovideo": {
        const mime = (
          qmsg?.mimetype ||
          qmsg?.msg?.mimetype ||
          ""
        ).toLowerCase();

        if (!mime || !/video|gif|webp/.test(mime)) {
          return reply(
            `Send or reply to a sticker, video or gif with caption *${prefix + command}*`,
          );
        }

        let media;
        const tempDir = "./database/temp";

        try {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "⏳", key: m.key },
          });

          if (!fs.existsSync(tempDir))
            fs.mkdirSync(tempDir, { recursive: true });

          media = await EliteProTech.downloadAndSaveMediaMessage(
            qmsg,
            `${tempDir}/${Date.now()}`,
          );

          let result;

          if (/webp/.test(mime)) {
            const webpToMp4 = await webp2mp4File(media);
            if (!webpToMp4 || !webpToMp4.result)
              throw new Error("webp2mp4 conversion failed");
            result = { url: webpToMp4.result };
          } else {
            result = fs.readFileSync(media);
          }

          await EliteProTech.sendMessage(
            m.chat,
            {
              video: result,
              mimetype: "video/mp4",
              caption: "Converted To MP4",
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (err) {
          console.error("tomp4 error:", err);

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });

          reply(`Failed to process media.\n${err?.message || err}`);
        } finally {
          if (media && fs.existsSync(media)) fs.unlinkSync(media);
        }

        break;
      }
      case "toaud":
      case "toaudio": {
        if (!mime || (!/video/.test(mime) && !/audio/.test(mime))) {
          return reply(
            `Send or reply a video/audio with caption ${prefix + command}`,
          );
        }

        await EliteProTech.sendMessage(m.chat, {
          react: { text: "⏳", key: m.key },
        });

        try {
          const media = await EliteProTech.downloadMediaMessage(qmsg);
          const audio = await toAudio(media, "mp4");

          await EliteProTech.sendMessage(
            m.chat,
            {
              audio: audio,
              mimetype: "audio/mpeg",
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (err) {
          console.error(err);

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });

          reply("Failed to convert media to audio.");
        }

        break;
      }
      case "videonote":
      case "tovideonote": {
        if (!mime || !/video/.test(mime)) {
          return reply(
            `Send or reply a video with caption ${prefix + command}`,
          );
        }

        await EliteProTech.sendMessage(m.chat, {
          react: { text: "⏳", key: m.key },
        });

        try {
          const media = await EliteProTech.downloadMediaMessage(qmsg);

          await EliteProTech.sendMessage(
            m.chat,
            {
              video: media,
              mimetype: "video/mp4",
              ptv: true,
            },
            { quoted: m },
          );

          await EliteProTech.sendMessage(m.chat, {
            react: { text: "✅", key: m.key },
          });
        } catch (err) {
          await EliteProTech.sendMessage(m.chat, {
            react: { text: "❌", key: m.key },
          });

          reply("Failed to convert video to video note.");
        }

        break;
      }
      case "extractaudio":
      case "mp3":
      case "tomp3":
        {
          if (!/video/.test(mime) && !/audio/.test(mime))
            return reply(
              `Send/Reply Video/Audio that you want to make into MP3 with caption ${prefix + command}`,
            );
          reply(mess.wait);
          let media = await EliteProTech.downloadMediaMessage(qmsg);
          let audio = await toAudio(media, "mp4");
          EliteProTech.sendMessage(
            m.chat,
            {
              document: audio,
              mimetype: "audio/mp3",
              fileName: `Elite.mp3`,
            },
            {
              quoted: m,
            },
          );
        }
        break;
      case "tovn":
      case "toptt":
        {
          if (!/video/.test(mime) && !/audio/.test(mime))
            return reply(
              `Reply Video/Audio that you want to make into a VN with caption ${prefix + command}`,
            );
          reply(mess.wait);
          let media = await EliteProTech.downloadMediaMessage(qmsg);
          let { toPTT } = require("./lib/converter");
          let audio = await toPTT(media, "mp4");
          EliteProTech.sendMessage(
            m.chat,
            {
              audio: audio,
              mimetype: "audio/mpeg",
              ptt: true,
            },
            {
              quoted: m,
            },
          );
        }
        break;
      case "togif":
        {
          if (!mime)
            return reply(
              `Reply to a sticker or video with caption *${prefix + command}*`,
            );

          try {
            await EliteProTech.sendMessage(m.chat, {
              react: { text: "⏳", key: m.key },
            });

            const media = await EliteProTech.downloadAndSaveMediaMessage(qmsg);

            let result;

            if (/webp/i.test(mime)) {
              const webpToMp4 = await webp2mp4File(media);
              result = webpToMp4.result;
            } else if (/video/i.test(mime)) {
              result = media;
            } else {
              fs.unlinkSync(media);
              return reply("Only sticker or video is supported");
            }

            await EliteProTech.sendMessage(
              m.chat,
              {
                video: { url: result },
                gifPlayback: true,
                caption: "Converted To GIF",
              },
              { quoted: m },
            );

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "✅", key: m.key },
            });

            fs.unlinkSync(media);
          } catch (e) {
            console.error(e);

            await EliteProTech.sendMessage(m.chat, {
              react: { text: "❌", key: m.key },
            });

            reply("Failed to convert to GIF");
          }
        }
        break;
      case "emojimix":
        {
          try {
            let [emoji1, emoji2] = text.split("+");
            if (!emoji1 || !emoji2) {
              return reply(`Example : ${prefix + command} 😅+🤔`);
            }

            reply(mess.wait);

            let api = `https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`;

            let anu = await fetchJson(api);

            if (!anu.results || anu.results.length === 0) {
              return reply("❌ Emoji mix not found.");
            }

            let imageUrl = anu.results[0].media_formats?.png_transparent?.url;
            if (!imageUrl) return reply("❌ Emoji mix not found.");

            let buffer = await getBuffer(imageUrl);

            await EliteProTech.sendImageAsSticker(m.chat, buffer, m, {
              packname: global.packname,
              author: global.author,
            });
          } catch (err) {
            console.log("EmojiMix Error:", err);
            reply("❌ Error creating emoji mix.");
          }
        }
        break;
      case "toonce":
      case "toviewonce":
        {
          if (!quoted) return reply(`Reply Image/Video`);
          if (/image/.test(mime)) {
            anuan = await EliteProTech.downloadAndSaveMediaMessage(quoted);
            EliteProTech.sendMessage(
              m.chat,
              {
                image: {
                  url: anuan,
                },
                caption: `Here you go!`,
                fileLength: "999",
                viewOnce: true,
              },
              {
                quoted: m,
              },
            );
          } else if (/video/.test(mime)) {
            anuanuan = await EliteProTech.downloadAndSaveMediaMessage(quoted);
            EliteProTech.sendMessage(
              m.chat,
              {
                video: {
                  url: anuanuan,
                },
                caption: `Here you go!`,
                fileLength: "99999999",
                viewOnce: true,
              },
              {
                quoted: m,
              },
            );
          }
        }
        break;
      case "toqr":
      case "qrcode":
      case "qr":
        {
          if (!q) return reply("Please include link or text!");

          try {
            const qrcode = require("qrcode");

            const qrBuffer = await qrcode.toBuffer(q, {
              scale: 35,
            });

            await EliteProTech.sendMessage(
              from,
              {
                image: qrBuffer,
                caption: "Here you go!",
              },
              {
                quoted: m,
              },
            );
          } catch (error) {
            console.log(error);
            reply("Failed to generate QR code");
          }
        }
        break;
      case "fliptext":
        {
          if (args.length < 1)
            return reply(`Example:\n${prefix}fliptext ElitPro`);
          quere = args.join(" ");
          flipe = quere.split("").reverse().join("");
          reply(
            `\`\`\`「 FLIP TEXT 」\`\`\`\n*•> Normal :*\n${quere}\n*•> Flip :*\n${flipe}`,
          );
        }
        break;
      case "addowner":
      case "addmod":
      case "setsudo":
      case "addsudo":
        {
          if (!isCreator) return reply(mess.owner);
          const rawOwner = q.split("|")[0].trim().toLowerCase();
          if (!rawOwner)
            return reply(
              `Use ${prefix + command} number or LID\nExamples:\n${prefix + command} 2347047504860\n${prefix + command} 123456789@lid`,
            );
          let ownerId;
          if (rawOwner.endsWith("@lid")) {
            ownerId = normalizeOwnerId(rawOwner);
            if (!/^\d+@lid$/.test(ownerId))
              return reply("Use a valid LID, for example: 123456789@lid");
          } else {
            ownerId = rawOwner.replace(/[^0-9]/g, "");
            if (!ownerId) return reply("Use a valid phone number or LID");
            const ceknye = await EliteProTech.onWhatsApp(ownerId);
            if (ceknye.length === 0)
              return reply("Enter a valid WhatsApp number");
          }
          if (owner.includes(ownerId))
            return reply("That owner is already added");
          owner.push(ownerId);
          _owner.push(ownerId);
          fs.writeFileSync(
            "./database/owner.json",
            JSON.stringify(owner, null, 2),
          );
          reply(`✅ ${ownerId} is now an owner`);
        }
        break;
      case "delowner":
      case "deletesudo":
      case "deleteowner":
      case "removesudo":
      case "delsudo":
      case "removemod":
      case "delmod":
        {
          if (!isCreator) return reply(mess.owner);
          const rawOwner = q.split("|")[0].trim().toLowerCase();
          if (!rawOwner) return reply(`Use ${prefix + command} number or LID`);
          if (rawOwner === "all") {
            const keep = [cleanId, cleanLid].filter(Boolean);
            const removable = owner.filter((o) => !keep.includes(o));
            if (!removable.length) return reply("ℹ️ No extra sudo users");
            for (const o of removable) {
              let i = owner.indexOf(o);
              if (i !== -1) owner.splice(i, 1);
              i = _owner.indexOf(o);
              if (i !== -1) _owner.splice(i, 1);
            }
            fs.writeFileSync("./database/owner.json", JSON.stringify(owner, null, 2));
            return reply(`✅ All sudo removed · ${removable.length}`);
          }
          const ownerId = rawOwner.endsWith("@lid")
            ? normalizeOwnerId(rawOwner)
            : rawOwner.replace(/[^0-9]/g, "");
          const index = owner.indexOf(ownerId);
          if (index === -1) return reply("That owner was not found");
          owner.splice(index, 1);
          const cacheIndex = _owner.indexOf(ownerId);
          if (cacheIndex !== -1) _owner.splice(cacheIndex, 1);
          fs.writeFileSync(
            "./database/owner.json",
            JSON.stringify(owner, null, 2),
          );
          reply(`✅ ${ownerId} was removed from the owner list`);
        }
        break;
      case "emptychat":
        EliteProTech.sendMessage(
          from,
          {
            text: "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
            mentions: [sender],
          },
          { quoted: m },
        );
        break;
      case "mainmenu":
      case "defaultmenu":
      case "convertmenu":
      case "animemenu":
      case "funmenu":
      case "mediamenu":
      case "moviesmenu":
      case "religionmenu":
      case "sportsmenu":
      case "reactionmenu":
      case "ephoto360menu":
      case "aimenu":
      case "menulist":
      case "fullmenu":
      case "menu":
        let timestampe = speed();
        let latensie = Math.max(0, Math.round(speed() - timestampe));
        const menuSections = eliteMenuSections();
        const elitemenuoh = menu421.build({
          sections: menuSections,
          botName: (typeof botname !== "undefined" && botname) || "Pixel",
          owner: (typeof ownername !== "undefined" && ownername) || "blacklord",
          version: "3.0.0",
          mode: EliteProTech.public ? "🌐 Public" : "🔒 Private",
          prefix,
          speedMs: latensie,
          toolset: menuSections.reduce((n, sec) => n + (sec.commands?.length || 0), 0),
          connected: !!EliteProTech.user,
          style: eliteMenuStyle(),
          footer: "ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ",
        });
        const reactions = [
          "✅",
          "🔥",
          "😎",
          "👌",
          "😏",
          "🌟",
          "⚡",
          "💥",
          "🎉",
          "🧘",
          "🥺",
          "😉",
          "🔔",
          "🤫",
        ];
        const randomReaction =
          reactions[Math.floor(Math.random() * reactions.length)];
        await EliteProTech.sendMessage(m.chat, {
          react: { text: randomReaction, key: m.key },
        });
        const menuWeb = global.link || "https://whatsapp.com/channel/0029VaXaqHII1rcmdDBBsd3g";
        try {
          await sendButtons(
            EliteProTech,
            m.chat,
            {
              image: { buffer: elitepropic, mimetype: "image/jpeg" },
              text: elitemenuoh,
              footer: undefined,
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "🌐 WEBSITE",
                    url: menuWeb,
                  }),
                },
                { id: `${prefix}ping`, text: "🏓 PING" },
              ],
            },
            { quoted: m },
          );
        } catch (e) {
          console.log("[menu] buttons failed -> " + e.message);
          await EliteProTech.sendMessage(
            m.chat,
            { image: elitepropic, caption: elitemenuoh },
            { quoted: m },
          );
        }
        break;
    }
  } catch (err) {
    console.log(util.format(err));
  }
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update ${__filename}`));
  delete require.cache[file];
  require(file);
});

process.on("uncaughtException", function (err) {
  let e = String(err);
  if (e.includes("conflict")) return;
  if (e.includes("Socket connection timeout")) return;
  if (e.includes("not-authorized")) return;
  if (e.includes("already-exists")) return;
  if (e.includes("rate-overlimit")) return;
  if (e.includes("Connection Closed")) return;
  if (e.includes("Timed Out")) return;
  if (e.includes("Value not found")) return;
  console.log("Caught exception: ", err);
});
