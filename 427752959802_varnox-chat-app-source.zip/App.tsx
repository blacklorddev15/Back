import { StatusBar } from 'expo-status-bar';
import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { AuthProvider, useAuth } from './src/state/AuthContext';
import { RealtimeProvider } from './src/state/RealtimeContext';
import { AppDrawer } from './src/components/AppDrawer';
import { TabBar, type Tab } from './src/components/TabBar';
import { AuthScreen, OnboardingScreen, TwoStepScreen, VerifyEmailScreen } from './src/screens/AuthScreens';
import { BlockedContactsScreen } from './src/screens/BlockedScreen';
import { CallsScreen } from './src/screens/CallsScreen';
import { ChatListScreen } from './src/screens/ChatListScreen';
import { ConversationScreen } from './src/screens/ConversationScreen';
import { GroupMembersScreen } from './src/screens/GroupMembersScreen';
import { NewChatScreen } from './src/screens/NewChatScreen';
import { NewGroupScreen } from './src/screens/NewGroupScreen';
import { ForgotPasswordScreen, ResetPasswordScreen } from './src/screens/PasswordResetScreens';
import { ProfileScreen } from './src/screens/ProfileScreen';
import { ServerSettingsScreen } from './src/screens/ServerSettingsScreen';
import { ToolsScreen } from './src/screens/ToolsScreen';
import { StatusComposerScreen, StatusViewerScreen } from './src/screens/StatusScreens';
import { ChannelScreen, ChannelsScreen, CreateChannelScreen } from './src/screens/ChannelsScreen';
import { StatusPrivacyScreen, UpdatesScreen } from './src/screens/UpdatesScreen';
import { initialiseServerUrl, me } from './src/api/client';
import { NotificationSettingsScreen, NotificationsScreen } from './src/screens/NotificationsScreen';
import { applyPendingUpdateOnLaunch } from './src/lib/appUpdates';
import { colors } from './src/theme';

/**
 * App root.
 *
 * Navigation is a hand-rolled stack rather than react-navigation. With one
 * linear flow and seven screens, a dependency that pulls in reanimated,
 * gesture-handler and screens would be more moving parts than the problem
 * needs — and it keeps the native build lean. Swap it out when the navigation
 * genuinely becomes a graph rather than a stack.
 */

type Route =
  | { name: 'onboarding' }
  // One screen hosts both tabs; `mode` only decides which tab is selected on
  // arrival, so a user who tapped "Log in" is not shown the register form.
  | { name: 'auth'; mode: 'login' | 'register' }
  | { name: 'verifyEmail'; email: string }
  | { name: 'twoStep'; challengeToken: string }
  | { name: 'forgotPassword' }
  | { name: 'resetPassword'; email: string }
  // Tab roots. These four are the only routes that render the bottom tab bar,
  // and they are only ever the sole entry on the stack — push anything and the
  // tabs give way to that screen.
  | { name: 'chats' }
  | { name: 'calls' }
  | { name: 'updates' }
  | { name: 'tools' }
  // Pushed from the Updates tab.
  | { name: 'statusCompose' }
  | { name: 'statusView'; authorUserId: string }
  | { name: 'statusPrivacy' }
  | { name: 'channels' }
  | { name: 'channel'; channelId: string }
  | { name: 'createChannel' }
  | { name: 'notifications' }
  | { name: 'notificationSettings' }
  | { name: 'blocked' }
  | { name: 'newChat' }
  | { name: 'newGroup' }
  | { name: 'groupMembers'; chatId: string }
  | { name: 'profile' }
  | { name: 'serverSettings' }
  | { name: 'conversation'; chatId: string };

function Splash() {
  return (
    <View style={styles.splash}>
      <ActivityIndicator size="large" color={colors.primary} />
    </View>
  );
}

function Router() {
  const { status } = useAuth();
  const [stack, setStack] = useState<Route[]>([{ name: 'onboarding' }]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [unreadNotifications, setUnreadNotifications] = useState(0);

  const refreshUnread = useCallback(() => {
    void me
      .unreadNotificationCount()
      .then((result) => setUnreadNotifications(result.unreadCount ?? 0))
      .catch(() => {
        // A failed count must never block navigation; the badge just stays put.
      });
  }, []);

  const push = (route: Route) => setStack((current) => [...current, route]);
  const pop = () => setStack((current) => (current.length > 1 ? current.slice(0, -1) : current));
  const reset = (route: Route) => setStack([route]);

  // When auth state flips (signed in, or signed out from anywhere), the stack
  // contains routes that no longer make sense. Reset rather than trying to
  // reconcile: a half-populated stack is how stale screens reappear.
  useEffect(() => {
    if (status === 'signedIn') {
      setStack((current) => (current[current.length - 1]?.name === 'chats' ? current : [{ name: 'chats' }]));
    } else if (status === 'signedOut') {
      setStack([{ name: 'onboarding' }]);
    }
    // The drawer is signed-in furniture; leaving it open across a sign-out
    // would float it over the onboarding screen.
    if (status !== 'signedIn') {
      setDrawerOpen(false);
      setUnreadNotifications(0);
    }
  }, [status]);

  // Refresh the badge whenever the stack changes depth — which covers both
  // signing in and coming back from the notification list after reading things.
  useEffect(() => {
    if (status === 'signedIn') refreshUnread();
  }, [status, stack.length, refreshUnread]);

  if (status === 'loading') return <Splash />;

  const route = stack[stack.length - 1]!;

  if (status === 'signedOut') {
    switch (route.name) {
      case 'auth':
        return (
          <AuthScreen
            initialMode={route.mode}
            onBack={pop}
            onTwoStep={(challengeToken) => push({ name: 'twoStep', challengeToken })}
            onRegistered={(email) => push({ name: 'verifyEmail', email })}
            onForgotPassword={() => push({ name: 'forgotPassword' })}
          />
        );
      case 'forgotPassword':
        return <ForgotPasswordScreen onBack={pop} onSent={(email) => push({ name: 'resetPassword', email })} />;
      case 'resetPassword':
        // Done -> back to sign-in, where the new password is used.
        return (
          <ResetPasswordScreen
            email={route.email}
            onBack={pop}
            onDone={() => reset({ name: 'auth', mode: 'login' })}
          />
        );
      case 'verifyEmail':
        return <VerifyEmailScreen email={route.email} onBack={() => reset({ name: 'auth', mode: 'login' })} />;
      case 'twoStep':
        return (
          <TwoStepScreen challengeToken={route.challengeToken} onBack={() => reset({ name: 'auth', mode: 'login' })} />
        );
      case 'serverSettings':
        // Reachable while signed out on purpose: if the address is wrong, the
        // user cannot sign in, so this is the only way back.
        return <ServerSettingsScreen onBack={pop} />;
      default:
        return (
          <OnboardingScreen
            onGetStarted={() => reset({ name: 'auth', mode: 'register' })}
            onSignIn={() => reset({ name: 'auth', mode: 'login' })}
          />
        );
    }
  }

  const screen = (() => {
    switch (route.name) {
      case 'notifications':
        return (
          <NotificationsScreen
            onBack={pop}
            onOpenChat={(chatId) => reset({ name: 'conversation', chatId })}
            onOpenSettings={() => push({ name: 'notificationSettings' })}
          />
        );
      case 'notificationSettings':
        return <NotificationSettingsScreen onBack={pop} />;
      case 'newChat':
        // reset rather than push: after picking someone, going "back" should
        // return to the chat list, not to the search screen with stale results.
        return <NewChatScreen onBack={pop} onOpenChat={(chatId) => reset({ name: 'conversation', chatId })} />;
      case 'newGroup':
        return <NewGroupScreen onBack={pop} onCreated={(chatId) => reset({ name: 'conversation', chatId })} />;
      case 'profile':
        return (
          <ProfileScreen
            onBack={pop}
            onOpenServerSettings={() => push({ name: 'serverSettings' })}
            onOpenBlocked={() => push({ name: 'blocked' })}
          />
        );
      case 'blocked':
        return <BlockedContactsScreen onBack={pop} />;
      case 'serverSettings':
        return <ServerSettingsScreen onBack={pop} />;
      case 'groupMembers':
        return <GroupMembersScreen chatId={route.chatId} onBack={pop} onLeft={() => reset({ name: 'chats' })} />;
      case 'conversation':
        return (
          <ConversationScreen
            chatId={route.chatId}
            onBack={pop}
            onOpenMembers={() => push({ name: 'groupMembers', chatId: route.chatId })}
          />
        );
      case 'calls':
        return <CallsScreen onOpenDrawer={() => setDrawerOpen(true)} />;
      case 'updates':
        return (
          <UpdatesScreen
            onOpenDrawer={() => setDrawerOpen(true)}
            onCompose={() => push({ name: 'statusCompose' })}
            onOpenViewer={(authorUserId) => push({ name: 'statusView', authorUserId })}
            onOpenChannels={() => push({ name: 'channels' })}
            onOpenSettings={() => push({ name: 'statusPrivacy' })}
          />
        );
      case 'statusCompose':
        // reset rather than pop: coming back from the composer should land on a
        // refreshed Updates tab, not back on a form that has already submitted.
        return <StatusComposerScreen onBack={pop} onPosted={() => reset({ name: 'updates' })} />;
      case 'statusView':
        return <StatusViewerScreen authorUserId={route.authorUserId} onBack={pop} />;
      case 'statusPrivacy':
        return <StatusPrivacyScreen onBack={pop} onSaved={() => {}} />;
      case 'channels':
        return (
          <ChannelsScreen
            onBack={pop}
            onOpenChannel={(channelId) => push({ name: 'channel', channelId })}
            onOpenCreate={() => push({ name: 'createChannel' })}
          />
        );
      case 'channel':
        return <ChannelScreen channelId={route.channelId} onBack={pop} />;
      case 'createChannel':
        // reset rather than pop: after creating, "back" should reach the
        // channel list, not a form that has already submitted.
        return (
          <CreateChannelScreen
            onBack={pop}
            onCreated={(channelId) => reset({ name: 'channel', channelId })}
          />
        );
      case 'tools':
        return (
          <ToolsScreen
            onOpenDrawer={() => setDrawerOpen(true)}
            onOpenProfile={() => push({ name: 'profile' })}
            onOpenServerSettings={() => push({ name: 'serverSettings' })}
          />
        );
      default:
        return (
          <ChatListScreen
            onOpenChat={(chatId) => push({ name: 'conversation', chatId })}
            onNewChat={() => push({ name: 'newChat' })}
            onOpenProfile={() => push({ name: 'profile' })}
            onOpenDrawer={() => setDrawerOpen(true)}
            onOpenNotifications={() => push({ name: 'notifications' })}
            unreadNotifications={unreadNotifications}
          />
        );
    }
  })();

  // The tab bar belongs to the four roots only. Any pushed screen — a
  // conversation, the profile, a picker — covers it, the way it does in every
  // messaging app: you are somewhere specific, not browsing a section.
  const isTabRoot =
    stack.length === 1 &&
    (route.name === 'chats' || route.name === 'calls' || route.name === 'updates' || route.name === 'tools');

  return (
    <View style={styles.app}>
      {screen}
      {isTabRoot ? <TabBar active={route.name as Tab} onSelect={(tab) => reset({ name: tab })} /> : null}
      {drawerOpen ? (
        <AppDrawer
          onClose={() => setDrawerOpen(false)}
          onOpenProfile={() => push({ name: 'profile' })}
          onNewGroup={() => push({ name: 'newGroup' })}
          onOpenNotifications={() => push({ name: 'notifications' })}
          onOpenServerSettings={() => push({ name: 'serverSettings' })}
          unreadCount={unreadNotifications}
        />
      ) : null}
    </View>
  );
}

export default function App() {
  const [ready, setReady] = useState(false);

  /**
   * The server address has to be resolved before anything issues a request —
   * including AuthProvider's session check, which fires on mount. Doing this in
   * an effect rather than at module scope keeps SecureStore access off the
   * synchronous startup path.
   */
  useEffect(() => {
    void initialiseServerUrl().finally(() => setReady(true));
  }, []);

  /**
   * Apply a published JavaScript update during startup.
   *
   * Runs alongside the server-address lookup rather than after it: if an update
   * is available the process restarts anyway, so there is nothing to sequence.
   * Left un-awaited so a slow update server cannot delay the app appearing.
   */
  useEffect(() => {
    void applyPendingUpdateOnLaunch();
  }, []);

  if (!ready) return <Splash />;

  return (
    <AuthProvider>
      <RealtimeProvider>
        <Router />
        <StatusBar style="light" />
      </RealtimeProvider>
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  splash: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.background },
  // Column so the tab bar sits below the screen and the drawer can be layered
  // over both as an absolutely positioned sibling.
  app: { flex: 1, backgroundColor: colors.background },
});
