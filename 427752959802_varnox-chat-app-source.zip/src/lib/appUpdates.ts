import * as Updates from 'expo-updates';

/**
 * Download and apply a published update during startup.
 *
 * expo-updates fetches a new bundle on one launch and applies it on the *next*
 * one, which makes "is my change live yet?" genuinely ambiguous: the same phone
 * shows either the old or the new code depending on how many times it has been
 * restarted since the publish. That ambiguity is what the App update screen was
 * added to expose, and this removes it at the source — the newest bundle is
 * running on the first launch.
 *
 * Reloading here is safe rather than disruptive because it happens while the
 * user is still looking at the splash screen, not mid-conversation.
 *
 * Note this cannot fix the launch it is delivered on: the code that performs
 * the check is itself part of an update, so the build that receives it still
 * needs one ordinary restart to pick it up. Every launch after that is a single
 * restart.
 */

// Guards against the check being started twice by a double mount. A reload
// resets this, but by then the running bundle is the newest one, so the next
// check reports nothing available and the cycle stops on its own.
let attempted = false;

export async function applyPendingUpdateOnLaunch(): Promise<void> {
  if (attempted) return;
  attempted = true;

  try {
    if (!Updates.isEnabled) return;

    const found = await Updates.checkForUpdateAsync();
    if (!found.isAvailable) return;

    await Updates.fetchUpdateAsync();
    await Updates.reloadAsync();
  } catch {
    // A failed update check must never stop the app from starting; the screen
    // silently carries on with whatever bundle it already has.
  }
}
