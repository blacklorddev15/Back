import { Platform } from 'react-native';

/**
 * Dark theme tokens.
 *
 * One file so the palette can change without hunting through screens, and so
 * the brand colours stay consistent between onboarding, auth and chat.
 *
 * The palette is deliberately low-contrast in the surfaces (near-black navy)
 * and high-contrast in the accents (a single green). Chat UIs live on screen
 * for hours, so large bright areas are tiring; colour is reserved for things
 * that need attention — buttons, unread counts, online dots.
 */
export const colors = {
  // Surfaces, darkest to lightest
  background: '#0B1220',
  surface: '#141E28',
  surfaceAlt: '#1B2733',
  surfaceRaised: '#22303D',
  border: '#22303D',
  borderStrong: '#2E3F4F',

  // Brand accent. `primary` is the fill; `onPrimary` is the text that sits on
  // it. Dark text on a saturated green reads far better than white.
  primary: '#00A884',
  primaryDark: '#008F70',
  primaryText: '#04150F',
  primarySoft: '#0E2A24',

  // Text hierarchy
  text: '#E9EDEF',
  textMuted: '#8696A0',
  textFaint: '#5C6B76',

  // Status. Backgrounds are dark tints rather than pastels — a pastel banner
  // on a dark UI glares.
  danger: '#F15C6D',
  dangerBg: '#33171C',
  dangerBorder: '#5A2630',
  warning: '#E0A33E',
  successBg: '#0E2A24',
  infoBg: '#14293D',
  infoText: '#8FC2F0',

  // Chat bubbles
  bubbleOutgoing: '#005C4B',
  bubbleIncoming: '#1B2733',
  online: '#00D26A',
  /** Read receipt. Sits on the outgoing bubble, so it must clear #005C4B. */
  tickRead: '#53BDEB',

  // Pure white, used for the primary call-to-action pill
  white: '#FFFFFF',
  onWhite: '#0B1220',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

/**
 * Space reserved below anything pinned to the bottom of the screen — the
 * conversation composer and the tab bar.
 *
 * The app targets SDK 36, and from Android 15 that means edge-to-edge is
 * enforced: the window covers the whole display and the navigation bar is drawn
 * on top of the app. Without this, the bottom control sits underneath the bar
 * and becomes unreachable.
 *
 * The accurate value is the device's own inset, which needs
 * react-native-safe-area-context — a native module, so it cannot ship
 * over-the-air. 48dp is the tallest navigation bar in common use (three
 * button); gesture navigation reserves roughly half that, so those handsets get
 * a little more breathing room than strictly needed. Replace with the real
 * inset at the next native build.
 */
export const bottomSystemBarClearance = Platform.OS === 'android' ? 48 : 34;

export const radius = {
  sm: 6,
  md: 12,
  lg: 18,
  pill: 999,
};

export const typography = {
  title: { fontSize: 26, fontWeight: '700' as const, color: colors.text },
  heading: { fontSize: 30, fontWeight: '700' as const, color: colors.text },
  subtitle: { fontSize: 15, color: colors.textMuted },
  body: { fontSize: 16, color: colors.text },
  label: { fontSize: 13, fontWeight: '600' as const, color: colors.textMuted },
  small: { fontSize: 12, color: colors.textFaint },
  /** The letterspaced all-caps treatment used for brand eyebrows. */
  eyebrow: { fontSize: 12, fontWeight: '600' as const, color: colors.textMuted, letterSpacing: 4 },
  wordmark: { fontSize: 40, fontWeight: '800' as const, color: colors.white, letterSpacing: 8 },
};

/**
 * Renders a timestamp the way a messaging app should: time for today,
 * "Yesterday" for yesterday, and a date beyond that. A raw ISO string is the
 * usual shortcut and it reads badly.
 */
export function formatTimestamp(iso: string | null | undefined): string {
  if (!iso) return '';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';

  const now = new Date();
  const sameDay =
    date.getFullYear() === now.getFullYear() &&
    date.getMonth() === now.getMonth() &&
    date.getDate() === now.getDate();
  if (sameDay) {
    return date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
  }

  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday =
    date.getFullYear() === yesterday.getFullYear() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getDate() === yesterday.getDate();
  if (isYesterday) return 'Yesterday';

  return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

export function formatClockTime(iso: string | null | undefined): string {
  if (!iso) return '';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

/** Falls back through the available name fields, then to something usable. */
export function displayNameOf(chat: {
  title?: string | null;
  peer_display_name?: string | null;
  peer_username?: string | null;
}): string {
  return chat.title || chat.peer_display_name || chat.peer_username || 'Unknown';
}
