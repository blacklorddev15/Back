import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { openRealtimeSocket, sendSocketFrame } from '../api/client';
import { useAuth } from './AuthContext';

/**
 * Realtime transport.
 *
 * One socket for the whole app, shared by every screen. Opening a socket per
 * screen is the common mistake: it multiplies connections, and a background
 * screen misses events while it is unmounted.
 *
 * Reconnection uses exponential backoff with a ceiling. Without a ceiling a
 * flaky network produces a reconnect storm that drains the battery; without
 * backoff at all, the same thing happens faster.
 */

type EventHandler = (event: Record<string, unknown>) => void;

export interface PresenceEntry {
  online: boolean;
  lastSeenAt: string | null;
}

interface RealtimeContextValue {
  connected: boolean;
  lastEventAt: number | null;
  /**
   * Live presence, keyed by user id.
   *
   * Only populated from `presence.update` frames, so someone who was already
   * online when this socket opened shows as unknown until their state changes.
   * Callers should fall back to the `last_seen_at` value they already hold from
   * the chat list rather than assuming absence means offline.
   */
  presence: Record<string, PresenceEntry>;
  /** Returns an unsubscribe function. */
  subscribe: (handler: EventHandler) => () => void;
  send: (frame: Record<string, unknown>) => void;
}

const RealtimeContext = createContext<RealtimeContextValue | null>(null);

export function RealtimeProvider({ children }: { children: React.ReactNode }) {
  const { status } = useAuth();
  const [connected, setConnected] = useState(false);
  const [lastEventAt, setLastEventAt] = useState<number | null>(null);
  const [presence, setPresence] = useState<Record<string, PresenceEntry>>({});

  const socketRef = useRef<WebSocket | null>(null);
  const handlersRef = useRef(new Set<EventHandler>());
  const reconnectTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const attemptRef = useRef(0);
  const disposedRef = useRef(false);

  const subscribe = useCallback((handler: EventHandler) => {
    handlersRef.current.add(handler);
    return () => {
      handlersRef.current.delete(handler);
    };
  }, []);

  const send = useCallback((frame: Record<string, unknown>) => {
    sendSocketFrame(socketRef.current, frame);
  }, []);

  useEffect(() => {
    // Only connect while signed in. On sign-out the effect re-runs, cleans up
    // the socket and stops reconnecting.
    if (status !== 'signedIn') {
      disposedRef.current = true;
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      socketRef.current?.close();
      socketRef.current = null;
      setConnected(false);
      return;
    }

    disposedRef.current = false;
    attemptRef.current = 0;

    const connect = async () => {
      if (disposedRef.current) return;

      const ws = await openRealtimeSocket({
        onOpen: () => {
          attemptRef.current = 0;
          setConnected(true);
        },
        onEvent: (event) => {
          setLastEventAt(Date.now());

          // Presence is app-wide state rather than something every screen should
          // have to subscribe to, so it is folded in here before dispatch.
          if (event.type === 'presence.update' && typeof event.userId === 'string') {
            const userId = event.userId;
            const entry: PresenceEntry = {
              online: Boolean(event.online),
              lastSeenAt: typeof event.lastSeenAt === 'string' ? event.lastSeenAt : null,
            };
            setPresence((current) => ({ ...current, [userId]: entry }));
          }

          for (const handler of handlersRef.current) {
            try {
              handler(event);
            } catch {
              // One bad subscriber must not stop the others from being notified.
            }
          }
        },
        onClose: () => {
          setConnected(false);
          socketRef.current = null;
          if (disposedRef.current) return;

          // 1s, 2s, 4s, ... capped at 30s.
          const delay = Math.min(30_000, 1000 * 2 ** attemptRef.current);
          attemptRef.current += 1;
          reconnectTimer.current = setTimeout(connect, delay);
        },
        onError: () => setConnected(false),
      });

      socketRef.current = ws;
    };

    void connect();

    return () => {
      disposedRef.current = true;
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      socketRef.current?.close();
      socketRef.current = null;
      setConnected(false);
    };
  }, [status]);

  const value = useMemo<RealtimeContextValue>(
    () => ({ connected, lastEventAt, presence, subscribe, send }),
    [connected, lastEventAt, presence, subscribe, send],
  );

  return <RealtimeContext.Provider value={value}>{children}</RealtimeContext.Provider>;
}

export function useRealtime(): RealtimeContextValue {
  const ctx = useContext(RealtimeContext);
  if (!ctx) throw new Error('useRealtime must be used inside a RealtimeProvider');
  return ctx;
}
