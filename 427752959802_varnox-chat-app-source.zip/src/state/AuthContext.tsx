import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  ApiError,
  auth,
  clearTokens,
  loadStoredTokens,
  saveTokens,
  setAuthFailureHandler,
  type AuthUser,
} from '../api/client';

/**
 * Authentication state for the whole app.
 *
 * Two details that matter:
 *
 *  - On launch we do NOT trust the stored token. We call GET /auth/session to
 *    confirm the session still exists server-side, because tokens live for 15
 *    minutes and the device may have been signed out remotely in the meantime.
 *  - A two-step login returns a challenge, not a session. It is kept in state
 *    (never stored) and must be exchanged for tokens via verifyTwoStep.
 */

type Status = 'loading' | 'signedOut' | 'signedIn';

interface AuthContextValue {
  status: Status;
  user: AuthUser | null;

  signIn: (identifier: string, password: string) => Promise<{ twoStepRequired: boolean; challengeToken?: string }>;
  verifyTwoStep: (challengeToken: string, pin: string) => Promise<void>;

  register: (input: { fullName: string; email: string; phone: string; password: string }) => Promise<void>;
  verifyEmail: (email: string, code: string) => Promise<void>;
  resendVerification: (email: string) => Promise<void>;

  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<Status>('loading');
  const [user, setUser] = useState<AuthUser | null>(null);

  const signOut = useCallback(async () => {
    const stored = await loadStoredTokens().catch(() => null);
    if (stored?.refreshToken) {
      // Best-effort: revoke server-side, but never block the user on it.
      await auth.logout(stored.refreshToken).catch(() => {});
    }
    await clearTokens().catch(() => {});
    setUser(null);
    setStatus('signedOut');
  }, []);

  // If the API client discovers a dead session on any request, drop to signed out.
  useEffect(() => {
    setAuthFailureHandler(() => {
      setUser(null);
      setStatus('signedOut');
    });
    return () => setAuthFailureHandler(null);
  }, []);

  // Bootstrap: validate any stored session before showing the chat list.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const stored = await loadStoredTokens();
        if (!stored) {
          if (!cancelled) setStatus('signedOut');
          return;
        }
        const session = await auth.session();
        if (cancelled) return;
        setUser(session.user);
        setStatus('signedIn');
      } catch {
        // Any failure here (expired, revoked, offline) means "show sign-in".
        if (!cancelled) {
          await clearTokens().catch(() => {});
          setUser(null);
          setStatus('signedOut');
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const signIn = useCallback<AuthContextValue['signIn']>(async (identifier, password) => {
    const result = await auth.login({ identifier: identifier.trim(), password });

    if (result.twoStepRequired) {
      // No tokens yet — the challenge must be completed first.
      return { twoStepRequired: true, challengeToken: result.challengeToken };
    }

    await saveTokens(result.tokens);
    setUser(result.user);
    setStatus('signedIn');
    return { twoStepRequired: false };
  }, []);

  const verifyTwoStep = useCallback<AuthContextValue['verifyTwoStep']>(async (challengeToken, pin) => {
    const result = await auth.verifyTwoStep({ challengeToken, pin });
    await saveTokens(result.tokens);
    setUser(result.user);
    setStatus('signedIn');
  }, []);

  const register = useCallback<AuthContextValue['register']>(async (input) => {
    // Registration only sends the code; the account stays 'pending' until the
    // email is verified, so there is nothing to store at this point.
    await auth.register(input);
  }, []);

  const verifyEmail = useCallback<AuthContextValue['verifyEmail']>(async (email, code) => {
    const result = await auth.verifyEmail({ email, code });
    await saveTokens(result.tokens);
    setUser(result.user);
    setStatus('signedIn');
  }, []);

  const resendVerification = useCallback<AuthContextValue['resendVerification']>(async (email) => {
    await auth.resendVerification(email);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({ status, user, signIn, verifyTwoStep, register, verifyEmail, resendVerification, signOut }),
    [status, user, signIn, verifyTwoStep, register, verifyEmail, resendVerification, signOut],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside an AuthProvider');
  return ctx;
}

/**
 * Turns any thrown value into a sentence worth showing a user.
 * ApiError already carries a human-readable server message; a NetworkError
 * carries the cleartext/unreachable hint. Everything else is a bug.
 */
export function describeError(err: unknown): string {
  if (err instanceof ApiError) return err.message;
  if (err instanceof Error) return err.message;
  return 'Something went wrong. Please try again.';
}
