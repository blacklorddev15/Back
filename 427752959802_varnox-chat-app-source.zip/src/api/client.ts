/**
 * API client for the chat backend.
 *
 * Everything the app knows about the server lives in this file: the base URL,
 * the request wrapper, token handling, and one typed function per endpoint.
 * Screens never call `fetch` directly — that is how base URLs, auth headers and
 * error shapes drift apart across a codebase.
 */
import * as SecureStore from 'expo-secure-store';

// ---------------------------------------------------------------------------
// Where the backend lives.
//
// This is a COMPILE-TIME DEFAULT, not the final answer. If it were the only
// source of truth, moving the server would mean rebuilding and reinstalling the
// APK — and already-installed copies would keep pointing at the retired host.
//
// The address is therefore resolved at runtime, in this order:
//
//   1. an override the user set in Server settings (in the device keystore)
//   2. otherwise this default
//
// A server move becomes "type the new address once" instead of "ship a build".
// The permanent fix is still a stable hostname: put the API behind
// https://api.example.com and this default never changes again.
//
// Android blocks cleartext HTTP by default on API 28+, so usesCleartextTraffic
// is enabled in app.json. Turn that off once you are on HTTPS.
// ---------------------------------------------------------------------------
export const DEFAULT_API_BASE_URL = 'http://194.36.88.248:3049';

const SERVER_URL_KEY = 'chat.serverUrl';

let resolvedBaseUrl = DEFAULT_API_BASE_URL;
let serverUrlSource: 'saved' | 'default' = 'default';

/** The base URL currently in use. All requests must read it through this. */
export function apiBaseUrl(): string {
  return resolvedBaseUrl;
}

export function serverUrlOrigin(): 'saved' | 'default' {
  return serverUrlSource;
}

/**
 * Trailing slashes are stripped so callers can interpolate
 * `${apiBaseUrl()}/path` without producing a double slash, which some proxies
 * treat as a different route.
 */
function normaliseUrl(input: string): string {
  const trimmed = input.trim().replace(/\/+$/, '');
  if (!trimmed) return DEFAULT_API_BASE_URL;
  // Assume http:// when a bare host is typed, since that is what people paste
  // out of the panel.
  if (!/^https?:\/\//i.test(trimmed)) return `http://${trimmed}`;
  return trimmed;
}

/** Call once at launch, before any request is issued. */
export async function initialiseServerUrl(): Promise<{ url: string; source: 'saved' | 'default' }> {
  try {
    const saved = await SecureStore.getItemAsync(SERVER_URL_KEY);
    if (saved && saved.trim()) {
      resolvedBaseUrl = normaliseUrl(saved);
      serverUrlSource = 'saved';
    }
  } catch {
    // A broken keystore must not stop the app launching on the default.
  }
  return { url: resolvedBaseUrl, source: serverUrlSource };
}

/**
 * Point the app at a different server, or pass null to return to the default.
 *
 * The caller must clear tokens afterwards: a session issued by one server is
 * meaningless to another, and every request would otherwise 401.
 */
export async function setServerUrl(input: string | null): Promise<void> {
  if (input === null) {
    await SecureStore.deleteItemAsync(SERVER_URL_KEY);
    resolvedBaseUrl = DEFAULT_API_BASE_URL;
    serverUrlSource = 'default';
    return;
  }
  const normalised = normaliseUrl(input);
  await SecureStore.setItemAsync(SERVER_URL_KEY, normalised);
  resolvedBaseUrl = normalised;
  serverUrlSource = 'saved';
}

/** WebSocket endpoint, derived live so it follows any server change. */
export function wsUrl(): string {
  return resolvedBaseUrl.replace(/^http/, 'ws') + '/ws';
}

/**
 * Reachability probe for Server settings. Unauthenticated and short-timeout, so
 * a wrong address fails in seconds rather than appearing to hang.
 */
export async function testServerConnection(url?: string): Promise<{
  ok: boolean;
  health?: { status: string; uptimeSeconds: number };
  ready?: { status: string; database?: { ok: boolean; latencyMs: number } };
  error?: string;
  latencyMs: number;
}> {
  const target = normaliseUrl(url ?? resolvedBaseUrl);
  const started = Date.now();

  const probe = async (path: string) => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const res = await fetch(`${target}${path}`, { signal: controller.signal });
      if (!res.ok) return { error: `${path} returned HTTP ${res.status}` };
      return { data: (await res.json()) as Record<string, unknown> };
    } catch (err) {
      return { error: err instanceof Error ? err.message : 'unreachable' };
    } finally {
      clearTimeout(timer);
    }
  };

  const health = await probe('/health');
  if ('error' in health) {
    return { ok: false, error: health.error, latencyMs: Date.now() - started };
  }

  const ready = await probe('/health/ready');
  return {
    ok: true,
    health: health.data as { status: string; uptimeSeconds: number },
    // Readiness failing is worth showing but is not the same as unreachable:
    // the API can be up while the database is not.
    ...('data' in ready ? { ready: ready.data as { status: string; database?: { ok: boolean; latencyMs: number } } } : {}),
    latencyMs: Date.now() - started,
  };
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface AuthUser {
  id: string;
  email: string | null;
  phone: string | null;
  username: string | null;
  fullName: string | null;
  status: string;
  isBusiness: boolean;
  isVerified: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
  twoStepEnabled: boolean;
  createdAt: string;
}

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  accessTokenExpiresAt: string;
  refreshTokenExpiresAt: string;
}

/**
 * Chat rows come straight from SQL with snake_case column names, because the
 * list endpoint selects named columns rather than shaping JSON. Message rows,
 * by contrast, are shaped by the API into camelCase. That inconsistency is
 * real and these two types mirror it rather than pretending otherwise.
 */
export interface ChatSummary {
  id: string;
  type: 'direct' | 'group' | 'community_announcement' | 'community_group' | 'channel_discussion';
  title: string | null;
  photo_url: string | null;
  last_message_at: string | null;
  last_message_preview: string | null;
  member_count: number;
  is_announcement: boolean;
  disappearing_seconds: number;
  role: 'member' | 'admin' | 'owner';
  muted_until: string | null;
  is_archived: boolean;
  pinned_at: string | null;
  is_favorite: boolean;
  is_locked: boolean;
  last_read_seq: string | number;
  last_delivered_seq: string | number;
  unread_count: number | string;
  peer_id: string | null;
  peer_username: string | null;
  peer_display_name: string | null;
  peer_avatar_url: string | null;
  peer_last_seen_at: string | null;
}

export interface Message {
  id: string;
  seq: number;
  chatId: string;
  senderId: string | null;
  type: string;
  body: string | null;
  metadata: Record<string, unknown>;
  replyToId: string | null;
  isDeleted: boolean;
  editedAt: string | null;
  isViewOnce: boolean;
  expiresAt: string | null;
  createdAt: string;
  clientId: string | null;
  reactions: { emoji: string; userIds: string[] }[];
  attachments: { id: string; kind: string; mimeType: string; fileName: string | null; byteSize: number; publicUrl: string | null }[];
  mentions: string[];
  poll: unknown;
}

export interface ChatDetail {
  chat: Record<string, unknown> & { id: string; type: string; title: string | null; member_count: number };
  role: string;
  members: {
    user_id: string;
    role: string;
    nickname: string | null;
    username: string | null;
    display_name: string | null;
    avatar_url: string | null;
    last_seen_at: string | null;
    /**
     * Per-member read/delivery watermarks. These let a freshly opened screen
     * render correct ticks for history instead of showing single ticks until
     * the next realtime event arrives.
     */
    last_read_seq: string | number;
    last_delivered_seq: string | number;
  }[];
  permissions: { whoCanSend: string; whoCanEditInfo: string; whoCanAddMembers: string; whoCanPin: string };
}

export interface UserSearchResult {
  id: string;
  username: string | null;
  display_name: string | null;
  avatar_url: string | null;
  is_verified: boolean;
  is_business: boolean;
  is_contact: boolean;
}

/**
 * A member of the browsable people directory.
 *
 * Deliberately a superset of UserSearchResult: the directory also carries when
 * the account was created, because the list is ordered oldest-first and the
 * screen shows how long someone has been here so early members stand out from
 * new ones. Email and phone are never present — see the API's listDirectory().
 */
export interface DirectoryMember extends UserSearchResult {
  created_at: string;
  last_seen_at: string | null;
}

export interface MeResponse {
  id: string;
  email: string | null;
  phone: string | null;
  username: string | null;
  full_name: string | null;
  status: string;
  is_business: boolean;
  is_verified: boolean;
  email_verified_at: string | null;
  phone_verified_at: string | null;
  two_step_enabled: boolean;
  created_at: string;
  display_name: string | null;
  about: string | null;
  avatar_url: string | null;
  date_of_birth: string | null;
  country_code: string | null;
  language_code: string | null;
  timezone: string | null;
  unreadNotifications: number;
  /** Raw settings rows; keys are snake_case column names from the database. */
  privacy: Record<string, unknown> | null;
  notifications: Record<string, unknown> | null;
  appearance: Record<string, unknown> | null;
}

export interface DeviceSummary {
  id: string;
  platform: string;
  device_name: string | null;
  app_version: string | null;
  os_version: string | null;
  is_primary: boolean;
  last_ip: string | null;
  last_seen_at: string | null;
  created_at: string;
  last_session_at: string | null;
  active_sessions: string | number;
}

export interface SecurityEvent {
  id: string;
  event_type: string;
  ip: string | null;
  user_agent: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface PrivacyPatch {
  lastSeenVisibility?: 'everyone' | 'contacts' | 'contacts_except' | 'nobody';
  onlineVisibility?: 'everyone' | 'contacts' | 'contacts_except' | 'nobody';
  profilePhotoVisibility?: 'everyone' | 'contacts' | 'contacts_except' | 'nobody';
  aboutVisibility?: 'everyone' | 'contacts' | 'contacts_except' | 'nobody';
  statusVisibility?: 'everyone' | 'contacts' | 'contacts_except' | 'nobody';
  readReceiptsEnabled?: boolean;
  typingIndicatorEnabled?: boolean;
  liveLocationEnabled?: boolean;
  groupInvitePolicy?: 'everyone' | 'contacts' | 'contacts_except' | 'nobody';
  discoverableByEmail?: boolean;
  discoverableByPhone?: boolean;
  discoverableByUsername?: boolean;
  silenceUnknownCallers?: boolean;
  screenshotProtection?: boolean;
  securityNotifications?: boolean;
}

// ---------------------------------------------------------------------------
// Errors
// ---------------------------------------------------------------------------

/**
 * Every non-2xx response becomes this, carrying the backend's stable error code
 * (`invalid_credentials`, `otp_invalid`, `blocked_by_recipient`, ...) so screens
 * can branch on meaning instead of on HTTP status numbers or message strings.
 */
export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: unknown;

  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

/** A network-level failure: no response at all, DNS, cleartext blocked, etc. */
export class NetworkError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'NetworkError';
  }
}

// ---------------------------------------------------------------------------
// Token storage
// ---------------------------------------------------------------------------

const ACCESS_KEY = 'chat.accessToken';
const REFRESH_KEY = 'chat.refreshToken';
const DEVICE_KEY = 'chat.deviceId';

let memoryTokens: TokenPair | null = null;

export async function loadStoredTokens(): Promise<TokenPair | null> {
  if (memoryTokens) return memoryTokens;
  try {
    const [accessToken, refreshToken] = await Promise.all([
      SecureStore.getItemAsync(ACCESS_KEY),
      SecureStore.getItemAsync(REFRESH_KEY),
    ]);
    if (!accessToken || !refreshToken) return null;
    memoryTokens = {
      accessToken,
      refreshToken,
      accessTokenExpiresAt: '',
      refreshTokenExpiresAt: '',
    };
    return memoryTokens;
  } catch {
    // SecureStore can fail on a device with a corrupted keystore. Treat that as
    // "not signed in" rather than crashing on launch.
    return null;
  }
}

export async function saveTokens(tokens: TokenPair): Promise<void> {
  memoryTokens = tokens;
  await SecureStore.setItemAsync(ACCESS_KEY, tokens.accessToken);
  await SecureStore.setItemAsync(REFRESH_KEY, tokens.refreshToken);
}

export async function clearTokens(): Promise<void> {
  memoryTokens = null;
  await SecureStore.deleteItemAsync(ACCESS_KEY);
  await SecureStore.deleteItemAsync(REFRESH_KEY);
}

/**
 * A stable identifier for this installation, so the backend can recognise the
 * device across sign-ins. Without it every login looks like a new device and
 * the user gets a "new device" security email every time.
 */
export async function getDeviceId(): Promise<string> {
  const existing = await SecureStore.getItemAsync(DEVICE_KEY);
  if (existing) return existing;

  // A v4-shaped id. Math.random is acceptable here: this is a device label, not
  // a security token — it grants nothing on its own and is always sent
  // alongside an authenticated request.
  const id = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });

  await SecureStore.setItemAsync(DEVICE_KEY, id);
  return id;
}

export async function getDeviceDescriptor(): Promise<{
  deviceId: string;
  platform: 'android' | 'ios';
  deviceName: string;
}> {
  const deviceId = await getDeviceId();
  return {
    deviceId,
    // The backend validates this against an enum; anything else is rejected.
    platform: 'android',
    deviceName: 'Android device',
  };
}

// ---------------------------------------------------------------------------
// Core request wrapper
// ---------------------------------------------------------------------------

let onAuthFailure: (() => void) | null = null;

/** Registered by AuthContext so a dead session can bounce the user to sign-in. */
export function setAuthFailureHandler(handler: (() => void) | null): void {
  onAuthFailure = handler;
}

/** Serialises concurrent refreshes so a burst of 401s triggers only one. */
let refreshInFlight: Promise<boolean> | null = null;

async function refreshTokens(): Promise<boolean> {
  if (refreshInFlight) return refreshInFlight;

  refreshInFlight = (async () => {
    const stored = memoryTokens ?? (await loadStoredTokens());
    if (!stored?.refreshToken) return false;

    try {
      const res = await fetch(`${apiBaseUrl()}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: stored.refreshToken }),
      });
      if (!res.ok) return false;

      const json = (await res.json()) as { tokens: TokenPair };
      if (!json?.tokens?.accessToken) return false;
      await saveTokens(json.tokens);
      return true;
    } catch {
      return false;
    } finally {
      refreshInFlight = null;
    }
  })();

  return refreshInFlight;
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  body?: unknown;
  /** Set false for the handful of endpoints that must not carry a token. */
  auth?: boolean;
  /** Internal: prevents infinite refresh recursion. */
  isRetry?: boolean;
}

export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, auth = true, isRetry = false } = options;

  const headers: Record<string, string> = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';

  if (auth) {
    const tokens = memoryTokens ?? (await loadStoredTokens());
    if (tokens?.accessToken) headers.Authorization = `Bearer ${tokens.accessToken}`;
  }

  let res: Response;
  try {
    res = await fetch(`${apiBaseUrl()}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (err) {
    // This is the branch that fires when cleartext HTTP is blocked by the
    // platform, or the server is unreachable. Distinguishing it from a 4xx/5xx
    // saves a lot of confused debugging.
    throw new NetworkError(
      `Could not reach the server at ${apiBaseUrl()}. ${
        err instanceof Error ? err.message : 'Unknown network failure'
      }`,
    );
  }

  // 204 has no body; anything else with JSON content is parsed.
  if (res.status === 204) return {} as T;

  const text = await res.text();
  let json: unknown = null;
  if (text.length > 0) {
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }
  }

  if (res.ok) return (json ?? {}) as T;

  const errorBody = (json ?? {}) as { error?: string; message?: string; details?: unknown };

  // A single transparent refresh-and-retry on an expired access token. Only
  // once (isRetry), because a refresh that produces another 401 means the
  // session is genuinely dead.
  const isExpired = res.status === 401 && errorBody.error === 'token_expired';
  const isSessionDead = res.status === 401 && errorBody.error === 'session_revoked';

  if (auth && !isRetry && (isExpired || isSessionDead)) {
    if (isExpired && (await refreshTokens())) {
      return apiRequest<T>(path, { ...options, isRetry: true });
    }
    // Refresh failed or the session was revoked server-side: sign the user out.
    await clearTokens();
    onAuthFailure?.();
    throw new ApiError(401, errorBody.error ?? 'session_revoked', 'Your session has ended. Please sign in again.');
  }

  throw new ApiError(
    res.status,
    errorBody.error ?? 'request_failed',
    errorBody.message ?? `Request failed with status ${res.status}`,
    errorBody.details,
  );
}

// ---------------------------------------------------------------------------
// Auth endpoints
// ---------------------------------------------------------------------------

export const auth = {
  register: (input: { fullName: string; email: string; phone: string; password: string }) =>
    apiRequest<{ userId: string; message: string; codeExpiresAt: string }>('/auth/register', {
      method: 'POST',
      body: input,
      auth: false,
    }),

  verifyEmail: async (input: { email: string; code: string }) => {
    const device = await getDeviceDescriptor();
    return apiRequest<{ user: AuthUser; tokens: TokenPair; deviceId: string }>('/auth/verify-email', {
      method: 'POST',
      body: { ...input, device },
      auth: false,
    });
  },

  resendVerification: (email: string) =>
    apiRequest<{ message: string; expiresAt: string }>('/auth/resend-verification', {
      method: 'POST',
      body: { email },
      auth: false,
    }),

  /**
   * The response is a union: either tokens, or a two-step challenge. The caller
   * must check `twoStepRequired` — the challenge token is NOT an authenticated
   * session and the API rejects it everywhere except the verify endpoint.
   */
  login: async (input: { identifier: string; password: string }) => {
    const device = await getDeviceDescriptor();
    return apiRequest<
      | { twoStepRequired: true; challengeToken: string; message: string }
      | { twoStepRequired: false; user: AuthUser; tokens: TokenPair; deviceId: string }
    >('/auth/login', { method: 'POST', body: { ...input, device }, auth: false });
  },

  verifyTwoStep: async (input: { challengeToken: string; pin: string }) => {
    const device = await getDeviceDescriptor();
    return apiRequest<{ user: AuthUser; tokens: TokenPair; deviceId: string }>('/auth/two-step/verify', {
      method: 'POST',
      body: { ...input, device },
      auth: false,
    });
  },

  logout: (refreshToken: string) =>
    apiRequest<{ loggedOut: boolean }>('/auth/logout', { method: 'POST', body: { refreshToken }, auth: false }),

  forgotPassword: (email: string) =>
    apiRequest<{ message: string }>('/auth/password/forgot', { method: 'POST', body: { email }, auth: false }),

  resetPassword: (input: { email: string; code: string; newPassword: string }) =>
    apiRequest<{ message: string }>('/auth/password/reset', { method: 'POST', body: input, auth: false }),

  session: () => apiRequest<{ userId: string; sessionId: string; role: string | null; user: AuthUser }>('/auth/session'),

  // --- two-step verification -------------------------------------------------
  enableTwoStep: (password: string, pin: string) =>
    apiRequest<{ message: string; backupCodes: string[] }>('/auth/two-step/enable', {
      method: 'POST',
      body: { password, pin },
    }),

  disableTwoStep: (password: string) =>
    apiRequest<{ message: string }>('/auth/two-step/disable', { method: 'POST', body: { password } }),

  // --- sessions & devices ---------------------------------------------------
  listDevices: () => apiRequest<{ devices: DeviceSummary[] }>('/auth/devices'),

  revokeDevice: (deviceId: string) =>
    apiRequest<{ message: string }>(`/auth/devices/${deviceId}`, { method: 'DELETE' }),

  /** Remote logout. `includeCurrentDevice` false keeps this phone signed in. */
  logoutAll: (includeCurrentDevice = false) =>
    apiRequest<{ loggedOut: boolean; sessionsEnded: number; currentDeviceKept: boolean }>('/auth/logout/all', {
      method: 'POST',
      body: { includeCurrentDevice },
    }),

  securityLog: (limit = 25) =>
    apiRequest<{ events: SecurityEvent[] }>(`/auth/security-log?limit=${limit}`),

  // --- password & email -----------------------------------------------------
  changePassword: (currentPassword: string, newPassword: string) =>
    apiRequest<{ message: string }>('/auth/password/change', {
      method: 'POST',
      body: { currentPassword, newPassword },
    }),

  // --- account deletion -----------------------------------------------------
  requestAccountDeletion: () =>
    apiRequest<{ message: string; scheduledFor: string; recoverable: string }>('/auth/account/delete', {
      method: 'POST',
      body: {},
    }),

  cancelAccountDeletion: () =>
    apiRequest<{ message: string }>('/auth/account/delete/cancel', { method: 'POST', body: {} }),
};

// ---------------------------------------------------------------------------
// Me / profile
// ---------------------------------------------------------------------------

export const me = {
  get: () => apiRequest<MeResponse>('/me'),

  updateProfile: (patch: { displayName?: string; about?: string; countryCode?: string; avatarUrl?: string }) =>
    apiRequest<{ profile: MeResponse }>('/me/profile', { method: 'PATCH', body: patch }),

  updatePrivacy: (patch: PrivacyPatch) =>
    apiRequest<{ privacy: Record<string, unknown> }>('/me/privacy', { method: 'PATCH', body: patch }),

  privacyCheckup: () =>
    apiRequest<{ findings: { key: string; severity: 'info' | 'warning'; message: string }[]; checkedAt: string }>(
      '/me/privacy-checkup',
    ),

  unreadNotificationCount: () => apiRequest<{ unreadCount: number }>('/notifications/unread-count'),

  /** Notification preferences: previews, in-app, vibration, badge, privacy. */
  updateNotifications: (patch: Partial<NotificationSettings>) =>
    apiRequest<{ notifications: NotificationSettings }>('/me/notifications', { method: 'PATCH', body: patch }),
};

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------

export interface NotificationSettings {
  previewsEnabled: boolean;
  inAppEnabled: boolean;
  vibrationEnabled: boolean;
  vibrationPattern: string;
  defaultSound: string;
  notificationPrivacy: 'sender_and_message' | 'sender_only' | 'hidden';
  badgeEnabled: boolean;
  emailSecurityAlerts: boolean;
  quietHoursStart: string | null;
  quietHoursEnd: string | null;
}

/**
 * Field names are snake_case because this endpoint returns its rows straight
 * from the database, as most of this API does — see ChatSummary. Getting this
 * wrong is silent: the list still renders, but every row looks unread and no
 * tap navigates anywhere, which is exactly what the first run of the
 * notification test caught.
 */
export interface AppNotification {
  id: string;
  type: string;
  title: string | null;
  body: string | null;
  target_type: string | null;
  target_id: string | null;
  metadata: Record<string, unknown>;
  priority: number;
  read_at: string | null;
  created_at: string;
}

// ---------------------------------------------------------------------------
// Channels — one-to-many broadcast
// ---------------------------------------------------------------------------

export type ChannelRole = 'follower' | 'admin' | 'owner';

export interface ChannelSummary {
  id: string;
  handle: string | null;
  name: string;
  description: string | null;
  photoUrl: string | null;
  category: string | null;
  isVerified: boolean;
  isSponsored: boolean;
  sponsorLabel: string | null;
  followerCount: number;
  postCount: number;
  createdAt: string;
  isFollowing?: boolean;
  isMuted?: boolean;
  myRole?: ChannelRole | null;
  unreadCount?: number;
  latestPostAt?: string | null;
}

export interface ChannelPost {
  id: string;
  seq: number;
  type: string;
  body: string | null;
  isPinned: boolean;
  editedAt: string | null;
  createdAt: string;
  reactions: Array<{ emoji: string; count: number }>;
  myReaction: string | null;
  attachments: Array<{
    id: string;
    kind: string;
    mimeType: string;
    storageKey: string;
    byteSize: number;
    width: number | null;
    height: number | null;
  }>;
}

export const channels = {
  /** The directory. `q` searches name, handle and description. */
  search: (q?: string, opts: { limit?: number; offset?: number } = {}) => {
    const qs = new URLSearchParams();
    if (q && q.trim()) qs.set('q', q.trim());
    if (opts.limit !== undefined) qs.set('limit', String(opts.limit));
    if (opts.offset !== undefined) qs.set('offset', String(opts.offset));
    const suffix = qs.toString();
    return apiRequest<{ channels: ChannelSummary[]; total: number }>(`/channels${suffix ? `?${suffix}` : ''}`);
  },

  /** Channels you follow or own, most recently active first. */
  mine: () => apiRequest<{ channels: ChannelSummary[] }>('/channels/mine'),

  create: (input: { name: string; description?: string; category?: string; isPublic?: boolean }) =>
    apiRequest<{ channel: ChannelSummary }>('/channels', { method: 'POST', body: input }),

  get: (channelId: string) => apiRequest<{ channel: ChannelSummary }>(`/channels/${channelId}`),

  update: (channelId: string, patch: { name?: string; description?: string; category?: string }) =>
    apiRequest<{ channel: ChannelSummary }>(`/channels/${channelId}`, { method: 'PATCH', body: patch }),

  follow: (channelId: string) =>
    apiRequest<{ channel: ChannelSummary }>(`/channels/${channelId}/follow`, { method: 'POST' }),

  unfollow: (channelId: string) =>
    apiRequest<{ channel: ChannelSummary }>(`/channels/${channelId}/follow`, { method: 'DELETE' }),

  setMuted: (channelId: string, muted: boolean) =>
    apiRequest<{ isMuted: boolean }>(`/channels/${channelId}/mute`, { method: 'PUT', body: { muted } }),

  /** Clears the "N new posts" watermark. */
  markRead: (channelId: string) =>
    apiRequest<{ lastReadSeq: number }>(`/channels/${channelId}/read`, { method: 'POST' }),

  posts: (channelId: string, opts: { limit?: number; beforeSeq?: number } = {}) => {
    const qs = new URLSearchParams();
    if (opts.limit !== undefined) qs.set('limit', String(opts.limit));
    if (opts.beforeSeq !== undefined) qs.set('beforeSeq', String(opts.beforeSeq));
    const suffix = qs.toString();
    return apiRequest<{ posts: ChannelPost[] }>(`/channels/${channelId}/posts${suffix ? `?${suffix}` : ''}`);
  },

  createPost: (
    channelId: string,
    input: {
      type: 'text' | 'image' | 'video' | 'audio';
      body?: string;
      attachments?: Array<{
        kind: 'image' | 'video' | 'audio' | 'document';
        mimeType: string;
        storageKey: string;
        byteSize?: number;
        width?: number;
        height?: number;
        durationMs?: number;
      }>;
    },
  ) => apiRequest<{ post: ChannelPost }>(`/channels/${channelId}/posts`, { method: 'POST', body: input }),

  deletePost: (channelId: string, postId: string) =>
    apiRequest<Record<string, never>>(`/channels/${channelId}/posts/${postId}`, { method: 'DELETE' }),

  /** Toggles: the same emoji twice removes it. */
  react: (postId: string, emoji: string) =>
    apiRequest<Record<string, never>>(`/channels/posts/${postId}/reactions`, { method: 'POST', body: { emoji } }),
};

export const notifications = {
  /**
   * The notification list. `unreadCount` comes back alongside it so a header
   * badge does not need a second round trip.
   */
  list: (opts: { unreadOnly?: boolean; limit?: number } = {}) => {
    const qs = new URLSearchParams();
    if (opts.unreadOnly) qs.set('unreadOnly', 'true');
    if (opts.limit !== undefined) qs.set('limit', String(opts.limit));
    const suffix = qs.toString();
    return apiRequest<{ notifications: AppNotification[]; unreadCount: number }>(
      `/notifications${suffix ? `?${suffix}` : ''}`,
    );
  },

  /** Omitting `ids` marks everything read — the "clear all" affordance. */
  markRead: (ids?: string[]) =>
    apiRequest<{ updated: number }>('/notifications/read', { method: 'POST', body: ids ? { ids } : {} }),
};

// ---------------------------------------------------------------------------
// Users & contacts
// ---------------------------------------------------------------------------

export const users = {
  search: (q: string) =>
    apiRequest<{ results: UserSearchResult[] }>(`/users/search?q=${encodeURIComponent(q)}`),

  /**
   * The people directory. Call with no argument to list everyone on this
   * deployment, oldest account first; pass a term to filter by name/username.
   * Filters server-side so a large member list does not have to be downloaded
   * in full before it can be searched.
   */
  directory: (q?: string, opts: { limit?: number; offset?: number } = {}) => {
    const qs = new URLSearchParams();
    if (q && q.trim()) qs.set('q', q.trim());
    if (opts.limit !== undefined) qs.set('limit', String(opts.limit));
    if (opts.offset !== undefined) qs.set('offset', String(opts.offset));
    const suffix = qs.toString();
    return apiRequest<{ members: DirectoryMember[]; total: number; limit: number; offset: number }>(
      `/users/directory${suffix ? `?${suffix}` : ''}`,
    );
  },
};

export const contacts = {
  add: (contactUserId: string, displayName?: string) =>
    apiRequest<{ id: string }>('/contacts', { method: 'POST', body: { contactUserId, displayName } }),

  list: () =>
    apiRequest<{
      contacts: {
        id: string;
        contact_user_id: string | null;
        display_name: string | null;
        is_favorite: boolean;
        label_name: string | null;
        username: string | null;
        profile_name: string | null;
        avatar_url: string | null;
      }[];
    }>('/contacts'),

  remove: (contactId: string) => apiRequest<{ message: string }>(`/contacts/${contactId}`, { method: 'DELETE' }),

  // --- blocking -------------------------------------------------------------
  block: (userId: string, reason?: string) =>
    apiRequest<{ message: string }>('/blocks', { method: 'POST', body: { userId, reason } }),

  unblock: (userId: string) => apiRequest<{ message: string }>(`/blocks/${userId}`, { method: 'DELETE' }),

  listBlocked: () =>
    apiRequest<{
      blocked: {
        id: string;
        blocked_id: string;
        reason: string | null;
        username: string | null;
        display_name: string | null;
      }[];
    }>('/blocks'),

  // --- reporting ------------------------------------------------------------
  report: (input: {
    targetType: 'user' | 'message' | 'group' | 'channel' | 'community' | 'status' | 'business';
    targetId: string;
    reason:
      | 'spam' | 'scam' | 'harassment' | 'hate' | 'violence'
      | 'sexual_content' | 'child_safety' | 'impersonation' | 'intellectual_property' | 'other';
    details?: string;
  }) => apiRequest<{ id: string; message: string }>('/reports', { method: 'POST', body: input }),
};

// ---------------------------------------------------------------------------
// Chats & messages
// ---------------------------------------------------------------------------

export const chats = {
  list: (filter: 'all' | 'unread' | 'groups' | 'direct' | 'archived' | 'favorites' = 'all') =>
    apiRequest<{ chats: ChatSummary[] }>(`/chats?filter=${filter}`),

  detail: (chatId: string) => apiRequest<ChatDetail>(`/chats/${chatId}`),

  createDirect: (userId: string) =>
    apiRequest<{ chatId: string; created: boolean }>('/chats/direct', { method: 'POST', body: { userId } }),

  createGroup: (input: { title: string; memberIds: string[] }) =>
    apiRequest<{ chatId: string }>('/chats/group', { method: 'POST', body: input }),

  markRead: (chatId: string, upToSeq?: number) =>
    apiRequest<{ lastReadSeq: number }>(`/chats/${chatId}/read`, { method: 'POST', body: { upToSeq } }),

  typing: (chatId: string, typing: boolean) =>
    apiRequest<{ typing: boolean }>(`/chats/${chatId}/typing`, { method: 'POST', body: { typing } }),

  // --- membership -----------------------------------------------------------
  addMembers: (chatId: string, userIds: string[]) =>
    apiRequest<{ added: string[] }>(`/chats/${chatId}/members`, { method: 'POST', body: { userIds } }),

  removeMember: (chatId: string, userId: string, options: { ban?: boolean; reason?: string } = {}) => {
    const qs = new URLSearchParams();
    if (options.ban) qs.set('ban', 'true');
    if (options.reason) qs.set('reason', options.reason);
    const suffix = qs.toString() ? `?${qs.toString()}` : '';
    return apiRequest<{ message: string }>(`/chats/${chatId}/members/${userId}${suffix}`, { method: 'DELETE' });
  },

  /** Leaving is the same endpoint with your own id — the server detects self-removal. */
  leave: (chatId: string, userId: string) =>
    apiRequest<{ message: string }>(`/chats/${chatId}/members/${userId}`, { method: 'DELETE' }),

  setRole: (chatId: string, userId: string, role: 'admin' | 'member') =>
    apiRequest<{ message: string }>(`/chats/${chatId}/members/${userId}/role`, { method: 'POST', body: { role } }),

  updateChat: (
    chatId: string,
    patch: {
      title?: string;
      description?: string;
      disappearingSeconds?: number;
      whoCanSend?: 'everyone' | 'admins';
      whoCanEditInfo?: 'everyone' | 'admins';
      whoCanAddMembers?: 'everyone' | 'admins';
      whoCanPin?: 'everyone' | 'admins';
    },
  ) => apiRequest<{ message: string }>(`/chats/${chatId}`, { method: 'PATCH', body: patch }),

  invite: (
    chatId: string,
    options: { expiresInHours?: number; maxUses?: number; requireApproval?: boolean } = {},
  ) =>
    apiRequest<{ id: string; code: string; url: string; qrPayload: string }>(`/chats/${chatId}/invites`, {
      method: 'POST',
      body: options,
    }),

  join: (code: string) =>
    apiRequest<{ joined: boolean; chatId?: string; requestId?: string; message: string }>(`/chats/join/${code}`, {
      method: 'POST',
    }),
};

export const messages = {
  list: (chatId: string, params: { limit?: number; before?: number } = {}) => {
    const qs = new URLSearchParams();
    qs.set('limit', String(params.limit ?? 50));
    if (params.before !== undefined) qs.set('before', String(params.before));
    return apiRequest<{ messages: Message[]; hasMore: boolean }>(`/chats/${chatId}/messages?${qs.toString()}`);
  },

  /**
   * `clientId` makes the send idempotent: if the request times out and the user
   * taps retry, the server recognises the id and returns the existing message
   * instead of creating a duplicate.
   */
  send: (chatId: string, body: string, clientId?: string) =>
    apiRequest<{ message: Message }>(`/chats/${chatId}/messages`, {
      method: 'POST',
      body: { body, type: 'text', clientId },
    }),

  markRead: (chatId: string, upToSeq?: number) =>
    apiRequest<{ lastReadSeq: number }>(`/chats/${chatId}/messages/read`, { method: 'POST', body: { upToSeq } }),

  /**
   * Send a message carrying an already-uploaded attachment. Two steps rather
   * than one multipart request so the file can be retried on its own without
   * re-sending the message text, and so the client can show upload progress.
   */
  sendAttachment: (chatId: string, attachment: UploadedAttachment, caption?: string, clientId?: string) =>
    apiRequest<{ message: Message }>(`/chats/${chatId}/messages`, {
      method: 'POST',
      body: {
        type: attachment.kind === 'image' ? 'image' : attachment.kind === 'video' ? 'video' : 'document',
        body: caption,
        clientId,
        attachments: [attachment],
      },
    }),

  react: (chatId: string, messageId: string, emoji: string) =>
    apiRequest<{ message: string }>(`/chats/${chatId}/messages/${messageId}/reactions`, {
      method: 'POST',
      body: { emoji },
    }),

  remove: (chatId: string, messageId: string, scope: 'me' | 'everyone' = 'me') =>
    apiRequest<{ message: string }>(`/chats/${chatId}/messages/${messageId}?scope=${scope}`, { method: 'DELETE' }),

  search: (q: string, chatId?: string) => {
    const qs = new URLSearchParams({ q });
    if (chatId) qs.set('chatId', chatId);
    return apiRequest<{ messages: Message[] }>(`/messages/search?${qs.toString()}`);
  },
};

// ---------------------------------------------------------------------------
// Attachments
// ---------------------------------------------------------------------------

/** The current access token, for building authenticated media URLs. */
export async function currentAccessToken(): Promise<string | null> {
  const tokens = memoryTokens ?? (await loadStoredTokens());
  return tokens?.accessToken ?? null;
}

/**
 * URL for an attachment's bytes. The token goes in the query string because
 * React Native's <Image> cannot be relied on to attach an Authorization header
 * on every platform.
 *
 * CAVEAT: access tokens live 15 minutes. A conversation left open longer than
 * that will show broken images until the next API call refreshes the token. A
 * signed media URL with its own expiry would remove that limitation.
 */
/**
 * Where to fetch the bytes for a status attachment.
 *
 * Same shape as attachmentUrl and for the same reason: React Native's <Image>
 * cannot be relied on to send an Authorization header, so the token goes in the
 * query string. The route behind it authorises on the status, so narrowing your
 * audience cuts off the file as well as the metadata.
 */
/**
 * Where to fetch a member's profile photo.
 *
 * The `avatarUrl` saved on the profile is the URL returned by the upload
 * endpoint, and that URL points at the configured media host — which in this
 * deployment is `http://localhost:8080`, unreachable from a phone. Saving it
 * therefore uploads a picture that never appears. This route resolves the stored
 * URL back to the file server-side, so the profile still stores a URL (which is
 * what the API's own validation requires) and the picture still renders.
 */
export function avatarMediaUrl(userId: string, accessToken: string | null): string {
  return `${apiBaseUrl()}/me/avatar/${userId}?token=${encodeURIComponent(accessToken ?? '')}`;
}

export function statusMediaUrl(attachmentId: string, accessToken: string | null): string {
  return `${apiBaseUrl()}/status/media/${attachmentId}?token=${encodeURIComponent(accessToken ?? '')}`;
}

export function attachmentUrl(attachmentId: string, accessToken: string | null): string {
  return `${apiBaseUrl()}/attachments/${attachmentId}?token=${encodeURIComponent(accessToken ?? '')}`;
}

export interface UploadedAttachment {
  kind: 'image' | 'video' | 'audio' | 'voice' | 'document' | 'sticker' | 'gif';
  mimeType: string;
  fileName?: string;
  byteSize: number;
  storageDriver: string;
  storageKey: string;
  publicUrl?: string;
  sha256?: string;
}

export const media = {
  /**
   * Upload one file. Written with raw fetch rather than apiRequest because
   * multipart bodies must not go through the JSON wrapper — and, critically,
   * the Content-Type header must be left for fetch to set, so it can include
   * the multipart boundary. Setting it by hand produces a request the server
   * cannot parse.
   */
  upload: async (file: { uri: string; fileName?: string; mimeType?: string; kind?: UploadedAttachment['kind'] }): Promise<UploadedAttachment> => {
    const tokens = memoryTokens ?? (await loadStoredTokens());
    if (!tokens?.accessToken) throw new ApiError(401, 'session_revoked', 'You are not signed in.');

    const name = file.fileName ?? `upload-${Date.now()}.jpg`;
    const type = file.mimeType ?? 'image/jpeg';

    const form = new FormData();
    // React Native's FormData accepts this {uri, name, type} shape for a file
    // part; the DOM typings do not describe it, hence the cast.
    form.append('file', { uri: file.uri, name, type } as unknown as Blob);

    let res: Response;
    try {
      res = await fetch(`${apiBaseUrl()}/media/upload`, {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${tokens.accessToken}`,
        },
        body: form,
      });
    } catch (err) {
      // The address is included for the same reason as in apiRequest: "cannot
      // reach the server" is only actionable once you can see *which* server,
      // and the app can be pointed at any address from Server settings.
      throw new NetworkError(
        `Upload failed to reach the server at ${apiBaseUrl()}. ${
          err instanceof Error ? err.message : 'Unknown network failure'
        }`,
      );
    }

    const text = await res.text();
    let json: { attachment?: UploadedAttachment; error?: string; message?: string } = {};
    try {
      json = text ? JSON.parse(text) : {};
    } catch {
      // Leave json empty; the error below reports the status.
    }

    if (!res.ok || !json.attachment) {
      throw new ApiError(res.status, json.error ?? 'upload_failed', json.message ?? `Upload failed (${res.status})`);
    }
    return json.attachment;
  },
};

// ---------------------------------------------------------------------------
// Status — posts that disappear after 24 hours
// ---------------------------------------------------------------------------

export type StatusType = 'text' | 'image' | 'video' | 'gif' | 'voice';

/**
 * Who may see your statuses. A profile-level setting, matching how WhatsApp
 * presents it, rather than a choice made per post.
 */
export type StatusVisibility = 'everyone' | 'contacts' | 'contacts_except' | 'nobody';

export interface StatusAttachment {
  id: string;
  kind: string;
  mimeType: string;
  storageKey: string;
  publicUrl: string | null;
  thumbnailUrl: string | null;
  byteSize: number;
  durationMs: number | null;
  width: number | null;
  height: number | null;
}

export interface StatusItem {
  id: string;
  type: StatusType;
  body: string | null;
  caption: string | null;
  backgroundColor: string | null;
  createdAt: string;
  expiresAt: string;
  attachments: StatusAttachment[];
  /** Present on your own statuses: how many people have looked. */
  viewCount?: number;
  myReaction?: string | null;
}

/** One person's run of live statuses. */
export interface StatusGroup {
  user: { id: string; displayName: string | null; username: string | null; avatarUrl: string | null };
  statuses: StatusItem[];
  latestAt: string;
  hasUnviewed: boolean;
}

export interface StatusViewer {
  id: string;
  displayName: string | null;
  username: string | null;
  avatarUrl: string | null;
  viewedAt: string;
}

export const status = {
  /** Everything the Updates tab needs: your own, everyone else's, and the setting. */
  all: () =>
    apiRequest<{ mine: StatusItem[]; feed: StatusGroup[]; visibility: StatusVisibility }>('/status'),

  create: (input: {
    type: StatusType;
    body?: string;
    caption?: string;
    backgroundColor?: string;
    attachments?: Array<{
      kind: 'image' | 'video' | 'voice' | 'gif';
      mimeType: string;
      storageKey: string;
      publicUrl?: string;
      thumbnailUrl?: string;
      byteSize?: number;
      durationMs?: number;
      width?: number;
      height?: number;
    }>;
  }) => apiRequest<{ status: StatusItem }>('/status', { method: 'POST', body: input }),

  setVisibility: (visibility: StatusVisibility) =>
    apiRequest<{ visibility: StatusVisibility }>('/status/visibility', { method: 'PUT', body: { visibility } }),

  get: (statusId: string) =>
    apiRequest<{ status: StatusItem; reactions: Array<{ emoji: string; count: number }> }>(`/status/${statusId}`),

  /** Records that you have seen it, so the ring stops showing as new. */
  view: (statusId: string) => apiRequest<Record<string, never>>(`/status/${statusId}/view`, { method: 'POST' }),

  viewers: (statusId: string) => apiRequest<{ viewers: StatusViewer[] }>(`/status/${statusId}/viewers`),

  react: (statusId: string, emoji: string) =>
    apiRequest<Record<string, never>>(`/status/${statusId}/reactions`, { method: 'POST', body: { emoji } }),

  remove: (statusId: string) => apiRequest<Record<string, never>>(`/status/${statusId}`, { method: 'DELETE' }),
};

// ---------------------------------------------------------------------------
// Realtime
// ---------------------------------------------------------------------------

/**
 * Opens the WebSocket.
 *
 * The token goes in the query string because a browser/RN WebSocket handshake
 * cannot carry an Authorization header. The server accepts it either way and
 * the token is short-lived, which is the mitigation for it appearing in logs.
 */
export async function openRealtimeSocket(
  handlers: {
    onEvent: (event: Record<string, unknown>) => void;
    onOpen?: () => void;
    onClose?: () => void;
    onError?: (message: string) => void;
  },
): Promise<WebSocket | null> {
  const tokens = memoryTokens ?? (await loadStoredTokens());
  if (!tokens?.accessToken) return null;

  let ws: WebSocket;
  try {
    ws = new WebSocket(`${wsUrl()}?token=${encodeURIComponent(tokens.accessToken)}`);
  } catch (err) {
    handlers.onError?.(err instanceof Error ? err.message : 'Could not open the realtime connection');
    return null;
  }

  ws.onopen = () => handlers.onOpen?.();
  ws.onclose = () => handlers.onClose?.();
  ws.onerror = () => handlers.onError?.('Realtime connection error');

  ws.onmessage = (raw: WebSocketMessageEvent) => {
    try {
      const parsed = JSON.parse(String(raw.data)) as Record<string, unknown>;
      // Answer the server's heartbeat so it does not consider us dead and drop
      // the connection after 90 seconds.
      if (parsed.type === 'ping') {
        ws.send(JSON.stringify({ type: 'pong', t: parsed.t }));
        return;
      }
      handlers.onEvent(parsed);
    } catch {
      // A malformed frame is not worth tearing the connection down for.
    }
  };

  return ws;
}

exp