import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import {
  DEFAULT_API_BASE_URL,
  apiBaseUrl,
  clearTokens,
  serverUrlOrigin,
  setServerUrl,
  testServerConnection,
} from '../api/client';
import { ErrorBanner, Notice, PrimaryButton, Screen, TextField } from '../components/ui';
import { describeError, useAuth } from '../state/AuthContext';
import { colors, spacing, typography } from '../theme';

/**
 * Where the app looks for the backend.
 *
 * This screen is reachable from the signed-OUT screens as well as the profile,
 * and that is deliberate: if the app is pointed at a dead server, the user
 * cannot sign in — so a settings screen only reachable after signing in would
 * be useless exactly when it is needed.
 *
 * Changing the server clears the stored session. A token issued by one server
 * means nothing to another, so keeping it would produce a wall of 401s.
 */
export function ServerSettingsScreen({ onBack }: { onBack: () => void }) {
  const { signOut } = useAuth();
  const [input, setInput] = useState(apiBaseUrl());
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [probe, setProbe] = useState<string | null>(null);

  const test = async () => {
    setBusy('test');
    setError(null);
    setNotice(null);
    setProbe(null);
    try {
      const result = await testServerConnection(input);
      if (!result.ok) {
        setError(`Could not reach ${input.trim()}: ${result.error}`);
        return;
      }
      const db = result.ready?.database;
      setProbe(
        [
          `/health       ${result.health?.status ?? '?'}  (up ${result.health?.uptimeSeconds ?? '?'}s)`,
          `/health/ready ${result.ready?.status ?? 'unreachable'}${db ? `  db ok=${db.ok} ${db.latencyMs}ms` : ''}`,
          `round trip    ${result.latencyMs}ms`,
        ].join('\n'),
      );
      if (db && db.ok === false) {
        setNotice('The API is up but cannot reach its database. Check DATABASE_URL on the server.');
      }
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(null);
    }
  };

  const save = async () => {
    setBusy('save');
    setError(null);
    setNotice(null);
    try {
      // Verify before committing — saving a dead address leaves the app unable
      // to do anything until it is corrected.
      const result = await testServerConnection(input);
      if (!result.ok) {
        setError(`Not saved: ${result.error}`);
        return;
      }
      await setServerUrl(input);
      await clearTokens();
      await signOut();
      setNotice('Server saved. Sign in again.');
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(null);
    }
  };

  const reset = async () => {
    setBusy('reset');
    setError(null);
    setNotice(null);
    setProbe(null);
    try {
      await setServerUrl(null);
      setInput(DEFAULT_API_BASE_URL);
      await clearTokens();
      await signOut();
      setNotice(`Reset to the default: ${DEFAULT_API_BASE_URL}`);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(null);
    }
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>{'‹'}</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Server settings</Text>
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={styles.hint}>
            Currently using the {serverUrlOrigin() === 'saved' ? 'saved' : 'built-in default'} address:
          </Text>
          <Text style={styles.current} selectable>
            {apiBaseUrl()}
          </Text>

          {error ? <ErrorBanner message={error} /> : null}
          {notice ? <Notice message={notice} tone="success" /> : null}
          {probe ? <Text style={styles.probe}>{probe}</Text> : null}

          <TextField
            label="Server address"
            value={input}
            onChangeText={setInput}
            placeholder="http://203.0.113.10:3049"
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            hint="Include the port. Hostnames work too, e.g. https://api.example.com"
          />

          <PrimaryButton title="Test connection" onPress={test} loading={busy === 'test'} variant="secondary" />
          <PrimaryButton title="Save and sign out" onPress={save} loading={busy === 'save'} />
          <Pressable onPress={reset} disabled={busy !== null} style={styles.linkRow}>
            <Text style={styles.link}>Reset to default</Text>
          </Pressable>

          <Text style={styles.note}>
            This exists so moving the backend does not require a new APK. It is still worth putting the
            API behind a fixed https:// hostname — then the address never changes at all, and traffic is
            encrypted instead of plain HTTP.
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { fontSize: 18, fontWeight: '600', color: colors.text },
  content: { padding: spacing.xl, paddingBottom: spacing.xxl, gap: spacing.md },
  hint: { ...typography.subtitle, fontSize: 14 },
  current: {
    fontFamily: 'monospace',
    fontSize: 13,
    color: colors.text,
    backgroundColor: colors.surface,
    padding: spacing.md,
    borderRadius: 8,
  },
  probe: {
    fontFamily: 'monospace',
    fontSize: 12,
    color: colors.text,
    backgroundColor: colors.surfaceAlt,
    padding: spacing.md,
    borderRadius: 8,
    lineHeight: 18,
  },
  linkRow: { alignItems: 'center', paddingVertical: spacing.sm },
  link: { color: colors.primary, fontWeight: '600', fontSize: 14 },
  note: { ...typography.small, lineHeight: 17, marginTop: spacing.sm },
});
