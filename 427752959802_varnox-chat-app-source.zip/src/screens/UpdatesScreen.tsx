import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { status as statusApi, type StatusGroup, type StatusItem, type StatusVisibility } from '../api/client';
import { TabHeader } from '../components/TabBar';
import { Avatar, EmptyState, ErrorBanner, Screen } from '../components/ui';
import { describeError, useAuth } from '../state/AuthContext';
import { colors, formatTimestamp, spacing, typography } from '../theme';

/**
 * The Updates tab — status.
 *
 * Two rows at the top, then everyone else's runs. The order matches WhatsApp:
 * your own status first because it is the one you manage, then other people,
 * newest first.
 *
 * The empty state is worth reading carefully, because the most likely reason
 * for an empty list is not "nobody posted" — it is that `status_visibility`
 * defaults to `contacts` and a deployment with no contact lists therefore shows
 * nothing. The screen says so and links straight to the setting rather than
 * leaving you to guess.
 */

const VISIBILITY_LABEL: Record<StatusVisibility, string> = {
  everyone: 'Everyone',
  contacts: 'My contacts',
  contacts_except: 'My contacts except…',
  nobody: 'Nobody',
};

export function UpdatesScreen({
  onOpenDrawer,
  onCompose,
  onOpenViewer,
  onOpenChannels,
  onOpenSettings,
}: {
  onOpenDrawer: () => void;
  onCompose: () => void;
  onOpenViewer: (authorUserId: string) => void;
  onOpenChannels: () => void;
  onOpenSettings: () => void;
}) {
  const { user } = useAuth();
  const [mine, setMine] = useState<StatusItem[]>([]);
  const [feed, setFeed] = useState<StatusGroup[]>([]);
  const [visibility, setVisibility] = useState<StatusVisibility>('contacts');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const data = await statusApi.all();
      setMine(data.mine ?? []);
      setFeed(data.feed ?? []);
      setVisibility(data.visibility);
      setError(null);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  // The router renders only the top of the stack, so returning to this tab
  // remounts it and this effect runs again — no explicit focus subscription is
  // needed to pick up a status posted or deleted on another screen.
  useEffect(() => {
    void load();
  }, [load]);

  const totalViews = mine.reduce((sum, item) => sum + (item.viewCount ?? 0), 0);
  const myLatest = mine[mine.length - 1];

  return (
    <Screen>
      <TabHeader title="Updates" subtitle="Status and channels" onOpenDrawer={onOpenDrawer} />

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={feed}
          keyExtractor={(group) => group.user.id}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                setRefreshing(true);
                void load();
              }}
            />
          }
          ListHeaderComponent={
            <View>
              <Text style={styles.sectionLabel}>My status</Text>
              <Pressable
                style={styles.row}
                onPress={() => (mine.length > 0 ? onOpenViewer(user?.id ?? '') : onCompose())}
              >
                <View style={[styles.ring, mine.length > 0 ? styles.ringActive : styles.ringIdle]}>
                  <Avatar name={user?.fullName ?? user?.email ?? '?'} size={44} />
                </View>
                <View style={styles.rowBody}>
                  <Text style={styles.rowTitle}>
                    {mine.length > 0 ? 'My status' : 'Tap to add a status update'}
                  </Text>
                  <Text style={styles.rowSub}>
                    {mine.length > 0
                      ? `${mine.length} update${mine.length === 1 ? '' : 's'} · ${totalViews} view${totalViews === 1 ? '' : 's'} · ${formatTimestamp(myLatest?.createdAt)}`
                      : `Visible to: ${VISIBILITY_LABEL[visibility]}`}
                  </Text>
                </View>
                {mine.length > 0 ? (
                  <Pressable onPress={onCompose} hitSlop={8} style={styles.addBadge}>
                    <Text style={styles.addBadgeText}>+</Text>
                  </Pressable>
                ) : null}
              </Pressable>

              <Pressable style={styles.row} onPress={onOpenSettings}>
                <Text style={styles.settingsIcon}>🔒</Text>
                <View style={styles.rowBody}>
                  <Text style={styles.rowTitle}>Status privacy</Text>
                  <Text style={styles.rowSub}>Who can see your statuses · {VISIBILITY_LABEL[visibility]}</Text>
                </View>
                <Text style={styles.chevron}>›</Text>
              </Pressable>

              {feed.length > 0 ? <Text style={styles.sectionLabel}>Recent updates</Text> : null}
            </View>
          }
          renderItem={({ item }) => (
            <Pressable style={styles.row} onPress={() => onOpenViewer(item.user.id)}>
              <View style={[styles.ring, item.hasUnviewed ? styles.ringActive : styles.ringIdle]}>
                <Avatar name={item.user.displayName ?? item.user.username ?? '?'} size={44} />
              </View>
              <View style={styles.rowBody}>
                <Text style={styles.rowTitle} numberOfLines={1}>
                  {item.user.displayName ?? item.user.username ?? 'Unnamed'}
                </Text>
                <Text style={styles.rowSub}>
                  {formatTimestamp(item.latestAt)} ·{' '}
                  {item.statuses.length} update{item.statuses.length === 1 ? '' : 's'}
                </Text>
              </View>
            </Pressable>
          )}
          ListFooterComponent={
            <View>
              <Pressable style={styles.row} onPress={onOpenChannels}>
                <Text style={styles.settingsIcon}>📣</Text>
                <View style={styles.rowBody}>
                  <Text style={styles.rowTitle}>Channels</Text>
                  <Text style={styles.rowSub}>Updates broadcast to followers, with no replies</Text>
                </View>
                <Text style={styles.chevron}>›</Text>
              </Pressable>
            </View>
          }
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <EmptyState
                title="No status updates to show"
                subtitle={
                  visibility === 'everyone'
                    ? 'Nobody has posted in the last 24 hours. Tap “Tap to add a status update” to post one.'
                    : 'This may simply be your privacy setting: most people share only with their contacts, and a deployment with no contact lists shows nothing. Tap Status privacy above to widen it, or add contacts.'
                }
              />
            </View>
          }
        />
      )}
    </Screen>
  );
}

/** Who may see your statuses. Writes the profile-level setting. */
export function StatusPrivacyScreen({ onBack, onSaved }: { onBack: () => void; onSaved: () => void }) {
  const [current, setCurrent] = useState<StatusVisibility | null>(null);
  const [saving, setSaving] = useState<StatusVisibility | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void (async () => {
      try {
        const data = await statusApi.all();
        setCurrent(data.visibility);
      } catch (err) {
        setError(describeError(err));
      }
    })();
  }, []);

  const choose = async (visibility: StatusVisibility) => {
    setSaving(visibility);
    setError(null);
    try {
      await statusApi.setVisibility(visibility);
      setCurrent(visibility);
      onSaved();
    } catch (err) {
      setError(describeError(err));
    } finally {
      setSaving(null);
    }
  };

  const options: Array<{ id: StatusVisibility; label: string; hint: string }> = [
    { id: 'everyone', label: 'Everyone', hint: 'Anyone on this deployment can see your statuses' },
    { id: 'contacts', label: 'My contacts', hint: 'Only people in your contact list' },
    { id: 'nobody', label: 'Nobody', hint: 'Stop sharing statuses without deleting them' },
  ];

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>‹</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Status privacy</Text>
      </View>

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      {options.map((option) => (
        <Pressable key={option.id} style={styles.row} onPress={() => void choose(option.id)} disabled={saving !== null}>
          <View style={styles.radioOuter}>
            {current === option.id ? <View style={styles.radioInner} /> : null}
          </View>
          <View style={styles.rowBody}>
            <Text style={styles.rowTitle}>{option.label}</Text>
            <Text style={styles.rowSub}>{option.hint}</Text>
          </View>
          {saving === option.id ? <ActivityIndicator size="small" /> : null}
        </Pressable>
      ))}

      <Text style={styles.footnote}>
        This is a profile setting rather than a per-status choice, which is how WhatsApp treats it. It applies to every
        status you post, now and later.
      </Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  sectionLabel: {
    ...typography.small,
    fontWeight: '600',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.lg,
    paddingBottom: spacing.xs,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.lg,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  rowBody: { flex: 1 },
  rowTitle: { fontSize: 16, fontWeight: '600', color: colors.text },
  rowSub: { ...typography.small, marginTop: 2 },
  chevron: { fontSize: 24, color: colors.textFaint },
  settingsIcon: { fontSize: 20, width: 30, textAlign: 'center' },

  // The ring around an avatar is the whole unviewed/viewed signal, so it is a
  // ring rather than a badge: no colour when there is nothing new.
  ring: { borderRadius: 999, padding: 3, borderWidth: 2 },
  ringActive: { borderColor: colors.primary },
  ringIdle: { borderColor: colors.border },

  addBadge: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addBadgeText: { color: '#FFFFFF', fontSize: 20, lineHeight: 22 },

  radioOuter: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioInner: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.primary },

  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  errorWrap: { paddingHorizontal: spacing.lg },
  emptyWrap: { paddingTop: spacing.lg },
  footnote: { ...typography.small, padding: spacing.lg },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { fontSize: 18, fontWeight: '600', color: colors.text },
});
