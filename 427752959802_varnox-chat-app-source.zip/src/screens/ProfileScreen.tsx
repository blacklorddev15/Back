import React, { useCallback, useEffect, useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import * as Updates from 'expo-updates';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import {
  auth,
  avatarMediaUrl,
  currentAccessToken,
  media,
  me,
  type DeviceSummary,
  type MeResponse,
  type PrivacyPatch,
  type SecurityEvent,
} from '../api/client';
import { Avatar, ErrorBanner, Notice, PrimaryButton, Screen } from '../components/ui';
import { describeError } from '../state/AuthContext';
import { colors, formatTimestamp, spacing, typography } from '../theme';

/**
 * Account settings.
 *
 * Everything here maps to an endpoint that already existed on the backend —
 * this screen is the missing UI for profile editing, privacy controls, device
 * management, the security log and account deletion.
 *
 * The privacy row values are read defensively: the API returns raw settings
 * rows with snake_case keys, and a missing row (a user created before a
 * setting existed) must not crash the screen.
 */

const LAST_SEEN_CYCLE = ['everyone', 'contacts', 'contacts_except', 'nobody'] as const;

function boolOf(value: unknown, fallback: boolean): boolean {
  return typeof value === 'boolean' ? value : fallback;
}

function stringOf(value: unknown, fallback: string): string {
  return typeof value === 'string' ? value : fallback;
}

export function ProfileScreen({
  onBack,
  onOpenServerSettings,
  onOpenBlocked,
}: {
  onBack: () => void;
  onOpenServerSettings: () => void;
  onOpenBlocked: () => void;
}) {
  const [profile, setProfile] = useState<MeResponse | null>(null);
  const [devices, setDevices] = useState<DeviceSummary[]>([]);
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [displayName, setDisplayName] = useState('');
  const [about, setAbout] = useState('');
  const [twoStepPassword, setTwoStepPassword] = useState('');
  const [twoStepPin, setTwoStepPin] = useState('');
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  // Needed to build the authenticated URL the photo is fetched from.
  const [token, setToken] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    void currentAccessToken().then(setToken);
  }, []);

  /**
   * Pick a photo, upload it, then point the profile at it.
   *
   * The order matters: the profile is only updated once the upload has
   * succeeded, so a failed upload leaves the old photo in place rather than
   * clearing it. The URL saved is the one the upload returned — the render path
   * resolves it back to the file, because that URL's host is not reachable from
   * a phone.
   */
  const changePhoto = async () => {
    setError(null);
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        setError('Photo access is required to set a profile picture.');
        return;
      }

      const picked = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.7,
      });
      if (picked.canceled || picked.assets.length === 0) return;

      const asset = picked.assets[0]!;
      setUploadingPhoto(true);
      const uploaded = await media.upload({
        uri: asset.uri,
        fileName: asset.fileName ?? undefined,
        mimeType: asset.mimeType ?? 'image/jpeg',
      });
      await me.updateProfile({ avatarUrl: uploaded.publicUrl ?? uploaded.storageKey });
      await load();
      setNotice('Profile photo updated.');
    } catch (err) {
      setError(describeError(err));
    } finally {
      setUploadingPhoto(false);
    }
  };

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Fetched together: they are all small and the screen is useless without
      // any one of them, so three sequential round trips would just be slower.
      const [self, deviceList, security] = await Promise.all([
        me.get(),
        auth.listDevices().catch(() => ({ devices: [] as DeviceSummary[] })),
        auth.securityLog(10).catch(() => ({ events: [] as SecurityEvent[] })),
      ]);
      setProfile(self);
      setUserId(self.id);
      setDisplayName(self.display_name ?? self.full_name ?? '');
      setAbout(self.about ?? '');
      setDevices(deviceList.devices ?? []);
      setEvents(security.events ?? []);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const run = async (key: string, action: () => Promise<unknown>, successMessage?: string) => {
    setBusy(key);
    setError(null);
    setNotice(null);
    try {
      await action();
      if (successMessage) setNotice(successMessage);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(null);
    }
  };

  const saveProfile = () =>
    run('profile', async () => {
      await me.updateProfile({ displayName: displayName.trim(), about: about.trim() });
      await load();
    }, 'Profile saved.');

  const patchPrivacy = (patch: PrivacyPatch) =>
    run('privacy', async () => {
      const result = await me.updatePrivacy(patch);
      setProfile((current) => (current ? { ...current, privacy: result.privacy } : current));
    });

  const cycleLastSeen = () => {
    const current = stringOf(profile?.privacy?.last_seen_visibility, 'contacts');
    const next = LAST_SEEN_CYCLE[(LAST_SEEN_CYCLE.indexOf(current as never) + 1) % LAST_SEEN_CYCLE.length]!;
    void patchPrivacy({ lastSeenVisibility: next });
  };

  const revokeDevice = (device: DeviceSummary) => {
    Alert.alert(
      'Sign out this device?',
      `${device.device_name ?? device.platform} will need to sign in again.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign out',
          style: 'destructive',
          onPress: () => void run(`device-${device.id}`, async () => {
            await auth.revokeDevice(device.id);
            await load();
          }, 'Device signed out.'),
        },
      ],
    );
  };

  const enableTwoStep = () =>
    run('enable2fa', async () => {
      const result = await auth.enableTwoStep(twoStepPassword, twoStepPin);
      setTwoStepPassword('');
      setTwoStepPin('');
      await load();
      Alert.alert(
        'Two-step verification is on',
        `Store these one-use backup codes somewhere safe:\n\n${result.backupCodes.join('\n')}`,
      );
    });

  const disableTwoStep = () =>
    run('disable2fa', async () => {
      await auth.disableTwoStep(twoStepPassword);
      setTwoStepPassword('');
      await load();
    }, 'Two-step verification is off.');

  const deleteAccount = () => {
    Alert.alert(
      'Delete your account?',
      'Your account is deactivated immediately and permanently deleted after 30 days. Signing in again before then cancels it.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => void run('delete', async () => {
            const result = await auth.requestAccountDeletion();
            Alert.alert('Account scheduled for deletion', `Scheduled for ${new Date(result.scheduledFor).toLocaleDateString()}.`);
          }),
        },
      ],
    );
  };

  if (loading) {
    return (
      <Screen>
        <Header onBack={onBack} title="Profile" />
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      </Screen>
    );
  }

  const privacy = profile?.privacy ?? {};

  return (
    <Screen>
      <Header onBack={onBack} title="Profile" />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {error ? <ErrorBanner message={error} /> : null}
        {notice ? <Notice message={notice} tone="success" /> : null}

        {/* ---------------- identity ---------------- */}
        <View style={styles.identity}>
          {/* Tapping the avatar is the whole photo control: a separate button
              for one action would be clutter on an identity block. */}
          <Pressable onPress={() => void changePhoto()} disabled={uploadingPhoto} accessibilityLabel="Change profile photo">
            <Avatar
              name={profile?.display_name ?? profile?.username ?? '?'}
              size={64}
              uri={profile?.avatar_url ? avatarMediaUrl(userId ?? '', token) : null}
            />
            <View style={styles.photoBadge}>
              <Text style={styles.photoBadgeText}>{uploadingPhoto ? '…' : '📷'}</Text>
            </View>
          </Pressable>
          <View style={styles.identityText}>
            <Text style={styles.name}>{profile?.display_name ?? profile?.full_name ?? 'No name set'}</Text>
            <Text style={styles.handle}>{profile?.username ? `@${profile.username}` : 'No username'}</Text>
            <Text style={styles.meta}>{profile?.email ?? ''}</Text>
            <Text style={styles.meta}>
              {profile?.phone ?? ''}
              {profile?.phone_verified_at ? '' : ' · not verified'}
            </Text>
          </View>
        </View>

        {/* ---------------- what the phone is running ----------------
            Placed directly under the identity block rather than at the bottom
            of the screen: while changes are being verified this is the first
            thing you need, and a card that requires scrolling past the device
            list to find is a card that gets reported as missing. */}
        <Section title="App update">
          <AppUpdateCard />
        </Section>

        {/* ---------------- editable profile ---------------- */}
        <Section title="Profile">
          <LabeledInput label="Display name" value={displayName} onChangeText={setDisplayName} />
          <LabeledInput label="About" value={about} onChangeText={setAbout} multiline />
          <PrimaryButton title="Save profile" onPress={saveProfile} loading={busy === 'profile'} />
        </Section>

        {/* ---------------- privacy ---------------- */}
        <Section title="Privacy">
          <Pressable style={styles.row} onPress={cycleLastSeen}>
            <Text style={styles.rowLabel}>Last seen</Text>
            <Text style={styles.rowValue}>
              {stringOf(privacy.last_seen_visibility, 'contacts').replace(/_/g, ' ')}
            </Text>
          </Pressable>

          <ToggleRow
            label="Read receipts"
            hint="Turning these off also stops you seeing other people's."
            value={boolOf(privacy.read_receipts_enabled, true)}
            disabled={busy === 'privacy'}
            onChange={(value) => void patchPrivacy({ readReceiptsEnabled: value })}
          />
          <ToggleRow
            label="Findable by username"
            value={boolOf(privacy.discoverable_by_username, true)}
            disabled={busy === 'privacy'}
            onChange={(value) => void patchPrivacy({ discoverableByUsername: value })}
          />
          <ToggleRow
            label="Findable by email"
            value={boolOf(privacy.discoverable_by_email, true)}
            disabled={busy === 'privacy'}
            onChange={(value) => void patchPrivacy({ discoverableByEmail: value })}
          />
          <ToggleRow
            label="Findable by phone"
            value={boolOf(privacy.discoverable_by_phone, true)}
            disabled={busy === 'privacy'}
            onChange={(value) => void patchPrivacy({ discoverableByPhone: value })}
          />
          <ToggleRow
            label="Silence unknown callers"
            value={boolOf(privacy.silence_unknown_callers, false)}
            disabled={busy === 'privacy'}
            onChange={(value) => void patchPrivacy({ silenceUnknownCallers: value })}
          />
          {/* The way back from a block. Without this entry a block could only
              be undone from the conversation it was placed in. */}
          <Pressable style={styles.navRow} onPress={onOpenBlocked} hitSlop={6}>
            <Text style={styles.navRowLabel}>Blocked contacts</Text>
            <Text style={styles.navRowChevron}>›</Text>
          </Pressable>
        </Section>

        {/* ---------------- two-step ---------------- */}
        <Section title="Two-step verification">
          <Text style={styles.statusLine}>
            Status: {profile?.two_step_enabled ? 'On' : 'Off'}
          </Text>
          <Text style={styles.hint}>
            Adds a 6-digit PIN after your password. Note: your current sign-in method uses your
            password; keep it somewhere safe.
          </Text>
          <LabeledInput
            label="Password"
            value={twoStepPassword}
            onChangeText={setTwoStepPassword}
            secureTextEntry
            placeholder="Confirm your password"
          />
          {!profile?.two_step_enabled ? (
            <>
              <LabeledInput
                label="New PIN"
                value={twoStepPin}
                onChangeText={(text) => setTwoStepPin(text.replace(/[^0-9]/g, ''))}
                keyboardType="number-pad"
                maxLength={6}
                placeholder="6 digits"
              />
              <PrimaryButton
                title="Turn on"
                onPress={enableTwoStep}
                loading={busy === 'enable2fa'}
                disabled={twoStepPassword.length === 0 || twoStepPin.length !== 6}
              />
            </>
          ) : (
            <PrimaryButton
              title="Turn off"
              variant="danger"
              onPress={disableTwoStep}
              loading={busy === 'disable2fa'}
              disabled={twoStepPassword.length === 0}
            />
          )}
        </Section>

        {/* ---------------- devices ---------------- */}
        <Section title="Devices">
          {devices.length === 0 ? <Text style={styles.hint}>No active devices.</Text> : null}
          {devices.map((device) => (
            <View key={device.id} style={styles.row}>
              <View style={styles.flex}>
                <Text style={styles.rowLabel}>
                  {device.device_name ?? device.platform}
                  {device.is_primary ? ' · this device' : ''}
                </Text>
                <Text style={styles.hint}>
                  {device.platform} · seen {formatTimestamp(device.last_seen_at) || 'never'}
                  {device.last_ip ? ` · ${device.last_ip}` : ''}
                </Text>
              </View>
              <Pressable onPress={() => revokeDevice(device)} disabled={busy === `device-${device.id}`}>
                <Text style={styles.dangerLink}>Sign out</Text>
              </Pressable>
            </View>
          ))}
        </Section>

        {/* ---------------- security log ---------------- */}
        <Section title="Recent security activity">
          {events.length === 0 ? <Text style={styles.hint}>Nothing recorded yet.</Text> : null}
          {events.map((event) => (
            <View key={event.id} style={styles.eventRow}>
              <Text style={styles.rowLabel}>{event.event_type.replace(/_/g, ' ')}</Text>
              <Text style={styles.hint}>
                {formatTimestamp(event.created_at)}
                {event.ip ? ` · ${event.ip}` : ''}
              </Text>
            </View>
          ))}
        </Section>

        {/* ---------------- danger zone ---------------- */}
        <Section title="Account">
          <PrimaryButton
            title="Sign out of all devices"
            variant="secondary"
            onPress={() =>
              void run('logoutall', async () => {
                const result = await auth.logoutAll(false);
                Alert.alert('Signed out', `${result.sessionsEnded} other session(s) ended.`);
              })
            }
            loading={busy === 'logoutall'}
          />
          <View style={styles.spacerSm} />
          <PrimaryButton
            title="Server settings"
            variant="secondary"
            onPress={onOpenServerSettings}
          />
          <View style={styles.spacerSm} />
          <PrimaryButton
            title="Delete account"
            variant="danger"
            onPress={deleteAccount}
            loading={busy === 'delete'}
          />
        </Section>
      </ScrollView>
    </Screen>
  );
}

function Header({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <View style={styles.header}>
      <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
        <Text style={styles.backText}>{'‹'}</Text>
      </Pressable>
      <Text style={styles.headerTitle}>{title}</Text>
    </View>
  );
}

/**
 * Which JavaScript bundle this phone is actually running.
 *
 * An over-the-air update and the bundle baked into the APK look identical on
 * screen, so without something like this there is no way to answer "did my
 * change arrive?" from the device itself — you would be comparing remembered
 * pixels. expo-updates knows the id and publish time of the bundle it is
 * executing, so the screen can just state them.
 *
 * The button also removes the two-launch wait: an update published to the
 * channel is normally downloaded on launch and applied on the next one, but
 * this fetches and reloads in place.
 */
type UpdateInfo = {
  enabled: boolean;
  updateId: string | null;
  createdAt: Date | null;
  runtimeVersion: string | null;
  channel: string | null;
  embedded: boolean;
};

function readUpdateInfo(): UpdateInfo | null {
  try {
    return {
      enabled: Updates.isEnabled,
      updateId: Updates.updateId,
      createdAt: Updates.createdAt,
      runtimeVersion: Updates.runtimeVersion,
      channel: Updates.channel,
      embedded: Updates.isEmbeddedLaunch,
    };
  } catch {
    // A binary without the expo-updates native module must not break the screen.
    return null;
  }
}

function AppUpdateCard() {
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  const info = readUpdateInfo();

  const check = useCallback(async () => {
    setBusy(true);
    setNote(null);
    try {
      const found = await Updates.checkForUpdateAsync();
      if (!found.isAvailable) {
        setNote('Already on the newest version.');
        return;
      }
      setNote('Downloading the new version…');
      await Updates.fetchUpdateAsync();
      setNote('Downloaded — restarting now.');
      await Updates.reloadAsync();
    } catch (err) {
      setNote(err instanceof Error ? err.message : 'Could not check for updates.');
    } finally {
      setBusy(false);
    }
  }, []);

  if (!info || !info.enabled) {
    return <Text style={styles.hint}>This build cannot receive over-the-air updates.</Text>;
  }

  const rows: { label: string; value: string }[] = [
    { label: 'Source', value: info.embedded ? 'Built into the app' : 'Over-the-air update' },
    { label: 'Update id', value: info.updateId ? info.updateId.slice(0, 8) : '—' },
    { label: 'Published', value: info.createdAt ? info.createdAt.toLocaleString() : '—' },
    { label: 'Runtime · channel', value: `${info.runtimeVersion ?? '—'} · ${info.channel ?? 'none'}` },
  ];

  return (
    <>
      {rows.map((row) => (
        <View key={row.label} style={styles.row}>
          <Text style={styles.rowLabel}>{row.label}</Text>
          <Text style={styles.updateValue}>{row.value}</Text>
        </View>
      ))}
      <Text style={styles.hint}>
        Each change I publish gets a new update id and publish time, so a fix is confirmed by those
        two values changing — not by trusting a screenshot. The runtime must stay at 1.1.0.
      </Text>
      <PrimaryButton title="Check for updates" onPress={() => void check()} loading={busy} />
      {note ? <Text style={styles.hint}>{note}</Text> : null}
    </>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.sectionBody}>{children}</View>
    </View>
  );
}

function LabeledInput({
  label,
  ...inputProps
}: { label: string } & React.ComponentProps<typeof TextInput>) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        style={styles.input}
        placeholderTextColor={colors.textFaint}
        autoCapitalize="none"
        autoCorrect={false}
        {...inputProps}
      />
    </View>
  );
}

function ToggleRow({
  label,
  hint,
  value,
  onChange,
  disabled,
}: {
  label: string;
  hint?: string;
  value: boolean;
  onChange: (value: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <View style={styles.row}>
      <View style={styles.flex}>
        <Text style={styles.rowLabel}>{label}</Text>
        {hint ? <Text style={styles.hint}>{hint}</Text> : null}
      </View>
      <Switch value={value} onValueChange={onChange} disabled={disabled} />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { fontSize: 18, fontWeight: '600', color: colors.text },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl, gap: spacing.lg },

  navRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
  },
  navRowLabel: { fontSize: 15, color: colors.text },
  navRowChevron: { fontSize: 22, color: colors.textFaint },
  photoBadge: {
    position: 'absolute',
    right: -2,
    bottom: -2,
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoBadgeText: { fontSize: 13 },
  identity: { flexDirection: 'row', gap: spacing.lg, alignItems: 'center' },
  identityText: { flex: 1 },
  name: { fontSize: 20, fontWeight: '700', color: colors.text },
  handle: { ...typography.subtitle, marginTop: 2 },
  meta: { ...typography.small, marginTop: 1 },

  section: { gap: spacing.sm },
  sectionTitle: { ...typography.label, textTransform: 'uppercase', letterSpacing: 0.6 },
  sectionBody: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    padding: spacing.md,
    gap: spacing.md,
    backgroundColor: colors.background,
  },

  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, minHeight: 34 },
  rowLabel: { fontSize: 15, color: colors.text, fontWeight: '500' },
  rowValue: { fontSize: 14, color: colors.textMuted, textTransform: 'capitalize' },
  // No textTransform: the update id, timestamp and runtime are literal values and
  // sentence-casing them would misreport what the app is running.
  updateValue: { flex: 1, fontSize: 14, color: colors.textMuted, textAlign: 'right' },
  eventRow: { gap: 2 },
  hint: { ...typography.small, lineHeight: 16 },
  statusLine: { fontSize: 15, color: colors.text, fontWeight: '600' },
  dangerLink: { color: colors.danger, fontWeight: '600', fontSize: 14 },
  spacerSm: { height: spacing.sm },

  field: { gap: spacing.xs },
  fieldLabel: { ...typography.label },
  input: {
    minHeight: 44,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 10,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    fontSize: 15,
    color: color