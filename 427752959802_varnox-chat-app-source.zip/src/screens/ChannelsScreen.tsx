import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Image, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { channels as channelsApi, currentAccessToken, media, statusMediaUrl, type ChannelPost, type ChannelSummary } from '../api/client';
import * as ImagePicker from 'expo-image-picker';
import { Avatar, EmptyState, ErrorBanner, PrimaryButton, Screen } from '../components/ui';
import { describeError } from '../state/AuthContext';
import { bottomSystemBarClearance, colors, formatTimestamp, spacing, typography } from '../theme';

/**
 * Channels: the directory, and one channel's feed.
 *
 * A channel is read-only for followers — the composer only appears for the
 * owner and admins. That is the whole difference from a group, so the UI makes
 * it explicit rather than letting a follower type something that will be
 * refused.
 */

function BackHeader({ title, onBack, action, onAction }: { title: string; onBack: () => void; action?: string; onAction?: () => void }) {
  return (
    <View style={styles.header}>
      <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
        <Text style={styles.backText}>‹</Text>
      </Pressable>
      <Text style={styles.headerTitle} numberOfLines={1}>
        {title}
      </Text>
      {action && onAction ? (
        <Pressable onPress={onAction} hitSlop={8}>
          <Text style={styles.headerAction}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function ChannelsScreen({
  onBack,
  onOpenChannel,
  onOpenCreate,
}: {
  onBack: () => void;
  onOpenChannel: (channelId: string) => void;
  onOpenCreate: () => void;
}) {
  const [mine, setMine] = useState<ChannelSummary[]>([]);
  const [directory, setDirectory] = useState<ChannelSummary[]>([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      // Both lists in one go: the screen shows "following" then "discover", and
      // fetching them separately makes the two halves flicker in at different
      // times.
      const term = query.trim();
      const [mineResult, directoryResult] = await Promise.all([
        channelsApi.mine(),
        channelsApi.search(term || undefined, { limit: 50 }),
      ]);
      setMine(mineResult.channels ?? []);
      setDirectory(directoryResult.channels ?? []);
      setError(null);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [query]);

  useEffect(() => {
    const timer = setTimeout(() => void load(), query ? 300 : 0);
    return () => clearTimeout(timer);
  }, [load, query]);

  const followingIds = new Set(mine.map((c) => c.id));
  // What you already follow is shown once, at the top — not repeated in the
  // discovery list below it.
  const discover = directory.filter((c) => !followingIds.has(c.id));

  return (
    <Screen>
      <BackHeader title="Channels" onBack={onBack} action="Create" onAction={onOpenCreate} />

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      <View style={styles.searchWrap}>
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Search channels"
          placeholderTextColor={colors.textFaint}
          style={styles.search}
          autoCapitalize="none"
          autoCorrect={false}
        />
      </View>

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={discover}
          keyExtractor={(item) => item.id}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                setRefreshing(true);
                void load();
              }}
            />
          }
          ListHeaderComponent={
            mine.length > 0 ? (
              <View>
                <Text style={styles.sectionLabel}>Following</Text>
                {mine.map((item) => (
                  <ChannelRow key={item.id} channel={item} onPress={() => onOpenChannel(item.id)} />
                ))}
                <Text style={styles.sectionLabel}>Discover</Text>
              </View>
            ) : null
          }
          renderItem={({ item }) => <ChannelRow channel={item} onPress={() => onOpenChannel(item.id)} />}
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <EmptyState
                title={query ? 'No channels match' : 'No channels yet'}
                subtitle={
                  query
                    ? 'Try a different word, or clear the box to see everything listed.'
                    : 'Channels are one-to-many broadcasts. Tap Create to start the first one.'
                }
              />
            </View>
          }
        />
      )}
    </Screen>
  );
}

function ChannelRow({ channel, onPress }: { channel: ChannelSummary; onPress: () => void }) {
  return (
    <Pressable style={styles.row} onPress={onPress}>
      <Avatar name={channel.name} size={46} />
      <View style={styles.rowBody}>
        <View style={styles.rowTitleLine}>
          <Text style={styles.rowTitle} numberOfLines={1}>
            {channel.name}
          </Text>
          {channel.isVerified ? <Text style={styles.verified}>✓</Text> : null}
        </View>
        <Text style={styles.rowSub} numberOfLines={1}>
          {channel.isFollowing ? 'Following · ' : ''}
          {channel.followerCount} follower{channel.followerCount === 1 ? '' : 's'}
          {channel.postCount > 0 ? ` · ${channel.postCount} update${channel.postCount === 1 ? '' : 's'}` : ''}
        </Text>
      </View>
      {channel.unreadCount && channel.unreadCount > 0 ? (
        <View style={styles.unreadPill}>
          <Text style={styles.unreadText}>{channel.unreadCount}</Text>
        </View>
      ) : null}
    </Pressable>
  );
}

export function CreateChannelScreen({ onBack, onCreated }: { onBack: () => void; onCreated: (channelId: string) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const create = async () => {
    if (name.trim().length < 3) {
      setError('A channel name needs at least 3 characters.');
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const result = await channelsApi.create({
        name: name.trim(),
        ...(description.trim() ? { description: description.trim() } : {}),
        isPublic,
      });
      onCreated(result.channel.id);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <BackHeader title="New channel" onBack={onBack} />
      <ScrollView contentContainerStyle={styles.form}>
        {error ? <ErrorBanner message={error} /> : null}

        <Text style={styles.label}>Name</Text>
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="Channel name"
          placeholderTextColor={colors.textFaint}
          style={styles.input}
          maxLength={80}
        />

        <Text style={styles.label}>Description</Text>
        <TextInput
          value={description}
          onChangeText={setDescription}
          placeholder="What is this channel about?"
          placeholderTextColor={colors.textFaint}
          style={[styles.input, styles.multiline]}
          multiline
          maxLength={500}
        />

        <Pressable style={styles.checkRow} onPress={() => setIsPublic((value) => !value)}>
          <View style={[styles.checkbox, isPublic && styles.checkboxOn]}>
            {isPublic ? <Text style={styles.checkMark}>✓</Text> : null}
          </View>
          <View style={styles.rowBody}>
            <Text style={styles.label}>Listed publicly</Text>
            <Text style={styles.hint}>
              Public channels appear in the directory and anyone can read them. Turn this off for an invite-only channel.
            </Text>
          </View>
        </Pressable>

        <PrimaryButton title={busy ? 'Creating…' : 'Create channel'} onPress={() => void create()} loading={busy} />
        <Text style={styles.hint}>
          You become the owner, and the only person who can post until you add admins.
        </Text>
      </ScrollView>
    </Screen>
  );
}

export function ChannelScreen({ channelId, onBack }: { channelId: string; onBack: () => void }) {
  const [channel, setChannel] = useState<ChannelSummary | null>(null);
  const [posts, setPosts] = useState<ChannelPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [posting, setPosting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [token, setToken] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [detail, feed] = await Promise.all([
        channelsApi.get(channelId),
        channelsApi.posts(channelId, { limit: 50 }),
      ]);
      setChannel(detail.channel);
      setPosts(feed.posts ?? []);
      setError(null);
      // Reading the channel clears its unread marker; the list behind this
      // screen will reflect that when it remounts.
      if (detail.channel.isFollowing) void channelsApi.markRead(channelId).catch(() => {});
    } catch (err) {
      setError(describeError(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [channelId]);

  useEffect(() => {
    void load();
    void currentAccessToken().then(setToken);
  }, [load]);

  const toggleFollow = async () => {
    if (!channel) return;
    try {
      const result = channel.isFollowing
        ? await channelsApi.unfollow(channelId)
        : await channelsApi.follow(channelId);
      setChannel(result.channel);
    } catch (err) {
      setError(describeError(err));
    }
  };

  const isAdmin = channel?.myRole === 'owner' || channel?.myRole === 'admin';

  const send = async () => {
    if (!draft.trim()) return;
    setPosting(true);
    setError(null);
    try {
      await channelsApi.createPost(channelId, { type: 'text', body: draft.trim() });
      setDraft('');
      await load();
    } catch (err) {
      setError(describeError(err));
    } finally {
      setPosting(false);
    }
  };

  const attachImage = async () => {
    setError(null);
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        setError('Photo access is required to post a photo.');
        return;
      }
      const picked = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
      if (picked.canceled || picked.assets.length === 0) return;

      const asset = picked.assets[0]!;
      setUploading(true);
      const uploaded = await media.upload({
        uri: asset.uri,
        fileName: asset.fileName ?? undefined,
        mimeType: asset.mimeType ?? 'image/jpeg',
      });
      await channelsApi.createPost(channelId, {
        type: 'image',
        ...(draft.trim() ? { body: draft.trim() } : {}),
        attachments: [
          {
            kind: 'image',
            mimeType: uploaded.mimeType,
            storageKey: uploaded.storageKey,
            byteSize: uploaded.byteSize,
          },
        ],
      });
      setDraft('');
      await load();
    } catch (err) {
      setError(describeError(err));
    } finally {
      setUploading(false);
    }
  };

  const react = async (postId: string, emoji: string) => {
    try {
      await channelsApi.react(postId, emoji);
      // Refetch rather than patching locally: the endpoint toggles, so the
      // server is the only thing that knows whether it went on or off.
      setPosts(await channelsApi.posts(channelId, { limit: 50 }).then((r) => r.posts ?? []));
    } catch (err) {
      setError(describeError(err));
    }
  };

  const confirmDelete = (postId: string) => {
    Alert.alert('Delete update', 'This removes it for every follower.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          void (async () => {
            try {
              await channelsApi.deletePost(channelId, postId);
              await load();
            } catch (err) {
              setError(describeError(err));
            }
          })();
        },
      },
    ]);
  };

  if (loading) {
    return (
      <Screen>
        <BackHeader title="Channel" onBack={onBack} />
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <BackHeader title={channel?.name ?? 'Channel'} onBack={onBack} />

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              void load();
            }}
          />
        }
        ListHeaderComponent={
          channel ? (
            <View style={styles.channelHeader}>
              <Avatar name={channel.name} size={64} />
              <Text style={styles.channelName}>{channel.name}</Text>
              <Text style={styles.rowSub}>
                @{channel.handle} · {channel.followerCount} follower{channel.followerCount === 1 ? '' : 's'}
                {channel.isVerified ? ' · verified' : ''}
              </Text>
              {channel.description ? <Text style={styles.channelAbout}>{channel.description}</Text> : null}
              <View style={styles.channelActions}>
                <PrimaryButton
                  title={channel.isFollowing ? 'Unfollow' : 'Follow'}
                  onPress={() => void toggleFollow()}
                  variant={channel.isFollowing ? 'secondary' : 'primary'}
                />
              </View>
            </View>
          ) : null
        }
        renderItem={({ item }) => (
          <View style={styles.post}>
            <View style={styles.postTop}>
              <Text style={styles.rowTime}>{formatTimestamp(item.createdAt)}</Text>
              {isAdmin ? (
                <Pressable onPress={() => confirmDelete(item.id)} hitSlop={8}>
                  <Text style={styles.deleteText}>Delete</Text>
                </Pressable>
              ) : null}
            </View>

            {item.body ? <Text style={styles.postBody}>{item.body}</Text> : null}

            {item.attachments.map((attachment) =>
              attachment.kind === 'image' ? (
                <Image
                  key={attachment.id}
                  source={{ uri: statusMediaUrl(attachment.id, token) }}
                  style={styles.postImage}
                  resizeMode="cover"
                />
              ) : null,
            )}

            <View style={styles.reactionRow}>
              {(item.reactions.length > 0 ? item.reactions : []).map((reaction) => (
                <Pressable
                  key={reaction.emoji}
                  style={[styles.reaction, item.myReaction === reaction.emoji && styles.reactionMine]}
                  onPress={() => void react(item.id, reaction.emoji)}
                >
                  <Text style={styles.reactionText}>
                    {reaction.emoji} {reaction.count}
                  </Text>
                </Pressable>
              ))}
              <Pressable style={styles.reaction} onPress={() => void react(item.id, '👍')}>
                <Text style={styles.reactionText}>👍</Text>
              </Pressable>
              <Pressable style={styles.reaction} onPress={() => void react(item.id, '❤️')}>
                <Text style={styles.reactionText}>❤️</Text>
              </Pressable>
            </View>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.emptyWrap}>
            <EmptyState
              title="No updates yet"
              subtitle={
                isAdmin
                  ? 'Post the first update below — followers will see it in Updates.'
                  : 'The owner has not posted yet. Follow to see updates as they arrive.'
              }
            />
          </View>
        }
      />

      {isAdmin ? (
        <View style={styles.composer}>
          <Pressable onPress={() => void attachImage()} disabled={uploading || posting} style={styles.attachButton}>
            <Text style={styles.attachText}>{uploading ? '…' : '📷'}</Text>
          </Pressable>
          <TextInput
            value={draft}
            onChangeText={setDraft}
            placeholder="Post an update"
            placeholderTextColor={colors.textFaint}
            style={styles.composerInput}
            multiline
            maxLength={4000}
          />
          <Pressable onPress={() => void send()} disabled={posting || !draft.trim()} style={styles.sendButton}>
            <Text style={styles.sendText}>{posting ? '…' : 'Send'}</Text>
          </Pressable>
        </View>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { flex: 1, fontSize: 18, fontWeight: '600', color: colors.text },
  headerAction: { color: colors.primary, fontWeight: '600', fontSize: 14 },

  searchWrap: { padding: spacing.lg, paddingBottom: spacing.sm },
  search: {
    height: 44,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 22,
    paddingHorizontal: spacing.lg,
    color: colors.text,
    fontSize: 15,
  },

  sectionLabel: { ...typography.small, fontWeight: '600', paddingHorizontal: spacing.lg, paddingTop: spacing.md, paddingBottom: spacing.xs },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  rowBody: { flex: 1 },
  rowTitleLine: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  rowTitle: { fontSize: 16, fontWeight: '600', color: colors.text },
  rowSub: { ...typography.small, marginTop: 2 },
  rowTime: { ...typography.small, fontSize: 11 },
  verified: { color: colors.primary, fontSize: 13, fontWeight: '700' },
  unreadPill: {
    minWidth: 24,
    height: 22,
    borderRadius: 11,
    paddingHorizontal: 6,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unreadText: { color: '#FFFFFF', fontSize: 12, fontWeight: '700' },

  form: { padding: spacing.lg, gap: spacing.sm },
  label: { ...typography.small, fontWeight: '600', color: colors.text },
  hint: { ...typography.small },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    padding: spacing.md,
    color: colors.text,
    fontSize: 16,
  },
  multiline: { minHeight: 90, textAlignVertical: 'top' },
  checkRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md, paddingVertical: spacing.md },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxOn: { borderColor: colors.primary, backgroundColor: colors.primary },
  checkMark: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },

  channelHeader: { alignItems: 'center', gap: spacing.sm, padding: spacing.lg },
  channelName: { fontSize: 20, fontWeight: '700', color: colors.text },
  channelAbout: { ...typography.small, textAlign: 'center', paddingHorizontal: spacing.lg },
  channelActions: { alignSelf: 'stretch', paddingTop: spacing.sm },

  post: { padding: spacing.lg, borderTopWidth: 1, borderTopColor: colors.border, gap: spacing.sm },
  postTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  postBody: { fontSize: 16, color: colors.text, lineHeight: 22 },
  postImage: { width: '100%', height: 220, borderRadius: 12 },
  deleteText: { color: colors.danger, fontSize: 13, fontWeight: '600' },
  reactionRow: { flexDirection: 'row', gap: spacing.sm, flexWrap: 'wrap' },
  reaction: {
    paddingHorizontal: spacing.md,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: colors.border,
  },
  reactionMine: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  reactionText: { fontSize: 14, color: colors.text },

  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: spacing.sm,
    padding: spacing.sm,
    // Pinned to the bottom of the window, so it has to clear the system
    // navigation bar itself — the same reason and the same constant as the
    // conversation composer. Without it the send button sits under the bar.
    paddingBottom: spacing.sm + bottomSystemBarClearance,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  attachButton: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  attachText: { fontSize: 20 },
  composerInput: {
    flex: 1,
    maxHeight: 120,
    minHeight: 44,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 22,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    color: colors.text,
    fontSize: 15,
    textAlignVertical: 'center',
  },
  sendButton: {
    height: 44,
    paddingHorizontal: spacing.lg,
    borderRadius: 22,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendText: { color: '#FFFFFF', fontWeight: '700', fontSize: 14 },

  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  errorWrap: { paddingHorizontal: spacing.lg },
  emptyWrap: { paddingTop: spacing.lg },
});
