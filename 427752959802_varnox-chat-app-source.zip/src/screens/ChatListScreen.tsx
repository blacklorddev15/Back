import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { chats, type ChatSummary } from '../api/client';
import { TabHeader } from '../components/TabBar';
import { Avatar, EmptyState, ErrorBanner, Screen } from '../components/ui';
import { useRealtime } from '../state/RealtimeContext';
import { colors, displayNameOf, formatTimestamp, spacing, typography } from '../theme';

/**
 * The chat list.
 *
 * Note the field names: rows from this endpoint are raw SQL columns
 * (snake_case), unlike message objects which the API shapes into camelCase.
 * That is why `last_message_preview` and `unread_count` are spelled that way.
 */

const FILTERS = ['all', 'unread', 'direct', 'groups', 'archived'] as const;
type Filter = (typeof FILTERS)[number];

export function ChatListScreen({
  onOpenChat,
  onNewChat,
  onOpenProfile,
  onOpenDrawer,
  onOpenNotifications,
  unreadNotifications = 0,
}: {
  onOpenChat: (chatId: string) => void;
  onNewChat: () => void;
  onOpenProfile: () => void;
  onOpenDrawer: () => void;
  onOpenNotifications: () => void;
  unreadNotifications?: number;
}) {
  // The signed-in identity and Sign out used to live in this screen's header.
  // Both moved into AppDrawer, which the header's three-dot button opens.
  const { connected, subscribe } = useRealtime();

  const [items, setItems] = useState<ChatSummary[]>([]);
  const [filter, setFilter] = useState<Filter>('all');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(
    async (which: Filter, mode: 'initial' | 'refresh' = 'initial') => {
      if (mode === 'initial') setLoading(true);
      else setRefreshing(true);
      setError(null);
      try {
        const result = await chats.list(which);
        setItems(result.chats ?? []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Could not load your chats.');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [],
  );

  useEffect(() => {
    void load(filter);
  }, [filter, load]);

  // Refresh the list when a message arrives anywhere, so previews and unread
  // badges stay current without polling.
  useEffect(() => {
    return subscribe((event) => {
      if (event.type === 'message.new') void load(filter, 'refresh');
    });
  }, [subscribe, load, filter]);

  const renderItem = ({ item }: { item: ChatSummary }) => {
    const name = displayNameOf(item);
    // The API returns counts as numbers, but a driver can hand back a string
    // for bigint columns, so coerce before comparing.
    const unread = Number(item.unread_count ?? 0);

    return (
      <Pressable style={styles.row} onPress={() => onOpenChat(item.id)}>
        <Avatar name={name} />
        <View style={styles.rowBody}>
          <View style={styles.rowTop}>
            <Text style={styles.rowTitle} numberOfLines={1}>
              {name}
            </Text>
            <Text style={styles.rowTime}>{formatTimestamp(item.last_message_at)}</Text>
          </View>
          <View style={styles.rowBottom}>
            <Text style={styles.rowPreview} numberOfLines={1}>
              {item.last_message_preview ?? 'No messages yet'}
            </Text>
            {unread > 0 ? (
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{unread > 99 ? '99+' : unread}</Text>
              </View>
            ) : null}
          </View>
        </View>
      </Pressable>
    );
  };

  return (
    <Screen>
      <TabHeader
        title="Varnox Chat"
        subtitle={connected ? 'live' : 'offline'}
        onOpenDrawer={onOpenDrawer}
        onPressTitle={onOpenProfile}
        onOpenNotifications={onOpenNotifications}
        unreadCount={unreadNotifications}
      />

      <View style={styles.filters}>
        {FILTERS.map((value) => (
          <Pressable
            key={value}
            onPress={() => setFilter(value)}
            style={[styles.chip, filter === value && styles.chipActive]}
          >
            <Text style={[styles.chipText, filter === value && styles.chipTextActive]}>
              {value[0]!.toUpperCase() + value.slice(1)}
            </Text>
          </Pressable>
        ))}
      </View>

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void load(filter, 'refresh')} />}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          ListEmptyComponent={
            <EmptyState
              title="No conversations yet"
              subtitle="Tap + to browse everyone on this deployment and pick someone to message."
            />
          }
          contentContainerStyle={items.length === 0 ? styles.emptyContainer : undefined}
        />
      )}

      {/* WhatsApp's chat list has no buttons along the bottom — starting a chat
          is the floating action button, and creating a group lives in the ⋮
          menu. Both used to be full-width buttons down here, which ate a strip
          off the bottom of the list for something you reach once a session. */}
      <Pressable style={styles.fab} onPress={onNewChat} accessibilityLabel="Start a new chat">
        <Text style={styles.fabIcon}>+</Text>
      </Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },

  filters: { flexDirection: 'row', gap: spacing.sm, paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  chip: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs + 2,
    borderRadius: 999,
    backgroundColor: colors.surface,
  },
  chipActive: { backgroundColor: colors.primary },
  chipText: { fontSize: 13, color: colors.textMuted, fontWeight: '600' },
  chipTextActive: { color: colors.primaryText },

  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: spacing.lg, paddingVertical: spacing.md, gap: spacing.md },
  rowBody: { flex: 1 },
  rowTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  rowTitle: { fontSize: 16, fontWeight: '600', color: colors.text, flex: 1 },
  rowTime: { ...typography.small, marginLeft: spacing.sm },
  rowBottom: { flexDirection: 'row', alignItems: 'center', marginTop: 2 },
  rowPreview: { ...typography.subtitle, flex: 1, fontSize: 14 },
  badge: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    paddingHorizontal: 6,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: spacing.sm,
  },
  badgeText: { color: colors.primaryText, fontSize: 11, fontWeight: '700' },
  separator: { height: 1, backgroundColor: colors.border, marginLeft: 76 },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  errorWrap: { paddingHorizontal: spacing.lg },
  emptyContainer: { flexGrow: 1 },
  // Floats over the list in the bottom-right corner, clear of the last row and
  // sitting just above the tab bar rather than on top of it.
  fab: {
    position: 'absolute',
    right: spacing.lg,
    bottom: spacing.lg,
    width: 56,
    height: 56,
    borderRadius: 18,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 6,
  },
  fabIcon: { color: '#FFFFFF', fontSize: 30, lineHeight: 34, fontWeight: '400' },
});
