import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { chats, users, type ChatDetail, type UserSearchResult } from '../api/client';
import { Avatar, ErrorBanner, Notice, PrimaryButton, Screen } from '../components/ui';
import { describeError, useAuth } from '../state/AuthContext';
import { colors, spacing, typography } from '../theme';

/**
 * Group membership management.
 *
 * The screen only offers what the caller is actually allowed to do — the
 * backend enforces every rule anyway (an admin cannot remove the owner, only
 * the owner can grant admin), but showing buttons that always fail is hostile.
 */
export function GroupMembersScreen({
  chatId,
  onBack,
  onLeft,
}: {
  chatId: string;
  onBack: () => void;
  onLeft: () => void;
}) {
  const { user } = useAuth();
  const [detail, setDetail] = useState<ChatDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [invite, setInvite] = useState<string | null>(null);

  const [adding, setAdding] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<UserSearchResult[]>([]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setDetail(await chats.detail(chatId));
    } catch (err) {
      setError(describeError(err));
    } finally {
      setLoading(false);
    }
  }, [chatId]);

  useEffect(() => {
    void load();
  }, [load]);

  // Debounced search for people to add.
  useEffect(() => {
    const term = query.trim();
    if (!adding || term.length < 3) {
      setResults([]);
      return;
    }
    let cancelled = false;
    const timer = setTimeout(async () => {
      try {
        const found = await users.search(term);
        if (!cancelled) setResults(found.results ?? []);
      } catch (err) {
        if (!cancelled) setError(describeError(err));
      }
    }, 350);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query, adding]);

  const run = async (key: string, action: () => Promise<unknown>, message?: string) => {
    setBusy(key);
    setError(null);
    setNotice(null);
    try {
      await action();
      await load();
      if (message) setNotice(message);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(null);
    }
  };

  const doAdd = (target: UserSearchResult) =>
    run(`add-${target.id}`, () => chats.addMembers(chatId, [target.id]), `${target.display_name ?? target.username ?? 'Member'} added.`);

  const doRemove = (memberId: string, name: string) =>
    Alert.alert(`Remove ${name}?`, 'They will no longer be able to send or read messages here.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => void run(`rm-${memberId}`, () => chats.removeMember(chatId, memberId), 'Member removed.'),
      },
    ]);

  const doBan = (memberId: string, name: string) =>
    Alert.alert(`Ban ${name}?`, 'They are removed and cannot rejoin through an invite link.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Ban',
        style: 'destructive',
        onPress: () =>
          void run(`ban-${memberId}`, () => chats.removeMember(chatId, memberId, { ban: true, reason: 'Removed by an admin' }), 'Member banned.'),
      },
    ]);

  const doLeave = () =>
    Alert.alert('Leave group?', 'You will stop receiving messages from it.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Leave',
        style: 'destructive',
        onPress: () =>
          void run('leave', async () => {
            if (!user) return;
            await chats.leave(chatId, user.id);
            onLeft();
          }),
      },
    ]);

  const createInvite = () =>
    run('invite', async () => {
      const created = await chats.invite(chatId, { expiresInHours: 24 * 7 });
      setInvite(created.url);
    });

  if (loading) {
    return (
      <Screen>
        <Header onBack={onBack} title="Members" />
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      </Screen>
    );
  }

  const myRole = detail?.role ?? 'member';
  const isAdmin = myRole === 'admin' || myRole === 'owner';
  const members = detail?.members ?? [];

  return (
    <Screen>
      <Header onBack={onBack} title={`Members (${members.length})`} />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {error ? <ErrorBanner message={error} /> : null}
        {notice ? <Notice message={notice} tone="success" /> : null}

        {isAdmin ? (
          <View style={styles.block}>
            <PrimaryButton
              title={adding ? 'Done adding' : 'Add members'}
              variant={adding ? 'secondary' : 'primary'}
              onPress={() => {
                setAdding((v) => !v);
                setQuery('');
              }}
            />
            {adding ? (
              <>
                <TextInput
                  value={query}
                  onChangeText={setQuery}
                  placeholder="Search by username, email or phone"
                  placeholderTextColor={colors.textFaint}
                  style={styles.search}
                  autoCapitalize="none"
                />
                {results.map((r) => {
                  const already = members.some((m) => m.user_id === r.id);
                  return (
                    <View key={r.id} style={styles.row}>
                      <Avatar name={r.display_name ?? r.username ?? '?'} size={36} />
                      <View style={styles.flex}>
                        <Text style={styles.rowLabel}>{r.display_name ?? r.username ?? 'Unnamed'}</Text>
                        <Text style={styles.hint}>{r.username ? `@${r.username}` : 'No username'}</Text>
                      </View>
                      <Pressable onPress={() => void doAdd(r)} disabled={already || busy === `add-${r.id}`}>
                        <Text style={already ? styles.hint : styles.actionLink}>{already ? 'already in' : 'Add'}</Text>
                      </Pressable>
                    </View>
                  );
                })}
              </>
            ) : null}
          </View>
        ) : null}

        <View style={styles.block}>
          <Text style={styles.sectionTitle}>Group members</Text>
          {members.map((member) => {
            const name = member.nickname ?? member.display_name ?? member.username ?? 'Member';
            const isMe = member.user_id === user?.id;
            return (
              <View key={member.user_id} style={styles.row}>
                <Avatar name={name} size={36} />
                <View style={styles.flex}>
                  <Text style={styles.rowLabel}>
                    {name}
                    {isMe ? ' (you)' : ''}
                  </Text>
                  <Text style={styles.hint}>
                    {member.role === 'owner' ? 'Owner' : member.role === 'admin' ? 'Admin' : 'Member'}
                    {member.username ? ` · @${member.username}` : ''}
                  </Text>
                </View>

                {/* Admins can act on others; nobody can act on the owner. */}
                {isAdmin && !isMe && member.role !== 'owner' ? (
                  <View style={styles.rowActions}>
                    <Pressable
                      onPress={() =>
                        void run(`role-${member.user_id}`, () =>
                          chats.setRole(chatId, member.user_id, member.role === 'admin' ? 'member' : 'admin'),
                        )
                      }
                      disabled={busy === `role-${member.user_id}`}
                    >
                      <Text style={styles.actionLink}>{member.role === 'admin' ? 'Demote' : 'Make admin'}</Text>
                    </Pressable>
                    <Pressable onPress={() => doRemove(member.user_id, name)} disabled={busy === `rm-${member.user_id}`}>
                      <Text style={styles.dangerLink}>Remove</Text>
                    </Pressable>
                    <Pressable onPress={() => doBan(member.user_id, name)} disabled={busy === `ban-${member.user_id}`}>
                      <Text style={styles.dangerLink}>Ban</Text>
                    </Pressable>
                  </View>
                ) : null}
              </View>
            );
          })}
        </View>

        {isAdmin ? (
          <View style={styles.block}>
            <Text style={styles.sectionTitle}>Invite link</Text>
            <Text style={styles.hint}>
              Anyone with this link can join for 7 days. Share it deliberately — it is a credential.
            </Text>
            <PrimaryButton title="Create invite link" onPress={createInvite} loading={busy === 'invite'} variant="secondary" />
            {invite ? (
              <Text style={styles.inviteCode} selectable>
                {invite}
              </Text>
            ) : null}
          </View>
        ) : null}

        <View style={styles.block}>
          <PrimaryButton title="Leave group" variant="danger" onPress={doLeave} loading={busy === 'leave'} />
        </View>
      </ScrollView>
    </Screen>
  );
}

function Header({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <View style={styles.header}>
      <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
        <Text style={styles.backText}>{'‹'}</Text>
      </Pressable>
      <Text style={styles.headerTitle}>{title}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { fontSize: 18, fontWeight: '600', color: colors.text },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl, gap: spacing.lg },
  block: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    padding: spacing.md,
    gap: spacing.sm,
  },
  sectionTitle: { ...typography.label, textTransform: 'uppercase', letterSpacing: 0.6 },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: spacing.sm },
  rowActions: { flexDirection: 'row', gap: spacing.md },
  rowLabel: { fontSize: 15, fontWeight: '500', color: colors.text },
  hint: { ...typography.small, lineHeight: 16 },
  actionLink: { color: colors.primary, fontWeight: '600', fontSize: 13 },
  dangerLink: { color: colors.danger, fontWeight: '600', fontSize: 13 },
  search: {
    height: 44,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 22,
    paddingHorizontal: spacing.lg,
    fontSize: 15,
    color: colors.text,
  },
  inviteCode: {
    fontFamily: 'monospace',
    fontSize: 13,
    color: colors.text,
    backgroundColor: colors.surface,
    padding: spacing.md,
    borderRadius: 8,
  },
});
