import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, Text, TextInput, View } from 'react-native';
import { chats, users, type DirectoryMember, type UserSearchResult } from '../api/client';
import { Avatar, EmptyState, ErrorBanner, Screen } from '../components/ui';
import { describeError } from '../state/AuthContext';
import { colors, spacing, typography } from '../theme';

/**
 * Find someone and open a conversation.
 *
 * The screen opens straight into the full member directory — no search term
 * required — so you can browse who is on this deployment instead of having to
 * already know a name to type. The list is ordered by signup date, oldest
 * account first, so the people who joined earliest appear at the top.
 *
 * Typing filters that list by display name or username (substring match, done
 * server-side). Typing something that looks like an email address or a phone
 * number additionally runs the exact-match lookup, which is the only way to
 * resolve someone who has hidden their name but is still findable by their
 * contact details.
 *
 * Email and phone numbers themselves are never returned by the directory.
 */

/** A row from either source, normalised so the list can render both together. */
type Person = DirectoryMember | UserSearchResult;

const DIRECTORY_PAGE_SIZE = 50;

/** Looks like an email address or a phone number rather than a name. */
function looksLikeContactDetail(term: string): boolean {
  if (term.includes('@')) return true;
  const digits = term.replace(/[\s\-()+]/g, '');
  return digits.length >= 3 && /^\d+$/.test(digits);
}

/** "Joined Aug 2026" — enough to tell an early member from a brand-new one. */
function joinedLabel(createdAt: string | undefined): string | null {
  if (!createdAt) return null;
  const parsed = new Date(createdAt);
  if (Number.isNaN(parsed.getTime())) return null;
  return `Joined ${parsed.toLocaleDateString(undefined, { month: 'short', year: 'numeric' })}`;
}

function subtitle(person: Person): string {
  const parts: string[] = [];
  parts.push(person.username ? `@${person.username}` : 'No username');
  const joined = 'created_at' in person ? joinedLabel(person.created_at) : null;
  if (joined) parts.push(joined);
  if (person.is_contact) parts.push('in contacts');
  if (person.is_verified) parts.push('verified');
  return parts.join(' · ');
}

export function NewChatScreen({
  onOpenChat,
  onBack,
}: {
  onOpenChat: (chatId: string) => void;
  onBack: () => void;
}) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Person[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [opening, setOpening] = useState<string | null>(null);
  const [reloadToken, setReloadToken] = useState(0);

  const term = query.trim();

  // Load the directory on mount, then re-query when the filter changes.
  // Debounced so a burst of keystrokes issues one request rather than one per
  // character; the first load fires immediately because there is no term yet.
  useEffect(() => {
    let cancelled = false;

    const run = async () => {
      try {
        // Always ask for the directory, filtered by the term. With an empty
        // term this is simply "everyone", which is the point of the screen.
        const [directory, exact] = await Promise.all([
          users.directory(term || undefined, { limit: DIRECTORY_PAGE_SIZE }),
          term.length >= 3 && looksLikeContactDetail(term)
            ? users.search(term).catch(() => ({ results: [] as UserSearchResult[] }))
            : Promise.resolve({ results: [] as UserSearchResult[] }),
        ]);

        if (cancelled) return;

        // Exact matches first, because they were asked for specifically, then
        // the rest of the filtered directory. De-duplicated by id.
        const seen = new Set<string>();
        const merged: Person[] = [];
        for (const person of [...(exact.results ?? []), ...(directory.members ?? [])]) {
          if (seen.has(person.id)) continue;
          seen.add(person.id);
          merged.push(person);
        }

        setResults(merged);
        setTotal(directory.total ?? merged.length);
        setError(null);
      } catch (err) {
        if (!cancelled) setError(describeError(err));
      } finally {
        if (!cancelled) {
          setLoading(false);
          setRefreshing(false);
        }
      }
    };

    const timer = setTimeout(() => void run(), term ? 300 : 0);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [term, reloadToken]);

  const refresh = () => {
    // Bumping a token re-runs the load effect, which keeps pull-to-refresh on
    // exactly the same code path as the initial load — including the merge with
    // exact-match results — instead of a second, subtly different fetch.
    setRefreshing(true);
    setReloadToken((n) => n + 1);
  };

  const open = async (userId: string) => {
    setOpening(userId);
    setError(null);
    try {
      const result = await chats.createDirect(userId);
      onOpenChat(result.chatId);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setOpening(null);
    }
  };

  const countLabel = useMemo(() => {
    if (loading) return null;
    if (term) return `${results.length} of ${total} ${total === 1 ? 'member' : 'members'}`;
    return `${total} ${total === 1 ? 'member' : 'members'} on Varnox Chat`;
  }, [loading, term, results.length, total]);

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>{'‹'}</Text>
        </Pressable>
        <Text style={styles.headerTitle}>New chat</Text>
      </View>

      <View style={styles.searchWrap}>
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Filter by name or username"
          placeholderTextColor={colors.textFaint}
          style={styles.search}
          autoCapitalize="none"
          autoCorrect={false}
          returnKeyType="search"
        />
        {countLabel ? <Text style={styles.count}>{countLabel}</Text> : null}
      </View>

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={(item) => item.id}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} />}
          renderItem={({ item }) => (
            <Pressable style={styles.row} onPress={() => void open(item.id)} disabled={opening === item.id}>
              <Avatar name={item.display_name ?? item.username ?? '?'} />
              <View style={styles.rowBody}>
                <Text style={styles.rowTitle} numberOfLines={1}>
                  {item.display_name ?? item.username ?? 'Unnamed'}
                </Text>
                <Text style={styles.rowSub} numberOfLines={1}>
                  {subtitle(item)}
                </Text>
              </View>
              {opening === item.id ? <ActivityIndicator size="small" /> : null}
            </Pressable>
          )}
          ListEmptyComponent={
            term ? (
              <EmptyState
                title="Nobody found"
                subtitle="Check the spelling, or clear the box to see everyone again."
              />
            ) : (
              <EmptyState
                title="Nobody has joined yet"
                subtitle="You are the first member on this deployment. Anyone who registers will show up here."
              />
            )
          }
          contentContainerStyle={results.length === 0 ? styles.emptyContainer : undefined}
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { fontSize: 18, fontWeight: '600', color: colors.text },
  searchWrap: { padding: spacing.lg, gap: spacing.xs },
  search: {
    height: 46,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 23,
    paddingHorizontal: spacing.lg,
    fontSize: 15,
    color: colors.text,
  },
  count: { ...typography.small, paddingHorizontal: spacing.xs },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  rowBody: { flex: 1 },
  rowTitle: { fontSize: 16, fontWeight: '600', color: colors.text },
  rowSub: { ...typography.small, marginTop: 2 },
  separator: { height: 1, backgroundColor: colors.border, marginLeft: 76 },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  errorWrap: { paddingHorizontal: spacing.lg },
  emptyContainer: { flexGrow: 1 },
});
