import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { auth } from '../api/client';
import { ErrorBanner, Notice, PrimaryButton, Screen, TextField } from '../components/ui';
import { describeError } from '../state/AuthContext';
import { colors, spacing, typography } from '../theme';

/**
 * Password recovery, in two steps because the backend sends a code rather than
 * a magic link:
 *
 *   1. POST /auth/password/forgot  — always reports success, whether or not the
 *      address exists, so it cannot be used to enumerate accounts.
 *   2. POST /auth/password/reset   — code + new password.
 *
 * Resetting also revokes every existing session server-side, which is the
 * correct behaviour: if someone is resetting because they suspect compromise,
 * leaving the attacker's session alive would defeat the point.
 */

export function ForgotPasswordScreen({
  onSent,
  onBack,
}: {
  onSent: (email: string) => void;
  onBack: () => void;
}) {
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError(null);
    if (!email.includes('@')) {
      setError('Enter the email address you signed up with.');
      return;
    }
    setBusy(true);
    try {
      await auth.forgotPassword(email.trim());
      onSent(email.trim());
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.form} keyboardShouldPersistTaps="handled">
          <Text style={styles.heading}>Forgot password</Text>
          <Text style={styles.subheading}>
            We will email you a 6-digit code to reset it.
          </Text>
          <ErrorBanner message={error} />
          <TextField
            label="Email"
            value={email}
            onChangeText={setEmail}
            placeholder="you@example.com"
            keyboardType="email-address"
            textContentType="emailAddress"
          />
          <PrimaryButton title="Send reset code" onPress={submit} loading={busy} />
          <Pressable onPress={onBack} style={styles.linkRow}>
            <Text style={styles.link}>Back to sign in</Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

export function ResetPasswordScreen({
  email,
  onDone,
  onBack,
}: {
  email: string;
  onDone: () => void;
  onBack: () => void;
}) {
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [resending, setResending] = useState(false);

  const submit = async () => {
    setError(null);
    setNotice(null);
    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    if (password !== confirm) {
      setError('The two passwords do not match.');
      return;
    }
    setBusy(true);
    try {
      await auth.resetPassword({ email, code: code.trim(), newPassword: password });
      onDone();
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(false);
    }
  };

  const resend = async () => {
    setError(null);
    setNotice(null);
    setResending(true);
    try {
      await auth.forgotPassword(email);
      setNotice('A new code is on its way.');
    } catch (err) {
      // The server rate-limits this and its message says exactly how long to
      // wait, so show it verbatim.
      setError(describeError(err));
    } finally {
      setResending(false);
    }
  };

  return (
    <Screen>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.form} keyboardShouldPersistTaps="handled">
          <Text style={styles.heading}>Reset password</Text>
          <Text style={styles.subheading}>Enter the code sent to {email} and choose a new password.</Text>
          {notice ? <Notice message={notice} tone="success" /> : null}
          <ErrorBanner message={error} />
          <TextField
            label="Reset code"
            value={code}
            onChangeText={(text) => setCode(text.replace(/[^0-9]/g, ''))}
            placeholder="000000"
            keyboardType="number-pad"
            maxLength={6}
          />
          <TextField
            label="New password"
            value={password}
            onChangeText={setPassword}
            placeholder="At least 8 characters"
            secureTextEntry
          />
          <TextField
            label="Confirm new password"
            value={confirm}
            onChangeText={setConfirm}
            placeholder="Repeat your password"
            secureTextEntry
          />
          <PrimaryButton title="Reset password" onPress={submit} loading={busy} disabled={code.length !== 6} />
          <PrimaryButton title="Resend code" onPress={resend} loading={resending} variant="secondary" />
          <Pressable onPress={onBack} style={styles.linkRow}>
            <Text style={styles.link}>Back</Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  form: { padding: spacing.xl, paddingBottom: spacing.xxl },
  heading: { ...typography.title, marginBottom: spacing.sm },
  subheading: { ...typography.subtitle, marginBottom: spacing.xl, lineHeight: 21 },
  linkRow: { marginTop: spacing.lg, alignItems: 'center' },
  link: { color: colors.primary, fontSize: 15, fontWeight: '600' },
});
