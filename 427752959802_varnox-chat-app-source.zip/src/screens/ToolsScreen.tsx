import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { TabHeader } from '../components/TabBar';
import { Screen } from '../components/ui';
import { useAuth } from '../state/AuthContext';
import { colors, spacing, typography } from '../theme';

/**
 * The Tools tab.
 *
 * Unlike Calls and Updates this one is not a placeholder — it is the shortcuts
 * hub, pointing at screens that genuinely work. WhatsApp's Tools tab is the
 * same idea: the settings and identity entry points, kept out of the chat list.
 *
 * The App update card deliberately lives in Profile rather than here, because
 * that is where it was wanted while changes are being verified; this tab links
 * to it rather than duplicating it.
 */
export function ToolsScreen({
  onOpenDrawer,
  onOpenProfile,
  onOpenServerSettings,
}: {
  onOpenDrawer: () => void;
  onOpenProfile: () => void;
  onOpenServerSettings: () => void;
}) {
  const { user, signOut } = useAuth();

  return (
    <Screen>
      <TabHeader title="Tools" subtitle={user?.email ?? 'Settings and shortcuts'} onOpenDrawer={onOpenDrawer} />
      <View style={styles.list}>
        <Row icon="👤" title="Profile" subtitle="Name, photo, privacy, two-step PIN, devices" onPress={onOpenProfile} />
        <Row
          icon="🖥️"
          title="Server settings"
          subtitle="The address this app connects to"
          onPress={onOpenServerSettings}
        />
        <Pressable style={styles.row} onPress={() => void signOut()}>
          <Text style={styles.rowIcon}>🚪</Text>
          <View style={styles.rowBody}>
            <Text style={[styles.rowTitle, styles.danger]}>Sign out</Text>
            <Text style={styles.rowSub}>You will need your password to get back in</Text>
          </View>
        </Pressable>
      </View>
    </Screen>
  );
}

function Row({ icon, title, subtitle, onPress }: { icon: string; title: string; subtitle: string; onPress: () => void }) {
  return (
    <Pressable style={styles.row} onPress={onPress}>
      <Text style={styles.rowIcon}>{icon}</Text>
      <View style={styles.rowBody}>
        <Text style={styles.rowTitle}>{title}</Text>
        <Text style={styles.rowSub} numberOfLines={2}>
          {subtitle}
        </Text>
      </View>
      <Text style={styles.chevron}>›</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  list: { paddingTop: spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, paddingHorizontal: spacing.lg, paddingVertical: spacing.lg },
  rowIcon: { fontSize: 20, width: 30, textAlign: 'center' },
  rowBody: { flex: 1 },
  rowTitle: { fontSize: 17, fontWeight: '600', color: colors.text },
  rowSub: { ...typography.small, marginTop: 2 },
  danger: { color: colors.danger },
  chevron: { fontSize: 24, color: colors.textFaint },
});
