import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { contacts } from '../api/client';
import { Avatar, EmptyState, ErrorBanner, Screen } from '../components/ui';
import { describeError } from '../state/AuthContext';
import { colors, spacing, typography } from '../theme';

/**
 * Blocked contacts.
 *
 * This screen exists because blocking used to be a one-way door: the
 * conversation action sheet offered "Block", and once blocked there was no
 * route back to it anywhere in the app. Unblocking is a mis-tap away from being
 * needed, so the list is the recovery path — and the sheet itself now offers
 * Unblock when someone is already blocked.
 */

type BlockedEntry = {
  id: string;
  blocked_id: string;
  reason: string | null;
  username: string | null;
  display_name: string | null;
};

export function BlockedContactsScreen({ onBack }: { onBack: () => void }) {
  const [blocked, setBlocked] = useState<BlockedEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const result = await contacts.listBlocked();
      setBlocked(result.blocked ?? []);
      setError(null);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const unblock = (entry: BlockedEntry) => {
    const name = entry.display_name ?? entry.username ?? 'this person';
    Alert.alert('Unblock', `Allow ${name} to message and call you again?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Unblock',
        onPress: () => {
          void (async () => {
            setBusy(entry.blocked_id);
            try {
              await contacts.unblock(entry.blocked_id);
              // Removed locally as well as refetched: the row disappearing is
              // the confirmation, and a refetch alone would flash.
              setBlocked((current) => current.filter((item) => item.blocked_id !== entry.blocked_id));
            } catch (err) {
              setError(describeError(err));
            } finally {
              setBusy(null);
            }
          })();
        },
      },
    ]);
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>‹</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Blocked contacts</Text>
      </View>

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={blocked}
          keyExtractor={(item) => item.blocked_id}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                setRefreshing(true);
                void load();
              }}
            />
          }
          renderItem={({ item }) => (
            <View style={styles.row}>
              <Avatar name={item.display_name ?? item.username ?? '?'} size={44} />
              <View style={styles.rowBody}>
                <Text style={styles.rowTitle} numberOfLines={1}>
                  {item.display_name ?? item.username ?? 'Unnamed'}
                </Text>
                <Text style={styles.rowSub} numberOfLines={1}>
                  {item.reason ? `Blocked · ${item.reason}` : 'Blocked'}
                </Text>
              </View>
              <Pressable onPress={() => unblock(item)} disabled={busy === item.blocked_id} hitSlop={8}>
                <Text style={styles.unblock}>{busy === item.blocked_id ? '…' : 'Unblock'}</Text>
              </Pressable>
            </View>
          )}
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <EmptyState
                title="Nobody is blocked"
                subtitle="People you block appear here, and you can let them back in from this screen."
              />
            </View>
          }
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { flex: 1, fontSize: 18, fontWeight: '600', color: colors.text },

  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  rowBody: { flex: 1 },
  rowTitle: { fontSize: 16, fontWeight: '600', color: colors.text },
  rowSub: { ...typography.small, marginTop: 2 },
  unblock: { color: colors.primary, fontWeight: '600', fontSize: 14 },

  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  errorWrap: { paddingHorizontal: spacing.lg },
  emptyWrap: { paddingTop: spacing.xl },
});
