import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import {
  ActivityIndicator,
  Alert,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import {
  currentAccessToken,
  media,
  status as statusApi,
  statusMediaUrl,
  type StatusGroup,
  type StatusItem,
  type StatusVisibility,
  type UploadedAttachment,
} from '../api/client';
import { Avatar, ErrorBanner, PrimaryButton, Screen } from '../components/ui';
import { describeError, useAuth } from '../state/AuthContext';
import { bottomSystemBarClearance, colors, formatTimestamp, spacing, typography } from '../theme';

/**
 * Status: the composer and the full-screen viewer.
 *
 * Text statuses only, for now. A photo status would need an authenticated route
 * to stream the media — `status_attachments` rows are not chat attachments, so
 * the existing `/attachments/:id` route cannot serve them, and `publicUrl`
 * points at the media host which is not reachable from the phone in this
 * deployment. That route is the next piece of work; until it exists, offering a
 * photo button would produce a status nobody could see.
 */

/** Backgrounds for a text status. WhatsApp's are similar muted solids. */
const BACKGROUNDS = ['#0B1220', '#1F3A5F', '#5B2333', '#1E4536', '#4A2C6B', '#7A4B1E'];

const QUICK_REACTIONS = ['❤️', '😂', '😮', '😢', '🙏', '🔥'];

const VISIBILITY_LABEL: Record<StatusVisibility, string> = {
  everyone: 'Everyone',
  contacts: 'My contacts',
  contacts_except: 'My contacts except…',
  nobody: 'Nobody',
};

export function StatusComposerScreen({ onBack, onPosted }: { onBack: () => void; onPosted: () => void }) {
  const [body, setBody] = useState('');
  const [background, setBackground] = useState(BACKGROUNDS[0]!);
  const [visibility, setVisibility] = useState<StatusVisibility>('contacts');
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [photo, setPhoto] = useState<{ uploaded: UploadedAttachment; previewUri: string } | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    void (async () => {
      try {
        const data = await statusApi.all();
        setVisibility(data.visibility);
      } catch {
        // Not fatal: the audience line is informational here, and the composer
        // should still work if the pre-flight fails.
      }
    })();
  }, []);

  const pickPhoto = async () => {
    setError(null);
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        setError('Photo access is required to add a photo.');
        return;
      }

      const picked = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        // Same reasoning as chat attachments: a phone photo at full size is
        // several megabytes and this is the user's mobile data.
        quality: 0.7,
      });
      if (picked.canceled || picked.assets.length === 0) return;

      const asset = picked.assets[0]!;
      setUploading(true);
      const uploaded = await media.upload({
        uri: asset.uri,
        fileName: asset.fileName ?? undefined,
        mimeType: asset.mimeType ?? 'image/jpeg',
      });
      setPhoto({ uploaded, previewUri: asset.uri });
    } catch (err) {
      setError(describeError(err));
    } finally {
      setUploading(false);
    }
  };

  const post = async () => {
    setError(null);

    // A photo status may carry a caption, but a text status needs words —
    // otherwise the server (rightly) rejects it.
    if (!photo && !body.trim()) {
      setError('Type something to post, or add a photo.');
      return;
    }

    setPosting(true);
    try {
      if (photo) {
        await statusApi.create({
          type: 'image',
          ...(body.trim() ? { caption: body.trim() } : {}),
          attachments: [
            {
              kind: 'image',
              mimeType: photo.uploaded.mimeType,
              storageKey: photo.uploaded.storageKey,
              ...(photo.uploaded.publicUrl ? { publicUrl: photo.uploaded.publicUrl } : {}),
              byteSize: photo.uploaded.byteSize,
            },
          ],
        });
      } else {
        await statusApi.create({ type: 'text', body: body.trim(), backgroundColor: background });
      }
      onPosted();
    } catch (err) {
      setError(describeError(err));
    } finally {
      setPosting(false);
    }
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>‹</Text>
        </Pressable>
        <Text style={styles.headerTitle}>New status</Text>
      </View>

      <ScrollView contentContainerStyle={styles.composerBody}>
        {error ? <ErrorBanner message={error} /> : null}

        {/* The preview is the point of a status: what you see here is what
            everyone else sees. A photo takes over the preview, with the caption
            over it. */}
        {photo ? (
          <View style={styles.photoPreview}>
            <Image source={{ uri: photo.previewUri }} style={styles.photoImage} resizeMode="cover" />
            {body.trim() ? <Text style={styles.photoCaption}>{body.trim()}</Text> : null}
            <Pressable style={styles.removePhoto} onPress={() => setPhoto(null)} hitSlop={8}>
              <Text style={styles.removePhotoText}>✕</Text>
            </Pressable>
          </View>
        ) : (
          <View style={[styles.preview, { backgroundColor: background }]}>
            <Text style={styles.previewText}>{body.trim() ? body : 'Type your status…'}</Text>
          </View>
        )}

        <View style={styles.composerActions}>
          <Pressable style={styles.photoButton} onPress={() => void pickPhoto()} disabled={uploading || posting}>
            <Text style={styles.photoButtonText}>{uploading ? 'Uploading…' : '📷  Add photo'}</Text>
          </Pressable>
        </View>

        <TextInput
          value={body}
          onChangeText={setBody}
          placeholder={photo ? 'Add a caption…' : 'Type your status…'}
          placeholderTextColor={colors.textFaint}
          style={styles.input}
          multiline
          maxLength={700}
        />

        {photo ? null : (
          <>
            <Text style={styles.label}>Background</Text>
            <View style={styles.swatches}>
              {BACKGROUNDS.map((colour) => (
                <Pressable
                  key={colour}
                  onPress={() => setBackground(colour)}
                  style={[styles.swatch, { backgroundColor: colour }, background === colour && styles.swatchActive]}
                  accessibilityLabel={`Background ${colour}`}
                />
              ))}
            </View>
          </>
        )}

        <Text style={styles.label}>Visible to: {VISIBILITY_LABEL[visibility]}</Text>
        <Text style={styles.hint}>
          Change this under Status privacy on the Updates tab. It is a profile setting, not a per-status one.
        </Text>

        <PrimaryButton title={posting ? 'Posting…' : 'Post status'} onPress={() => void post()} loading={posting} />
        <Text style={styles.hint}>Disappears automatically after 24 hours.</Text>
      </ScrollView>
    </Screen>
  );
}

export function StatusViewerScreen({ authorUserId, onBack }: { authorUserId: string; onBack: () => void }) {
  const { user } = useAuth();
  const [statuses, setStatuses] = useState<StatusItem[]>([]);
  const [authorName, setAuthorName] = useState('Status');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [index, setIndex] = useState(0);
  const [reaction, setReaction] = useState<string | null>(null);

  const isMine = authorUserId === user?.id;
  const advanceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Needed to build authenticated media URLs; the ID is not guessable but the
  // request still has to carry a token.
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    void currentAccessToken().then(setToken);
  }, []);

  const load = useCallback(async () => {
    try {
      const data = await statusApi.all();
      if (isMine) {
        setStatuses(data.mine ?? []);
        setAuthorName('My status');
      } else {
        const group: StatusGroup | undefined = (data.feed ?? []).find((entry) => entry.user.id === authorUserId);
        setStatuses(group?.statuses ?? []);
        setAuthorName(group?.user.displayName ?? group?.user.username ?? 'Status');
      }
      setIndex(0);
      setError(null);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setLoading(false);
    }
  }, [authorUserId, isMine]);

  useEffect(() => {
    void load();
  }, [load]);

  const current = statuses[index];

  // Marking viewed is what turns the ring from coloured to grey for everyone
  // else, so it happens as each status is shown rather than when the viewer
  // closes.
  useEffect(() => {
    if (!current || isMine) return;
    void statusApi.view(current.id).catch(() => {});
  }, [current, isMine]);

  useEffect(() => {
    if (advanceRef.current) clearTimeout(advanceRef.current);
    if (!current) return;
    advanceRef.current = setTimeout(() => {
      setIndex((value) => (value + 1 < statuses.length ? value + 1 : value));
      setReaction(null);
    }, 5000);
    return () => {
      if (advanceRef.current) clearTimeout(advanceRef.current);
    };
  }, [current, statuses.length]);

  const goNext = () => {
    if (index + 1 < statuses.length) {
      setIndex(index + 1);
      setReaction(null);
    } else {
      onBack();
    }
  };

  const goPrevious = () => {
    if (index > 0) {
      setIndex(index - 1);
      setReaction(null);
    }
  };

  const react = async (emoji: string) => {
    if (!current) return;
    setReaction(emoji);
    try {
      await statusApi.react(current.id, emoji);
    } catch (err) {
      setError(describeError(err));
    }
  };

  const confirmDelete = () => {
    if (!current) return;
    Alert.alert('Delete status', 'This removes it for everyone, immediately.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          void (async () => {
            try {
              await statusApi.remove(current.id);
              onBack();
            } catch (err) {
              setError(describeError(err));
            }
          })();
        },
      },
    ]);
  };

  const background = useMemo(() => current?.backgroundColor ?? colors.bubbleIncoming, [current]);
  const photoAttachment = useMemo(
    () => current?.attachments.find((item) => item.kind === 'image' || item.kind === 'gif'),
    [current],
  );

  if (loading) {
    return (
      <Screen style={styles.viewerScreen}>
        <ActivityIndicator />
      </Screen>
    );
  }

  if (!current) {
    return (
      <Screen style={styles.viewerScreen}>
        <View style={styles.viewerHeader}>
          <Pressable onPress={onBack} hitSlop={10}>
            <Text style={styles.viewerClose}>✕</Text>
          </Pressable>
          <Text style={styles.viewerName}>{authorName}</Text>
        </View>
        <View style={styles.viewerEmpty}>
          <Text style={styles.viewerEmptyTitle}>Nothing to show</Text>
          <Text style={styles.hint}>This status is gone — it expired, was deleted, or you can no longer see it.</Text>
        </View>
      </Screen>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: background }}>
      {/* Segmented progress, one bar per status in the run. */}
      <View style={styles.progressRow}>
        {statuses.map((item, position) => (
          <View key={item.id} style={[styles.progressTrack, position <= index && styles.progressFilled]} />
        ))}
      </View>

      <View style={styles.viewerHeader}>
        <Avatar name={authorName} size={34} />
        <View style={styles.viewerHeaderText}>
          <Text style={styles.viewerName} numberOfLines={1}>
            {authorName}
          </Text>
          <Text style={styles.viewerTime}>{formatTimestamp(current.createdAt)}</Text>
        </View>
        <Pressable onPress={onBack} hitSlop={10}>
          <Text style={styles.viewerClose}>✕</Text>
        </Pressable>
      </View>

      {error ? <ErrorBanner message={error} /> : null}

      {/* Tap zones: the left third steps back, the rest steps forward — the same
          convention every stories viewer uses. */}
      <View style={styles.viewerStage}>
        <Pressable style={styles.tapLeft} onPress={goPrevious} />
        <Pressable style={styles.tapRight} onPress={goNext} />

        {photoAttachment ? (
          // Served from the authenticated status-media route, so the audience
          // rules apply to the bytes as well as to the metadata.
          <Image
            source={{ uri: statusMediaUrl(photoAttachment.id, token) }}
            style={styles.viewerImage}
            resizeMode="contain"
          />
        ) : (
          <Text style={styles.viewerText}>{current.body}</Text>
        )}

        {current.caption ? (
          <Text style={[styles.viewerCaption, photoAttachment ? styles.viewerCaptionOver : null]}>
            {current.caption}
          </Text>
        ) : null}
      </View>

      <View style={styles.viewerFooter}>
        {isMine ? (
          <>
            <Text style={styles.viewerMeta}>
              {current.viewCount ?? 0} view{(current.viewCount ?? 0) === 1 ? '' : 's'}
            </Text>
            <Pressable onPress={confirmDelete} hitSlop={8}>
              <Text style={styles.deleteText}>Delete</Text>
            </Pressable>
          </>
        ) : (
          <View style={styles.reactionRow}>
            {QUICK_REACTIONS.map((emoji) => (
              <Pressable
                key={emoji}
                onPress={() => void react(emoji)}
                style={[styles.reaction, reaction === emoji && styles.reactionActive]}
              >
                <Text style={styles.reactionText}>{emoji}</Text>
              </Pressable>
            ))}
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { fontSize: 18, fontWeight: '600', color: colors.text },

  // The ScrollView runs to the bottom of the window, so the Post button would
  // otherwise finish underneath the system navigation bar.
  composerBody: { padding: spacing.lg, paddingBottom: spacing.lg + bottomSystemBarClearance, gap: spacing.md },
  preview: {
    minHeight: 180,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  previewText: { color: '#FFFFFF', fontSize: 24, fontWeight: '600', textAlign: 'center' },
  input: {
    minHeight: 80,
    maxHeight: 160,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    padding: spacing.md,
    color: colors.text,
    fontSize: 16,
    textAlignVertical: 'top',
  },
  label: { ...typography.small, fontWeight: '600', color: colors.text },
  hint: { ...typography.small },
  swatches: { flexDirection: 'row', gap: spacing.md, flexWrap: 'wrap' },
  swatch: { width: 40, height: 40, borderRadius: 20, borderWidth: 2, borderColor: colors.border },
  swatchActive: { borderColor: colors.primary },

  viewerScreen: { padding: spacing.lg },
  progressRow: { flexDirection: 'row', gap: 4, padding: spacing.md },
  progressTrack: { flex: 1, height: 3, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.25)' },
  progressFilled: { backgroundColor: '#FFFFFF' },
  viewerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
  },
  viewerHeaderText: { flex: 1 },
  viewerName: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  viewerTime: { color: 'rgba(255,255,255,0.7)', fontSize: 12 },
  viewerClose: { color: '#FFFFFF', fontSize: 22 },
  composerActions: { flexDirection: 'row', gap: spacing.md },
  photoButton: {
    flex: 1,
    paddingVertical: spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
  },
  photoButtonText: { color: colors.text, fontSize: 15, fontWeight: '600' },
  photoPreview: { borderRadius: 16, overflow: 'hidden', backgroundColor: colors.surface },
  photoImage: { width: '100%', height: 320 },
  photoCaption: { color: colors.text, padding: spacing.md, fontSize: 15 },
  removePhoto: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  removePhotoText: { color: '#FFFFFF', fontSize: 16 },

  viewerStage: { flex: 1, justifyContent: 'center', paddingHorizontal: spacing.xl },
  viewerImage: { width: '100%', height: '100%' },
  viewerCaption: { color: 'rgba(255,255,255,0.85)', fontSize: 15, textAlign: 'center', marginTop: spacing.md },
  viewerCaptionOver: { textAlign: 'center' },
  tapLeft: { position: 'absolute', left: 0, top: 0, bottom: 0, width: '35%' },
  tapRight: { position: 'absolute', right: 0, top: 0, bottom: 0, width: '65%' },
  viewerText: { color: '#FFFFFF', fontSize: 26, fontWeight: '600', textAlign: 'center' },
  viewerFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.lg,
    // The reaction row and the Delete control sit at the bottom of a
    // full-screen view, so they need the navigation-bar clearance too.
    paddingBottom: spacing.lg + bottomSystemBarClearance,
  },
  viewerMeta: { color: 'rgba(255,255,255,0.85)', fontSize: 14 },
  deleteText: { color: '#FF8A8A', fontSize: 15, fontWeight: '600' },
  reactionRow: { flexDirection: 'row', gap: spacing.sm, flex: 1, justifyContent: 'center' },
  reaction: { paddingHorizontal: spacing.sm, paddingVertical: 6, borderRadius: 999, backgroundColor: 'rgba(0,0,0,0.25)' },
  reactionActive: { backgroundColor: 'rgba(255,255,255,0.25)' },
  reactionText: { fontSize: 20 },

  viewerEmpty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.sm, padding: spacing.xl },
  viewerEmptyTitle: { color: '#FFFFFF', fontSize: 18, fontWeight: '600' },
});
