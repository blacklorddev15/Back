import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import {
  ApiError,
  attachmentUrl,
  chats,
  contacts,
  currentAccessToken,
  media,
  messages as messagesApi,
  type ChatDetail,
  type Message,
} from '../api/client';
import { Avatar, ErrorBanner, Screen } from '../components/ui';
import { describeError, useAuth } from '../state/AuthContext';
import { useRealtime } from '../state/RealtimeContext';
import {
  bottomSystemBarClearance,
  colors,
  displayNameOf,
  formatClockTime,
  formatTimestamp,
  spacing,
  typography,
} from '../theme';

/**
 * One conversation.
 *
 * Three things worth knowing about how this is built:
 *
 * 1. Sending is optimistic. The message appears immediately with a `sending`
 *    status and is reconciled with the server's row on success, or marked
 *    `failed` with a tap-to-retry. A chat that waits for a round trip before
 *    showing your own text feels broken on a slow connection.
 *
 * 2. Ticks come from realtime events only. The history endpoint returns
 *    messages without per-message receipt state, so a freshly loaded screen
 *    cannot know which of your messages were read. It learns from
 *    `receipt.update` frames as they arrive.
 *
 * 3. `clientId` is sent with every message so a retry after a timeout cannot
 *    create a duplicate. The server keys on it and returns the existing row.
 */

type LocalMessage = Message & {
  localStatus?: 'sending' | 'failed';
  localId?: string;
};

// Space reserved below the composer for the system navigation bar. Now shared
// with the tab bar via theme.ts so the two cannot drift apart.
const BOTTOM_SYSTEM_BAR_CLEARANCE = bottomSystemBarClearance;

export function ConversationScreen({
  chatId,
  onBack,
  onOpenMembers,
}: {
  chatId: string;
  onBack: () => void;
  onOpenMembers: () => void;
}) {
  const { user } = useAuth();
  const { subscribe, send: sendFrame, presence } = useRealtime();

  const [detail, setDetail] = useState<ChatDetail | null>(null);
  const [items, setItems] = useState<LocalMessage[]>([]);
  const [draft, setDraft] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [peerTyping, setPeerTyping] = useState(false);
  const [uploading, setUploading] = useState(false);
  // Needed to build authenticated attachment URLs for <Image> sources.
  const [token, setToken] = useState<string | null>(null);

  // Watermarks for the other participant, learned from realtime receipts.
  const [peerDelivered, setPeerDelivered] = useState(0);
  const [peerRead, setPeerRead] = useState(0);

  const typingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastTypingSent = useRef(0);

  const peer = useMemo(() => {
    if (!detail) return null;
    return detail.members.find((member) => member.user_id !== user?.id) ?? detail.members[0] ?? null;
  }, [detail, user?.id]);

  // The peer comes first: in a one-to-one chat the person you are talking to is
  // the title. displayNameOf falls back to the literal 'Unknown', which is
  // always truthy, so calling it first made every unnamed direct chat read
  // "Unknown" even when the member row carried a real display name.
  const title = peer
    ? peer.display_name || peer.username || 'Conversation'
    : detail
      ? displayNameOf(detail.chat as never)
      : 'Conversation';

  // --- initial load -------------------------------------------------------
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const [info, history] = await Promise.all([chats.detail(chatId), messagesApi.list(chatId, { limit: 50 })]);
        if (cancelled) return;
        setDetail(info);
        setItems(history.messages ?? []);

        // Seed the peer's watermarks from the member list so ticks are correct
        // for history. Without this the screen can only show single ticks until
        // the first realtime receipt arrives, which looks like a bug.
        const other = info.members.find((member) => member.user_id !== user?.id);
        if (other) {
          setPeerDelivered(Number(other.last_delivered_seq ?? 0));
          setPeerRead(Number(other.last_read_seq ?? 0));
        }

        // Tell the server we have read up to the newest message.
        const newest = history.messages?.[0]?.seq;
        if (newest) {
          await messagesApi.markRead(chatId, newest).catch(() => {});
          sendFrame({ type: 'read', chatId, upToSeq: newest });
        }
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Could not open this conversation.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // user?.id participates because the watermark seed above compares against it.
  }, [chatId, sendFrame, user?.id]);

  useEffect(() => {
    void currentAccessToken().then(setToken);
  }, []);

  // --- attachments --------------------------------------------------------
  const pickAndSendImage = useCallback(async () => {
    setError(null);
    try {
      // The library needs no permission on modern Android, but iOS does, and
      // asking here means the user sees our explanation before the system
      // dialog rather than after.
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        setError('Photo access is required to send an image.');
        return;
      }

      const picked = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        // 0.7 keeps a phone photo around a few hundred KB instead of several
        // megabytes, which matters because the server caps uploads at 50 MB and
        // mobile data is the user's.
        quality: 0.7,
      });
      if (picked.canceled || picked.assets.length === 0) return;

      const asset = picked.assets[0]!;
      setUploading(true);

      const uploaded = await media.upload({
        uri: asset.uri,
        fileName: asset.fileName ?? undefined,
        mimeType: asset.mimeType ?? 'image/jpeg',
      });

      const clientId = `${user?.id ?? 'anon'}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const result = await messagesApi.sendAttachment(chatId, uploaded, undefined, clientId);

      // Append the server's message directly rather than optimistically: an
      // optimistic bubble could not render (it has no attachment id yet), so a
      // spinner is more honest than a broken image.
      setItems((current) => [result.message, ...current]);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setUploading(false);
    }
  }, [chatId, user?.id]);

  /**
   * Documents. The MIME allowlist mirrors the server's; offering a type the
   * backend rejects would produce a confusing upload error after the user has
   * already picked the file.
   */
  const pickAndSendDocument = useCallback(async () => {
    setError(null);
    try {
      const picked = await DocumentPicker.getDocumentAsync({
        type: [
          'application/pdf',
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'application/vnd.ms-excel',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          'application/vnd.ms-powerpoint',
          'application/vnd.openxmlformats-officedocument.presentationml.presentation',
          'application/zip',
          'text/plain',
          'text/csv',
          'application/json',
        ],
        // Without this the picker returns a content:// handle that the uploader
        // cannot always read; copying into the cache makes the URI dependable.
        copyToCacheDirectory: true,
      });
      if (picked.canceled || picked.assets.length === 0) return;

      const asset = picked.assets[0]!;
      setUploading(true);

      const uploaded = await media.upload({
        uri: asset.uri,
        fileName: asset.name ?? undefined,
        mimeType: asset.mimeType ?? 'application/octet-stream',
      });

      const clientId = `${user?.id ?? 'anon'}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const result = await messagesApi.sendAttachment(chatId, uploaded, undefined, clientId);
      setItems((current) => [result.message, ...current]);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setUploading(false);
    }
  }, [chatId, user?.id]);

  // Presence is only known once a peer's state changes, so an online user who
  // was already online when we connected falls back to last-seen.
  const peerPresence = peer ? presence[peer.user_id] : undefined;
  const peerIsOnline = peerPresence?.online ?? false;

  const openActions = useCallback(() => {
    const isGroup = detail ? detail.chat.type !== 'direct' : false;

    /**
     * Builds the sheet once we know whether this person is already blocked.
     *
     * That has to be asked of the server rather than tracked locally: a block
     * can be placed from another device or from this same sheet on an earlier
     * day, and offering "Block" to someone already blocked is a dead end — the
     * sheet used to do exactly that, with no way back.
     */
    const build = (blocked: boolean) => {
      const buttons: { text: string; style?: 'cancel' | 'destructive'; onPress?: () => void }[] = [];

      if (isGroup) {
        buttons.push({ text: 'Members', onPress: onOpenMembers });
      } else if (peer) {
        buttons.push({
          text: blocked ? 'Unblock user' : 'Block user',
          style: blocked ? undefined : 'destructive',
          onPress: () => {
            const action = blocked ? contacts.unblock(peer.user_id) : contacts.block(peer.user_id);
            void action
              .then(() =>
                Alert.alert(
                  blocked ? 'Unblocked' : 'Blocked',
                  blocked ? 'They can message you again.' : 'They can no longer message or call you.',
                ),
              )
              .catch((err) => setError(describeError(err)));
          },
        });
      }

      buttons.push({
        text: 'Report',
        onPress: () => {
          // Reports are filed with a reason the moderation queue understands;
          // "spam" is the honest default and the details field carries context.
          void contacts
            .report({
              targetType: isGroup ? 'group' : 'user',
              targetId: isGroup ? chatId : peer?.user_id ?? chatId,
              reason: 'spam',
              details: 'Reported from the conversation screen',
            })
            .then(() => Alert.alert('Report sent', 'Thanks — our moderation team will review it.'))
            .catch((err) => setError(describeError(err)));
        },
      });

      buttons.push({ text: 'Cancel', style: 'cancel' });
      Alert.alert(title, 'Choose an action', buttons);
    };

    if (isGroup || !peer) {
      build(false);
      return;
    }

    void contacts
      .listBlocked()
      .then((result) => build((result.blocked ?? []).some((entry) => entry.blocked_id === peer.user_id)))
      // If the lookup fails, fall back to offering Block rather than blocking the
      // whole sheet: the report action still has to be reachable.
      .catch(() => build(false));
  }, [detail, peer, chatId, onOpenMembers, title]);

  // --- realtime -----------------------------------------------------------
  useEffect(() => {
    return subscribe((event) => {
      if (event.chatId !== chatId) return;

      switch (event.type) {
        case 'message.new': {
          const incoming = event.message as LocalMessage;
          if (!incoming?.id) return;
          setItems((current) => {
            // Skip if we already have it (our own optimistic row reconciled, or
            // a duplicate frame).
            if (current.some((m) => m.id === incoming.id)) return current;
            // Drop any optimistic twin of our own message.
            const withoutTwin = current.filter(
              (m) => !(m.localStatus && m.senderId === incoming.senderId && m.body === incoming.body),
            );
            return [incoming, ...withoutTwin];
          });

          // Reading it immediately keeps the sender's ticks honest.
          if (incoming.senderId !== user?.id && incoming.seq) {
            void messagesApi.markRead(chatId, incoming.seq).catch(() => {});
            sendFrame({ type: 'read', chatId, upToSeq: incoming.seq });
          }
          break;
        }

        case 'message.deleted': {
          const messageId = event.messageId as string;
          setItems((current) =>
            event.scope === 'everyone'
              ? current.map((m) => (m.id === messageId ? { ...m, isDeleted: true, body: null } : m))
              : current.filter((m) => m.id !== messageId),
          );
          break;
        }

        case 'message.updated': {
          const updated = event.message as LocalMessage;
          setItems((current) => current.map((m) => (m.id === updated.id ? { ...updated, localStatus: undefined } : m)));
          break;
        }

        case 'receipt.update': {
          if (event.userId === user?.id) break;
          if (typeof event.deliveredUpTo === 'number') {
            setPeerDelivered((prev) => Math.max(prev, event.deliveredUpTo as number));
          }
          if (typeof event.readUpTo === 'number') {
            setPeerRead((prev) => Math.max(prev, event.readUpTo as number));
          }
          break;
        }

        case 'typing.start':
          if (event.userId !== user?.id) setPeerTyping(true);
          break;

        case 'typing.stop':
          if (event.userId !== user?.id) setPeerTyping(false);
          break;

        default:
          break;
      }
    });
  }, [subscribe, chatId, user?.id, sendFrame]);

  // --- sending ------------------------------------------------------------
  const doSend = useCallback(
    async (body: string, localId: string) => {
      const clientId = `${user?.id ?? 'anon'}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      try {
        const result = await messagesApi.send(chatId, body, clientId);
        setItems((current) =>
          current.map((m) => (m.localId === localId ? { ...result.message, localStatus: undefined } : m)),
        );
      } catch (err) {
        setItems((current) => current.map((m) => (m.localId === localId ? { ...m, localStatus: 'failed' } : m)));
        if (err instanceof ApiError && err.code === 'blocked_by_recipient') {
          setError('You can no longer send messages to this person.');
        }
      }
    },
    [chatId, user?.id],
  );

  const sendMessage = useCallback(() => {
    const body = draft.trim();
    if (!body || !user) return;

    const localId = `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const optimistic: LocalMessage = {
      id: localId,
      localId,
      seq: Number.MAX_SAFE_INTEGER,
      chatId,
      senderId: user.id,
      type: 'text',
      body,
      metadata: {},
      replyToId: null,
      isDeleted: false,
      editedAt: null,
      isViewOnce: false,
      expiresAt: null,
      createdAt: new Date().toISOString(),
      clientId: null,
      reactions: [],
      attachments: [],
      mentions: [],
      poll: null,
      localStatus: 'sending',
    };

    setItems((current) => [optimistic, ...current]);
    setDraft('');
    void doSend(body, localId);
  }, [draft, user, chatId, doSend]);

  const onDraftChange = useCallback(
    (text: string) => {
      setDraft(text);
      const now = Date.now();
      // Throttle: one typing frame every 2s is plenty, and sending one per
      // keystroke would be a needless flood of WebSocket traffic.
      if (now - lastTypingSent.current > 2000) {
        lastTypingSent.current = now;
        sendFrame({ type: 'typing.start', chatId });
      }
      if (typingTimer.current) clearTimeout(typingTimer.current);
      typingTimer.current = setTimeout(() => sendFrame({ type: 'typing.stop', chatId }), 3000);
    },
    [chatId, sendFrame],
  );

  useEffect(() => {
    return () => {
      if (typingTimer.current) clearTimeout(typingTimer.current);
    };
  }, []);

  // --- rendering ----------------------------------------------------------
  const statusFor = (message: LocalMessage): string => {
    if (message.localStatus === 'sending') return '·';
    if (message.localStatus === 'failed') return '!';
    if (message.seq <= peerRead) return '✓✓';
    if (message.seq <= peerDelivered) return '✓✓';
    return '✓';
  };

  const renderMessage = ({ item }: { item: LocalMessage }) => {
    const isMine = item.senderId === user?.id;
    const failed = item.localStatus === 'failed';

    return (
      <View style={[styles.bubbleRow, isMine ? styles.bubbleRowMine : styles.bubbleRowTheirs]}>
        <Pressable
          onLongPress={() => {
            if (item.localStatus) return;
            void messagesApi.react(chatId, item.id, '👍').catch(() => {});
          }}
          onPress={() => {
            if (failed) {
              setItems((current) => current.map((m) => (m.id === item.id ? { ...m, localStatus: 'sending' } : m)));
              void doSend(item.body ?? '', item.localId ?? item.id);
            }
          }}
          style={[styles.bubble, isMine ? styles.bubbleMine : styles.bubbleTheirs, failed && styles.bubbleFailed]}
        >
          {!item.isDeleted && item.attachments.length > 0 ? (
            <AttachmentPreview attachment={item.attachments[0]!} token={token} />
          ) : null}

          {item.isDeleted || item.body ? (
            <Text style={styles.bubbleText}>
              {item.isDeleted ? <Text style={styles.deletedText}>This message was deleted</Text> : item.body}
            </Text>
          ) : null}

          {!item.isDeleted && item.reactions.length > 0 ? (
            <Text style={styles.reactions}>{item.reactions.map((r) => r.emoji).join(' ')}</Text>
          ) : null}

          <View style={styles.metaRow}>
            {item.editedAt ? <Text style={styles.metaText}>edited </Text> : null}
            <Text style={styles.metaText}>{formatClockTime(item.createdAt)}</Text>
            {isMine ? (
              <Text style={[styles.metaText, peerRead >= item.seq && !item.localStatus && styles.tickRead]}>
                {' '}
                {statusFor(item)}
              </Text>
            ) : null}
          </View>
        </Pressable>
        {failed ? <Text style={styles.failedHint}>Tap to retry</Text> : null}
      </View>
    );
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>{'‹'}</Text>
        </Pressable>
        {peer ? <Avatar name={peer.display_name ?? peer.username ?? '?'} size={36} /> : null}
        <View style={styles.flex}>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {title}
          </Text>
          <Text style={styles.headerSub}>
            {peerTyping
              ? 'typing…'
              : peerIsOnline
                ? 'online'
                : peer?.last_seen_at
                  ? `last seen ${formatTimestamp(peer.last_seen_at)}`
                  : peer?.username
                    ? `@${peer.username}`
                    : ''}
          </Text>
        </View>
        <Pressable onPress={openActions} hitSlop={10} style={styles.menuButton}>
          <Text style={styles.menuText}>⋯</Text>
        </Pressable>
      </View>

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      ) : (
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.flex}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
        >
          <FlatList
            // The API returns newest-first, which is exactly what `inverted`
            // expects, so no client-side sorting is needed.
            inverted
            data={items}
            keyExtractor={(item) => item.id}
            renderItem={renderMessage}
            contentContainerStyle={styles.listContent}
          />

          <View style={[styles.composer, { paddingBottom: spacing.sm + BOTTOM_SYSTEM_BAR_CLEARANCE }]}>
            <Pressable onPress={pickAndSendImage} disabled={uploading} style={styles.attachButton} hitSlop={6}>
              {uploading ? <ActivityIndicator size="small" /> : <Text style={styles.attachText}>＋</Text>}
            </Pressable>
            <Pressable onPress={pickAndSendDocument} disabled={uploading} style={styles.attachButton} hitSlop={6}>
              <Text style={styles.attachText}>📎</Text>
            </Pressable>
            <TextInput
              value={draft}
              onChangeText={onDraftChange}
              placeholder="Message"
              placeholderTextColor={colors.textFaint}
              style={styles.composerInput}
              multiline
            />
            <Pressable
              onPress={sendMessage}
              disabled={draft.trim().length === 0}
              style={[styles.sendButton, draft.trim().length === 0 && styles.sendButtonDisabled]}
            >
              <Text style={styles.sendText}>Send</Text>
            </Pressable>
          </View>
        </KeyboardAvoidingView>
      )}
    </Screen>
  );
}

/**
 * Renders an attachment inside a bubble. Images stream straight from the
 * authenticated attachment endpoint; anything else is a labelled row, because a
 * chat bubble is a bad place to embed a PDF viewer.
 */
function AttachmentPreview({ attachment, token }: { attachment: Message['attachments'][number]; token: string | null }) {
  const uri = attachmentUrl(attachment.id, token);

  if (attachment.kind === 'image' || attachment.kind === 'sticker' || attachment.kind === 'gif') {
    return <Image source={{ uri }} style={styles.attachmentImage} resizeMode="cover" />;
  }

  return (
    <View style={styles.attachmentFile}>
      <Text style={styles.attachmentFileText}>📄 {attachment.fileName ?? 'Attachment'}</Text>
      <Text style={styles.attachmentFileMeta}>
        {attachment.mimeType} · {Math.max(1, Math.round(attachment.byteSize / 1024))} KB
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  menuButton: { paddingHorizontal: spacing.sm },
  menuText: { fontSize: 24, color: colors.textMuted, lineHeight: 26 },
  headerTitle: { fontSize: 16, fontWeight: '600', color: colors.text },
  headerSub: { ...typography.small },

  listContent: { padding: spacing.md, gap: spacing.sm },
  bubbleRow: { maxWidth: '85%' },
  bubbleRowMine: { alignSelf: 'flex-end', alignItems: 'flex-end' },
  bubbleRowTheirs: { alignSelf: 'flex-start' },
  bubble: { borderRadius: 12, paddingHorizontal: spacing.md, paddingVertical: spacing.sm },
  bubbleMine: { backgroundColor: colors.bubbleOutgoing },
  bubbleTheirs: { backgroundColor: colors.surface },
  bubbleFailed: { backgroundColor: colors.dangerBg },
  bubbleText: { fontSize: 15, color: colors.text, lineHeight: 20 },
  deletedText: { fontStyle: 'italic', color: colors.textMuted },
  reactions: { fontSize: 14, marginTop: 4 },
  metaRow: { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', marginTop: 2 },
  metaText: { fontSize: 11, color: colors.textFaint },
  tickRead: { color: colors.tickRead },
  failedHint: { ...typography.small, color: colors.danger, marginTop: 2 },

  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  errorWrap: { paddingHorizontal: spacing.md },

  composer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: spacing.sm,
    padding: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  attachButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
  attachText: { fontSize: 22, color: colors.primary, lineHeight: 26 },
  attachmentImage: { width: 220, height: 220, borderRadius: 10, backgroundColor: colors.surfaceAlt, marginBottom: 4 },
  attachmentFile: { gap: 2, marginBottom: 4 },
  attachmentFileText: { fontSize: 14, color: colors.text, fontWeight: '600' },
  attachmentFileMeta: { fontSize: 11, color: colors.textMuted },
  composerInput: {
    flex: 1,
    maxHeight: 120,
    minHeight: 44,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 22,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    fontSize: 15,
    lineHeight: 20,
    color: colors.text,
    // Android puts multiline text at the top of the box by default, which left
    // the single-line case sitting high against the pill's rounded edge.
    textAlignVertical: 'center',
  },
  sendButton: {
    height: 44,
    paddingHorizontal: spacing.lg,
    borderRadius: 22,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendButtonDisabled: { opacity: 0.4 },
  sendText: { color: colors.primaryText, fontWeight: '700' },
});
