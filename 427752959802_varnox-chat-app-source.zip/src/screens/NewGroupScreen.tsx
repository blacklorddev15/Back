import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { chats, users, type UserSearchResult } from '../api/client';
import { Avatar, EmptyState, ErrorBanner, PrimaryButton, Screen } from '../components/ui';
import { describeError } from '../state/AuthContext';
import { bottomSystemBarClearance, colors, spacing, typography } from '../theme';

/**
 * Create a group.
 *
 * Members are chosen from a search rather than a contact picker because the
 * backend's search already respects each user's discoverability settings and
 * excludes anyone who has blocked you — a client-side contact list cannot make
 * those guarantees.
 *
 * The creator is added by the server as owner; the id is deliberately not sent
 * in memberIds, and the backend filters it out anyway if it is.
 */
export function NewGroupScreen({
  onCreated,
  onBack,
}: {
  onCreated: (chatId: string) => void;
  onBack: () => void;
}) {
  const [title, setTitle] = useState('');
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<UserSearchResult[]>([]);
  const [selected, setSelected] = useState<Map<string, UserSearchResult>>(new Map());
  const [searching, setSearching] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const term = query.trim();
    if (term.length < 3) {
      setResults([]);
      return;
    }

    let cancelled = false;
    setSearching(true);
    const timer = setTimeout(async () => {
      try {
        const found = await users.search(term);
        if (!cancelled) setResults(found.results ?? []);
      } catch (err) {
        if (!cancelled) setError(describeError(err));
      } finally {
        if (!cancelled) setSearching(false);
      }
    }, 350);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  const toggle = (user: UserSearchResult) => {
    setSelected((current) => {
      const next = new Map(current);
      if (next.has(user.id)) next.delete(user.id);
      else next.set(user.id, user);
      return next;
    });
  };

  const create = async () => {
    setError(null);
    if (!title.trim()) {
      setError('Give the group a name.');
      return;
    }
    if (selected.size === 0) {
      setError('Add at least one other member.');
      return;
    }

    setCreating(true);
    try {
      const result = await chats.createGroup({
        title: title.trim(),
        memberIds: [...selected.keys()],
      });
      onCreated(result.chatId);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setCreating(false);
    }
  };

  const selectedList = [...selected.values()];

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>{'‹'}</Text>
        </Pressable>
        <Text style={styles.headerTitle}>New group</Text>
      </View>

      <View style={styles.top}>
        <TextInput
          value={title}
          onChangeText={setTitle}
          placeholder="Group name"
          placeholderTextColor={colors.textFaint}
          style={styles.titleInput}
        />

        {selectedList.length > 0 ? (
          <View style={styles.chips}>
            {selectedList.map((user) => (
              <Pressable key={user.id} onPress={() => toggle(user)} style={styles.chip}>
                <Text style={styles.chipText}>
                  {user.display_name ?? user.username ?? 'Member'} ✕
                </Text>
              </Pressable>
            ))}
          </View>
        ) : null}

        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Add people by username, email or phone"
          placeholderTextColor={colors.textFaint}
          style={styles.search}
          autoCapitalize="none"
          autoCorrect={false}
        />

        {error ? <ErrorBanner message={error} /> : null}
      </View>

      {searching ? (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={(item) => item.id}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          renderItem={({ item }) => {
            const isSelected = selected.has(item.id);
            return (
              <Pressable style={styles.row} onPress={() => toggle(item)}>
                <Avatar name={item.display_name ?? item.username ?? '?'} size={40} />
                <View style={styles.rowBody}>
                  <Text style={styles.rowTitle}>{item.display_name ?? item.username ?? 'Unnamed'}</Text>
                  <Text style={styles.rowSub}>{item.username ? `@${item.username}` : 'No username'}</Text>
                </View>
                <View style={[styles.checkbox, isSelected && styles.checkboxOn]}>
                  {isSelected ? <Text style={styles.checkmark}>✓</Text> : null}
                </View>
              </Pressable>
            );
          }}
          ListEmptyComponent={
            query.trim().length < 3 ? (
              <EmptyState title="Add members" subtitle="Type at least 3 characters to search for people." />
            ) : (
              <EmptyState title="Nobody found" subtitle="Try a different username." />
            )
          }
          contentContainerStyle={results.length === 0 ? styles.emptyContainer : undefined}
        />
      )}

      <View style={styles.footer}>
        <PrimaryButton
          title={selected.size > 0 ? `Create group with ${selected.size + 1} members` : 'Create group'}
          onPress={create}
          loading={creating}
          disabled={!title.trim() || selected.size === 0}
        />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { fontSize: 18, fontWeight: '600', color: colors.text },
  top: { padding: spacing.lg, gap: spacing.md },
  titleInput: {
    height: 46,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    fontSize: 18,
    color: colors.text,
  },
  search: {
    height: 44,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 22,
    paddingHorizontal: spacing.lg,
    fontSize: 15,
    color: colors.text,
  },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  chip: { backgroundColor: colors.surfaceAlt, borderRadius: 999, paddingHorizontal: spacing.md, paddingVertical: 6 },
  chipText: { fontSize: 13, color: colors.text },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingHorizontal: spacing.lg, paddingVertical: spacing.sm },
  rowBody: { flex: 1 },
  rowTitle: { fontSize: 15, fontWeight: '600', color: colors.text },
  rowSub: { ...typography.small },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 6,
    borderWidth: 1.5,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  checkmark: { color: colors.primaryText, fontSize: 14, fontWeight: '700' },
  separator: { height: 1, backgroundColor: colors.border, marginLeft: 68 },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyContainer: { flexGrow: 1 },
  // Pinned to the bottom of the window, so it has to clear the system
  // navigation bar itself, like every other bottom bar in the app.
  footer: {
    padding: spacing.lg,
    paddingBottom: spacing.lg + bottomSystemBarClearance,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
});
