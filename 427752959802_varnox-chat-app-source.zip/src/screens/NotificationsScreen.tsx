import React, { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, Switch, Text, View } from 'react-native';
import {
  me,
  notifications as notificationsApi,
  type AppNotification,
  type NotificationSettings,
} from '../api/client';
import { EmptyState, ErrorBanner, Screen } from '../components/ui';
import { describeError, useAuth } from '../state/AuthContext';
import { colors, formatTimestamp, spacing, typography } from '../theme';

/**
 * The notification centre.
 *
 * This is the *in-app* half of notifications: a durable record of what
 * happened, readable whenever the app is open. The other half — a banner when
 * the app is closed — is push, which is server-side complete (`notifyNewMessage`
 * writes the row and `sendExpoPush` posts it to Expo for every registered
 * device) but cannot be switched on from here: the app has no
 * `expo-notifications` module, so it has no device token to register. That needs
 * a native build; until then this screen is where notifications are read.
 */

/** Type → glyph. Anything unmapped falls back to a neutral bell. */
const ICONS: Record<string, string> = {
  message: '💬',
  group_message: '👥',
  mention: '@',
  reply: '↩️',
  reaction: '❤️',
  voice_call: '📞',
  video_call: '🎥',
  missed_call: '📵',
  group_invite: '👥',
  channel_post: '📣',
  channel_update: '📣',
  status: '◎',
  security: '🔒',
  system: 'ℹ️',
  moderation: '⚠️',
  report_update: '⚠️',
  follow: '➕',
};

export function NotificationsScreen({
  onBack,
  onOpenChat,
  onOpenSettings,
}: {
  onBack: () => void;
  onOpenChat: (chatId: string) => void;
  onOpenSettings: () => void;
}) {
  const [items, setItems] = useState<AppNotification[]>([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const data = await notificationsApi.list({ limit: 100 });
      setItems(data.notifications ?? []);
      setUnread(data.unreadCount ?? 0);
      setError(null);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const open = async (item: AppNotification) => {
    // Marking read first means the list is already correct if the destination
    // pushes a new screen and this one is unmounted.
    if (!item.read_at) {
      try {
        await notificationsApi.markRead([item.id]);
        setItems((current) => current.map((n) => (n.id === item.id ? { ...n, read_at: new Date().toISOString() } : n)));
        setUnread((value) => Math.max(0, value - 1));
      } catch {
        // Non-fatal: the navigation below is what the tap was for.
      }
    }
    if (item.target_type === 'chat' && item.target_id) onOpenChat(item.target_id);
  };

  const markAllRead = async () => {
    try {
      await notificationsApi.markRead();
      const now = new Date().toISOString();
      setItems((current) => current.map((n) => (n.read_at ? n : { ...n, read_at: now })));
      setUnread(0);
    } catch (err) {
      setError(describeError(err));
    }
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>‹</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Notifications</Text>
        {unread > 0 ? (
          <Pressable onPress={() => void markAllRead()} hitSlop={8}>
            <Text style={styles.headerAction}>Mark all read</Text>
          </Pressable>
        ) : (
          <Pressable onPress={onOpenSettings} hitSlop={8}>
            <Text style={styles.headerAction}>Settings</Text>
          </Pressable>
        )}
      </View>

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                setRefreshing(true);
                void load();
              }}
            />
          }
          renderItem={({ item }) => (
            <Pressable style={[styles.row, !item.read_at && styles.rowUnread]} onPress={() => void open(item)}>
              <Text style={styles.icon}>{ICONS[item.type] ?? '🔔'}</Text>
              <View style={styles.rowBody}>
                <Text style={styles.rowTitle} numberOfLines={1}>
                  {item.title ?? item.type.replace(/_/g, ' ')}
                </Text>
                {item.body ? (
                  <Text style={styles.rowSub} numberOfLines={2}>
                    {item.body}
                  </Text>
                ) : null}
                <Text style={styles.rowTime}>{formatTimestamp(item.created_at)}</Text>
              </View>
              {!item.read_at ? <View style={styles.dot} /> : null}
            </Pressable>
          )}
          ListEmptyComponent={
            <View style={styles.emptyWrap}>
              <EmptyState
                title="No notifications"
                subtitle="Messages, mentions and security alerts land here. Banners while the app is closed need push, which arrives with the next build."
              />
            </View>
          }
        />
      )}
    </Screen>
  );
}

/** Preferences. Several of these only bite once push exists, which is stated. */
export function NotificationSettingsScreen({ onBack }: { onBack: () => void }) {
  const [settings, setSettings] = useState<NotificationSettings | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void (async () => {
      try {
        const self = await me.get();
        setSettings((self.notifications as NotificationSettings | null) ?? null);
      } catch (err) {
        setError(describeError(err));
      }
    })();
  }, []);

  const update = async (patch: Partial<NotificationSettings>) => {
    setSaving(true);
    setError(null);
    try {
      const result = await me.updateNotifications(patch);
      setSettings(result.notifications);
    } catch (err) {
      setError(describeError(err));
    } finally {
      setSaving(false);
    }
  };

  if (!settings) {
    return (
      <Screen>
        <View style={styles.header}>
          <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
            <Text style={styles.backText}>‹</Text>
          </Pressable>
          <Text style={styles.headerTitle}>Notification settings</Text>
        </View>
        {error ? <ErrorBanner message={error} /> : <ActivityIndicator style={styles.loading} />}
      </Screen>
    );
  }

  const toggles: Array<{ key: keyof NotificationSettings; label: string; hint: string }> = [
    { key: 'inAppEnabled', label: 'In-app notifications', hint: 'Show new activity while the app is open' },
    { key: 'previewsEnabled', label: 'Message previews', hint: 'Include the message text, not just who sent it' },
    { key: 'badgeEnabled', label: 'Notification badge', hint: 'Show an unread count on the app icon' },
    { key: 'vibrationEnabled', label: 'Vibration', hint: 'Vibrate on a new notification' },
    { key: 'emailSecurityAlerts', label: 'Security emails', hint: 'Email me about new sign-ins and password changes' },
  ];

  const privacyOptions: Array<{ id: NotificationSettings['notificationPrivacy']; label: string }> = [
    { id: 'sender_and_message', label: 'Sender and message' },
    { id: 'sender_only', label: 'Sender only' },
    { id: 'hidden', label: 'Hide content' },
  ];

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backButton}>
          <Text style={styles.backText}>‹</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Notification settings</Text>
      </View>

      {error ? (
        <View style={styles.errorWrap}>
          <ErrorBanner message={error} />
        </View>
      ) : null}

      <View style={styles.list}>
        {toggles.map((toggle) => (
          <View key={String(toggle.key)} style={styles.row}>
            <View style={styles.rowBody}>
              <Text style={styles.rowTitle}>{toggle.label}</Text>
              <Text style={styles.rowSub}>{toggle.hint}</Text>
            </View>
            <Switch
              value={Boolean(settings[toggle.key])}
              onValueChange={(value) => void update({ [toggle.key]: value } as Partial<NotificationSettings>)}
              disabled={saving}
            />
          </View>
        ))}

        <View style={styles.sectionLabelWrap}>
          <Text style={styles.sectionLabel}>When the app is closed</Text>
        </View>
        {privacyOptions.map((option) => (
          <Pressable
            key={option.id}
            style={styles.row}
            disabled={saving}
            onPress={() => void update({ notificationPrivacy: option.id })}
          >
            <View style={styles.radioOuter}>
              {settings.notificationPrivacy === option.id ? <View style={styles.radioInner} /> : null}
            </View>
            <View style={styles.rowBody}>
              <Text style={styles.rowTitle}>{option.label}</Text>
            </View>
          </Pressable>
        ))}

        <Text style={styles.footnote}>
          These are stored and applied by the server. Vibration and badge only take effect once push is enabled on this
          device, which needs the next native build — the server half is already in place.
        </Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backButton: { paddingHorizontal: spacing.xs },
  backText: { fontSize: 30, color: colors.primary, lineHeight: 32 },
  headerTitle: { flex: 1, fontSize: 18, fontWeight: '600', color: colors.text },
  headerAction: { color: colors.primary, fontWeight: '600', fontSize: 14 },

  list: { paddingTop: spacing.sm },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  rowUnread: { backgroundColor: colors.primarySoft },
  rowBody: { flex: 1 },
  rowTitle: { fontSize: 16, fontWeight: '600', color: colors.text },
  rowSub: { ...typography.small, marginTop: 2 },
  rowTime: { ...typography.small, fontSize: 11, marginTop: 4 },
  icon: { fontSize: 20, width: 28, textAlign: 'center' },
  dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.primary },

  sectionLabelWrap: { paddingHorizontal: spacing.lg, paddingTop: spacing.lg, paddingBottom: spacing.xs },
  sectionLabel: { ...typography.small, fontWeight: '600' },
  radioOuter: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioInner: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.primary },

  loading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  errorWrap: { paddingHorizontal: spacing.lg },
  emptyWrap: { paddingTop: spacing.xl },
  footnote: { ...typography.small, padding: spacing.lg },
});
