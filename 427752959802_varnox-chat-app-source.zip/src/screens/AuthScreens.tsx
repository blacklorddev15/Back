import React, { useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { BrandMark, ErrorBanner, Notice, PrimaryButton, Screen, Segmented, TextField } from '../components/ui';
import { describeError, useAuth } from '../state/AuthContext';
import { colors, radius, spacing, typography } from '../theme';

/**
 * Onboarding and authentication.
 *
 * The flow is deliberately three screens rather than one, because the backend
 * will not issue a session until the emailed code is verified — the account sits
 * in `pending`. Collapsing that into a single form would mean either pretending
 * verification succeeded or failing after the fact.
 *
 *   Onboarding → Auth (login | register) → Verify email → signed in
 */

// ---------------------------------------------------------------------------
// Onboarding
// ---------------------------------------------------------------------------

export function OnboardingScreen({
  onGetStarted,
  onSignIn,
}: {
  onGetStarted: () => void;
  onSignIn: () => void;
}) {
  return (
    <Screen>
      <ScrollView contentContainerStyle={styles.onboarding} showsVerticalScrollIndicator={false}>
        <Text style={styles.eyebrow}>PRIVATE MESSAGING</Text>
        <Text style={styles.wordmark}>VARNOX</Text>

        {/* The brand mark: concentric rings with the phoenix at the centre. */}
        <View style={styles.markWrap}>
          <BrandMark size={300} />
        </View>

        <Text style={styles.onboardingHeading}>Private by design.</Text>
        <Text style={styles.onboardingSub}>
          Messages, calls and updates for the people you choose — and nobody else.
        </Text>

        <View style={styles.onboardingCta}>
          <PrimaryButton title="Get started" onPress={onGetStarted} variant="white" />
        </View>

        <View style={styles.onboardingLinks}>
          <Text style={styles.finePrint}>
            Already have an account?{' '}
            <Text style={styles.link} onPress={onSignIn}>
              Log in
            </Text>
          </Text>
          {/* Rendered as plain text, not tappable links: these pages do not exist
              yet, and a link that goes nowhere is worse than unlinked text. */}
          <Text style={styles.finePrint}>Read our Privacy Policy and Terms of Service.</Text>
          <Text style={styles.license}>License</Text>
        </View>
      </ScrollView>
    </Screen>
  );
}

// ---------------------------------------------------------------------------
// Login / Register
// ---------------------------------------------------------------------------

export function AuthScreen({
  initialMode = 'login',
  onBack,
  onTwoStep,
  onRegistered,
  onForgotPassword,
}: {
  initialMode?: 'login' | 'register';
  onBack: () => void;
  onTwoStep: (challengeToken: string) => void;
  onRegistered: (email: string) => void;
  onForgotPassword: () => void;
}) {
  const { signIn, register } = useAuth();
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [confirm, setConfirm] = useState('');

  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const switchMode = (next: 'login' | 'register') => {
    setMode(next);
    setError(null);
  };

  const submitLogin = async () => {
    setError(null);
    if (!identifier.trim() || !password) {
      setError('Enter your username and password.');
      return;
    }
    setBusy(true);
    try {
      const result = await signIn(identifier, password);
      if (result.twoStepRequired && result.challengeToken) {
        onTwoStep(result.challengeToken);
      }
      // On success AuthProvider flips to signedIn and the router swaps screens.
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(false);
    }
  };

  const submitRegister = async () => {
    setError(null);

    // The backend validates all of this too; checking here saves a round trip
    // for an obvious typo.
    if (!fullName.trim()) return setError('Enter your full name.');
    if (!email.includes('@')) return setError('Enter a valid email address.');
    if (!/^\+?[1-9]\d{6,14}$/.test(phone.replace(/[\s()-]/g, ''))) {
      return setError('Enter your phone number in international format, e.g. +254712345678.');
    }
    if (password.length < 8) return setError('Password must be at least 8 characters.');
    if (password !== confirm) return setError('The two passwords do not match.');

    setBusy(true);
    try {
      await register({
        fullName: fullName.trim(),
        email: email.trim(),
        phone: phone.replace(/[\s()-]/g, ''),
        password,
      });
      onRegistered(email.trim());
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.authBody} keyboardShouldPersistTaps="handled">
          <Pressable onPress={onBack} style={styles.back} hitSlop={10}>
            <Text style={styles.backText}>{'←'} Back</Text>
          </Pressable>

          <View style={styles.authBrandRow}>
            <Text style={styles.authWordmark}>VARNOX</Text>
            <View style={styles.appChip}>
              <Text style={styles.appChipText}>APP</Text>
            </View>
          </View>

          <Text style={styles.authHeading}>Your conversations, private and close.</Text>
          <Text style={styles.authSub}>Create an account or sign in to continue.</Text>

          <View style={styles.segmentedWrap}>
            <Segmented
              options={[
                { value: 'login', label: 'Log in' },
                { value: 'register', label: 'Register' },
              ]}
              value={mode}
              onChange={switchMode}
            />
          </View>

          <ErrorBanner message={error} />

          {mode === 'login' ? (
            <>
              <TextField
                label="Username"
                value={identifier}
                onChangeText={setIdentifier}
                placeholder="you@example.com"
                keyboardType="email-address"
                textContentType="username"
                hint="Email, phone number or username all work."
              />
              <TextField
                label="Password"
                value={password}
                onChangeText={setPassword}
                placeholder="At least 8 characters"
                secureTextEntry
                textContentType="password"
              />
              <PrimaryButton title="Log in to VARNOX" onPress={submitLogin} loading={busy} />
              <Pressable onPress={onForgotPassword} style={styles.linkRow}>
                <Text style={styles.link}>Forgot password?</Text>
              </Pressable>
              <Pressable onPress={() => switchMode('register')} style={styles.linkRow}>
                <Text style={styles.mutedLink}>Sign in with a phone &amp; email code</Text>
              </Pressable>
            </>
          ) : (
            <>
              <TextField label="Full name" value={fullName} onChangeText={setFullName} placeholder="Ada Lovelace" />
              <TextField
                label="Email"
                value={email}
                onChangeText={setEmail}
                placeholder="you@example.com"
                keyboardType="email-address"
                textContentType="emailAddress"
              />
              <TextField
                label="Phone number"
                value={phone}
                onChangeText={setPhone}
                placeholder="+254712345678"
                keyboardType="phone-pad"
              />
              <TextField
                label="Password"
                value={password}
                onChangeText={setPassword}
                placeholder="At least 8 characters"
                secureTextEntry
              />
              <TextField
                label="Confirm password"
                value={confirm}
                onChangeText={setConfirm}
                placeholder="Repeat your password"
                secureTextEntry
              />
              <PrimaryButton title="Create my VARNOX account" onPress={submitRegister} loading={busy} />
              <Text style={styles.hintCentred}>
                We will email you a 6-digit code to confirm the address.
              </Text>
            </>
          )}
        </ScrollView>

        <Text style={styles.authFooter}>By continuing, you agree to use Varnox responsibly.</Text>
      </KeyboardAvoidingView>
    </Screen>
  );
}

// ---------------------------------------------------------------------------
// Two-step verification
// ---------------------------------------------------------------------------

export function TwoStepScreen({ challengeToken, onBack }: { challengeToken: string; onBack: () => void }) {
  const { verifyTwoStep } = useAuth();
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError(null);
    setBusy(true);
    try {
      await verifyTwoStep(challengeToken, pin.trim());
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Screen>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.form} keyboardShouldPersistTaps="handled">
          <Text style={styles.eyebrow}>SECURITY</Text>
          <Text style={styles.heading}>Two-step verification</Text>
          <Text style={styles.subheading}>
            Your password was correct. Enter your 6-digit PIN to finish signing in.
          </Text>
          <ErrorBanner message={error} />
          <TextField
            label="PIN"
            value={pin}
            onChangeText={(text) => setPin(text.replace(/[^0-9]/g, ''))}
            placeholder="000000"
            keyboardType="number-pad"
            maxLength={6}
          />
          <PrimaryButton title="Verify" onPress={submit} loading={busy} disabled={pin.length !== 6} />
          <Pressable onPress={onBack} style={styles.linkRow}>
            <Text style={styles.link}>Back</Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

// ---------------------------------------------------------------------------
// Email verification
// ---------------------------------------------------------------------------

export function VerifyEmailScreen({ email, onBack }: { email: string; onBack: () => void }) {
  const { verifyEmail, resendVerification } = useAuth();
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [resending, setResending] = useState(false);

  const submit = async () => {
    setError(null);
    setNotice(null);
    setBusy(true);
    try {
      await verifyEmail(email, code.trim());
    } catch (err) {
      setError(describeError(err));
    } finally {
      setBusy(false);
    }
  };

  const resend = async () => {
    setError(null);
    setNotice(null);
    setResending(true);
    try {
      await resendVerification(email);
      setNotice('If that address needs verification, a new code is on its way.');
    } catch (err) {
      // The backend rate-limits resends and its message says exactly how long
      // to wait, so surface it verbatim.
      setError(describeError(err));
    } finally {
      setResending(false);
    }
  };

  return (
    <Screen>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView contentContainerStyle={styles.form} keyboardShouldPersistTaps="handled">
          <Text style={styles.eyebrow}>VERIFY</Text>
          <Text style={styles.heading}>Check your email</Text>
          <Text style={styles.subheading}>Enter the 6-digit code we sent to {email}.</Text>
          {notice ? <Notice message={notice} tone="success" /> : null}
          <ErrorBanner message={error} />
          <TextField
            label="Verification code"
            value={code}
            onChangeText={(text) => setCode(text.replace(/[^0-9]/g, ''))}
            placeholder="000000"
            keyboardType="number-pad"
            maxLength={6}
          />
          <PrimaryButton title="Verify email" onPress={submit} loading={busy} disabled={code.length !== 6} />
          <PrimaryButton title="Resend code" onPress={resend} loading={resending} variant="secondary" />
          <Pressable
            onPress={() =>
              Alert.alert(
                'Code not arriving?',
                'Check your spam folder. The sending domain must have SPF and DKIM records configured or delivery will be unreliable.',
              )
            }
            style={styles.linkRow}
          >
            <Text style={styles.mutedLink}>Trouble receiving it?</Text>
          </Pressable>
          <Pressable onPress={onBack} style={styles.linkRow}>
            <Text style={styles.link}>Back to sign in</Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },

  // --- onboarding ---
  onboarding: { paddingHorizontal: spacing.xl, paddingTop: spacing.xl, paddingBottom: spacing.xxl, alignItems: 'center' },
  eyebrow: { ...typography.eyebrow, textAlign: 'center' },
  wordmark: { ...typography.wordmark, marginTop: spacing.sm, textAlign: 'center' },
  markWrap: { marginVertical: spacing.xxl },
  onboardingHeading: { ...typography.heading, textAlign: 'center', marginTop: spacing.md },
  onboardingSub: {
    ...typography.subtitle,
    textAlign: 'center',
    marginTop: spacing.md,
    lineHeight: 22,
    paddingHorizontal: spacing.md,
  },
  onboardingCta: { alignSelf: 'stretch', marginTop: spacing.xxl },
  onboardingLinks: { marginTop: spacing.xl, alignItems: 'center', gap: spacing.md },
  finePrint: { ...typography.small, textAlign: 'center' },
  license: { ...typography.small, letterSpacing: 2, marginTop: spacing.sm, color: colors.textFaint },
  link: { color: colors.primary, fontWeight: '700' },
  mutedLink: { color: colors.primary, fontWeight: '600', fontSize: 14 },

  // --- auth ---
  authBody: { padding: spacing.xl, paddingBottom: spacing.lg },
  back: { marginBottom: spacing.lg },
  backText: { color: colors.text, fontSize: 16, fontWeight: '600' },
  authBrandRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  authWordmark: { fontSize: 30, fontWeight: '800', color: colors.white, letterSpacing: 3 },
  appChip: {
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: radius.pill,
    paddingHorizontal: spacing.md,
    paddingVertical: 3,
  },
  appChipText: { color: colors.primary, fontSize: 11, fontWeight: '700', letterSpacing: 1.5 },
  authHeading: { ...typography.heading, fontSize: 28, marginTop: spacing.lg, lineHeight: 34 },
  authSub: { ...typography.subtitle, marginTop: spacing.md, marginBottom: spacing.xl },
  segmentedWrap: { marginBottom: spacing.xl },
  authFooter: { ...typography.small, textAlign: 'center', paddingVertical: spacing.lg, paddingHorizontal: spacing.xl },

  // --- shared ---
  form: { padding: spacing.xl, paddingBottom: spacing.xxl },
  heading: { ...typography.title, marginTop: spacing.sm, marginBottom: spacing.sm },
  subheading: { ...typography.subtitle, marginBottom: spacing.xl, lineHeight: 21 },
  linkRow: { marginTop: spacing.lg, alignItems: 'center' },
  hintCentred: { ...typography.small, textAlign: 'center', marginTop: spacing.lg },
});
