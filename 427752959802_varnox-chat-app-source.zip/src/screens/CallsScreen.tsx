import React from 'react';
import { StyleSheet, View } from 'react-native';
import { TabHeader } from '../components/TabBar';
import { EmptyState, Screen } from '../components/ui';
import { spacing } from '../theme';

/**
 * The Calls tab.
 *
 * Present so the navigation matches the shape of a messaging app, but call
 * history has nothing behind it yet: `call_events`, `call_participants` and
 * `call_links` exist in the database, while no API routes do. The screen says
 * so rather than showing a convincing empty list that would read as "you have
 * no calls" when the truth is "calls are not implemented".
 */
export function CallsScreen({ onOpenDrawer }: { onOpenDrawer: () => void }) {
  return (
    <Screen>
      <TabHeader title="Calls" subtitle="Voice and video" onOpenDrawer={onOpenDrawer} />
      <View style={styles.body}>
        <EmptyState
          title="Calls are not available yet"
          subtitle="Call history needs the calls API, which has not been built. The tables are already in the database, so this screen will fill in once those endpoints exist."
        />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  body: { flex: 1, paddingTop: spacing.xl },
});
