import React from 'react';
import {
  ActivityIndicator,
  Image,
  Platform,
  Pressable,
  StatusBar as RNStatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
  type TextInputProps,
  type ViewStyle,
} from 'react-native';
import { colors, radius, spacing, typography } from '../theme';

/**
 * Shared primitives, styled for the dark theme.
 *
 * `Screen` avoids react-native's SafeAreaView: on Android it is a no-op, so
 * content slides under the status bar. Padding from StatusBar.currentHeight is
 * reliable on both platforms without pulling in react-native-safe-area-context.
 */

export function Screen({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  const topInset = Platform.OS === 'android' ? RNStatusBar.currentHeight ?? 0 : 44;
  return <View style={[styles.screen, { paddingTop: topInset }, style]}>{children}</View>;
}

// ---------------------------------------------------------------------------
// Brand
// ---------------------------------------------------------------------------

/**
 * The concentric-ring brand mark with the phoenix at its centre.
 *
 * Rings are plain Views with borderRadius rather than an SVG dependency: three
 * circles and an empty bubble is not worth a drawing library. The image is the
 * transparent brand-mark asset, so the near-black field of the original JPEG
 * does not show as a square against the app background.
 */
export function BrandMark({ size = 300 }: { size?: number }) {
  const ring = (fraction: number, opacity: number) => ({
    position: 'absolute' as const,
    width: size * fraction,
    height: size * fraction,
    borderRadius: (size * fraction) / 2,
    borderWidth: 1,
    borderColor: `rgba(0, 168, 132, ${opacity})`,
  });

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          position: 'absolute',
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: colors.surface,
          opacity: 0.55,
        }}
      />
      <View style={ring(0.78, 0.35)} />
      <View style={ring(0.56, 0.5)} />
      <View
        style={{
          position: 'absolute',
          width: size * 0.36,
          height: size * 0.36,
          borderRadius: (size * 0.36) / 2,
          backgroundColor: colors.primarySoft,
        }}
      />
      <Image
        source={require('../../assets/brand-mark.png')}
        style={{ width: size * 0.34, height: size * 0.34 }}
        resizeMode="contain"
      />
    </View>
  );
}

// ---------------------------------------------------------------------------
// Buttons
// ---------------------------------------------------------------------------

export function PrimaryButton({
  title,
  onPress,
  loading = false,
  disabled = false,
  variant = 'primary',
}: {
  title: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  variant?: 'primary' | 'secondary' | 'danger' | 'white';
}) {
  const isDisabled = disabled || loading;
  const background =
    variant === 'primary'
      ? colors.primary
      : variant === 'white'
        ? colors.white
        : variant === 'danger'
          ? colors.danger
          : colors.surfaceAlt;
  const textColor =
    variant === 'primary'
      ? colors.primaryText
      : variant === 'white'
        ? colors.onWhite
        : variant === 'danger'
          ? colors.white
          : colors.text;

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: background },
        isDisabled && styles.buttonDisabled,
        pressed && !isDisabled && styles.buttonPressed,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={textColor} size="small" />
      ) : (
        <Text style={[styles.buttonText, { color: textColor }]}>{title}</Text>
      )}
    </Pressable>
  );
}

/** The Log in | Register pill toggle. */
export function Segmented<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (value: T) => void;
}) {
  return (
    <View style={styles.segmented}>
      {options.map((option) => {
        const active = option.value === value;
        return (
          <Pressable
            key={option.value}
            onPress={() => onChange(option.value)}
            style={[styles.segment, active && styles.segmentActive]}
          >
            <Text style={[styles.segmentText, active && styles.segmentTextActive]}>{option.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

// ---------------------------------------------------------------------------
// Fields & feedback
// ---------------------------------------------------------------------------

export function TextField({
  label,
  hint,
  ...inputProps
}: { label: string; hint?: string } & TextInputProps) {
  return (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        placeholderTextColor={colors.textFaint}
        style={styles.input}
        autoCapitalize="none"
        autoCorrect={false}
        {...inputProps}
      />
      {hint ? <Text style={styles.fieldHint}>{hint}</Text> : null}
    </View>
  );
}

export function ErrorBanner({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <View style={styles.errorBanner}>
      <Text style={styles.errorText}>{message}</Text>
    </View>
  );
}

export function Notice({ message, tone = 'info' }: { message: string; tone?: 'info' | 'success' }) {
  return (
    <View style={[styles.notice, tone === 'success' && styles.noticeSuccess]}>
      <Text style={[styles.noticeText, tone === 'success' && styles.noticeTextSuccess]}>{message}</Text>
    </View>
  );
}

export function EmptyState({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <View style={styles.empty}>
      <Text style={styles.emptyTitle}>{title}</Text>
      {subtitle ? <Text style={styles.emptySubtitle}>{subtitle}</Text> : null}
    </View>
  );
}

export function LinkText({ children, onPress }: { children: React.ReactNode; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} hitSlop={6}>
      <Text style={styles.link}>{children}</Text>
    </Pressable>
  );
}

export function Avatar({ name, size = 48, uri }: { name: string; size?: number; uri?: string | null }) {
  // A photo when there is one, initials otherwise. The initials stay as the
  // fallback rather than an error state: most members will never set a photo,
  // and a coloured initial reads better than a broken image.
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('');

  // Deterministic colour from the name so the same person keeps the same colour.
  // Mid-tone hues only: they need to hold up against a near-black surface.
  const palette = ['#0E7C6B', '#1F5F8B', '#5B4B9E', '#8A6D2F', '#8C4A2F', '#2A6E70'];
  const index = name.split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 0) % palette.length;

  if (uri) {
    return (
      <Image
        source={{ uri }}
        style={[styles.avatar, { width: size, height: size, borderRadius: size / 2 }]}
        resizeMode="cover"
      />
    );
  }

  return (
    <View
      style={[
        styles.avatar,
        { width: size, height: size, borderRadius: size / 2, backgroundColor: palette[index] },
      ]}
    >
      <Text style={[styles.avatarText, { fontSize: size * 0.38 }]}>{initials || '?'}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  button: {
    height: 52,
    borderRadius: radius.pill,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.lg,
  },
  buttonDisabled: { opacity: 0.45 },
  buttonPressed: { opacity: 0.85 },
  buttonText: { fontSize: 16, fontWeight: '700' },

  segmented: {
    flexDirection: 'row',
    backgroundColor: colors.surfaceAlt,
    borderRadius: radius.pill,
    padding: 5,
    borderWidth: 1,
    borderColor: colors.border,
  },
  segment: { flex: 1, paddingVertical: 12, borderRadius: radius.pill, alignItems: 'center' },
  segmentActive: { backgroundColor: colors.primary },
  segmentText: { fontSize: 15, fontWeight: '700', color: colors.textMuted },
  segmentTextActive: { color: colors.primaryText },

  field: { marginBottom: spacing.lg },
  fieldLabel: { ...typography.label, marginBottom: spacing.sm, color: colors.text },
  input: {
    height: 54,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    paddingHorizontal: spacing.lg,
    fontSize: 16,
    color: colors.text,
    backgroundColor: colors.surface,
  },
  fieldHint: { ...typography.small, marginTop: spacing.xs },

  errorBanner: {
    backgroundColor: colors.dangerBg,
    borderColor: colors.dangerBorder,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  errorText: { color: colors.danger, fontSize: 14 },

  notice: {
    backgroundColor: colors.infoBg,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  noticeSuccess: { backgroundColor: colors.successBg },
  noticeText: { color: colors.infoText, fontSize: 14 },
  noticeTextSuccess: { color: colors.primary },

  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl },
  emptyTitle: { ...typography.body, fontWeight: '600', marginBottom: spacing.xs },
  emptySubtitle: { ...typography.subtitle, textAlign: 'center' },

  link: { color: colors.primary, fontWeight: '700', fontSize: 15 },

  avatar: { alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#FFFFFF', fontWeight: '700' },
});
