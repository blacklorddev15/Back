import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Avatar } from './ui';
import { useAuth } from '../state/AuthContext';
import { bottomSystemBarClearance, colors, spacing, typography } from '../theme';

/**
 * The side menu behind the three-dot button in the tab headers.
 *
 * Opens from the right, anchored to the same corner as the button that summoned
 * it, which is where a hand already is when it taps the top-right of the screen.
 * Everything that used to be scattered across the chat-list header — profile,
 * server address, signing out — lives here, so the headers themselves only have
 * to carry a title.
 */

type Item = { key: string; label: string; icon: string; onPress: () => void; danger?: boolean; count?: number };

export function AppDrawer({
  onClose,
  onOpenProfile,
  onNewGroup,
  onOpenNotifications,
  onOpenServerSettings,
  unreadCount = 0,
}: {
  onClose: () => void;
  onOpenProfile: () => void;
  onNewGroup: () => void;
  onOpenNotifications: () => void;
  onOpenServerSettings: () => void;
  unreadCount?: number;
}) {
  const { user, signOut } = useAuth();

  // Wrapped so the drawer closes before the destination pushes: leaving it open
  // underneath the next screen means it reappears when that screen pops.
  const run = (action: () => void) => () => {
    onClose();
    action();
  };

  // Ordered the way WhatsApp's ⋮ menu is: the create action first, then the
  // settings entries. "New chat" is deliberately absent — that is the floating
  // button on the chat list, and WhatsApp does not offer it twice.
  const items: Item[] = [
    { key: 'newGroup', label: 'New group', icon: '👥', onPress: run(onNewGroup) },
    {
      key: 'notifications',
      label: 'Notifications',
      icon: '🔔',
      onPress: run(onOpenNotifications),
      // The count rides on the label so the drawer needs no extra layout for it.
      count: unreadCount,
    },
    { key: 'profile', label: 'Profile', icon: '👤', onPress: run(onOpenProfile) },
    { key: 'server', label: 'Server settings', icon: '🖥️', onPress: run(onOpenServerSettings) },
    { key: 'signOut', label: 'Sign out', icon: '🚪', onPress: run(() => void signOut()), danger: true },
  ];

  return (
    <View style={styles.overlay}>
      <Pressable style={styles.scrim} onPress={onClose} accessibilityLabel="Close menu" />
      <View style={styles.panel}>
        <View style={styles.identity}>
          <Avatar name={user?.fullName ?? user?.email ?? '?'} />
          <View style={styles.identityText}>
            <Text style={styles.name} numberOfLines={1}>
              {user?.fullName ?? 'Signed in'}
            </Text>
            <Text style={styles.email} numberOfLines={1}>
              {user?.email ?? ''}
            </Text>
          </View>
        </View>

        <ScrollView>
          {items.map((item) => (
            <Pressable key={item.key} style={styles.item} onPress={item.onPress}>
              <Text style={styles.itemIcon}>{item.icon}</Text>
              <Text style={[styles.itemLabel, item.danger && styles.itemLabelDanger]}>{item.label}</Text>
              {item.count && item.count > 0 ? (
                <View style={styles.countPill}>
                  <Text style={styles.countText}>{item.count > 99 ? '99+' : String(item.count)}</Text>
                </View>
              ) : null}
            </Pressable>
          ))}
        </ScrollView>

        <Text style={styles.footnote}>Varnox Chat · tap outside to close</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  // Spelled out rather than StyleSheet.absoluteFillObject: the shorthand is not
  // in this React Native version's types.
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  scrim: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.6)' },
  panel: {
    width: '78%',
    maxWidth: 340,
    backgroundColor: colors.surface,
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
    paddingTop: spacing.xxl,
    paddingBottom: spacing.md + bottomSystemBarClearance,
  },
  identity: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  identityText: { flex: 1 },
  name: { fontSize: 16, fontWeight: '700', color: colors.text },
  email: { ...typography.small, marginTop: 2 },
  item: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  itemIcon: { fontSize: 18, width: 24, textAlign: 'center' },
  itemLabel: { flex: 1, fontSize: 16, color: colors.text },
  itemLabelDanger: { color: colors.danger },
  countPill: {
    minWidth: 24,
    height: 22,
    borderRadius: 11,
    paddingHorizontal: 6,
    backgroundColor: colors.danger,
    alignItems: 'center',
    justifyContent: 'center',
  },
  countText: { color: '#FFFFFF', fontSize: 12, fontWeight: '700' },
  footnote: { ...typography.small, paddingHorizontal: spacing.lg, paddingTop: spacing.sm },
});
