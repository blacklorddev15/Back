import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { bottomSystemBarClearance, colors, spacing, typography } from '../theme';

/**
 * The four top-level destinations, plus the header the tab screens share.
 *
 * Deliberately hand-rolled rather than pulling in react-navigation's bottom
 * tabs: the app's navigation is still a stack with four roots, and the tab bar
 * is a row of pressables. Adding the navigation stack's dependencies for that
 * would cost a rebuild of the native project, which is not available right now.
 */

export type Tab = 'chats' | 'calls' | 'updates' | 'tools';

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: 'chats', label: 'Chats', icon: '💬' },
  { id: 'calls', label: 'Calls', icon: '📞' },
  { id: 'updates', label: 'Updates', icon: '📣' },
  { id: 'tools', label: 'Tools', icon: '⚙️' },
];

export function TabBar({ active, onSelect }: { active: Tab; onSelect: (tab: Tab) => void }) {
  return (
    <View style={styles.bar}>
      {TABS.map((tab) => {
        const selected = tab.id === active;
        return (
          <Pressable
            key={tab.id}
            style={styles.tab}
            onPress={() => onSelect(tab.id)}
            accessibilityRole="tab"
            accessibilityState={{ selected }}
          >
            <View style={[styles.iconWrap, selected && styles.iconWrapActive]}>
              {/* Emoji carry their own colour, so the active state is shown on
                  the pill behind the icon and on the label underneath. */}
              <Text style={styles.icon}>{tab.icon}</Text>
            </View>
            <Text style={[styles.label, selected && styles.labelActive]}>{tab.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

/**
 * Header for a tab root: a title on the left, and the three-dot button that
 * opens the drawer on the right. Every tab uses it so the drawer is reachable
 * from wherever you are, which is the point of putting it in the header rather
 * than burying it in a settings screen.
 */
export function TabHeader({
  title,
  subtitle,
  onOpenDrawer,
  onPressTitle,
  onOpenNotifications,
  unreadCount = 0,
}: {
  title: string;
  subtitle?: string;
  onOpenDrawer: () => void;
  onPressTitle?: () => void;
  /** Omit to hide the bell — the other tabs do not pass it. */
  onOpenNotifications?: () => void;
  unreadCount?: number;
}) {
  const titleBlock = (
    <>
      <Text style={styles.title} numberOfLines={1}>
        {title}
      </Text>
      {subtitle ? (
        <Text style={styles.subtitle} numberOfLines={1}>
          {subtitle}
        </Text>
      ) : null}
    </>
  );

  return (
    <View style={styles.header}>
      {onPressTitle ? (
        <Pressable style={styles.headerText} onPress={onPressTitle} hitSlop={6}>
          {titleBlock}
        </Pressable>
      ) : (
        <View style={styles.headerText}>{titleBlock}</View>
      )}
      {onOpenNotifications ? (
        <Pressable
          onPress={onOpenNotifications}
          hitSlop={10}
          accessibilityLabel={unreadCount > 0 ? `Notifications, ${unreadCount} unread` : 'Notifications'}
          style={styles.bell}
        >
          <Text style={styles.bellText}>🔔</Text>
          {unreadCount > 0 ? (
            <View style={styles.bellBadge}>
              <Text style={styles.bellBadgeText}>{unreadCount > 99 ? '99+' : String(unreadCount)}</Text>
            </View>
          ) : null}
        </Pressable>
      ) : null}
      <Pressable onPress={onOpenDrawer} hitSlop={10} accessibilityLabel="Open menu" style={styles.dots}>
        <Text style={styles.dotsText}>⋮</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.surface,
    paddingTop: spacing.sm,
    // The tab bar is pinned to the bottom of the window, so it has to clear the
    // system navigation bar itself — see bottomSystemBarClearance in theme.ts.
    paddingBottom: bottomSystemBarClearance,
  },
  tab: { flex: 1, alignItems: 'center', gap: 2 },
  iconWrap: {
    minWidth: 56,
    paddingHorizontal: spacing.lg,
    paddingVertical: 3,
    borderRadius: 999,
    alignItems: 'center',
  },
  iconWrapActive: { backgroundColor: colors.primarySoft },
  icon: { fontSize: 19 },
  label: { ...typography.small, fontSize: 11 },
  labelActive: { color: colors.primary, fontWeight: '600' },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  headerText: { flex: 1 },
  title: { ...typography.title, fontSize: 24 },
  subtitle: { ...typography.small, marginTop: 2 },
  dots: { paddingHorizontal: spacing.xs },
  dotsText: { fontSize: 26, color: colors.text, lineHeight: 28 },
  bell: { paddingHorizontal: spacing.xs, paddingVertical: spacing.xs },
  bellText: { fontSize: 19 },
  bellBadge: {
    position: 'absolute',
    top: -2,
    right: -6,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 4,
    backgroundColor: colors.danger,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bellBadgeText: { color: '#FFFFFF', fontSize: 10, fontWeight: '700' },
});
